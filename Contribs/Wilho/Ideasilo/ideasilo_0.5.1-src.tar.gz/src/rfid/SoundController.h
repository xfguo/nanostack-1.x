#ifndef SOUNDCONTROLLER_H_
#define SOUNDCONTROLLER_H_

#include <map>
#include <queue>
#include <pthread.h>

using namespace std;

class SoundController
{
public:
	typedef map<string, string>		sounds;
	typedef queue<string>			queue;
	
	SoundController();
	virtual ~SoundController();
	
	void loadSounds(const string & dir);
	void requestSound(const string & soundid);
	void checkRequests();
	
private:
	void playSound(const string & soundid);
	
	pthread_mutex_t	_requestlock;
	pthread_mutex_t	_soundlock;
	
	sounds		_sounds;
	queue		_queue;
	
	
};

#endif /*SOUNDCONTROLLER_H_*/
