#ifndef RFIDREADER_H_
#define RFIDREADER_H_

#include "AppData.h"
#include "util/Thread.h"
#include "event/Event.h"
#include "event/EventBuffer.h"
#include "dataformat/Node.h"
#include "util/SettingHandler.h"
#include "main.h"
#include "SoundController.h"

// nSniff
//#include <stdio.h>
//#include <sys/types.h>
//#include <sys/socket.h>
#include <sys/time.h>
//#include <netinet/in.h>

#include <arpa/inet.h>
//#include <unistd.h>

//#include <strings.h>
//#include <string.h>
//#include <signal.h>
//#include <stdlib.h>

#include <sys/poll.h>

#define NPING_PORT 0xfd
#define FLAGS    0              /* flags argument, must be zero */

using namespace std;


class NRPPacket {
public:
	NRPPacket();
	~NRPPacket();
	
	void clear();
	
	unsigned char * rbuf;
	unsigned char * data;
	int len;
	string timestamp;
	unsigned char d_len;
	unsigned char prot;

	unsigned char s_type, s_addr[12];
	unsigned char d_type, d_addr[12];
	unsigned short int s_port, d_port;

	unsigned short int siglvl;
	unsigned short int seq;

	static const int BUFFER_SIZE = 256;
	
};

class NDEFMessage {
public:
	
	~NDEFMessage();
	
	static NDEFMessage * parse(const unsigned char * data, unsigned long len);
	
	static const unsigned char MSG_BEGIN = 1 << 7;
	static const unsigned char MSG_END = 1 << 6;
	static const unsigned char CHUNK = 1 << 5;
	static const unsigned char SHORT_RECORD = 1 << 4;
	static const unsigned char ID_LEN = 1 << 3;
	
	unsigned char getTNF()		{ return _header & 0x7; }
	unsigned char getTypeLength() { return _typelen; }
	unsigned long getLength()	{ return _payloadlen; }
	string toString()			{ return string(_payload); }
	
	
private:
	NDEFMessage();
	NDEFMessage(const NDEFMessage & ot);		// No implementation
	
	bool isSet(unsigned char flag) { return _header & flag; } 
	
	unsigned char _ndefversion;
	unsigned char _memorysize;
	unsigned char _rwaccess;
	unsigned char _vfieldtype;
	unsigned int _vfieldlen;
	
	// V-Field
	unsigned int _header;
	unsigned int _typelen;
	unsigned int _idlen;
	unsigned long _payloadlen;
	unsigned char * _type;
	unsigned char * _id;
	char * _payload;	
};

class RFIDReader : public Thread, public SoundController
{
public:
	RFIDReader(AppData * appdata, EventBuffer::Writer * writer, SettingHandler & appsettings);
	~RFIDReader();
	
	void			setNRouteAvailable(bool available, bool running);
	static string 	getTimeString();
	void 			raiseTestMsg_v2(const string & nodeid);
	
private:
	enum NRoutedConnectionStatus { NROUTE_NOT_AVAILABLE, NROUTE_AVAILABLE, NROUTE_RUNNING, NROUTE_CONNECTION_READY };
	
	AppData * 				_appdata;				// Struct containing system data
	EventBuffer::Writer * 	_writer;				// Object used for generating events
	SettingHandler & 		_appsettings;			// User modifiable application settings
	
	virtual int setup();							// Called when the thread is initialized
	virtual int run();								// Called when the thread is started
	
	bool handlePollingError(int error);
	// Try to raise an event signaling that a new dataset has been read. Disregards empty datasets
	bool raiseRFIDReadEvent(Node * newnode);
	
	
	bool 	nRoutedStatusUpdate();	// Checks if nRouted is ok and tries to repair it if not. Returns true upon success
	int 	nRoutedConfigure(const char ** message);	// Tries to subscribe to nRouted

	NRoutedConnectionStatus	_nroute_status;
	int 		_retrywait;
	int 		_failcount;
	
	
	// from nSniff
	pollfd 	_pfds;		// For storing information about polling nRouted
	int 	_sockfd;	// TCP socket to nRouted
	sockaddr_in srvaddr;
	
};



#endif /*RFIDREADER_H_*/
