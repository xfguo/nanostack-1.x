#include "RFIDEvent.h"
#include "gui/GUI.h"
#include "network/NetworkController.h"
#include "EventMonitor.h"

#include <iostream>

using namespace std;

bool RFIDReadEvent::process(ApplicationContext & context)
{
	Node * newnode = detach();
	string ID = newnode->getID();
	//if (context.gui.updateDataBaseWithRootNode(newnode)) {
	context.gui.updateDataBaseWithRootNode(newnode);
	context.net.queryServerNode(ID);
	//}
	return true;
}

Node * RFIDReadEvent::detach() {
	Node * temp = _node;
	_node = NULL;
	return temp;
}

bool NRouteTerminationEvent::process(ApplicationContext & context) { 
	cout << "--> NRouteTerminationEvent::process" << endl;
	//if (context.evmon.getNRouteStatus() == EventMonitor::NROUTE_RUNNING)
	context.evmon.nRouteStop();
	cout << "<-- NRouteTerminationEvent::process" << endl;
	return true; 
}

bool NRouteRestartRequestEvent::process(ApplicationContext & context) { 
	if (context.evmon.getNRouteStatus() == EventMonitor::NROUTE_RUNNING)
		context.evmon.nRouteStop();
	if (context.evmon.getNRouteStatus() == EventMonitor::NROUTE_STOPPED)
		context.evmon.nRouteStart();

	return true; 
}

bool NRouteStartRequestEvent::process(ApplicationContext & context) { 
	if (context.evmon.getNRouteStatus() == EventMonitor::NROUTE_STOPPED ||
			context.evmon.getNRouteStatus() == EventMonitor::NROUTE_AVAILABLE)
		context.evmon.nRouteStart();

	return true; 
}


bool ReaderConnectionStatusChangeEvent::process(ApplicationContext & context)
{
	//cout << "Processing ReaderConnectionStatusChangeEvent, status " << _status << "..." << endl;
	context.rfid.setNRouteAvailable(_nroute_available, _nroute_running);
	context.gui.setReaderStatus(_connection_ready, _statusmsg);
	return true;
}
