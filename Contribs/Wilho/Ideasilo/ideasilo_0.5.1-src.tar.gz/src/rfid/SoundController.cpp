#include "SoundController.h"

#include <dirent.h>
#include <iostream>
#include <fstream>
#include <errno.h>
#include <glib-object.h>
#include <hildon-widgets/hildon-system-sound.h>
#include <sys/stat.h>	
#include "util/Util.h"

SoundController::SoundController()
{
	pthread_mutex_init(&_requestlock,NULL);
	pthread_mutex_init(&_soundlock,NULL);
}

SoundController::~SoundController()
{
}

void SoundController::loadSounds(const string & dirname) {
	DIR * dir = opendir(dirname.c_str());
	if (dir == NULL) {
		cerr << "SoundController::loadSounds: Error (" << errno << ") while opening sound directory: " << dirname << endl;
		return;
	}
	struct dirent * entry;
	string soundsuffix = ".WAV";
	pthread_mutex_lock(&_soundlock);
	while ((entry = readdir(dir)) != NULL) {
		string file = dirname + entry->d_name;
		if (file.length() < soundsuffix.length())
			continue;
		string filesuffix = file.substr(file.length()-soundsuffix.length(), soundsuffix.length());
		if (!Util::compareNoCase(filesuffix,soundsuffix)) {
			//cout << "Found sound file: " << file << endl;
			struct stat fileinfo;
			if (!stat(file.c_str(), &fileinfo)) {
				int lastslash = file.find_last_of("/");
				string id = file.substr(lastslash+1, file.length() - soundsuffix.length() - lastslash - 1);
				//cout << "Stored as id: " << id << endl;
				if (id.length() > 0)
					_sounds[id] = file;
				else
					cerr << "SoundController::loadSounds: Warning! File " << file << " lacks the actual filename" << endl;
				
			} else
				cerr << "SoundController::loadSounds: Warning! Could not stat sound file " << file << " for reading" << endl;
		}
	}
	closedir(dir);
	pthread_mutex_unlock(&_soundlock);
}

void SoundController::requestSound(const string & soundid) {
	//cout << "In SoundController::requestSound" << endl;
	//cout << "Requested sound: " << soundid << endl;
	pthread_mutex_lock(&_requestlock);
	_queue.push(soundid);
	pthread_mutex_unlock(&_requestlock);
	//cout << "Leaving SoundController::requestSound" << endl;
}

void SoundController::checkRequests() {
	//cout << "SoundController::checkRequests: " << _queue.size() << endl;
	while (!_queue.empty()) {
		pthread_mutex_lock(&_requestlock);
		if (_queue.empty()) {
			pthread_mutex_unlock(&_requestlock);
			return;
		}
		string nextsound(_queue.front());
		_queue.pop();
		pthread_mutex_unlock(&_requestlock);
		playSound(nextsound);
	}
}

void SoundController::playSound(const string & soundid) {
	//cout << "In SoundController::playSound" << endl;
	pthread_mutex_lock(&_soundlock);
	sounds::iterator it = _sounds.find(soundid);
	if (it != _sounds.end()) {
		//cout << "play file: " << it->second << endl;
		hildon_play_system_sound(it->second.c_str());
	}
	pthread_mutex_unlock(&_soundlock);
	//cout << "Leaving SoundController::playSound" << endl;
}
