#include "OrderingMode.h"

#include <dataformat/Branch.h>
#include <dataformat/TextLeaf.h>
#include <iostream>
#include "gui/dialog/SendOrderDialog.h"
#include "gui/action/GUIAction.h"
#include "gui/GladeTag.h"
#include "util/Util.h"
#include "GtkCellRendererButton.h"
#include "OrderingModeEvent.h"
#include "event/GUIEvent.h"

struct ColumnInfo {
	ColumnInfo(const string & theheader, const string & theid_suffix):header(theheader), id_suffix(theid_suffix), label(false) {}
	ColumnInfo(const string & theheader):header(theheader), label(true) {}
	string	header;
	string	id_suffix;
	bool	label;
};

class ColumnData {
public:	
	ColumnData() {}
	//ColumnData(const string & first) { _extrainfo.push_back(first); }
	~ColumnData() {}
	
	void 	addExtraHeader(const string & header, const string & idsuffix) { _extrainfo.push_back(ColumnInfo(header, idsuffix)); }
	void 	addExtraHeader(const string & header) { _extrainfo.push_back(ColumnInfo(header)); }
	
	int		getIDColumnID()			{ return 0; }
	int		getCountColumnID()		{ return _extrainfo.size() + 1; }
	int		getExtraColumnID(int n)	{ if (n >= 0 && n < (int)_extrainfo.size()) return 1+n; else return -1; }
	int		getExtraColumnN()		{ return _extrainfo.size(); }
	ColumnInfo & getExtraColumn(int n)	{ return _extrainfo[n]; }
	int 	getColumnN()			{ return _extrainfo.size() + 2; }
	GType *	createTypeArray()	{
		//cout << "size: " << size << " extrasize: " << extrasize << endl;
		GType * typearray = new GType[getColumnN()];
		for (int n = 0; n < getColumnN(); n++) {
			typearray[n] = G_TYPE_STRING;
		}
		return typearray;
	}
	
private:
	vector<ColumnInfo>	_extrainfo;
};


OrderingMode::OrderingMode(AppData * appdata, SettingHandler * appsettings, const DataBase & db, const rootnodes & rnodes):
ApplicationMode(appdata, appsettings, db, rnodes),
_columndata(NULL),
_rootxml(NULL),
_root(NULL),
_view(NULL),
_list(NULL),
_nodatapage(NULL)
{
	_opensendorderaction = new OpenSendOrderDialogAction(_appdata->evbuf->requestWriter(), _appdata->uifilename, "send", "Send", "Send order");
	_opensendorderaction->setTarget(this);
}

OrderingMode::~OrderingMode()
{
	//cout << "In OrderingMode::~OrderingMode" << endl;
	release();
	while (!_orderingdata.empty()) {
		orderingdata::iterator it = _orderingdata.begin();
		delete it->second;
		_orderingdata.erase(it);	
	}
	delete _opensendorderaction;
	//cout << "Leaving OrderingMode::~OrderingMode" << endl;
}

//OrderingNodeView * OrderingMode::getNodeView(const string & nodeid) {
//	for (nodeviews::iterator it = _nodeviews.begin();it != _nodeviews.end(); it++) {
//		if (*it && (*it)->getNode()) {
//			if (!nodeid.compare((*it)->getNode()->getID()))
//				return *it;
//		}
//	}
//	return NULL;
//}

void 	OrderingMode::activate() {
	GdkThread::enter();
	if (!_nodatapage) {
		GladeXML * nodataxml = glade_xml_new(_appdata->uifilename.c_str(), GLADE::COMMON::NODATAPAGE, NULL);
		_nodatapage = glade_xml_get_widget(nodataxml, GLADE::COMMON::NODATAPAGE); // Store the info page for later use
		g_object_ref(_nodatapage);				// Store the empty page for later use
		gtk_object_sink(GTK_OBJECT(_nodatapage));
		g_object_unref(nodataxml);
	}
	if (!_rootxml) {
		_rootxml = glade_xml_new(_appdata->uifilename.c_str(), GLADE::ORDERING::ROOT,NULL);
	}
	if (!_root && _rootxml) {
		_root = glade_xml_get_widget(_rootxml, GLADE::ORDERING::ROOT);
		g_object_ref(_root);				// Store the empty page for later use
		gtk_object_sink(GTK_OBJECT(_root));
		// Get context information about required extra information columns
		ContextSetting extrainfo = _currentcontext->getSetting("/extrainfo");
		_columndata = new ColumnData();
		if (extrainfo.isEmpty() == false) {
			const Context::settings & extrainfolist = extrainfo.getChildren();
			for (Context::settings::const_iterator it = extrainfolist.begin(); it != extrainfolist.end(); it++) {
				const ContextSetting * header = it->second->getSetting("/header");
				const ContextSetting * idsuffix = it->second->getSetting("/id_suffix");
				if (header && idsuffix) {
					//cout << "Found header: " << header->getData() << endl;
					_columndata->addExtraHeader(header->getData(), idsuffix->getData());
				} else if (header) {
					_columndata->addExtraHeader(header->getData());
				}
			}
		}
		if (_columndata->getExtraColumnN() == 0)
			_columndata->addExtraHeader("Item");
							
		// Create the liststore model
		GType * typearray = _columndata->createTypeArray();
		_list = gtk_list_store_newv(_columndata->getColumnN(), typearray);
		delete [] typearray;
		// Fetch the treeview from the glade file and bind the model to it
		_view = GTK_TREE_VIEW(glade_xml_get_widget(_rootxml, GLADE::ORDERING::VIEW));
		gtk_tree_view_set_model(_view, GTK_TREE_MODEL(_list));
		gtk_tree_view_columns_autosize(_view);
		gtk_tree_view_set_rules_hint(_view, true);
		// Set up the view selection mode
		GtkTreeSelection * select = gtk_tree_view_get_selection(_view);
		gtk_tree_selection_set_mode(select, GTK_SELECTION_BROWSE);
		// Set up the treeview columns
		gtk_tree_view_set_headers_visible(_view, true);
		GtkTreeViewColumn * newcolumn;
		GtkCellRenderer * newrenderer;
		newrenderer = gtk_cell_renderer_text_new();
		g_object_set(newrenderer, "foreground", "red", "size-points", 8.0, NULL);
		newcolumn = gtk_tree_view_column_new_with_attributes("ID", newrenderer, "text", _columndata->getIDColumnID(), NULL);//"size-points", 12.0, "foreground", "red",  NULL);
		gtk_tree_view_column_set_visible(newcolumn, false);		// Hide the ID column. ID is only used internally, no need to present it to the user
		gtk_tree_view_append_column(_view, newcolumn);
		
		for (int n = 0; n < _columndata->getExtraColumnN(); n++) {
			newrenderer = gtk_cell_renderer_text_new();
			if (n != 0)
				g_object_set(newrenderer, "xalign", 0.5f, NULL);
			newcolumn = gtk_tree_view_column_new_with_attributes(_columndata->getExtraColumn(n).header.c_str(), newrenderer, "text", _columndata->getExtraColumnID(n), NULL);
			if (n == 0)
				gtk_tree_view_column_set_expand(newcolumn, true);
			gtk_tree_view_append_column(_view, newcolumn);
		}
		
		newrenderer = gtk_cell_renderer_button_new();
		g_object_set(newrenderer, "stock-id", GTK_STOCK_REMOVE, "mode", GTK_CELL_RENDERER_MODE_ACTIVATABLE, NULL);
		g_signal_connect(newrenderer, "activated", G_CALLBACK(decrease_button_clicked), this);
		newcolumn = gtk_tree_view_column_new_with_attributes("", newrenderer, NULL);
		//gtk_tree_view_column_set_sizing(newcolumn, GTK_TREE_VIEW_COLUMN_FIXED);
		gtk_tree_view_append_column(_view, newcolumn);
		
		newrenderer = gtk_cell_renderer_text_new();
		g_object_set(newrenderer, "xalign", 0.5f, "mode", GTK_CELL_RENDERER_MODE_EDITABLE, NULL);
		newcolumn = gtk_tree_view_column_new_with_attributes("#", newrenderer, "text", _columndata->getCountColumnID(), NULL);
		gtk_tree_view_column_set_sizing(newcolumn, GTK_TREE_VIEW_COLUMN_AUTOSIZE);
		//gtk_tree_view_column_set_alignment(newcolumn, 0.5f);
		gtk_tree_view_append_column(_view, newcolumn);
		
		newrenderer = gtk_cell_renderer_button_new();
		g_signal_connect(newrenderer, "activated", G_CALLBACK(increase_button_clicked), this);
		g_object_set(newrenderer, "stock-id", GTK_STOCK_ADD, "mode", GTK_CELL_RENDERER_MODE_ACTIVATABLE, NULL);
		newcolumn = gtk_tree_view_column_new_with_attributes("", newrenderer, NULL);
		gtk_tree_view_append_column(_view, newcolumn);
		
		GtkWidget * widget = glade_xml_get_widget(_rootxml, GLADE::ORDERING::CLOSE_BUTTON);
		g_signal_connect(widget, "clicked", G_CALLBACK(close_button_clicked), this);
	}
	refreshNodes();
	setFrontpage();
	GdkThread::leave();
}

void 	OrderingMode::release() {
	//cout << "In OrderingMode::release" << endl;
	GdkThread::enter();
	resetToolbar();
	_frontwidget = NULL;
//	while (!_nodeviews.empty()) {
//		nodeviews::iterator it = _nodeviews.begin();
//		//it->second->releaseWidgets();
//		delete *it;
//		_nodeviews.erase(it);	
//	}
	if (_nodatapage) {
		g_object_unref(_nodatapage);
		_nodatapage = NULL;
	}
	if (_root) {
		g_object_unref(_root);
		_root = NULL;
		// TODO: Make sure there's no memory leak here
		_view = NULL;
		_list = NULL;
		delete _columndata;
	}
	if (_rootxml) {
		g_object_unref(_rootxml);
		_rootxml = NULL;
	}
	GdkThread::leave();
	//cout << "Leaving OrderingMode::release" << endl;
}

void	OrderingMode::setToolbar(GtkToolbar * toolbar) {
	if (!_toolbar) {
		_toolbar = toolbar;
		_opensendorderaction->addToToolbar(_toolbar);
		//_removenodeaction->addToToolbar(_toolbar);
	}
}

void	OrderingMode::resetToolbar() {
	//cout << "In OrderingMode::resetToolbar" << endl;
	if (_toolbar) {
		
		_opensendorderaction->removeFromToolbar(_toolbar);
		//_removenodeaction->removeFromToolbar(_toolbar);
		_toolbar = NULL;
	}
	//cout << "Leaving OrderingMode::resetToolbar" << endl;
}

void	OrderingMode::refreshNode(const string & nodeid) {
	//cout << "in OrderingMode::refreshNode: " << nodeid << endl;
	GdkThread::enter();
	const Node * node = getNode(nodeid);
	if (node) {
		int index = isRootNode(node->getID());
		if (index != -1) {
			orderingdata::iterator oddit = _orderingdata.find(nodeid);
			OrderingData * orderingdata = NULL;
			if (oddit != _orderingdata.end())
				orderingdata = oddit->second;
			else {
				orderingdata = new OrderingData;
				_orderingdata[nodeid] = orderingdata;
			}
			refreshRow(node, index, orderingdata);
		}
	} else {
		removeReferencesToNode(nodeid);
	}
	setFrontpage();
	GdkThread::leave();
	//cout << "leaving OrderingMode::refreshNode: " << nodeid << endl;
}

void	OrderingMode::refreshRow(const Node * node, int index, OrderingData * orderingdata) {
	//cout << "In OrderingMode::refreshRow" << endl;
	// Find the correct line in the view
	GtkTreeModel * model = GTK_TREE_MODEL(_list);
	GtkTreeIter it;
	bool valid = gtk_tree_model_get_iter_first(model, &it);
	while (valid) {
		gchar * id;
		gtk_tree_model_get(model, &it, _columndata->getIDColumnID(), &id, -1);
		bool equal = !strcmp(node->getID().c_str(), id);
		g_free(id);
		if (equal)
			break;
		valid = gtk_tree_model_iter_next(model, &it);
	}
	if (!valid) {
		gtk_list_store_insert_with_values(_list, &it, index, _columndata->getIDColumnID(), node->getID().c_str(), -1);
	}
	if (node->getContentType() == NodeContent::TYPE_BRANCH) {
		for (int n = 0; n < _columndata->getExtraColumnN(); n++) {
			ColumnInfo & info = _columndata->getExtraColumn(n);
			if (info.label == false) {
				const Branch * branch = static_cast<const Branch*>(node->getContents());
				const Branch::children & children = branch->getChildren();
				for (Branch::children::const_iterator childit = children.begin(); childit != children.end(); childit++) {
					string childid = childit->first;
					if (Util::stringEndsWith(childid, info.id_suffix)) {
						const Node * child = childit->second;
						if (!child)
							child = getNode(childid);
						if (child && child->getContentType() == NodeContent::TYPE_TEXT) {
							const TextLeaf * textchild = static_cast<const TextLeaf*>(child->getContents());
							gtk_list_store_set(_list, &it, _columndata->getExtraColumnID(n), textchild->getData().c_str(),-1);
						}
					}
				}
			} else {
				gtk_list_store_set(_list, &it, _columndata->getExtraColumnID(n), node->getContents()->getLabel().c_str(),-1);
			}
		}
	} else if (node->getContentType() == NodeContent::TYPE_TEXT && _columndata->getExtraColumnN() > 0) {
		gtk_list_store_set(_list, &it, _columndata->getExtraColumnID(0), node->getContents()->getLabel().c_str(), -1);
	}
	stringstream ss;
	ss << orderingdata->count;
	gtk_list_store_set(_list, &it, _columndata->getCountColumnID(), ss.str().c_str(), -1);
	//cout << "leaving OrderingMode::refreshRow" << endl;
}

void OrderingMode::removeReferencesToNode(const string & nodeid) {
	GtkTreeModel * model = GTK_TREE_MODEL(_list);
	GtkTreeIter it;
	bool valid = gtk_tree_model_get_iter_first(model, &it);
	while (valid) {
		gchar * id;
		gtk_tree_model_get(model, &it, _columndata->getIDColumnID(), &id, -1);
		bool equal = !strcmp(nodeid.c_str(), id);
		g_free(id);
		if (equal)
			break;
		valid = gtk_tree_model_iter_next(model, &it);
	}
	if (valid) {
		gtk_list_store_remove(_list, &it);	
	}
}

string OrderingMode::getSelection() {
	GtkTreeSelection *selection = gtk_tree_view_get_selection(_view);
	GtkTreeIter it;
	GtkTreeModel * model;
	gchar * nodeid = NULL;
	string result;
	if (gtk_tree_selection_get_selected(selection, &model, &it)) {
		gtk_tree_model_get(model, &it, _columndata->getIDColumnID(), &nodeid, -1);
		result = nodeid;
		g_free(nodeid);
	}
	if (nodeid)
		return result;
	else 
		return "";
}

void OrderingMode::increaseCount(const string & nodeid) {
	orderingdata::iterator it = _orderingdata.find(nodeid);
	if (it != _orderingdata.end()) {
		OrderingData * data = it->second;
		if (data->count + data->step >= data->countmax)
			data->count = data->countmax;
		else
			data->count += data->step;
		refreshNode(nodeid);
	}
}

void OrderingMode::decreaseCount(const string & nodeid) {
	orderingdata::iterator it = _orderingdata.find(nodeid);
	if (it != _orderingdata.end()) {
		OrderingData * data = it->second;
		if (data->count - data->step < data->countmin)
			data->count = data->countmin;
		else
			data->count -= data->step;
		refreshNode(nodeid);
	}
}


void OrderingMode::increase_button_clicked(GtkCellRenderer * rend, gchar * path, OrderingMode * mode) {
	GtkTreeIter it;
	gtk_tree_model_get_iter_from_string(GTK_TREE_MODEL(mode->_list), &it, path);
	gchar * nodeid = NULL;
	gtk_tree_model_get(GTK_TREE_MODEL(mode->_list), &it, mode->_columndata->getIDColumnID(), &nodeid, -1);
	mode->_writer->push(new ModifyOrderEvent(ModifyOrderEvent::INCREASE_STEP, nodeid));
	g_free(nodeid);
}
void OrderingMode::decrease_button_clicked(GtkCellRenderer * rend,  gchar * path, OrderingMode * mode) {
	GtkTreeIter it;
	gtk_tree_model_get_iter_from_string(GTK_TREE_MODEL(mode->_list), &it, path);
	gchar * nodeid = NULL;
	gtk_tree_model_get(GTK_TREE_MODEL(mode->_list), &it, mode->_columndata->getIDColumnID(), &nodeid, -1);
	mode->_writer->push(new ModifyOrderEvent(ModifyOrderEvent::DECREASE_STEP, nodeid));
	g_free(nodeid);
}

void OrderingMode::close_button_clicked(GtkButton * button, OrderingMode * mode) {
	string nodeid = mode->getSelection();
	if (nodeid.length() == 0)
		return;
	mode->_writer->push(new RemoveNodeEvent(nodeid));
}


void	OrderingMode::setFrontpage() {
	_frontwidget = _root;
}
