#ifndef ORDERINGMODE_H_
#define ORDERINGMODE_H_

#include <set>
#include "gui/ApplicationMode.h"
//#include "OrderingNodeView.h"
#include "gui/action/Action.h"

using namespace std;

class OrderingData {
public:
	OrderingData():
		count(0),step(1),countmin(0),countmax(999) {}
	
	float		count, step, countmin, countmax;
};

class ColumnData;
class OrderingMode: public ApplicationMode
{
public:
	typedef map<string, OrderingData*> 	orderingdata;
	
	static const int MODE_ID = 2;
		
	OrderingMode(AppData * appdata, SettingHandler * appsettings, const DataBase & db, const rootnodes & rnodes);
	virtual ~OrderingMode();
	
	virtual int 	getModeID()		{ return MODE_ID; }
	void setFocus(const string & pageid);
	
	virtual void 	activate();				// Called when the mode is activated, for example when selected from the toolbar 
	virtual void 	release();				// Called when the mode is disabled in favor of some other mode. This function is supposed to destroy the widgets
	
	virtual void	setToolbar(GtkToolbar * toolbar); 	// Modifies the application toolbar to suit the current mode
	virtual void	resetToolbar();						// Undoes the changes made in setToolbar
	virtual void	refreshNode(const string & nodeid);	// Signals that a particular datapage has changed. This should also update the screen
	virtual string	getSelection();
	
	void 	increaseCount(const string & nodeid);
	void 	decreaseCount(const string & nodeid);
	
	GtkListStore * 	getForm()		{ return _list; }
	
protected:
	//OrderingNodeView *	getNodeView(const string & nodeid);
	
	virtual void	setFrontpage();		// Called when there is a reason why the front page in the mode might have changed
	
	ColumnData *		_columndata;
	
	GladeXML * 			_rootxml;
	GtkWidget *			_root;
	GtkTreeView *		_view;
	GtkListStore * 		_list;
	GtkWidget * 		_nodatapage;

	//nodeviews			_nodeviews;
	orderingdata		_orderingdata;
	
	Action * 			_opensendorderaction;

private:
	void	refreshRow(const Node * node, int index, OrderingData * orderingdata);
	void 	removeReferencesToNode(const string & nodeid);
	
	// Callbacks
	static void increase_button_clicked(GtkCellRenderer * rend, gchar * path, OrderingMode * mode);
	static void decrease_button_clicked(GtkCellRenderer * rend,  gchar * path, OrderingMode * mode);
	static void close_button_clicked(GtkButton * button, OrderingMode * mode);
};

#endif /*ORDERINGMODE_H_*/
