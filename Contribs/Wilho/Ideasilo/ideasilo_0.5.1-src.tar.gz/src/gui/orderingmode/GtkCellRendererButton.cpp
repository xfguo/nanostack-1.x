#include "GtkCellRendererButton.h"
#include "gui/gtkmarshalers.h"

// GObject type system related functions
static void     gtk_cell_renderer_button_init(GtkCellRendererButton      *cellprogress);
static void     gtk_cell_renderer_button_class_init(GtkCellRendererButtonClass *klass);
static void     gtk_cell_renderer_button_get_property(GObject                    *object,
                                                             guint                    param_id,
                                                             GValue                  *value,
                                                             GParamSpec              *pspec);
static void     gtk_cell_renderer_button_set_property(GObject                    *object,
                                                             guint                    param_id,
                                                             const GValue            *value,
                                                             GParamSpec              *pspec);
static void     gtk_cell_renderer_button_finalize(GObject *gobject);

// The following functions form the core of the custom cell renderer
static void     gtk_cell_renderer_button_get_size(GtkCellRenderer            *cell,
                                                          GtkWidget               *widget,
                                                          GdkRectangle            *cell_area,
                                                          gint                    *x_offset,
                                                          gint                    *y_offset,
                                                          gint                    *width,
                                                          gint                    *height);
static void     gtk_cell_renderer_button_render(GtkCellRenderer            *cell,
														  GdkDrawable             *drawable,
                                                          GtkWidget               *widget,
                                                          GdkRectangle            *background_area,
                                                          GdkRectangle            *cell_area,
                                                          GdkRectangle            *expose_area,
                                                          GtkCellRendererState     flags);

static gboolean	cellActivated(GtkCellRenderer *cell, GdkEvent *event, GtkWidget *widget, const gchar *path, GdkRectangle *background_area, GdkRectangle *cell_area, GtkCellRendererState flags);


enum {
	PROP_0,
	PROP_NODE,
	
	// From GtkCellRendererPixbuf:
	PROP_STOCK_ID,
	PROP_STOCK_SIZE,
	PROP_STOCK_DETAIL,

};

enum {
  ACTIVATED,
  LAST_SIGNAL
};

static gpointer parent_class;
static guint gtk_cell_renderer_button_signals[LAST_SIGNAL];

const gchar * GTK_CELL_RENDERER_BUTTON_PATH = "gtk-cell-renderer-button-path";
#define GTK_CELL_RENDERER_BUTTON_GET_PRIVATE(obj) (G_TYPE_INSTANCE_GET_PRIVATE ((obj), GTK_TYPE_CELL_RENDERER_BUTTON, GtkCellRendererButtonPrivate))

typedef struct _GtkCellRendererButtonPrivate GtkCellRendererButtonPrivate;
struct _GtkCellRendererButtonPrivate
{
	// Pixbuf related:
	GdkPixbuf	*stock_pixbuf;
	gchar 		*stock_id;
	GtkIconSize stock_size;
	gchar 		*stock_detail;	
};


// Register the custom type with the GObject type system if it's not done yet.
// Everything else is done in the callbacks
GType gtk_cell_renderer_button_get_type() {
	static GType cell_multi_type = 0;

	if (cell_multi_type)
		return cell_multi_type;	// The type is registered already

	static const GTypeInfo cell_multi_info = {
			sizeof(GtkCellRendererButtonClass),
			NULL,                                                     // base_init
			NULL,                                                     // base_finalize
			(GClassInitFunc)gtk_cell_renderer_button_class_init,
			NULL,                                                     // class_finalize
			NULL,                                                     // class_data 
			sizeof(GtkCellRendererButton),
			0,                                                        // n_preallocs 
			(GInstanceInitFunc)gtk_cell_renderer_button_init,
	};

	// Register the type, presenting it as derived from GtkCellRenderer
	cell_multi_type = g_type_register_static(GTK_TYPE_CELL_RENDERER,
			"GtkCellRendererButton",
			&cell_multi_info, (GTypeFlags)0);

	return cell_multi_type;
}

// Set some default properties of the parent
static void gtk_cell_renderer_button_init(GtkCellRendererButton *rendbutton)
{
	GTK_CELL_RENDERER(rendbutton)->mode = GTK_CELL_RENDERER_MODE_INERT;

	GTK_CELL_RENDERER(rendbutton)->xalign = 0.0;
	GTK_CELL_RENDERER(rendbutton)->yalign = 0.5;
	GTK_CELL_RENDERER(rendbutton)->xpad = 0;
	GTK_CELL_RENDERER(rendbutton)->ypad = 0;

	GtkCellRendererButtonPrivate * priv = GTK_CELL_RENDERER_BUTTON_GET_PRIVATE(rendbutton);
	priv->stock_size = GTK_ICON_SIZE_BUTTON;
}

// Set up custom get_property and set_property functions, and override the parent's
// functions that need to be implemented. Make custom properties known to the system.
// Override 'activate' to enable cell activation
static void gtk_cell_renderer_button_class_init(GtkCellRendererButtonClass *klass)
{
	GtkCellRendererClass *cell_class   = GTK_CELL_RENDERER_CLASS(klass);
	GObjectClass         *object_class = G_OBJECT_CLASS(klass);

	parent_class           = g_type_class_peek_parent (klass);
	object_class->finalize = gtk_cell_renderer_button_finalize;

	// Set up custom property set and get functions
	object_class->get_property = gtk_cell_renderer_button_get_property;
	object_class->set_property = gtk_cell_renderer_button_set_property;

	// Set up the crucial cell rendering functions
	cell_class->get_size = gtk_cell_renderer_button_get_size;
	cell_class->render   = gtk_cell_renderer_button_render;
	cell_class->activate = cellActivated;
	
	// Finally install the custom properties
	// TODO: In case of additional properties, add installation code here
	
	// From GtkCellRendererPixbuf
	g_object_class_install_property (object_class, PROP_STOCK_ID, g_param_spec_string ("stock-id", "Stock ID", "The stock ID of the stock icon to render", NULL, (GParamFlags)G_PARAM_READWRITE));
	g_object_class_install_property (object_class, PROP_STOCK_SIZE, g_param_spec_uint ("stock-size", "Size", "The GtkIconSize value that specifies the size of the rendered icon", 0, G_MAXUINT, GTK_ICON_SIZE_MENU, (GParamFlags)G_PARAM_READWRITE));
	g_object_class_install_property (object_class, PROP_STOCK_DETAIL, g_param_spec_string ("stock-detail", "Detail", "Render detail to pass to the theme engine", NULL, (GParamFlags)G_PARAM_READWRITE));

	gtk_cell_renderer_button_signals[ACTIVATED] = g_signal_new ("activated",
				G_OBJECT_CLASS_TYPE (object_class),
				G_SIGNAL_RUN_LAST,
				G_STRUCT_OFFSET (GtkCellRendererButtonClass, activated),
				NULL, NULL,
				_gtk_marshal_VOID__STRING,
				G_TYPE_NONE, 1,
				G_TYPE_STRING);
	
	
	g_type_class_add_private (object_class, sizeof(GtkCellRendererButtonPrivate));
}

// The callback used for freeing the resources
static void gtk_cell_renderer_button_finalize(GObject *object)
{
	//GtkCellRendererButton *rendbutton = GTK_CELL_RENDERER_BUTTON(object);

	GtkCellRendererButtonPrivate * priv = GTK_CELL_RENDERER_BUTTON_GET_PRIVATE(object);
	if (priv->stock_pixbuf)
		g_object_unref(priv->stock_pixbuf);
	g_free(priv->stock_id);
	g_free(priv->stock_detail);
	// Then finalize the parent class
	(* G_OBJECT_CLASS(parent_class)->finalize)(object);
}

// Callback for getting properties
static void gtk_cell_renderer_button_get_property(GObject *object, 
		guint param_id, GValue *value, GParamSpec *psec)
{
	//GtkCellRendererButton *rendbutton = GTK_CELL_RENDERER_BUTTON(object);
	GtkCellRendererButtonPrivate * priv = GTK_CELL_RENDERER_BUTTON_GET_PRIVATE(object);

	switch (param_id) {
    case PROP_STOCK_ID:
      g_value_set_string (value, priv->stock_id);
      break;
    case PROP_STOCK_SIZE:
      g_value_set_uint (value, priv->stock_size);
      break;
    case PROP_STOCK_DETAIL:
      g_value_set_string (value, priv->stock_detail);
      break;
	default:
		G_OBJECT_WARN_INVALID_PROPERTY_ID(object, param_id, psec);
		break;
	}
}

// Callback for setting properties
static void gtk_cell_renderer_button_set_property (GObject *object,
		guint param_id, const GValue *value, GParamSpec *pspec)
{
	//GtkCellRendererButton *rendbutton = GTK_CELL_RENDERER_BUTTON(object);
	GtkCellRendererButtonPrivate * priv = GTK_CELL_RENDERER_BUTTON_GET_PRIVATE(object);
	
	switch (param_id) {
    case PROP_STOCK_ID:
    	if (priv->stock_id)
    		g_free (priv->stock_id);
    	if (priv->stock_pixbuf) {
    		g_object_unref(priv->stock_pixbuf);
    		priv->stock_pixbuf = NULL;
    	}
    	priv->stock_id = g_value_dup_string(value);
    	break;
    case PROP_STOCK_SIZE:
    	priv->stock_size = (GtkIconSize)g_value_get_uint(value);
    	break;
    case PROP_STOCK_DETAIL:
    	if (priv->stock_detail)
    		g_free (priv->stock_detail);
    	priv->stock_detail = g_value_dup_string(value);
    	break;
	default:
		G_OBJECT_WARN_INVALID_PROPERTY_ID(object, param_id, pspec);
		break;
	}
}

// Returns a new cell renderer instance
GtkCellRenderer * gtk_cell_renderer_button_new()
{
	return GTK_CELL_RENDERER(g_object_new(GTK_TYPE_CELL_RENDERER_BUTTON, NULL));
}

#include <iostream>
using namespace std;


static void createStockPixbuf(GtkCellRendererButton * multi, GtkWidget * widget) {
	GtkCellRendererButtonPrivate * priv = GTK_CELL_RENDERER_BUTTON_GET_PRIVATE(multi);

	if (priv->stock_pixbuf)
		g_object_unref (priv->stock_pixbuf);
	priv->stock_pixbuf = gtk_widget_render_icon(widget, priv->stock_id, priv->stock_size, priv->stock_detail);
	//g_object_notify(G_OBJECT(multi), "pixbuf");
}

// One of the core functions. Calculates the size of the cell to be rendered.
// Takes into accound padding and alignment properties of the parent.
static void gtk_cell_renderer_button_get_size (GtkCellRenderer *cell,
		GtkWidget *widget, GdkRectangle *cell_area, gint *x_offset,
		gint *y_offset, gint *width, gint *height)
{
	GtkCellRendererButton * multi = GTK_CELL_RENDERER_BUTTON(cell);
	GtkCellRendererButtonPrivate * priv = GTK_CELL_RENDERER_BUTTON_GET_PRIVATE(multi);
	if (!priv->stock_pixbuf)
		createStockPixbuf(multi, widget);
	if (!priv->stock_pixbuf)
		return;
	GdkPixbuf * pixbuf = priv->stock_pixbuf;
	
	gint pixbuf_width = gdk_pixbuf_get_width(pixbuf);
	gint pixbuf_height = gdk_pixbuf_get_height(pixbuf);
	gint calc_width = (gint)cell->xpad * 2 + pixbuf_width;
	gint calc_height = (gint)cell->ypad * 2 + pixbuf_height;

	if (cell_area && pixbuf_width > 0 && pixbuf_height > 0) {
		if (x_offset) {
			*x_offset = static_cast<int>(cell->xalign * (cell_area->width - calc_width));
			*x_offset = MAX (*x_offset, 0);
		}
		if (y_offset) {
			*y_offset = static_cast<int>(cell->yalign * (cell_area->height - calc_height));
			*y_offset = MAX (*y_offset, 0);
		}
	} else {
		if (x_offset) *x_offset = 0;
		if (y_offset) *y_offset = 0;
	}
	if (width) *width = calc_width;
	if (height) *height = calc_height;
	//cout << "gtk_cell_renderer_button_get_size: Width: " << calc_width << " Height: " << calc_height << endl;

}

//static void renderPixbuf(GtkCellRenderer *cell,
//		GdkDrawable *drawable, GtkWidget *widget, GdkRectangle *background_area,
//		GdkRectangle *cell_area, GdkRectangle *expose_area, GtkCellRendererState flags) {
//	GtkCellRendererButton * rendbutton = GTK_CELL_RENDERER_BUTTON(cell);
//	GdkRectangle pix_rect;
//	GdkRectangle draw_rect;
//	gtk_cell_renderer_button_get_size(cell, widget, cell_area,
//			&pix_rect.x, &pix_rect.y, &pix_rect.width, &pix_rect.height);
//	
//	pix_rect.x += cell_area->x;
//	pix_rect.y += cell_area->y;
//	pix_rect.width  -= cell->xpad * 2;
//	pix_rect.height -= cell->ypad * 2;
//	
//	if (gdk_rectangle_intersect (cell_area, &pix_rect, &draw_rect) &&
//			gdk_rectangle_intersect (expose_area, &draw_rect, &draw_rect)) {
//		gdk_draw_pixbuf(drawable, widget->style->black_gc, imageleaf->getImage(),
//				// pixbuf 0, 0 is at pix_rect.x, pix_rect.y 
//				draw_rect.x - pix_rect.x,
//				draw_rect.y - pix_rect.y,
//				draw_rect.x, draw_rect.y,
//				draw_rect.width, draw_rect.height,
//				GDK_RGB_DITHER_NORMAL, 0, 0);
//	}
//}

static void renderStockIcon(GtkCellRenderer *cell,
		GdkDrawable *drawable, GtkWidget *widget, GdkRectangle *background_area,
		GdkRectangle *cell_area, GdkRectangle *expose_area, GtkCellRendererState flags) {
	GtkCellRendererButton * rendbutton = GTK_CELL_RENDERER_BUTTON(cell);
	GtkCellRendererButtonPrivate * priv = GTK_CELL_RENDERER_BUTTON_GET_PRIVATE(rendbutton);
	GdkRectangle pix_rect;
	GdkRectangle draw_rect;
	gtk_cell_renderer_button_get_size(cell, widget, cell_area,
			&pix_rect.x, &pix_rect.y, &pix_rect.width, &pix_rect.height);
	
	pix_rect.x += cell_area->x;
	pix_rect.y += cell_area->y;
	pix_rect.width  -= cell->xpad * 2;
	pix_rect.height -= cell->ypad * 2;
	
	if (gdk_rectangle_intersect (cell_area, &pix_rect, &draw_rect) &&
			gdk_rectangle_intersect (expose_area, &draw_rect, &draw_rect)) {
		gdk_draw_pixbuf(drawable, widget->style->black_gc, priv->stock_pixbuf,
				// pixbuf 0, 0 is at pix_rect.x, pix_rect.y 
				draw_rect.x - pix_rect.x,
				draw_rect.y - pix_rect.y,
				draw_rect.x, draw_rect.y,
				draw_rect.width, draw_rect.height,
				GDK_RGB_DITHER_NORMAL, 0, 0);
	}
}

// One of the core callback functions. Does the actual rendering.
static void gtk_cell_renderer_button_render(GtkCellRenderer *cell,
		GdkDrawable *drawable, GtkWidget *widget, GdkRectangle *background_area,
		GdkRectangle *cell_area, GdkRectangle *expose_area, GtkCellRendererState flags)
{	
	//renderPixbuf(cell, drawable, widget, background_area, cell_area, expose_area, flags);
	renderStockIcon(cell, drawable, widget, background_area, cell_area, expose_area, flags);
	 
}

static gboolean	cellActivated(GtkCellRenderer *cell, GdkEvent *event, GtkWidget *widget, const gchar *path, GdkRectangle *background_area, GdkRectangle *cell_area, GtkCellRendererState flags) {
	//GtkCellRendererButton * rend = GTK_CELL_RENDERER_BUTTON(cell);
	g_signal_emit(cell, gtk_cell_renderer_button_signals[ACTIVATED], 0, path);
	return true;
}

