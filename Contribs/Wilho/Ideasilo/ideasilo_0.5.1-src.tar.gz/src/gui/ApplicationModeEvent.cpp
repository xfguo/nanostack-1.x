#include "ApplicationModeEvent.h"
#include "GUI.h"

bool ApplicationModeEvent::process(ApplicationContext & context) {
	ApplicationMode * mode = context.gui.getAppMode();
	if (mode && mode->getModeID() == _modeid) {
		return processInMode(mode);
	}
	return true;
}
