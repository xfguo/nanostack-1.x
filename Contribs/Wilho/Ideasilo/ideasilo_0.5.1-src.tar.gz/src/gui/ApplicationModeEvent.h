#ifndef APPLICATIONMODEEVENT_H_
#define APPLICATIONMODEEVENT_H_

#include "event/Event.h"
#include "ApplicationMode.h"

class ApplicationModeEvent: public Event {
public:	
	ApplicationModeEvent(int modeid): _modeid(modeid) { }
	virtual ~ApplicationModeEvent() {}
	
	bool process(ApplicationContext & context);

protected:
	virtual bool processInMode(ApplicationMode * mode) = 0;
	
private:
	int _modeid;
};
#endif /*APPLICATIONMODEEVENT_H_*/
