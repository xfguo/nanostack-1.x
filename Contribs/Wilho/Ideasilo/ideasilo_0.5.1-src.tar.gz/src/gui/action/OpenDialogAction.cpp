#include "OpenDialogAction.h"
#include "event/GUIEvent.h"

void OpenDialogAction::activate(void * target) {
	Dialog * newdialog = createDialog(target);
	if (newdialog)
		_evwriter->push(new OpenDialogEvent(newdialog));
}
