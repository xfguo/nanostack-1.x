#ifndef ACTION_H_
#define ACTION_H_

#include "util/widgethandler.h"
#include <string>
#include "event/EventBuffer.h"

using namespace std;

class Action
{
public:
	//Action(EventBuffer::Writer * writer);
	Action(EventBuffer::Writer * writer, 
			const string & name, const string & label, 
			const string & tooltip, const string & stock_id);
	virtual ~Action();
	void setTarget(void * target)		{ _target = target; }
	
	virtual void activate(void * target) = 0;
	GtkWidget * getMenuWidget();
	GtkWidget * getToolWidget();
	void addToMenu(GtkMenu * menu);
	void addToToolbar(GtkToolbar * toolbar, int pos=-1);
	void removeFromToolbar(GtkToolbar * toolbar);
	
protected:

	GtkAction * _action;
	EventBuffer::Writer * _evwriter;
	
	string _name;
	string _label;
	string _stockid;
	string _tooltip;
	string _toolbarlabel;
	
	bool visible;
	bool sensitive;

private:
	void * _target;
	static void activateEntryPoint(GtkWidget * widget, void * object);
	static const int WIDGETCOUNT = 2;
	GtkWidget * createWidget(int n);
	GtkWidget * _widgets[WIDGETCOUNT];
};

#endif /*ACTION_H_*/
