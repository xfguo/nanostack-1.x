#ifndef GUIACTION_H_
#define GUIACTION_H_

#include "gui/action/Action.h"

class RemoveNodeAction : public Action
{
public:
	RemoveNodeAction(EventBuffer::Writer * writer, const string & name, 
		const string & label, const string & tooltip):
		Action(writer, name, label, tooltip, "gtk-delete") {}
	virtual ~RemoveNodeAction() {}
	
	// The target should be set to point to the current ApplicationMode implementation
	virtual void	activate(void * target); 
	
};

#endif /*GUIACTION_H_*/
