#ifndef APPLICATIONMODE_H_
#define APPLICATIONMODE_H_

#include <list>
#include "AppData.h"
#include "main.h"
#include "util/widgethandler.h"
#include "util/SettingHandler.h"
#include "dataformat/DataBase.h"
#include "event/EventBuffer.h"
#include "gui/Context.h"

/**
 * ApplicationMode is the interface for classes that represent the data stored
 * in the memory. The implementing classes will be accessed with the virtual
 * functions defined in this class.
 **/
class ApplicationMode
{
public:
	friend class NodeView;
	
	typedef list<string>				rootnodes;
	
	ApplicationMode(AppData * appdata, SettingHandler * appsettings, const DataBase & db, const rootnodes & rnodes);
	virtual ~ApplicationMode();
	
	virtual int 	getModeID() = 0;
	const Node *	getNode(const string & ID) const;
	Node *			getNodeCopy(const string & ID, int depth) const;
	int				isRootNode(const string & nodeid) const;
	virtual GtkWidget * getFrontWidget()		{ return _frontwidget; }
	
	virtual void 	activate() = 0;				// Called when the mode is activated, for example when selected from the toolbar 
	virtual void 	release() = 0;				// Called when the mode is disabled in favor of some other mode. This function is supposed to destroy the widgets
	
	void			setContext(const Context * newcontext);
	virtual void	setToolbar(GtkToolbar * toolbar) = 0; 	// Modifies the application toolbar to suit the current mode
	virtual void	resetToolbar()=0;						// Undoes the changes made in setToolbar
	void			refreshNodes();
	virtual void	refreshNode(const string & nodeid) = 0;	// Signals that a particular node has changed. This should also update the screen
	virtual void	activateNodeView(const string & nodeid) {}
	virtual string	getSelection() 					{ return ""; }
	const SettingHandler * getSettings()			{ return _appsettings; }
	
protected:
	virtual void	setFrontpage()=0;				// Called when there is a reason why the front page in the mode might have changed
	
	AppData * 				_appdata;				// Struct containing system data
	SettingHandler * 		_appsettings;			// Reference to application settings
	Context	*				_currentcontext;		// The context according to which the mode should display the data
	EventBuffer::Writer * 	_writer;				
	const DataBase &		_db;					// Reference to current data
	const rootnodes &		_rootnodes;
	GtkWidget * 			_frontwidget;			// The widget currently in front
	GtkToolbar * 			_toolbar;				// Reference to the program toolbar
};





#endif /*APPLICATIONMODE_H_*/
