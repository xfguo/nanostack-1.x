#ifndef NODEVIEW_H_
#define NODEVIEW_H_

#include "util/GObjectHandler.h"
#include "ApplicationMode.h"
#include "event/EventBuffer.h"
#include "dataformat/Node.h"


using namespace std;

class NodeView: public GObjectHandler
{
public:
	NodeView(const ApplicationMode * mode):
		_mode(mode),
		_node(NULL) {}
	virtual ~NodeView();
	
	const Node * 		getNode()				{ return _node; }
	virtual void 		attachNode(const Node * newnode);
	virtual void 		removeNode();
	virtual void		removeReferencesToNode(const string & nodeid) = 0;
	virtual objects & 	createObjects() = 0;
	virtual void 		redrawObjects() = 0;
	
	
protected:
	const ApplicationMode * _mode;
	const Node * 			_node;

	
	// Basic callbacks
	static void node_close(GtkButton *widget, gpointer nodeview);
	
};

#endif
