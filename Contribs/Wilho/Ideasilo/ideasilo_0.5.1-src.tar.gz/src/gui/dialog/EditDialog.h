#ifndef EDITDIALOG_H_
#define EDITDIALOG_H_
#include "gui/dialog/Dialog.h"
#include "gui/action/OpenDialogAction.h"
#include "dataformat/Node.h"

class EditDialog : public Dialog
{
public:
	EditDialog(EventBuffer::Writer * writer, const string & UIFilename, 
			Node * node);
	virtual ~EditDialog();

protected:
	virtual bool 			initTopWidget();
	virtual GtkWidget * 	getTopWidget();
	
private:
	enum ChildViewColumns {
	   NODE_ID_COLUMN,
	   LABEL_COLUMN,
	   N_COLUMNS
	};
	
	string extractEntryContents(int xmlid, const char * entrytag);

	GtkWidget **	_customdata;
	GtkWidget **	_customdata_label;
	int				_customdata_count;
	Node * 			_node;	// A copy of the original Node, owned by the dialog
	// Callbacks
	static void updateButtonPress(GtkWidget * widget, gpointer data);
	//static void cancelButtonPress(GtkWidget * widget, gpointer data);
};


class OpenEditDialogAction: public OpenDialogAction {
public:
	OpenEditDialogAction(EventBuffer::Writer * writer,  const string & UIFilename,
			const string & name, const string & label, 
			const string & tooltip):
		OpenDialogAction(writer,UIFilename, name, label, tooltip, "gtk-edit") {}
	
	virtual ~OpenEditDialogAction() {}
	Dialog * createDialog(void * target);	
};


#endif /*UPDATEDIALOG_H_*/
