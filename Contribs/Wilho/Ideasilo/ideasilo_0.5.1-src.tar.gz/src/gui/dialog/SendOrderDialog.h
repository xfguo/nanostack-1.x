#ifndef SENDORDERDIALOG_H_
#define SENDORDERDIALOG_H_

#include "Dialog.h"
#include "gui/action/OpenDialogAction.h"
#include "util/SettingHandler.h"

class SendOrderDialog : public Dialog
{
public:
	SendOrderDialog(EventBuffer::Writer * writer, const string & UIFilename, 
			const SettingHandler * settings, GtkListStore * list);
	virtual ~SendOrderDialog();
	
protected:
	virtual GtkWidget * getTopWidget();
	virtual bool 		initTopWidget();
	
private:
	void			initOrderForm(GtkListStore * list);
	static void 	submitButtonPress(GtkWidget * widget, gpointer data);
	
	const SettingHandler * 	_settings;
	stringstream			_orderformstr;
	GtkComboBox * 			_supplierbox;
	
};

class OpenSendOrderDialogAction: public OpenDialogAction {
public:
	
	OpenSendOrderDialogAction(EventBuffer::Writer * writer,  const string & UIFilename,
			const string & name, const string & label, const string & tooltip):
		OpenDialogAction(writer, UIFilename, name, label, tooltip, "gtk-apply")
		{}
	virtual ~OpenSendOrderDialogAction() {}
	
	Dialog * createDialog(void * target); 
	
};


#endif /*SENDORDERDIALOG_H_*/
