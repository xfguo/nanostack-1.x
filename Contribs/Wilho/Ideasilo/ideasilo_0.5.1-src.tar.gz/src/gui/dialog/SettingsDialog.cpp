#include "SettingsDialog.h"
#include <iostream> //DEBUG
#include "event/GUIEvent.h"
#include "util/widgethandler.h"

namespace GLADE {
	namespace SETTINGS {
		const char * TOP = "[settings]top";
		const char * SETTING_BASE = "[settings]setting_base";
		const char * CLOSEBUTTON = "[settings]closebutton";
		const char * CANCELBUTTON = "[settings]cancelbutton";
		const char * OKBUTTON = "[settings]okbutton";
		const char * LABEL = "[settings]label";
		const char * DATA = "[settings]data";
	}
}

enum SettingsDialogWidget { SETTINGS_TOP };

SettingsDialog::SettingsDialog(EventBuffer::Writer * writer, const string & UIFilename, 
		SettingHandler * settings):
Dialog(writer, UIFilename),
_settings(settings)
{
	_ID = "settings_dialog";
}

SettingsDialog::~SettingsDialog() {
}

bool SettingsDialog::initTopWidget() {
	if (!hasXML(SETTINGS_TOP)) {
		GladeXML * xml =  glade_xml_new(_uifilename.c_str(),GLADE::SETTINGS::TOP, NULL);
		registerXML(SETTINGS_TOP, xml);
	}
	if (!hasObject(SETTINGS_TOP) && hasXML(SETTINGS_TOP)) {
		registerObject(SETTINGS_TOP, GLADE::SETTINGS::TOP);
	}
	if (hasXML(SETTINGS_TOP) && hasObject(SETTINGS_TOP)) {
		GladeXML * xml = getXML(SETTINGS_TOP);
		GtkWidget * widget;
		// Find out the packing settings
		GtkTable * table = GTK_TABLE(glade_xml_get_widget(xml, GLADE::SETTINGS::SETTING_BASE));		
		TablePackingSettings labelpack(GTK_WIDGET(table),0,0), datapack(GTK_WIDGET(table),1,0);
		gtk_widget_destroy(glade_xml_get_widget(xml, GLADE::SETTINGS::LABEL));
		gtk_widget_destroy(glade_xml_get_widget(xml, GLADE::SETTINGS::DATA));
		// Add setting entries
		int n = 0, count = _settings->_settings.size();
		if (count == 0) count = 1;
		gtk_table_resize(table, 2, count);
		for (SettingHandler::settings::iterator it = _settings->_settings.begin(); it != _settings->_settings.end(); it++, n++) {
			GladeXML * labelxml = glade_xml_new(_uifilename.c_str(), GLADE::SETTINGS::LABEL, NULL);
			GladeXML * dataxml = glade_xml_new(_uifilename.c_str(), GLADE::SETTINGS::DATA, NULL);
			widget = glade_xml_get_widget(labelxml, GLADE::SETTINGS::LABEL);
			gtk_label_set_text(GTK_LABEL(widget), (it->second->getName() + " =").c_str());
			WidgetUtil::attachToTable(table, widget, 0, 1, n, n+1, labelpack);
			gtk_widget_show_all(widget);
			widget = glade_xml_get_widget(dataxml, GLADE::SETTINGS::DATA);
			gtk_entry_set_text(GTK_ENTRY(widget), it->second->getData().c_str());
			WidgetUtil::attachToTable(table, widget, 1, 2, n, n+1, datapack);
			gtk_widget_show_all(widget);
		}
		// Connect button signals
		widget = glade_xml_get_widget(xml, GLADE::SETTINGS::CLOSEBUTTON);
		g_signal_connect(widget, "clicked", G_CALLBACK(closeButtonPress), this);
		widget = glade_xml_get_widget(xml, GLADE::SETTINGS::OKBUTTON);
		g_signal_connect(widget, "clicked", G_CALLBACK(okButtonPress), this);
		widget = glade_xml_get_widget(xml, GLADE::SETTINGS::CANCELBUTTON);
		g_signal_connect(widget, "clicked", G_CALLBACK(cancelButtonPress), this);
		return true;
	}
	return false;
}

GtkWidget * SettingsDialog::getTopWidget() {
	return getWidget(SETTINGS_TOP);
}

void SettingsDialog::cancelButtonPress(GtkWidget * widget, gpointer data) {
	closeButtonPress(widget, data);
}

void SettingsDialog::okButtonPress(GtkWidget * widget, SettingsDialog * dialog) {
	if (!dialog->hasObject(SETTINGS_TOP))
		return;
	GladeXML * xml = dialog->getXML(SETTINGS_TOP);
	GtkTable * table = GTK_TABLE(glade_xml_get_widget(xml, GLADE::SETTINGS::SETTING_BASE));
	for (GList * child = table->children; child; child = child->next) {
		GtkEntry * data_widget = GTK_ENTRY(((GtkTableChild*)child->data)->widget);
		child = child->next;
		GtkLabel * label_widget = GTK_LABEL(((GtkTableChild*)child->data)->widget);
		string label = gtk_label_get_text(label_widget);
		label = label.substr(0,label.length()-2);
		string data = gtk_entry_get_text(data_widget);
		Setting * oldsetting = dialog->_settings->find(label);
		if (oldsetting) {
			if (data.compare(oldsetting->getData()))		// If a setting has changed, notify the system about the change
				dialog->_evwriter->push(new SettingChangedEvent(label, oldsetting->getData(), data));
			oldsetting->set(data);
		}
	}
	dialog->_settings->save();
	dialog->_evwriter->push(new CloseDialogEvent(dialog));
}




