#include "SendOrderDialog.h"
#include "util/widgethandler.h"
#include <iostream>
#include <sstream>
#include "gui/orderingmode/OrderingMode.h"
#include "gui/Context.h"
#include "event/GUIEvent.h"
#include "network/NetworkEvent.h"

namespace GLADE {
	namespace SENDORDER {
		const char * TOP = "[sendorder]top";
		const char * CLOSEBUTTON = "[sendorder]closebutton";
		const char * CANCELBUTTON = "[sendorder]cancelbutton";
		const char * SUBMITBUTTON = "[sendorder]submitbutton";
		const char * CONTENT = "[sendorder]content";
		const char * ORDERER = "[sendorder]orderer";
		const char * SUPPLIER = "[sendorder]supplier";
		const char * SUPPLIER_VBOX = "[sendorder]supplier_vbox";
	}
}

enum SendOrderDialogWidget { SENDORDER_TOP };

Dialog * OpenSendOrderDialogAction::createDialog(void * target) {
	//cout << "In OpenSendOrderDialogAction::createDialog" << endl;
	if (!target)
		return NULL;
	OrderingMode * mode = static_cast<OrderingMode*>(target);

	return new SendOrderDialog(_evwriter, _uifilename, mode->getSettings(), mode->getForm());
}



SendOrderDialog::SendOrderDialog(EventBuffer::Writer * writer, const string & UIFilename, 
		const SettingHandler * settings, GtkListStore * list):
Dialog(writer, UIFilename),
_settings(settings),
_supplierbox(NULL)
{
	if (list)
		initOrderForm(list);
	_ID = "sendorder_dialog";
}

SendOrderDialog::~SendOrderDialog()
{
	// Cleaning up done in GObjectHandler
}

GtkWidget * SendOrderDialog::getTopWidget() {
	return getWidget(SENDORDER_TOP);
}

bool SendOrderDialog::initTopWidget() {
	//cout << "In SendOrderDialog::initTopWidget" << endl;
	if (!hasXML(SENDORDER_TOP)) {
		GladeXML * xml = glade_xml_new(_uifilename.c_str(), GLADE::SENDORDER::TOP, NULL);
		registerXML(SENDORDER_TOP, xml);
	}
	if (!hasObject(SENDORDER_TOP) && hasXML(SENDORDER_TOP)) {
		registerObject(SENDORDER_TOP, GLADE::SENDORDER::TOP);
	}
	if (hasXML(SENDORDER_TOP) && hasObject(SENDORDER_TOP)) {
		GladeXML * xml = getXML(SENDORDER_TOP);
		GtkLabel * ordererlabel = GTK_LABEL(glade_xml_get_widget(xml, GLADE::SENDORDER::ORDERER));
		if (ordererlabel) {
			string orderername = _context->getSettingValue("/orderers/ID001/name");
			gtk_label_set_text(ordererlabel, orderername.c_str());
		}

		GtkVBox * suppliervbox = GTK_VBOX(glade_xml_get_widget(xml, GLADE::SENDORDER::SUPPLIER_VBOX));
		if (suppliervbox) {
			_supplierbox = GTK_COMBO_BOX(gtk_combo_box_new_text());
			ContextSetting suppliers = _context->getSetting("/suppliers");
			if (suppliers.isEmpty() == false) {
				const Context::settings & supplierlist = suppliers.getChildren();
				int n = 0;
				for (Context::settings::const_iterator it = supplierlist.begin(); it != supplierlist.end(); it++, n++) {
					const ContextSetting * suppliername = it->second->getSetting("/name");
					if (suppliername) {
						gtk_combo_box_insert_text(_supplierbox, n, suppliername->getData().c_str());
						if (n == 0)
							gtk_combo_box_set_active(_supplierbox, n);
					}
				}
			}
			gtk_container_add(GTK_CONTAINER(suppliervbox), GTK_WIDGET(_supplierbox));
			gtk_widget_show_all(GTK_WIDGET(suppliervbox));
		}

		GtkTextView * content = GTK_TEXT_VIEW(glade_xml_get_widget(xml, GLADE::SENDORDER::CONTENT));
		if (content) {
			GtkTextBuffer * textbuf = gtk_text_view_get_buffer(content);
			gtk_text_buffer_set_text(textbuf, _orderformstr.str().c_str(), -1);
		}
		// Connect button signals
		GtkWidget * closebutton = glade_xml_get_widget(xml, GLADE::SENDORDER::CLOSEBUTTON);
		g_signal_connect(closebutton, "clicked", G_CALLBACK(closeButtonPress), this);
		GtkWidget * submitbutton = glade_xml_get_widget(xml, GLADE::SENDORDER::SUBMITBUTTON);
		g_signal_connect(submitbutton, "clicked", G_CALLBACK(submitButtonPress), this);
		GtkWidget * cancelbutton = glade_xml_get_widget(xml, GLADE::SENDORDER::CANCELBUTTON);
		g_signal_connect(cancelbutton, "clicked", G_CALLBACK(closeButtonPress), this);

	}
	return true;
}

void SendOrderDialog::initOrderForm(GtkListStore * list) {
	GtkTreeModel * model = GTK_TREE_MODEL(list);
	GtkTreeIter it;
	int n_columns = gtk_tree_model_get_n_columns(model);
	bool valid = gtk_tree_model_get_iter_first(model, &it);
	while (valid) {
		gchar * value[n_columns];
		for (int n = 1; n < n_columns; n++)
			gtk_tree_model_get(model, &it, n, &value[n], -1);
		float count = atof(value[n_columns-1]);
		if (count > 0) {
			stringstream countstr, itemstr;
			countstr << value[n_columns-1] << " x ";
			bool comma = false;
			for (int n = 1; n < n_columns-1; n++) {
				if (value[n] != NULL && strlen(value[n]) > 0) {
					if (comma)
						itemstr << ", ";
					itemstr << value[n];
					comma = true;
				}
			}
			string itemline = itemstr.str();
			if (itemline.length() > 0) {
				_orderformstr << countstr.str() << itemline << endl;
			}
		}
		for (int n = 1; n < n_columns; n++)
			g_free(value[n]);
	
		valid = gtk_tree_model_iter_next(model, &it);
	}
	//cout << "SendOrderDialog::initOrderForm:" << endl << _orderformstr.str() << endl;
}

void SendOrderDialog::submitButtonPress(GtkWidget * widget, gpointer data) {
	SendOrderDialog * dialog = static_cast<SendOrderDialog*>(data);
	if (dialog->hasObject(SENDORDER_TOP)) {
		GladeXML * xml = dialog->getXML(SENDORDER_TOP);
		GtkLabel * ordererlabel = GTK_LABEL(glade_xml_get_widget(xml, GLADE::SENDORDER::ORDERER));
		string orderer = gtk_label_get_text(ordererlabel);
		gchar * supplierstr = gtk_combo_box_get_active_text(dialog->_supplierbox);
		string supplier = supplierstr;
		g_free(supplierstr);
		GtkTextView * content = GTK_TEXT_VIEW(glade_xml_get_widget(xml, GLADE::SENDORDER::CONTENT));
		string orderlist = WidgetUtil::getTextViewData(content);
		dialog->_evwriter->push(new ServerSendOrderFormEvent(orderer, supplier, orderlist));
	}
	dialog->_evwriter->push(new CloseDialogEvent(dialog));
}


