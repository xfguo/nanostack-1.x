#include "ManageNodeView.h"
#include "event/GUIEvent.h"
#include <iostream>
#include "dataformat/Branch.h"

//namespace ManagePageViewTag {
//	const char * ROOT_TAG = 			"[page]root";
//	const char * TABROOT_TAG = 			"[page]tab_root";
//	const char * TAB_LABEL_TAG =		"[page]tab_label";
//	const char * TAB_CLOSEBUTTON_TAG = 	"[page]tab_closebutton";
//	const char * ENTRY_BASE_TAG = 		"[page]dataentry_base";
//}

//using namespace ManagePageViewTag;

ManageNodeView::ManageNodeView(const ApplicationMode * mode):
NodeView(mode),
_list(NULL)
{
}

ManageNodeView::~ManageNodeView()
{
}


NodeView::objects & ManageNodeView::createObjects() {
	GdkThread::enter();
	if (!hasObject(LIST)) {
		_list = gtk_list_store_new(N_BRANCHVIEW_COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_POINTER);
		registerObject(LIST, G_OBJECT(_list));
	}
	GdkThread::leave();
	return _objects;
}

void ManageNodeView::redrawObjects() {
	//cout << "In ManageNodeView::redrawObjects: " << getNode()->getID() << endl;
	if (!_node)
		return;
	GdkThread::enter();
	gtk_list_store_clear(_list);
	NodeContent::ContentType type = _node->getContentType();
	bool nodata = (type == NodeContent::TYPE_EMPTY);
	if (!nodata) {
		if (_node->getContentType() == NodeContent::TYPE_BRANCH) {
			const Branch * branch = static_cast<const Branch*>(_node->getContents());
			if (branch->hasChildren()) {
				//cout << "ManageNodeView::redrawObjects: Branch " << _node->getID() << " has children." << endl;
				const Branch::children & children = branch->getChildren();
				for (Branch::children::const_iterator it = children.begin(); it != children.end(); it++) {
					const Node * childnode = it->second;
					if (!childnode) {
						//cout << "ManageNodeView::redrawObjects: Fetching child node " << it->first << " from database" << endl;
						childnode = _mode->getNode(it->first);
					} 
					if (childnode) {
						//cout << "ManageNodeView::redrawObjects: Found child node " << childnode->getID() << endl;
						const NodeContent * childcontent = childnode->getContents(); 
						GtkTreeIter treeit;
						gtk_list_store_append(_list, &treeit);
						stringstream ss;
						ss << childcontent->getVersion();
						gtk_list_store_set(_list, &treeit,
								BRANCHVIEW_ID_COLUMN, childnode->getID().c_str(),
								BRANCHVIEW_VERSION_COLUMN, ss.str().c_str(),
								BRANCHVIEW_LABEL_COLUMN, childcontent->getLabel().c_str(),
								BRANCHVIEW_DATA_COLUMN, childnode, 
								-1);
					}
				}
			} else 
				nodata = true;
		} else if (_node->getContentType() != NodeContent::TYPE_EMPTY) {
			//cout << "ManageNodeView::redrawObjects: Non-branch: " << _node->getID() << endl;
			const NodeContent * content = _node->getContents(); 
			GtkTreeIter treeit;
			gtk_list_store_append(_list, &treeit);
			stringstream ss;
			ss << content->getVersion();
			gtk_list_store_set(_list, &treeit,
					BRANCHVIEW_ID_COLUMN, _node->getID().c_str(),
					BRANCHVIEW_VERSION_COLUMN, ss.str().c_str(),
					BRANCHVIEW_LABEL_COLUMN, content->getLabel().c_str(),
					BRANCHVIEW_DATA_COLUMN, _node, 
					-1);
		}
	}
	if (nodata) {
		//cout << "ManageNodeView::redrawObjects: No data: " << _node->getID() << endl;
		GtkTreeIter treeit;
		gtk_list_store_append(_list, &treeit);
		gtk_list_store_set(_list, &treeit,
				BRANCHVIEW_ID_COLUMN, "N/A",
				BRANCHVIEW_VERSION_COLUMN, "",
				BRANCHVIEW_LABEL_COLUMN, "",
				BRANCHVIEW_DATA_COLUMN, NULL, 
				-1);
	}
	//cout << "Leaving ManageNodeView::redrawObjects" << endl;
	GdkThread::leave();
}

void ManageNodeView::refreshNode(const string & nodeid) {
	// TODO: Make sure this function works
	GtkTreeIter it;
	GtkTreeModel * model = GTK_TREE_MODEL(_list);
	gtk_tree_model_get_iter_first(model, &it);
	do {
		gchar * id;
		gtk_tree_model_get(model, &it, BRANCHVIEW_ID_COLUMN, &id, -1);
		bool equal = !strcmp(nodeid.c_str(), id);
		g_free(id);
		if (equal) {
			GtkTreePath * path = gtk_tree_model_get_path(model, &it);
			gtk_tree_model_row_changed(model, path, &it);
			gtk_tree_path_free(path);
			return;
		}
	} while (gtk_tree_model_iter_next(model, &it));

}


void ManageNodeView::releaseObjects() {
	//cout << "start ManagePageView::releaseWidgets" << endl;
	// Nothing to release
	//cout << "end ManagePageView::releaseWidgets" << endl;
}

//void ManageNodeView::redrawEntry(int entryid) {
//	// TODO: Make sure this function works
//	GtkTreeIter it;
//	GtkTreeModel * model = GTK_TREE_MODEL(_list);
//	gtk_tree_model_get_iter_first(model, &it);
//	do {
//		gint id;
//		gtk_tree_model_get(model, &it, BRANCHVIEW_ID_COLUMN, &id, -1);
//		if (id == entryid) {
//			GtkTreePath * path = gtk_tree_model_get_path(model, &it);
//			gtk_tree_model_row_changed(model, path, &it);
//			gtk_tree_path_free(path);
//			return;
//		}
//	} while (gtk_tree_model_iter_next(model, &it));
//}


void ManageNodeView::displayInBranchView(GtkTreeView * view) {
	//cout << "In ManageNodeView::displayInBranchView" << endl;
	gtk_tree_view_set_model(view, GTK_TREE_MODEL(_list));
	gtk_tree_view_columns_autosize(view);
	//cout << "Leaving ManageNodeView::displayInBranchView" << endl;
}

void ManageNodeView::removeReferencesToNode(const string & nodeid) {
	if (_node) {
		GtkTreeIter it;
		GtkTreeModel * model = GTK_TREE_MODEL(_list);
		bool valid;
		if (gtk_tree_model_get_iter_first(model, &it))
			do {
				gchar * data;
				gtk_tree_model_get(model, &it, BRANCHVIEW_ID_COLUMN, &data, -1);
				bool equal = !strcmp(nodeid.c_str(), data);
				g_free(data);
				if (equal) {
					valid = gtk_list_store_remove(_list, &it);
				} else
					valid = gtk_tree_model_iter_next(model, &it);
			} while (valid);

		if (!nodeid.compare(_node->getID()))
			removeNode();
	}
}

int	ManageNodeView::getListSize() const {
	return gtk_tree_model_iter_n_children(GTK_TREE_MODEL(_list),NULL);
}

// **************** Callbacks ****************



void ManageNodeView::do_nothing(GtkWidget * widget, gpointer user_data) {
}

bool ManageNodeView::suppress_signal(GtkWidget * widget, gpointer datapage) {
	return true;
}

