#ifndef MANAGEMODEEVENT_H_
#define MANAGEMODEEVENT_H_

#include "gui/ApplicationModeEvent.h"
#include "ManageMode.h"

class ManageModeEvent: public ApplicationModeEvent {
public:	
	ManageModeEvent(): ApplicationModeEvent(ManageMode::MODE_ID) { }
	virtual ~ManageModeEvent() {}
	
	virtual bool processInManageMode(ManageMode * mode)=0;
	
protected:
	bool processInMode(ApplicationMode * mode);
};

class BrowseEvent : public ManageModeEvent {
public:
	enum BrowseEventType { UNKNOWN, BACK, FORWARD, PARENT };
	BrowseEvent(BrowseEventType type):_type(type) {}
	virtual ~BrowseEvent() {}
	
	virtual bool processInManageMode(ManageMode * mode);
	
private:
	BrowseEventType _type;
};

#endif /*MANAGEMODEEVENT_H_*/
