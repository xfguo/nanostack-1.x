#include "ManageModeEvent.h"

bool ManageModeEvent::processInMode(ApplicationMode * mode) {
	ManageMode * managemode = static_cast<ManageMode*>(mode);
	return processInManageMode(managemode);
}


bool BrowseEvent::processInManageMode(ManageMode * mode) {
	if (_type == BACK) {
		mode->browseBack();
	} else if (_type == FORWARD) {
		mode->browseForward();
	} else if (_type == PARENT) {
		mode->browseParent();
	}
	return true;
}
