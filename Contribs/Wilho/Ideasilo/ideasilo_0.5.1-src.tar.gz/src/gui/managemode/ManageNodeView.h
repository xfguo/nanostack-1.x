#ifndef MANAGENODEVIEW_H_
#define MANAGENODEVIEW_H_
//#include <glade/glade.h>
#include "util/widgethandler.h"

#include "gui/NodeView.h"
//#include "gui/DataEntryView.h"

//
//namespace ManageNodeViewTag {
//	extern const char * ROOT_TAG;
//	extern const char * TABROOT_TAG;
//	extern const char * ENTRY_BASE_TAG;	
//}

class ManageNodeView : public NodeView
{
public:
	enum ManagePageViewObject 		{ LIST };
	enum BranchViewColumns { BRANCHVIEW_ID_COLUMN, BRANCHVIEW_VERSION_COLUMN, BRANCHVIEW_LABEL_COLUMN, BRANCHVIEW_DATA_COLUMN, N_BRANCHVIEW_COLUMNS };
	
	ManageNodeView(const ApplicationMode * mode);
	~ManageNodeView();
	
	virtual objects & createObjects();
	virtual void redrawObjects();
	virtual void releaseObjects();
	void	refreshNode(const string & nodeid);
	//void redrawEntry(int entryid);
	
	//void clearTable();
	//DataEntryView ** 	getFocus();//			{ return &_focus; }
	//void				setFocus(int entryid);
	//DataEntryView * 	getEntryView(int entryid);
	bool				addToSelectionList(GtkListStore * list);
	bool				removeFromSelectionList(GtkListStore * list);
	void				displayInBranchView(GtkTreeView * view);
	void				removeReferencesToNode(const string & nodeid);
	int					getListSize() const;
	
private:
	//Callbacks
	
	static void do_nothing(GtkWidget * widget, gpointer datapage);
	static bool suppress_signal(GtkWidget * widget, gpointer datapage);
	
	GtkListStore * 		_list;
};

#endif
