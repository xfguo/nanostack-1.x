#include "CellRendererMulti.h"
#include "gui/gtkmarshalers.h"
#include "dataformat/ImageLeaf.h"
#include "dataformat/URILeaf.h"

const char * ERROR_REMOTE_IMAGE = "Image data";
const char * ERROR_BINARY_DATA = "Binary data";
const char * ERROR_UNKNOWN_FORMAT = "Unrecognized data";
const char * ERROR_UNDEFINED_DATA = "No data available";
const char * ERROR_MISSING_ICON = "Icon missing";

// GObject type system related functions
static void     cell_renderer_multi_init(CellRendererMulti      *cellprogress);
static void     cell_renderer_multi_class_init(CellRendererMultiClass *klass);
static void     cell_renderer_multi_get_property(GObject                    *object,
                                                             guint                    param_id,
                                                             GValue                  *value,
                                                             GParamSpec              *pspec);
static void     cell_renderer_multi_set_property(GObject                    *object,
                                                             guint                    param_id,
                                                             const GValue            *value,
                                                             GParamSpec              *pspec);
static void     cell_renderer_multi_finalize(GObject *gobject);

static gboolean	cellActivated(GtkCellRenderer *cell, GdkEvent *event, GtkWidget *widget, const gchar *path, GdkRectangle *background_area, GdkRectangle *cell_area, GtkCellRendererState flags);

// The following functions form the core of the custom cell renderer
static void     cell_renderer_multi_get_size(GtkCellRenderer            *cell,
                                                          GtkWidget               *widget,
                                                          GdkRectangle            *cell_area,
                                                          gint                    *x_offset,
                                                          gint                    *y_offset,
                                                          gint                    *width,
                                                          gint                    *height);
static void     cell_renderer_multi_render(GtkCellRenderer            *cell,
														  GdkDrawable             *drawable,
                                                          GtkWidget               *widget,
                                                          GdkRectangle            *background_area,
                                                          GdkRectangle            *cell_area,
                                                          GdkRectangle            *expose_area,
                                                          GtkCellRendererState     flags);


static GtkCellEditable *cell_renderer_multi_text_start_editing(GtkCellRenderer      *cell,
							      GdkEvent             *event,
							      GtkWidget            *widget,
							      const gchar          *path,
							      GdkRectangle         *background_area,
							      GdkRectangle         *cell_area,
							      GtkCellRendererState  flags);

enum {
	PROP_0,
	PROP_NODE,
	
	// From GtkCellRendererPixbuf:
	PROP_STOCK_ID,
	PROP_STOCK_SIZE,
	PROP_STOCK_DETAIL,
	
	// From GtkCellRendererText:
	PROP_TEXT,
	PROP_MARKUP,
	PROP_ATTRIBUTES,
	PROP_SINGLE_PARAGRAPH_MODE,
	PROP_WIDTH_CHARS,

	// ... Style args 
	PROP_BACKGROUND,
	PROP_FOREGROUND,
	PROP_BACKGROUND_GDK,
	PROP_FOREGROUND_GDK,
	PROP_FONT,
	PROP_FONT_DESC,
	PROP_FAMILY,
	PROP_STYLE,
	PROP_VARIANT,
	PROP_WEIGHT,
	PROP_STRETCH,
	PROP_SIZE,
	PROP_SIZE_POINTS,
	PROP_SCALE,
	PROP_EDITABLE,
	PROP_STRIKETHROUGH,
	PROP_UNDERLINE,
	PROP_RISE,
	PROP_LANGUAGE,
	PROP_ELLIPSIZE,

	// ... Whether-a-style-arg-is-set args
	PROP_BACKGROUND_SET,
	PROP_FOREGROUND_SET,
	PROP_FAMILY_SET,
	PROP_STYLE_SET,
	PROP_VARIANT_SET,
	PROP_WEIGHT_SET,
	PROP_STRETCH_SET,
	PROP_SIZE_SET,
	PROP_SCALE_SET,
	PROP_EDITABLE_SET,
	PROP_STRIKETHROUGH_SET,
	PROP_UNDERLINE_SET,
	PROP_RISE_SET,
	PROP_LANGUAGE_SET,
	PROP_ELLIPSIZE_SET
};

enum {
  EDITED,
  ACTIVATED,
  LAST_SIGNAL
};

static gpointer parent_class;
static guint cell_renderer_multi_signals[LAST_SIGNAL];

const gchar * CELL_RENDERER_MULTI_PATH = "cell-renderer-multi-path";
#define CELL_RENDERER_MULTI_GET_PRIVATE(obj) (G_TYPE_INSTANCE_GET_PRIVATE ((obj), TYPE_CELL_RENDERER_MULTI, CellRendererMultiPrivate))

typedef struct _CellRendererMultiPrivate CellRendererMultiPrivate;
struct _CellRendererMultiPrivate
{
	// Pixbuf related:
	GdkPixbuf	*stock_pixbuf;
	gchar 		*stock_id;
	GtkIconSize stock_size;
	gchar 		*stock_detail;	

	// Text related:
	guint single_paragraph : 1;
	guint language_set : 1;
	guint markup_set : 1;
	guint ellipsize_set : 1;

	gulong focus_out_id;
	PangoLanguage *language;
	PangoEllipsizeMode ellipsize;

	gulong populate_popup_id;
	gulong entry_menu_popdown_timeout;
	gboolean in_entry_menu;

	gint width_chars;

	GtkWidget *entry;
};


// Register the custom type with the GObject type system if it's not done yet.
// Everything else is done in the callbacks
GType cell_renderer_multi_get_type() {
	static GType cell_multi_type = 0;

	if (cell_multi_type)
		return cell_multi_type;	// The type is registered already

	static const GTypeInfo cell_multi_info = {
			sizeof(CellRendererMultiClass),
			NULL,                                                     // base_init
			NULL,                                                     // base_finalize
			(GClassInitFunc)cell_renderer_multi_class_init,
			NULL,                                                     // class_finalize
			NULL,                                                     // class_data 
			sizeof(CellRendererMulti),
			0,                                                        // n_preallocs 
			(GInstanceInitFunc)cell_renderer_multi_init,
	};

	// Register the type, presenting it as derived from GtkCellRenderer
	cell_multi_type = g_type_register_static(GTK_TYPE_CELL_RENDERER,
			"CellRendererMulti",
			&cell_multi_info, (GTypeFlags)0);

	return cell_multi_type;
}

// Set some default properties of the parent
static void cell_renderer_multi_init(CellRendererMulti *cellrenderermulti)
{
	GTK_CELL_RENDERER(cellrenderermulti)->mode = GTK_CELL_RENDERER_MODE_INERT;

	GTK_CELL_RENDERER(cellrenderermulti)->xalign = 0.0;
	GTK_CELL_RENDERER(cellrenderermulti)->yalign = 0.5;
	GTK_CELL_RENDERER(cellrenderermulti)->xpad = 0;
	GTK_CELL_RENDERER(cellrenderermulti)->ypad = 0;
	cellrenderermulti->fixed_height_rows = -1;
	cellrenderermulti->font = pango_font_description_new ();
	
	CellRendererMultiPrivate * priv = CELL_RENDERER_MULTI_GET_PRIVATE(cellrenderermulti);
	priv->width_chars = -1;
	priv->stock_size = GTK_ICON_SIZE_BUTTON;
}

// Set up custom get_property and set_property functions, and override the parent's
// functions that need to be implemented. Make custom properties known to the system.
// Override 'activate' to enable cell activation
static void cell_renderer_multi_class_init(CellRendererMultiClass *klass)
{
	GtkCellRendererClass *cell_class   = GTK_CELL_RENDERER_CLASS(klass);
	GObjectClass         *object_class = G_OBJECT_CLASS(klass);

	parent_class           = g_type_class_peek_parent (klass);
	object_class->finalize = cell_renderer_multi_finalize;

	// Set up custom property set and get functions
	object_class->get_property = cell_renderer_multi_get_property;
	object_class->set_property = cell_renderer_multi_set_property;

	// Set up the crucial cell rendering functions
	cell_class->get_size = cell_renderer_multi_get_size;
	cell_class->render   = cell_renderer_multi_render;
	cell_class->start_editing = cell_renderer_multi_text_start_editing;
	cell_class->activate = cellActivated;
	
	// Finally install the custom properties
	// TODO: In case of additional properties, add installation code here
	g_object_class_install_property(object_class, PROP_NODE,
			g_param_spec_pointer("dataentry",
					"DataEntry object handle",
					"The data structure to represent",
					(GParamFlags)G_PARAM_READWRITE));
	
	// From GtkCellRendererPixbuf
	g_object_class_install_property (object_class, PROP_STOCK_ID, g_param_spec_string ("stock-id", "Stock ID", "The stock ID of the stock icon to render", NULL, (GParamFlags)G_PARAM_READWRITE));
	g_object_class_install_property (object_class, PROP_STOCK_SIZE, g_param_spec_uint ("stock-size", "Size", "The GtkIconSize value that specifies the size of the rendered icon", 0, G_MAXUINT, GTK_ICON_SIZE_MENU, (GParamFlags)G_PARAM_READWRITE));
	g_object_class_install_property (object_class, PROP_STOCK_DETAIL, g_param_spec_string ("stock-detail", "Detail", "Render detail to pass to the theme engine", NULL, (GParamFlags)G_PARAM_READWRITE));

	
	// From GtkCellRendererText...
	g_object_class_install_property (object_class, PROP_TEXT, g_param_spec_string ("text", "Text", "Text to render", NULL, (GParamFlags)G_PARAM_READWRITE));
	g_object_class_install_property (object_class, PROP_MARKUP, g_param_spec_string ("markup", "Markup", "Marked up text to render", NULL, G_PARAM_WRITABLE));
	g_object_class_install_property (object_class, PROP_ATTRIBUTES, g_param_spec_boxed ("attributes", "Attributes", "A list of style attributes to apply to the text of the renderer", PANGO_TYPE_ATTR_LIST, (GParamFlags)G_PARAM_READWRITE));
	g_object_class_install_property (object_class, PROP_SINGLE_PARAGRAPH_MODE, g_param_spec_boolean ("single-paragraph-mode", "Single Paragraph Mode", "Whether or not to keep all text in a single paragraph", FALSE, (GParamFlags)G_PARAM_READWRITE));
	g_object_class_install_property (object_class, PROP_BACKGROUND, g_param_spec_string ("background", "Background color name", "Background color as a string", NULL, G_PARAM_WRITABLE));
	g_object_class_install_property (object_class, PROP_BACKGROUND_GDK, g_param_spec_boxed ("background-gdk", "Background color", "Background color as a GdkColor", GDK_TYPE_COLOR, (GParamFlags)(G_PARAM_READABLE | G_PARAM_WRITABLE)));  
	g_object_class_install_property (object_class, PROP_FOREGROUND, g_param_spec_string ("foreground", "Foreground color name", "Foreground color as a string", NULL, (GParamFlags)G_PARAM_WRITABLE));
	g_object_class_install_property (object_class, PROP_FOREGROUND_GDK, g_param_spec_boxed ("foreground-gdk", "Foreground color", "Foreground color as a GdkColor", GDK_TYPE_COLOR, (GParamFlags)(G_PARAM_READABLE | G_PARAM_WRITABLE)));
	g_object_class_install_property (object_class, PROP_EDITABLE, g_param_spec_boolean ("editable", "Editable", "Whether the text can be modified by the user", FALSE, (GParamFlags)(G_PARAM_READABLE | G_PARAM_WRITABLE)));
	g_object_class_install_property (object_class, PROP_FONT, g_param_spec_string ("font", "Font", "Font description as a string", NULL, (GParamFlags)(G_PARAM_READABLE | G_PARAM_WRITABLE)));
	g_object_class_install_property (object_class, PROP_FONT_DESC, g_param_spec_boxed ("font-desc", "Font", "Font description as a PangoFontDescription struct", PANGO_TYPE_FONT_DESCRIPTION, (GParamFlags)(G_PARAM_READABLE | G_PARAM_WRITABLE)));
	g_object_class_install_property (object_class, PROP_FAMILY, g_param_spec_string ("family", "Font family", "Name of the font family, e.g. Sans, Helvetica, Times, Monospace", NULL, (GParamFlags)(G_PARAM_READABLE | G_PARAM_WRITABLE)));
	g_object_class_install_property (object_class, PROP_STYLE, g_param_spec_enum ("style", "Font style", "Font style", PANGO_TYPE_STYLE, PANGO_STYLE_NORMAL, (GParamFlags)(G_PARAM_READABLE | G_PARAM_WRITABLE)));
	g_object_class_install_property (object_class, PROP_VARIANT, g_param_spec_enum ("variant", "Font variant", "Font variant", PANGO_TYPE_VARIANT, PANGO_VARIANT_NORMAL, (GParamFlags)(G_PARAM_READABLE | G_PARAM_WRITABLE)));
	g_object_class_install_property (object_class, PROP_WEIGHT, g_param_spec_int ("weight","Font weight","Font weight", 0, G_MAXINT, PANGO_WEIGHT_NORMAL, (GParamFlags)(G_PARAM_READABLE | G_PARAM_WRITABLE)));
	g_object_class_install_property (object_class, PROP_STRETCH, g_param_spec_enum ("stretch", "Font stretch","Font stretch", PANGO_TYPE_STRETCH, PANGO_STRETCH_NORMAL, (GParamFlags)(G_PARAM_READABLE | G_PARAM_WRITABLE)));
	g_object_class_install_property (object_class, PROP_SIZE, g_param_spec_int ("size", "Font size", "Font size", 0, G_MAXINT, 0, (GParamFlags)(G_PARAM_READABLE | G_PARAM_WRITABLE)));
	g_object_class_install_property (object_class, PROP_SIZE_POINTS, g_param_spec_double ("size-points", "Font points", "Font size in points", 0.0, G_MAXDOUBLE, 0.0, (GParamFlags)(G_PARAM_READABLE | G_PARAM_WRITABLE)));  
	g_object_class_install_property (object_class, PROP_SCALE, g_param_spec_double ("scale", "Font scale", "Font scaling factor", 0.0, G_MAXDOUBLE, 1.0, (GParamFlags)(G_PARAM_READABLE | G_PARAM_WRITABLE)));
	g_object_class_install_property (object_class, PROP_RISE, g_param_spec_int ("rise", "Rise", "Offset of text above the baseline (below the baseline if rise is negative)", -G_MAXINT, G_MAXINT, 0, (GParamFlags)(G_PARAM_READABLE | G_PARAM_WRITABLE)));
	g_object_class_install_property (object_class, PROP_STRIKETHROUGH, g_param_spec_boolean ("strikethrough", "Strikethrough", "Whether to strike through the text", FALSE, (GParamFlags)(G_PARAM_READABLE | G_PARAM_WRITABLE)));
	g_object_class_install_property (object_class, PROP_UNDERLINE, g_param_spec_enum ("underline", "Underline", "Style of underline for this text", PANGO_TYPE_UNDERLINE, PANGO_UNDERLINE_NONE, (GParamFlags)(G_PARAM_READABLE | G_PARAM_WRITABLE)));
	g_object_class_install_property (object_class, PROP_LANGUAGE, g_param_spec_string ("language", "Language", "The language this text is in, as an ISO code. Pango can use this as a hint when rendering the text. If you don't understand this parameter, you probably don't need it", NULL, (GParamFlags)G_PARAM_WRITABLE));
	g_object_class_install_property (object_class, PROP_ELLIPSIZE, g_param_spec_enum ("ellipsize", "Ellipsize", "The preferred place to ellipsize the string, if the cell renderer does not have enough room to display the entire string, if at all",	PANGO_TYPE_ELLIPSIZE_MODE, PANGO_ELLIPSIZE_NONE, (GParamFlags)G_PARAM_WRITABLE));
	g_object_class_install_property (object_class, PROP_WIDTH_CHARS, g_param_spec_int ("width-chars", "Width In Characters", "The desired width of the label, in characters", -1, G_MAXINT, -1, (GParamFlags)G_PARAM_WRITABLE));

	// Style props are set or not
#define ADD_SET_PROP(propname, propval, nick, blurb) g_object_class_install_property(object_class, propval, g_param_spec_boolean (propname, nick, blurb, FALSE, (GParamFlags)(G_PARAM_READABLE | G_PARAM_WRITABLE)))
	ADD_SET_PROP ("background-set", PROP_BACKGROUND_SET, "Background set", "Whether this tag affects the background color");
	ADD_SET_PROP ("foreground-set", PROP_FOREGROUND_SET, "Foreground set", "Whether this tag affects the foreground color");
	ADD_SET_PROP ("editable-set", PROP_EDITABLE_SET, "Editability set", "Whether this tag affects text editability");
	ADD_SET_PROP ("family-set", PROP_FAMILY_SET, "Font family set", "Whether this tag affects the font family");  
	ADD_SET_PROP ("style-set", PROP_STYLE_SET, "Font style set", "Whether this tag affects the font style");
	ADD_SET_PROP ("variant-set", PROP_VARIANT_SET, "Font variant set", "Whether this tag affects the font variant");
	ADD_SET_PROP ("weight-set", PROP_WEIGHT_SET, "Font weight set", "Whether this tag affects the font weight");
	ADD_SET_PROP ("stretch-set", PROP_STRETCH_SET, "Font stretch set", "Whether this tag affects the font stretch");
	ADD_SET_PROP ("size-set", PROP_SIZE_SET, "Font size set", "Whether this tag affects the font size");
	ADD_SET_PROP ("scale-set", PROP_SCALE_SET, "Font scale set", "Whether this tag scales the font size by a factor");
	ADD_SET_PROP ("rise-set", PROP_RISE_SET, "Rise set", "Whether this tag affects the rise");
	ADD_SET_PROP ("strikethrough-set", PROP_STRIKETHROUGH_SET, "Strikethrough set", "Whether this tag affects strikethrough");
	ADD_SET_PROP ("underline-set", PROP_UNDERLINE_SET, "Underline set", "Whether this tag affects underlining");
	ADD_SET_PROP ("language-set", PROP_LANGUAGE_SET, "Language set", "Whether this tag affects the language the text is rendered as");
	ADD_SET_PROP ("ellipsize-set", PROP_ELLIPSIZE_SET, "Ellipsize set", "Whether this tag affects the ellipsize mode");

	cell_renderer_multi_signals[EDITED] = g_signal_new ("edited",
				G_OBJECT_CLASS_TYPE (object_class),
				G_SIGNAL_RUN_LAST,
				G_STRUCT_OFFSET (CellRendererMultiClass, edited),
				NULL, NULL,
				_gtk_marshal_VOID__STRING_STRING,
				G_TYPE_NONE, 2,
				G_TYPE_STRING,
				G_TYPE_STRING);

	cell_renderer_multi_signals[ACTIVATED] = g_signal_new ("activated",
				G_OBJECT_CLASS_TYPE (object_class),
				G_SIGNAL_RUN_LAST,
				G_STRUCT_OFFSET (CellRendererMultiClass, activated),
				NULL, NULL,
				_gtk_marshal_VOID__VOID,
				G_TYPE_NONE, 0);
	
	
	g_type_class_add_private (object_class, sizeof(CellRendererMultiPrivate));
}

// The callback used for freeing the resources
static void cell_renderer_multi_finalize(GObject *object)
{
	CellRendererMulti *multi = CELL_RENDERER_MULTI(object);

	pango_font_description_free(multi->font);
	if (multi->text) g_free(multi->text);
	if (multi->extra_attrs) pango_attr_list_unref(multi->extra_attrs);

	CellRendererMultiPrivate * priv = CELL_RENDERER_MULTI_GET_PRIVATE(object);
	if (priv->language)
		g_object_unref(priv->language);
	if (priv->stock_pixbuf)
		g_object_unref(priv->stock_pixbuf);
	g_free(priv->stock_id);
	g_free(priv->stock_detail);
	// Then finalize the parent class
	(* G_OBJECT_CLASS(parent_class)->finalize)(object);
}

static PangoFontMask get_property_font_set_mask(guint prop_id)
{
	switch (prop_id)
	{
	case PROP_FAMILY_SET:
		return PANGO_FONT_MASK_FAMILY;
	case PROP_STYLE_SET:
		return PANGO_FONT_MASK_STYLE;
	case PROP_VARIANT_SET:
		return PANGO_FONT_MASK_VARIANT;
	case PROP_WEIGHT_SET:
		return PANGO_FONT_MASK_WEIGHT;
	case PROP_STRETCH_SET:
		return PANGO_FONT_MASK_STRETCH;
	case PROP_SIZE_SET:
		return PANGO_FONT_MASK_SIZE;
	}
	return (PangoFontMask)0;
}

// Callback for getting properties
static void cell_renderer_multi_get_property(GObject *object, 
		guint param_id, GValue *value, GParamSpec *psec)
{
	CellRendererMulti *multi = CELL_RENDERER_MULTI(object);
	CellRendererMultiPrivate * priv = CELL_RENDERER_MULTI_GET_PRIVATE(object);

	switch (param_id) {
	case PROP_NODE:
		g_value_set_pointer(value, multi->node);
		break;
    case PROP_STOCK_ID:
      g_value_set_string (value, priv->stock_id);
      break;
    case PROP_STOCK_SIZE:
      g_value_set_uint (value, priv->stock_size);
      break;
    case PROP_STOCK_DETAIL:
      g_value_set_string (value, priv->stock_detail);
      break;
    case PROP_TEXT:
		g_value_set_string (value, multi->text);
		break;

	case PROP_ATTRIBUTES:
		g_value_set_boxed (value, multi->extra_attrs);
		break;

	case PROP_SINGLE_PARAGRAPH_MODE:
		g_value_set_boolean (value, priv->single_paragraph);
		break;

	case PROP_BACKGROUND_GDK: {
		GdkColor color;

		color.red = multi->background.red;
		color.green = multi->background.green;
		color.blue = multi->background.blue;

		g_value_set_boxed (value, &color);
	}
	break;

	case PROP_FOREGROUND_GDK: {
		GdkColor color;

		color.red = multi->foreground.red;
		color.green = multi->foreground.green;
		color.blue = multi->foreground.blue;

		g_value_set_boxed (value, &color);
	}
	break;

	case PROP_FONT: {
		/* FIXME GValue imposes a totally gratuitous string copy
		 * here, we could just hand off string ownership
		 */
		gchar *str = pango_font_description_to_string (multi->font);
		g_value_set_string (value, str);
		g_free (str);
	}
	break;

	case PROP_FONT_DESC:
		g_value_set_boxed (value, multi->font);
		break;

	case PROP_FAMILY:
		g_value_set_string (value, pango_font_description_get_family (multi->font));
		break;

	case PROP_STYLE:
		g_value_set_enum (value, pango_font_description_get_style (multi->font));
		break;

	case PROP_VARIANT:
		g_value_set_enum (value, pango_font_description_get_variant (multi->font));
		break;

	case PROP_WEIGHT:
		g_value_set_int (value, pango_font_description_get_weight (multi->font));
		break;

	case PROP_STRETCH:
		g_value_set_enum (value, pango_font_description_get_stretch (multi->font));
		break;

	case PROP_SIZE:
		g_value_set_int (value, pango_font_description_get_size (multi->font));
		break;

	case PROP_SIZE_POINTS:
		g_value_set_double (value, ((double)pango_font_description_get_size (multi->font)) / (double)PANGO_SCALE);
		break;

	case PROP_SCALE:
		g_value_set_double (value, multi->font_scale);
		break;

	case PROP_EDITABLE:
		g_value_set_boolean (value, multi->editable);
		break;

	case PROP_STRIKETHROUGH:
		g_value_set_boolean (value, multi->strikethrough);
		break;

	case PROP_UNDERLINE:
		g_value_set_enum (value, multi->underline_style);
		break;

	case PROP_RISE:
		g_value_set_int (value, multi->rise);
		break;  

	case PROP_LANGUAGE:
		g_value_set_string (value, pango_language_to_string (priv->language));
		break;

	case PROP_ELLIPSIZE:
		g_value_set_enum (value, priv->ellipsize);
		break;

	case PROP_BACKGROUND_SET:
		g_value_set_boolean (value, multi->background_set);
		break;

	case PROP_FOREGROUND_SET:
		g_value_set_boolean (value, multi->foreground_set);
		break;

	case PROP_FAMILY_SET:
	case PROP_STYLE_SET:
	case PROP_VARIANT_SET:
	case PROP_WEIGHT_SET:
	case PROP_STRETCH_SET:
	case PROP_SIZE_SET:
	{
		PangoFontMask mask = get_property_font_set_mask (param_id);
		g_value_set_boolean (value, (pango_font_description_get_set_fields (multi->font) & mask) != 0);

		break;
	}

	case PROP_SCALE_SET:
		g_value_set_boolean (value, multi->scale_set);
		break;

	case PROP_EDITABLE_SET:
		g_value_set_boolean (value, multi->editable_set);
		break;

	case PROP_STRIKETHROUGH_SET:
		g_value_set_boolean (value, multi->strikethrough_set);
		break;

	case PROP_UNDERLINE_SET:
		g_value_set_boolean (value, multi->underline_set);
		break;

	case  PROP_RISE_SET:
		g_value_set_boolean (value, multi->rise_set);
		break;

	case PROP_LANGUAGE_SET:
		g_value_set_boolean (value, priv->language_set);
		break;

	case PROP_ELLIPSIZE_SET:
		g_value_set_boolean (value, priv->ellipsize_set);
		break;

	case PROP_WIDTH_CHARS:
		g_value_set_int (value, priv->width_chars);
		break;  

	case PROP_BACKGROUND:
	case PROP_FOREGROUND:
	case PROP_MARKUP:
	default:
		G_OBJECT_WARN_INVALID_PROPERTY_ID(object, param_id, psec);
		break;
	}
}

static void
set_bg_color(CellRendererMulti *multi, GdkColor *color)
{
	if (color) {
		if (!multi->background_set) {
			multi->background_set = TRUE;
			g_object_notify (G_OBJECT (multi), "background-set");
		}

		multi->background.red = color->red;
		multi->background.green = color->green;
		multi->background.blue = color->blue;
	}
	else {
		if (multi->background_set) {
			multi->background_set = FALSE;
			g_object_notify (G_OBJECT (multi), "background-set");
		}
	}
}

static void set_fg_color (CellRendererMulti *multi, GdkColor *color)
{
	if (color) {
		if (!multi->foreground_set) {
			multi->foreground_set = TRUE;
			g_object_notify (G_OBJECT (multi), "foreground-set");
		}
		multi->foreground.red = color->red;
		multi->foreground.green = color->green;
		multi->foreground.blue = color->blue;
	} else {
		if (multi->foreground_set) {
			multi->foreground_set = FALSE;
			g_object_notify (G_OBJECT (multi), "foreground-set");
		}
	}
}

static PangoFontMask
set_font_desc_fields (PangoFontDescription *desc,
		PangoFontMask         to_set)
{
	PangoFontMask changed_mask = (PangoFontMask)0;

	if (to_set & PANGO_FONT_MASK_FAMILY) {
		const char *family = pango_font_description_get_family (desc);
		if (!family) {
			family = "sans";
			changed_mask = (PangoFontMask)(changed_mask | PANGO_FONT_MASK_FAMILY);
		}
		pango_font_description_set_family (desc, family);
	}
	if (to_set & PANGO_FONT_MASK_STYLE)
		pango_font_description_set_style (desc, pango_font_description_get_style (desc));
	if (to_set & PANGO_FONT_MASK_VARIANT)
		pango_font_description_set_variant (desc, pango_font_description_get_variant (desc));
	if (to_set & PANGO_FONT_MASK_WEIGHT)
		pango_font_description_set_weight (desc, pango_font_description_get_weight (desc));
	if (to_set & PANGO_FONT_MASK_STRETCH)
		pango_font_description_set_stretch (desc, pango_font_description_get_stretch (desc));
	if (to_set & PANGO_FONT_MASK_SIZE) {
		gint size = pango_font_description_get_size (desc);
		if (size <= 0) {
			size = 10 * PANGO_SCALE;
			changed_mask = (PangoFontMask)(changed_mask | PANGO_FONT_MASK_SIZE);
		}

		pango_font_description_set_size (desc, size);
	}

	return changed_mask;
}

static void
notify_set_changed (GObject       *object,
		PangoFontMask  changed_mask)
{
	if (changed_mask & PANGO_FONT_MASK_FAMILY)
		g_object_notify (object, "family-set");
	if (changed_mask & PANGO_FONT_MASK_STYLE)
		g_object_notify (object, "style-set");
	if (changed_mask & PANGO_FONT_MASK_VARIANT)
		g_object_notify (object, "variant-set");
	if (changed_mask & PANGO_FONT_MASK_WEIGHT)
		g_object_notify (object, "weight-set");
	if (changed_mask & PANGO_FONT_MASK_STRETCH)
		g_object_notify (object, "stretch-set");
	if (changed_mask & PANGO_FONT_MASK_SIZE)
		g_object_notify (object, "size-set");
}

static void
notify_fields_changed (GObject       *object,
		PangoFontMask  changed_mask)
{
	if (changed_mask & PANGO_FONT_MASK_FAMILY)
		g_object_notify (object, "family");
	if (changed_mask & PANGO_FONT_MASK_STYLE)
		g_object_notify (object, "style");
	if (changed_mask & PANGO_FONT_MASK_VARIANT)
		g_object_notify (object, "variant");
	if (changed_mask & PANGO_FONT_MASK_WEIGHT)
		g_object_notify (object, "weight");
	if (changed_mask & PANGO_FONT_MASK_STRETCH)
		g_object_notify (object, "stretch");
	if (changed_mask & PANGO_FONT_MASK_SIZE)
		g_object_notify (object, "size");
}

static void
set_font_description (CellRendererMulti  *multi,
		PangoFontDescription *font_desc)
{
	GObject *object = G_OBJECT (multi);
	PangoFontDescription *new_font_desc;
	PangoFontMask old_mask, new_mask, changed_mask, set_changed_mask;

	if (font_desc)
		new_font_desc = pango_font_description_copy (font_desc);
	else
		new_font_desc = pango_font_description_new ();

	old_mask = pango_font_description_get_set_fields (multi->font);
	new_mask = pango_font_description_get_set_fields (new_font_desc);

	changed_mask = (PangoFontMask)(old_mask | new_mask);
	set_changed_mask = (PangoFontMask)(old_mask ^ new_mask);

	pango_font_description_free (multi->font);
	multi->font = new_font_desc;

	g_object_freeze_notify (object);

	g_object_notify (object, "font-desc");
	g_object_notify (object, "font");

	if (changed_mask & PANGO_FONT_MASK_FAMILY)
		g_object_notify (object, "family");
	if (changed_mask & PANGO_FONT_MASK_STYLE)
		g_object_notify (object, "style");
	if (changed_mask & PANGO_FONT_MASK_VARIANT)
		g_object_notify (object, "variant");
	if (changed_mask & PANGO_FONT_MASK_WEIGHT)
		g_object_notify (object, "weight");
	if (changed_mask & PANGO_FONT_MASK_STRETCH)
		g_object_notify (object, "stretch");
	if (changed_mask & PANGO_FONT_MASK_SIZE)
	{
		g_object_notify (object, "size");
		g_object_notify (object, "size-points");
	}

	notify_set_changed (object, set_changed_mask);

	g_object_thaw_notify (object);
}

// Callback for setting properties
static void cell_renderer_multi_set_property (GObject *object,
		guint param_id, const GValue *value, GParamSpec *pspec)
{
	CellRendererMulti *multi = CELL_RENDERER_MULTI(object);
	CellRendererMultiPrivate * priv = CELL_RENDERER_MULTI_GET_PRIVATE(object);
	
	switch (param_id) {
	case PROP_NODE:
		multi->node = static_cast<Node*>(g_value_get_pointer(value));
		break;

    case PROP_STOCK_ID:
    	if (priv->stock_id)
    		g_free (priv->stock_id);
    	if (priv->stock_pixbuf) {
    		g_object_unref(priv->stock_pixbuf);
    		priv->stock_pixbuf = NULL;
    	}
    	priv->stock_id = g_value_dup_string(value);
    	break;
    case PROP_STOCK_SIZE:
    	priv->stock_size = (GtkIconSize)g_value_get_uint(value);
    	break;
    case PROP_STOCK_DETAIL:
    	if (priv->stock_detail)
    		g_free (priv->stock_detail);
    	priv->stock_detail = g_value_dup_string(value);
    	break;
	case PROP_TEXT:
		if (multi->text)
			g_free (multi->text);

		if (priv->markup_set)
		{
			if (multi->extra_attrs)
				pango_attr_list_unref (multi->extra_attrs);
			multi->extra_attrs = NULL;
			priv->markup_set = FALSE;
		}

		multi->text = g_strdup (g_value_get_string (value));
		g_object_notify (object, "text");
		break;

	case PROP_ATTRIBUTES:
		if (multi->extra_attrs)
			pango_attr_list_unref (multi->extra_attrs);

		multi->extra_attrs = (PangoAttrList*)g_value_get_boxed (value);
		if (multi->extra_attrs)
			pango_attr_list_ref (multi->extra_attrs);
		break;
	case PROP_MARKUP:
	{
		const gchar *str;
		gchar *text = NULL;
		GError *error = NULL;
		PangoAttrList *attrs = NULL;

		str = g_value_get_string (value);
		if (str && !pango_parse_markup (str,
				-1,
				0,
				&attrs,
				&text,
				NULL,
				&error))
		{
			g_warning ("Failed to set cell text from markup due to error parsing markup: %s",
					error->message);
			g_error_free (error);
			return;
		}

		if (multi->text)
			g_free (multi->text);

		if (multi->extra_attrs)
			pango_attr_list_unref (multi->extra_attrs);

		multi->text = text;
		multi->extra_attrs = attrs;
		priv->markup_set = TRUE;
	}
	break;

	case PROP_SINGLE_PARAGRAPH_MODE:
		priv->single_paragraph = g_value_get_boolean (value);
		break;

	case PROP_BACKGROUND:
	{
		GdkColor color;

		if (!g_value_get_string (value))
			set_bg_color (multi, NULL);       /* reset to backgrounmd_set to FALSE */
		else if (gdk_color_parse (g_value_get_string (value), &color))
			set_bg_color (multi, &color);
		else
			g_warning ("Don't know color `%s'", g_value_get_string (value));

		g_object_notify (object, "background-gdk");
	}
	break;

	case PROP_FOREGROUND:
	{
		GdkColor color;

		if (!g_value_get_string (value))
			set_fg_color (multi, NULL);       /* reset to foreground_set to FALSE */
		else if (gdk_color_parse (g_value_get_string (value), &color))
			set_fg_color (multi, &color);
		else
			g_warning ("Don't know color `%s'", g_value_get_string (value));

		g_object_notify (object, "foreground-gdk");
	}
	break;

	case PROP_BACKGROUND_GDK:
		/* This notifies the GObject itself. */
		set_bg_color (multi, (GdkColor*)g_value_get_boxed (value));
		break;

	case PROP_FOREGROUND_GDK:
		/* This notifies the GObject itself. */
		set_fg_color (multi, (GdkColor*)g_value_get_boxed (value));
		break;

	case PROP_FONT:
	{
		PangoFontDescription *font_desc = NULL;
		const gchar *name;

		name = g_value_get_string (value);

		if (name)
			font_desc = pango_font_description_from_string (name);

		set_font_description (multi, font_desc);

		pango_font_description_free (font_desc);

		if (multi->fixed_height_rows != -1)
			multi->calc_fixed_height = TRUE;
	}
	break;

	case PROP_FONT_DESC:
		set_font_description (multi, (PangoFontDescription*)g_value_get_boxed (value));

		if (multi->fixed_height_rows != -1)
			multi->calc_fixed_height = TRUE;
		break;

	case PROP_FAMILY:
	case PROP_STYLE:
	case PROP_VARIANT:
	case PROP_WEIGHT:
	case PROP_STRETCH:
	case PROP_SIZE:
	case PROP_SIZE_POINTS:
	{
		PangoFontMask old_set_mask = pango_font_description_get_set_fields (multi->font);

		switch (param_id)
		{
		case PROP_FAMILY:
			pango_font_description_set_family (multi->font,
					g_value_get_string (value));
			break;
		case PROP_STYLE:
			pango_font_description_set_style (multi->font,
					(PangoStyle)g_value_get_enum (value));
			break;
		case PROP_VARIANT:
			pango_font_description_set_variant (multi->font,
					(PangoVariant)g_value_get_enum (value));
			break;
		case PROP_WEIGHT:
			pango_font_description_set_weight (multi->font,
					(PangoWeight)g_value_get_int (value));
			break;
		case PROP_STRETCH:
			pango_font_description_set_stretch (multi->font,
					(PangoStretch)g_value_get_enum (value));
			break;
		case PROP_SIZE:
			pango_font_description_set_size (multi->font,
					g_value_get_int (value));
			g_object_notify (object, "size-points");
			break;
		case PROP_SIZE_POINTS:
			pango_font_description_set_size (multi->font,
					(gint)g_value_get_double (value) * PANGO_SCALE);
			g_object_notify (object, "size");
			break;
		}

		if (multi->fixed_height_rows != -1)
			multi->calc_fixed_height = TRUE;

		notify_set_changed (object, (PangoFontMask)(old_set_mask & pango_font_description_get_set_fields (multi->font)));
		g_object_notify (object, "font-desc");
		g_object_notify (object, "font");

		break;
	}

	case PROP_SCALE:
		multi->font_scale = g_value_get_double (value);
		multi->scale_set = TRUE;
		if (multi->fixed_height_rows != -1)
			multi->calc_fixed_height = TRUE;
		g_object_notify (object, "scale-set");
		break;

	case PROP_EDITABLE:
		multi->editable = g_value_get_boolean (value);
		multi->editable_set = TRUE;
		if (multi->editable)
			GTK_CELL_RENDERER (multi)->mode = GTK_CELL_RENDERER_MODE_EDITABLE;
		else
			GTK_CELL_RENDERER (multi)->mode = GTK_CELL_RENDERER_MODE_INERT;
		g_object_notify (object, "editable-set");
		break;

	case PROP_STRIKETHROUGH:
		multi->strikethrough = g_value_get_boolean (value);
		multi->strikethrough_set = TRUE;
		g_object_notify (object, "strikethrough-set");
		break;

	case PROP_UNDERLINE:
		multi->underline_style = (PangoUnderline)g_value_get_enum (value);
		multi->underline_set = TRUE;
		g_object_notify (object, "underline-set");

		break;

	case PROP_RISE:
		multi->rise = g_value_get_int (value);
		multi->rise_set = TRUE;
		g_object_notify (object, "rise-set");
		if (multi->fixed_height_rows != -1)
			multi->calc_fixed_height = TRUE;
		break;  

	case PROP_LANGUAGE:
		priv->language_set = TRUE;
		if (priv->language)
			g_object_unref (priv->language);
		priv->language = pango_language_from_string (g_value_get_string (value));
		g_object_notify (object, "language-set");
		break;

	case PROP_ELLIPSIZE:
		priv->ellipsize = (PangoEllipsizeMode)g_value_get_enum (value);
		priv->ellipsize_set = TRUE;
		g_object_notify (object, "ellipsize-set");
		break;

	case PROP_WIDTH_CHARS:
		priv->width_chars = g_value_get_int (value);
		g_object_notify (object, "width-chars");
		break;  
	case PROP_BACKGROUND_SET:
		multi->background_set = g_value_get_boolean (value);
		break;

	case PROP_FOREGROUND_SET:
		multi->foreground_set = g_value_get_boolean (value);
		break;

	case PROP_FAMILY_SET:
	case PROP_STYLE_SET:
	case PROP_VARIANT_SET:
	case PROP_WEIGHT_SET:
	case PROP_STRETCH_SET:
	case PROP_SIZE_SET:
		if (!g_value_get_boolean (value))
		{
			pango_font_description_unset_fields (multi->font,
					get_property_font_set_mask (param_id));
		}
		else
		{
			PangoFontMask changed_mask;

			changed_mask = set_font_desc_fields (multi->font,
					get_property_font_set_mask (param_id));
			notify_fields_changed (G_OBJECT (multi), changed_mask);
		}
		break;

	case PROP_SCALE_SET:
		multi->scale_set = g_value_get_boolean (value);
		break;

	case PROP_EDITABLE_SET:
		multi->editable_set = g_value_get_boolean (value);
		break;

	case PROP_STRIKETHROUGH_SET:
		multi->strikethrough_set = g_value_get_boolean (value);
		break;

	case PROP_UNDERLINE_SET:
		multi->underline_set = g_value_get_boolean (value);
		break;

	case PROP_RISE_SET:
		multi->rise_set = g_value_get_boolean (value);
		break;

	case PROP_LANGUAGE_SET:
		priv->language_set = g_value_get_boolean (value);
		break;

	case PROP_ELLIPSIZE_SET:
		priv->ellipsize_set = g_value_get_boolean (value);
		break;		
		
	default:
		G_OBJECT_WARN_INVALID_PROPERTY_ID(object, param_id, pspec);
		break;
	}
}

// Returns a new cell renderer instance
GtkCellRenderer * cell_renderer_multi_new()
{
	return GTK_CELL_RENDERER(g_object_new(TYPE_CELL_RENDERER_MULTI, NULL));
}

static void add_attr (PangoAttrList  *attr_list, PangoAttribute *attr)
{
	attr->start_index = 0;
	attr->end_index = G_MAXINT;
	pango_attr_list_insert (attr_list, attr);
}

static PangoLayout*
get_layout (CellRendererMulti *multi,
		GtkWidget           *widget,
		gboolean             will_render,
		GtkCellRendererState flags) {
	PangoAttrList *attr_list;
	PangoLayout *layout;
	PangoUnderline uline;
	CellRendererMultiPrivate * priv = CELL_RENDERER_MULTI_GET_PRIVATE (multi);

	layout = gtk_widget_create_pango_layout (widget, multi->text);

	if (multi->extra_attrs)
		attr_list = pango_attr_list_copy (multi->extra_attrs);
	else
		attr_list = pango_attr_list_new ();

	pango_layout_set_single_paragraph_mode (layout, priv->single_paragraph);

	if (will_render)
	{
		/* Add options that affect appearance but not size */

		/* note that background doesn't go here, since it affects
		 * background_area not the PangoLayout area
		 */

		if (multi->foreground_set
				&& (flags & GTK_CELL_RENDERER_SELECTED) == 0)
		{
			PangoColor color;

			color = multi->foreground;

			add_attr (attr_list,
					pango_attr_foreground_new (color.red, color.green, color.blue));
		}

		if (multi->strikethrough_set)
			add_attr (attr_list,
					pango_attr_strikethrough_new (multi->strikethrough));
	}

	add_attr (attr_list, pango_attr_font_desc_new (multi->font));

	if (multi->scale_set &&
			multi->font_scale != 1.0)
		add_attr (attr_list, pango_attr_scale_new (multi->font_scale));

	if (multi->underline_set)
		uline = multi->underline_style;
	else
		uline = PANGO_UNDERLINE_NONE;

	if (priv->language_set)
		add_attr (attr_list, pango_attr_language_new (priv->language));

	if ((flags & GTK_CELL_RENDERER_PRELIT) == GTK_CELL_RENDERER_PRELIT)
	{
		switch (uline)
		{
		case PANGO_UNDERLINE_NONE:
			uline = PANGO_UNDERLINE_SINGLE;
			break;

		case PANGO_UNDERLINE_SINGLE:
			uline = PANGO_UNDERLINE_DOUBLE;
			break;

		default:
			break;
		}
	}

	if (uline != PANGO_UNDERLINE_NONE)
		add_attr (attr_list, pango_attr_underline_new (multi->underline_style));

	if (multi->rise_set)
		add_attr (attr_list, pango_attr_rise_new (multi->rise));

	if (priv->ellipsize_set)
		pango_layout_set_ellipsize (layout, priv->ellipsize);
	else
		pango_layout_set_ellipsize (layout, PANGO_ELLIPSIZE_NONE);

	pango_layout_set_attributes (layout, attr_list);
	pango_layout_set_width (layout, -1);

	pango_attr_list_unref (attr_list);

	return layout;
}

static void
get_size (GtkCellRenderer *cell,
		GtkWidget       *widget,
		GdkRectangle    *cell_area,
		PangoLayout     *layout,
		gint            *x_offset,
		gint            *y_offset,
		gint            *width,
		gint            *height)
{
	CellRendererMulti *multi = (CellRendererMulti *) cell;
	PangoRectangle rect;
	CellRendererMultiPrivate * priv = CELL_RENDERER_MULTI_GET_PRIVATE (cell);

	if (multi->calc_fixed_height)
	{
		PangoContext *context;
		PangoFontMetrics *metrics;
		PangoFontDescription *font_desc;
		gint row_height;

		font_desc = pango_font_description_copy (widget->style->font_desc);
		pango_font_description_merge (font_desc, multi->font, TRUE);

		if (multi->scale_set)
			pango_font_description_set_size (font_desc,
					(gint)multi->font_scale * pango_font_description_get_size (font_desc));

		context = gtk_widget_get_pango_context (widget);

		metrics = pango_context_get_metrics (context,
				font_desc,
				pango_context_get_language (context));
		row_height = (pango_font_metrics_get_ascent (metrics) +
				pango_font_metrics_get_descent (metrics));
		pango_font_metrics_unref (metrics);

		pango_font_description_free (font_desc);

		gtk_cell_renderer_set_fixed_size (cell,
				cell->width, 2*cell->ypad +
				multi->fixed_height_rows * PANGO_PIXELS (row_height));

		if (height)
		{
			*height = cell->height;
			height = NULL;
		}
		multi->calc_fixed_height = FALSE;
		if (width == NULL)
			return;
	}

	if (layout)
		g_object_ref (layout);
	else
		layout = get_layout (multi, widget, FALSE, (GtkCellRendererState)0);

	pango_layout_get_pixel_extents (layout, NULL, &rect);

	if (height)
		*height = GTK_CELL_RENDERER (multi)->ypad * 2 + rect.height;

	/* The minimum size for ellipsized labels is ~ 3 chars */
	if (width)
	{
		*width = GTK_CELL_RENDERER (multi)->xpad * 2 + rect.width;
	}

	if (cell_area)
	{
		if (x_offset)
		{
			if (gtk_widget_get_direction (widget) == GTK_TEXT_DIR_RTL)
				*x_offset = (int)(1.0 - cell->xalign) * (cell_area->width - rect.width - (2 * cell->xpad));
			else 
				*x_offset = (int)cell->xalign * (cell_area->width - rect.width - (2 * cell->xpad));

			if (priv->ellipsize)
				*x_offset = MAX(*x_offset, 0);
		}
		if (y_offset)
		{
			*y_offset = (int)cell->yalign * (cell_area->height - rect.height - (2 * cell->ypad));
			*y_offset = MAX (*y_offset, 0);
		}
	}

	g_object_unref (layout);
}
#include <iostream>
using namespace std;


static void createStockPixbuf(CellRendererMulti * multi, GtkWidget * widget) {
	CellRendererMultiPrivate * priv = CELL_RENDERER_MULTI_GET_PRIVATE(multi);

	if (priv->stock_pixbuf)
		g_object_unref (priv->stock_pixbuf);
	priv->stock_pixbuf = gtk_widget_render_icon(widget, priv->stock_id, priv->stock_size, priv->stock_detail);
	//g_object_notify(G_OBJECT(multi), "pixbuf");
}

NodeContent::ContentType getRenderingType(CellRendererMulti * multi, GtkWidget * widget) {
	CellRendererMultiPrivate * priv = CELL_RENDERER_MULTI_GET_PRIVATE(multi);
	static const gchar * lasttext = NULL;
	if (!multi) {
		return NodeContent::TYPE_EMPTY;	// Can't display anything
	}
	const gchar * newtext = NULL;
	NodeContent::ContentType type = NodeContent::TYPE_TEXT;
	
	if (!multi->node || multi->node->getContentType() == NodeContent::TYPE_EMPTY) {
		newtext = ERROR_UNDEFINED_DATA;
		g_object_set(multi, "foreground", "red", NULL);
	} else if (multi->node->getContentType() == NodeContent::TYPE_IMAGE) {
		ImageLeaf * imageleaf = static_cast<ImageLeaf*>(multi->node->getContents());
		if (imageleaf->getImage() != NULL)
			return NodeContent::TYPE_IMAGE;	// Will display an image
		else {
			newtext = ERROR_REMOTE_IMAGE;
			g_object_set(multi, "foreground", "red", NULL);
		}
	} else if (multi->node->getContentType() == NodeContent::TYPE_BRANCH) {
		if (!priv->stock_pixbuf)
			createStockPixbuf(multi, widget);
		if (priv->stock_pixbuf)
			return NodeContent::TYPE_BRANCH;
		else {
			newtext = ERROR_MISSING_ICON;
			g_object_set(multi, "foreground", "red", NULL);
		}
	} else if (multi->node->getContentType() == NodeContent::TYPE_TEXT) {
		TextLeaf * textleaf = static_cast<TextLeaf*>(multi->node->getContents());
		newtext = textleaf->getData().c_str();
		g_object_set(multi, "foreground", "black", NULL);
	} else if (multi->node->getContentType() == NodeContent::TYPE_URI) {
		TextLeaf * textleaf = static_cast<TextLeaf*>(multi->node->getContents());
		newtext = textleaf->getData().c_str();
		g_object_set(multi, "foreground", "purple", NULL);
		type = NodeContent::TYPE_URI;			
	} else if (multi->node->getContentType() == NodeContent::TYPE_BINARY) {
		newtext = ERROR_BINARY_DATA;
		g_object_set(multi, "foreground", "green", NULL);
	}
	if (newtext != lasttext) {
		//cout << "Text set to:" << newtext << " last text was: " << lasttext << endl;
		lasttext = newtext;
		g_object_set(multi, "text", newtext, NULL);
	}
	return type;		// Will display something as text
}


// One of the core functions. Calculates the size of the cell to be rendered.
// Takes into accound padding and alignment properties of the parent.
static void cell_renderer_multi_get_size (GtkCellRenderer *cell,
		GtkWidget *widget, GdkRectangle *cell_area, gint *x_offset,
		gint *y_offset, gint *width, gint *height)
{
	CellRendererMulti * multi = CELL_RENDERER_MULTI(cell);
	CellRendererMultiPrivate * priv = CELL_RENDERER_MULTI_GET_PRIVATE(multi);
	NodeContent::ContentType nodetype = getRenderingType(multi, widget);

	if (nodetype == NodeContent::TYPE_IMAGE || nodetype == NodeContent::TYPE_BRANCH) {
		// Render as an image
		GdkPixbuf * pixbuf;
		if (nodetype == NodeContent::TYPE_BRANCH) {
			pixbuf = priv->stock_pixbuf;
		} else {
			ImageLeaf * imageleaf = static_cast<ImageLeaf*>(multi->node->getContents());
			pixbuf = imageleaf->getImage();
		}
		gint pixbuf_width = gdk_pixbuf_get_width(pixbuf);
		gint pixbuf_height = gdk_pixbuf_get_height(pixbuf);
		gint calc_width = (gint)cell->xpad * 2 + pixbuf_width;
		gint calc_height = (gint)cell->ypad * 2 + pixbuf_height;
		
		if (cell_area && pixbuf_width > 0 && pixbuf_height > 0) {
			if (x_offset) {
				*x_offset = static_cast<int>(cell->xalign * (cell_area->width - calc_width));
				*x_offset = MAX (*x_offset, 0);
			}
			if (y_offset) {
				*y_offset = static_cast<int>(cell->yalign * (cell_area->height - calc_height));
				*y_offset = MAX (*y_offset, 0);
			}
		} else {
			if (x_offset) *x_offset = 0;
			if (y_offset) *y_offset = 0;
		}
		if (width) *width = calc_width;
		if (height) *height = calc_height;
		//cout << "cell_renderer_multi_get_size: Width: " << calc_width << " Height: " << calc_height << endl;
	} else {
		// Render as text, link or an error message
		get_size (cell, widget, cell_area, NULL, x_offset, y_offset, width, height);	
	} 
}

static void renderText(GtkCellRenderer *cell,
		GdkDrawable *drawable, GtkWidget *widget, GdkRectangle *background_area,
		GdkRectangle *cell_area, GdkRectangle *expose_area, GtkCellRendererState flags) {
	CellRendererMulti *multi = (CellRendererMulti *) cell;
	PangoLayout *layout;
	GtkStateType state;
	gint x_offset;
	gint y_offset;
	CellRendererMultiPrivate * priv = CELL_RENDERER_MULTI_GET_PRIVATE (cell);;
	PangoRectangle logical_rect;

	layout = get_layout(multi, widget, TRUE, flags);
	cell_renderer_multi_get_size(cell, widget, cell_area, &x_offset, &y_offset, NULL, NULL);

	if (!cell->sensitive) {
		state = GTK_STATE_INSENSITIVE;
	} else if ((flags & GTK_CELL_RENDERER_SELECTED) == GTK_CELL_RENDERER_SELECTED) {
		if (GTK_WIDGET_HAS_FOCUS (widget))
			state = GTK_STATE_SELECTED;
		else
			state = GTK_STATE_ACTIVE;
	} else if ((flags & GTK_CELL_RENDERER_PRELIT) == GTK_CELL_RENDERER_PRELIT &&
			GTK_WIDGET_STATE (widget) == GTK_STATE_PRELIGHT)
	{
		state = GTK_STATE_NORMAL;
	} else {
		if (GTK_WIDGET_STATE (widget) == GTK_STATE_INSENSITIVE)
			state = GTK_STATE_INSENSITIVE;
		else
			state = GTK_STATE_NORMAL;
	}

	if (multi->background_set && (flags & GTK_CELL_RENDERER_SELECTED) == 0) {
		GdkColor color;
		GdkGC *gc;

		color.red = multi->background.red;
		color.green = multi->background.green;
		color.blue = multi->background.blue;

		gc = gdk_gc_new(drawable);

		gdk_gc_set_rgb_fg_color (gc, &color);

		if (expose_area)               
			gdk_gc_set_clip_rectangle (gc, expose_area);
		gdk_draw_rectangle (drawable, gc, TRUE,
				background_area->x,
				background_area->y,
				background_area->width,
				background_area->height);
		if (expose_area)               
			gdk_gc_set_clip_rectangle (gc, NULL);
		g_object_unref (gc);
	}

	/* Hildon: Dirty hack to force ellipsation
	 * FIXME sanity check MIN() use
	 */
	pango_layout_get_extents (layout, NULL, &logical_rect);
	if (!priv->ellipsize_set && 
			PANGO_PIXELS (logical_rect.width) > MIN (background_area->width, expose_area->width)) {
		priv->ellipsize = PANGO_ELLIPSIZE_END;
		priv->ellipsize_set = TRUE;

		pango_layout_set_ellipsize (layout, priv->ellipsize);
	}

	if (priv->ellipsize)
		pango_layout_set_width (layout, (cell_area->width - x_offset - 2 * cell->xpad) * PANGO_SCALE);
	else
		pango_layout_set_width (layout, -1);

	gtk_paint_layout (widget->style, drawable, state, TRUE, expose_area, widget,
			"cellrenderertext",
			cell_area->x + x_offset + cell->xpad,
			cell_area->y + y_offset + cell->ypad,
			layout);

	g_object_unref (layout);
}

static void renderPixbuf(GtkCellRenderer *cell,
		GdkDrawable *drawable, GtkWidget *widget, GdkRectangle *background_area,
		GdkRectangle *cell_area, GdkRectangle *expose_area, GtkCellRendererState flags) {
	CellRendererMulti * multi = CELL_RENDERER_MULTI(cell);
	GdkRectangle pix_rect;
	GdkRectangle draw_rect;
	cell_renderer_multi_get_size(cell, widget, cell_area,
			&pix_rect.x, &pix_rect.y, &pix_rect.width, &pix_rect.height);
	
	pix_rect.x += cell_area->x;
	pix_rect.y += cell_area->y;
	pix_rect.width  -= cell->xpad * 2;
	pix_rect.height -= cell->ypad * 2;
	
	if (gdk_rectangle_intersect (cell_area, &pix_rect, &draw_rect) &&
			gdk_rectangle_intersect (expose_area, &draw_rect, &draw_rect)) {
		ImageLeaf * imageleaf = static_cast<ImageLeaf*>(multi->node->getContents());
		gdk_draw_pixbuf(drawable, widget->style->black_gc, imageleaf->getImage(),
				// pixbuf 0, 0 is at pix_rect.x, pix_rect.y 
				draw_rect.x - pix_rect.x,
				draw_rect.y - pix_rect.y,
				draw_rect.x, draw_rect.y,
				draw_rect.width, draw_rect.height,
				GDK_RGB_DITHER_NORMAL, 0, 0);
	}
}

static void renderStockIcon(GtkCellRenderer *cell,
		GdkDrawable *drawable, GtkWidget *widget, GdkRectangle *background_area,
		GdkRectangle *cell_area, GdkRectangle *expose_area, GtkCellRendererState flags) {
	CellRendererMulti * multi = CELL_RENDERER_MULTI(cell);
	CellRendererMultiPrivate * priv = CELL_RENDERER_MULTI_GET_PRIVATE(multi);
	GdkRectangle pix_rect;
	GdkRectangle draw_rect;
	cell_renderer_multi_get_size(cell, widget, cell_area,
			&pix_rect.x, &pix_rect.y, &pix_rect.width, &pix_rect.height);
	
	pix_rect.x += cell_area->x;
	pix_rect.y += cell_area->y;
	pix_rect.width  -= cell->xpad * 2;
	pix_rect.height -= cell->ypad * 2;
	
	if (gdk_rectangle_intersect (cell_area, &pix_rect, &draw_rect) &&
			gdk_rectangle_intersect (expose_area, &draw_rect, &draw_rect)) {
		gdk_draw_pixbuf(drawable, widget->style->black_gc, priv->stock_pixbuf,
				// pixbuf 0, 0 is at pix_rect.x, pix_rect.y 
				draw_rect.x - pix_rect.x,
				draw_rect.y - pix_rect.y,
				draw_rect.x, draw_rect.y,
				draw_rect.width, draw_rect.height,
				GDK_RGB_DITHER_NORMAL, 0, 0);
	}
}

// One of the core callback functions. Does the actual rendering.
static void cell_renderer_multi_render(GtkCellRenderer *cell,
		GdkDrawable *drawable, GtkWidget *widget, GdkRectangle *background_area,
		GdkRectangle *cell_area, GdkRectangle *expose_area, GtkCellRendererState flags)
{
	CellRendererMulti * multi = CELL_RENDERER_MULTI(cell);
	NodeContent::ContentType nodetype = getRenderingType(multi, widget);
	
	if (nodetype == NodeContent::TYPE_IMAGE) {
		renderPixbuf(cell, drawable, widget, 
				background_area, cell_area, expose_area, flags);
	} else if (nodetype == NodeContent::TYPE_BRANCH) {
		renderStockIcon(cell, drawable, widget, 
				background_area, cell_area, expose_area, flags);
	} else if (nodetype == NodeContent::TYPE_TEXT) {
		renderText(cell, drawable, widget, 
				background_area, cell_area, expose_area, flags);
	} else if (nodetype == NodeContent::TYPE_URI) {
		renderText(cell, drawable, widget, 
				background_area, cell_area, expose_area, flags);
	} else {
		fprintf(stderr, "Error! Renderer was told to render TYPE_EMPTY!\n");
	}
}

static gboolean	cellActivated(GtkCellRenderer *cell, GdkEvent *event, GtkWidget *widget, const gchar *path, GdkRectangle *background_area, GdkRectangle *cell_area, GtkCellRendererState flags) {
	//CellRendererMulti * multi = CELL_RENDERER_MULTI(cell);
	//cout << "GdkEvent: " << event->type << endl;
	g_signal_emit (cell, cell_renderer_multi_signals[ACTIVATED], 0, path);
	return true;
}


static void cell_renderer_multi_text_editing_done (GtkCellEditable *entry, gpointer         data) {
	const gchar *path;
	const gchar *new_text;
	CellRendererMultiPrivate * priv = CELL_RENDERER_MULTI_GET_PRIVATE (data);

	priv->entry = NULL;

	if (priv->focus_out_id > 0)
	{
		g_signal_handler_disconnect (entry, priv->focus_out_id);
		priv->focus_out_id = 0;
	}

	if (priv->populate_popup_id > 0)
	{
		g_signal_handler_disconnect (entry, priv->populate_popup_id);
		priv->populate_popup_id = 0;
	}

	if (priv->entry_menu_popdown_timeout)
	{
		g_source_remove (priv->entry_menu_popdown_timeout);
		priv->entry_menu_popdown_timeout = 0;
	}

	gtk_cell_renderer_stop_editing (GTK_CELL_RENDERER (data), 
			GTK_ENTRY (entry)->editing_canceled);
	if (GTK_ENTRY (entry)->editing_canceled)
		return;

	path = (gchar*)g_object_get_data(G_OBJECT (entry), CELL_RENDERER_MULTI_PATH);
	new_text = gtk_entry_get_text (GTK_ENTRY (entry));

	g_signal_emit(data, cell_renderer_multi_signals[EDITED], 0, path, new_text);
}

static gboolean popdown_timeout (gpointer data)
{
	CellRendererMultiPrivate * priv = CELL_RENDERER_MULTI_GET_PRIVATE (data);

	GDK_THREADS_ENTER ();

	priv->entry_menu_popdown_timeout = 0;

	if (!GTK_WIDGET_HAS_FOCUS (priv->entry))
		cell_renderer_multi_text_editing_done (GTK_CELL_EDITABLE (priv->entry), data);

	GDK_THREADS_LEAVE ();

	return FALSE;
}

static void
cell_renderer_multi_text_popup_unmap (GtkMenu *menu,
		gpointer data)
{
	CellRendererMultiPrivate * priv = CELL_RENDERER_MULTI_GET_PRIVATE (data);

	priv->in_entry_menu = FALSE;

	if (priv->entry_menu_popdown_timeout)
		return;

	priv->entry_menu_popdown_timeout = g_timeout_add (500, popdown_timeout,
			data);
}

static void
cell_renderer_multi_text_populate_popup (GtkEntry *entry,
		GtkMenu  *menu,
		gpointer  data)
{
	CellRendererMultiPrivate * priv = CELL_RENDERER_MULTI_GET_PRIVATE (data);

	if (priv->entry_menu_popdown_timeout)
	{
		g_source_remove (priv->entry_menu_popdown_timeout);
		priv->entry_menu_popdown_timeout = 0;
	}

	priv->in_entry_menu = TRUE;

	g_signal_connect (menu, "unmap", G_CALLBACK (cell_renderer_multi_text_popup_unmap), data);
}

static gboolean
cell_renderer_multi_text_focus_out_event (GtkWidget *entry,
		GdkEvent  *event,
		gpointer   data)
{
	CellRendererMultiPrivate * priv = CELL_RENDERER_MULTI_GET_PRIVATE (data);

	if (priv->in_entry_menu)
		return FALSE;

	cell_renderer_multi_text_editing_done (GTK_CELL_EDITABLE (entry), data);

	/* entry needs focus-out-event */
	return FALSE;
}

static GtkCellEditable *
cell_renderer_multi_text_start_editing (GtkCellRenderer      *cell,
		GdkEvent             *event,
		GtkWidget            *widget,
		const gchar          *path,
		GdkRectangle         *background_area,
		GdkRectangle         *cell_area,
		GtkCellRendererState  flags)
		{
	GtkCellRendererText *celltext;
	CellRendererMultiPrivate * priv = CELL_RENDERER_MULTI_GET_PRIVATE(cell);

	celltext = GTK_CELL_RENDERER_TEXT (cell);

	/* If the cell isn't editable we return NULL. */
	if (celltext->editable == FALSE)
		return NULL;

	priv->entry = (GtkWidget*)g_object_new(GTK_TYPE_ENTRY,
			"has_frame", FALSE,
			"xalign", cell->xalign,
			NULL);

	if (celltext->text)
		gtk_entry_set_text (GTK_ENTRY (priv->entry), celltext->text);
	g_object_set_data_full (G_OBJECT (priv->entry), CELL_RENDERER_MULTI_PATH, g_strdup (path), g_free);

	gtk_editable_select_region (GTK_EDITABLE (priv->entry), 0, -1);


	priv->in_entry_menu = FALSE;
	if (priv->entry_menu_popdown_timeout)
	{
		g_source_remove (priv->entry_menu_popdown_timeout);
		priv->entry_menu_popdown_timeout = 0;
	}

	g_signal_connect(priv->entry, "editing_done",
			G_CALLBACK (cell_renderer_multi_text_editing_done), celltext);
	priv->focus_out_id = g_signal_connect(priv->entry, "focus_out_event",
			G_CALLBACK (cell_renderer_multi_text_focus_out_event),
			celltext);
	priv->populate_popup_id =
		g_signal_connect(priv->entry, "populate_popup",
				G_CALLBACK (cell_renderer_multi_text_populate_popup),
				celltext);

	gtk_widget_show (priv->entry);

	return GTK_CELL_EDITABLE (priv->entry);
		}

/**
 * gtk_cell_renderer_text_set_fixed_height_from_font:
 * @renderer: A #GtkCellRendererText
 * @number_of_rows: Number of rows of text each cell renderer is allocated, or -1
 * 
 * Sets the height of a renderer to explicitly be determined by the "font" and
 * "y_pad" property set on it.  Further changes in these properties do not
 * affect the height, so they must be accompanied by a subsequent call to this
 * function.  Using this function is unflexible, and should really only be used
 * if calculating the size of a cell is too slow (ie, a massive number of cells
 * displayed).  If @number_of_rows is -1, then the fixed height is unset, and
 * the height is determined by the properties again.
 **/
void
cell_renderer_multi_set_fixed_height_from_font (GtkCellRendererText *renderer,
		gint                 number_of_rows)
{
	g_return_if_fail (GTK_IS_CELL_RENDERER_TEXT (renderer));
	g_return_if_fail (number_of_rows == -1 || number_of_rows > 0);

	if (number_of_rows == -1)
	{
		gtk_cell_renderer_set_fixed_size (GTK_CELL_RENDERER (renderer),
				GTK_CELL_RENDERER (renderer)->width,
				-1);
	}
	else {
		renderer->fixed_height_rows = number_of_rows;
		renderer->calc_fixed_height = TRUE;
	}
}
