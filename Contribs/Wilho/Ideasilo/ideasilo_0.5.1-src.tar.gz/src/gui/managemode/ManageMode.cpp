#include "ManageMode.h"

#include <iostream>
#include "gui/dialog/EditDialog.h"
#include "gui/action/GUIAction.h"

#include "event/GUIEvent.h"
#include "ManageModeEvent.h"
#include "gui/GladeTag.h"


enum RootListViewColumns { 
	ROOTLISTVIEW_ID_COLUMN, 
	ROOTLISTVIEW_LABEL_COLUMN, 
	N_ROOTLISTVIEW_COLUMNS
};


ManageMode::ManageMode(AppData * appdata, SettingHandler * appsettings, const DataBase & db, const rootnodes & rnodes):
ApplicationMode(appdata, appsettings, db, rnodes),
_managerootxml(NULL),
_manageroot(NULL),
_rootlistview(NULL),
_rootlist(NULL),
_branchview(NULL),
_nodatapage(NULL)
{
	_openeditaction = new OpenEditDialogAction(_appdata->evbuf->requestWriter(), _appdata->uifilename, "edit", "Edit", "Edit entry");
	_openeditaction->setTarget(this);
	_removedatapageaction = new RemoveNodeAction(_appdata->evbuf->requestWriter(), "deletedatapage", "Delete", "Delete set");
	_removedatapageaction->setTarget(this);
}

ManageMode::~ManageMode()
{
	release();
	delete _openeditaction;
	delete _removedatapageaction;
}

void ManageMode::activate() {
	//cout << "in ManageMode::activate" << endl;
	GdkThread::enter();
	_branchhistory.clear();
	_currentbranch = _branchhistory.end();
	if (!_nodatapage) {
		GladeXML * nodataxml = glade_xml_new(_appdata->uifilename.c_str(), GLADE::COMMON::NODATAPAGE, NULL);
		_nodatapage = glade_xml_get_widget(nodataxml, GLADE::COMMON::NODATAPAGE); // Store the info page for later use
		g_object_ref(_nodatapage);				// Store the empty page for later use
		gtk_object_sink(GTK_OBJECT(_nodatapage));
		g_object_unref(nodataxml);
	}
	if (!_managerootxml) {
		_managerootxml = glade_xml_new(_appdata->uifilename.c_str(), GLADE::MANAGE::ROOT, NULL);
	}
	if (!_manageroot && _managerootxml) {	
		_manageroot = glade_xml_get_widget(_managerootxml, GLADE::MANAGE::ROOT);	
		g_object_ref(_manageroot);
		gtk_object_sink(GTK_OBJECT(_manageroot));
		// * Fetch the treeviews from the glade file
		_rootlistview = GTK_TREE_VIEW(glade_xml_get_widget(_managerootxml, GLADE::MANAGE::SELECTLIST_VIEW));
		_branchview = GTK_TREE_VIEW(glade_xml_get_widget(_managerootxml, GLADE::MANAGE::MAINLIST_VIEW));
		// * Set up the treeviews
		GtkTreeViewColumn * newcolumn;
		GtkCellRenderer * newrenderer;
		
		// ** set up the root list view
		// TODO: Make sure there's no memory leak
		_rootlist = gtk_list_store_new(N_ROOTLISTVIEW_COLUMNS, G_TYPE_STRING, G_TYPE_STRING);
		gtk_tree_view_set_model(_rootlistview, GTK_TREE_MODEL(_rootlist));
		
		// *** set up the columns and associated renderers
		newrenderer = gtk_cell_renderer_text_new();
		g_object_set(newrenderer, "foreground", "red", "size-points", 8.0, NULL);
		newcolumn = gtk_tree_view_column_new_with_attributes("ID", newrenderer, "text", ROOTLISTVIEW_ID_COLUMN, NULL);//"size-points", 12.0, "foreground", "red",  NULL);
		gtk_tree_view_column_set_visible(newcolumn, false);		// Hide the ID column. ID is only used internally, no need to present it to the user
		gtk_tree_view_append_column(_rootlistview, newcolumn);
		newrenderer = gtk_cell_renderer_text_new();
		newcolumn = gtk_tree_view_column_new_with_attributes("Label", newrenderer, "text", ROOTLISTVIEW_LABEL_COLUMN, NULL);
		gtk_tree_view_append_column(_rootlistview, newcolumn);
		
		// *** set up the selection callback for the select list
		GtkTreeSelection * select = gtk_tree_view_get_selection(_rootlistview);
		gtk_tree_selection_set_mode(select, GTK_SELECTION_BROWSE);
		g_signal_connect(G_OBJECT(select), "changed", G_CALLBACK(page_selection_changed), this);
		g_signal_connect(G_OBJECT(_rootlistview), "enter-notify-event", G_CALLBACK(rootlistview_selected), this);
		
		// ** set up the main list view
		// *** set up the selection callback for the branchview list
		select = gtk_tree_view_get_selection(_branchview);
		gtk_tree_selection_set_mode(select, GTK_SELECTION_BROWSE);
//		g_signal_connect(G_OBJECT(select), "changed", G_CALLBACK(branch_selection_changed), this);
		// *** set up the columns and associated renderers
		newrenderer = gtk_cell_renderer_text_new();
		g_object_set(newrenderer, "foreground", "red", "size-points", 8.0, NULL);
		newcolumn = gtk_tree_view_column_new_with_attributes("ID", newrenderer, "text", ManageNodeView::BRANCHVIEW_ID_COLUMN, NULL);
		gtk_tree_view_column_set_visible(newcolumn, false);		// Hide the ID column. ID is only used internally, no need to present it to the user
		gtk_tree_view_append_column(_branchview, newcolumn);
		
		newrenderer = gtk_cell_renderer_text_new();
		g_object_set(newrenderer, "foreground", "red", "size-points", 8.0, NULL);
		newcolumn = gtk_tree_view_column_new_with_attributes("Version", newrenderer, "text", ManageNodeView::BRANCHVIEW_VERSION_COLUMN, NULL);
		gtk_tree_view_append_column(_branchview, newcolumn);
		
		newrenderer = gtk_cell_renderer_text_new();
		g_object_set(newrenderer, "foreground", "blue", "yalign", 0.0, NULL);
		newcolumn = gtk_tree_view_column_new_with_attributes("Label", newrenderer, "text", ManageNodeView::BRANCHVIEW_LABEL_COLUMN, NULL);
		gtk_tree_view_append_column(_branchview, newcolumn);
		
		// Using a custom made cell renderer, able to render both text and images
		newrenderer = cell_renderer_multi_new();
		g_signal_connect(newrenderer, "activated", G_CALLBACK(node_activated), this);
		g_object_set(newrenderer, "stock-id", GTK_STOCK_FIND, "mode", GTK_CELL_RENDERER_MODE_ACTIVATABLE, NULL);
		newcolumn = gtk_tree_view_column_new_with_attributes("Data", newrenderer, "dataentry", ManageNodeView::BRANCHVIEW_DATA_COLUMN, NULL);
		gtk_tree_view_append_column(_branchview, newcolumn);
		
		// Connect the browse buttons
		GtkButton * button;
		button = GTK_BUTTON(glade_xml_get_widget(_managerootxml, GLADE::MANAGE::BROWSE_BACK_BUTTON));
		g_signal_connect(G_OBJECT(button), "clicked", G_CALLBACK(back_button_clicked), this);
		button = GTK_BUTTON(glade_xml_get_widget(_managerootxml, GLADE::MANAGE::BROWSE_FORWARD_BUTTON));
		g_signal_connect(G_OBJECT(button), "clicked", G_CALLBACK(forward_button_clicked), this);
		button = GTK_BUTTON(glade_xml_get_widget(_managerootxml, GLADE::MANAGE::BROWSE_PARENT_BUTTON));
		g_signal_connect(G_OBJECT(button), "clicked", G_CALLBACK(parent_button_clicked), this);
	}
	
	refreshNodes();
	setFrontpage();
	GdkThread::leave();
	//cout << "leaving ManageMode::activate" << endl;
}

void ManageMode::release() {
	GdkThread::enter();
	resetToolbar();
	_frontwidget = NULL;
	//cout << "start ManageMode::release" << endl;
	nodeviews::iterator it;
	while (!_nodeviews.empty()) {
		it = _nodeviews.begin();
		//it->second->releaseWidgets();
		delete *it;
		_nodeviews.erase(it);	
	}
	if (_nodatapage) {
		g_object_unref(_nodatapage);
		_nodatapage = NULL;
	}
	if (_manageroot) {
		g_object_unref(_manageroot);
		_manageroot = NULL;
		// TODO: Make sure there's no memory leak here
		_rootlistview = NULL;
		_branchview = NULL;
	}
	if (_managerootxml) {
		g_object_unref(_managerootxml);
		_managerootxml = NULL;
	}
	//cout << "end ManageMode::release" << endl;
	GdkThread::leave();
}

void ManageMode::setToolbar(GtkToolbar * toolbar) {
	if (!_toolbar) {
		_toolbar = toolbar;
		_openeditaction->addToToolbar(_toolbar);
		_removedatapageaction->addToToolbar(_toolbar);
	}
}

void ManageMode::resetToolbar() {
	if (_toolbar) {
		_openeditaction->removeFromToolbar(_toolbar);
		_removedatapageaction->removeFromToolbar(_toolbar);
		_toolbar = NULL;
	}
}

ManageNodeView * ManageMode::getNodeView(const string & nodeid) {
	for (nodeviews::iterator it = _nodeviews.begin();it != _nodeviews.end(); it++) {
		if (*it && (*it)->getNode()) {
			//cout << "ManageMode::getNodeView: Searching for: " << nodeid << " This is: " << (*it)->getNode()->getID() << endl;
			if (!nodeid.compare((*it)->getNode()->getID()))
				return *it;
		}
	}
	return NULL;
}

void	ManageMode::refreshNode(const string & nodeid) {
	//cout << "in ManageMode::refreshNode: " << nodeid << endl;
	GdkThread::enter();
	ManageNodeView * nodeview = getNodeView(nodeid);
	const Node * node = getNode(nodeid);
	//cout << "ManageMode::refreshNode: << " << nodeid << " "<< (nodeview != NULL) << " " << (node != NULL) << endl;
	if (node) {
		if (nodeview) {
			// A Nodeview exists already in the screen and the memory. Update the contents.
			nodeview->redrawObjects();	
		} else {
			// Nodeview doesn't exist. This could mean the node is one of the children of the currently viewed branch node
			string currentroot = getRootSelection();
			nodeview = getNodeView(currentroot);
			if (nodeview)
				nodeview->refreshNode(nodeid);
		}
		refreshRootlistView(node);
	} else {
		removeReferencesToNode(nodeid);
	}
	setFrontpage();
	GdkThread::leave();
	//cout << "leaving ManageMode::refreshNode: " << nodeid << endl;
}

void	ManageMode::refreshRootlistView(const Node * node) {
	//cout << "In ManageMode::refreshRootlistView: "<<  endl;
	// Dont add non-root nodes to the root list
	int index = isRootNode(node->getID());
	if (index == -1)
		return;
	removeFromRootlistView(node->getID());
	// Dont add contentless nodes to the root list
	if (node->getContentType() != NodeContent::TYPE_EMPTY) {
		GdkThread::enter();
		const string & label = node->getContents()->getLabel();
		GtkTreeIter it;
		// Inserting a new row to the list must be done with gtk_list_store_insert_with_values, because it's the only one that can be done atomically. It must be done atomically, because otherwise it would run selection changed callback on an empty row.
		gtk_list_store_insert_with_values(_rootlist, &it, index, ROOTLISTVIEW_ID_COLUMN, node->getID().c_str(), ROOTLISTVIEW_LABEL_COLUMN, label.c_str(), -1);
		GdkThread::leave();
	}
	
	//cout << "Leaving ManageMode::refreshRootlistView: " << endl;
}

void ManageMode::removeFromRootlistView(const string & nodeid) {
	//cout << "In ManageMode::removeFromRootlistView: " << nodeid << endl;
	GtkTreeIter it;
	GtkTreeModel * model = GTK_TREE_MODEL(_rootlist);
	if (gtk_tree_model_get_iter_first(model, &it))
		do {
			gchar * data;
			gtk_tree_model_get(model, &it, ROOTLISTVIEW_ID_COLUMN, &data, -1);
			bool equal = !strcmp(nodeid.c_str(), data);
			g_free(data);
			if (equal) {
				gtk_list_store_remove(_rootlist, &it);
				return;
			}
		} while (gtk_tree_model_iter_next(model, &it));
	//cout << "Leaving ManageMode::removeFromRootlistView: " << nodeid << endl;
}


void ManageMode::removeReferencesToNode(const string & nodeid) {
	//cout << "<<del>>" << (nodeview != NULL) << " " << (node != NULL) << endl;
	// A page was removed from the data. Find the representations and delete them
	removeFromRootlistView(nodeid);
	ManageNodeView * nodeview = getNodeView(nodeid);
	if (nodeview) {
		_nodeviews.erase(nodeview);
		delete nodeview;
	}
	// All nodeviews also need to be checked in case of references to the missing node 
	for (nodeviews::iterator it = _nodeviews.begin(); it != _nodeviews.end(); it++) {
		nodeview = *it;
		nodeview->removeReferencesToNode(nodeid);
	}
}

string ManageMode::getSelection() {
	GtkTreeSelection *selection = gtk_tree_view_get_selection(_branchview);
	GtkTreeIter it;
	GtkTreeModel * model;
	gchar * nodeid = NULL;
	string result;
	if (gtk_tree_selection_get_selected(selection, &model, &it)) {
		gtk_tree_model_get(model, &it, ManageNodeView::BRANCHVIEW_ID_COLUMN, &nodeid, -1);
		result = nodeid;
		g_free(nodeid);
	}
	if (nodeid)
		return result;
	else 
		return getRootSelection();
}

string ManageMode::getRootSelection() {
	GtkTreeIter it;
	GtkTreeModel * model;
	GtkTreeSelection *selection = gtk_tree_view_get_selection(_rootlistview);
	gchar * nodeid = NULL;
	string result;
	if (gtk_tree_selection_get_selected(selection, &model, &it)) {
		gtk_tree_model_get(model, &it, ROOTLISTVIEW_ID_COLUMN, &nodeid, -1);
		result = nodeid;
		g_free(nodeid);
	}
	if (nodeid)
		return result;
	else
		return "";
}

//void	ManageMode::changeFocus(const string & setid, int entryid) {
//	//cout << "ManageMode::setFocus: " << setid << endl;
//	ManagePageView * view = getPageView(setid);
//	if (view)
//		view->setFocus(entryid);
//}

void	ManageMode::setFrontpage() {
	GdkThread::enter();
	if (_rootnodes.empty()) {
		_frontwidget = _nodatapage;
	} else {
		_frontwidget = GTK_WIDGET(_manageroot);
	}
	GdkThread::leave();
}

void ManageMode::activateNodeView(const string & nodeid) {
	//cout << "In ManageMode::activateNodeView: "<< nodeid<< endl;
	GdkThread::enter();
	ManageNodeView * nodeview = getNodeView(nodeid);
	const Node * node = getNode(nodeid);
	if (node) {
		if (!nodeview) {
			//cout << "ManageMode::activateNodeView: Adding new nodeview for node: " << node->getID() << endl;
			// A new node appeared in the data. Represent it with a new nodeview.
			nodeview = new ManageNodeView(this);
			nodeview->createObjects();
			_nodeviews.insert(nodeview);
			nodeview->attachNode(node);
		}
		if (nodeview) {
			branchhistory::iterator it = _currentbranch;
			it++;
			if (_currentbranch == _branchhistory.end() || nodeid.compare(*_currentbranch))
				if (_currentbranch != _branchhistory.end() && it != _branchhistory.end() && !nodeid.compare(*it)) {
					_currentbranch = it;
				} else {
					if (_currentbranch != _branchhistory.end() && it != _branchhistory.end()) {
						_branchhistory.erase(it, _branchhistory.end());
					}
					_branchhistory.push_back(nodeid);
					_currentbranch = _branchhistory.end();
					_currentbranch--;
					//cout << "Set currentbranch to: " << *_currentbranch << " " << _branchhistory.size() << endl;
				}
			nodeview->displayInBranchView(_branchview);
			GtkTreeSelection * branchselection = gtk_tree_view_get_selection(_branchview);
			gtk_tree_selection_unselect_all(branchselection);
//			if (isRootNode(nodeid) ==  -1) {
//				// If the new nodeview is not in the root node list, unselect the current selection in the root list view
//				GtkTreeSelection * rootselection = gtk_tree_view_get_selection(_rootlistview);
//				//gtk_tree_selection_unselect_all(rootselection);
//			}
		}
	}
	GdkThread::leave();
	//cout << "Leaving ManageMode::activateNodeView: nodeid" << endl;
}

void ManageMode::browseBack() {
	//cout << "In ManageMode::browseBack" << endl;
	if (_branchhistory.empty())
		return;
	if (_currentbranch == _branchhistory.begin() || _currentbranch == _branchhistory.end())
		return;
	branchhistory::iterator it = _currentbranch;
	it--;
	for (; ; it--) {
		if (it == _branchhistory.end())
			return;
		const Node * node = getNode(*it);
		if (node)
			break;
		if (it == _branchhistory.begin()) {
			return;
		}
	}
	_currentbranch = it;
	//cout << "ManageMode::browseBack: Activating " << *_currentbranch << endl;
	activateNodeView(*_currentbranch);
	//cout << "Leaving ManageMode::browseBack" << endl;
}

void ManageMode::browseForward() {
	if (_branchhistory.empty())
		return;
	branchhistory::iterator it = _currentbranch;
	it++;
	if (it == _branchhistory.end())
		return;
	_currentbranch = it;
	activateNodeView(*_currentbranch);
}

void ManageMode::browseParent() {
	string currentbranch = *_currentbranch;
	//cout << currentbranch << endl;
	if (currentbranch.length() <= 1)
		return;
	int index = currentbranch.find_last_of("/", currentbranch.length()-1);
	if (index >= 0) {
		string parentid = currentbranch.substr(0, index);
		//cout << parentid << endl;
		activateNodeView(parentid);
	}
}

// ***************** CALLBACKS ******************
void ManageMode::page_selection_changed(GtkTreeSelection *selection, gpointer mode) {
	//cout << "In ManageMode::page_selection_changed" << endl;
    GtkTreeIter iter;
    GtkTreeModel *model;
    if (gtk_tree_selection_get_selected(selection, &model, &iter)) {
    	gchar * data;
    	gtk_tree_model_get(model, &iter, ROOTLISTVIEW_ID_COLUMN, &data, -1);
    	if (data) {
    		ManageMode * managemode = static_cast<ManageMode*>(mode);
    		//cout << "ManageMode::page_selection_changed: " << data << endl;
    		managemode->_writer->push(new NodeViewActivationEvent(data));
    		g_free (data);
    	}
    }
    //cout << "Leaving ManageMode::page_selection_changed" << endl;

}

bool ManageMode::rootlistview_selected(GtkWidget * widget, GdkEventCrossing * event, gpointer mode) {
	if (event->mode == GDK_CROSSING_UNGRAB) {
		//cout << "Called!" << endl;
		ManageMode * managemode = static_cast<ManageMode*>(mode);
		GtkTreeSelection * branchselection = gtk_tree_view_get_selection(managemode->_branchview);
		gtk_tree_selection_unselect_all(branchselection);
	}
	return false;
}

// A node content was clicked in the branch view
void ManageMode::node_activated(CellRendererMulti * multi, gpointer modeptr) {
	if (multi) {
		Node * node = multi->node;
		if (node && node->getContentType() == NodeContent::TYPE_BRANCH) {
			ManageMode * mode = static_cast<ManageMode*>(modeptr);
			if (mode) {
				mode->_writer->push(new NodeViewActivationEvent(node->getID()));
			}
		}
	}
}

void ManageMode::back_button_clicked(GtkWidget * widget, ManageMode * mode) {
	mode->_writer->push(new BrowseEvent(BrowseEvent::BACK));
}

void ManageMode::forward_button_clicked(GtkWidget * widget, ManageMode * mode) {
	mode->_writer->push(new BrowseEvent(BrowseEvent::FORWARD));
}

void ManageMode::parent_button_clicked(GtkWidget * widget, ManageMode * mode) {
	mode->_writer->push(new BrowseEvent(BrowseEvent::PARENT));
}

