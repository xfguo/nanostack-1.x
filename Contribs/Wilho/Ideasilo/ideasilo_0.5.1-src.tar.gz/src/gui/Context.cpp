#include "Context.h"
#include <iostream>



const xmlChar * CONTEXT_TAG = (xmlChar*)"context";
const xmlChar * ID_TAG = (xmlChar*)"ID";
const xmlChar * LABEL_TAG = (xmlChar*)"label";
const xmlChar * SHORT_TAG = (xmlChar*)"short";
const xmlChar * MODE_TAG = (xmlChar*)"mode";
const xmlChar * SETTINGS_TAG = (xmlChar*)"settings";

ContextSetting::ContextSetting() {	
}

ContextSetting::ContextSetting(const ContextSetting & ot):
data(ot.data)
{
	for (settings::const_iterator it = ot.children.begin(); it != ot.children.end(); it++) {
		children[it->first] = new ContextSetting(*it->second);
	}
}

ContextSetting::~ContextSetting() {
	for (settings::iterator it = children.begin(); it != children.end(); it++)
		delete it->second;
}

ContextSetting & ContextSetting::operator=(const ContextSetting & ot) {
	if (&ot == this)
		return *this;
	data = ot.data;
	for (settings::iterator it = children.begin(); it != children.end(); it++) {
		delete it->second;
		children.erase(it);
	}
	for (settings::const_iterator it = ot.children.begin(); it != ot.children.end(); it++) {
		children[it->first] = new ContextSetting(*it->second);
	}
	return *this;
}

const ContextSetting * ContextSetting::getSetting(const string & path) const {
	return getSettingPair(path).second;
}

const ContextSetting::setting ContextSetting::getSettingPair(const string & path) const {
	unsigned int slash = 0, nextslash;
	slash = path.find('/', slash);
	//cout << "Slash found at: " << slash << endl;
	nextslash = path.find('/', slash+1);
	//cout << "Next slash found at: " << nextslash << endl;
	string thispath, nextpath;
	if (nextslash == string::npos) {
		thispath = path.substr(slash+1);
		nextpath = "";
	} else {
		thispath = path.substr(slash+1, nextslash-slash-1);
		nextpath = path.substr(nextslash);
	}
	//cout << "Thispath is: " << thispath << endl;
	//cout << "Nextpath is: " << nextpath << endl;
	settings::const_iterator it = children.find(thispath);
	if (it != children.end()) {
		if (nextpath.length() == 0 || !nextpath.compare("/")) {
			// Either the last character was a slash, or the slash was not found at all. The required setting was found; return it
			//cout << "Found final node with name: " << it->first << endl;
			return *it;
		} else {
			// The string under inspection is not the last one in the chain. Continue searching.
			//cout << "Found child node with name: " << it->first << endl;
			//cout << "Calling getSetting with path: " << nextpath << endl;
			return it->second->getSettingPair(nextpath);		
		}
	} else {
		// The required setting was not found. Return the missing setting string with NULL
		return pair<string, ContextSetting*>(thispath, NULL);
	}
}


ContextSetting* ContextSetting::parseContextSetting(const xmlNode * root) {
	ContextSetting * newsetting = new ContextSetting;
	if (root->content) {
		
		cout << "Data found! Node: "<< (char*)root->name << "Data: " << newsetting->data << endl;
	}
	for (const xmlNode * child = root->children; child; child = child->next) {
		if (child->type == XML_ELEMENT_NODE) {
			newsetting->children[(char*)child->name] = parseContextSetting(child);
		} else if (child->type == XML_TEXT_NODE) {
			newsetting->data = newsetting->data.append((const char*)child->content);
		}
	}
	newsetting->data = newsetting->data.substr(newsetting->data.find_first_not_of(' '), newsetting->data.find_last_not_of(' ')+1);
	return newsetting;
}

Context::Context():
_mode(-1),
_settings(NULL)
{
	pthread_mutex_init(&_lock,NULL);
}

Context::Context(const Context & ot)
{
	pthread_mutex_init(&_lock,NULL);
	pthread_mutex_lock(&ot._lock);
	_id = ot._id;
	_mode = ot._mode;
	_label = ot._label;
	_shortlabel = ot._shortlabel;
	if (ot._settings)
		_settings = new ContextSetting(*ot._settings);
	else
		_settings = NULL;
	pthread_mutex_unlock(&ot._lock);
}

Context::~Context()
{
	delete _settings;
}



ContextSetting Context::getSetting(const string & path) const {
	ContextSetting result;
	if (!_settings)
		return result;
	pthread_mutex_lock(&_lock);
	const ContextSetting * setting = _settings->getSetting(path);
	if (setting)
		result = *setting;
	pthread_mutex_unlock(&_lock);
	return result;
}

string Context::getSettingValue(const string & path) const {
	if (!_settings)
		return "";
	pthread_mutex_lock(&_lock);
	string result = "";
	const ContextSetting * setting = _settings->getSetting(path);
	if (setting)
		result = setting->getData();
	pthread_mutex_unlock(&_lock);
	return result;
}

Context & Context::operator=(const Context & ot) {
	if (&ot == this)
		return *this;
	pthread_mutex_lock(&_lock);
	_id = ot._id;
	_mode = ot._mode;
	_label = ot._label;
	_shortlabel = ot._shortlabel;
	delete _settings;
	_settings = new ContextSetting(*ot._settings);
	pthread_mutex_unlock(&_lock);
	return *this;
}

Context * Context::parseContextData(const string & xmldata) {
	xmlDoc * doc = xmlReadMemory(xmldata.c_str(), xmldata.length(), "newcontext.xml", NULL, 0);
	if (doc == NULL) {
		cerr << "Warning! Failed to parse context data" << endl;
		return NULL;	
	}
	xmlNode * root = xmlDocGetRootElement(doc);
	Context * newcontext = parseContextData(root);
	xmlFreeDoc(doc);
	return newcontext;
}

Context * Context::parseContextData(const xmlNode * root) {
	Context * newcontext = NULL;
	if (root->type == XML_ELEMENT_NODE && xmlStrEqual(root->name, CONTEXT_TAG)) {
		newcontext = new Context;
		for (const xmlNode * curnode = root->children; curnode; curnode = curnode->next) {
			if (curnode->type == XML_ELEMENT_NODE && xmlStrEqual(curnode->name, ID_TAG)) {
				newcontext->_id = atoi((char*)curnode->children->content);
			} else if (curnode->type == XML_ELEMENT_NODE && xmlStrEqual(curnode->name, LABEL_TAG)) {
				newcontext->_label = (char*)curnode->children->content;
			} else if (curnode->type == XML_ELEMENT_NODE && xmlStrEqual(curnode->name, SHORT_TAG)) {
				newcontext->_shortlabel = (char*)curnode->children->content;
			} else if (curnode->type == XML_ELEMENT_NODE && xmlStrEqual(curnode->name, MODE_TAG)) {
				newcontext->_mode = atoi((char*)curnode->children->content);
			} else if (curnode->type == XML_ELEMENT_NODE && xmlStrEqual(curnode->name, SETTINGS_TAG)) {
				newcontext->_settings = ContextSetting::parseContextSetting(curnode);
			}
		}
		
	}
	return newcontext;
}


