#include "Connection.h"
#include <iostream>

Connection::Connection():
_request(NULL) {
	_handle = curl_easy_init();
	// Set options specific to all curl connections
	curl_easy_setopt(_handle, CURLOPT_WRITEFUNCTION, write_data_callback);
	curl_easy_setopt(_handle, CURLOPT_WRITEDATA, this);
	curl_easy_setopt(_handle, CURLOPT_HEADERFUNCTION, write_header_callback);
	curl_easy_setopt(_handle, CURLOPT_HEADERDATA, this);
	curl_easy_setopt(_handle, CURLOPT_CONNECTTIMEOUT, (long)5);	// Connection timeout is 3 seconds

	//curl_easy_setopt(_handle, CURLOPT_READFUNCTION, read_data_callback);
	//curl_easy_setopt(_handle, CURLOPT_READDATA, this);
}

Connection::~Connection() {
	curl_easy_cleanup(_handle);
	if (_request)
		delete _request;
}


bool Connection::setRequest(Request * request) {
	if (!isIdle()) {
		delete request;
		return false;
	}
	if (_request)
		delete _request;
	_request = request;
	_headers.clear();
	_received.clear();
	
	if (_request->content.length() > 0) {
		// Set options specific to all POST type curl connections
		struct curl_slist * headers = NULL;
		headers = curl_slist_append(headers, "Content-Type: text/xml");
		//headers = curl_slist_append(headers, "Connection: close");
		curl_easy_setopt(_handle, CURLOPT_NOSIGNAL, 1);
		curl_easy_setopt(_handle, CURLOPT_POSTFIELDSIZE, _request->content.length());//_request->content.str().length());
		curl_easy_setopt(_handle, CURLOPT_POSTFIELDS, _request->content.c_str());
		curl_easy_setopt(_handle, CURLOPT_POST, 1);
		curl_easy_setopt(_handle, CURLOPT_HTTPHEADER, headers);
		//curl_slist_free_all(headers); // Is this ok?
	} else {
		// Set options specific to all GET type curl connections
		curl_easy_setopt(_handle, CURLOPT_HTTPGET, 1);
	}
	
	return true;
}

bool Connection::setURL(const string & url) {
	if (isIdle()) {
		_url = url;
		curl_easy_setopt(_handle, CURLOPT_URL, _url.c_str());
		return true;
	} else
		return false;
}

string Connection::getHeader(const string & header) {
	headers::iterator it = _headers.find(header);
	if (it != _headers.end())
		return it->second;
	else
		return "";
}

size_t Connection::write_header_callback(void *buffer, size_t size, size_t nmemb, void *userp) {
	Connection * transac = static_cast<Connection*>(userp);
	string headerline((char*)buffer, size*nmemb);
	size_t index = headerline.find(": ",0);
	size_t end = headerline.find("\r\n");
	if (index > 0) {
		string header = headerline.substr(0, index);
		string value = headerline.substr(index+2, end-index-2);
		transac->_headers[header] = value;
	}
	return size * nmemb;
}

// Static callback function for receiving data from the network
size_t Connection::write_data_callback(void *buffer, size_t size, size_t nitems, void *userp) {
	//cout << "Connection::write_data_callback called!" << endl;
	Connection * transac = static_cast<Connection*>(userp);
	//cout << "** Received data **" << endl;
	//cout << "Size: " << size << " nmemb: " << nmemb << endl;
	//cout << (char*)buffer << endl;
	transac->_received.write((char*)buffer, size*nitems);
	return size * nitems;
}
