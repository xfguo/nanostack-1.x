#ifndef NETWORKCONTROLLER_H_
#define NETWORKCONTROLLER_H_

//#include <iostream>
#include <string>
#include <curl/curl.h>	// For implementing HTTP connection
#include <map>
#include <sstream>
#include "AppData.h"
#include "event/Event.h"
#include "event/EventBuffer.h"
#include "util/SettingHandler.h"
#include "util/Thread.h"
#include "dataformat/Node.h"
#include "Connection.h"
#include "Request.h"

using namespace std;

class NetworkController : public Thread
{
public:
	
	//friend Connection::Connection;
	typedef queue<Request*> requests;
	typedef map<CURL*, Connection *> connections;
	
	NetworkController(AppData * appdata, EventBuffer::Writer * writer, SettingHandler & appsettings);
	virtual ~NetworkController();
	
	void sendLogin();
	void sendOrderForm(const string & orderer, const string & supplier, const string & orderlist);
	void queryServerNode(const string & nodeid);
	void queryServerImage(const Node * node);
	void queryServerImage(const string & nodeid);
	void queryRemoteImage(const string & nodeid, const string & url, unsigned int clientver);
	void updateServerNode(const Node * newnode);
	void setServerURL(const string & url);
	string	getServerURL() const	{ return _serverurl; }
	
	bool raiseTestResponse_v2(const string & ID);
	string getTestImageXML1();		// DEBUG;
	
private:
	
	pthread_mutex_t _lock;		// For making sure the query stack isn't accessed by several threads at once
	requests 		_requests;
	
	void			addRequest(Request * req);
	Connection * 	checkRequests();
	void			dispatchCurlMsg(CURLMsg * msg);
	
	int				addConnection(Connection * conn);
	int				removeConnection(Connection * conn);
	int				getRunningHandles()			{ return _runninghandles; }
	
	void 			printInMessage(const string & str);
	void 			printOutMessage(const string & str);
	GdkPixbuf *		loadImage(const stringstream & stream);

	
	AppData * 					_appdata;		// Struct containing system data
	EventBuffer::Writer * 		_writer;
	SettingHandler & 			_appsettings;
	
	virtual int setup();
	virtual int run();
	
	string						_serverurl;		// Server URL. This is just a copy of the one set in application settings
	curl_version_info_data * 	_curlversion;	// current curl version information
	CURLM * 					_curl;			// Handle to curl multi interface
	connections 				_connections;
	int							_runninghandles;
};


#endif /*NETWORKCONTROLLER_H_*/
