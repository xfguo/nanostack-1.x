#include "NetworkController.h"

#include <string>
#include <string.h>
#include <sstream>
#include <iostream> //DEBUG
#include <sys/stat.h>
#include "gui/GUI.h"
#include "event/GUIEvent.h"
#include "NetworkEvent.h"
#include "dataformat/ImageLeaf.h"
#include "util/Util.h"

const string PROTOCOL_STRING = "http://";
const string DATABASE_APP_NAME = "db";

const string CONTENT_TYPE_IMAGE = "image";
const string CONTENT_TYPE_XML = "text/xml";

const string SETTING_OFFLINE_DEBUG = "Offline-debug";

NetworkController::NetworkController(AppData * appdata, EventBuffer::Writer * writer, SettingHandler & appsettings):
_appdata(appdata),
_writer(writer), 
_appsettings(appsettings),
_runninghandles(0)
{
	pthread_mutex_init(&_lock,NULL);
	// Get information about the current version of libcurl
	_curl = curl_multi_init();
	_curlversion = curl_version_info(CURLVERSION_NOW);
//	const Setting * serverurl = _appsettings.find(SETTING_SERVER_URL);
//	if (serverurl) {
//		setServerURL(serverurl->getData()); 
//	} else {
//		cerr << "Warning! Could not find setting ServerIP in application settings" << endl;
//	}
}

NetworkController::~NetworkController()
{
	if (_curl) curl_multi_cleanup(_curl);
	
}

void NetworkController::sendLogin() {
	Request * newreq = new Request(Request::TYPE_IDEASILO_SERVER_REQUEST);
	newreq->req_params = string("?action=login");
	addRequest(newreq);
}

void NetworkController::sendOrderForm(const string & orderer, const string & supplier, const string & orderlist) {
	Request * newreq = new Request(Request::TYPE_IDEASILO_SERVER_REQUEST);
	newreq->req_params = string("?action=sendorder");
	stringstream content;
	content << "<sendorder>" << endl;
	content << "<orderer>" << orderer << "</orderer>" << endl;
	content << "<supplier>" << supplier << "</supplier>" << endl;
	content << "<order>" << orderlist << "</order>" << endl;
	content << "</sendorder>";
	newreq->content = content.str();
	addRequest(newreq);
}

void NetworkController::queryServerNode(const string & nodeid) {
	bool debug = false;
	Setting * offline_debug = _appsettings.find(SETTING_OFFLINE_DEBUG);
	if (offline_debug) {
		if (!Util::compareNoCase(offline_debug->getData(), "true") ||
				!Util::compareNoCase(offline_debug->getData(), "1"))
			debug = true;
	}
	if (debug) {
		if (raiseTestResponse_v2(nodeid)); 
			return;	
	}
	Request * newreq = new Request(Request::TYPE_IDEASILO_SERVER_REQUEST);
	newreq->req_params = string("?action=query&nodeid=") + nodeid + "&depth=-1";
	addRequest(newreq);
	
}

void NetworkController::updateServerNode(const Node * newnode) {
	stringstream content;
	Request * newreq = new Request(Request::TYPE_IDEASILO_SERVER_REQUEST);
	newreq->req_params = "?action=update";
	content << "<update>" << endl;
	content << newnode->serializeToXML(1) << endl;
	content << "</update>";
	newreq->content = content.str();
	addRequest(newreq);	
	//printOutMessage(content.str());	// DEBUG!
	//delete newreq;					// DEBUG!
}

void NetworkController::queryServerImage(const Node * node) {
//	if (node->getContentType() == NodeContent::TYPE_IMAGE) {
//		const ImageLeaf * imageleaf = static_cast<const ImageLeaf*>(node->getContents());
//		if (imageleaf->getRemoteURL().length() > 0) {
//			stringstream srv;
//			Request * newreq = new Request(Request::TYPE_QUERY_IMAGE, node->getID());
//			newreq->remote = imageleaf->getRemoteURL();
//			pthread_mutex_lock(&_lock);
//			_requests.push(newreq);
//			pthread_mutex_unlock(&_lock);
//			return;
//		}
//		queryServerImage(node->getID());
//	}
}

void NetworkController::queryServerImage(const string & nodeid) {
//	stringstream srv;
//	Request * newreq = new Request(Request::TYPE_QUERY_IMAGE, nodeid);
//	srv << "?action=queryimage&setid=" << nodeid;
//	newreq->req_params = srv.str();
//	pthread_mutex_lock(&_lock);
//	_requests.push(newreq);
//	pthread_mutex_unlock(&_lock);
}

void NetworkController::queryRemoteImage(const string & nodeid, const string & url, unsigned int version) {
	stringstream srv;
	Request * newreq = new Request(Request::TYPE_REMOTE_QUERY_IMAGE);
	newreq->nodeid = nodeid;
	newreq->remote = url;
	newreq->client_version = version;
	addRequest(newreq);
	return;
}

void NetworkController::setServerURL(const string & url) {
	string newurl = url;
	if (newurl.compare(0, PROTOCOL_STRING.length(), PROTOCOL_STRING))
		newurl = PROTOCOL_STRING + newurl;
	if (newurl.compare(newurl.length()- 1, 1, "/"))
		newurl = newurl + "/";
	if (newurl.compare(newurl.length()- 1 - DATABASE_APP_NAME.length(), DATABASE_APP_NAME.length(), DATABASE_APP_NAME))
		newurl = newurl + DATABASE_APP_NAME;
	// TODO: Stop ongoing transfers before changing the url
	_serverurl = newurl;
}



void NetworkController::printOutMessage(const string & buf) {
	cout << "---------- Message sent to server ----------" << endl;
	cout << buf << endl;
	cout << "--------------------------------------------" << endl;	
}

void NetworkController::printInMessage(const string & buf) {
	cout << "------- Message received from server -------" << endl;
	cout << buf;
	cout << "--------------------------------------------" << endl;	
}

int NetworkController::setup() {
	_appdata->log->write("Network thread: Initializing...");
	_appdata->log->write("Network thread: Initialized succesfully.");
	return 0;

}

int NetworkController::run() {
	_appdata->log->write("Network thread: Running...");
	int runninghandles_now;
	CURLMcode result;
	Connection * newconnection = NULL;
	while(!is_killed()) {
		// First check for new requests from the rest of the application
		while ((newconnection = checkRequests()) != NULL) {
			addConnection(newconnection);
		}
		//cout << "NetworkController::run: Performing..." << endl;
		result = curl_multi_perform(_curl, &runninghandles_now);
		//cout << "NetworkController::run: Performed." << endl;
		//while ((result = curl_multi_perform(_curl, &runninghandles_now)) == CURLM_CALL_MULTI_PERFORM);
		if (result == CURLM_OK) {
			if (runninghandles_now < getRunningHandles()) {
				// At least one transfer has finished
				CURLMsg * newmessage;
				int messages = 0;
				while ((newmessage = curl_multi_info_read(_curl, &messages)) != NULL) {
					dispatchCurlMsg(newmessage);
				}
			}
		} else if (result == CURLM_CALL_MULTI_PERFORM) {
			// This is not an error
		} else {
			cerr << "Error (" << result << ") occurred with curl multi stack!" << endl;
		}
	}
	_appdata->log->write("Network thread: Stopped.");
	return 0;
}

void NetworkController::addRequest(Request * req) {
	pthread_mutex_lock(&_lock);
	_requests.push(req);
	pthread_mutex_unlock(&_lock);
}

Connection * NetworkController::checkRequests() {
	if (_requests.empty())
		return NULL;
	pthread_mutex_lock(&_lock);
	Request * request = _requests.front();
	_requests.pop();
	pthread_mutex_unlock(&_lock);
	// Get server URL from application settings
	if (_serverurl.length() > 0 || request->remote.length() > 0) {
		//cout << "ServerURL: " << serverurl->getData() << endl;
		// Get the xml request string
		Connection * connection = NULL;
		// Try to use an existing connection
		// TODO: Check the server address too. It might have changed.
		for (connections::iterator it = _connections.begin(); !_connections.empty() && it != _connections.end(); it++) {
			if (it->second->isIdle()) {
				connection = it->second;
				break;
			}
		}
		if (!connection) {					// If we didn't find one...
			connection = new Connection;	// create a new one
			_connections[connection->getHandle()] = connection;
		}
		if (request->remote.length() > 0) {
			cout << "Request: " << request->remote << endl;
			connection->setURL(request->remote);
		} else {
			cout << "Request: " << _serverurl << " " << request->req_params << endl;
			connection->setURL(_serverurl + request->req_params);
		}
		connection->setRequest(request);

		return connection;
	}
	delete request;
	return NULL;
}

void NetworkController::dispatchCurlMsg(CURLMsg * msg) {
	if (!msg)
		return;
	switch (msg->msg) {
	case CURLMSG_DONE: {
		Connection * conn = _connections[msg->easy_handle];
		const Request * req = conn->getRequest();
		char * contenttype = NULL;
		curl_easy_getinfo(conn->getHandle(), CURLINFO_CONTENT_TYPE, &contenttype);
		long responsecode = 0;
		curl_easy_getinfo(conn->getHandle(), CURLINFO_RESPONSE_CODE, &responsecode);
		stringstream sstr;
		sstr << "NetworkController::dispatchCurlMsg: Server responsecode: " << responsecode;
		if (responsecode != 0 && contenttype != NULL)
			sstr << " Content-Type: " << contenttype << endl;
		cout << sstr.str()  << endl;
		if (responsecode == 200) {
			const string & data = conn->getData().str();
			if (req->type == Request::TYPE_REMOTE_QUERY_IMAGE) {
				if (!strncmp(contenttype, CONTENT_TYPE_IMAGE.c_str(), CONTENT_TYPE_IMAGE.length())) {
					_writer->push(new ServerQueryImageResponseEvent(req->nodeid, req->client_version, data.c_str(), data.length()));
				} 		
			} else if (req->type == Request::TYPE_IDEASILO_SERVER_REQUEST) {
				if (!strncmp(contenttype, CONTENT_TYPE_XML.c_str(), CONTENT_TYPE_XML.length())) {
					xmlDoc * doc = xmlReadMemory(data.c_str(), data.length(), "newdata.xml", NULL, 0);
					if (doc) {
						const xmlNode * root = xmlDocGetRootElement(doc);
						if (root && root->type == XML_ELEMENT_NODE) {
							if (xmlStrEqual(root->name, (xmlChar*)"queryresult")) {
								for (const xmlNode * current = root->children; current; current = current->next) {
									if (current->type == XML_ELEMENT_NODE) {
										Node * newnode = Node::parseXML(current);
										if (newnode)
											_writer->push(new ServerQueryResponseEvent(newnode));
									}
								}
							} else if (xmlStrEqual(root->name, (xmlChar*)"contextdata")) {
								for (const xmlNode * current = root->children; current; current = current->next) {
									if (current->type == XML_ELEMENT_NODE) {
										Context * newcontext = Context::parseContextData(current);
										if (newcontext) {
											_writer->push(new ContextDataEvent(newcontext));
											_writer->push(new ServerConnectionStatusChangeEvent("", true));
										}
									}
									
								}
							}
						}	
						xmlFreeDoc(doc);
					}
				}
			} else
				cout << "---- Received Data -----\n" << conn->getData().str() << endl;
		}
		removeConnection(_connections[msg->easy_handle]);
		break;
	}
	default:
		cout << "NetworkController::dispatchCurlMsg: got message " << msg->msg << endl;
		break;
	}
}

int		NetworkController::addConnection(Connection * conn) {
	conn->setIdle(false);
	curl_multi_add_handle(_curl, conn->getHandle());
	return ++_runninghandles;
}

int		NetworkController::removeConnection(Connection * conn) {
	curl_multi_remove_handle(_curl, conn->getHandle());
	conn->setIdle();
	return --_runninghandles;
}

GdkPixbuf * NetworkController::loadImage(const stringstream & stream) {
	//cout << "NetworkController::loadImage called" << endl;
	string tempfile_basename = "/tmp/__ideasilo_remote_image_temp_";
	int index = 0;
	struct stat fileinfo;
	string filename;
	for (bool fail = true; fail; index++) {
		stringstream s;
		s << tempfile_basename << index;
		filename = s.str();
		if (stat(filename.c_str(), &fileinfo))
			fail = false;
	}
	//cout << "NetworkController::loadImage: tempfilename: " << filename << endl;
	FILE * tempfile = fopen(filename.c_str(), "w");
	if (!tempfile) {
		cerr << "NetworkController::loadImage: Error! Could not open tempfile" << endl;
		return NULL;
	}
	fwrite(stream.str().c_str(), stream.str().length(), sizeof(char), tempfile);
	fclose(tempfile);
	GError *error = NULL;
	GdkPixbuf * newimage = gdk_pixbuf_new_from_file(filename.c_str(), &error);
	if (!newimage)
		cerr << "NetworkController::loadImage: Warning! Failed to open received image." << endl;
	remove(filename.c_str());
	return newimage;
}

bool NetworkController::raiseTestResponse_v2(const string & ID) {
	//cout << "In NetworkController::raiseTestResponse_v2: " << ID << endl;
	stringstream xml;
	if (!ID.compare("IdeasiloDemo-00001")) {
		xml << "<branch ID=\"IdeasiloDemo-00001\" v=\"1\" label=\"Blue pants, S\">" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00001/1\" v=\"1\" label=\"Item\">Blue pants</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00001/2\" v=\"1\" label=\"Size\">S</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00001/3\" v=\"1\" label=\"Color\">Blue</text>" << endl;
		xml << "  <image ID=\"IdeasiloDemo-00001/4\" v=\"1\" label=\"Image\" format=\"jpg\"><uri>http://www.ee.oulu.fi/~mipoloja/ideasilodemo/images/Blue_pants_S.jpg</uri></image>" << endl;
		//xml << getTestImageXML1();
		//xml << "  <binary ID=\"IdeasiloDemo-00001/5\" v=\"1\" label=\"Advertisement\"><![CDATA[VmVyeSBuaWNlIHBhbnRzIQ==]]></binary>" << endl;
		xml << "  <branch ID=\"IdeasiloDemo-00001/6\" v=\"1\" label=\"Washing info\">" << endl;
		xml << "    <text ID=\"IdeasiloDemo-00001/6/1\" v=\"1\" label=\"Temperature\">40</text>" << endl;
		xml << "    <text ID=\"IdeasiloDemo-00001/6/2\" v=\"1\" label=\"Notes\">Do not bleach, iron or tumble</text>" << endl;
		xml << "  </branch>" << endl;
		xml << "</branch>" << endl;
	} 
//	if (!ID.compare("IdeasiloDemo-00001")) {
//		xml << "<branch ID=\"IdeasiloDemo-00001\" v=\"1\" label=\"Polojärvi, Mikko\">" << endl;
//		xml << "  <text ID=\"IdeasiloDemo-00001/1\" v=\"1\" label=\"Family name\">Polojärvi</text>" << endl;
//		xml << "  <text ID=\"IdeasiloDemo-00001/2\" v=\"1\" label=\"First name\">Mikko</text>" << endl;
//		xml << "  <text ID=\"IdeasiloDemo-00001/3\" v=\"1\" label=\"Middle name\">Ilmari</text>" << endl;
//		xml << "  <text ID=\"IdeasiloDemo-00001/4\" v=\"1\" label=\"Gender\">Male</text>" << endl;
//		xml << "  <text ID=\"IdeasiloDemo-00001/5\" v=\"1\" label=\"Occupation\">Information engineering student</text>" << endl;
//		xml << "  <image ID=\"IdeasiloDemo-00001/6\" v=\"1\" label=\"Picture\" format=\"jpg\"><uri>http://www.ee.oulu.fi/~mipoloja/ideasilodemo/images/Mikon_naama.jpg</uri></image>" << endl;
//		xml << "  <branch ID=\"IdeasiloDemo-00001/7\" v=\"1\" label=\"Personal history\">" << endl;
//		xml << "    <text ID=\"IdeasiloDemo-00001/7/1\" v=\"1\" label=\"Birthdate\">5.10.1981</text>" << endl;
//		xml << "    <text ID=\"IdeasiloDemo-00001/7/2\" v=\"1\" label=\"Birthplace\">Oulu</text>" << endl;
//		xml << "  </branch>" << endl;
//		xml << "  <branch ID=\"IdeasiloDemo-00001/8\" v=\"1\" label=\"Publications\">" << endl;
//		xml << "    <text ID=\"IdeasiloDemo-00001/8/1\" v=\"1\" label=\"Master's thesis\">Application platform for utilizing RFID information</text>" << endl;
//		xml << "    <text ID=\"IdeasiloDemo-00001/8/2\" v=\"1\" label=\"Doctoral thesis\">Facilitating password management with RFID tags</text>" << endl;
//		xml << "    <text ID=\"IdeasiloDemo-00001/8/3\" v=\"1\" label=\"Nobel prize\">Utilizing RFID to detect cancer</text>" << endl;
//		xml << "  </branch>" << endl;
//		xml << "  <node ID=\"IdeasiloDemo-00009\" v=\"1\" label=\"Favourite shirt\"/>" << endl;
//		xml << "</branch>" << endl;
	else if (!ID.compare("IdeasiloDemo-00002")) {
		xml << "<branch ID=\"IdeasiloDemo-00002\" v=\"1\" label=\"Blue pants, M\">" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00002/1\" v=\"1\" label=\"Item\">Blue pants</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00002/2\" v=\"1\" label=\"Size\">M</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00002/3\" v=\"1\" label=\"Color\">Blue</text>" << endl;
		xml << "  <image ID=\"IdeasiloDemo-00002/4\" v=\"1\" label=\"Image\" format=\"jpg\"><uri>http://www.ee.oulu.fi/~mipoloja/ideasilodemo/images/Blue_pants_M.jpg</uri></image>" << endl;
		xml << "</branch>" << endl;
	} else if (!ID.compare("IdeasiloDemo-00003")) {
		xml << "<branch ID=\"IdeasiloDemo-00003\" v=\"1\" label=\"Blue pants, L\">" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00003/1\" v=\"1\" label=\"Item\">Blue pants</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00003/2\" v=\"1\" label=\"Size\">L</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00003/3\" v=\"1\" label=\"Color\">Blue</text>" << endl;
		xml << "  <image ID=\"IdeasiloDemo-00003/4\" v=\"1\" label=\"Image\" format=\"jpg\"><uri>http://www.ee.oulu.fi/~mipoloja/ideasilodemo/images/Blue_pants_L.jpg</uri></image>" << endl;
		xml << "</branch>" << endl;
	} else if (!ID.compare("IdeasiloDemo-00004")) {
		xml << "<branch ID=\"IdeasiloDemo-00004\" v=\"1\" label=\"Blue pants, XL\">" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00004/1\" v=\"1\" label=\"Item\">Blue pants</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00004/2\" v=\"1\" label=\"Size\">XL</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00004/3\" v=\"1\" label=\"Color\">Blue</text>" << endl;
		xml << "  <image ID=\"IdeasiloDemo-00004/4\" v=\"1\" label=\"Image\" format=\"jpg\"><uri>http://www.ee.oulu.fi/~mipoloja/ideasilodemo/images/Blue_pants_XL.jpg</uri></image>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00004/5\" v=\"1\" label=\"Note\">Too big for most people</text>" << endl;
		xml << "</branch>" << endl;
	} else if (!ID.compare("IdeasiloDemo-00005")) {
		xml << "<branch ID=\"IdeasiloDemo-00005\" v=\"1\" label=\"Blue shirt, S\">" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00005/1\" v=\"1\" label=\"Item\">Blue shirt</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00005/2\" v=\"1\" label=\"Size\">S</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00005/3\" v=\"1\" label=\"Color\">Blue</text>" << endl;
		xml << "  <image ID=\"IdeasiloDemo-00005/4\" v=\"1\" label=\"Image\" format=\"jpg\"><uri>http://www.ee.oulu.fi/~mipoloja/ideasilodemo/images/Blue_shirt_S.jpg</uri></image>" << endl;
		xml << "</branch>" << endl;
	} else if (!ID.compare("IdeasiloDemo-00006")) {
		xml << "<branch ID=\"IdeasiloDemo-00006\" v=\"1\" label=\"Blue shirt, M\">" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00006/1\" v=\"1\" label=\"Item\">Blue shirt</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00006/2\" v=\"1\" label=\"Size\">M</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00006/3\" v=\"1\" label=\"Color\">Blue</text>" << endl;
		xml << "  <image ID=\"IdeasiloDemo-00006/4\" v=\"1\" label=\"Image\" format=\"jpg\"><uri>http://www.ee.oulu.fi/~mipoloja/ideasilodemo/images/Blue_shirt_M.jpg</uri></image>" << endl;
		xml << "</branch>" << endl;
	} else if (!ID.compare("IdeasiloDemo-00007")) {
		xml << "<branch ID=\"IdeasiloDemo-00007\" v=\"1\" label=\"Blue shirt, L\">" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00007/1\" v=\"1\" label=\"Item\">Blue shirt</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00007/2\" v=\"1\" label=\"Size\">L</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00007/3\" v=\"1\" label=\"Color\">Blue</text>" << endl;
		xml << "  <image ID=\"IdeasiloDemo-00007/4\" v=\"1\" label=\"Image\" format=\"jpg\"><uri>http://www.ee.oulu.fi/~mipoloja/ideasilodemo/images/Blue_shirt_L.jpg</uri></image>" << endl;
		xml << "</branch>" << endl;
	} else if (!ID.compare("IdeasiloDemo-00008")) {
		xml << "<branch ID=\"IdeasiloDemo-00008\" v=\"1\" label=\"Blue shirt, XL\">" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00008/1\" v=\"1\" label=\"Item\">Blue shirt</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00008/2\" v=\"1\" label=\"Size\">XL</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00008/3\" v=\"1\" label=\"Color\">Blue</text>" << endl;
		xml << "  <image ID=\"IdeasiloDemo-00008/4\" v=\"1\" label=\"Image\" format=\"jpg\"><uri>http://www.ee.oulu.fi/~mipoloja/ideasilodemo/images/Blue_shirt_XL.jpg</uri></image>" << endl;
		xml << "</branch>" << endl;
	} else if (!ID.compare("IdeasiloDemo-00009")) {
		xml << "<branch ID=\"IdeasiloDemo-00009\" v=\"1\" label=\"Morning coat, S\">" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00009/1\" v=\"1\" label=\"Item\">Morning coat</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00009/2\" v=\"1\" label=\"Size\">S</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00009/3\" v=\"1\" label=\"Color\">Red</text>" << endl;
		xml << "  <image ID=\"IdeasiloDemo-00009/4\" v=\"1\" label=\"Image\" format=\"jpg\"><uri>http://www.ee.oulu.fi/~mipoloja/ideasilodemo/images/Bathrobe_S_red.jpg</uri></image>" << endl;
		xml << "</branch>" << endl;
	} else if (!ID.compare("IdeasiloDemo-00010")) {
		xml << "<branch ID=\"IdeasiloDemo-00010\" v=\"1\" label=\"Morning coat, M\">" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00010/1\" v=\"1\" label=\"Item\">Morning coat</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00010/2\" v=\"1\" label=\"Size\">M</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00010/3\" v=\"1\" label=\"Color\">Light blue</text>" << endl;
		xml << "  <image ID=\"IdeasiloDemo-00010/4\" v=\"1\" label=\"Image\" format=\"jpg\"><uri>http://www.ee.oulu.fi/~mipoloja/ideasilodemo/images/Bathrobe_M_lblue.jpg</uri></image>" << endl;
		xml << "</branch>" << endl;
	} else if (!ID.compare("IdeasiloDemo-00011")) {
		xml << "<branch ID=\"IdeasiloDemo-00011\" v=\"1\" label=\"Morning coat, L\">" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00011/1\" v=\"1\" label=\"Item\">Morning coat</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00011/2\" v=\"1\" label=\"Size\">L</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00011/3\" v=\"1\" label=\"Color\">Blue</text>" << endl;
		xml << "  <image ID=\"IdeasiloDemo-00011/4\" v=\"1\" label=\"Image\" format=\"jpg\"><uri>http://www.ee.oulu.fi/~mipoloja/ideasilodemo/images/Bathrobe_L_blue.jpg</uri></image>" << endl;
		xml << "</branch>" << endl;
	} else if (!ID.compare("IdeasiloDemo-00012")) {
		xml << "<branch ID=\"IdeasiloDemo-00012\" v=\"1\" label=\"Morning coat, XL\">" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00012/1\" v=\"1\" label=\"Item\">Morning coat</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00012/2\" v=\"1\" label=\"Size\">XL</text>" << endl;
		xml << "  <text ID=\"IdeasiloDemo-00012/3\" v=\"1\" label=\"Color\">Brown</text>" << endl;
		xml << "  <image ID=\"IdeasiloDemo-00012/4\" v=\"1\" label=\"Image\" format=\"jpg\"><uri>http://www.ee.oulu.fi/~mipoloja/ideasilodemo/images/Bathrobe_XL_brown.jpg</uri></image>" << endl;
		xml << "</branch>" << endl;
	} else
		return false;
	Node * newnode = Node::parseXML(xml.str());
	ServerQueryResponseEvent * ev = new ServerQueryResponseEvent(newnode);
	_writer->push(ev);
	return true;
	//printInMessage(xml.str());	
	//cout << "Leaving NetworkController::raiseTestResponse_v2: " << ID << endl;
}


//void NetworkController::raiseTestResponse(const string & ID) {
//	stringstream xml;
//	if (!ID.compare("00001")) {
//		xml << "<dataset ID=\"00001\"><entry name=\"Set name\" ID=\"1\" data=\"Blue pants, S\"/><entry name=\"Item\" ID=\"2\" data=\"Blue pants\"/><entry name=\"Size\" ID=\"3\" data=\"S\"/><entry name=\"Image\" ID=\"4\" type=\"text\" data=\"http://www.ee.oulu.fi/~mipoloja/ideasilo/images/Blue_pants_S.jpg\"/></dataset>";
//	} else if (!ID.compare("00002")) {
//		xml << "<dataset ID=\"00002\"><entry name=\"Set name\" ID=\"1\" data=\"Blue pants, M\"/><entry name=\"Item\" ID=\"2\" data=\"Blue pants\"/><entry name=\"Size\" ID=\"3\" data=\"M\"/><entry name=\"Image\" ID=\"4\" type=\"image\" data=\"http://www.ee.oulu.fi/~mipoloja/ideasilo/images/Blue_pants_M.jpg\"/></dataset>";
//	} else if (!ID.compare("00003")) {
//		xml << "<dataset ID=\"00003\"><entry name=\"Set name\" ID=\"1\" data=\"Blue pants, L\"/><entry name=\"Item\" ID=\"2\" data=\"Blue pants\"/><entry name=\"Size\" ID=\"3\" data=\"L\"/><entry name=\"Image\" ID=\"4\" type=\"image\" data=\"http://www.ee.oulu.fi/~mipoloja/ideasilo/images/Blue_pants_L.jpg\"/></dataset>";
//	} else if (!ID.compare("00004")) {
//		xml << "<dataset ID=\"00004\"><entry name=\"Set name\" ID=\"1\" data=\"Blue pants, XL\"/><entry name=\"Item\" ID=\"2\" data=\"Blue pants\"/><entry name=\"Size\" ID=\"3\" data=\"XL\"/><entry name=\"Image\" ID=\"4\" type=\"image\" data=\"http://www.ee.oulu.fi/~mipoloja/ideasilo/images/Blue_pants_XL.jpg\"/></dataset>";
//	} else if (!ID.compare("00005")) {
//		xml << "<dataset ID=\"00005\"><entry name=\"Set name\" ID=\"1\" data=\"Blue shirt, S\"/><entry name=\"Item\" ID=\"2\" data=\"Blue shirt\"/><entry name=\"Size\" ID=\"3\" data=\"S\"/><entry name=\"Image\" ID=\"4\" type=\"image\" data=\"http://www.ee.oulu.fi/~mipoloja/ideasilo/images/Blue_shirt_S.jpg\"/></dataset>";
//	} else if (!ID.compare("00006")) {
//		xml << "<dataset ID=\"00006\"><entry name=\"Set name\" ID=\"1\" data=\"Blue shirt, M\"/><entry name=\"Item\" ID=\"2\" data=\"Blue shirt\"/><entry name=\"Size\" ID=\"3\" data=\"M\"/><entry name=\"Image\" ID=\"4\" type=\"image\" data=\"http://www.ee.oulu.fi/~mipoloja/ideasilo/images/Blue_shirt_M.jpg\"/></dataset>";
//	} else if (!ID.compare("00007")) {
//		xml << "<dataset ID=\"00007\"><entry name=\"Set name\" ID=\"1\" data=\"Blue shirt, L\"/><entry name=\"Item\" ID=\"2\" data=\"Blue shirt\"/><entry name=\"Size\" ID=\"3\" data=\"L\"/><entry name=\"Image\" ID=\"4\" type=\"image\" data=\"http://www.ee.oulu.fi/~mipoloja/ideasilo/images/Blue_shirt_L.jpg\"/></dataset>";
//	} else if (!ID.compare("00008")) {
//		xml << "<dataset ID=\"00008\"><entry name=\"Set name\" ID=\"1\" data=\"Blue shirt, XL\"/><entry name=\"Item\" ID=\"2\" data=\"Blue shirt\"/><entry name=\"Size\" ID=\"3\" data=\"XL\"/><entry name=\"Image\" ID=\"4\" type=\"image\" data=\"http://www.ee.oulu.fi/~mipoloja/ideasilo/images/Blue_shirt_XL.jpg\"/></dataset>";
//	} else if (!ID.compare("00009")) {
//		xml << "<dataset ID=\"00009\"><entry name=\"Set name\" ID=\"1\" data=\"Morning coat, red, S\"/><entry name=\"Item\" ID=\"2\" data=\"Morning coat, red\"/><entry name=\"Size\" ID=\"3\" data=\"S\"/><entry name=\"Color\" ID=\"4\" data=\"Red\"/><entry name=\"Image\" ID=\"5\" type=\"image\" data=\"http://www.ee.oulu.fi/~mipoloja/ideasilo/images/Bathrobe_S_red.jpg\"/></dataset>";
//	} else if (!ID.compare("00010")) {
//		xml << "<dataset ID=\"00010\"><entry name=\"Set name\" ID=\"1\" data=\"Morning coat, light blue, M\"/><entry name=\"Item\" ID=\"2\" data=\"Morning coat, light blue\"/><entry name=\"Size\" ID=\"3\" data=\"M\"/><entry name=\"Color\" ID=\"4\" data=\"Light blue\"/><entry name=\"Image\" ID=\"5\" type=\"image\" data=\"http://www.ee.oulu.fi/~mipoloja/ideasilo/images/Bathrobe_M_lblue.jpg\"/></dataset>";
//	} else if (!ID.compare("00011")) {
//		xml << "<dataset ID=\"00011\"><entry name=\"Set name\" ID=\"1\" data=\"Morning coat, blue, L\"/><entry name=\"Item\" ID=\"2\" data=\"Morning coat, blue\"/><entry name=\"Size\" ID=\"3\" data=\"L\"/><entry name=\"Color\" ID=\"4\" data=\"Blue\"/><entry name=\"Image\" ID=\"5\" type=\"image\" data=\"http://www.ee.oulu.fi/~mipoloja/ideasilo/images/Bathrobe_L_blue.jpg\"/></dataset>";
//	} else if (!ID.compare("00012")) {
//		xml << "<dataset ID=\"00012\"><entry name=\"Set name\" ID=\"1\" data=\"Morning coat, brown, XL\"/><entry name=\"Item\" ID=\"2\" data=\"Morning coat, brown\"/><entry name=\"Size\" ID=\"3\" data=\"XL\"/><entry name=\"Color\" ID=\"4\" data=\"Brown\"/><entry name=\"Image\" ID=\"5\" type=\"image\" data=\"http://www.ee.oulu.fi/~mipoloja/ideasilo/images/Bathrobe_XL_brown.jpg\"/></dataset>";
//	}
//	DataSet * newset = DataSet::parseXML(xml.str(), SERVER);
//	ServerQueryResponseEvent * ev = new ServerQueryResponseEvent(newset);
//	_writer->push(ev);
//	//printInMessage(xml.str());
//}

string NetworkController::getTestImageXML1() {
	FILE * file = fopen((string(_appdata->datapath) + "TestImage1.xml").c_str(), "r");
	if (!file)
		return "";
	fseek(file, 0, SEEK_END);
	int size = ftell(file);
	fseek(file, 0, SEEK_SET);
	char * buf = new char[size];
	fread(buf, sizeof(char), size, file);
	string str = buf;
	delete [] buf;
	fclose(file);
	//cout<< "STRING:" << str << endl;
	return str;
		
}
