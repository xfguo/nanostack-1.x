#ifndef NETWORKEVENT_H_
#define NETWORKEVENT_H_

#include "event/Event.h"
#include "dataformat/Node.h"
#include <gdk-pixbuf/gdk-pixbuf.h>

// An event raised when there is a response to a query made to the server
class ServerQueryResponseEvent : public Event
{
public:
	ServerQueryResponseEvent(Node * newnode):_node(newnode) {}
	virtual ~ServerQueryResponseEvent() { delete _node; }
	
	virtual bool process(ApplicationContext & context);

private:
	Node * _node;
};

// An event to update the server with some new data
class ServerUpdateNodeEvent : public Event
{
public:
	ServerUpdateNodeEvent(Node * newnode):_node(newnode) {}
	~ServerUpdateNodeEvent() { delete _node; }
	
	virtual bool process(ApplicationContext & context);
	
private:
	Node * _node;
	
};

// An event to query for a single image on the database
class ServerQueryImageEvent : public Event
{
public:
	ServerQueryImageEvent(const string & nodeid):_nodeid(nodeid){}
	~ServerQueryImageEvent() { }
	
	virtual bool process(ApplicationContext & context);
	
private:
	string 				_nodeid;
};

class ServerQueryImageResponseEvent : public Event 
{	
public:
	ServerQueryImageResponseEvent(const string & nodeid, unsigned int version, const char * image, size_t size):
		_nodeid(nodeid),_version(version), _imagesize(size) {
		if (image) {
			_image = (char*)malloc(sizeof(char)*_imagesize);
			memcpy(_image, image, _imagesize);
		} else _image = NULL;
	}
	
	~ServerQueryImageResponseEvent() { 
		if (_image) free (_image);
	}
	
	virtual bool process(ApplicationContext & context);
	
private:
	string 				_nodeid;
	unsigned int		_version;
	char *				_image;
	size_t				_imagesize;
};

class ServerSendOrderFormEvent : public Event
{
public:
	ServerSendOrderFormEvent(const string & orderer, const string & supplier, const string & orderlist):
		_orderer(orderer), _supplier(supplier), _orderlist(orderlist) {}
	~ServerSendOrderFormEvent() { }
	
	virtual bool process(ApplicationContext & context);
	
private:
	string 				_orderer;
	string				_supplier;
	string				_orderlist;
};

// An event to query for a single image on the database
class RemoteQueryImageEvent : public Event
{
public:
	RemoteQueryImageEvent(const string & nodeid, const string & url, unsigned int version):
		_nodeid(nodeid), _url(url), _version(version) {}
	~RemoteQueryImageEvent() { }
	
	virtual bool process(ApplicationContext & context);
	
private:
	string 				_nodeid;
	string				_url;
	unsigned int		_version;
};

class ServerConnectionStatusChangeEvent : public Event
{
public:
	ServerConnectionStatusChangeEvent(const string & newserverurl, bool newstatus = false):
		_status(newstatus), _serverurl(newserverurl) {}
	~ServerConnectionStatusChangeEvent() { }
	
	virtual bool process(ApplicationContext & context);
	
private:
	bool				_status;
	string 				_serverurl;
	
};

#endif /*NETWORKEVENT_H_*/
