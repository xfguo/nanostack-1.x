#include "EventMonitor.h"

#include <signal.h>		// For installing the signal handlers
#include <iostream>
#include <fstream>
#include <errno.h>
#include <sys/stat.h>
#include <sys/wait.h>

#include "event/ApplicationEvent.h"
#include "rfid/RFIDEvent.h"
#include "network/NetworkEvent.h"
#include "util/SettingHandler.h"

const char * UIFILENAME = "ideasiloGUI.glade";

const char * NROUTE_EXEC_FILE = "nRouted";
const char * NROUTE_LOCK_FILE_BASENAME = "/tmp/.nRouted-lock-";
const char * NROUTE_LOCK_FILE_DIR = "/tmp";

const char * SETTING_DEVFILE = "Transmitter devfile";
const string SETTING_SERVER_URL = "Server URL";

const char * NROUTE_STATUS_NOT_RUNNING = "nRouted is not running properly";
const char * NROUTE_STATUS_MISSING = "Could not find nRouted";
const char * NROUTE_STATUS_DEVFILE_NOT_SET = "Transmitter device file not set";
const char * NROUTE_STATUS_LOCKFILE_REMOVE_ERROR = "Could not remove lock from nRouted";
const char * NROUTE_STATUS_RADIO_NOT_DETECTED = "Could not detect radio module";
const char * NROUTE_STATUS_NOT_CONFIGURED = "nRouted not configured properly";
const char * NROUTE_STATUS_LAUNCH_ERROR = "Could not launch nRouted";
const char * NROUTE_STATUS_SPAWN_PROCESS_ERROR = "Could not create a new process for nRouted";

EventBuffer::Writer * EventMonitor::_writer = NULL;
static bool			_child_termination_signaled = false;

EventMonitor::EventMonitor(AppData * appdata):
_appdata(appdata),
_evreader(appdata->evbuf->requestReader()),
_gui(NULL),
_net(NULL),
_rfid(NULL),
_nroute_pid(-1),
_nroute_status(NROUTE_STOPPED)
{
	_writer = NULL;
}

EventMonitor::~EventMonitor()
{
	nRouteStop();
	delete _gui;
	delete _net;
	delete _rfid;
	delete _appsettings;
}


int EventMonitor::setup() {
	int result;

	if (!_writer)
		_writer = _appdata->evbuf->requestWriter();
	
	// Check the ui file can be found & opened
	_appdata->setUIFilename(UIFILENAME);
	ifstream uifilestream;
	uifilestream.open(_appdata->uifilename.c_str(), ifstream::in);
	if(!uifilestream.is_open()) {
		string errmsg = string("Cannot find UI definition file in '") + _appdata->datapath + "'"; 
		_appdata->log->write(string("EventMonitor: ") + errmsg);
		cerr << errmsg << endl; 
		return ENOENT;
	} else
		uifilestream.close();
	
	// Set up a handler for child termination signal
	if((signal(SIGCHLD, (sighandler_t)sig_child_terminated)) == SIG_ERR) {
    	cerr << "Warning! Could not install sigchld signal handler" << endl;
    }
	
	// Initialize application settings
	_appsettings = new SettingHandler(string(_appdata->userdatapath) + SETTINGSFILENAME);
	if (_appsettings->load())
		_appdata->log->write("Application settings loaded successfully.");
	else
		_appdata->log->write("Could not load application settings, generating new.");
	
	// Initialize the threads
	_gui = new GUI(_appdata, _appsettings);
	_net = new NetworkController(_appdata, _appdata->evbuf->requestWriter(), *_appsettings);
	_rfid = new RFIDReader(_appdata, _appdata->evbuf->requestWriter(), *_appsettings);
	
	if ((result = _gui->init()))
		return result;
	if ((result = _net->init()))
		return result;
	if ((result = _rfid->init()))
		return result;
	
	// Try to connect to the server defined in the settings file
	const Setting * serverurl = _appsettings->find(SETTING_SERVER_URL);
	if (serverurl)
		_writer->push(new ServerConnectionStatusChangeEvent(serverurl->getData(), false));
	else
		_writer->push(new ServerConnectionStatusChangeEvent("", false));
	_writer->push(new ReaderConnectionStatusChangeEvent(nRouteAvailable(), false, false, NROUTE_STATUS_NOT_RUNNING));
		
	
	//_appdata->log->write("Raising debug messages...");
	//_rfid->raiseTestMsg_v2("IdeasiloDemo-00001");
	//_rfid->raiseTestMsg_v2("IdeasiloDemo-00002");
	
	_appdata->log->write("Eventmonitor: Initialized succesfully.");
	return 0;
}

int EventMonitor::run() {
	_appdata->log->write("Eventmonitor: Running...");
	int result;
	
	if ((result = _gui->start(NULL))) {
		cerr << startErrMsg(result, "GUI") << endl;
		return result;
	}
	if ((result = _rfid->start(NULL))) {
		cerr << startErrMsg(result, "RFID") << endl;
		return result;
	}
	if ((result = _net->start(NULL))) {
		cerr << startErrMsg(result, "Network") << endl;
		return result;
	}

	ApplicationContext context(*this, *_gui, *_net, *_rfid);
	while (!is_killed() && !_gui->is_killed()) {
		if (_child_termination_signaled) {
			//cout << "Resolving child termination..." << endl;
			_child_termination_signaled = false;
			waitpid(_nroute_pid, NULL, WNOHANG);
			_nroute_pid = -1;
			_nroute_status = NROUTE_STOPPED;
			//cout << "Resolved child termination." << endl;
		}
		if (_gui->is_alive()) {
			Event * ev = _evreader->pop(TIMEOUT);
			if (ev) {
				ev->process(context);
				delete ev;
			}
		}		
	}
	_appdata->log->write("Eventmonitor: Shutting down RFID and network threads...");
	_rfid->kill(getExitcode());
	_net->kill(0);
	_rfid->join(NULL);
	_net->join(NULL);	
	_appdata->log->write("Eventmonitor: Shutting down GUI thread...");
	_gui->kill(getExitcode());	
	_gui->join(NULL);
	_appdata->log->write("Eventmonitor: Stopped.");
	return getExitcode();
}

void EventMonitor::requestSound(const string & soundid) {
	if (_rfid)
		_rfid->requestSound(soundid);
}

bool EventMonitor::nRouteAvailable(const char **message) {
	string nroute_devfile = "";
	const Setting * devfilesetting = _appsettings->find(SETTING_DEVFILE);
	if (devfilesetting) {
		nroute_devfile = devfilesetting->getData(); 
	} else {
		if (message) *message = NROUTE_STATUS_DEVFILE_NOT_SET;
		return false;
	}
	string nroute_devfile_path = string("/dev/") + nroute_devfile;
	string nroute_lockfile = string(NROUTE_LOCK_FILE_BASENAME) + nroute_devfile;
	string nroute_path = _appdata->datapath;
	string nroute_file = nroute_path + NROUTE_EXEC_FILE;
	struct stat fileinfo;
	
	// First check if nRoute is even there
	//cout << "Searching nRoute from: " << nroute_file << endl;
	if (stat(nroute_file.c_str(),&fileinfo)) {
		if (message) *message = NROUTE_STATUS_MISSING;
		return false;
	}
	// Then check whether the usb device file is there
	if (stat(nroute_devfile_path.c_str(), &fileinfo)) {
		//cerr << "Device " << devfile << " cannot be accessed." << endl;
		if (message) *message = NROUTE_STATUS_RADIO_NOT_DETECTED;
		return false;
	}
	// Then check whether the lock file is already there
	if (!stat(nroute_lockfile.c_str(), &fileinfo)) {
		// If it is, try to remove it. It serves absolutely no purpose
		if (remove(nroute_lockfile.c_str())) {
			if (message) *message = NROUTE_STATUS_LOCKFILE_REMOVE_ERROR;
			return false;
		}
	}	
	return true;
}

bool EventMonitor::nRouteStart() {
	string nroute_path = _appdata->datapath;
	if (_nroute_status == NROUTE_STOPPED) {
		const char * msg = NULL;
		if (!nRouteAvailable(&msg)) {
			cout << "EventMonitor::nRouteStart: nRouted was not available with message: " << msg << endl;
			if (_writer) _writer->push(new ReaderConnectionStatusChangeEvent(false, false, false, msg));
		} else {
			_nroute_status = NROUTE_AVAILABLE; 
			cout << "EventMonitor::nRouteStart: nRouted was available." << endl;
		}
	}
	if (_nroute_status == NROUTE_AVAILABLE) {	
		// Start nRouted
		cout << "Starting nRouted..." << endl;
		if ((_nroute_pid = fork()) == 0) {
			chdir(nroute_path.c_str());
			//char *argv[] = {"-d", NULL};
			char *argv[] = {"", NULL};
			execv(NROUTE_EXEC_FILE, argv);
			cerr << "Warning! Could not execute nRouted" << endl;
			// a succesfull call to exec doesn't return, therefore at this point there must be an error
			exit(1);
			//_nrouted_statusmsg = NROUTED_STATUS_LAUNCH_ERROR;
			//return false;
		} else if (_nroute_pid < 0) {
			// There was a process spawning problem
			cerr << "Warning! Could not spawn process for nRouted" << endl;
			if (_writer) _writer->push(new ReaderConnectionStatusChangeEvent(true, false, false, NROUTE_STATUS_SPAWN_PROCESS_ERROR));
		} else {
			if (_writer) _writer->push(new ReaderConnectionStatusChangeEvent(true, true, false, NROUTE_STATUS_NOT_CONFIGURED));
			_nroute_status = NROUTE_RUNNING;
		}
	}
	if (_nroute_status == NROUTE_RUNNING)
		return true;
	else
		return false;
}


void EventMonitor::nRouteStop() {
	if (_nroute_pid > 0) {
		cout << "Stopping nRouted..." << endl;
		::kill(_nroute_pid, SIGKILL);
		waitpid(_nroute_pid, NULL, WNOHANG);
	} else {
		cout << "Stopping nRouted... but it was already stopped" << endl;
		
	}
	if (_writer) {
		_writer->push(new ReaderConnectionStatusChangeEvent(nRouteAvailable(), false, false, NROUTE_STATUS_NOT_RUNNING));
	}
	_nroute_status = NROUTE_STOPPED;
	_nroute_pid = -1;
}

void EventMonitor::sig_child_terminated() {
	//cout << "--! EventMonitor::sig_child_terminated" << endl;
	//cout << "--> EventMonitor::sig_child_terminated" << endl;
	_child_termination_signaled = true;
	//cout << "<-- EventMonitor::sig_child_terminated" << endl;
}
