#ifndef MAIN_H_
#define MAIN_H_

#include <iostream>
#include <string>
#include <sstream>


using std::cout;
using std::cerr;
using std::endl;
using std::string;
using std::stringstream;

#endif
