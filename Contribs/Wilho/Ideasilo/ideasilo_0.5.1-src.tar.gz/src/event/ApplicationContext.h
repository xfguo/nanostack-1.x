#ifndef APPLICATIONCONTEXT_H_
#define APPLICATIONCONTEXT_H_
class NetworkController;
class GUI;
class EventMonitor;
class RFIDReader;

struct ApplicationContext {
	ApplicationContext(EventMonitor & newevmon, GUI & newgui, NetworkController & newnet, RFIDReader & newrfid): 
		evmon(newevmon), net(newnet), gui(newgui), rfid(newrfid) {} 
	
	EventMonitor & evmon;
	NetworkController & net;
	GUI & gui;
	RFIDReader & rfid;

};

#endif /*APPLICATIONCONTEXT_H_*/
