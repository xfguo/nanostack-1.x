#include "EventBuffer.h"
#include <time.h>
#include <errno.h>
#include <iostream>

#include "Event.h"

EventBuffer::EventBuffer(int readers, int writers):
_READERS_AVAILABLE(readers),
_WRITERS_AVAILABLE(writers),
_writersInUse(0),
_readersInUse(0)
{
	pthread_mutex_init(&_lock,NULL);
	pthread_mutex_init(&_readerRequestLock,NULL);
	pthread_mutex_init(&_writerRequestLock,NULL);
	pthread_cond_init(&_emptyCondition,NULL);
	_reservedReaders = new Reader*[_READERS_AVAILABLE];
	_reservedWriters = new Writer*[_WRITERS_AVAILABLE];
	int n;
	for (n = 0; n < _READERS_AVAILABLE; ++n)
		_reservedReaders[n] = NULL;
	for (n = 0; n < _WRITERS_AVAILABLE; ++n)
		_reservedWriters[n] = NULL;
}

EventBuffer::~EventBuffer()
{
	int n;
	for (n = 0; n < _READERS_AVAILABLE; ++n)
		delete _reservedReaders[n];
	for (n = 0; n < _WRITERS_AVAILABLE; ++n)
		delete _reservedWriters[n];
	delete [] _reservedReaders;
	delete [] _reservedWriters;
	while (!_queue.empty()) {
		Event * e = _queue.front();
		delete e;
		_queue.pop();
	}
		
}

EventBuffer::Reader * EventBuffer::requestReader() {
	pthread_mutex_lock( &_readerRequestLock );
	EventBuffer::Reader * newReader = NULL;
	if (_readersInUse < _READERS_AVAILABLE) {
		newReader = new EventBuffer::Reader(this);
		int n;
		for (n = 0; n < _READERS_AVAILABLE; ++n) {
			if (_reservedReaders[n] == NULL) {
				_reservedReaders[n] = newReader;
				newReader->ID = n;
				break;
			}
		}
		if (n >= _READERS_AVAILABLE) {	// If the code works properly, this piece of code should never be executed
			delete newReader;
			newReader = NULL;	
		} else {
			++_readersInUse;
		}
	}
	pthread_mutex_unlock( &_readerRequestLock );
	return newReader;
}

EventBuffer::Writer * EventBuffer::requestWriter() {
	//cout << " In EventBuffer::requestWriter: " << _writersInUse << endl;
	pthread_mutex_lock( &_writerRequestLock );
	EventBuffer::Writer * newWriter = NULL;
	if (_writersInUse < _WRITERS_AVAILABLE) {
		newWriter = new EventBuffer::Writer(this);
		int n;
		for (n = 0; n < _WRITERS_AVAILABLE; ++n) {
			if (_reservedWriters[n] == NULL) {
				_reservedWriters[n] = newWriter;
				newWriter->ID = n;
				break;
			}
		}
		if (n >= _WRITERS_AVAILABLE) {	// If the code works properly, this piece of code should never be executed
			delete newWriter;
			newWriter = NULL;	
		} else {
			++_writersInUse;
		}
	}
	pthread_mutex_unlock( &_writerRequestLock );
	return newWriter;
}

Event* EventBuffer::Reader::pop() {
	pthread_mutex_lock( &parent._lock );
	while (parent._queue.empty())
		pthread_cond_wait( &parent._emptyCondition, &parent._lock );
	Event * newEvent = parent._queue.front();
	parent._queue.pop();	
	pthread_mutex_unlock( &parent._lock );
	return newEvent;
}

Event* EventBuffer::Reader::pop(unsigned long timeout) {
	pthread_mutex_lock( &parent._lock );
	int result = 0;
	timespec t;
	clock_gettime(CLOCK_REALTIME, &t);
	t.tv_nsec += timeout * 1000000;
	while (parent._queue.empty() && result != ETIMEDOUT)
		result = pthread_cond_timedwait( &parent._emptyCondition, &parent._lock, &t );
	if (result != 0) {
		pthread_mutex_unlock( &parent._lock );
		return NULL;
	}
	Event * newEvent = parent._queue.front();
	parent._queue.pop();	
	pthread_mutex_unlock( &parent._lock );
	return newEvent;
}

void EventBuffer::Writer::push(Event * event) {
	pthread_mutex_lock( &parent._lock );
	parent._queue.push(event);
	pthread_cond_broadcast( &parent._emptyCondition );
	pthread_mutex_unlock( &parent._lock );
}
