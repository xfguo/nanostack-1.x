#ifndef APPLICATIONQUITEVENT_H_
#define APPLICATIONQUITEVENT_H_

#include "Event.h"

class ApplicationQuitEvent : public Event
{
public:
	ApplicationQuitEvent() { }
	virtual ~ApplicationQuitEvent() { }
	
	virtual bool process(ApplicationContext & context);

};

#endif /*APPLICATIONQUITEVENT_H_*/
