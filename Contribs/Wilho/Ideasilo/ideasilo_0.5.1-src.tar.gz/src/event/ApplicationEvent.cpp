#include "ApplicationEvent.h"
#include "EventMonitor.h"
#include <iostream>

bool ApplicationQuitEvent::process(ApplicationContext & context) { 
	context.evmon.kill(0);
	return true; 
}

