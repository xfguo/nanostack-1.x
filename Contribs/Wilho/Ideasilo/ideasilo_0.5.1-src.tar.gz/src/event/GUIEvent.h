#ifndef GUIEVENT_H_
#define GUIEVENT_H_

#include "Event.h"
#include "gui/Context.h"
#include "gui/dialog/Dialog.h"
#include <string>

using namespace std;


class RemoveNodeEvent : public Event {
public:
	RemoveNodeEvent(const string & nodeid): _nodeid(nodeid) {}
	virtual ~RemoveNodeEvent() {}
	
	virtual bool process(ApplicationContext & context);

private:
	string _nodeid;
};

class NodeViewActivationEvent : public Event {
public:
	NodeViewActivationEvent(const string & nodeid):_nodeid(nodeid) {}
	virtual ~NodeViewActivationEvent() {}
	
	virtual bool process(ApplicationContext & context);

private:
	string _nodeid;
};

class ContextChangeEvent : public Event {
public:
	ContextChangeEvent(int newcontextid):_newcontextid(newcontextid) {}
	virtual ~ContextChangeEvent() {}
	
	virtual bool process(ApplicationContext & context);

private:
	int _newcontextid;
};

class ContextDataEvent : public Event {
public:
	ContextDataEvent(Context * newcontext):_context(newcontext) {}
	virtual ~ContextDataEvent() { delete _context; }
	
	virtual bool process(ApplicationContext & context);

private:
	Context * _context;	
};

class SettingChangedEvent : public Event {
public:
	SettingChangedEvent(const string & setting, const string & olddata, const string & newdata):
		_setting(setting), _olddata(olddata), _newdata(newdata) {}
	virtual ~SettingChangedEvent() { }
	
	virtual bool process(ApplicationContext & context);

private:
	string _setting;
	string _olddata;
	string _newdata;	
};


class OpenDialogEvent : public Event {
public:
	OpenDialogEvent(Dialog * dialog):_dialog(dialog) {}
	virtual ~OpenDialogEvent() {}
	
	virtual bool process(ApplicationContext & context);
private:
	Dialog * _dialog;
};

class CloseDialogEvent : public Event {
public:
	CloseDialogEvent(Dialog * dialog):_dialog(dialog) {}
	virtual ~CloseDialogEvent() {}
	
	virtual bool process(ApplicationContext & context);
	
private:
	Dialog * _dialog;
};




#endif /*GUIEVENT_H_*/
