#include "GUIEvent.h"
#include "gui/GUI.h"
#include <iostream>

bool RemoveNodeEvent::process(ApplicationContext & context) {
	context.gui.removeNode(_nodeid);
	return true;
}



bool NodeViewActivationEvent::process(ApplicationContext & context) {
	ApplicationMode * mode = context.gui.getAppMode();
	if (mode) {
		mode->activateNodeView(_nodeid);
	}
	return true;
}

bool ContextChangeEvent::process(ApplicationContext & context) {
	//cout << "ContextChangeEvent! NewContextID: " << _newcontextid << endl;
	GdkThread::enter();
	int oldcontextid = context.gui._activecontext;
	Context * oldcontext = context.gui.getContext();
	if (!oldcontext || (oldcontext->getID() != _newcontextid)) {
		// Context changed
		context.gui._activecontext = _newcontextid;
		Context * newcontext = context.gui.getContext();
		if (newcontext) {
			// Check if mode was changed
			ApplicationMode * mode = context.gui.getAppMode();
			if (!oldcontext || (oldcontext->getModeID() != newcontext->getModeID())) {			
				// Application mode was changed with the context
				if (mode)
					mode->release();
				context.gui._activemode = newcontext->getModeID();
				mode = context.gui.getAppMode();
				if (mode) {
					mode->setContext(newcontext);
					mode->activate();
					mode->setToolbar(context.gui._toolbar);
					mode->refreshNodes();
				}
				context.gui.setFrontpage();	
			} else {
				// Context was changed, but mode wasnt. Just refresh the data according to the new context
				cerr << "Context was changed, but mode wasn't. The program should now refresh the content." << endl;
				if (mode) {
					mode->setContext(newcontext);
					mode->refreshNodes();
				}
			}
		} else {
			// New context isn't defined (which is weird).
			cerr << "Warning! Tried to change to a context which doesn't exist." << endl;
			context.gui._activecontext = oldcontextid;
		}
		
	}
	GdkThread::leave();
	//cout << "Leaving ContextChangeEvent::process" << endl;
	return true;
}

bool ContextDataEvent::process(ApplicationContext & context) {
	if (_context) {
		GdkThread::enter();
		Context * oldcontext = context.gui.getContext(_context->getID());
		if (oldcontext) {
			*oldcontext = *_context;
			delete _context;
			_context = NULL;
			// TODO: Generate ContextModifiedEvent
		} else {
			context.gui._contexts[_context->getID()] = _context;
			gtk_combo_box_insert_text(context.gui._contextbox, _context->getID(), _context->getLabel().c_str());
			_context = NULL;
		}
		GdkThread::leave();
	}
	return true;
}

bool SettingChangedEvent::process(ApplicationContext & context) {
	// DEBUG!
	cout << "--! SettingChangedEvent::process: setting: " << _setting << " olddata: " << _olddata << " newdata: " << _newdata << endl;	
	return true;
}


bool OpenDialogEvent::process(ApplicationContext & context) {
	_dialog->setContext(context.gui.getContext());
	context.gui.displayDialog(_dialog);
	return true;
}

bool CloseDialogEvent::process(ApplicationContext & context) {
	context.gui.closeDialog(_dialog);
	return true;
}
