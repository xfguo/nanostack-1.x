#ifndef EVENT_H_
#define EVENT_H_

// This class is supposed to know nothing of the actual implementation of network and GUI
#include "ApplicationContext.h"

class Event {
public:
	Event() {}
	virtual ~Event() {}

	virtual bool process(ApplicationContext & context)=0;
	
private:

};

#endif /*EVENT_H_*/
