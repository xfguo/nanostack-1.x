#ifndef THREAD_H_
#define THREAD_H_

#include <pthread.h>
#include <string>

using namespace std;

class Thread
{
public:
	Thread();
	virtual ~Thread();
	int init()								{ _initcode = setup(); return _initcode; }
	int start(void * arg);
	int join(void ** exit_value);
	virtual void kill(int exitcode = 0)		{ if (!_killed) { _exitcode = exitcode; _killed = true; pthread_cond_broadcast( &_killedcondition );} }
	inline int getExitcode()				{ return _exitcode; }
	inline bool is_alive()					{ return _alive; }
	inline bool is_killed() 				{ return _killed; }
	string startErrMsg(int code, const char * module);
	
protected:
	void wait(unsigned long msec);
	void execute();
	static void * entrypoint(void*);
	virtual int setup()			{ return 0; }
	virtual int run()=0;
	void * getArg() const		{ return _arg; }
	void setArg(void * newarg)	{ _arg = newarg; }
	
private:
	void * _arg;
	pthread_t _handle;
	bool _alive;
	bool _killed;
	int _initcode;
	int _exitcode;
	pthread_cond_t _killedcondition;
	pthread_mutex_t	_lock;
	
};

#endif /*THREAD_H_*/
