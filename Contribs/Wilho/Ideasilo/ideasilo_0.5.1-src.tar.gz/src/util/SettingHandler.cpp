#include "SettingHandler.h"
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

Setting::Setting():
	_type(UNDEFINED)
{
	pthread_mutex_init(&_lock,NULL);
}

Setting::Setting(SettingType type, string name, string data):
	_type(type),
	_name(name),
	_data(data) 
{
	pthread_mutex_init(&_lock,NULL);
	validateType();
}

Setting::Setting(string name, string data):
_name(name),
_data(data)
{
	pthread_mutex_init(&_lock,NULL);
	_type = guessType(data);
}

Setting::Setting(const Setting & op)
{
	pthread_mutex_init(&_lock,NULL);
	*this = op;
}

void Setting::set(const string & data) {
	pthread_mutex_lock(&_lock);
	_data = data;
	validateType();
	pthread_mutex_unlock(&_lock);
}

void Setting::validateType() {
	if (_type == INTEGER) {
		if (_data.length() == 0)
			_data = "0";
		else if (_data.compare("0") && atoi(_data.c_str()) == 0)
			_type = STRING;
	}	
}

Setting::SettingType Setting::guessType(const string & data) {
	return STRING;
}

Setting & Setting::operator=(const Setting & op) {
	pthread_mutex_lock(&_lock);
	//pthread_mutex_lock(&op._lock);	// Possibility of a deadlock!
	_type = op._type;
	_name = op._name;
	_data = op._data;
	//pthread_mutex_unlock(&op._lock);
	pthread_mutex_unlock(&_lock);
	return *this;
}

string Setting::getData() const
{
	pthread_mutex_lock(&_lock);
	string temp = _data;
	pthread_mutex_unlock(&_lock);
	return temp;
}

string Setting::getName() const
{
	pthread_mutex_lock(&_lock);
	string temp = _name;
	pthread_mutex_unlock(&_lock);
	return temp;
}

Setting::SettingType Setting::getType() const 
{
	pthread_mutex_lock(&_lock);
	SettingType temp = _type;
	pthread_mutex_unlock(&_lock);
	return temp;
}

int Setting::getIntData() {
	if (_type != INTEGER)
		return -1; 
	else 
		return atoi(_data.c_str());
}

SettingHandler::SettingHandler(const string & filename):
_filename(filename)
{
	pthread_mutex_init(&_lock,NULL);
}

SettingHandler::~SettingHandler() {
	pthread_mutex_lock(&_lock);
	while (!_settings.empty()) {
		settings::iterator it = _settings.begin();
		delete it->second;
		_settings.erase(it);
	}
	pthread_mutex_unlock(&_lock);
}

void SettingHandler::add(const Setting & setting) {
	string name = setting.getName();
	if (setting.getType() != Setting::UNDEFINED && name.length() != 0) {
		pthread_mutex_lock(&_lock);
		Setting * newsetting = NULL;
		settings::iterator it = _settings.find(name);
		if (it != _settings.end()) {
			newsetting = it->second;
		} else {
			newsetting = new Setting;
			_settings[name] = newsetting;
		}
		(*newsetting) = setting;
		
		pthread_mutex_unlock(&_lock);
	}
}

Setting* SettingHandler::find(const string & name) {
	pthread_mutex_lock(&_lock);
	Setting * setting = NULL;
	settings::iterator it = _settings.find(name);
	if (it != _settings.end())
		setting = it->second;
	pthread_mutex_unlock(&_lock);
	return setting;
}

const Setting* SettingHandler::find(const string & name) const {
	pthread_mutex_lock(&_lock);
	Setting * setting = NULL;
	settings::const_iterator it = _settings.find(name);
	if (it != _settings.end())
		setting = it->second;
	pthread_mutex_unlock(&_lock);
	return setting;
}

int SettingHandler::size() const {
	pthread_mutex_lock(&_lock);
	int temp = _settings.size();
	pthread_mutex_unlock(&_lock);
	return temp;
}

bool SettingHandler::save() {
	pthread_mutex_lock(&_lock);
	bool write= true, open = true, close = true;
	FILE *file = fopen(_filename.c_str(), "w");
	if (open = (file != NULL)) {
		for (settings::iterator it = _settings.begin(); write && it != _settings.end(); it++) {
			string entry = it->second->getName() + "=" + it->second->getData() + "\n";
			write = fputs(entry.c_str(), file) >= 0;
		}
		close = (fclose(file) != EOF);
	}
	pthread_mutex_unlock(&_lock);
	return open && write && close;
}

bool SettingHandler::load() {
	//pthread_mutex_lock(&_lock);
	bool open = true, read= true, close = true;
	ifstream file(_filename.c_str()); 
	if (open = file.good()) {
		string buf;
		std::getline(file, buf);
		while (!file.eof()) {
			int delimpos = buf.find('=');
			if (delimpos > 0) {
				string label = buf.substr(0, delimpos);
				string data = buf.substr(delimpos+1, buf.length()-delimpos-1);
				add(Setting(label,data));
			}
			std::getline(file, buf);
		}
	}
	//pthread_mutex_unlock(&_lock);
	return open && read && close;
}

