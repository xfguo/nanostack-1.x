#ifndef GOBJECTHANDLER_H_
#define GOBJECTHANDLER_H_

#include <map>
#include "util/widgethandler.h"

using namespace std;

class GObjectHandler
{
public:
	typedef map<int, GObject*> 		objects;
	typedef map<int, GladeXML*>		objectxmls;
	
	GObjectHandler() {}
	virtual ~GObjectHandler();
	
	void				setUIFilename(const string & filename)	{ _uifilename = filename; }
	virtual objects & 	getObjects()			{ return _objects; }
	GObject * 			getObject(int objectid);
	GtkWidget * 		getWidget(int widgetid);
	bool 				hasObject(int objectid);

	void 				registerObject(int objectid, const char * xmltag);
	void 				registerObject(int objectid, GObject * object);
	void 				registerObject(int objectid, GtkWidget * object);
	void 				releaseObjects();
	
	
protected:
	void 				releaseXMLs();
	bool				hasXML(int xmlid);
	GladeXML *			getXML(int xmlid);
	void				registerXML(int xmlid, GladeXML * xml);
	
	string 				_uifilename;
	objects 			_objects;
	objectxmls			_xmls;

	
	
};

#endif /*GOBJECTHANDLER_H_*/
