#include "widgethandler.h"
#include <string>
#include <iostream> // debug
#include <pthread.h>
#include <gtk/gtk.h>
#include <sys/stat.h>	// for stat()

using namespace std;

TablePackingSettings::TablePackingSettings(GtkWidget * table, int x, int y):
xoptions((GtkAttachOptions)0),
yoptions((GtkAttachOptions)0),
xpadding(0),
ypadding(0) 
{		
	define(table, x, y);
}

void TablePackingSettings::define(GtkWidget * tablew, int x, int y) {
	GtkTable * table = GTK_TABLE(tablew);
	for (GList * children = table->children; children; children = children->next) {
		GtkTableChild * props = (GtkTableChild*)children->data;
		if (props->left_attach == x && props->top_attach == y)
			define(props);
	}
}

void TablePackingSettings::define(GtkTableChild * child) {
	xpadding = child->xpadding;
	ypadding = child->ypadding;
	xoptions = (GtkAttachOptions)((child->xexpand << 0) | (child->xshrink << 1) | (child->xfill << 2));	
	yoptions = (GtkAttachOptions)((child->yexpand << 0) | (child->yshrink << 1) | (child->yfill << 2));
}

void WidgetUtil::attachToTable(GtkTable * table, GtkWidget * widget, 
	int left, int right, int top, int bottom, TablePackingSettings settings) {
	gtk_table_attach(table, widget, left, right, top, bottom, 
		settings.xoptions, settings.yoptions, settings.xpadding, settings.ypadding);
}

void WidgetUtil::setTextViewData(GtkTextView * textview, const char * text) {
	GtkTextBuffer * textbuf = gtk_text_view_get_buffer(textview);
	gtk_text_buffer_set_text(textbuf, text, -1);
}

string WidgetUtil::getTextViewData(GtkTextView * textview) {
	GtkTextBuffer * databuf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(textview));
	GtkTextIter begin, end;
	gtk_text_buffer_get_start_iter(databuf, &begin);
	gtk_text_buffer_get_end_iter(databuf, &end);
	gchar * data = gtk_text_buffer_get_text(databuf, &begin, &end, false);
	string datastr = data;
	g_free(data);
	return datastr;
}

void WidgetUtil::destroyWidget(GtkWidget * widget) {
	if (!widget)
		return;
	g_object_ref(widget);
	gtk_object_sink(GTK_OBJECT(widget));
	gtk_widget_destroy(widget);
	g_object_unref(widget);
}

void WidgetUtil::destroyAndForget(GtkWidget *& widget) {
	if (!widget)
		return;
	g_object_ref(widget);
	gtk_object_sink(GTK_OBJECT(widget));
	gtk_widget_destroy(widget);
	g_object_unref(widget);
	widget = NULL;
}

void WidgetUtil::unrefAndForget(GtkWidget *& widget) {
	if (!widget)
		return;
	g_object_unref(widget);
	widget = NULL;
}

void WidgetUtil::unrefAndForget(GladeXML *& gladexml) {
	if (!gladexml)
		return;
	g_object_unref(gladexml);
	gladexml = NULL;
}

bool WidgetUtil::disable_event(GtkWidget * widget, gpointer something) {
	return true;
}

GdkPixbuf * WidgetUtil::loadImage(const stringstream & stream) {
	return WidgetUtil::loadImage(stream.str().c_str(), stream.str().length());
}

GdkPixbuf * WidgetUtil::loadImage(const char * stream, size_t streamlen) {
	string tempfile_basename = "/tmp/__ideasilo_remote_image_temp_";
	int index = 0;
	struct stat fileinfo;
	string filename;
	for (bool fail = true; fail; index++) {
		stringstream s;
		s << tempfile_basename << index;
		filename = s.str();
		if (stat(filename.c_str(), &fileinfo))
			fail = false;
	}
	//cout << "NetworkController::loadImage: tempfilename: " << filename << endl;
	FILE * tempfile = fopen(filename.c_str(), "w");
	if (!tempfile) {
		cerr << "NetworkController::loadImage: Error! Could not open tempfile" << endl;
		return NULL;
	}
	fwrite(stream, streamlen, sizeof(char), tempfile);
	fclose(tempfile);
	GError *error = NULL;
	GdkPixbuf * newimage = gdk_pixbuf_new_from_file(filename.c_str(), &error);
	if (!newimage)
		cerr << "NetworkController::loadImage: Warning! Failed to open received image." << endl;
	remove(filename.c_str());
	return newimage;
}

static pthread_t currentthread = 0;
static int entercount = 0;
void GdkThread::enter() {
	pthread_t caller = pthread_self();
	if (!currentthread || currentthread != caller) {
		// No threads in critical section or a different thread accessing critical section
		gdk_threads_enter();
		currentthread = caller;
		++entercount;
		return;
	} else if (currentthread == caller) {	
		// Calling thread accessing critical section
		++entercount;
		return;
	}
	cout << "MIKKO EI TAMA KOODI TOIMI!" << endl;
}

void GdkThread::leave() {
	
	pthread_t caller = pthread_self();
	if (currentthread == caller) {
		--entercount;
		if (entercount == 0) {
			gdk_flush();
			gdk_threads_leave();
			currentthread = 0;
		}
		if (entercount < 0)
			cerr << "Warning! Critical section entered less times than leaved!" << endl;
	} else	// DEBUG
		cerr << "Warning! Critical secion left by a differed thread than it was entered" << endl;
}

