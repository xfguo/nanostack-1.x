#ifndef SETTINGHANDLER_H_
#define SETTINGHANDLER_H_

#include <string>
#include <pthread.h>
#include <map>

using std::string;
using std::map;

class SettingHandler;
class Setting {
public:
	enum SettingType { UNDEFINED, STRING, INTEGER, REAL, IP, TIME, DATE };
	//friend class SettingsDialog;
	Setting();
	Setting(string name, string data);
	Setting(SettingType type, string name, string data);
	Setting(const Setting & op);
	Setting & operator=(const Setting & op);
	
	string getData() const;
	string getName() const;
	SettingType getType() const;
	int getIntData();
	void set(const string & data);
	static SettingType guessType(const string & data);
	// TODO: Support for rest of the setting types
	
private:
	mutable pthread_mutex_t _lock;	// Makes sure the setting isn't modified and accessed at the same time
	void validateType();
	
	SettingType _type;
	string _name;
	string _data;
};

class SettingHandler {
public:
	friend class SettingsDialog;
	SettingHandler(const string & filename);
	~SettingHandler();
	Setting* find(const string & name);
	const Setting * find(const string & name) const;
	void add(const Setting & setting);
	int size() const;
	bool save();
	bool load();
	
private:
	typedef map<string,Setting*> settings;
	mutable pthread_mutex_t _lock;
	settings  _settings;
	string _filename;
};




#endif /* SETTINGHANDLER_H_ */
