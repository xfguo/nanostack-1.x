#ifndef LOGGER_H_
#define LOGGER_H_

#include <pthread.h>
#include <stdio.h>
#include <string>
using std::string;

class Logger
{
public:
	Logger(const char * filename);
	~Logger();
	
	void write(const string & msg, int erno = 0);
	void disable()	{ _disable = true; }
	void enable()	{ _disable = false; }
	
private:
	const char * 	_filename;
	pthread_mutex_t	_lock;
	bool			_disable;
	FILE *			_file;
};

#endif /*LOGGER_H_*/
