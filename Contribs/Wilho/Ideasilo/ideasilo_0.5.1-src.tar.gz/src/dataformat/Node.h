#ifndef NODE_H_
#define NODE_H_

#include <libxml/parser.h>
#include <libxml/tree.h>
#include <string>
#include "NodeContent.h"


using namespace std;

class Node
{
public:
	Node();
	Node(const Node & ot);
	Node(const string & id): _id(id), _content(NULL) {}
	virtual ~Node();
	static Node * parseXML(const string & XML);
	static Node * parseXML(const xmlNode * entrynode);
	
	const string & 		getID() const		{ return _id; }
	const NodeContent * getContents() const	{ return _content; }
	NodeContent *		getContents()		{ return _content; }
	NodeContent::ContentType getContentType() const	{ if (_content) return _content->getType(); else return NodeContent::TYPE_EMPTY; }
	void				attachContent(NodeContent * newcontent);
	NodeContent * 		detachContent()	{ NodeContent * temp = _content; _content = NULL; return temp; }
	bool				canUpdate(const Node * newnode);
	bool				update(Node * newnode);
	bool				update(unsigned int version, char * data, size_t datalen);
	string				serializeToXML(int indent = 0) const;
	
private:
	
	string 			_id;
	NodeContent * 	_content;
	
};


#endif /*NODE_H_*/
