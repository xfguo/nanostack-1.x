#include "Leaf.h"

#include <iostream>
#include <sstream>

#include "util/widgethandler.h"
#include "util/Util.h"
#include "TextLeaf.h"
#include "URILeaf.h"
#include "BinaryLeaf.h"
#include "ImageLeaf.h"
#include "XMLTag.h"


const char * IMAGE_FORMAT_JPG = "jpg";
const char * IMAGE_FORMAT_PNG = "png";
const char * IMAGE_FORMAT_ICO = "ico";
const char * IMAGE_FORMAT_BMP = "bmp";

Leaf::Leaf()
{
}

Leaf::~Leaf()
{
}

Leaf * Leaf::parseXMLToLeaf(const xmlNode * root) {
	// This function is called by Node::parseXML,
	// therefore it can be assumed that the node is an element node
	if (!root)
		return NULL;
	Leaf * newleaf = NULL;
	if (xmlStrEqual(root->name, XML::ELEMENT::TEXT))
		newleaf = TextLeaf::parseXMLToTextLeaf(root);
	else if (xmlStrEqual(root->name, XML::ELEMENT::URI))
		newleaf = UriLeaf::parseXMLToUriLeaf(root);
	else if (xmlStrEqual(root->name, XML::ELEMENT::IMAGE))
		newleaf = ImageLeaf::parseXMLToImageLeaf(root);
	else if (xmlStrEqual(root->name, XML::ELEMENT::BINARY))
		newleaf = BinaryLeaf::parseXMLToBinaryLeaf(root);
	return newleaf;
}


Leaf::ContentType Leaf::parseTypeString(const char * str) {
	if (!strcmp(str, "text"))
		return TYPE_TEXT;
	else if (!strcmp(str, "uri"))
		return TYPE_URI;
	else if (!strcmp(str, "image"))
		return TYPE_IMAGE;
	else if (!strcmp(str, "binary"))
		return TYPE_BINARY;
	else
		return TYPE_EMPTY;
}



