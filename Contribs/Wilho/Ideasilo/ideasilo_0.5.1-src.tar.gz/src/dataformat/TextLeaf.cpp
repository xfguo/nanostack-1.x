#include "TextLeaf.h"

#include <sstream>

TextLeaf::TextLeaf() {}
TextLeaf::~TextLeaf() {}
TextLeaf * TextLeaf::parseXMLToTextLeaf(const xmlNode * root, TextLeaf * textleaf) {
	//cout << "Parsing a text leaf" << endl;
	if (!textleaf)
		textleaf = new TextLeaf;
	stringstream str;
	for (const xmlNode * current = root->children; current; current = current->next) {
		if (current->type == XML_TEXT_NODE)
			str << (char*)current->content;
	}
	textleaf->_text = str.str();
	//cout << "Text leaf contents: " << newtextleaf->_text << endl;
	return textleaf;
}

string TextLeaf::serializeToXML(int indent) const {
	stringstream str;
	while (indent-- > 0) {
		str << "\t";
	}
	str << _text;
	return str.str();
}

bool TextLeaf::hasData() const {
	if (_text.length() > 0)
		return true;
	else
		return false;
}

NodeContent * TextLeaf::clone() const {
	return new TextLeaf(*this);
}
