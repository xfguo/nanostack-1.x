#ifndef TEXTLEAF_H_
#define TEXTLEAF_H_

#include "Leaf.h"

class TextLeaf : public Leaf {
public:
	static TextLeaf * 		parseXMLToTextLeaf(const xmlNode * root, TextLeaf * textleaf = NULL);
	
	TextLeaf();
	virtual ~TextLeaf();
	//TextLeaf(const TextLeaf & ot);		// Default copy constructor
	
	virtual string			serializeToXML(int indent = 0) const;
	virtual bool			hasData() const;
	virtual const string & 	getData() const 		{ return _text; }
	void					setData(const string & data) { _text = data; }
	virtual ContentType		getType() const			{ return TYPE_TEXT; }
	virtual const char * 	getTypeString() const 	{ return "text"; }
	virtual NodeContent *	clone() const;
	
protected:	
	string 			_text;
	
};

#endif /*TEXTLEAF_H_*/
