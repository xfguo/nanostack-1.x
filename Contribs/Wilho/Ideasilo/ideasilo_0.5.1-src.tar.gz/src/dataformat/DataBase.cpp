#include "DataBase.h"
#include "Branch.h"

DataBase::DataBase()
{
	// Jezus! 5 Lines of code just to initialise a simple recursive mutex!
	pthread_mutexattr_t attr;
	pthread_mutexattr_init(&attr);
	pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE_NP);
	pthread_mutex_init(&_lock,&attr);
	pthread_mutexattr_destroy(&attr);
}

DataBase::~DataBase()
{
	clear();
}

void DataBase::clear() {
	for (nodes::iterator it = _nodes.begin(); it != _nodes.end(); it++) {
		delete it->second;
	}
	_nodes.clear();
}


const Node * DataBase::get(const string & id) const {
	pthread_mutex_lock(&_lock);
	nodes::const_iterator it = _nodes.find(id);
	pthread_mutex_unlock(&_lock);
	if (it != _nodes.end())
		return it->second;
	else
		return NULL;
}

Node * DataBase::get(const string & id) {
	pthread_mutex_lock(&_lock);
	nodes::iterator it = _nodes.find(id);
	pthread_mutex_unlock(&_lock);
	if (it != _nodes.end())
		return it->second;
	else
		return NULL;
}

Node * DataBase::getCopy(const string & id, int depth) const {
	if (depth < 0)
		return NULL;
	Node * result = NULL;
	pthread_mutex_lock(&_lock);
	nodes::const_iterator it = _nodes.find(id);
	if (it != _nodes.end()) {
		result = new Node(*(it->second));
		if (depth > 0 && result->getContentType() == NodeContent::TYPE_BRANCH) {
			Branch * branch = static_cast<Branch*>(result->getContents());
			for (Branch::children::iterator cit = branch->_children.begin(); cit != branch->_children.end(); cit++) {
				if (cit->second == NULL)
					cit->second = getCopy(cit->first, depth-1);
			}
		}
	}
	pthread_mutex_unlock(&_lock);
	return result;
}

//bool DataBase::insert(DataNode * newnode) {
//	if (!newnode)
//		return false;
//	bool result = true;
//	const string & id = newnode->getID();
//	pthread_mutex_lock(&_lock);
//	nodes::iterator it = _nodes.find(id);
//	if (it != _nodes.end()) {
//		delete newnode;
//		result = false;
//	} else
//		_nodes[id] = newnode;
//	pthread_mutex_unlock(&_lock);
//	return result;
//}

Node * DataBase::detach(const string & id) {
	if (id.length() == 0)
		return NULL;
	Node * target = NULL;
	pthread_mutex_lock(&_lock);
	nodes::iterator it = _nodes.find(id);
	if (it != _nodes.end()) {
		target = it->second;
		_nodes.erase(it);
	}
	pthread_mutex_unlock(&_lock);
	return target;
}

bool DataBase::update(Node * newnode) {
	if (!newnode)
		return false;
	bool success = true;
	const string & id = newnode->getID();
	pthread_mutex_lock(&_lock);
	nodes::iterator it = _nodes.find(id);
	if (it == _nodes.end())
		_nodes[id] = newnode;
	else {
		Node * oldnode = it->second;
		success = oldnode->update(newnode);
	}
	if (success) {
		assimilate(it->second);
	}
		
	pthread_mutex_unlock(&_lock);
	return success;
}

bool DataBase::update(const string & nodeid, unsigned int version, char * data, size_t datalen) {
	bool success = false;
	pthread_mutex_lock(&_lock);
	nodes::iterator it = _nodes.find(nodeid);
	if (it != _nodes.end()) {
		Node * oldnode = it->second;
		success = oldnode->update(version, data, datalen);
	} 
	pthread_mutex_unlock(&_lock);
	return success;
}

void DataBase::assimilate(Node * node) {
	if (!node)
		return;
	NodeContent * contents = node->getContents();
	if (!contents || !contents->hasChildren())
		return;
	Branch * set = static_cast<Branch*>(contents);
	for (Branch::children::iterator it = set->_children.begin(); it != set->_children.end(); it++) {
		Node * child = it->second;
		if (update(child)) {
			it->second = NULL;
			assimilate(child);
		}
	}
}
