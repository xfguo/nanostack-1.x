#ifndef IMAGELEAF_H_
#define IMAGELEAF_H_

#include <gdk-pixbuf/gdk-pixbuf.h>
#include "BinaryLeaf.h"

class ImageLeaf: public BinaryLeaf {
public:
	static ImageLeaf * parseXMLToImageLeaf(const xmlNode * root, ImageLeaf * imageleaf = NULL);
	
	ImageLeaf();
	ImageLeaf(unsigned int version, const string & label);
	virtual ~ImageLeaf();
	ImageLeaf(const ImageLeaf & ot);
	
	virtual bool 			hasData() const;
	virtual ContentType		getType() const			{ return TYPE_IMAGE; }
	virtual const char * 	getTypeString() const 	{ return "image"; }	
	virtual NodeContent *	clone() const;
	//virtual bool			update(NodeContent * newcontent);
	virtual bool			update(char * data, size_t datalen);
	
	virtual string			serializeAttributesToXML() const;
	virtual string			serializeToXML(int indent = 0) const;
	

	const string &			getFormat() const		{ return _format; }
	//void					setImage(GdkPixbuf * newimage);
	GdkPixbuf * 			getImage();
	const GdkPixbuf * 		getImage() const;
	//GdkPixbuf * 			detachImage();
	void					setRemoteURL(const string & newurl)		{ _remoteurl = newurl; }
	const string &			getRemoteURL() const	{ return _remoteurl; }
	
	
protected:
	GdkPixbuf *				initImage() const ;
	mutable GdkPixbuf *		_image;
	string					_format;
	string					_remoteurl;
};

#endif /*IMAGELEAF_H_*/
