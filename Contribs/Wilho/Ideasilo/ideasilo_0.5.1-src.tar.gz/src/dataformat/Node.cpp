#include "Node.h"

#include <sstream>

namespace XML {
	namespace ATTRIB {
		const xmlChar * ID = (xmlChar*)"ID";
	};
};

Node::Node():
	_content(NULL)
{
}

Node::Node(const Node & ot) {
	_id = ot._id;
	if (ot._content)
		_content = ot._content->clone();
	else
		_content = NULL;
}

Node::~Node()
{
	delete _content;
}
#include <iostream>
void Node::attachContent(NodeContent * newcontent) {
	if (newcontent == _content)
		return;
	delete _content;
	_content = newcontent;
}

bool Node::canUpdate(const Node * newnode) {
	if (!newnode || !newnode->_content || _id.compare(newnode->_id))
		return false;
	if (_content && _content->_version > newnode->_content->_version) {
		return false;
	} 
	return true;
}


bool Node::update(Node * newnode) {
	bool success = false;
	if (canUpdate(newnode)) {
		delete _content;
		_content = newnode->detachContent();
		success = true;
	} else if (_content != NULL) {
		if (_content ->update(newnode->_content ))
			success = true;
	}
	delete newnode;
	return success;
}

bool Node::update(unsigned int version, char * data, size_t datalen) {
	bool success = false;
	if (_content && _content->getVersion() <= version) {
		success = _content->update(data, datalen);
	}
	if (!success) {
		free(data);
	}
	return success;
}


Node * Node::parseXML(const string & XML) {
	xmlDoc * doc = xmlReadMemory(XML.c_str(), XML.length(), "newdataset.xml", NULL, 0);
	if (doc == NULL) {
		return NULL;	
	} else {
		const xmlNode * root = xmlDocGetRootElement(doc);
		Node * newnode = parseXML(root);
		xmlFreeDoc(doc);
		return newnode;
	}
}

Node * Node::parseXML(const xmlNode * root) {
	if (!root || root->type != XML_ELEMENT_NODE)
		return NULL;
	Node * newnode = new Node;
	for (const xmlAttr * curattr = root->properties; curattr; curattr = curattr->next) {
		if (curattr->type == XML_ATTRIBUTE_NODE) {
			if (xmlStrEqual(curattr->name, XML::ATTRIB::ID)) {
				newnode->_id = (char*)curattr->children->content;
			} 
		}
	}
	NodeContent * newcontent = NodeContent::parseXMLToContent(root);
	if (newnode->_id.length() == 0) {
		delete newcontent;
		delete newnode;
		return NULL;
	}
//	cout << "Parsed a new node." << endl;
//	if (!newnode)
//		cout << "Node was NULL!" << endl;
//	if (!newcontent)
//		cout << "Content was NULL!" << endl;
	newnode->attachContent(newcontent);
	return newnode;
}

string Node::serializeToXML(int indent) const {
	stringstream xml;
	string roottag;
	for (int n = indent; n > 0; n--)
		xml << "\t";
	if (getContentType() == NodeContent::TYPE_EMPTY)
		xml << "<node ID=\"" << _id << "\"/>";
	else {
		roottag = _content->getTypeString();

		xml << "<" << roottag << " ";
		xml << XML::ATTRIB::ID << "=\"" << _id << "\" ";
		xml << _content->serializeAttributesToXML();
		xml << ">";
		xml << _content->serializeToXML();
		xml << "</" << roottag << ">";
	}
	
	return xml.str();
}

//<branch ID="IdeasiloDemo-00001" v="1" label="Blue pants, S">
//	<text ID="IdeasiloDemo-00001-1" v="1" label="Item">Blue pants</text>
//  <text ID="IdeasiloDemo-00001-2" v="1" label="Size">S</text>
//  <text ID="IdeasiloDemo-00001-3" v="1" label="Color">Blue</text>
//  <uri ID="IdeasiloDemo-00001-4" v="1" label="Manufacturer webpage">http://www.acme.com/generic_pants</text>
//  <image ID="IdeasiloDemo-00001-5" v="1" label="Image">http://www.ee.oulu.fi/~mipoloja/ideasilo/images/Blue_pants_S.jpg</image>
//  <binary ID="IdeasiloDemo-00001-6" v="1" label="Advertisement">ABCDE</binary>
//  <branch ID="IdeasiloDemo-00001-7" v="1" label="Washing info">
//    <text ID="IdeasiloDemo-00001-7-1" v="1" label="Temperature">40</text>
//    <text ID="IdeasiloDemo-00001-7-2" v="1" label="Notes">Do not bleach, iron or tumble</text>
//  </branch>
//</branch>
