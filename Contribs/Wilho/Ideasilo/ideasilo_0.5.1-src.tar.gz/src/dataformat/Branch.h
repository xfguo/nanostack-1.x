#ifndef BRANCH_H_
#define BRANCH_H_

#include <libxml/parser.h>
#include <libxml/tree.h>
#include <vector>

#include "Node.h"
//#include "NodeContent.h"

class Branch : public NodeContent
{
public:
	friend class DataBase;
	typedef vector< pair<string,Node*> > children;
	typedef pair<string,Node*> child;
	Branch();
	virtual ~Branch();
	Branch(const Branch & ot);
	static Branch * 		parseXMLToBranch(const xmlNode * root);
	virtual string			serializeToXML(int indent = 0) const;
	
	const children &		getChildren() const	{ return _children; }
	virtual ContentType 	getType() const		{ return TYPE_BRANCH; }
	virtual const char * 	getTypeString() const 	{ return "branch"; }
	bool 					hasData() const		{ return false; }
	bool 					hasChildren() const	{ if (_children.size() == 0) return false; else return true; }
	
	//virtual bool			update(NodeContent * newcontent);
	virtual NodeContent * 	clone() const;
	
protected:
	children _children;
	
};

#endif /*BRANCH_H_*/
