#include "NodeContent.h"
#include "Branch.h"
#include "Leaf.h"

#include <sstream>

namespace XML {
	namespace ELEMENT { 
		const xmlChar * BRANCH = (xmlChar*)"branch";
	};

	namespace ATTRIB {
		const xmlChar * LABEL = (xmlChar*)"label";
		const xmlChar * VERSION = (xmlChar*)"v";
	};
};

using namespace std;

NodeContent::NodeContent(): 
	_version(0)
{
}

NodeContent::~NodeContent()
{
}

string NodeContent::serializeAttributesToXML() const {
	stringstream xml;
	xml << XML::ATTRIB::VERSION << "=\"" << _version << "\" ";
	xml << XML::ATTRIB::LABEL << "=\"" << _label << "\" ";
	return xml.str();
}

NodeContent * NodeContent::parseXMLToContent(const xmlNode * root) {
	NodeContent * newcontent;
	if (xmlStrEqual(root->name, XML::ELEMENT::BRANCH)) {
		newcontent = Branch::parseXMLToBranch(root);
	} else 
		newcontent = Leaf::parseXMLToLeaf(root);
	if (newcontent) {
		for (const xmlAttr * curattr = root->properties; curattr; curattr = curattr->next) {
			if (curattr->type == XML_ATTRIBUTE_NODE) {
				if (xmlStrEqual(curattr->name, XML::ATTRIB::VERSION)) {
					unsigned long ver = atol((char*)curattr->children->content);
					if (ver > 0) newcontent->_version = ver;
				} else if (xmlStrEqual(curattr->name, XML::ATTRIB::LABEL)) {
					newcontent->_label = (char*)curattr->children->content;
				}
			}
		}
	}
	return newcontent;

}
