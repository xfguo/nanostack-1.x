#ifndef URILEAF_H_
#define URILEAF_H_

#include "TextLeaf.h"

class UriLeaf : public TextLeaf {
public:
	UriLeaf();
	virtual ~UriLeaf();
	// UriLeaf(const UriLeaf & ot);		// Default copy constructor
	static UriLeaf *  	parseXMLToUriLeaf(const xmlNode * root, UriLeaf * urileaf = NULL);
	
	ContentType			getType() const			{ return TYPE_URI; }
	const char * 		getTypeString() const 	{ return "uri"; }
	NodeContent *		clone() const;
	
protected:	
	
};

#endif /*URILEAF_H_*/
