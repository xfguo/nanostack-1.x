#ifndef DATALEAF_H_
#define DATALEAF_H_

#include <libxml/parser.h>
#include <libxml/tree.h>
#include "NodeContent.h"

using namespace std;

class Leaf : public NodeContent
{
public:
	static Leaf * 			parseXMLToLeaf(const xmlNode * root);
	static ContentType 		parseTypeString(const char * str);
	
	Leaf();
	Leaf(unsigned int version, const string & label): NodeContent(version, label) {}
	virtual ~Leaf();

	virtual const char * 	getTypeString() const = 0;
	
	bool					hasChildren() const	{ return false; }
	
protected:
	
};

#endif /*DATALEAF_H_*/
