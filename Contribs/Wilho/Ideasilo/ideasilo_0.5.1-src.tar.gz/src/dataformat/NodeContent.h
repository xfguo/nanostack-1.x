#ifndef NODECONTENT_H_
#define NODECONTENT_H_

#include <string>
#include <libxml/parser.h>

using namespace std;

class NodeContent
{
public:
	enum ContentType { TYPE_EMPTY, TYPE_TEXT, TYPE_URI, TYPE_IMAGE, TYPE_BINARY, TYPE_BRANCH };
	friend class Node;
	
	static NodeContent * parseXMLToContent(const xmlNode * root);
	
	NodeContent();
	NodeContent(unsigned int version, const string & label): _version(version), _label(label) {}
	virtual ~NodeContent();
	
	virtual bool			hasChildren() const = 0;
	virtual bool			hasData() const = 0;
	virtual ContentType 	getType() const = 0;
	virtual const char * 	getTypeString() const = 0;
	virtual bool			update(NodeContent * newcontent) 		{ return false; }
	virtual bool			update(char * data, size_t datalen)		{ return false; }
	virtual NodeContent * 	clone() const = 0;
	
	virtual string			serializeToXML(int indent = 0) const = 0;
	virtual string			serializeAttributesToXML() const;
	
	const string & 			getLabel() const				{ return _label; }
	void					setLabel(const string & label)	{ _label = label; }
	unsigned int 			getVersion() const				{ return _version; }
	void					setVersion(unsigned int version){ _version = version; }
	
protected:
	
	unsigned int 	_version;
	string 			_label;
};

#endif /*NODECONTENT_H_*/
