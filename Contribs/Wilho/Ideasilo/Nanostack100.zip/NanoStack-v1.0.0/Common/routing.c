/*
    NanoStack: MCU software and PC tools for sensor networking.
		
    Copyright (C) 2006-2007 Sensinode Ltd.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

		Address:
		Sensinode Ltd.
		PO Box 1
		90571 Oulu, Finland

		E-mail:
		info@sensinode.com
*/


/**
 *
 * \file     routing.c
 * \brief    Routing module which handle routing & neighbourtable informations.
 *
 *  This module will be usefull for every modules who want check neighbor_tables and routing_tables
 *  
 */
/*
 LICENSE_HEADER
 */
#include "FreeRTOS.h"
#include "semphr.h"
#include "queue.h"
#include <sys/inttypes.h>
#include <string.h>
#include "address.h"
#include "neighbor_routing_table.h"
#include "stack.h"
#include "debug.h"
#define TTL		15	
#define ROUTING_TTL	15

void check_tables_status(void *unused_parameter);
void free_table_semaphore(void);
xSemaphoreHandle table_lock = NULL;
#ifdef HAVE_ROUTING
routing_table_t routing_table;
uint8_t n_route_buffer=0;
xQueueHandle     route_info; 
#endif
neighbor_table_t neighbor_table;
xQueueHandle     neighbor_info;

uint8_t n_neigh_buffer=0;
/**
 * Initialize Neighbour and Routing tables.
 *
 * Create also semaphore for tables.
 *
 */
void routing_init(void)
{
	neighbor_info_t *b;
	vSemaphoreCreateBinary( table_lock );
	if(table_lock != NULL)
	{
	uint8_t i;
	/* Initialize broadcast sequence number, neighbor- and routing-tables */
#ifdef HAVE_ROUTING
	route_info_t *ptr;
		routing_table.count=0;
#endif
		neighbor_table.count=0;
		neighbor_table.child_count=0;
	neighbor_info = xQueueCreate( MAX_NEIGHBOR_COUNT, sizeof( neighbor_info_t * ) );
#ifdef HAVE_ROUTING
	route_info = xQueueCreate( MAX_ROUTE_INFO_COUNT, sizeof( route_info_t * ) );
#endif
		i = 0;
		while (i < MAX_NEIGHBOR_COUNT)
		{	/*Allocate a maximum of STACK_BUFFERS_MIN buffers */
			b = pvPortMalloc(sizeof(neighbor_info_t));
			if (b)
			{
				memset(b, 0, sizeof(neighbor_info_t));
				n_neigh_buffer++;
				if (xQueueSend( neighbor_info, ( void * ) &b,(portTickType) 0 ) == pdFALSE)
				{
	#ifdef ROUTING_DEBUG   
					debug("Routing: buffers fail.\r\n");
	#endif  
				}
			}
			else
			{
	#ifdef ROUTING_DEBUG   
				debug("Routing: buffer allocation failed.\r\n");
	#endif
				i = MAX_NEIGHBOR_COUNT;  
			}
			if (i++ >= MIN_NEIGHBOR_INFO_COUNT) i = MAX_NEIGHBOR_COUNT;
		}
		/* init tables */
		for(i=0; i < MAX_ROUTE_INFO_COUNT ; i++)
		{
			neighbor_table.neighbor_info[i]=0;
		}
#ifdef HAVE_ROUTING
	/* Allocate routing info buffers */
	i = 0;
	while (i < MAX_ROUTE_INFO_COUNT)
	{	/*Allocate a maximum of STACK_BUFFERS_MIN buffers */
		ptr = pvPortMalloc(sizeof(route_info_t));
		if (ptr)
		{
  			memset(ptr, 0, sizeof(route_info_t));
			n_route_buffer++;
  			if (xQueueSend( route_info, ( void * ) &ptr,(portTickType) 0 ) == pdFALSE)
			{
#ifdef ROUTING_DEBUG   
				debug("Routing: buffers fail.\r\n");
#endif  
			}
		}
		else
		{
#ifdef ROUTING_DEBUG   
			debug("Routing: buffer allocation failed.\r\n");
#endif
			i = MAX_ROUTE_INFO_COUNT;  
		}
		if (i++ >= MIN_ROUTE_INFO_COUNT) i = MAX_ROUTE_INFO_COUNT;
	}
	/* init tables */
	for(i=0; i < MAX_ROUTE_INFO_COUNT ; i++)
	{
		routing_table.route_info[i]=0;
	}
#endif /* HAVE_ROUTING */
	}
}
/**
 * Function for look for neighbourtable.
 *
 * After check shuold run free_table_semaphore()
 *
 * \return address for neighbour table
 */
neighbor_table_t* get_neighbour_info(void)
{
	if( xSemaphoreTake( table_lock, ( portTickType ) 10 ) == pdTRUE )
	{
		return &(neighbor_table);
	}
	return 0;
}

void free_table_semaphore(void)
{
	xSemaphoreGive( table_lock ); /*free lock*/
}

/**
 *  Get buffer for neighbor info.
 *
 *	\param blocktime  time to wait for buffer
 *
 *  \return           pointer to buffer, 0 on failure (all buffers allocated)
 */
neighbor_info_t* neigh_buffer_get( portTickType blocktime )
{
  neighbor_info_t *b; 

 	 if (xQueueReceive( neighbor_info, &( b ), 0) == pdTRUE)
	{
		return b;
	}
	else if (n_neigh_buffer < MAX_NEIGHBOR_COUNT)
	{
		b = pvPortMalloc(sizeof(neighbor_info_t));
		if (b)
		{
  			memset(b, 0, sizeof(neighbor_info_t));
			n_neigh_buffer++;
			return b;
		}
	}
  	else if (xQueueReceive( neighbor_info, &( b ), blocktime / portTICK_RATE_MS) == pdTRUE)
	{
		return b;
	}
	return 0;
}
/**
 *  Free neighbor info buffer.
 *
 *	\param b					pointer to buffer
 *
 */
void neigh_buffer_free( neighbor_info_t *b )
{
  b->last_lqi  =	0;
  b->last_sqn  =    0;
  b->child_dev =	0;
  b->type	   =	0;
  xQueueSend( neighbor_info, ( void * ) &b, ( portTickType ) 0 );
}

/**
 * Update neighbor tables if necessary.
 *
 * Mac-layer use this function every time when received packet which LQI > 0.
 *
 * \param type indicates type of neighbor address mode
 * \param address neighbor address
 * \param lqi Last received LQI value
 * \param last_sqn last MAC sqn from this address
 *
 * \return 1 when last_sqn is different than current
 * \return 0 when sqn is same, now MAC discard packet
 */
uint8_t update_neighbour_table(addrtype_t type, address_t address, uint8_t last_lqi, uint8_t last_sqn)
{
	uint8_t i,j,tmp_8=0, sqn_check=0, length=0;
	dest_delivery_t delivery_mode;
	delivery_mode = NOT_NEIGHBOR;

	if( xSemaphoreTake( table_lock, ( portTickType ) 10 ) == pdTRUE )
	{
		if(type==ADDR_802_15_4_PAN_LONG)
		{
#ifdef CELLSENSOR
			length=4;
#else
			length=8;					
#endif	
		}
		if(type == ADDR_802_15_4_PAN_SHORT)
		{
			length=4;
		}
		delivery_mode = NOT_NEIGHBOR;
		if(neighbor_table.count > 0)
		{
			for(i=0; i < neighbor_table.count ; i++)
			{
				if(neighbor_table.neighbor_info[i] && (type == neighbor_table.neighbor_info[i]->type))
				{
					if(memcmp(neighbor_table.neighbor_info[i]->address, address,length) == 0)
					{
						delivery_mode = NEIGHBOR;
					}
					/* Update lqi and compare sqn to old one */
					if( delivery_mode == NEIGHBOR )
					{
#ifndef CELLSENSOR
						if(type != ADDR_802_15_4_PAN_SHORT)
						{
							for(j=0; j<2; j++)
							{
								neighbor_table.neighbor_info[i]->address[length+j] = address[length+j];
							}
						}
#endif
						/* Duplicated packet check */
						if(neighbor_table.neighbor_info[i]->last_sqn != last_sqn)
						{
							neighbor_table.neighbor_info[i]->last_sqn = last_sqn;
							sqn_check=1;
						}
						neighbor_table.neighbor_info[i]->last_lqi = last_lqi;
#ifdef CELLSENSOR
						if(type == ADDR_802_15_4_PAN_SHORT)
						{
							neighbor_table.neighbor_info[i]->ttl=TTL;
						}
#else
						neighbor_table.neighbor_info[i]->ttl=TTL;
#endif
						i=(neighbor_table.count);
					}
				}
			}
		}
		/* Add new neighbor if addresstype is source */
		if((delivery_mode == NOT_NEIGHBOR) && neighbor_table.count < MAX_NEIGHBOR_COUNT)
		{
			tmp_8=neighbor_table.count;
			neighbor_table.neighbor_info[tmp_8] = neigh_buffer_get(2);
			if(neighbor_table.neighbor_info[tmp_8])
			{
#ifdef CELLSENSOR
				if(type==ADDR_802_15_4_PAN_LONG)
				{
					for(j=0; j < 4 ; j++)
					{
						neighbor_table.neighbor_info[tmp_8]->address[j] = address[j];
					}
				}
				else
				{
					for(j=0; j < length ; j++)
					{
						neighbor_table.neighbor_info[tmp_8]->address[j] = address[j];
#ifdef ROUTING_DEBUG
						debug_hex(address[j]);
						debug(" : ");
#endif
					}			
				}	
	#else
				if(type==ADDR_802_15_4_PAN_LONG)
				{
						length+=2;
				}
				for(j=0; j < length ; j++)
				{
					neighbor_table.neighbor_info[tmp_8]->address[j] = address[j];
#ifdef ROUTING_DEBUG
					debug_hex(address[j]);
					debug(" : ");
#endif
				}					
#endif
				/* add lqi value to neighbor */
				neighbor_table.neighbor_info[tmp_8]->last_lqi  =	last_lqi;
				neighbor_table.neighbor_info[tmp_8]->last_sqn  =    last_sqn;
				neighbor_table.neighbor_info[tmp_8]->child_dev =	0;
				sqn_check=1;
	#ifdef CELLSENSOR
				if(type == ADDR_802_15_4_PAN_LONG)
				{
					neighbor_table.neighbor_info[tmp_8]->ttl = 1;
				}
				if(type == ADDR_802_15_4_PAN_SHORT)
				{
					neighbor_table.neighbor_info[tmp_8]->ttl=TTL;
				}
	#else
				neighbor_table.neighbor_info[tmp_8]->ttl=TTL;
	#endif
				neighbor_table.neighbor_info[tmp_8]->type = type;
				/* Increace Neigbor count */
				tmp_8++;
				neighbor_table.count = tmp_8;
	#ifdef ROUTING_DEBUG
				debug("\r\nNew neigbor added\r\n");
	#endif
				delivery_mode = NEW_NEIGHBOR;
			}
		}
		free_table_semaphore();
	}
	return sqn_check;
}

/**
 * Update neighbor & routing table TTL when unicast TX working.
 *
 * \param type indicates type of address
 * \param address 
 */
void update_tables_ttl(addrtype_t type, address_t address)
{
	uint8_t i, length=0, final_length=0;
	if( xSemaphoreTake( table_lock, ( portTickType ) 10 ) == pdTRUE )
	{
		if(type==ADDR_802_15_4_PAN_LONG)
		{
#ifdef CELLSENSOR
			length = 4;
			final_length = 4;
#else
			length=8;
			final_length =10;					
#endif	
		}
		if(type == ADDR_802_15_4_PAN_SHORT)
		{
			length=4;
			final_length=4;
		}

		if(neighbor_table.count > 0)
		{
			for(i=0; i < neighbor_table.count ; i++)
			{
				if(neighbor_table.neighbor_info[i] && (type == neighbor_table.neighbor_info[i]->type))
				{
					if(memcmp(neighbor_table.neighbor_info[i]->address, address,length) == 0)
					{
#ifdef CELLSENSOR
						if(type == ADDR_802_15_4_PAN_SHORT)
						{
							neighbor_table.neighbor_info[i]->ttl=TTL;
						}
#else
						neighbor_table.neighbor_info[i]->ttl=TTL;
#endif
						i=(neighbor_table.count);
					}
				}
			}
		}
#ifdef HAVE_ROUTING
		if(routing_table.count > 0)
		{
			for(i=0; i < routing_table.count ; i++)
			{
				if(routing_table.route_info[i] && (type==routing_table.route_info[i]->next_hop_addr_type))
				{
					/* compare next hop address */
					if(memcmp(address, routing_table.route_info[i]->next_hop, final_length) ==0)
					{
						routing_table.route_info[i]->ttl=ROUTING_TTL;
					}
				}
			}
		}
#endif
		free_table_semaphore();
	}
}




/**
 * Check destination address from neighbor.
 *
 * IP-layer uses this function when it has to forward packet.
 *
 * \param type indicates type of destination address mode
 * \param address destination address
 *
 * \return BROADCAST when address was broadcast.
 * \return NEIGHBOR when address was already in list.
 * \return NO_SUPPORT when address type not valid.
 */
dest_delivery_t check_neighbour_table(addrtype_t type, address_t address)
{
	uint8_t i,j, broadcast=1, length;
	addrtype_t temp = 0;
	dest_delivery_t delivery_mode = NOT_NEIGHBOR;
	if( xSemaphoreTake( table_lock, ( portTickType ) 10 ) == pdTRUE )
	{
		switch (type)
		{
			case ADDR_802_15_4_PAN_SHORT:		
				/* Check if broadcast address */
				length=2;
				temp = ADDR_SHORT;
				break;
			case ADDR_802_15_4_PAN_LONG:
				length=8;
				temp = type;
				break;
			default:
#ifdef ROUTING_DEBUG
				debug("No supported address field\r\n");
#endif
				return NO_SUPPORT;
				break;
		}
		/* Check if broadcast address */
		if(stack_check_broadcast(address, temp) != pdTRUE)
		{
				broadcast = 0;
		}
		/* NOT BROADCAST */
		if(broadcast == 0)
		{
			if(neighbor_table.count > 0)
			{
				for(i=0; i < neighbor_table.count ; i++)
				{
					if(neighbor_table.neighbor_info[i] && (neighbor_table.neighbor_info[i]->type == type))
					{
						if(memcmp(neighbor_table.neighbor_info[i]->address, address,length) == 0)
						{
							delivery_mode = NEIGHBOR;
							for(j=0; j<2; j++)
							{
								address[length+j] = neighbor_table.neighbor_info[i]->address[length+j];
							}
							i=neighbor_table.count;
						}
					}
				}
			}
			else
			{
				delivery_mode = NOT_NEIGHBOR;
			}
		}
		else
		{
			delivery_mode = BROADCAST;
		}
		free_table_semaphore();
	}
return delivery_mode;	
}

/**
 * Update new child information.
 *
 * IP-layer uses this function when it has to forward packet.
 *
 * \param type indicates type of child address mode
 * \param address child address
 *
 * \return NOT_CHILD wrong address type.
 * \return CHILD added.
 * \return DISCARD_ASSOC assocation discard.
 */
#ifdef MAC_FFD
child_status_type_t check_child_role(addrtype_t type, address_t address)
{
	uint8_t i,j, length, tmp_8;
	child_status_type_t return_value;
	return_value = NOT_CHILD;
	if( xSemaphoreTake( table_lock, ( portTickType ) 10 ) == pdTRUE )
	{
		switch (type)
		{
			case ADDR_802_15_4_PAN_SHORT:		
				/* Check if broadcast address */
				length=4;
				break;
			case ADDR_802_15_4_SHORT:		
				/* Check if broadcast address */
				length=2;
				type=ADDR_802_15_4_PAN_SHORT;
				break;
			case ADDR_802_15_4_PAN_LONG:
				length=8;
				break;
			default:
#ifdef ROUTING_DEBUG
				debug("No supported address field\r\n");
#endif
				free_table_semaphore();
				return return_value;
				break;
		}
		if(neighbor_table.count > 0)
		{
			for(i=0; i < neighbor_table.count ; i++)
			{
				
				if(neighbor_table.neighbor_info[i] && (neighbor_table.neighbor_info[i]->type == type) )
				{
					if(memcmp(neighbor_table.neighbor_info[i]->address, address,length) == 0)
					{
						if(neighbor_table.neighbor_info[i]->child_dev == 0)
						{
							neighbor_table.child_count++;
							neighbor_table.neighbor_info[i]->child_dev=1;
						}
						return_value = CHILD;
						i=neighbor_table.count;
					}
				}
			}
		}

		if((return_value==NOT_CHILD) && (neighbor_table.child_count == NWK_MAX_CHILD) )
		{
							return_value = DISCARD_ASSOC;
		}
		if((return_value==NOT_CHILD) && (neighbor_table.child_count < NWK_MAX_CHILD))
		{
			tmp_8=neighbor_table.count;
			neighbor_table.neighbor_info[tmp_8] = neigh_buffer_get(2);
			if(neighbor_table.neighbor_info[tmp_8])
			{
#ifdef CELLSENSOR
				if(type==ADDR_802_15_4_PAN_LONG)
				{
						neighbor_table.neighbor_info[tmp_8]->address[0] = address[0];
						neighbor_table.neighbor_info[tmp_8]->address[1] = address[1];
						neighbor_table.neighbor_info[tmp_8]->address[2] = address[2];
						neighbor_table.neighbor_info[tmp_8]->address[3] = address[3];
				}
				else
				{
					for(j=0; j < length ; j++)
					{
						neighbor_table.neighbor_info[tmp_8]->address[j] = address[j];
#ifdef ROUTING_DEBUG
						debug_hex(address[j]);
						debug(" : ");
#endif
					}			
				}	
	#else
				if(type==ADDR_802_15_4_PAN_LONG)
				{
						length+=2;
				}
				for(j=0; j < length ; j++)
				{
					neighbor_table.neighbor_info[tmp_8]->address[j] = address[j];
#ifdef ROUTING_DEBUG
					debug_hex(address[j]);
					debug(" : ");
#endif
				}					
#endif
				/* add lqi value to neighbor */
				neighbor_table.neighbor_info[tmp_8]->last_lqi=0;
				neighbor_table.neighbor_info[tmp_8]->last_sqn = 0;
				neighbor_table.neighbor_info[tmp_8]->child_dev=1;
		#ifdef CELLSENSOR
				if(type == ADDR_802_15_4_PAN_LONG)
				{
					neighbor_table.neighbor_info[tmp_8]->ttl = 1;
				}
				if(type == ADDR_802_15_4_PAN_SHORT)
				{
					neighbor_table.neighbor_info[tmp_8]->ttl=TTL;
				}
		#else
				neighbor_table.neighbor_info[tmp_8]->ttl=TTL;
		#endif
				neighbor_table.neighbor_info[tmp_8]->type = type;
				/* Increace Neigbor count */
				tmp_8++;
				neighbor_table.count = tmp_8;
				neighbor_table.child_count++;
				if(neighbor_table.child_count == NWK_MAX_CHILD)
					return_value=NO_CAPASITY_AFTER_NEW_CHILD;
				else
					return_value=NEW_CHILD;
#ifdef ROUTING_DEBUG
				debug("\r\nNew neigbor added\r\n");
#endif
			}
		}
		free_table_semaphore();
	}
return return_value;	
}
#endif

/**
 *  Get routing info buffer.
 *
 *	\param blocktime  time to wait for buffer
 *
 *  \return           pointer to buffer, 0 on failure (all buffers allocated)
 */
#ifdef HAVE_ROUTING
route_info_t* routing_buffer_get( portTickType blocktime )
{
  route_info_t *b; 

 	if (xQueueReceive( route_info, &( b ), 0) == pdTRUE)
	{
		return b;
	}
	else if (n_route_buffer < MAX_ROUTE_INFO_COUNT)
	{
		b = pvPortMalloc(sizeof(route_info_t));
		if (b)
		{
  			memset(b, 0, sizeof(route_info_t));
			n_route_buffer++;
			return b;
		}
	}
  	else if (xQueueReceive( route_info, &( b ), blocktime / portTICK_RATE_MS) == pdTRUE)
	{
		return b;
	}
	return 0;
}
#endif
/**
 *  Free routing information buffer.
 *
 *	\param b					pointer to buffer
 *
 */
#ifdef HAVE_ROUTING
void routing_buffer_free( route_info_t *b )
{
  xQueueSend( route_info, ( void * ) &b, ( portTickType ) 0 );
}
#endif


/**
 * Check route for destination address.
 *
 * If destination address is not neighbor IP-layer checks route to destination.
 *
 * \param type indicates type of destination address mode
 * \param address destination address
 * \param r_check pointer for route check response
 */
#ifdef HAVE_ROUTING
portCHAR check_routing_table(addrtype_t type, address_t address, route_check_t *r_check )
{
	uint8_t i,j, flag=0, final_length, next_hop_addr_length=0;
	if( xSemaphoreTake( table_lock, ( portTickType ) 10 ) == pdTRUE )
	{
		/* Check destination address from routing_table */
		if(type==ADDR_802_15_4_PAN_LONG)
		{
			final_length=8;
		}
		else
		{
			final_length=2;
		}
		flag=0;
		if(routing_table.count > 0)
		{
			for(i=0; i < routing_table.count ; i++)
			{
				if(routing_table.route_info[i] && (type == routing_table.route_info[i]->dest_addr_type))
				{
			
					if(memcmp(routing_table.route_info[i]->destination, address,final_length) == 0)
					{
						flag=1;
#ifdef ROUTING_DEBUG
						debug("\r\n Route and next hop found succesfully  ");
#endif
						r_check->status=1;
						if(routing_table.route_info[i]->next_hop_addr_type==ADDR_802_15_4_PAN_LONG)
						{
							next_hop_addr_length=10;
						}
						else
						{
							next_hop_addr_length=4;
						}
						for(j=0; j < next_hop_addr_length; j++)
						{
							r_check->next_hop[j] = routing_table.route_info[i]->next_hop[j];
						}
						r_check->address_type = routing_table.route_info[i]->next_hop_addr_type;
						r_check->hop_count = routing_table.route_info[i]->hop_count;
						i=routing_table.count;
					}
				}	
			}
		}
		free_table_semaphore();
	}
	return pdTRUE;
}
#endif

/**
 * Update route info to routing table.
 *
 * If IP-layer detects that distance to originator device is over 1, then layer updates route info to routing table.
 *
 * \param type indicates type of destination address mode.
 * \param final_destination final-destination address.
 * \param next_hop next_hop address.
 * \param hop_count hop count to originator.
 * \param lqi link quality indication for next_hop.
 * \param only_check situation when received same broadcast sqn than last forwarded, now only comprare next hop address, lqi & hop count not add new route.
 */
#ifdef HAVE_ROUTING
portCHAR update_routing_table(addrtype_t final_type, address_t final_destination,addrtype_t next_hop_type, address_t next_hop, uint8_t hop_count, uint8_t lqi , uint8_t only_check)
{
	uint8_t i=0,j, tmp_8=0, final_length, next_hop_length;
	if( xSemaphoreTake( table_lock, ( portTickType ) 10 ) == pdTRUE )
	{
		if(final_type==ADDR_802_15_4_PAN_LONG)
		{
			final_length=8;
		}
		else
		{
			final_length=2;
		}
		if(next_hop_type==ADDR_802_15_4_PAN_LONG)
		{
			next_hop_length=8;
		}
		else
		{
			next_hop_length=4;
		}
		tmp_8 = 0;
		/* Predict older route information */
		if(check_time_stamp(final_type, final_destination) == pdFALSE)
		{
			tmp_8=1; /* cancel update process */
		}

		if(routing_table.count > 0 && tmp_8==0)
		{
			for(i=0; i < routing_table.count ; i++)
			{
				
				/* Check originator address from routing table */
				if(routing_table.route_info[i] && (final_type == routing_table.route_info[i]->dest_addr_type))
				{
					if(memcmp(routing_table.route_info[i]->destination, final_destination,final_length) ==0)
					{
						if(next_hop_type==routing_table.route_info[i]->next_hop_addr_type)
						{
							/* compare next hop address */
							if(memcmp(next_hop, routing_table.route_info[i]->next_hop, next_hop_length) !=0)
							{
								/* Compare hop count values */
								if(hop_count==routing_table.route_info[i]->hop_count)
								{
									if(lqi > routing_table.route_info[i]->lqi || (routing_table.route_info[i]->ttl  < (ROUTING_TTL - 2)  ))
									{
										next_hop_length+=2;
										/* added new next hop info */
										for(j=0; j < next_hop_length ; j++)
										{
											routing_table.route_info[i]->next_hop[j] = next_hop[j];
										}
										routing_table.route_info[i]->lqi=lqi;
										routing_table.route_info[i]->hop_count = hop_count;
									}
								}
								if(hop_count < routing_table.route_info[i]->hop_count)
								{
										next_hop_length+=2;
										/* added new next hop info */
										for(j=0; j < next_hop_length ; j++)
										{
											routing_table.route_info[i]->next_hop[j] = next_hop[j];
										}
										routing_table.route_info[i]->lqi=lqi;
										routing_table.route_info[i]->hop_count = hop_count;
								}
							}
							else
							{
								routing_table.route_info[i]->lqi=lqi;
								routing_table.route_info[i]->hop_count = hop_count;
							}
							tmp_8=1;
							
						}
						routing_table.route_info[i]->ttl=ROUTING_TTL;
						i=routing_table.count;
					}
				}	
			}
		}

		if(only_check==0 && (tmp_8==0 && routing_table.count < MAX_ROUTE_INFO_COUNT ))
		{
#ifdef ROUTING_DEBUG
			debug("\r\n Update route info to table");
#endif
			uint8_t count = routing_table.count;
			routing_table.route_info[count] = routing_buffer_get(2);
			if(routing_table.route_info[count])
			{
				for(j=0; j < final_length ; j++)
				{
	#ifdef ROUTING_DEBUG
					debug_hex(final_destination[j]);
					debug(" : ");
	#endif
					routing_table.route_info[count]->destination[j] = final_destination[j];		
				}
				next_hop_length+=2;
				for(j=0; j < next_hop_length ; j++)
				{
	#ifdef ROUTING_DEBUG
					debug_hex(next_hop[j]);
					debug(" : ");
	#endif
					routing_table.route_info[count]->next_hop[j] = next_hop[j];
				}
	
				routing_table.route_info[i]->next_hop_addr_type = next_hop_type;
				routing_table.route_info[i]->dest_addr_type = final_type;

				routing_table.route_info[count]->hop_count = hop_count;
				routing_table.route_info[count]->ttl=ROUTING_TTL;
				routing_table.route_info[count]->lqi=lqi;
				count++;
				routing_table.count=count;
			}
			else
			{
#ifdef ROUTING_DEBUG
				debug("All buffers are used\r\n");
#endif
			}
		}
		free_table_semaphore();
	}
return pdTRUE;
}
/**
 * Function remove specified routing information.
 *
 * \param type for address 
 * \param address for neighbour table
 */
void remove_broken_route(addrtype_t type, address_t address)
{
	uint8_t i,t,length=0;
	if( xSemaphoreTake( table_lock, ( portTickType ) 10 ) == pdTRUE )
	{
		if(type== ADDR_802_15_4_PAN_SHORT)	
			length=2;
		if(type== ADDR_802_15_4_PAN_LONG)
			length=8;

		if(routing_table.count > 0)
		{
			for(i=0; i < routing_table.count ; i++)
			{
				if(routing_table.route_info[i] && (type == routing_table.route_info[i]->dest_addr_type))
				{
					if(memcmp(routing_table.route_info[i]->destination, address,length) == 0)
					{
#ifdef ROUTING_DEBUG
						debug("\r\n Route and next hop found succesfully  ");
#endif

						routing_buffer_free(routing_table.route_info[i]);
						routing_table.route_info[i]=0;
						t=i;
						t++;
						if(routing_table.route_info[t] && t < routing_table.count)
						{
							for( ;t < neighbor_table.count; t++)
							{
								routing_table.route_info[i] = (route_info_t*)routing_table.route_info[t];
								i++;
							}							
						}
						i=routing_table.count;
						routing_table.count--;
					}
				}	
			}
		}
		free_table_semaphore();
	}
}


#endif

/**
 * Checkout routing- and neighbor tables time-stamp.
 *
 * If function detect that TTL, time to live value is coming zero it delete route or neighbor-info.
 *
 */
void check_tables_status(void *unused_parameter)
{
	uint8_t i, temp, minus_count=0, temp_index=0, t;
	if( xSemaphoreTake( table_lock, ( portTickType ) 10 ) == pdTRUE )
	{
		if(neighbor_table.count)
		{
			temp=neighbor_table.count;
			minus_count=0;
			for(i=0; i < temp; i++)
			{
				if(neighbor_table.neighbor_info[temp_index]->ttl > 1)
				{
					neighbor_table.neighbor_info[temp_index]->ttl--;
					temp_index++;
				}
				else
				{
					if(neighbor_table.neighbor_info[temp_index]->child_dev)
					{
						neighbor_table.child_count--;
					}
					neigh_buffer_free(neighbor_table.neighbor_info[temp_index]);
					neighbor_table.neighbor_info[temp_index]=0;
					minus_count++;
					t=i;
					t++;
					if(neighbor_table.neighbor_info[t] && t < neighbor_table.count)
					{
						
						neighbor_table.neighbor_info[temp_index] = (neighbor_info_t*)neighbor_table.neighbor_info[t];
					}
				}
			}
			if(minus_count)
			{
				neighbor_table.count -= minus_count;
			}
		}
#ifdef HAVE_ROUTING
		if(routing_table.count)
		{
			temp_index=0;
			temp=routing_table.count;
			minus_count=0;
			for(i=0; i < temp; i++)
			{
				if(routing_table.route_info[temp_index]->ttl > 1)
				{
					routing_table.route_info[temp_index]->ttl--;
					temp_index++;
				}
				else
				{
					routing_buffer_free(routing_table.route_info[temp_index]);
					routing_table.route_info[temp_index]=0;
					minus_count++;
					t=i;
					t++;
					if(routing_table.route_info[t] && t < routing_table.count)
					{
						
						routing_table.route_info[temp_index] = (route_info_t*)routing_table.route_info[t];
					}
				}
			}
			if(minus_count)
			{
				routing_table.count -= minus_count;
			}
		}
#endif
		free_table_semaphore();
	}
}
/**
 * Printout neighbour and routing table information.
 *
 *
 */
void print_table_information(void)
{
	if( xSemaphoreTake( table_lock, ( portTickType ) 10 ) == pdTRUE )
	{

		uint8_t i, j;
		if(neighbor_table.count)
		{
			debug("Neighbor Info count:");
			debug_hex(neighbor_table.count);
			debug("\r\n");
			debug("Child count:");
			debug_hex(neighbor_table.child_count);
			debug("\r\n");
			for(i=0; i < neighbor_table.count; i++)
			{
				if(neighbor_table.neighbor_info[i]->type== ADDR_802_15_4_PAN_LONG)
				{
					debug("Long:  ");
					for(j=0; j < 2 ; j++)
					{
						if (j) debug_put(':');
						debug_hex( neighbor_table.neighbor_info[i]->address[3-j]);
					}
					debug("  ");
					for(j=0; j < 2 ; j++)
					{
						if (j) debug_put(':');
						debug_hex( neighbor_table.neighbor_info[i]->address[1-j]);
					}
					
				}
				if(neighbor_table.neighbor_info[i]->type == ADDR_802_15_4_PAN_SHORT)
				{
					debug("Short:  ");
					for(j=0; j < 2 ; j++)
					{
						if (j) debug_put(':');
						debug_hex( neighbor_table.neighbor_info[i]->address[3-j]);
					}
					debug("  ");
					for(j=0; j < 2 ; j++)
					{
						if (j) debug_put(':');
						debug_hex( neighbor_table.neighbor_info[i]->address[1-j]);
					}
				}
				debug("\r\nlast_lqi: ");
				debug_hex(neighbor_table.neighbor_info[i]->last_lqi);
				debug("\r\nTTL: ");
				debug_hex(neighbor_table.neighbor_info[i]->ttl);
				debug("\r\n");
			}
		}
		else
		{
			debug("No Neighbor info\r\n");
		}
#ifdef HAVE_ROUTING
		uint8_t addres_length=0;
		if(routing_table.count)
		{
			
			debug("\r\nroute Info count:");
			debug_hex(routing_table.count);
			debug("\r\n");
			
			for(i=0; i < routing_table.count; i++)
			{
				debug("Dest:  ");
				if(routing_table.route_info[i]->dest_addr_type==ADDR_802_15_4_PAN_LONG)
				{
					addres_length=8;
				}
				else
				{
					addres_length=2;
				}
				for(j=0; j < addres_length ; j++)
				{
					if (j) debug_put(':');
					debug_hex(routing_table.route_info[i]->destination[j]);
				}
				debug("\r\nNext hop:  ");
				if(routing_table.route_info[i]->next_hop_addr_type==ADDR_802_15_4_PAN_LONG)
				{
					addres_length=2;
				}
				else
				{
					addres_length=4;
				}
				for(j=0; j < addres_length ; j++)
				{
					if (j) debug_put(':');
					debug_hex(routing_table.route_info[i]->next_hop[j]);
				}
	
				debug("\r\nlqi: ");
				debug_hex(routing_table.route_info[i]->lqi);
				debug("\r\nHop count:  ");
				debug_hex(routing_table.route_info[i]->hop_count);
				debug("\r\nTTL: ");
				debug_hex(routing_table.route_info[i]->ttl);
				debug("\r\n");
			}
		}
		else
		{
			debug("No route info\r\n");
		}
#else
		debug("Routing disable\r\n");
#endif
		//xSemaphoreGive( table_lock );
		free_table_semaphore();
	}
}

#ifdef MAC_FFD
#ifdef HAVE_ROUTING
/**
 * Function remove specified neighbour information.
 *
 * \param type for address 
 * \param address for neighbour table
 */
void remove_broken_link(addrtype_t type, address_t address)
{
	uint8_t i,t,length=0;
	if( xSemaphoreTake( table_lock, ( portTickType ) 10 ) == pdTRUE )
	{
			if(type== ADDR_802_15_4_PAN_SHORT)	
				length=2;
			if(type== ADDR_802_15_4_PAN_LONG)
				length=8;


		if(neighbor_table.count > 0)
		{
			for(i=0; i < neighbor_table.count ; i++)
			{
				if(neighbor_table.neighbor_info[i] && (neighbor_table.neighbor_info[i]->type == type))
				{
					if(memcmp(neighbor_table.neighbor_info[i]->address, address,length) ==0)
					{
						neigh_buffer_free(neighbor_table.neighbor_info[i]);
						neighbor_table.neighbor_info[i]=0;
						t=i;
						t++;
						if(neighbor_table.neighbor_info[t] && t < neighbor_table.count)
						{
							for( ;t <neighbor_table.count; t++)
							{
								neighbor_table.neighbor_info[i] = (neighbor_info_t*)neighbor_table.neighbor_info[t];
								i++;
							}
						}
						
						i=neighbor_table.count;
						neighbor_table.count--;
					}
				}
			}
			
		}
		free_table_semaphore();
		//xSemaphoreGive( table_lock ); /*free lock*/
	}
}
/**
 * Function reason is that NanoMesh not add routing info for own neighbours.
 *
 * NanoMesh will call this function automatick when it update routing info.
 * \return pdTRUE when neighbours TTL is coming older
 * \return pdFALSE when current is Active. This time NanoMesh cancel update process.
 */
portCHAR check_time_stamp(addrtype_t type, address_t address)
{
	uint8_t i,length=0;
	
	if(type== ADDR_802_15_4_PAN_SHORT)	
		length=2;
	if(type== ADDR_802_15_4_PAN_LONG)
		length=8;

	if(neighbor_table.count > 0)
	{
		for(i=0; i < neighbor_table.count ; i++)
		{
			if(neighbor_table.neighbor_info[i] && (neighbor_table.neighbor_info[i]->type == type))
			{
				if(memcmp(neighbor_table.neighbor_info[i]->address, address,length) ==0)
				{
					if(neighbor_table.neighbor_info[i]->ttl > (TTL -2))
					return pdFALSE;
				}
			}
		}
	}
	return pdTRUE;
}
#endif /*HAVE_ROUTING*/
#endif /*MAC_FFD*/
