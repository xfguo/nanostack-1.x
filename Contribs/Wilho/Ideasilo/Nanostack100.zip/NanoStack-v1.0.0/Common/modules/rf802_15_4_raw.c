/*
    NanoStack: MCU software and PC tools for sensor networking.
		
    Copyright (C) 2006-2007 Sensinode Ltd.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

		Address:
		Sensinode Ltd.
		PO Box 1
		90571 Oulu, Finland

		E-mail:
		info@sensinode.com
*/


/**
 *
 * \file     rf802_15_4_raw.c
 * \brief    802.15.4 basic raw protocol module.
 *
 *  802.15.4 header handling and CSMA sequence: handler functions.
 *  Supports only long address format.
 *  Intended to be used as a minimal MAC layer to get maximum
 *  control over the radio channel.
 */

/*
 LICENSE_HEADER
 */


#include <string.h>
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#include "debug.h"
#include "stack.h"
#include "buffer.h"

#include "module.h"

#include "event_timer.h"
#include "rf.h"

#include "neighbor_routing_table.h"
#ifdef HAVE_ROUTING
#endif

/*
[NAME]
802_15_4_RAW

[ID]
MODULE_802_15_4_RAW,

[INFO]
#ifdef HAVE_802_15_4_RAW
  {rf_raw_init, rf_raw_handle, rf_raw_check, 0, MODULE_802_15_4_RAW, 23, ADDR_802_15_4_PAN_LONG, 0 },
#endif

[FUNCS]*/
extern portCHAR rf_raw_init(buffer_t *buf);
extern portCHAR rf_raw_handle( buffer_t *buf );
extern portCHAR rf_raw_check( buffer_t *buf );

/* correct backoff unit = 100 us*/

#define RF802_15_4_BACKOFF_TIME 1	

xQueueHandle rf_raw_txqueue;
uint8_t rf_raw_tx_state;
uint8_t rf_raw_tx_retry;
uint8_t rf_raw_tx_sequence;
uint8_t rf_raw_pan_id[2];
uint8_t rf_raw_short_address[2];
address_t rf_raw_device_address;

uint8_t rf_raw_timer_id;
extern void rf_raw_event(void *param);
extern sockaddr_t rf_mac_address;
uint8_t rf_802_15_4_create_mac_frame(buffer_t *buf);

/* MAC Header masks */
#define FC_DST_MODE			0x0C    
#define FC_DST_ADDR_NONE	0x00
#define FC_DST_16_BITS		0x08
#define FC_DST_64_BITS		0x0C
#define FC_SRC_MODE			0xC0   
#define FC_SRC_ADDR_NONE	0x00
#define FC_SRC_16_BITS		0x80
#define FC_SRC_64_BITS		0xC0 
#define FC_INTRA_PAN		0x40     
#define FC_ACK				0x20     
#define FC_SEC				0x08 
#define FC_PENDING			0x10    
#define FC_FRAME_TYPE_MASK 	0x07    
#define FC_BEACON_FRAME		0x00     
#define FC_DATA_FRAME		0x01     
#define FC_ACK_FRAME		0x02     
#define FC_COMMAND_FRAME	0x03

#ifdef SDCC_CC2430
#define rf_raw_set_param(x) (void *) NULL + x
#else
#define rf_raw_set_param(x) (void *) x
#endif

/**
 *  Standard nanostack module initalizer.
 *
 *  \return  pdTRUE    OK
 */
portCHAR rf_raw_init( buffer_t *buf )
{  
	event_t event;
	uint8_t i;
	
	if (buf) ;	
	event.process = rf_raw_event;
	event.param = (void *) 0;
	for(i=0; i<2; i++)
	{
		rf_raw_pan_id[i] = 0xff;
		rf_raw_short_address[i] = 0xff;
	}
	rf_raw_tx_state = 0;
	rf_raw_tx_sequence = 0;
	rf_raw_tx_retry = 0;
	rf_raw_timer_id = evtTimerAlloc(events, sizeof(event_t));
	rf_raw_txqueue = xQueueCreate( 4, sizeof( buffer_t * ) );
	evtTimerStart(rf_raw_timer_id, (uint8_t *) &event,	200 / portTICK_RATE_MS );
#ifdef RF_RAW_DEBUG
	debug("RF init done.\r\n");
#endif	
	return pdTRUE;
}

/**
 *  Standard nanostack buffer handler.
 *
 *	\param   buf      Buffer to process
 *  \return  pdTRUE   Buffer handled by this module
 *  \return  pdFALSE	Buffer rejected by module
 */
portCHAR rf_raw_handle( buffer_t *buf )
{
  	/* Process the packet */
 	uint8_t i, tmp_8, fcf[2], ack_req=0, header_size;
	uint8_t sqn = 0;
  	uint8_t ind;
	portCHAR ret_value;
	sockaddr_t device_own_address;
	address_t dest_address;
#ifdef HAVE_ROUTING
#endif
		
#ifdef RF_RAW_DEBUG
			debug("802_15_4_RAW: handler.\r\n");
#endif
	switch(buf->dir)
	{
		case BUFFER_DOWN:
#ifdef RF_RAW_DEBUG
			debug("down: ");
#endif		
			if ((buf->buf_end - buf->buf_ptr) > 0)
			{
				header_size=0;
				header_size = rf_802_15_4_create_mac_frame(buf); /* Create mac data frame */
				if(header_size==0)
				{
					stack_buffer_free(buf);
					return pdTRUE;

				}
#ifdef RF_RAW_DEBUG
				debug(" ptr: ");
				debug_int(buf->buf_ptr);
				debug(" end: ");
				debug_int(buf->buf_end);
				debug("\r\nDst: ");
				for(i=0; i < 8; i++)
				{
					if (i) debug_put(':');
					debug_hex(buf->dst_sa.address[7-i]);
				}
				debug("\r\nSrc: ");
				for(i=0; i < 8; i++)
				{
					if (i) debug_put(':');
						debug_hex(buf->src_sa.address[7-i]);
				}
				debug("\r\n");
#endif
				if (rf_raw_tx_state == 1)
				{	/*tx ready*/
					event_t event;
					if (uxQueueMessagesWaiting(rf_raw_txqueue))
					{ /*Get from queue*/
#ifdef RF_RAW_DEBUG
						debug("Buffer from queue.\r\n");
#endif
						if (xQueueSend(rf_raw_txqueue, &buf,0) == pdFALSE)
						{
							stack_buffer_push(buf);
						}
						
						xQueueReceive(rf_raw_txqueue, &buf,0);
					}
					ret_value = rf_write(buf);
					rf_raw_tx_state = 5;
	
					event.process = &rf_raw_event;
					event.param = rf_raw_set_param(5);

					evtTimerStart(rf_raw_timer_id, (uint8_t *) &event,	10);
				}
				else
				{
				 	ret_value = pdTRUE+1;
					rf_raw_tx_retry--; /*not retried, keep same*/
				}
				
				if (ret_value == pdTRUE)
				{
					stack_buffer_free(buf);
					buf = 0;
				}
				else
				{
					buf->buf_ptr += header_size; /* restore header space */
					
					if (ret_value == pdTRUE+1)
					{
						event_t event;
						
						rf_raw_tx_retry++;
						if (rf_raw_tx_retry > 3) rf_raw_tx_retry = 3;
						if (xQueueSend(rf_raw_txqueue, &buf, 1) == pdTRUE)
						{
#ifdef RF_RAW_DEBUG
							debug("802_15_4_RAW: Buffer to waiting queue.\r\n");
#endif
							buf = 0;
							if (rf_raw_tx_state == 1)
							{
#ifdef RF_RAW_DEBUG
								debug("802_15_4_RAW: Backoff.\r\n");
#endif
								event.process = rf_raw_event;
								event.param = rf_raw_set_param(3);

								evtTimerStart(rf_raw_timer_id, (uint8_t *) &event,	1);
							}
							else
							{
#ifdef RF_RAW_DEBUG
								debug("802_15_4_RAW: Channel free state.\r\n");
#endif
								if (evtTimerCheck(rf_raw_timer_id) == pdFALSE)
								{
									event.process = rf_raw_event;
									event.param = rf_raw_set_param(5);

									evtTimerStart(rf_raw_timer_id, (uint8_t *) &event,	5);
								}
							}
						}
						if (buf) stack_buffer_push(buf); /*if tx queue full, push to stack*/
					}
					else stack_buffer_push(buf);
					
					return pdTRUE;
				}
			}
			break;

		case BUFFER_UP:			/* From driver */
			ind = buf->buf_ptr;
			
			fcf[0] = buf->buf[ind++];
			fcf[1] = buf->buf[ind++];
			sqn = buf->buf[ind++]; 
#ifdef RF_RAW_DEBUG
			debug("Up -> Seq:");
			debug_int(sqn);
			debug(". ");
			debug(" ptr: ");
			debug_int(buf->buf_ptr);
			debug(" end: ");
			debug_int(buf->buf_end);
			debug("\r\nDst: ");
#endif
			ack_req = (fcf[0] & FC_ACK);
			switch (fcf[1] & FC_DST_MODE)
			{
				case FC_DST_ADDR_NONE:
					break;			
				case FC_DST_64_BITS:
				
					buf->dst_sa.address[8] = buf->buf[ind++];
					buf->dst_sa.address[9] = buf->buf[ind++];				
					for (i = 0; i < 8 ; i++)
					{
						buf->dst_sa.address[i] = buf->buf[ind++];
						device_own_address.address[i] = rf_raw_device_address[i];	/* For destination match */

					}
					device_own_address.address[8] = rf_raw_pan_id[0];
					device_own_address.address[9] = rf_raw_pan_id[1];
					buf->dst_sa.addr_type = ADDR_802_15_4_PAN_LONG;
					device_own_address.addr_type = ADDR_802_15_4_PAN_LONG;
					break;

				case FC_DST_16_BITS:
					for (i = 0; i < 2 ; i++)
					{
						buf->dst_sa.address[2+i] = buf->buf[ind++];
					}
					for (i = 0; i < 2 ; i++)
					{
						buf->dst_sa.address[i] = buf->buf[ind++];
						device_own_address.address[i] = rf_raw_short_address[i];	/* For destination match */
					}
					buf->dst_sa.addr_type = ADDR_802_15_4_PAN_SHORT;
					device_own_address.addr_type = ADDR_802_15_4_PAN_SHORT;
					device_own_address.address[2] = rf_raw_pan_id[0];
					device_own_address.address[3] = rf_raw_pan_id[1];
					break;

				default:
					break;
			}
			buf->dst_sa.port = 0;

			switch (fcf[1] & FC_SRC_MODE)
			{
				case FC_SRC_ADDR_NONE:
					buf->src_sa.addr_type = ADDR_NONE;
					break;

				case FC_SRC_64_BITS:
					if(fcf[0] & FC_INTRA_PAN)
					{
						if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_SHORT)
						{
							buf->src_sa.address[8]=buf->dst_sa.address[2];
							buf->src_sa.address[9]=buf->dst_sa.address[3];
						}
						if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_LONG)
						{
							buf->src_sa.address[8]=buf->dst_sa.address[8];
							buf->src_sa.address[9]=buf->dst_sa.address[8];
						} 
					}
					else
					{
						buf->src_sa.address[8]=buf->buf[ind++];
						buf->src_sa.address[9]=buf->buf[ind++]; 
					}
					for (i = 0; i < 8 ; i++)
					{
						buf->src_sa.address[i] = buf->buf[ind++];
					}
#ifdef HAVE_ROUTING
					for(i=0; i<10; i++)
					{	
						dest_address[i]=buf->src_sa.address[i];
					}
#endif
					buf->src_sa.addr_type = ADDR_802_15_4_PAN_LONG;
					break;

				case FC_SRC_16_BITS:
					if(fcf[0] & FC_INTRA_PAN)
					{
						if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_SHORT)
						{
							buf->src_sa.address[2]=buf->dst_sa.address[2];
							buf->src_sa.address[3]=buf->dst_sa.address[3];
						}
						if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_LONG)
						{
							buf->src_sa.address[2]=buf->dst_sa.address[8];
							buf->src_sa.address[3]=buf->dst_sa.address[8];
						} 
					}
					else
					{
						buf->src_sa.address[2]=buf->buf[ind++];
						buf->src_sa.address[3]=buf->buf[ind++]; 
					}
					for (i = 0; i < 4 ; i++)
					{
						buf->src_sa.address[i] = buf->buf[ind++];
					}
#ifdef HAVE_ROUTING
					for(i=0; i<4; i++)
					{	
						dest_address[i]=buf->src_sa.address[i];
					}
#endif
					buf->src_sa.addr_type = ADDR_802_15_4_PAN_SHORT;
					break;

				default:
					break;
			}
#ifdef RF_RAW_DEBUG
			if (buf->dst_sa.addr_type == ADDR_802_15_4_PAN_SHORT)
			{
				tmp_8 = 4;
			}
			else 
			{
				tmp_8 = 8;
			}
			for(i=0; i<tmp_8; i++)
			{
				if (i) debug_put(':');
					debug_hex(buf->dst_sa.address[i]);
			}
			if (buf->src_sa.addr_type == ADDR_802_15_4_PAN_SHORT)
			{
				tmp_8 = 4;
			}
			else 
			{
				tmp_8 = 8;
			}
			debug("\r\nSrc: ");
			for(i=0; i<tmp_8; i++)
			{
				if (i) debug_put(':');
					debug_hex(buf->src_sa.address[i]);
			}
			debug("\r\n");
#endif

#ifdef HAVE_ROUTING
			if(buf->options.rf_lqi)
			{
				if(buf->src_sa.addr_type != ADDR_NONE)
				{
					i=update_neighbour_table(buf->src_sa.addr_type, dest_address, buf->options.rf_lqi, sqn);
				}
			}
#endif
			buf->src_sa.port = 0;

				switch(fcf[0] & FC_FRAME_TYPE_MASK)
				{

				case FC_BEACON_FRAME: /*beacon frame*/
#ifdef RF_RAW_DEBUG
					debug("802_15_4_RAW: Beacon frame.\r\n");
#endif
					tmp_8 = 0;
					break;

				case FC_DATA_FRAME: /*data frame*/
#ifdef RF_RAW_DEBUG
					debug("802_15_4_RAW: Data frame.\r\n");
#endif
					/* Read the packet payload */
					buf->buf_ptr = ind; /*cut header*/
#ifndef HAVE_NRP
					tmp_8 = 0;
					if(stack_compare_address(&device_own_address, &buf->dst_sa) == pdTRUE)
					{
						tmp_8 = 1;
#ifndef RF_AUTO_ACK
						if(ack_req)
						{
							rf_send_ack(0);
						}
#endif
					}
					/*tmp_8 = 1;*/
#else
					tmp_8 = 1;
					if(device_own_address.addr_type != ADDR_802_15_4_PAN_SHORT)
					{
						//buf->dst_sa.addr_type = ADDR_802_15_4_PAN_LONG;
						if(stack_compare_address(&device_own_address, &buf->dst_sa) == pdTRUE)
						{
							if(ack_req)
							{
								rf_send_ack(0);
							}
						}
					}
					buf->from = MODULE_802_15_4_RAW;
					buf->to = MODULE_NONE;
					buf->dir = BUFFER_UP;
					stack_buffer_push(buf);
					buf = 0;
#endif
					break;

				case FC_ACK_FRAME: /*ack frame*/
#ifdef RF_RAW_DEBUG
					debug("802_15_4_RAW: ACK frame.\r\n");
#endif
					tmp_8 = 0;
					break;

				case FC_COMMAND_FRAME: /*command frame*/
#ifdef RF_RAW_DEBUG
					debug("Command frame.\r\n");
#endif
					tmp_8 = 0;
					break;

				default:
#ifdef RF_RAW_DEBUG
					debug("802_15_4_RAW: Unknown frame.\r\n");
#endif
					tmp_8 = 0;
					break;
			}
			if (tmp_8 && buf)
			{
				buf->from = MODULE_802_15_4_RAW;
				buf->to = MODULE_NONE;
				buf->dir = BUFFER_UP;
				stack_buffer_push(buf);
				buf = 0;
			}
			else
			{
#ifdef RF_RAW_DEBUG
				debug("802_15_4_RAW: Free buffer.\r\n");
#endif
				stack_buffer_free(buf);
				buf=0;
			}
			break;
	} 
  return pdTRUE;  
}


/**
 *  Standard nanostack buffer checker.
 *
 *	\param   buf      Buffer to process
 *  \return  pdTRUE   Buffer passed module check
 *  \return  pdFALSE	Buffer rejected by module
 */
portCHAR rf_raw_check( buffer_t *buf )
{
  if(buf);

	return pdFALSE;  
}

/**
 *  MAC event handler.
 *
 *	\param   param    Message ID
 *
 */
void rf_raw_event(void *param)
{
	uint8_t id,i;
	event_t event;
#ifdef RF_AUTO_ACK
	sockaddr_t address;
#endif	
	event.process = rf_raw_event;
	
	id = (uint8_t) ((uint16_t)param);
	
	switch (id)
	{
		buffer_t *buffer;
		
		case 0:
			rf_init();
			event.param = rf_raw_set_param(1);
			evtTimerStart(rf_raw_timer_id, (uint8_t *) &event,	100);
			rf_raw_tx_state = 1;
			for(i=0; i<8; i++)
			{
				rf_raw_device_address[i] = rf_mac_address.address[7-i];
			}
#ifdef RF_AUTO_ACK
			if(rf_address_decoder_mode(1) == pdTRUE)
			{
				for(i=0; i<4;i++)
				{
					address.address[i]= 0xff;
				}
				address.addr_type = ADDR_802_15_4_PAN_SHORT;
				rf_set_address(&address);
				for(i=0; i<8;i++)
				{
					address.address[i]= rf_raw_device_address[i];
				}
				for(i=0; i<2;i++)
				{
					address.address[8+i]= 0xff;
				}
				address.addr_type = ADDR_802_15_4_LONG;
				rf_set_address(&address);
			}
#endif
			break;
		
		case 5:
			rf_raw_tx_state = 1;
		case 1:
			event.param = rf_raw_set_param(1);
			if (uxQueueMessagesWaiting(rf_raw_txqueue))
			{
				if (rf_raw_tx_state != 1) rf_raw_tx_state = 1;
				if (xQueueReceive(rf_raw_txqueue, &buffer,0) == pdTRUE)
				{
					stack_buffer_push(buffer);
#ifdef RF_RAW_DEBUG
				debug_printf("802_15_4_RAW: Tx queue: %d.\r\n", uxQueueMessagesWaiting(rf_raw_txqueue));
#endif
				}
				evtTimerStart(rf_raw_timer_id, (uint8_t *) &event,	5);
			}
			else
			{
				if (rf_raw_tx_state != 1) rf_raw_tx_state = 1;
				evtTimerStart(rf_raw_timer_id, (uint8_t *) &event,	50);
			}
			break;

		case 2:
			rf_rx_disable();
			event.param = rf_raw_set_param(3);
			rf_raw_tx_state = 2;
			evtTimerStart(rf_raw_timer_id, (uint8_t *) &event,	50);
			break;

		case 3:
			rf_rx_enable();
			rf_raw_tx_state = 3;
			event.param = rf_raw_set_param(4);
			evtTimerStart(rf_raw_timer_id, (uint8_t *) &event,	1);
			break;
		
		case 4:	/*do backoff*/
			rf_raw_tx_state = 4;
			event.param = rf_raw_set_param(5);
			evtTimerStart(rf_raw_timer_id, (uint8_t *) &event,	(1 << rf_raw_tx_retry));
			break;
						
		default:
			event.param = rf_raw_set_param(0);
			rf_raw_tx_state = 0;
			evtTimerStart(rf_raw_timer_id, (uint8_t *) &event,	50);
			break;
	}
}

uint8_t rf_802_15_4_create_mac_frame(buffer_t *buf)
{
	uint8_t i , tmp_8=0, ind=0,fc[2], intra=0;
	uint8_t overflow=0;
	uint8_t header_size = 3; /* including Frame Control and sqn */
	fc[0] = FC_DATA_FRAME;

	if(buf->dst_sa.addr_type != ADDR_BROADCAST)
	{
		if(memcmp(&buf->dst_sa.address[8],rf_raw_pan_id,2 ) == 0) /* Compare PAN-IDs --> if match use intra-flag */
		{
			intra=1;
			fc[0] |= FC_INTRA_PAN;
			header_size -=2;
		}
	}

	/* Check broadcast address */
	if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_LONG)
	{
		buf->dst_sa.addr_type = ADDR_BROADCAST;
		for(i=0; i<8; i++)
		{
			if(buf->dst_sa.address[i] != 0xff)
			{
				buf->dst_sa.addr_type = ADDR_802_15_4_PAN_LONG;
				i=8;
			}
		}
	}

	/* Create Source address */
	if (buf->src_sa.addr_type == ADDR_NONE)
	{
			for (i = 0; i < 8; i++)
			{
				buf->src_sa.address[i] = rf_raw_device_address[i];
			}
			buf->src_sa.address[8] = rf_raw_pan_id[0];
			buf->src_sa.address[9] = rf_raw_pan_id[1];
			buf->src_sa.addr_type = ADDR_802_15_4_PAN_LONG;
			fc[1]  |= FC_SRC_64_BITS;
			header_size +=10;
			tmp_8=0;
	}

	/* Build frame control field */
	if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_SHORT)
	{
		fc[1] |= FC_DST_16_BITS;
		header_size += 4;
	}
	if(buf->dst_sa.addr_type == ADDR_BROADCAST)
	{
		fc[1] |= FC_DST_16_BITS;
		header_size += 4;
		buf->dst_sa.addr_type = ADDR_802_15_4_PAN_SHORT;
		for (i = 0; i < 4; i++)
		{
			buf->dst_sa.address[i]  = 0xff;
		}
	}
	if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_LONG)
	{
		fc[1] |= FC_DST_64_BITS;
		header_size += 10;
	}

	/*check that we get headroom*/
	if (stack_buffer_headroom(buf, header_size) == pdFALSE)
	{
		overflow = 1;
		return 0;
	}
	else
	{
		buf->buf_ptr -= header_size;
	}
	
	if(overflow == 0)
	{
		ind = buf-> buf_ptr;
		buf->buf[ind++] = fc[0]; 	/* FCF*/
		buf->buf[ind++] = fc[1];

		buf->buf[ind++] = rf_raw_tx_sequence;		/*packet sequence number*/
		if(rf_raw_tx_sequence == 0xff)
			rf_raw_tx_sequence=0;
		else
			rf_raw_tx_sequence++;
		/* Craete address field */
		if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_LONG )
		{
			buf->buf[ind++] = rf_raw_pan_id[0];
			buf->buf[ind++] = rf_raw_pan_id[1];
			for (i = 0; i < 8; i++)
			{
				buf->buf[ind++] = buf->dst_sa.address[i];
			}
		}
		else
		{
			buf->buf[ind++] = buf->dst_sa.address[2];
			buf->buf[ind++] = buf->dst_sa.address[3];
			for (i = 0; i < 2; i++)
			{
				buf->buf[ind++] = buf->dst_sa.address[i];
			}
		}
		
		if(buf->src_sa.addr_type == ADDR_802_15_4_PAN_LONG)
		{
			if(intra==0)
			{
				buf->buf[ind++] = buf->src_sa.address[8];
				buf->buf[ind++] = buf->src_sa.address[9];
			}
			for (i = 0; i < 8; i++)
			{
				buf->buf[ind++] = buf->src_sa.address[i];
			}
		}
		else
		{
			if(intra==0)
			{
				buf->buf[ind++] = buf->src_sa.address[2];
				buf->buf[ind++] = buf->src_sa.address[3];
			}
			for (i = 0; i < 2; i++)
			{
				buf->buf[ind++] = buf->src_sa.address[i];
			}
		}
	}
	return header_size;
}

