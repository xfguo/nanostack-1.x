/*
    NanoStack: MCU software and PC tools for sensor networking.
		
    Copyright (C) 2006-2007 Sensinode Ltd.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

		Address:
		Sensinode Ltd.
		PO Box 1
		90571 Oulu, Finland

		E-mail:
		info@sensinode.com
*/


/**
 *
 * \file     icmp.c
 * \brief    ICMP protocol module.
 *
 *  Module includes Echo Req/Response... .
 */

/*
 LICENSE_HEADER
 */


#include <string.h>
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#include "debug.h"
#include "stack.h"
#include "control_message.h"
#include "neighbor_routing_table.h"
#include "cipv6.h"

/*
[NAME]
ICMP

[ID]
MODULE_ICMP,

[INFO]
#ifdef HAVE_ICMP
  {icmp_init, icmp_handle, icmp_check, 0, MODULE_ICMP, 16, ADDR_NONE, 0 },
#endif

[FUNCS]*/
extern portCHAR icmp_init(buffer_t *buf);
extern portCHAR icmp_handle( buffer_t *buf );
extern portCHAR icmp_check( buffer_t *buf );
uint8_t gateway_features;

void icmp_ctrl_message_to_mac(buffer_t *buf, mac_control_id_t message_id , uint16_t parameter);
/**
 *  Initialize ICMP module.
 *
 *  \return  pdTRUE    OK
 */
portCHAR icmp_init( buffer_t *buf )
{
	gateway_features=0;
	return pdTRUE;
}

/**
 *  Main ICMP buffer handler.
 *
 *	\param buf pointer to buffer
 *  \return  pdTRUE    OK
 */
portCHAR icmp_handle( buffer_t *buf )
{
	uint8_t i, ind=0, dest_length=0, icmp_type=0, icmp_code=0,length=0;
	uint16_t temp_16, echo_id, echo_sqn;
	uint8_t *dptr;
	control_message_t *ptr;
#ifdef ICMP_DEBUG	
	debug("ICMP: handler.\r\n");
#endif	
	if(buf->options.type == BUFFER_CONTROL && buf)		/* Control message received */
	{	/* Control-message */
		ptr = ( control_message_t*) buf->buf;
		switch(ptr->message.ip_control.message_id)
		{
#ifdef HAVE_ROUTING
			case ROUTER_DISCOVER:
#ifdef ICMP_DEBUG
				debug("Control: Router discover\r\n");
#endif
				buf->buf_ptr = 0;
				buf->buf_end = 8;
				memset(buf->buf, 0, 8);
				dptr = buf->buf + buf->buf_ptr;
				*dptr++ = ROUTER_SOLICICATION_TYPE;
				*dptr++ = ICMP_CODE;
				buf->dst_sa.addr_type = ADDR_BROADCAST;
				for (i=0; i <4; i++)
				{
					buf->dst_sa.address[i] = 0xff;
				}
				break;

			case BROKEN_LINK:
#ifdef ICMP_DEBUG
				debug("Control: Broken link mes create & send\r\n");
#endif
				length = 24;
				memset(buf->buf, 0, 24);
				dptr = buf->buf;
				buf->buf_ptr = 0;
				buf->buf_end = 24;
				*dptr++ = ICMP_ERROR_MESSAGE_TYPE;
				*dptr++ = ERROR_CODE_BROKEN_LINK;
				dptr += 6;
				/* Error packet destination address */
				*dptr++ = 0xfe;
				*dptr++ = 0x80;
				dptr += 6;
				if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_LONG)
				{
					for(i=0;i<8;i++)
					{
						*dptr++ = buf->dst_sa.address[7-i];
					}
				}
				else
				{
					dptr += 3;
					*dptr++ = 0xff;
					*dptr++ = 0xfe;
					dptr += 1;
					*dptr++ = buf->dst_sa.address[1];
					*dptr++ = buf->dst_sa.address[0];
				}

				buf->dst_sa.addr_type = buf->src_sa.addr_type;
				buf->src_sa.addr_type = ADDR_NONE;
				if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_LONG)
					dest_length=8;
				else
					dest_length=2;
	
				for (i=0; i < dest_length; i++)
				{
					buf->dst_sa.address[i] = buf->src_sa.address[i];
				}
				break;
#endif
			case ECHO_REQ:
#ifdef ICMP_DEBUG
				debug("Control: Echo Req\r\n");
#endif
				if(ptr->message.ip_control.message.ip_icmp_echo_req.unicast_address==0)
				{ 
					buf->dst_sa.addr_type = ADDR_BROADCAST;
					for (i=0; i <4; i++)
					{
						buf->dst_sa.address[i] = 0xff;
					}
				}
				echo_id 	= ptr->message.ip_control.message.ip_icmp_echo_req.echo_req_id;
				echo_sqn 	= ptr->message.ip_control.message.ip_icmp_echo_req.echo_req_sqn;
				buf->buf_ptr=0;

				if(ptr->message.ip_control.message.ip_icmp_echo_req.data_length)
				{
					dptr = buf->buf;
					dptr += 8;
					length = ptr->message.ip_control.message.ip_icmp_echo_req.data_length;
					memmove(dptr, ptr->message.ip_control.message.ip_icmp_echo_req.echo_data ,length);
					buf->buf_end = (8+length);
				}
				else
				{
					buf->buf_end = 8;
				}
				dptr = buf->buf + buf->buf_ptr;

				*dptr++ = ECHO_REQUEST_TYPE;
				*dptr++ = ICMP_CODE;
				*dptr++ = 0x00;
				*dptr++ = 0x00;
				*dptr++ = (echo_id >> 8);
				*dptr++ = (uint8_t) echo_id;
				*dptr++ = (echo_sqn >> 8);
				*dptr++ = (uint8_t) echo_sqn; 
				break;

#ifdef HAVE_ROUTING
			case ROUTER_ADVER_SEND:
#ifdef ICMP_DEBUG
				debug("Control: Router adv. message send");
#endif
				if(gateway_features)
				{
					length=16;
					memset(buf->buf, 0, 16);
					buf->buf_ptr = 0;
					buf->buf_end = 16;
					buf->buf[0] = ROUTER_ADVRT_TYPE;
					buf->buf[1] = ICMP_CODE;
					buf->buf[4] = GENERAL_HOPLIMIT;
					
					buf->dst_sa.addr_type = ADDR_BROADCAST;
					for (i=0; i <4; i++)
					{
						buf->dst_sa.address[i] = 0xff;
					}
				}
				else
				{
					stack_buffer_free(buf);
					buf=0;
				}
				break;
#endif
			default:
				stack_buffer_free(buf);
				buf=0;
				break;
		}
	}
	else
	{
		switch(buf->dir)
		{
			case BUFFER_DOWN:
				stack_buffer_free(buf);
				buf=0;
				break;
	
			case BUFFER_UP:
#ifndef NO_FCS
				ind= buf->buf_ptr + 2;
				temp_16 = buf->buf[ind++];
				temp_16 <<= 8;
				temp_16 += buf->buf[ind++];
				/* Check FCS first */
				if(temp_16 && (ipv6_fcf(buf, NEXT_HEADER_ICMP6, 1) != 0xffff))
				{
#ifdef ICMP_DEBUG
					debug("FCS fail\r\n");
#endif
					stack_buffer_free(buf);
					buf=0;
				}
				else
#endif
				{
#ifdef ICMP_DEBUG
					if (temp_16 == 0)
					{
						debug("FCS disabled.\r\n");
					}					
#endif
					ind= buf->buf_ptr;
					icmp_type = buf->buf[ind++];
					icmp_code = buf->buf[ind++];
				}
#ifdef HAVE_ROUTING
				if(icmp_type == ICMP_ERROR_MESSAGE_TYPE && buf)
				{
					if(icmp_code == ERROR_CODE_BROKEN_LINK)
					{
						ipv6_address_t ipv6_address;
#ifdef ICMP_DEBUG
						debug("ICMP ERROR: Broken link\r\n");
#endif
						ind+=6;
						for(i=0; i<16; i++)
						{
							ipv6_address[i] = buf->buf[ind++];
						}
						if(ipv6_address[0] == 0xfe && ipv6_address[1] == 0x80)
						{
							if((ipv6_address[12]== 0xfe && ipv6_address[11] == 0xff) && ipv6_address[13] == 0x00)
							{

								buf->dst_sa.addr_type=ADDR_802_15_4_PAN_SHORT;
								for(i=0; i<2; i++)
								{
									//ptr->message.ip_control.message.broken_link_detect.address[i] = ipv6_address[14+i];
									buf->dst_sa.address[i] = ipv6_address[14+i];
								}
								
							}
							else
							{

								buf->dst_sa.addr_type=ADDR_802_15_4_PAN_LONG;
								for(i=0; i<8; i++)
								{
									//ptr->message.ip_control.message.broken_link_detect.address[i] = ipv6_address[8+i];
									buf->dst_sa.address[i] = ipv6_address[8+i];
								}
							}
						}
						remove_broken_route(buf->dst_sa.addr_type, buf->dst_sa.address);
						icmp_ctrl_message_to_mac(buf, BROKEN_LINK , 0); 
						stack_buffer_push(buf);
						buf = 0;
					}
					stack_buffer_free(buf);
					buf=0;
				}

				if((icmp_type==ROUTER_ADVRT_TYPE && icmp_code==0x00) && buf)
				{
#ifdef ICMP_DEBUG
					debug("Router advertise message\r\n");
#endif
					icmp_ctrl_message_to_mac(buf, ROUTER_DISCOVER_RESPONSE , 0); 
					stack_buffer_push(buf);
					buf=0;
				}

				if((icmp_type==ROUTER_SOLICICATION_TYPE && icmp_code==0x00) && buf)
				{
#ifdef CIPV6_DEBUG
					debug("Router disvover req \r\n");
#endif
					if(gateway_features)
					{
						buf->dst_sa.addr_type = buf->src_sa.addr_type;
						buf->src_sa.addr_type = ADDR_NONE;
						if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_LONG)
							dest_length=8;
						else
							dest_length=2;
		
						for (i=0; i < dest_length; i++)
						{
							buf->dst_sa.address[i] = buf->src_sa.address[i];
						}
						length=16;
						memset(buf->buf, 0, 16);
						buf->buf_ptr = 0;
						buf->buf_end = 16;
						buf->buf[0] = ROUTER_ADVRT_TYPE;
						buf->buf[1] = ICMP_CODE;
						buf->buf[4] = GENERAL_HOPLIMIT;
					}
					else
					{		
						stack_buffer_free(buf);
						buf=0;
					}								
				}
#endif
				if((icmp_type==ECHO_RESPONSE_TYPE && icmp_code==0x00) && buf)
				{
#ifdef ICMP_DEBUG
					debug("Echo response\r\n");
#endif
					ind += 4;
					temp_16 = (buf->buf[ind++]);
					temp_16 <<= 8;
					temp_16 += buf->buf[ind++];
					icmp_ctrl_message_to_mac(buf, ECHO_RES , temp_16);  
					stack_buffer_push(buf);
					buf=0;
				}
				if((icmp_type==ECHO_REQUEST_TYPE && icmp_code==0x00) && buf)
				{
#ifdef ICMP_DEBUG
					debug("Echo req->res\r\n");
#endif
					/* Copy source -> Destination field */
					buf->dst_sa.addr_type = buf->src_sa.addr_type;
					buf->src_sa.addr_type = ADDR_NONE;
					if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_LONG)
						dest_length=8;
					else
						dest_length=2;
					for (i=0; i < dest_length; i++)
					{
						buf->dst_sa.address[i] = buf->src_sa.address[i];
					}
					dptr = buf->buf + buf->buf_ptr;
					*dptr++ = ECHO_RESPONSE_TYPE;
					*dptr++ = ICMP_CODE;
					*dptr++ = 0x00;
					*dptr++ = 0x00;	
				}
			break;	
		}
	}
	/* ICMP message build and forward */
	if(buf)
	{
#ifndef NO_FCS
		uint16_t fcs=0;		/* Calculate FCS */
		
		/* IP pseudo header */
		fcs = ipv6_fcf(buf, NEXT_HEADER_ICMP6, 0);
		//fcs = general_fcf_build(buf , message, 0, length, NEXT_HEADER_ICMP6);
		/* ICMP header */
#endif /*NO_FCS*/
		/* Add FCS */
		dptr = buf->buf + (buf->buf_ptr + 2);
#ifndef NO_FCS
		*dptr++ = (fcs >> 8);
		*dptr++ = (uint8_t)fcs;
#endif /*NO_FCS*/
		buf->src_sa.addr_type = ADDR_NONE;
		buf->from = MODULE_ICMP;
		buf->to = MODULE_NONE;
		buf->dir = BUFFER_DOWN;
		buf->options.type = BUFFER_DATA;
		buf->socket=0;
		stack_buffer_push(buf);
		buf=0;
	}
	return pdTRUE;
}

portCHAR icmp_check( buffer_t *buf )
{
	if(buf->options.type == BUFFER_CONTROL)
	{
		control_message_t *ptr = ( control_message_t*) buf->buf;
		switch(ptr->message.ip_control.message_id)
		{
			

			case ECHO_REQ:
				break;
			case ROUTER_DISCOVER:
				break;

			case BROKEN_LINK:
				break;
			case ROUTER_ADVER_SEND:
				break;
			default:
				return pdFALSE;
				break;
		}
	}
	else
	{
		uint8_t icmp_type=0;
		icmp_type = buf->buf[buf->buf_ptr];
		switch(icmp_type)
		{
			case ROUTER_ADVRT_TYPE:
				break;
			case ROUTER_SOLICICATION_TYPE:
				break;

			case ECHO_REQUEST_TYPE:
				break;
			case ECHO_RESPONSE_TYPE:
				break;
			case ICMP_ERROR_MESSAGE_TYPE:
				break;
	
			default:
				return pdFALSE;
				break;
		}
	}
	return pdTRUE;
}
/**
 * Function set gateway features for ICMP module.
 *
 */
void enable_router_features( void )
{
	gateway_features=1;
}
/**
 * Function build ICMP control messages for Application.
 *
 * \param buf pointer to data
 * \param message_id message type
 * \param parameter echo response sqn use this only.
 */
void icmp_ctrl_message_to_mac(buffer_t *buf, mac_control_id_t message_id , uint16_t parameter)
{
#ifdef HAVE_ROUTING
	uint8_t i, temp;
#endif
	control_message_t *ptr;
	buf->buf_end = 0;
	buf->buf_ptr = 0;
	ptr = ( control_message_t*) buf->buf;
	ptr->message.mac_control.message_id = message_id;
	switch(message_id)
	{

		case ECHO_RES:
			ptr->message.ip_control.message.echo_response = parameter;	
			break;
#ifdef HAVE_ROUTING
		case ROUTER_DISCOVER_RESPONSE:
			ptr->message.ip_control.message.router_discover_response.address_type=buf->src_sa.addr_type;
			if(buf->src_sa.addr_type==ADDR_802_15_4_PAN_LONG)
				temp=8;
			else
				temp=2;
			for(i=0; i<temp; i++)
			{
				ptr->message.ip_control.message.router_discover_response.address[i] = buf->src_sa.address[i];
			}
			ptr->message.ip_control.message.router_discover_response.hop_distance = buf->options.hop_count;
			ptr->message.ip_control.message.router_discover_response.payload[0] = buf->src_sa.addr_type;
			ptr->message.ip_control.message.router_discover_response.payload[1] = buf->options.rf_lqi;
			break;

		case BROKEN_LINK:
			if(buf->dst_sa.addr_type ==ADDR_802_15_4_PAN_SHORT)
			{
				temp=2;
			}
			else
			{
				temp=8;
			}
			for(i=0; i<temp; i++)
			{
				ptr->message.ip_control.message.broken_link_detect.address[i] = buf->dst_sa.address[i];
			}
			ptr->message.ip_control.message.broken_link_detect.type = buf->dst_sa.addr_type;
			buf->src_sa.addr_type = ADDR_NONE;
			break;
#endif
		default:

			break;	
	}
	buf->dst_sa.addr_type=ADDR_NONE;
	buf->dst_sa.port = ICMP_CTRL_PORT;
	buf->src_sa.port = ICMP_CTRL_PORT;
	buf->options.type = BUFFER_CONTROL;
	buf->from = MODULE_ICMP;
	buf->to = MODULE_APP;
	buf->dir = BUFFER_UP;
}
