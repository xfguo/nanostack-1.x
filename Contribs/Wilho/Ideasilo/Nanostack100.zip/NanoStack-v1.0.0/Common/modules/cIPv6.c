/*
    NanoStack: MCU software and PC tools for sensor networking.
		
    Copyright (C) 2006-2007 Sensinode Ltd.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

		Address:
		Sensinode Ltd.
		PO Box 1
		90571 Oulu, Finland

		E-mail:
		info@sensinode.com
*/


/**
 *
 * \file     cIPv6.c
 * \brief    Lowpan and cIPv6 module.
 *
 *  Module includes LowPan adaptation module.
 */

/*
 LICENSE_HEADER
 */


#include <string.h>
#include <sys/inttypes.h>
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#include "debug.h"
#include "stack.h"
#include "buffer.h"
#include "address.h"

#include "module.h"
#include "neighbor_routing_table.h"
#include "control_message.h"
#include "event_timer.h"
#include "rf.h"
#include "cipv6.h"
#include "socket.h"

/*
[NAME]
CIPV6

[ID]
MODULE_CIPV6,

[INFO]
#ifdef HAVE_CIPV6
  {cipv6_init, cipv6_handle, cipv6_check, 0, MODULE_CIPV6, 41, ADDR_802_15_4_LONG, 0 },
#endif

[FUNCS]*/
extern portCHAR cipv6_init(buffer_t *buf);
extern portCHAR cipv6_handle( buffer_t *buf );
extern portCHAR cipv6_check( buffer_t *buf );

extern sockaddr_t mac_long;

cipv6_ib_t cipv6_pib;
/**
 *  Initialize cIPv6 module.
 *
 *  \return  pdTRUE    OK
 */
portCHAR cipv6_init( buffer_t *buf )
{	
	buf;
	
	cipv6_pib.own_brodcast_sqn = 0;
	cipv6_pib.last_forwarded_bc_sqn = 0xff;
	cipv6_pib.use_short_address=0;
	cipv6_pib.short_address[0] = 0xfe;
	cipv6_pib.short_address[1] = 0xff;
	cipv6_pib.use_full_compress = 1;
	routing_init();
	return pdTRUE;
}

/**
 *  Set LoWPAN's compression mode.
 *
 *  \return  pdTRUE    OK
 */
void cipv6_compress_mode( uint8_t mode )
{	
	cipv6_pib.use_full_compress = mode;
}

/**
 *  Main cUDP buffer handler.
 *
 *	\param buf pointer to buffer
 *  \return  pdTRUE    OK
 */
portCHAR cipv6_handle( buffer_t *buf )
{

	uint8_t i;
  	/* Process the packet */		
	if(cipv6_pib.own_brodcast_sqn == 0)
	{
		cipv6_pib.own_brodcast_sqn = mac_long.address[7];
	}
#ifdef CIPV6_DEBUG	
	debug("Lowpan & cIPv6: handler.\r\n");
#endif
	
	if(buf->options.type == BUFFER_CONTROL && buf)		/* Control message received */
	{	/* Control-message */
		control_message_t *ptr = ( control_message_t*) buf->buf;
		if(ptr->message.ip_control.message_id==IP_ADDRESS__MODE_SETUP)
		{
#ifdef CIPV6_CONTROL_DEBUG
			debug("\r\nControl:IP address state");
#endif
			if(cipv6_pib.use_short_address==1 && buf)
			{
				if(ptr->message.ip_control.message.address_setup.use_short_address==0) cipv6_pib.use_short_address=0;
				stack_buffer_free(buf);
				buf=0;
			}
			if(cipv6_pib.use_short_address==0 && buf)
			{
				if(ptr->message.ip_control.message.address_setup.use_short_address)
				{
					cipv6_pib.use_short_address=1;
					for(i=0; i<2;i++)
					{
						cipv6_pib.short_address[i] = ptr->message.ip_control.message.address_setup.address[i];
					}
				}
				else
				{
					for(i=0; i<8;i++)
					{
						cipv6_pib.long_address[i] = ptr->message.ip_control.message.address_setup.address[i] ;
					}
				}
				stack_buffer_free(buf);
				buf=0;
			}
		}
		if(buf)
		{
			stack_buffer_free(buf);
			buf=0;
		}
		return pdTRUE;
	}

	switch(buf->dir)
	{
		case BUFFER_DOWN:
			if(cipv6_pib.use_full_compress)
			{	
				build_lowpan_header(buf);
			}
			else
			{
				build_ipv6_header(buf);
			}
			break;

		case BUFFER_UP:			/* From Lower layer(usually RF802.15.4) */
			/* Lets check header start type */

			if(buf->options.handle_type == HANDLE_BROKEN_LINK)
			{
#ifdef HAVE_ROUTING
				ip_broken_link_notify(buf);
				buf=0;
#else
				stack_buffer_free(buf);
				buf=0;
#endif
			}

			if(buf)
			{
				if(buf->buf[buf->buf_ptr] == IPV6)
				{
					parse_ipv_header(buf);
					buf=0;
				}
				else
				{
					switch (buf->buf[buf->buf_ptr] & LOWPAN_TYPE_BM )
					{
					/* Normal unicast send-mode */
						case DISPATCH_TYPE:
							//debug("dispa\r\n");
							/* Parse Unicast packet from neighbor */
							parse_hc1_message(buf);
							break;	
			
						/* Packet deliverymode is mesh */	
						case MESH_ROUTING_TYPE: /* Mesh Routing */
							//debug("mesh\r\n");
							parse_mesh_packet(buf);
						break;	/* END_OF_MESH_ROUTING_TYPE */
			
						default:
							stack_buffer_free(buf);
						break;
					}
				}
			}
		break;
						
	}
return pdTRUE;
}

/**
 *  The cIPv6 buffer checker.
 *
 *	\param buf pointer to buffer
 *
 *  \return  pdTRUE    is cIPv6
 *  \return  pdFALSE   is not cIPv6 or broken header
 */
portCHAR cipv6_check( buffer_t *buf )
{
	uint8_t temp;
	//ind = buf->buf_ptr;
	if(buf->buf[buf->buf_ptr] == IPV6)
	{
		/* Uncompressed IPv6 header dispatch */
		return pdTRUE; 
	}
	else
	{
		temp = (buf->buf[buf->buf_ptr] & LOWPAN_TYPE_BM);
		if(temp == DISPATCH_TYPE)
		{
			return pdTRUE; 
		}
#ifdef FRAGMENTATION
		else if(temp == FRAGMENT_TYPE)
		{
			return pdTRUE; 
		}
#endif
		else if(temp == MESH_ROUTING_TYPE)
		{
			return pdTRUE; 
		}
		else
		{
			return pdFALSE;
		}
	}
}

/**
 * Function parse mesh header.
 *
 * \param buf pointer to data
 */
void parse_hc1_message(buffer_t *buf)
{
	uint8_t ind=0, lowpan_dispatch, hc1,hoplimit=0, hc2_field_check=0;
	ind = buf->buf_ptr;
	/* Check Dispatch pattern */
	lowpan_dispatch = buf->buf[ind++];
	/* Received LowPan-packet without mesh and fragmentation and using HC1 compress to IPv6  */
	if( lowpan_dispatch == LOWPAN_HC1 )
	{
#ifdef CIPV6_DEBUG	
		debug("LowPan_HC1.\r\n");
		debug("Up ->\r\n");
#endif
		/* Check HC1 options */
		hc1 = buf->buf[ind++];

		if((hc1==HC1_NEXT_HEADER_COMPRESSED_UDP || hc1 == HC1_NEXT_HEADER_UNCOMPRES_UDP)  || hc1==IP_HEADER_FOR_ICMP)
		{
			if((hc1==HC1_NEXT_HEADER_COMPRESSED_UDP || hc1 == HC1_NEXT_HEADER_UNCOMPRES_UDP))
			{
				buf->to = MODULE_CUDP;
				if(hc1 == HC1_NEXT_HEADER_COMPRESSED_UDP) /* Read udp encode field */
				{
					buf->options.lowpan_compressed = buf->buf[ind++];
					if(buf->options.lowpan_compressed==0x07 || buf->options.lowpan_compressed==0x04)
						hc2_field_check=1;
				}
				else
					hc2_field_check=1;
			}
			else
			{
				buf->to = MODULE_ICMP;
				buf->options.hop_count = 1;
			}

			hoplimit= buf->buf[ind++];
			hoplimit--;
			if((hoplimit > 0 && hc2_field_check) || buf->to == MODULE_ICMP)
			{
				buf->buf_ptr = ind; /*cut header*/
				
				buf->from = MODULE_CIPV6;
				stack_buffer_push(buf);
				buf=0;
			}
		}
	}/* END_OF_LOWPAN_HC1 */
	/* General buffer discard part */	
	if(buf)
	{
#ifdef CIPV6_DEBUG	
		debug("Discard.\r\n");
#endif
		stack_buffer_free(buf);
		buf=0;
	}
}

void parse_mesh_packet(buffer_t *buf)
{
 	/* Process the packet */
 	uint8_t tmp_8=0,mesh_header,hops_left=0,i,bc_seq=0, dest_length=0;
 	uint8_t ind=0, lowpan_dispatch, hc1,hoplimit=0,tmp,  hops_to_ori=0;
 	addrtype_t o_addrtype=0;
	address_t ori_address;
#ifdef HAVE_ROUTING
	buffer_t *forward_buffer = 0;
	uint8_t j;
#endif
	match_type_t address_mode = NOT_OWN;

#ifdef CIPV6_DEBUG		
	debug("cIPv6 Mesh routing enable.\r\n");
#endif
	
	ind = buf->buf_ptr;
	mesh_header=0;			
	mesh_header = buf->buf[ind++];
	hops_left=0;
	hops_left = (mesh_header & 0xf0);
	hops_left = hops_left >> 4;
	hops_left--;
	/* Check Originator and Final-destination address */
	tmp=(mesh_header & MESH_ADDRESSTYPE_BM);
	tmp_8 = (tmp & O_ADDRESSTYPE_BM);

	if(tmp_8 == O_ADDRESSTYPE_16)
	{
		o_addrtype=ADDR_802_15_4_PAN_SHORT;
		dest_length=2;
	}
	else
	{
		o_addrtype=ADDR_802_15_4_PAN_LONG;
		dest_length=8;	
	}

	for(i=0; i < dest_length; i++)
	{
		ori_address[i] = buf->buf[ind++];
	}
	tmp_8 = (tmp & D_ADDRESSTYPE_BM);

	if(tmp_8 == D_ADDRESSTYPE_16)
	{
		buf->dst_sa.addr_type =  ADDR_802_15_4_PAN_SHORT;
		dest_length=2;
	}
	else
	{
		buf->dst_sa.addr_type=ADDR_802_15_4_PAN_LONG;
		dest_length=8;
	}

	for(i=0; i < dest_length; i++)
	{
		buf->dst_sa.address[i] = buf->buf[ind++];
	}
	/* compare final-destination address to own address */
	address_mode = OWN;
	tmp_8 = 1;
	if(buf->dst_sa.addr_type==ADDR_802_15_4_PAN_LONG)
	{
		if (memcmp(buf->dst_sa.address, cipv6_pib.long_address, 8) != 0)
		{
			if(stack_check_broadcast(buf->dst_sa.address, ADDR_802_15_4_PAN_LONG) != pdTRUE)
			{
				tmp_8 = 0;
				address_mode = NOT_OWN;
			}
			else
			{
				tmp_8=1;
				address_mode = BCAST;
			}
		}
	}
	else
	{
		if (memcmp(buf->dst_sa.address, cipv6_pib.short_address, 2) != 0)
		{
			if(stack_check_broadcast(buf->dst_sa.address, ADDR_SHORT) != pdTRUE)
			{
				tmp_8 = 0;
				address_mode = NOT_OWN;
			}
			else
			{
				tmp_8=1;
				address_mode = BCAST;
			}
		}
	}
	switch (address_mode)
	{
		case OWN: /* we are final destination */
		case BCAST:
			lowpan_dispatch=0;
			lowpan_dispatch = buf->buf[ind++];
			bc_seq=0;
			if(lowpan_dispatch == LOWPAN_BC0)
			{
				bc_seq = buf->buf[ind++];
				lowpan_dispatch=0;
				lowpan_dispatch = buf->buf[ind++];
			}
				if(lowpan_dispatch == LOWPAN_HC1)
				{
					/* Check HC1 options */
					hc1= buf->buf[ind++];
					if((hc1 == HC1_NEXT_HEADER_COMPRESSED_UDP || hc1 == HC1_NEXT_HEADER_UNCOMPRES_UDP) || hc1 == IP_HEADER_FOR_ICMP)
					{
						if(hc1 == IP_HEADER_FOR_ICMP)
						{
							buf->to = MODULE_ICMP;
						}
						else
						{
							buf->to = MODULE_CUDP;
							if(hc1 == HC1_NEXT_HEADER_COMPRESSED_UDP) /* Read udp encode field */
							{
								buf->options.lowpan_compressed = buf->buf[ind++];
							}
						}
						hoplimit= buf->buf[ind];
						hoplimit--;
						buf->buf[ind] = hoplimit;
						ind++;
						hops_to_ori = (GENERAL_HOPLIMIT - hoplimit);
						if(hc1 == IP_HEADER_FOR_ICMP) 
							buf->options.hop_count = hops_to_ori;
#ifdef HAVE_ROUTING

#ifdef CIPV6_DEBUG
						debug("\r\n Hops to originator ");
						debug_hex(hops_to_ori);
						debug("\r\n");
#endif
						if(hops_to_ori > 1 && buf->options.rf_lqi > 0x15)
						{
							/* check own */
							if(compare_ori_to_own(o_addrtype, ori_address) != pdTRUE)
							{
								tmp_8=0;
								if(bc_seq && (bc_seq == cipv6_pib.last_forwarded_bc_sqn))
									tmp_8=1;

								update_routing_table( o_addrtype, ori_address, buf->src_sa.addr_type, buf->src_sa.address,  hops_to_ori, buf->options.rf_lqi, tmp_8);
							}
						}
#endif
						/* Copy originator address to src field */
						if(o_addrtype == ADDR_802_15_4_PAN_LONG)
							memcpy(buf->src_sa.address,ori_address, 8);
						else
							memcpy(buf->src_sa.address,ori_address, 2);

						buf->src_sa.addr_type = o_addrtype;
						if(address_mode == BCAST)
						{
							/* Check sequence number if same than last sent/forwarded discard buffer */
							if(bc_seq != cipv6_pib.last_forwarded_bc_sqn )
							{
#ifdef HAVE_ROUTING
								if(hops_left > 0)
								{
									forward_buffer=0;
									/* Get new buffer for forwarding */
									forward_buffer = stack_buffer_get(20);
									if (forward_buffer)
									{
										/* Copy original buffer for forwarding */
										memcpy(forward_buffer, buf, sizeof(buffer_t) + buf->buf_end);
										i = (uint8_t)forward_buffer->buf_ptr;
										j = (mesh_header & 0x0f);
										hops_left = hops_left << 4;
										forward_buffer->buf[i] = (j + hops_left);
										forward_buffer->src_sa.addr_type = ADDR_NONE;
										forward_buffer->dst_sa.addr_type = ADDR_BROADCAST;
										forward_buffer->from = MODULE_CIPV6;
										forward_buffer->to = MODULE_NONE;
										forward_buffer->dir = BUFFER_DOWN;
										forward_buffer->options.type = BUFFER_DATA;
										cipv6_pib.last_forwarded_bc_sqn = bc_seq;
										stack_buffer_push(forward_buffer);
										forward_buffer=0;
									}
									else
										debug("no buffer\r\n");
								}
#endif
								buf->buf_ptr = ind;
								buf->to = MODULE_NONE;
								buf->from = MODULE_CIPV6;
								stack_buffer_push(buf);
								buf=0;
							}
							else
							{
								stack_buffer_free(buf);
								buf=0;
							}
						}
						if(buf)
						{
							//if((hoplimit >= 1 && bc_seq==0) || bc_seq != cipv6_pib.last_forwarded_bc_sqn)
							if(hoplimit >= 1 )
							{
								buf->buf_ptr = ind; /*cut header*/
								buf->from = MODULE_CIPV6;
								buf->to = MODULE_NONE;
								stack_buffer_push(buf);
								buf=0;
							}
						}
					}
				}
		break;
		case NOT_OWN:/* We are not final destination */
#ifndef HAVE_NRP
#ifdef HAVE_ROUTING
			if(hops_left > 0)
			{
				/* Route packet */
				route_packet(buf, ori_address, o_addrtype, mesh_header, hops_left, ind);
				buf=0;
			}
			else
			{
				stack_buffer_free(buf);
				buf=0;
			}
#endif /*HAVE_ROUTING*/
#endif/*HAVE_NRP*/
		break;
	}
	/* Discard buffer */
	if(buf)
	{
		stack_buffer_free(buf);
		buf=0;
	}
}


#ifdef HAVE_ROUTING
/**
 * Function forward mesh packet.
 *
 * \param buf pointer to data
 * \param ori_address address to orginator
 * \param o_addrtype originator address type
 * \param mesh_header prebuilded mesh header for packet
 * \param hops_left if zero function doesn't forward packet
 * \param ind buffer table index
 *
 * \return fcf 16-values
 */
void route_packet(buffer_t *buf, address_t ori_address, addrtype_t o_addrtype, uint8_t mesh_header, uint8_t hops_left, uint8_t ind)
{
 	/* Process the packet */
 	dest_delivery_t destination_delivery = NOT_NEIGHBOR;	
 	uint8_t tmp_8=0,i,bc_seq=0, dest_length=0;
 	uint8_t lowpan_dispatch, hc1,hoplimit=0,tmp, hops_to_ori=0;

	route_check_t route_check;
 	route_check.status=0;

	/* Check which is next header */
	lowpan_dispatch=0;
	lowpan_dispatch = buf->buf[ind++];
	bc_seq=0;
	if(lowpan_dispatch==LOWPAN_BC0)
	{	
		bc_seq = buf->buf[ind++];
		lowpan_dispatch=0;
		lowpan_dispatch = buf->buf[ind++];
	}

	if(lowpan_dispatch==LOWPAN_HC1)
	{
		/* How many hops to originator address device */
		hc1 = buf->buf[ind++];
	
		if((hc1 == HC1_NEXT_HEADER_COMPRESSED_UDP || hc1 == HC1_NEXT_HEADER_UNCOMPRES_UDP) || hc1 == IP_HEADER_FOR_ICMP)
		{
			if(hc1 == HC1_NEXT_HEADER_COMPRESSED_UDP)
				buf->options.lowpan_compressed = buf->buf[ind++];

			hoplimit= buf->buf[ind];
			hoplimit--;
			buf->buf[ind] = hoplimit;
			ind++;
			hops_to_ori = 0;
			hops_to_ori = (GENERAL_HOPLIMIT - hoplimit);
#ifdef CIPV6_DEBUG
			debug("\r\n Hops to originator ");
			debug_hex(hops_to_ori);
			debug("\r\n");
#endif
			if(hops_to_ori > 1 && buf->options.rf_lqi > 0x15)
			{
				/* check own */
				if(compare_ori_to_own(o_addrtype, ori_address) != pdTRUE)
				{
					tmp_8=0;
					if(bc_seq == cipv6_pib.last_forwarded_bc_sqn) tmp_8=1;

					update_routing_table( o_addrtype, ori_address, buf->src_sa.addr_type, buf->src_sa.address,  hops_to_ori, buf->options.rf_lqi, tmp_8);
				}
			}
			/* Check sequence number if same than last sent/forwarded discard buffer */
			if(bc_seq != cipv6_pib.last_forwarded_bc_sqn || bc_seq==0)
			{
				if(bc_seq) cipv6_pib.last_forwarded_bc_sqn = bc_seq;
					/* Check if address is neighbors */
					destination_delivery = check_neighbour_table(buf->dst_sa.addr_type, buf->dst_sa.address );

					if(destination_delivery == NOT_NEIGHBOR)
					{
						//debug("not neigh\r\n");
						/* Check destination address from routing_table */
						route_check.status = 0;
						check_routing_table(buf->dst_sa.addr_type, buf->dst_sa.address, &route_check );
						if(route_check.status == 0)
						{

							buf->dst_sa.addr_type = ADDR_BROADCAST;
							/* When received unicast packet */
							if(bc_seq==0)
								buf->buf_ptr -= 2;
							else
								cipv6_pib.last_forwarded_bc_sqn = bc_seq;
							/* GENERAL PART */
							ind = buf->buf_ptr;
							tmp = (mesh_header & 0x0f);
							hops_left = hops_left << 4;
							buf->buf[ind] = (hops_left | tmp);
							bc_seq=1;
						}
						if(route_check.status == 1)
						{
#ifdef CIPV6_DEBUG
							debug("\r\nI know route\r\n");
#endif
							/* When mesh flooding --> Unicast */
							if(bc_seq)
								buf->buf_ptr += 2;
							/* GENERAL PART */
							ind = buf-> buf_ptr;
							tmp=(mesh_header & 0x0f);
							hops_left = hops_left << 4;
							buf->buf[ind++] = (hops_left | tmp);
							if(route_check.address_type==ADDR_802_15_4_PAN_SHORT)
								dest_length=2;
							else
								dest_length=8;
							/* Change next-hop address to rf_802_15_4 dest_address */
							for(i=0;i < dest_length; i++)
							{
								buf->dst_sa.address[i] = route_check.next_hop[i];
							}
							buf->dst_sa.addr_type = route_check.address_type;
							bc_seq=0;
						}
					}
					if(destination_delivery == NEIGHBOR)
					{
						/* When mesh flooding --> Unicast */
						if(bc_seq)
						{
							buf->buf_ptr += 2;
						}
						ind = buf->buf_ptr;
						tmp = (mesh_header & 0x0f);
						hops_left = hops_left << 4;
						buf->buf[ind++] = (hops_left | tmp);
						bc_seq=0;
					}
					/* Generally part for routing case */
					/* Originator address */
					if(o_addrtype==ADDR_802_15_4_PAN_SHORT)
						ind=stack_insert_address_to_buffer(buf, ind, ADDR_802_15_4_SHORT, ori_address);
					else
						ind=stack_insert_address_to_buffer(buf, ind, ADDR_802_15_4_LONG, ori_address);										
					/* Final destination address */
					if(buf->dst_sa.addr_type==ADDR_802_15_4_PAN_SHORT)
						ind=stack_insert_address_to_buffer(buf, ind, ADDR_802_15_4_SHORT, buf->dst_sa.address);
					else
						ind=stack_insert_address_to_buffer(buf, ind, ADDR_802_15_4_LONG, buf->dst_sa.address);
					/* Add broadcast header if no route to destination */
					if(bc_seq)
					{
						buf->buf[ind++] = LOWPAN_BC0;
						buf->buf[ind++] = cipv6_pib.own_brodcast_sqn;
						update_ip_sqn();
					}

					buf->src_sa.addr_type = ADDR_NONE;
					buf->from = MODULE_CIPV6;
					buf->to = MODULE_NONE;
					buf->dir = BUFFER_DOWN;
					stack_buffer_push(buf);
					buf=0;
			}
		}
	}
	if(buf)
	{
#ifdef CIPV6_DEBUG	
		debug("discard\r\n");
#endif
		stack_buffer_free(buf);
		buf=0;
	}	
}
#endif

uint8_t add_own_address(uint8_t *d_ptr);

/**
 * Function build lowpan header / mesh header.
 *
 * \param buf pointer to data
 */
portCHAR build_lowpan_header(buffer_t *buf)
{
 	uint8_t mesh_header ,header_size=0;
 	dest_delivery_t destination_delivery = NOT_NEIGHBOR;	
	uint8_t *dptr;
	route_check_t route_check;
	uint8_t i, dest_length=0;
	
 	route_check.status=0;
	mesh_header = MESH_ROUTING_TYPE;
	
	header_size = 3;
	if((buf->from == MODULE_CUDP) && buf->options.lowpan_compressed)
	{
			header_size++;
	}
	
	if(cipv6_pib.use_short_address)
	{
		mesh_header |= O_ADDRESSTYPE_16;
		header_size +=2;
	}
	else
	{
		mesh_header |= O_ADDRESSTYPE_64;
		header_size +=8;
	} 

	/* Check destination address and delivery mode from neighbor table */
	switch(buf->dst_sa.addr_type)
	{
		case ADDR_COORDINATOR:
			destination_delivery = NEIGHBOR;
			break;
		
		case ADDR_BROADCAST:
			mesh_header |= D_ADDRESSTYPE_16;
			header_size +=2;
			destination_delivery = BROADCAST;
			break;
			
		case ADDR_802_15_4_PAN_SHORT:
			mesh_header |= D_ADDRESSTYPE_16;
			header_size +=2;
			goto mesh_neighbour_check;
			
		case ADDR_802_15_4_LONG:
			buf->dst_sa.addr_type = ADDR_802_15_4_PAN_LONG;			
		case ADDR_802_15_4_PAN_LONG:
			mesh_header |= D_ADDRESSTYPE_64;
			header_size +=8;

		default:
			mesh_neighbour_check:			
			/* Check neighbourtable */
			destination_delivery = check_neighbour_table(buf->dst_sa.addr_type, buf->dst_sa.address);
			if(destination_delivery==BROADCAST && buf->dst_sa.addr_type==ADDR_802_15_4_PAN_LONG)
			{
				header_size -=6;
				mesh_header &=(~ D_ADDRESSTYPE_64);
				mesh_header |=D_ADDRESSTYPE_16;
			}
			break;
	}
	switch (destination_delivery)
	{
		case NOT_NEIGHBOR:
#ifdef CIPV6_DEBUG		
			debug("\r\nNOT_NEIGHBOR");
#endif
			/* Check destination address from routing_table */
			route_check.status = 0;
#ifdef HAVE_ROUTING
			check_routing_table(buf->dst_sa.addr_type, buf->dst_sa.address, &route_check );
#endif
			/* Case when routing-table know route */ 
			if(route_check.status == 1)
			{
#ifdef HAVE_ROUTING
				header_size++;
#ifdef CIPV6_DEBUG
				debug("\r\nI know route: ");
#endif
				if(stack_buffer_headroom(buf,header_size)==pdFALSE)
				{
					stack_buffer_free(buf);
					return pdTRUE;
				}
#endif /* HAVE_ROUTING */
			}
			else
			{
				/* Case when routing-table doesn't know route */ 
				header_size+=3;
#ifdef CIPV6_DEBUG	
				debug("\r\nMESH FLOODING");
#endif
				if(stack_buffer_headroom( buf,header_size)==pdFALSE)
				{
					stack_buffer_free(buf);
					return pdFALSE;
				}
			}
			buf->buf_ptr -= header_size; /* mesh_header+address_field+HC1_DISPATCH+ HC1*/
			dptr = buffer_data_pointer(buf);
			mesh_header |= BASIC_HOP_VALUE;
			*dptr++ = mesh_header;
			/* Build Mesh delivery address field*/
			/* Originator address */
			dptr += add_own_address(dptr);
			/* Final destination address */
			if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_SHORT)
			{
				dest_length=2;
			}
			else
			{
				dest_length=8;
			}
			for(i=0; i<dest_length ;i++)
			{
				*dptr++ = buf->dst_sa.address[i];
			}
			/* Add Broadcast dispatch if necessary */
			if( route_check.status == 0)
			{
#ifndef AD_HOC_STATE /* Case when device is RFD */
				buf->dst_sa.addr_type = ADDR_COORDINATOR;
#else
				buf->dst_sa.addr_type = ADDR_BROADCAST;
#endif
				*dptr++ = LOWPAN_BC0;
				*dptr++ = cipv6_pib.own_brodcast_sqn;
				update_ip_sqn();
			}
			else
			{
				/* Change next-hop address to rf_802_15_4 dest_address */
				if(route_check.address_type == ADDR_802_15_4_PAN_LONG)
					dest_length=10;
				else
					dest_length=4;

				for(i=0;i<dest_length; i++)
				{
					buf->dst_sa.address[i]=route_check.next_hop[i];
				}
				buf->dst_sa.addr_type = route_check.address_type;
			}
			break;

		case NEIGHBOR:
#ifdef CIPV6_DEBUG	
			debug("\r\nNeighbour\r\n");
#endif				
			header_size = 3;
			if(buf->options.lowpan_compressed && buf->from == MODULE_CUDP)
				header_size++;

			if(stack_buffer_headroom(buf,header_size) == pdFALSE)
			{
				stack_buffer_free(buf);
				buf=0;
				return pdTRUE;
			}
			buf->buf_ptr -= header_size; 				/* lowpan-dispatch+HC1 = header space */
			dptr = buffer_data_pointer(buf);
			break;
			
		case BROADCAST:
#ifdef CIPV6_DEBUG	
			debug("\r\nBroadcast");
#endif
			header_size +=3;
			if(stack_buffer_headroom(buf,header_size) == pdFALSE)
			{
				stack_buffer_free(buf);
				buf=0;
				return pdTRUE;
			}
			buf->buf_ptr -= header_size; /* lowpan-dispatch+HC1 = header space */
			dptr = buffer_data_pointer(buf);
			/* Mesh frame type */
#ifdef HAVE_NRP
			*dptr++ = (mesh_header | (GENERAL_HOPLIMIT<<4));
#else

#ifdef HAVE_ROUTING
			if(buf->options.hop_count)
				*dptr++ = (mesh_header | (buf->options.hop_count<<4));
			else
				*dptr++ = (mesh_header | (1<<4));
#else
			*dptr++ = (mesh_header | (1<<4));
#endif/*HAVE_ROUTING*/
#endif/*HAVE_NRP*/
			buf->dst_sa.addr_type = ADDR_BROADCAST;
			buf->src_sa.addr_type = ADDR_NONE;
			/* Originator-address */
			dptr += add_own_address(dptr);
			/* Final-destination-address */
			*dptr++ = 0xff;
			*dptr++ = 0xff;
			
			/* Mesh broadcast header type and sequence number */
			*dptr++ = LOWPAN_BC0;
			*dptr++ = cipv6_pib.own_brodcast_sqn;
			update_ip_sqn();
			break;
		
		default:
#ifdef CIPV6_DEBUG	
			debug("no support\r\n");
#endif
			dptr = 0;
			stack_buffer_free(buf);
			buf=0;
			break;
	}
	/* General Lowpan and cIPv6 headers */
	if(buf)
	{
		*dptr++ = LOWPAN_HC1; 	/* LowPan Dispatch	 */
		/* HC1 encode */
		if(buf->from == MODULE_ICMP)
			*dptr++ = IP_HEADER_FOR_ICMP;
		else
		{
			if(buf->options.lowpan_compressed)
			{
				*dptr++ = HC1_NEXT_HEADER_COMPRESSED_UDP;
				*dptr++ = buf->options.lowpan_compressed;
			}		
			else 
				*dptr++ = HC1_NEXT_HEADER_UNCOMPRES_UDP;
		}
		*dptr++ = GENERAL_HOPLIMIT;	/* Hop-limit	*/
		buf->from = MODULE_CIPV6;
		buf->to = MODULE_NONE;
		stack_buffer_push(buf);
		buf=0;
	}
	return pdTRUE;
}

uint8_t add_own_address(uint8_t *d_ptr)
{
	uint8_t i;
	if(cipv6_pib.use_short_address)
	{
		for (i=0; i<2; i++)
		{
			*d_ptr++ = cipv6_pib.short_address[i];
		}
		return 2;
	}
	else
	{
		for (i=0; i<8; i++)
		{
			*d_ptr++ = cipv6_pib.long_address[i];
		}
		return 8;
	}
}

void update_ip_sqn(void)
{
	cipv6_pib.last_forwarded_bc_sqn = cipv6_pib.own_brodcast_sqn;
	/* Increace broadcast_counter */
	if(cipv6_pib.own_brodcast_sqn==0xff) cipv6_pib.own_brodcast_sqn=1;
	else cipv6_pib.own_brodcast_sqn++;
}

/**
 * Build IPv6 header.
 *
 * Function create whole uncompressed header and add dispatch for that --> Header size 41 byte.
 * \param buf pointer to data
 */
portCHAR build_ipv6_header(buffer_t *buf)
{
	uint8_t next_header=0, i;
	uint8_t *dptr;
	uint16_t payload_length=0;
	address_t ipv6_address;
	dest_delivery_t destination_delivery = NOT_NEIGHBOR;
	memset(ipv6_address, 0,8);
	payload_length = (buf->buf_end - buf->buf_ptr);

	if(stack_buffer_headroom( buf,41)==pdFALSE)
	{
		stack_buffer_free(buf);
		return pdTRUE;
	}
	buf->buf_ptr -= 41;
	/* Check deliverymode from neighbour table */
	if(buf->dst_sa.addr_type != ADDR_BROADCAST && buf->dst_sa.addr_type != ADDR_COORDINATOR)
	{
		destination_delivery = check_neighbour_table(buf->dst_sa.addr_type, buf->dst_sa.address);
		if(destination_delivery==BROADCAST)
		{
			buf->dst_sa.addr_type = ADDR_BROADCAST;
		}
	}
	if(buf->from == MODULE_CUDP)
		next_header = NEXT_HEADER_UDP;
	else
		next_header = NEXT_HEADER_ICMP6;

	//ind = buf->buf_ptr;
	dptr = buf->buf + buf->buf_ptr;
	*dptr++ = IPV6;
	*dptr++ = 0x06;
	*dptr++ = 0x00;
	*dptr++ = 0x00;
	*dptr++ = 0x00;
	*dptr++ = (payload_length >> 8);	
	*dptr++ = (uint8_t) payload_length;			/* Length */
	*dptr++ = next_header;
	*dptr++ = GENERAL_HOPLIMIT;
	/* Add source */
	if(cipv6_pib.use_short_address)
	{
		ipv6_address[4]=0xff;
		ipv6_address[3]=0xfe;
		ipv6_address[1]=cipv6_pib.short_address[1];
		ipv6_address[0]=cipv6_pib.short_address[0];
	}
	else
	{
		for(i=0; i<8; i++)
		{
			ipv6_address[i] = cipv6_pib.long_address[7-i];
		}
	}
	*dptr++ =0xfe;
	*dptr++ = 0x80;
	for(i=0; i<6; i++)
	{
		*dptr++ = 0x00;
	}
	for(i=0; i<8; i++)
	{
		*dptr++ = ipv6_address[i];
	}
	memset(ipv6_address, 0,8);
	 /* Link Local IPV6 ADDRESS PREFIX */
	/* Check destination */
	/* Destination */
	if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_SHORT ||  buf->dst_sa.addr_type == ADDR_802_15_4_PAN_LONG)
	{

		if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_LONG)
		{
			for(i=0;i<8;i++)
			{
				ipv6_address[i] = buf->dst_sa.address[7-i];
			}
		}
		else
		{
			ipv6_address[3]=0xff;
			ipv6_address[4]=0xfe;
			ipv6_address[6]=buf->dst_sa.address[1];
			ipv6_address[7]=buf->dst_sa.address[0];
		}

		*dptr++ =0xfe;
		*dptr++ = 0x80;

		for(i=0; i<6; i++)
		{
			*dptr++ = 0x00;
		}

		for(i=0; i<8; i++)
		{
			*dptr++ = ipv6_address[i];
		}
	}
	if(buf->dst_sa.addr_type == ADDR_BROADCAST)
	{
		*dptr++ =0xff;
		*dptr++ = 0x02;	
		for(i=0; i<13; i++)
		{
			*dptr++ = 0x00;
		}
		*dptr++ = 0x01;
	}

	buf->from = MODULE_CIPV6;
	buf->to = MODULE_NONE;
	stack_buffer_push(buf);
	buf=0;
	return pdTRUE;
}
/**
 * Parse IPv6 header.
 *
 * Function support only link-local unicast and multicast for all nodes.
 * \param buf pointer to data
 */
void parse_ipv_header(buffer_t *buf)
{
	uint8_t ind=0, ip_version,hoplimit=0, next_header=0, i, dest_match=0;
	ipv6_address_t destination;
	ind = buf->buf_ptr;
	ind++;
	/* Check IP version */
	ip_version = buf->buf[ind++];
	if( ip_version == 0x06 )
	{
#ifdef CIPV6_DEBUG	
		debug("IPv6 packet.\r\n");
#endif
		/* Check HC1 options */
		ind +=5;
		next_header = buf->buf[ind++];
		hoplimit= buf->buf[ind++];
		hoplimit--;
		ind +=16;
		for(i=0; i<16; i++)
		{
			destination[15-i] = buf->buf[ind++];
		}
		if(destination[15] == 0xfe && destination[14] == 0x80)
		{
#ifdef CIPV6_DEBUG	
			debug("link local unicast\r\n");
#endif
			if(destination[3] == 0xfe && destination[3] == 0xff)
			{
				if(memcmp(destination, cipv6_pib.short_address, 2) ==0)
					dest_match=1;
			}
			else
			{
				if(memcmp(destination, cipv6_pib.long_address, 8) ==0)
					dest_match=1;
			}	

		}
		if((destination[15] == 0xff && destination[14] == 0x02) && destination[0] == 0x01)
		{
#ifdef CIPV6_DEBUG	
			debug("link local multicast for all nodes\r\n");
#endif
			dest_match=1;
		}

		buf->options.lowpan_compressed = 0;
		if(next_header==NEXT_HEADER_ICMP6) buf->options.hop_count = 1;
		if(hoplimit > 0 && dest_match)
		{
			buf->buf_ptr = ind; /*cut header*/
			buf->to = MODULE_NONE;
			buf->from = MODULE_CIPV6;
			stack_buffer_push(buf);
			buf=0;
		}
		else
		{
#ifdef CIPV6_DEBUG	
			debug("destination not match\r\n");
#endif
		}
	}/* END_OF_LOWPAN_HC1 */
	/* General buffer discard part */	
	if(buf)
	{
#ifdef CIPV6_DEBUG	
		debug("Discard.\r\n");
#endif
		stack_buffer_free(buf);
		buf=0;
	}
}

portCHAR compare_ori_to_own(addrtype_t type, address_t address)
{
	if(type==ADDR_802_15_4_PAN_LONG)
	{
		if(memcmp(address,cipv6_pib.long_address , 8)==0)
			return pdTRUE;
	}
	else
	{
		if(memcmp(address,cipv6_pib.short_address ,2)==0)
			return pdTRUE;
	}
	return pdFALSE;
}


#ifndef NO_FCS
uint8_t ipv6_in_use = 0;

uint8_t ipv6_pseudo[40] = 
{
    // source address
    0xfe, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    // destination address
    0xfe, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    // payload length
    0x00, 0x00, 0x00, 0x00,
    // next header
    0x00, 0x00, 0x00, 0x00
};
	
/**
 * Check & Calculate FCF.
 *
 * Function calculate typical IP FCF which is used IPv6 and ICMP protocols.
 * \param buf pointer to data
 * \param next_protocol NEXT_HEADER_UDP / NEXT_HEADER_ICMP6
 * \param rx_case flag when function now it have to check and when calculate
 *
 * \return fcf 16-values
 */
uint16_t ipv6_fcf(buffer_t *buf, uint8_t next_protocol, uint8_t rx_case)
{
	uint32_t sum = 0;
	uint16_t cksum;
	uint8_t i, tmp=0;
	uint8_t *p_payload = buffer_data_pointer(buf);
	uint16_t length = buffer_data_length(buf);
	
	while (ipv6_in_use)
	{
		debug("wait");
		vTaskDelay(200/portTICK_RATE_MS);
	};
	
	ipv6_in_use = 1;
	//Create and init IPv6 pseudo header array
	memset(ipv6_pseudo, (uint8_t) 0, 40);
	ipv6_pseudo[0] = 0xfe;
	ipv6_pseudo[1] = 0x80;
	ipv6_pseudo[16] = 0xfe;
	ipv6_pseudo[17] = 0x80;

#ifndef AD_HOC_STATE
#ifdef MAC_RFD
	if ((rx_case == 0) && (buf->dst_sa.addr_type == ADDR_COORDINATOR))
	{
		if(get_coord_address(&buf->dst_sa) !=pdTRUE)
		{

		}
	}
#endif
#endif

#ifdef CIPV6_DEBUG	
	debug("s:");
#endif
	if(rx_case)
	{
		//RX case use buffers source address field
		if(buf->src_sa.addr_type == ADDR_802_15_4_PAN_LONG)
		{
			for(i=0;i<8;i++)
			{
				ipv6_pseudo[8+i] = buf->src_sa.address[7-i];
			}
#ifdef CIPV6_DEBUG	
			debug_address(&(buf->src_sa));
#endif
		}
		else
		{
			ipv6_pseudo[11]=0xff;
			ipv6_pseudo[12]=0xfe;
			ipv6_pseudo[14]=buf->src_sa.address[1];
			ipv6_pseudo[15]=buf->src_sa.address[0];
#ifdef CIPV6_DEBUG	
			debug_hex(buf->src_sa.address[1]);
			debug_hex(buf->src_sa.address[0]);
#endif
		}
	}
	else
	{
		// Source address
		if(cipv6_pib.use_short_address)
		{
			ipv6_pseudo[11]=0xff;
			ipv6_pseudo[12]=0xfe;
			ipv6_pseudo[14]=cipv6_pib.short_address[1];
			ipv6_pseudo[15]=cipv6_pib.short_address[0];
#ifdef CIPV6_DEBUG	
			debug_hex(cipv6_pib.short_address[1]);
			debug_hex(cipv6_pib.short_address[0]);
#endif
		}
		else
		{
			for(i=0; i<8; i++)
			{
				ipv6_pseudo[8+i] = cipv6_pib.long_address[7-i];
#ifdef CIPV6_DEBUG	
				debug_hex(cipv6_pib.long_address[7-i]);
#endif
			}
		}
	}
	
#ifdef CIPV6_DEBUG	
	debug("d:");
#endif
	//Destination address
	if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_LONG)
	{
		tmp=0;
		for(i=0;i<8;i++)
		{
			if(buf->dst_sa.address[i] !=0xff)
			{
				tmp=1;
				i=8;
			}
		}

		if(tmp)
		{
			for(i=0;i<8;i++)
			{
				ipv6_pseudo[24+i] = buf->dst_sa.address[7-i];
			}
#ifdef CIPV6_DEBUG	
			debug_address(&(buf->dst_sa));
#endif
		}
		else
		{
			buf->dst_sa.addr_type = ADDR_BROADCAST;
#ifdef CIPV6_DEBUG	
			debug("broadcast");
#endif
		}
	}
	if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_SHORT)
	{
		if((buf->dst_sa.address[1] !=0xff) && (buf->dst_sa.address[0] !=0xff))
		{
			ipv6_pseudo[27]=0xff;
			ipv6_pseudo[28]=0xfe;
			ipv6_pseudo[30]=buf->dst_sa.address[1];
			ipv6_pseudo[31]=buf->dst_sa.address[0];
#ifdef CIPV6_DEBUG	
			debug_hex(buf->dst_sa.address[1]);
			debug_hex(buf->dst_sa.address[0]);
#endif
		}
		else
		{
			buf->dst_sa.addr_type = ADDR_BROADCAST;
#ifdef CIPV6_DEBUG	
			debug("broadcast");
#endif
		}
	}
	if(buf->dst_sa.addr_type == ADDR_BROADCAST)
	{
		// Multicast to all nodes ff02: :01
		ipv6_pseudo[16] =0xff;
		ipv6_pseudo[17] = 0x02;	
		ipv6_pseudo[31] = 0x01;
	}

	ipv6_pseudo[35] = length;
	ipv6_pseudo[39] = next_protocol;

	//Calculate sum of ipv6_pseudo header
	for ( i = 0; i < sizeof(ipv6_pseudo); i += 2 )
	{
		uint16_t x = (uint16_t)(ipv6_pseudo[ i ] << 8) | ipv6_pseudo[ i+1 ];
		sum += x;
	}
	// Calculate sum of upper-layer payload
	for ( i = 0; i < length; i += 2 )
	{
		uint16_t x;
		// account for odd-length payload, pad with 0
		if ( (i+1) == length )
		x = (uint16_t)(p_payload[ i ] << 8);
		else
		x = (uint16_t)(p_payload[ i ] << 8) | p_payload[ i+1 ];
		sum += x;
	}
	cksum = (sum >> 16) + (sum & 0xffff);
	
	if(rx_case==0)
	{
		if ( cksum != 0xffff )
			cksum = ~cksum;
	}
	ipv6_in_use = 0;
	return cksum;
}
#endif /*NO_FCS*/

#ifdef HAVE_ROUTING
/**
 * Function notify for Broken link.
 *
 * Function remove allways neighbour info which not answer and if packet is Mesh routing header it will also remove routing info to destination.
 * Then it check originator address, if address is device own it will notify application.
   if address is not own it will forward ctrl message to ICMP module which create ICMP error message to originator.
 * \param buf pointer to data
 */
void ip_broken_link_notify(buffer_t *buf)
{
	uint8_t i, dest_length=0, mesh_header, tmp, ind;
	control_message_t *msg;
	remove_broken_link(buf->dst_sa.addr_type, buf->dst_sa.address);
	if((buf->buf[buf->buf_ptr] & LOWPAN_TYPE_BM) ==  MESH_ROUTING_TYPE)
	{
		ind = buf->buf_ptr;
		mesh_header = buf->buf[ind++];
		/* Check Originator and Final-destination address */
		tmp=(mesh_header & MESH_ADDRESSTYPE_BM);
		if((tmp & O_ADDRESSTYPE_BM) == O_ADDRESSTYPE_16)
		{
			buf->src_sa.addr_type=ADDR_802_15_4_PAN_SHORT;
			dest_length=2;
		}
		else
		{
			buf->src_sa.addr_type=ADDR_802_15_4_PAN_LONG;
			dest_length=8;	
		}
		for(i=0; i < dest_length; i++)
		{
			buf->src_sa.address[i] = buf->buf[ind++];
		}
	
		if((tmp & D_ADDRESSTYPE_BM) == D_ADDRESSTYPE_16)
		{
			buf->dst_sa.addr_type =  ADDR_802_15_4_PAN_SHORT;
			dest_length=2;
		}
		else
		{
			buf->dst_sa.addr_type=ADDR_802_15_4_PAN_LONG;
			dest_length=8;
		}
		for(i=0; i < dest_length; i++)
		{
			buf->dst_sa.address[i] = buf->buf[ind++];
		}
		remove_broken_route(buf->dst_sa.addr_type, buf->dst_sa.address);
	}
	else i=99;	/* Destination is neighbour */
	buf->buf_end=0;
	buf->buf_ptr=0;
	buf->options.type = BUFFER_CONTROL;
	msg = ( control_message_t*) buf->buf;
	msg->message.ip_control.message_id = BROKEN_LINK;
	buf->from = MODULE_CIPV6;
	buf->socket = 0;
	if(compare_ori_to_own(buf->src_sa.addr_type, buf->src_sa.address) == pdTRUE || i==99)
	{
		buf->to = MODULE_APP;
		buf->dst_sa.port = ICMP_CTRL_PORT;
		buf->src_sa.port = ICMP_CTRL_PORT;
		msg->message.ip_control.message.broken_link_detect.type = buf->dst_sa.addr_type;
		for(i=0; i<dest_length; i++)
		{
			msg->message.ip_control.message.broken_link_detect.address[i] = buf->dst_sa.address[i];
		}					
		buf->dst_sa.addr_type = ADDR_NONE;
		buf->src_sa.addr_type = ADDR_NONE;	
	}
	else
	{
		buf->to = MODULE_ICMP;
		msg->message.ip_control.message.broken_link_detect.type = buf->dst_sa.addr_type;
		for(i=0; i<dest_length; i++)
		{
			msg->message.ip_control.message.broken_link_detect.address[i] = buf->dst_sa.address[i];
		}
	}
	buf->options.handle_type = HANDLE_DEFAULT;
	buf->dir = BUFFER_UP;
	stack_buffer_push(buf);
	buf = 0;
}
#endif

