                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Nov 10 2006)
                              4 ; This file generated Fri Feb  1 13:33:37 2008
                              5 ;--------------------------------------------------------
                              6 	.module list
                              7 	.optsdcc -mmcs51 --model-large
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _IRCON2_P2IF
                             13 	.globl _IRCON2_UTX0IF
                             14 	.globl _IRCON2_UTX1IF
                             15 	.globl _IRCON2_P1IF
                             16 	.globl _IRCON2_WDTIF
                             17 	.globl _CY
                             18 	.globl _AC
                             19 	.globl _F0
                             20 	.globl _RS1
                             21 	.globl _RS0
                             22 	.globl _OV
                             23 	.globl _F1
                             24 	.globl _P
                             25 	.globl _IRCON_DMAIF
                             26 	.globl _IRCON_T1IF
                             27 	.globl _IRCON_T2IF
                             28 	.globl _IRCON_T3IF
                             29 	.globl _IRCON_T4IF
                             30 	.globl _IRCON_P0IF
                             31 	.globl _IRCON_STIF
                             32 	.globl _IEN1_DMAIE
                             33 	.globl _IEN1_T1IE
                             34 	.globl _IEN1_T2IE
                             35 	.globl _IEN1_T3IE
                             36 	.globl _IEN1_T4IE
                             37 	.globl _IEN1_P0IE
                             38 	.globl _IEN0_RFERRIE
                             39 	.globl _IEN0_ADCIE
                             40 	.globl _IEN0_URX0IE
                             41 	.globl _IEN0_URX1IE
                             42 	.globl _IEN0_ENCIE
                             43 	.globl _IEN0_STIE
                             44 	.globl _IEN0_EA
                             45 	.globl _EA
                             46 	.globl _P2_4
                             47 	.globl _P2_3
                             48 	.globl _P2_2
                             49 	.globl _P2_1
                             50 	.globl _P2_0
                             51 	.globl _S0CON_ENCIF_0
                             52 	.globl _S0CON_ENCIF_1
                             53 	.globl _P1_7
                             54 	.globl _P1_6
                             55 	.globl _P1_5
                             56 	.globl _P1_4
                             57 	.globl _P1_3
                             58 	.globl _P1_2
                             59 	.globl _P1_1
                             60 	.globl _P1_0
                             61 	.globl _TCON_IT0
                             62 	.globl _TCON_RFERRIF
                             63 	.globl _TCON_IT1
                             64 	.globl _TCON_URX0IF
                             65 	.globl _TCON_ADCIF
                             66 	.globl _TCON_URX1IF
                             67 	.globl _P0_0
                             68 	.globl _P0_1
                             69 	.globl _P0_2
                             70 	.globl _P0_3
                             71 	.globl _P0_4
                             72 	.globl _P0_5
                             73 	.globl _P0_6
                             74 	.globl _P0_7
                             75 	.globl _P2DIR
                             76 	.globl _P1DIR
                             77 	.globl _P0DIR
                             78 	.globl _U1GCR
                             79 	.globl _U1UCR
                             80 	.globl _U1BAUD
                             81 	.globl _U1BUF
                             82 	.globl _U1CSR
                             83 	.globl _P2INP
                             84 	.globl _P1INP
                             85 	.globl _P2SEL
                             86 	.globl _P1SEL
                             87 	.globl _P0SEL
                             88 	.globl _ADCCFG
                             89 	.globl _PERCFG
                             90 	.globl _B
                             91 	.globl _T4CC1
                             92 	.globl _T4CCTL1
                             93 	.globl _T4CC0
                             94 	.globl _T4CCTL0
                             95 	.globl _T4CTL
                             96 	.globl _T4CNT
                             97 	.globl _RFIF
                             98 	.globl _IRCON2
                             99 	.globl _T1CCTL2
                            100 	.globl _T1CCTL1
                            101 	.globl _T1CCTL0
                            102 	.globl _T1CTL
                            103 	.globl _T1CNTH
                            104 	.globl _T1CNTL
                            105 	.globl _RFST
                            106 	.globl _ACC
                            107 	.globl _T1CC2H
                            108 	.globl _T1CC2L
                            109 	.globl _T1CC1H
                            110 	.globl _T1CC1L
                            111 	.globl _T1CC0H
                            112 	.globl _T1CC0L
                            113 	.globl _RFD
                            114 	.globl _TIMIF
                            115 	.globl _DMAREQ
                            116 	.globl _DMAARM
                            117 	.globl _DMA0CFGH
                            118 	.globl _DMA0CFGL
                            119 	.globl _DMA1CFGH
                            120 	.globl _DMA1CFGL
                            121 	.globl _DMAIRQ
                            122 	.globl _PSW
                            123 	.globl _T3CC1
                            124 	.globl _T3CCTL1
                            125 	.globl _T3CC0
                            126 	.globl _T3CCTL0
                            127 	.globl _T3CTL
                            128 	.globl _T3CNT
                            129 	.globl _WDCTL
                            130 	.globl _T2CON
                            131 	.globl _MEMCTR
                            132 	.globl _CLKCON
                            133 	.globl _U0GCR
                            134 	.globl _U0UCR
                            135 	.globl _T2CNF
                            136 	.globl _U0BAUD
                            137 	.globl _U0BUF
                            138 	.globl _IRCON
                            139 	.globl _SLEEP
                            140 	.globl _RNDH
                            141 	.globl _RNDL
                            142 	.globl _ADCH
                            143 	.globl _ADCL
                            144 	.globl _IP1
                            145 	.globl _IEN1
                            146 	.globl _RCCTL
                            147 	.globl _ADCCON3
                            148 	.globl _ADCCON2
                            149 	.globl _ADCCON1
                            150 	.globl _ENCCS
                            151 	.globl _ENCDO
                            152 	.globl _ENCDI
                            153 	.globl _FWDATA
                            154 	.globl _FCTL
                            155 	.globl _FADDRH
                            156 	.globl _FADDRL
                            157 	.globl _FWT
                            158 	.globl _IP0
                            159 	.globl _IEN0
                            160 	.globl _IE
                            161 	.globl _T2THD
                            162 	.globl _T2TLD
                            163 	.globl _T2CAPHPH
                            164 	.globl _T2CAPLPL
                            165 	.globl _T2OF2
                            166 	.globl _T2OF1
                            167 	.globl _T2OF0
                            168 	.globl _P2
                            169 	.globl _T2PEROF2
                            170 	.globl _T2PEROF1
                            171 	.globl _T2PEROF0
                            172 	.globl _S1CON
                            173 	.globl _IEN2
                            174 	.globl _HSRC
                            175 	.globl _S0CON
                            176 	.globl _ST2
                            177 	.globl _ST1
                            178 	.globl _ST0
                            179 	.globl _T2CMP
                            180 	.globl __XPAGE
                            181 	.globl _DPS
                            182 	.globl _RFIM
                            183 	.globl _P1
                            184 	.globl _P0INP
                            185 	.globl _P1IEN
                            186 	.globl _PICTL
                            187 	.globl _P2IFG
                            188 	.globl _P1IFG
                            189 	.globl _P0IFG
                            190 	.globl _TCON
                            191 	.globl _PCON
                            192 	.globl _U0CSR
                            193 	.globl _DPH1
                            194 	.globl _DPL1
                            195 	.globl _DPH0
                            196 	.globl _DPL0
                            197 	.globl _SP
                            198 	.globl _P0
                            199 	.globl _RFD_SHADOW
                            200 	.globl _RFSTATUS
                            201 	.globl _CHIPID
                            202 	.globl _CHVER
                            203 	.globl _FSMTC1
                            204 	.globl _RXFIFOCNT
                            205 	.globl _IOCFG3
                            206 	.globl _IOCFG2
                            207 	.globl _IOCFG1
                            208 	.globl _IOCFG0
                            209 	.globl _SHORTADDRL
                            210 	.globl _SHORTADDRH
                            211 	.globl _PANIDL
                            212 	.globl _PANIDH
                            213 	.globl _IEEE_ADDR7
                            214 	.globl _IEEE_ADDR6
                            215 	.globl _IEEE_ADDR5
                            216 	.globl _IEEE_ADDR4
                            217 	.globl _IEEE_ADDR3
                            218 	.globl _IEEE_ADDR2
                            219 	.globl _IEEE_ADDR1
                            220 	.globl _IEEE_ADDR0
                            221 	.globl _DACTSTL
                            222 	.globl _DACTSTH
                            223 	.globl _ADCTSTL
                            224 	.globl _ADCTSTH
                            225 	.globl _FSMSTATE
                            226 	.globl _AGCCTRLL
                            227 	.globl _AGCCTRLH
                            228 	.globl _MANORL
                            229 	.globl _MANORH
                            230 	.globl _MANANDL
                            231 	.globl _MANANDH
                            232 	.globl _FSMTCL
                            233 	.globl _FSMTCH
                            234 	.globl _RFPWR
                            235 	.globl _CSPT
                            236 	.globl _CSPCTRL
                            237 	.globl _CSPZ
                            238 	.globl _CSPY
                            239 	.globl _CSPX
                            240 	.globl _FSCTRLL
                            241 	.globl _FSCTRLH
                            242 	.globl _RXCTRL1L
                            243 	.globl _RXCTRL1H
                            244 	.globl _RXCTRL0L
                            245 	.globl _RXCTRL0H
                            246 	.globl _TXCTRLL
                            247 	.globl _TXCTRLH
                            248 	.globl _SYNCWORDL
                            249 	.globl _SYNCWORDH
                            250 	.globl _RSSIL
                            251 	.globl _RSSIH
                            252 	.globl _MDMCTRL1L
                            253 	.globl _MDMCTRL1H
                            254 	.globl _MDMCTRL0L
                            255 	.globl _MDMCTRL0H
                            256 	.globl _vListInitialise
                            257 	.globl _vListInitialiseItem
                            258 	.globl _vListInsertEnd
                            259 	.globl _vListInsert
                            260 	.globl _vListRemove
                            261 ;--------------------------------------------------------
                            262 ; special function registers
                            263 ;--------------------------------------------------------
                            264 	.area RSEG    (DATA)
                    0080    265 _P0	=	0x0080
                    0081    266 _SP	=	0x0081
                    0082    267 _DPL0	=	0x0082
                    0083    268 _DPH0	=	0x0083
                    0084    269 _DPL1	=	0x0084
                    0085    270 _DPH1	=	0x0085
                    0086    271 _U0CSR	=	0x0086
                    0087    272 _PCON	=	0x0087
                    0088    273 _TCON	=	0x0088
                    0089    274 _P0IFG	=	0x0089
                    008A    275 _P1IFG	=	0x008a
                    008B    276 _P2IFG	=	0x008b
                    008C    277 _PICTL	=	0x008c
                    008D    278 _P1IEN	=	0x008d
                    008F    279 _P0INP	=	0x008f
                    0090    280 _P1	=	0x0090
                    0091    281 _RFIM	=	0x0091
                    0092    282 _DPS	=	0x0092
                    0093    283 __XPAGE	=	0x0093
                    0094    284 _T2CMP	=	0x0094
                    0095    285 _ST0	=	0x0095
                    0096    286 _ST1	=	0x0096
                    0097    287 _ST2	=	0x0097
                    0098    288 _S0CON	=	0x0098
                    0099    289 _HSRC	=	0x0099
                    009A    290 _IEN2	=	0x009a
                    009B    291 _S1CON	=	0x009b
                    009C    292 _T2PEROF0	=	0x009c
                    009D    293 _T2PEROF1	=	0x009d
                    009E    294 _T2PEROF2	=	0x009e
                    00A0    295 _P2	=	0x00a0
                    00A1    296 _T2OF0	=	0x00a1
                    00A2    297 _T2OF1	=	0x00a2
                    00A3    298 _T2OF2	=	0x00a3
                    00A4    299 _T2CAPLPL	=	0x00a4
                    00A5    300 _T2CAPHPH	=	0x00a5
                    00A6    301 _T2TLD	=	0x00a6
                    00A7    302 _T2THD	=	0x00a7
                    00A8    303 _IE	=	0x00a8
                    00A8    304 _IEN0	=	0x00a8
                    00A9    305 _IP0	=	0x00a9
                    00AB    306 _FWT	=	0x00ab
                    00AC    307 _FADDRL	=	0x00ac
                    00AD    308 _FADDRH	=	0x00ad
                    00AE    309 _FCTL	=	0x00ae
                    00AF    310 _FWDATA	=	0x00af
                    00B1    311 _ENCDI	=	0x00b1
                    00B2    312 _ENCDO	=	0x00b2
                    00B3    313 _ENCCS	=	0x00b3
                    00B4    314 _ADCCON1	=	0x00b4
                    00B5    315 _ADCCON2	=	0x00b5
                    00B6    316 _ADCCON3	=	0x00b6
                    00B7    317 _RCCTL	=	0x00b7
                    00B8    318 _IEN1	=	0x00b8
                    00B9    319 _IP1	=	0x00b9
                    00BA    320 _ADCL	=	0x00ba
                    00BB    321 _ADCH	=	0x00bb
                    00BC    322 _RNDL	=	0x00bc
                    00BD    323 _RNDH	=	0x00bd
                    00BE    324 _SLEEP	=	0x00be
                    00C0    325 _IRCON	=	0x00c0
                    00C1    326 _U0BUF	=	0x00c1
                    00C2    327 _U0BAUD	=	0x00c2
                    00C3    328 _T2CNF	=	0x00c3
                    00C4    329 _U0UCR	=	0x00c4
                    00C5    330 _U0GCR	=	0x00c5
                    00C6    331 _CLKCON	=	0x00c6
                    00C7    332 _MEMCTR	=	0x00c7
                    00C8    333 _T2CON	=	0x00c8
                    00C9    334 _WDCTL	=	0x00c9
                    00CA    335 _T3CNT	=	0x00ca
                    00CB    336 _T3CTL	=	0x00cb
                    00CC    337 _T3CCTL0	=	0x00cc
                    00CD    338 _T3CC0	=	0x00cd
                    00CE    339 _T3CCTL1	=	0x00ce
                    00CF    340 _T3CC1	=	0x00cf
                    00D0    341 _PSW	=	0x00d0
                    00D1    342 _DMAIRQ	=	0x00d1
                    00D2    343 _DMA1CFGL	=	0x00d2
                    00D3    344 _DMA1CFGH	=	0x00d3
                    00D4    345 _DMA0CFGL	=	0x00d4
                    00D5    346 _DMA0CFGH	=	0x00d5
                    00D6    347 _DMAARM	=	0x00d6
                    00D7    348 _DMAREQ	=	0x00d7
                    00D8    349 _TIMIF	=	0x00d8
                    00D9    350 _RFD	=	0x00d9
                    00DA    351 _T1CC0L	=	0x00da
                    00DB    352 _T1CC0H	=	0x00db
                    00DC    353 _T1CC1L	=	0x00dc
                    00DD    354 _T1CC1H	=	0x00dd
                    00DE    355 _T1CC2L	=	0x00de
                    00DF    356 _T1CC2H	=	0x00df
                    00E0    357 _ACC	=	0x00e0
                    00E1    358 _RFST	=	0x00e1
                    00E2    359 _T1CNTL	=	0x00e2
                    00E3    360 _T1CNTH	=	0x00e3
                    00E4    361 _T1CTL	=	0x00e4
                    00E5    362 _T1CCTL0	=	0x00e5
                    00E6    363 _T1CCTL1	=	0x00e6
                    00E7    364 _T1CCTL2	=	0x00e7
                    00E8    365 _IRCON2	=	0x00e8
                    00E9    366 _RFIF	=	0x00e9
                    00EA    367 _T4CNT	=	0x00ea
                    00EB    368 _T4CTL	=	0x00eb
                    00EC    369 _T4CCTL0	=	0x00ec
                    00ED    370 _T4CC0	=	0x00ed
                    00EE    371 _T4CCTL1	=	0x00ee
                    00EF    372 _T4CC1	=	0x00ef
                    00F0    373 _B	=	0x00f0
                    00F1    374 _PERCFG	=	0x00f1
                    00F2    375 _ADCCFG	=	0x00f2
                    00F3    376 _P0SEL	=	0x00f3
                    00F4    377 _P1SEL	=	0x00f4
                    00F5    378 _P2SEL	=	0x00f5
                    00F6    379 _P1INP	=	0x00f6
                    00F7    380 _P2INP	=	0x00f7
                    00F8    381 _U1CSR	=	0x00f8
                    00F9    382 _U1BUF	=	0x00f9
                    00FA    383 _U1BAUD	=	0x00fa
                    00FB    384 _U1UCR	=	0x00fb
                    00FC    385 _U1GCR	=	0x00fc
                    00FD    386 _P0DIR	=	0x00fd
                    00FE    387 _P1DIR	=	0x00fe
                    00FF    388 _P2DIR	=	0x00ff
                            389 ;--------------------------------------------------------
                            390 ; special function bits
                            391 ;--------------------------------------------------------
                            392 	.area RSEG    (DATA)
                    0087    393 _P0_7	=	0x0087
                    0086    394 _P0_6	=	0x0086
                    0085    395 _P0_5	=	0x0085
                    0084    396 _P0_4	=	0x0084
                    0083    397 _P0_3	=	0x0083
                    0082    398 _P0_2	=	0x0082
                    0081    399 _P0_1	=	0x0081
                    0080    400 _P0_0	=	0x0080
                    008F    401 _TCON_URX1IF	=	0x008f
                    008D    402 _TCON_ADCIF	=	0x008d
                    008B    403 _TCON_URX0IF	=	0x008b
                    008A    404 _TCON_IT1	=	0x008a
                    0089    405 _TCON_RFERRIF	=	0x0089
                    0088    406 _TCON_IT0	=	0x0088
                    0090    407 _P1_0	=	0x0090
                    0091    408 _P1_1	=	0x0091
                    0092    409 _P1_2	=	0x0092
                    0093    410 _P1_3	=	0x0093
                    0094    411 _P1_4	=	0x0094
                    0095    412 _P1_5	=	0x0095
                    0096    413 _P1_6	=	0x0096
                    0097    414 _P1_7	=	0x0097
                    0099    415 _S0CON_ENCIF_1	=	0x0099
                    0098    416 _S0CON_ENCIF_0	=	0x0098
                    00A0    417 _P2_0	=	0x00a0
                    00A1    418 _P2_1	=	0x00a1
                    00A2    419 _P2_2	=	0x00a2
                    00A3    420 _P2_3	=	0x00a3
                    00A4    421 _P2_4	=	0x00a4
                    00AF    422 _EA	=	0x00af
                    00AF    423 _IEN0_EA	=	0x00af
                    00AD    424 _IEN0_STIE	=	0x00ad
                    00AC    425 _IEN0_ENCIE	=	0x00ac
                    00AB    426 _IEN0_URX1IE	=	0x00ab
                    00AA    427 _IEN0_URX0IE	=	0x00aa
                    00A9    428 _IEN0_ADCIE	=	0x00a9
                    00A8    429 _IEN0_RFERRIE	=	0x00a8
                    00BD    430 _IEN1_P0IE	=	0x00bd
                    00BC    431 _IEN1_T4IE	=	0x00bc
                    00BB    432 _IEN1_T3IE	=	0x00bb
                    00BA    433 _IEN1_T2IE	=	0x00ba
                    00B9    434 _IEN1_T1IE	=	0x00b9
                    00B8    435 _IEN1_DMAIE	=	0x00b8
                    00C7    436 _IRCON_STIF	=	0x00c7
                    00C5    437 _IRCON_P0IF	=	0x00c5
                    00C4    438 _IRCON_T4IF	=	0x00c4
                    00C3    439 _IRCON_T3IF	=	0x00c3
                    00C2    440 _IRCON_T2IF	=	0x00c2
                    00C1    441 _IRCON_T1IF	=	0x00c1
                    00C0    442 _IRCON_DMAIF	=	0x00c0
                    00D0    443 _P	=	0x00d0
                    00D1    444 _F1	=	0x00d1
                    00D2    445 _OV	=	0x00d2
                    00D3    446 _RS0	=	0x00d3
                    00D4    447 _RS1	=	0x00d4
                    00D5    448 _F0	=	0x00d5
                    00D6    449 _AC	=	0x00d6
                    00D7    450 _CY	=	0x00d7
                    00EC    451 _IRCON2_WDTIF	=	0x00ec
                    00EB    452 _IRCON2_P1IF	=	0x00eb
                    00EA    453 _IRCON2_UTX1IF	=	0x00ea
                    00E9    454 _IRCON2_UTX0IF	=	0x00e9
                    00E8    455 _IRCON2_P2IF	=	0x00e8
                            456 ;--------------------------------------------------------
                            457 ; overlayable register banks
                            458 ;--------------------------------------------------------
                            459 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     460 	.ds 8
                            461 ;--------------------------------------------------------
                            462 ; internal ram data
                            463 ;--------------------------------------------------------
                            464 	.area DSEG    (DATA)
                            465 ;--------------------------------------------------------
                            466 ; overlayable items in internal ram 
                            467 ;--------------------------------------------------------
                            468 	.area OSEG    (OVR,DATA)
                            469 ;--------------------------------------------------------
                            470 ; indirectly addressable internal ram data
                            471 ;--------------------------------------------------------
                            472 	.area ISEG    (DATA)
                            473 ;--------------------------------------------------------
                            474 ; bit data
                            475 ;--------------------------------------------------------
                            476 	.area BSEG    (BIT)
                            477 ;--------------------------------------------------------
                            478 ; paged external ram data
                            479 ;--------------------------------------------------------
                            480 	.area PSEG    (PAG,XDATA)
                            481 ;--------------------------------------------------------
                            482 ; external ram data
                            483 ;--------------------------------------------------------
                            484 	.area XSEG    (XDATA)
                    DF02    485 _MDMCTRL0H	=	0xdf02
                    DF03    486 _MDMCTRL0L	=	0xdf03
                    DF04    487 _MDMCTRL1H	=	0xdf04
                    DF05    488 _MDMCTRL1L	=	0xdf05
                    DF06    489 _RSSIH	=	0xdf06
                    DF07    490 _RSSIL	=	0xdf07
                    DF08    491 _SYNCWORDH	=	0xdf08
                    DF09    492 _SYNCWORDL	=	0xdf09
                    DF0A    493 _TXCTRLH	=	0xdf0a
                    DF0B    494 _TXCTRLL	=	0xdf0b
                    DF0C    495 _RXCTRL0H	=	0xdf0c
                    DF0D    496 _RXCTRL0L	=	0xdf0d
                    DF0E    497 _RXCTRL1H	=	0xdf0e
                    DF0F    498 _RXCTRL1L	=	0xdf0f
                    DF10    499 _FSCTRLH	=	0xdf10
                    DF11    500 _FSCTRLL	=	0xdf11
                    DF12    501 _CSPX	=	0xdf12
                    DF13    502 _CSPY	=	0xdf13
                    DF14    503 _CSPZ	=	0xdf14
                    DF15    504 _CSPCTRL	=	0xdf15
                    DF16    505 _CSPT	=	0xdf16
                    DF17    506 _RFPWR	=	0xdf17
                    DF20    507 _FSMTCH	=	0xdf20
                    DF21    508 _FSMTCL	=	0xdf21
                    DF22    509 _MANANDH	=	0xdf22
                    DF23    510 _MANANDL	=	0xdf23
                    DF24    511 _MANORH	=	0xdf24
                    DF25    512 _MANORL	=	0xdf25
                    DF26    513 _AGCCTRLH	=	0xdf26
                    DF27    514 _AGCCTRLL	=	0xdf27
                    DF39    515 _FSMSTATE	=	0xdf39
                    DF3A    516 _ADCTSTH	=	0xdf3a
                    DF3B    517 _ADCTSTL	=	0xdf3b
                    DF3C    518 _DACTSTH	=	0xdf3c
                    DF3D    519 _DACTSTL	=	0xdf3d
                    DF43    520 _IEEE_ADDR0	=	0xdf43
                    DF44    521 _IEEE_ADDR1	=	0xdf44
                    DF45    522 _IEEE_ADDR2	=	0xdf45
                    DF46    523 _IEEE_ADDR3	=	0xdf46
                    DF47    524 _IEEE_ADDR4	=	0xdf47
                    DF48    525 _IEEE_ADDR5	=	0xdf48
                    DF49    526 _IEEE_ADDR6	=	0xdf49
                    DF4A    527 _IEEE_ADDR7	=	0xdf4a
                    DF4B    528 _PANIDH	=	0xdf4b
                    DF4C    529 _PANIDL	=	0xdf4c
                    DF4D    530 _SHORTADDRH	=	0xdf4d
                    DF4E    531 _SHORTADDRL	=	0xdf4e
                    DF4F    532 _IOCFG0	=	0xdf4f
                    DF50    533 _IOCFG1	=	0xdf50
                    DF51    534 _IOCFG2	=	0xdf51
                    DF52    535 _IOCFG3	=	0xdf52
                    DF53    536 _RXFIFOCNT	=	0xdf53
                    DF54    537 _FSMTC1	=	0xdf54
                    DF60    538 _CHVER	=	0xdf60
                    DF61    539 _CHIPID	=	0xdf61
                    DF62    540 _RFSTATUS	=	0xdf62
                    DFD9    541 _RFD_SHADOW	=	0xdfd9
                            542 ;--------------------------------------------------------
                            543 ; external initialized ram data
                            544 ;--------------------------------------------------------
                            545 	.area XISEG   (XDATA)
                            546 	.area HOME    (CODE)
                            547 	.area GSINIT0 (CODE)
                            548 	.area GSINIT1 (CODE)
                            549 	.area GSINIT2 (CODE)
                            550 	.area GSINIT3 (CODE)
                            551 	.area GSINIT4 (CODE)
                            552 	.area GSINIT5 (CODE)
                            553 	.area GSINIT  (CODE)
                            554 	.area GSFINAL (CODE)
                            555 	.area CSEG    (CODE)
                            556 ;--------------------------------------------------------
                            557 ; global & static initialisations
                            558 ;--------------------------------------------------------
                            559 	.area HOME    (CODE)
                            560 	.area GSINIT  (CODE)
                            561 	.area GSFINAL (CODE)
                            562 	.area GSINIT  (CODE)
                            563 ;--------------------------------------------------------
                            564 ; Home
                            565 ;--------------------------------------------------------
                            566 	.area HOME    (CODE)
                            567 	.area CSEG    (CODE)
                            568 ;--------------------------------------------------------
                            569 ; code
                            570 ;--------------------------------------------------------
                            571 	.area CSEG    (CODE)
                            572 ;------------------------------------------------------------
                            573 ;Allocation info for local variables in function 'vListInitialise'
                            574 ;------------------------------------------------------------
                            575 ;pxList                    Allocated to stack - offset 1
                            576 ;sloc0                     Allocated to stack - offset 4
                            577 ;------------------------------------------------------------
                            578 ;	../../FreeRTOS/Source/list.c:89: void vListInitialise( xList *pxList )
                            579 ;	-----------------------------------------
                            580 ;	 function vListInitialise
                            581 ;	-----------------------------------------
   2AA3                     582 _vListInitialise:
                    0002    583 	ar2 = 0x02
                    0003    584 	ar3 = 0x03
                    0004    585 	ar4 = 0x04
                    0005    586 	ar5 = 0x05
                    0006    587 	ar6 = 0x06
                    0007    588 	ar7 = 0x07
                    0000    589 	ar0 = 0x00
                    0001    590 	ar1 = 0x01
   2AA3 C0 10               591 	push	_bp
   2AA5 85 81 10            592 	mov	_bp,sp
                            593 ;     genReceive
   2AA8 C0 82               594 	push	dpl
   2AAA C0 83               595 	push	dph
   2AAC C0 F0               596 	push	b
   2AAE 05 81               597 	inc	sp
   2AB0 05 81               598 	inc	sp
   2AB2 05 81               599 	inc	sp
                            600 ;	../../FreeRTOS/Source/list.c:94: pxList->pxIndex = ( xListItem * ) &( pxList->xListEnd );
                            601 ;	genPlus
   2AB4 A8 10               602 	mov	r0,_bp
   2AB6 08                  603 	inc	r0
                            604 ;     genPlusIncr
   2AB7 74 01               605 	mov	a,#0x01
   2AB9 26                  606 	add	a,@r0
   2ABA FD                  607 	mov	r5,a
                            608 ;	Peephole 181	changed mov to clr
   2ABB E4                  609 	clr	a
   2ABC 08                  610 	inc	r0
   2ABD 36                  611 	addc	a,@r0
   2ABE FE                  612 	mov	r6,a
   2ABF 08                  613 	inc	r0
   2AC0 86 07               614 	mov	ar7,@r0
                            615 ;	genPlus
   2AC2 A8 10               616 	mov	r0,_bp
   2AC4 08                  617 	inc	r0
   2AC5 E5 10               618 	mov	a,_bp
   2AC7 24 04               619 	add	a,#0x04
   2AC9 F9                  620 	mov	r1,a
                            621 ;     genPlusIncr
   2ACA 74 04               622 	mov	a,#0x04
   2ACC 26                  623 	add	a,@r0
   2ACD F7                  624 	mov	@r1,a
                            625 ;	Peephole 181	changed mov to clr
   2ACE E4                  626 	clr	a
   2ACF 08                  627 	inc	r0
   2AD0 36                  628 	addc	a,@r0
   2AD1 09                  629 	inc	r1
   2AD2 F7                  630 	mov	@r1,a
   2AD3 08                  631 	inc	r0
   2AD4 09                  632 	inc	r1
   2AD5 E6                  633 	mov	a,@r0
   2AD6 F7                  634 	mov	@r1,a
                            635 ;	genPointerSet
                            636 ;	genGenPointerSet
   2AD7 8D 82               637 	mov	dpl,r5
   2AD9 8E 83               638 	mov	dph,r6
   2ADB 8F F0               639 	mov	b,r7
   2ADD E5 10               640 	mov	a,_bp
   2ADF 24 04               641 	add	a,#0x04
   2AE1 F8                  642 	mov	r0,a
   2AE2 E6                  643 	mov	a,@r0
   2AE3 12 DF B7            644 	lcall	__gptrput
   2AE6 A3                  645 	inc	dptr
   2AE7 08                  646 	inc	r0
   2AE8 E6                  647 	mov	a,@r0
   2AE9 12 DF B7            648 	lcall	__gptrput
   2AEC A3                  649 	inc	dptr
   2AED 08                  650 	inc	r0
   2AEE E6                  651 	mov	a,@r0
   2AEF 12 DF B7            652 	lcall	__gptrput
                            653 ;	../../FreeRTOS/Source/list.c:98: pxList->xListEnd.xItemValue = portMAX_DELAY;
                            654 ;	genPointerSet
                            655 ;	genGenPointerSet
   2AF2 E5 10               656 	mov	a,_bp
   2AF4 24 04               657 	add	a,#0x04
   2AF6 F8                  658 	mov	r0,a
   2AF7 86 82               659 	mov	dpl,@r0
   2AF9 08                  660 	inc	r0
   2AFA 86 83               661 	mov	dph,@r0
   2AFC 08                  662 	inc	r0
   2AFD 86 F0               663 	mov	b,@r0
   2AFF 74 FF               664 	mov	a,#0xFF
   2B01 12 DF B7            665 	lcall	__gptrput
   2B04 A3                  666 	inc	dptr
   2B05 74 FF               667 	mov	a,#0xFF
   2B07 12 DF B7            668 	lcall	__gptrput
                            669 ;	../../FreeRTOS/Source/list.c:102: pxList->xListEnd.pxNext = ( xListItem * ) &( pxList->xListEnd );
                            670 ;	genPlus
   2B0A E5 10               671 	mov	a,_bp
   2B0C 24 04               672 	add	a,#0x04
   2B0E F8                  673 	mov	r0,a
                            674 ;     genPlusIncr
   2B0F 74 02               675 	mov	a,#0x02
   2B11 26                  676 	add	a,@r0
   2B12 FB                  677 	mov	r3,a
                            678 ;	Peephole 181	changed mov to clr
   2B13 E4                  679 	clr	a
   2B14 08                  680 	inc	r0
   2B15 36                  681 	addc	a,@r0
   2B16 FC                  682 	mov	r4,a
   2B17 08                  683 	inc	r0
   2B18 86 05               684 	mov	ar5,@r0
                            685 ;	genPointerSet
                            686 ;	genGenPointerSet
   2B1A 8B 82               687 	mov	dpl,r3
   2B1C 8C 83               688 	mov	dph,r4
   2B1E 8D F0               689 	mov	b,r5
   2B20 E5 10               690 	mov	a,_bp
   2B22 24 04               691 	add	a,#0x04
   2B24 F8                  692 	mov	r0,a
   2B25 E6                  693 	mov	a,@r0
   2B26 12 DF B7            694 	lcall	__gptrput
   2B29 A3                  695 	inc	dptr
   2B2A 08                  696 	inc	r0
   2B2B E6                  697 	mov	a,@r0
   2B2C 12 DF B7            698 	lcall	__gptrput
   2B2F A3                  699 	inc	dptr
   2B30 08                  700 	inc	r0
   2B31 E6                  701 	mov	a,@r0
   2B32 12 DF B7            702 	lcall	__gptrput
                            703 ;	../../FreeRTOS/Source/list.c:103: pxList->xListEnd.pxPrevious = ( xListItem * ) &( pxList->xListEnd );
                            704 ;	genPlus
   2B35 E5 10               705 	mov	a,_bp
   2B37 24 04               706 	add	a,#0x04
   2B39 F8                  707 	mov	r0,a
                            708 ;     genPlusIncr
   2B3A 74 05               709 	mov	a,#0x05
   2B3C 26                  710 	add	a,@r0
   2B3D FB                  711 	mov	r3,a
                            712 ;	Peephole 181	changed mov to clr
   2B3E E4                  713 	clr	a
   2B3F 08                  714 	inc	r0
   2B40 36                  715 	addc	a,@r0
   2B41 FC                  716 	mov	r4,a
   2B42 08                  717 	inc	r0
   2B43 86 05               718 	mov	ar5,@r0
                            719 ;	genPointerSet
                            720 ;	genGenPointerSet
   2B45 8B 82               721 	mov	dpl,r3
   2B47 8C 83               722 	mov	dph,r4
   2B49 8D F0               723 	mov	b,r5
   2B4B E5 10               724 	mov	a,_bp
   2B4D 24 04               725 	add	a,#0x04
   2B4F F8                  726 	mov	r0,a
   2B50 E6                  727 	mov	a,@r0
   2B51 12 DF B7            728 	lcall	__gptrput
   2B54 A3                  729 	inc	dptr
   2B55 08                  730 	inc	r0
   2B56 E6                  731 	mov	a,@r0
   2B57 12 DF B7            732 	lcall	__gptrput
   2B5A A3                  733 	inc	dptr
   2B5B 08                  734 	inc	r0
   2B5C E6                  735 	mov	a,@r0
   2B5D 12 DF B7            736 	lcall	__gptrput
                            737 ;	../../FreeRTOS/Source/list.c:105: pxList->uxNumberOfItems = 0;
                            738 ;	genPointerSet
                            739 ;	genGenPointerSet
   2B60 A8 10               740 	mov	r0,_bp
   2B62 08                  741 	inc	r0
   2B63 86 82               742 	mov	dpl,@r0
   2B65 08                  743 	inc	r0
   2B66 86 83               744 	mov	dph,@r0
   2B68 08                  745 	inc	r0
   2B69 86 F0               746 	mov	b,@r0
                            747 ;	Peephole 181	changed mov to clr
   2B6B E4                  748 	clr	a
   2B6C 12 DF B7            749 	lcall	__gptrput
                            750 ;	Peephole 300	removed redundant label 00101$
   2B6F 85 10 81            751 	mov	sp,_bp
   2B72 D0 10               752 	pop	_bp
   2B74 22                  753 	ret
                            754 ;------------------------------------------------------------
                            755 ;Allocation info for local variables in function 'vListInitialiseItem'
                            756 ;------------------------------------------------------------
                            757 ;pxItem                    Allocated to registers r2 r3 r4 
                            758 ;------------------------------------------------------------
                            759 ;	../../FreeRTOS/Source/list.c:109: void vListInitialiseItem( xListItem *pxItem )
                            760 ;	-----------------------------------------
                            761 ;	 function vListInitialiseItem
                            762 ;	-----------------------------------------
   2B75                     763 _vListInitialiseItem:
                            764 ;	genReceive
   2B75 AA 82               765 	mov	r2,dpl
   2B77 AB 83               766 	mov	r3,dph
   2B79 AC F0               767 	mov	r4,b
                            768 ;	../../FreeRTOS/Source/list.c:112: pxItem->pvContainer = NULL;
                            769 ;	genPlus
                            770 ;     genPlusIncr
   2B7B 74 0B               771 	mov	a,#0x0B
                            772 ;	Peephole 236.a	used r2 instead of ar2
   2B7D 2A                  773 	add	a,r2
   2B7E FA                  774 	mov	r2,a
                            775 ;	Peephole 181	changed mov to clr
   2B7F E4                  776 	clr	a
                            777 ;	Peephole 236.b	used r3 instead of ar3
   2B80 3B                  778 	addc	a,r3
   2B81 FB                  779 	mov	r3,a
                            780 ;	genPointerSet
                            781 ;	genGenPointerSet
   2B82 8A 82               782 	mov	dpl,r2
   2B84 8B 83               783 	mov	dph,r3
   2B86 8C F0               784 	mov	b,r4
                            785 ;	Peephole 181	changed mov to clr
   2B88 E4                  786 	clr	a
   2B89 12 DF B7            787 	lcall	__gptrput
   2B8C A3                  788 	inc	dptr
                            789 ;	Peephole 181	changed mov to clr
   2B8D E4                  790 	clr	a
   2B8E 12 DF B7            791 	lcall	__gptrput
   2B91 A3                  792 	inc	dptr
                            793 ;	Peephole 181	changed mov to clr
   2B92 E4                  794 	clr	a
                            795 ;	Peephole 253.b	replaced lcall/ret with ljmp
   2B93 02 DF B7            796 	ljmp	__gptrput
                            797 ;
                            798 ;------------------------------------------------------------
                            799 ;Allocation info for local variables in function 'vListInsertEnd'
                            800 ;------------------------------------------------------------
                            801 ;pxNewListItem             Allocated to stack - offset -5
                            802 ;pxList                    Allocated to stack - offset 1
                            803 ;pxIndex                   Allocated to stack - offset 4
                            804 ;sloc0                     Allocated to stack - offset 7
                            805 ;sloc1                     Allocated to stack - offset 10
                            806 ;------------------------------------------------------------
                            807 ;	../../FreeRTOS/Source/list.c:116: void vListInsertEnd( xList *pxList, xListItem *pxNewListItem )
                            808 ;	-----------------------------------------
                            809 ;	 function vListInsertEnd
                            810 ;	-----------------------------------------
   2B96                     811 _vListInsertEnd:
   2B96 C0 10               812 	push	_bp
   2B98 85 81 10            813 	mov	_bp,sp
                            814 ;     genReceive
   2B9B C0 82               815 	push	dpl
   2B9D C0 83               816 	push	dph
   2B9F C0 F0               817 	push	b
   2BA1 E5 81               818 	mov	a,sp
   2BA3 24 0C               819 	add	a,#0x0c
   2BA5 F5 81               820 	mov	sp,a
                            821 ;	../../FreeRTOS/Source/list.c:124: pxIndex = pxList->pxIndex;
                            822 ;	genPlus
   2BA7 A8 10               823 	mov	r0,_bp
   2BA9 08                  824 	inc	r0
   2BAA E5 10               825 	mov	a,_bp
   2BAC 24 07               826 	add	a,#0x07
   2BAE F9                  827 	mov	r1,a
                            828 ;     genPlusIncr
   2BAF 74 01               829 	mov	a,#0x01
   2BB1 26                  830 	add	a,@r0
   2BB2 F7                  831 	mov	@r1,a
                            832 ;	Peephole 181	changed mov to clr
   2BB3 E4                  833 	clr	a
   2BB4 08                  834 	inc	r0
   2BB5 36                  835 	addc	a,@r0
   2BB6 09                  836 	inc	r1
   2BB7 F7                  837 	mov	@r1,a
   2BB8 08                  838 	inc	r0
   2BB9 09                  839 	inc	r1
   2BBA E6                  840 	mov	a,@r0
   2BBB F7                  841 	mov	@r1,a
                            842 ;	genPointerGet
                            843 ;	genGenPointerGet
   2BBC E5 10               844 	mov	a,_bp
   2BBE 24 07               845 	add	a,#0x07
   2BC0 F8                  846 	mov	r0,a
   2BC1 86 82               847 	mov	dpl,@r0
   2BC3 08                  848 	inc	r0
   2BC4 86 83               849 	mov	dph,@r0
   2BC6 08                  850 	inc	r0
   2BC7 86 F0               851 	mov	b,@r0
   2BC9 12 E4 9F            852 	lcall	__gptrget
   2BCC FA                  853 	mov	r2,a
   2BCD A3                  854 	inc	dptr
   2BCE 12 E4 9F            855 	lcall	__gptrget
   2BD1 FB                  856 	mov	r3,a
   2BD2 A3                  857 	inc	dptr
   2BD3 12 E4 9F            858 	lcall	__gptrget
   2BD6 FC                  859 	mov	r4,a
                            860 ;	genAssign
   2BD7 E5 10               861 	mov	a,_bp
   2BD9 24 04               862 	add	a,#0x04
   2BDB F8                  863 	mov	r0,a
   2BDC A6 02               864 	mov	@r0,ar2
   2BDE 08                  865 	inc	r0
   2BDF A6 03               866 	mov	@r0,ar3
   2BE1 08                  867 	inc	r0
   2BE2 A6 04               868 	mov	@r0,ar4
                            869 ;	../../FreeRTOS/Source/list.c:126: pxNewListItem->pxNext = pxIndex->pxNext;
                            870 ;	genAssign
   2BE4 E5 10               871 	mov	a,_bp
   2BE6 24 FB               872 	add	a,#0xfffffffb
   2BE8 F8                  873 	mov	r0,a
   2BE9 86 02               874 	mov	ar2,@r0
   2BEB 08                  875 	inc	r0
   2BEC 86 03               876 	mov	ar3,@r0
   2BEE 08                  877 	inc	r0
   2BEF 86 04               878 	mov	ar4,@r0
                            879 ;	genPlus
   2BF1 E5 10               880 	mov	a,_bp
   2BF3 24 0A               881 	add	a,#0x0a
   2BF5 F8                  882 	mov	r0,a
                            883 ;     genPlusIncr
   2BF6 74 02               884 	mov	a,#0x02
                            885 ;	Peephole 236.a	used r2 instead of ar2
   2BF8 2A                  886 	add	a,r2
   2BF9 F6                  887 	mov	@r0,a
                            888 ;	Peephole 181	changed mov to clr
   2BFA E4                  889 	clr	a
                            890 ;	Peephole 236.b	used r3 instead of ar3
   2BFB 3B                  891 	addc	a,r3
   2BFC 08                  892 	inc	r0
   2BFD F6                  893 	mov	@r0,a
   2BFE 08                  894 	inc	r0
   2BFF A6 04               895 	mov	@r0,ar4
                            896 ;	genAssign
   2C01 E5 10               897 	mov	a,_bp
   2C03 24 04               898 	add	a,#0x04
   2C05 F8                  899 	mov	r0,a
   2C06 86 05               900 	mov	ar5,@r0
   2C08 08                  901 	inc	r0
   2C09 86 06               902 	mov	ar6,@r0
   2C0B 08                  903 	inc	r0
   2C0C 86 07               904 	mov	ar7,@r0
                            905 ;	genPlus
                            906 ;     genPlusIncr
   2C0E 74 02               907 	mov	a,#0x02
                            908 ;	Peephole 236.a	used r5 instead of ar5
   2C10 2D                  909 	add	a,r5
   2C11 FD                  910 	mov	r5,a
                            911 ;	Peephole 181	changed mov to clr
   2C12 E4                  912 	clr	a
                            913 ;	Peephole 236.b	used r6 instead of ar6
   2C13 3E                  914 	addc	a,r6
   2C14 FE                  915 	mov	r6,a
                            916 ;	genPointerGet
                            917 ;	genGenPointerGet
   2C15 8D 82               918 	mov	dpl,r5
   2C17 8E 83               919 	mov	dph,r6
   2C19 8F F0               920 	mov	b,r7
   2C1B 12 E4 9F            921 	lcall	__gptrget
   2C1E FD                  922 	mov	r5,a
   2C1F A3                  923 	inc	dptr
   2C20 12 E4 9F            924 	lcall	__gptrget
   2C23 FE                  925 	mov	r6,a
   2C24 A3                  926 	inc	dptr
   2C25 12 E4 9F            927 	lcall	__gptrget
   2C28 FF                  928 	mov	r7,a
                            929 ;	genPointerSet
                            930 ;	genGenPointerSet
   2C29 E5 10               931 	mov	a,_bp
   2C2B 24 0A               932 	add	a,#0x0a
   2C2D F8                  933 	mov	r0,a
   2C2E 86 82               934 	mov	dpl,@r0
   2C30 08                  935 	inc	r0
   2C31 86 83               936 	mov	dph,@r0
   2C33 08                  937 	inc	r0
   2C34 86 F0               938 	mov	b,@r0
   2C36 ED                  939 	mov	a,r5
   2C37 12 DF B7            940 	lcall	__gptrput
   2C3A A3                  941 	inc	dptr
   2C3B EE                  942 	mov	a,r6
   2C3C 12 DF B7            943 	lcall	__gptrput
   2C3F A3                  944 	inc	dptr
   2C40 EF                  945 	mov	a,r7
   2C41 12 DF B7            946 	lcall	__gptrput
                            947 ;	../../FreeRTOS/Source/list.c:127: pxNewListItem->pxPrevious = pxList->pxIndex;
                            948 ;	genPlus
   2C44 E5 10               949 	mov	a,_bp
   2C46 24 0A               950 	add	a,#0x0a
   2C48 F8                  951 	mov	r0,a
                            952 ;     genPlusIncr
   2C49 74 05               953 	mov	a,#0x05
                            954 ;	Peephole 236.a	used r2 instead of ar2
   2C4B 2A                  955 	add	a,r2
   2C4C F6                  956 	mov	@r0,a
                            957 ;	Peephole 181	changed mov to clr
   2C4D E4                  958 	clr	a
                            959 ;	Peephole 236.b	used r3 instead of ar3
   2C4E 3B                  960 	addc	a,r3
   2C4F 08                  961 	inc	r0
   2C50 F6                  962 	mov	@r0,a
   2C51 08                  963 	inc	r0
   2C52 A6 04               964 	mov	@r0,ar4
                            965 ;	genPointerGet
                            966 ;	genGenPointerGet
   2C54 E5 10               967 	mov	a,_bp
   2C56 24 07               968 	add	a,#0x07
   2C58 F8                  969 	mov	r0,a
   2C59 86 82               970 	mov	dpl,@r0
   2C5B 08                  971 	inc	r0
   2C5C 86 83               972 	mov	dph,@r0
   2C5E 08                  973 	inc	r0
   2C5F 86 F0               974 	mov	b,@r0
   2C61 12 E4 9F            975 	lcall	__gptrget
   2C64 FD                  976 	mov	r5,a
   2C65 A3                  977 	inc	dptr
   2C66 12 E4 9F            978 	lcall	__gptrget
   2C69 FE                  979 	mov	r6,a
   2C6A A3                  980 	inc	dptr
   2C6B 12 E4 9F            981 	lcall	__gptrget
   2C6E FF                  982 	mov	r7,a
                            983 ;	genPointerSet
                            984 ;	genGenPointerSet
   2C6F E5 10               985 	mov	a,_bp
   2C71 24 0A               986 	add	a,#0x0a
   2C73 F8                  987 	mov	r0,a
   2C74 86 82               988 	mov	dpl,@r0
   2C76 08                  989 	inc	r0
   2C77 86 83               990 	mov	dph,@r0
   2C79 08                  991 	inc	r0
   2C7A 86 F0               992 	mov	b,@r0
   2C7C ED                  993 	mov	a,r5
   2C7D 12 DF B7            994 	lcall	__gptrput
   2C80 A3                  995 	inc	dptr
   2C81 EE                  996 	mov	a,r6
   2C82 12 DF B7            997 	lcall	__gptrput
   2C85 A3                  998 	inc	dptr
   2C86 EF                  999 	mov	a,r7
   2C87 12 DF B7           1000 	lcall	__gptrput
                           1001 ;	../../FreeRTOS/Source/list.c:128: pxIndex->pxNext->pxPrevious = ( volatile xListItem * ) pxNewListItem;
                           1002 ;	genAssign
   2C8A E5 10              1003 	mov	a,_bp
   2C8C 24 04              1004 	add	a,#0x04
   2C8E F8                 1005 	mov	r0,a
   2C8F 86 05              1006 	mov	ar5,@r0
   2C91 08                 1007 	inc	r0
   2C92 86 06              1008 	mov	ar6,@r0
   2C94 08                 1009 	inc	r0
   2C95 86 07              1010 	mov	ar7,@r0
                           1011 ;	genPlus
                           1012 ;     genPlusIncr
   2C97 74 02              1013 	mov	a,#0x02
                           1014 ;	Peephole 236.a	used r5 instead of ar5
   2C99 2D                 1015 	add	a,r5
   2C9A FD                 1016 	mov	r5,a
                           1017 ;	Peephole 181	changed mov to clr
   2C9B E4                 1018 	clr	a
                           1019 ;	Peephole 236.b	used r6 instead of ar6
   2C9C 3E                 1020 	addc	a,r6
   2C9D FE                 1021 	mov	r6,a
                           1022 ;	genPointerGet
                           1023 ;	genGenPointerGet
   2C9E 8D 82              1024 	mov	dpl,r5
   2CA0 8E 83              1025 	mov	dph,r6
   2CA2 8F F0              1026 	mov	b,r7
   2CA4 12 E4 9F           1027 	lcall	__gptrget
   2CA7 FD                 1028 	mov	r5,a
   2CA8 A3                 1029 	inc	dptr
   2CA9 12 E4 9F           1030 	lcall	__gptrget
   2CAC FE                 1031 	mov	r6,a
   2CAD A3                 1032 	inc	dptr
   2CAE 12 E4 9F           1033 	lcall	__gptrget
   2CB1 FF                 1034 	mov	r7,a
                           1035 ;	genPlus
                           1036 ;     genPlusIncr
   2CB2 74 05              1037 	mov	a,#0x05
                           1038 ;	Peephole 236.a	used r5 instead of ar5
   2CB4 2D                 1039 	add	a,r5
   2CB5 FD                 1040 	mov	r5,a
                           1041 ;	Peephole 181	changed mov to clr
   2CB6 E4                 1042 	clr	a
                           1043 ;	Peephole 236.b	used r6 instead of ar6
   2CB7 3E                 1044 	addc	a,r6
   2CB8 FE                 1045 	mov	r6,a
                           1046 ;	genPointerSet
                           1047 ;	genGenPointerSet
   2CB9 8D 82              1048 	mov	dpl,r5
   2CBB 8E 83              1049 	mov	dph,r6
   2CBD 8F F0              1050 	mov	b,r7
   2CBF EA                 1051 	mov	a,r2
   2CC0 12 DF B7           1052 	lcall	__gptrput
   2CC3 A3                 1053 	inc	dptr
   2CC4 EB                 1054 	mov	a,r3
   2CC5 12 DF B7           1055 	lcall	__gptrput
   2CC8 A3                 1056 	inc	dptr
   2CC9 EC                 1057 	mov	a,r4
   2CCA 12 DF B7           1058 	lcall	__gptrput
                           1059 ;	../../FreeRTOS/Source/list.c:129: pxIndex->pxNext = ( volatile xListItem * ) pxNewListItem;
                           1060 ;	genAssign
   2CCD E5 10              1061 	mov	a,_bp
   2CCF 24 04              1062 	add	a,#0x04
   2CD1 F8                 1063 	mov	r0,a
   2CD2 86 05              1064 	mov	ar5,@r0
   2CD4 08                 1065 	inc	r0
   2CD5 86 06              1066 	mov	ar6,@r0
   2CD7 08                 1067 	inc	r0
   2CD8 86 07              1068 	mov	ar7,@r0
                           1069 ;	genPlus
                           1070 ;     genPlusIncr
   2CDA 74 02              1071 	mov	a,#0x02
                           1072 ;	Peephole 236.a	used r5 instead of ar5
   2CDC 2D                 1073 	add	a,r5
   2CDD FD                 1074 	mov	r5,a
                           1075 ;	Peephole 181	changed mov to clr
   2CDE E4                 1076 	clr	a
                           1077 ;	Peephole 236.b	used r6 instead of ar6
   2CDF 3E                 1078 	addc	a,r6
   2CE0 FE                 1079 	mov	r6,a
                           1080 ;	genPointerSet
                           1081 ;	genGenPointerSet
   2CE1 8D 82              1082 	mov	dpl,r5
   2CE3 8E 83              1083 	mov	dph,r6
   2CE5 8F F0              1084 	mov	b,r7
   2CE7 EA                 1085 	mov	a,r2
   2CE8 12 DF B7           1086 	lcall	__gptrput
   2CEB A3                 1087 	inc	dptr
   2CEC EB                 1088 	mov	a,r3
   2CED 12 DF B7           1089 	lcall	__gptrput
   2CF0 A3                 1090 	inc	dptr
   2CF1 EC                 1091 	mov	a,r4
   2CF2 12 DF B7           1092 	lcall	__gptrput
                           1093 ;	../../FreeRTOS/Source/list.c:130: pxList->pxIndex = ( volatile xListItem * ) pxNewListItem;
                           1094 ;	genPointerSet
                           1095 ;	genGenPointerSet
   2CF5 E5 10              1096 	mov	a,_bp
   2CF7 24 07              1097 	add	a,#0x07
   2CF9 F8                 1098 	mov	r0,a
   2CFA 86 82              1099 	mov	dpl,@r0
   2CFC 08                 1100 	inc	r0
   2CFD 86 83              1101 	mov	dph,@r0
   2CFF 08                 1102 	inc	r0
   2D00 86 F0              1103 	mov	b,@r0
   2D02 EA                 1104 	mov	a,r2
   2D03 12 DF B7           1105 	lcall	__gptrput
   2D06 A3                 1106 	inc	dptr
   2D07 EB                 1107 	mov	a,r3
   2D08 12 DF B7           1108 	lcall	__gptrput
   2D0B A3                 1109 	inc	dptr
   2D0C EC                 1110 	mov	a,r4
   2D0D 12 DF B7           1111 	lcall	__gptrput
                           1112 ;	../../FreeRTOS/Source/list.c:133: pxNewListItem->pvContainer = ( void * ) pxList;
                           1113 ;	genPlus
                           1114 ;     genPlusIncr
   2D10 74 0B              1115 	mov	a,#0x0B
                           1116 ;	Peephole 236.a	used r2 instead of ar2
   2D12 2A                 1117 	add	a,r2
   2D13 FA                 1118 	mov	r2,a
                           1119 ;	Peephole 181	changed mov to clr
   2D14 E4                 1120 	clr	a
                           1121 ;	Peephole 236.b	used r3 instead of ar3
   2D15 3B                 1122 	addc	a,r3
   2D16 FB                 1123 	mov	r3,a
                           1124 ;	genPointerSet
                           1125 ;	genGenPointerSet
   2D17 8A 82              1126 	mov	dpl,r2
   2D19 8B 83              1127 	mov	dph,r3
   2D1B 8C F0              1128 	mov	b,r4
   2D1D A8 10              1129 	mov	r0,_bp
   2D1F 08                 1130 	inc	r0
   2D20 E6                 1131 	mov	a,@r0
   2D21 12 DF B7           1132 	lcall	__gptrput
   2D24 A3                 1133 	inc	dptr
   2D25 08                 1134 	inc	r0
   2D26 E6                 1135 	mov	a,@r0
   2D27 12 DF B7           1136 	lcall	__gptrput
   2D2A A3                 1137 	inc	dptr
   2D2B 08                 1138 	inc	r0
   2D2C E6                 1139 	mov	a,@r0
   2D2D 12 DF B7           1140 	lcall	__gptrput
                           1141 ;	../../FreeRTOS/Source/list.c:135: ( pxList->uxNumberOfItems )++;
                           1142 ;	genPointerGet
                           1143 ;	genGenPointerGet
   2D30 A8 10              1144 	mov	r0,_bp
   2D32 08                 1145 	inc	r0
   2D33 86 82              1146 	mov	dpl,@r0
   2D35 08                 1147 	inc	r0
   2D36 86 83              1148 	mov	dph,@r0
   2D38 08                 1149 	inc	r0
   2D39 86 F0              1150 	mov	b,@r0
   2D3B 12 E4 9F           1151 	lcall	__gptrget
                           1152 ;	genPlus
                           1153 ;     genPlusIncr
                           1154 ;	Peephole 185	changed order of increment (acc incremented also!)
   2D3E 04                 1155 	inc	a
   2D3F FA                 1156 	mov	r2,a
                           1157 ;	genPointerSet
                           1158 ;	genGenPointerSet
   2D40 A8 10              1159 	mov	r0,_bp
   2D42 08                 1160 	inc	r0
   2D43 86 82              1161 	mov	dpl,@r0
   2D45 08                 1162 	inc	r0
   2D46 86 83              1163 	mov	dph,@r0
   2D48 08                 1164 	inc	r0
   2D49 86 F0              1165 	mov	b,@r0
   2D4B EA                 1166 	mov	a,r2
   2D4C 12 DF B7           1167 	lcall	__gptrput
                           1168 ;	Peephole 300	removed redundant label 00101$
   2D4F 85 10 81           1169 	mov	sp,_bp
   2D52 D0 10              1170 	pop	_bp
   2D54 22                 1171 	ret
                           1172 ;------------------------------------------------------------
                           1173 ;Allocation info for local variables in function 'vListInsert'
                           1174 ;------------------------------------------------------------
                           1175 ;pxNewListItem             Allocated to stack - offset -5
                           1176 ;pxList                    Allocated to stack - offset 1
                           1177 ;pxIterator                Allocated to stack - offset 4
                           1178 ;xValueOfInsertion         Allocated to stack - offset 7
                           1179 ;sloc0                     Allocated to stack - offset 9
                           1180 ;------------------------------------------------------------
                           1181 ;	../../FreeRTOS/Source/list.c:139: void vListInsert( xList *pxList, xListItem *pxNewListItem )
                           1182 ;	-----------------------------------------
                           1183 ;	 function vListInsert
                           1184 ;	-----------------------------------------
   2D55                    1185 _vListInsert:
   2D55 C0 10              1186 	push	_bp
   2D57 85 81 10           1187 	mov	_bp,sp
                           1188 ;     genReceive
   2D5A C0 82              1189 	push	dpl
   2D5C C0 83              1190 	push	dph
   2D5E C0 F0              1191 	push	b
   2D60 E5 81              1192 	mov	a,sp
   2D62 24 0B              1193 	add	a,#0x0b
   2D64 F5 81              1194 	mov	sp,a
                           1195 ;	../../FreeRTOS/Source/list.c:145: xValueOfInsertion = pxNewListItem->xItemValue;
                           1196 ;	genAssign
   2D66 E5 10              1197 	mov	a,_bp
   2D68 24 FB              1198 	add	a,#0xfffffffb
   2D6A F8                 1199 	mov	r0,a
   2D6B 86 05              1200 	mov	ar5,@r0
   2D6D 08                 1201 	inc	r0
   2D6E 86 06              1202 	mov	ar6,@r0
   2D70 08                 1203 	inc	r0
   2D71 86 07              1204 	mov	ar7,@r0
                           1205 ;	genPointerGet
                           1206 ;	genGenPointerGet
   2D73 8D 82              1207 	mov	dpl,r5
   2D75 8E 83              1208 	mov	dph,r6
   2D77 8F F0              1209 	mov	b,r7
   2D79 12 E4 9F           1210 	lcall	__gptrget
   2D7C FA                 1211 	mov	r2,a
   2D7D A3                 1212 	inc	dptr
   2D7E 12 E4 9F           1213 	lcall	__gptrget
   2D81 FB                 1214 	mov	r3,a
                           1215 ;	genAssign
   2D82 E5 10              1216 	mov	a,_bp
   2D84 24 07              1217 	add	a,#0x07
   2D86 F8                 1218 	mov	r0,a
   2D87 A6 02              1219 	mov	@r0,ar2
   2D89 08                 1220 	inc	r0
   2D8A A6 03              1221 	mov	@r0,ar3
                           1222 ;	../../FreeRTOS/Source/list.c:154: if( xValueOfInsertion == portMAX_DELAY )
                           1223 ;	genCmpEq
   2D8C E5 10              1224 	mov	a,_bp
   2D8E 24 07              1225 	add	a,#0x07
   2D90 F8                 1226 	mov	r0,a
                           1227 ;	gencjneshort
                           1228 ;	Peephole 112.b	changed ljmp to sjmp
                           1229 ;	Peephole 197.c	optimized misc jump sequence
   2D91 B6 FF 49           1230 	cjne	@r0,#0xFF,00102$
   2D94 08                 1231 	inc	r0
   2D95 B6 FF 45           1232 	cjne	@r0,#0xFF,00102$
                           1233 ;	Peephole 200.b	removed redundant sjmp
                           1234 ;	Peephole 300	removed redundant label 00113$
                           1235 ;	Peephole 300	removed redundant label 00114$
                           1236 ;	../../FreeRTOS/Source/list.c:156: pxIterator = pxList->xListEnd.pxPrevious;
                           1237 ;	genIpush
   2D98 C0 05              1238 	push	ar5
   2D9A C0 06              1239 	push	ar6
   2D9C C0 07              1240 	push	ar7
                           1241 ;	genPlus
   2D9E A8 10              1242 	mov	r0,_bp
   2DA0 08                 1243 	inc	r0
                           1244 ;     genPlusIncr
   2DA1 74 04              1245 	mov	a,#0x04
   2DA3 26                 1246 	add	a,@r0
   2DA4 FD                 1247 	mov	r5,a
                           1248 ;	Peephole 181	changed mov to clr
   2DA5 E4                 1249 	clr	a
   2DA6 08                 1250 	inc	r0
   2DA7 36                 1251 	addc	a,@r0
   2DA8 FE                 1252 	mov	r6,a
   2DA9 08                 1253 	inc	r0
   2DAA 86 07              1254 	mov	ar7,@r0
                           1255 ;	genPlus
                           1256 ;     genPlusIncr
   2DAC 74 05              1257 	mov	a,#0x05
                           1258 ;	Peephole 236.a	used r5 instead of ar5
   2DAE 2D                 1259 	add	a,r5
   2DAF FD                 1260 	mov	r5,a
                           1261 ;	Peephole 181	changed mov to clr
   2DB0 E4                 1262 	clr	a
                           1263 ;	Peephole 236.b	used r6 instead of ar6
   2DB1 3E                 1264 	addc	a,r6
   2DB2 FE                 1265 	mov	r6,a
                           1266 ;	genPointerGet
                           1267 ;	genGenPointerGet
   2DB3 8D 82              1268 	mov	dpl,r5
   2DB5 8E 83              1269 	mov	dph,r6
   2DB7 8F F0              1270 	mov	b,r7
   2DB9 12 E4 9F           1271 	lcall	__gptrget
   2DBC FD                 1272 	mov	r5,a
   2DBD A3                 1273 	inc	dptr
   2DBE 12 E4 9F           1274 	lcall	__gptrget
   2DC1 FE                 1275 	mov	r6,a
   2DC2 A3                 1276 	inc	dptr
   2DC3 12 E4 9F           1277 	lcall	__gptrget
   2DC6 FF                 1278 	mov	r7,a
                           1279 ;	genAssign
   2DC7 E5 10              1280 	mov	a,_bp
   2DC9 24 04              1281 	add	a,#0x04
   2DCB F8                 1282 	mov	r0,a
   2DCC A6 05              1283 	mov	@r0,ar5
   2DCE 08                 1284 	inc	r0
   2DCF A6 06              1285 	mov	@r0,ar6
   2DD1 08                 1286 	inc	r0
   2DD2 A6 07              1287 	mov	@r0,ar7
                           1288 ;	genIpop
   2DD4 D0 07              1289 	pop	ar7
   2DD6 D0 06              1290 	pop	ar6
   2DD8 D0 05              1291 	pop	ar5
   2DDA 02 2E 6E           1292 	ljmp	00103$
   2DDD                    1293 00102$:
                           1294 ;	../../FreeRTOS/Source/list.c:160: for( pxIterator = ( xListItem * ) &( pxList->xListEnd ); pxIterator->pxNext->xItemValue <= xValueOfInsertion; pxIterator = pxIterator->pxNext )
                           1295 ;	genPlus
   2DDD A8 10              1296 	mov	r0,_bp
   2DDF 08                 1297 	inc	r0
   2DE0 E5 10              1298 	mov	a,_bp
   2DE2 24 04              1299 	add	a,#0x04
   2DE4 F9                 1300 	mov	r1,a
                           1301 ;     genPlusIncr
   2DE5 74 04              1302 	mov	a,#0x04
   2DE7 26                 1303 	add	a,@r0
   2DE8 F7                 1304 	mov	@r1,a
                           1305 ;	Peephole 181	changed mov to clr
   2DE9 E4                 1306 	clr	a
   2DEA 08                 1307 	inc	r0
   2DEB 36                 1308 	addc	a,@r0
   2DEC 09                 1309 	inc	r1
   2DED F7                 1310 	mov	@r1,a
   2DEE 08                 1311 	inc	r0
   2DEF 09                 1312 	inc	r1
   2DF0 E6                 1313 	mov	a,@r0
   2DF1 F7                 1314 	mov	@r1,a
   2DF2                    1315 00104$:
                           1316 ;	genIpush
                           1317 ;	genAssign
   2DF2 E5 10              1318 	mov	a,_bp
   2DF4 24 04              1319 	add	a,#0x04
   2DF6 F8                 1320 	mov	r0,a
   2DF7 86 02              1321 	mov	ar2,@r0
   2DF9 08                 1322 	inc	r0
   2DFA 86 03              1323 	mov	ar3,@r0
   2DFC 08                 1324 	inc	r0
   2DFD 86 04              1325 	mov	ar4,@r0
                           1326 ;	genPlus
                           1327 ;     genPlusIncr
   2DFF 74 02              1328 	mov	a,#0x02
                           1329 ;	Peephole 236.a	used r2 instead of ar2
   2E01 2A                 1330 	add	a,r2
   2E02 FA                 1331 	mov	r2,a
                           1332 ;	Peephole 181	changed mov to clr
   2E03 E4                 1333 	clr	a
                           1334 ;	Peephole 236.b	used r3 instead of ar3
   2E04 3B                 1335 	addc	a,r3
   2E05 FB                 1336 	mov	r3,a
                           1337 ;	genPointerGet
                           1338 ;	genGenPointerGet
   2E06 8A 82              1339 	mov	dpl,r2
   2E08 8B 83              1340 	mov	dph,r3
   2E0A 8C F0              1341 	mov	b,r4
   2E0C 12 E4 9F           1342 	lcall	__gptrget
   2E0F FA                 1343 	mov	r2,a
   2E10 A3                 1344 	inc	dptr
   2E11 12 E4 9F           1345 	lcall	__gptrget
   2E14 FB                 1346 	mov	r3,a
   2E15 A3                 1347 	inc	dptr
   2E16 12 E4 9F           1348 	lcall	__gptrget
   2E19 FC                 1349 	mov	r4,a
                           1350 ;	genPointerGet
                           1351 ;	genGenPointerGet
   2E1A 8A 82              1352 	mov	dpl,r2
   2E1C 8B 83              1353 	mov	dph,r3
   2E1E 8C F0              1354 	mov	b,r4
   2E20 12 E4 9F           1355 	lcall	__gptrget
   2E23 FA                 1356 	mov	r2,a
   2E24 A3                 1357 	inc	dptr
   2E25 12 E4 9F           1358 	lcall	__gptrget
   2E28 FB                 1359 	mov	r3,a
                           1360 ;	genCmpGt
   2E29 E5 10              1361 	mov	a,_bp
   2E2B 24 07              1362 	add	a,#0x07
   2E2D F8                 1363 	mov	r0,a
                           1364 ;	genCmp
   2E2E C3                 1365 	clr	c
   2E2F E6                 1366 	mov	a,@r0
   2E30 9A                 1367 	subb	a,r2
   2E31 08                 1368 	inc	r0
   2E32 E6                 1369 	mov	a,@r0
   2E33 9B                 1370 	subb	a,r3
                           1371 ;	genIpop
                           1372 ;	genIfx
                           1373 ;	genIfxJump
                           1374 ;	Peephole 108.b	removed ljmp by inverse jump logic
                           1375 ;	Peephole 129.a	jump optimization
   2E34 40 38              1376 	jc	00103$
                           1377 ;	Peephole 300	removed redundant label 00115$
                           1378 ;	genIpush
                           1379 ;	genAssign
   2E36 E5 10              1380 	mov	a,_bp
   2E38 24 04              1381 	add	a,#0x04
   2E3A F8                 1382 	mov	r0,a
   2E3B 86 02              1383 	mov	ar2,@r0
   2E3D 08                 1384 	inc	r0
   2E3E 86 03              1385 	mov	ar3,@r0
   2E40 08                 1386 	inc	r0
   2E41 86 04              1387 	mov	ar4,@r0
                           1388 ;	genPlus
                           1389 ;     genPlusIncr
   2E43 74 02              1390 	mov	a,#0x02
                           1391 ;	Peephole 236.a	used r2 instead of ar2
   2E45 2A                 1392 	add	a,r2
   2E46 FA                 1393 	mov	r2,a
                           1394 ;	Peephole 181	changed mov to clr
   2E47 E4                 1395 	clr	a
                           1396 ;	Peephole 236.b	used r3 instead of ar3
   2E48 3B                 1397 	addc	a,r3
   2E49 FB                 1398 	mov	r3,a
                           1399 ;	genPointerGet
                           1400 ;	genGenPointerGet
   2E4A 8A 82              1401 	mov	dpl,r2
   2E4C 8B 83              1402 	mov	dph,r3
   2E4E 8C F0              1403 	mov	b,r4
   2E50 12 E4 9F           1404 	lcall	__gptrget
   2E53 FA                 1405 	mov	r2,a
   2E54 A3                 1406 	inc	dptr
   2E55 12 E4 9F           1407 	lcall	__gptrget
   2E58 FB                 1408 	mov	r3,a
   2E59 A3                 1409 	inc	dptr
   2E5A 12 E4 9F           1410 	lcall	__gptrget
   2E5D FC                 1411 	mov	r4,a
                           1412 ;	genAssign
   2E5E E5 10              1413 	mov	a,_bp
   2E60 24 04              1414 	add	a,#0x04
   2E62 F8                 1415 	mov	r0,a
   2E63 A6 02              1416 	mov	@r0,ar2
   2E65 08                 1417 	inc	r0
   2E66 A6 03              1418 	mov	@r0,ar3
   2E68 08                 1419 	inc	r0
   2E69 A6 04              1420 	mov	@r0,ar4
                           1421 ;	genIpop
   2E6B 02 2D F2           1422 	ljmp	00104$
   2E6E                    1423 00103$:
                           1424 ;	../../FreeRTOS/Source/list.c:167: pxNewListItem->pxNext = pxIterator->pxNext;
                           1425 ;	genPlus
   2E6E E5 10              1426 	mov	a,_bp
   2E70 24 09              1427 	add	a,#0x09
   2E72 F8                 1428 	mov	r0,a
                           1429 ;     genPlusIncr
   2E73 74 02              1430 	mov	a,#0x02
                           1431 ;	Peephole 236.a	used r5 instead of ar5
   2E75 2D                 1432 	add	a,r5
   2E76 F6                 1433 	mov	@r0,a
                           1434 ;	Peephole 181	changed mov to clr
   2E77 E4                 1435 	clr	a
                           1436 ;	Peephole 236.b	used r6 instead of ar6
   2E78 3E                 1437 	addc	a,r6
   2E79 08                 1438 	inc	r0
   2E7A F6                 1439 	mov	@r0,a
   2E7B 08                 1440 	inc	r0
   2E7C A6 07              1441 	mov	@r0,ar7
                           1442 ;	genAssign
   2E7E E5 10              1443 	mov	a,_bp
   2E80 24 04              1444 	add	a,#0x04
   2E82 F8                 1445 	mov	r0,a
   2E83 86 02              1446 	mov	ar2,@r0
   2E85 08                 1447 	inc	r0
   2E86 86 03              1448 	mov	ar3,@r0
   2E88 08                 1449 	inc	r0
   2E89 86 04              1450 	mov	ar4,@r0
                           1451 ;	genPlus
                           1452 ;     genPlusIncr
   2E8B 74 02              1453 	mov	a,#0x02
                           1454 ;	Peephole 236.a	used r2 instead of ar2
   2E8D 2A                 1455 	add	a,r2
   2E8E FA                 1456 	mov	r2,a
                           1457 ;	Peephole 181	changed mov to clr
   2E8F E4                 1458 	clr	a
                           1459 ;	Peephole 236.b	used r3 instead of ar3
   2E90 3B                 1460 	addc	a,r3
   2E91 FB                 1461 	mov	r3,a
                           1462 ;	genPointerGet
                           1463 ;	genGenPointerGet
   2E92 8A 82              1464 	mov	dpl,r2
   2E94 8B 83              1465 	mov	dph,r3
   2E96 8C F0              1466 	mov	b,r4
   2E98 12 E4 9F           1467 	lcall	__gptrget
   2E9B FA                 1468 	mov	r2,a
   2E9C A3                 1469 	inc	dptr
   2E9D 12 E4 9F           1470 	lcall	__gptrget
   2EA0 FB                 1471 	mov	r3,a
   2EA1 A3                 1472 	inc	dptr
   2EA2 12 E4 9F           1473 	lcall	__gptrget
   2EA5 FC                 1474 	mov	r4,a
                           1475 ;	genPointerSet
                           1476 ;	genGenPointerSet
   2EA6 E5 10              1477 	mov	a,_bp
   2EA8 24 09              1478 	add	a,#0x09
   2EAA F8                 1479 	mov	r0,a
   2EAB 86 82              1480 	mov	dpl,@r0
   2EAD 08                 1481 	inc	r0
   2EAE 86 83              1482 	mov	dph,@r0
   2EB0 08                 1483 	inc	r0
   2EB1 86 F0              1484 	mov	b,@r0
   2EB3 EA                 1485 	mov	a,r2
   2EB4 12 DF B7           1486 	lcall	__gptrput
   2EB7 A3                 1487 	inc	dptr
   2EB8 EB                 1488 	mov	a,r3
   2EB9 12 DF B7           1489 	lcall	__gptrput
   2EBC A3                 1490 	inc	dptr
   2EBD EC                 1491 	mov	a,r4
   2EBE 12 DF B7           1492 	lcall	__gptrput
                           1493 ;	../../FreeRTOS/Source/list.c:168: pxNewListItem->pxNext->pxPrevious = ( volatile xListItem * ) pxNewListItem;
                           1494 ;	genPointerGet
                           1495 ;	genGenPointerGet
   2EC1 E5 10              1496 	mov	a,_bp
   2EC3 24 09              1497 	add	a,#0x09
   2EC5 F8                 1498 	mov	r0,a
   2EC6 86 82              1499 	mov	dpl,@r0
   2EC8 08                 1500 	inc	r0
   2EC9 86 83              1501 	mov	dph,@r0
   2ECB 08                 1502 	inc	r0
   2ECC 86 F0              1503 	mov	b,@r0
   2ECE 12 E4 9F           1504 	lcall	__gptrget
   2ED1 FA                 1505 	mov	r2,a
   2ED2 A3                 1506 	inc	dptr
   2ED3 12 E4 9F           1507 	lcall	__gptrget
   2ED6 FB                 1508 	mov	r3,a
   2ED7 A3                 1509 	inc	dptr
   2ED8 12 E4 9F           1510 	lcall	__gptrget
   2EDB FC                 1511 	mov	r4,a
                           1512 ;	genPlus
                           1513 ;     genPlusIncr
   2EDC 74 05              1514 	mov	a,#0x05
                           1515 ;	Peephole 236.a	used r2 instead of ar2
   2EDE 2A                 1516 	add	a,r2
   2EDF FA                 1517 	mov	r2,a
                           1518 ;	Peephole 181	changed mov to clr
   2EE0 E4                 1519 	clr	a
                           1520 ;	Peephole 236.b	used r3 instead of ar3
   2EE1 3B                 1521 	addc	a,r3
   2EE2 FB                 1522 	mov	r3,a
                           1523 ;	genPointerSet
                           1524 ;	genGenPointerSet
   2EE3 8A 82              1525 	mov	dpl,r2
   2EE5 8B 83              1526 	mov	dph,r3
   2EE7 8C F0              1527 	mov	b,r4
   2EE9 ED                 1528 	mov	a,r5
   2EEA 12 DF B7           1529 	lcall	__gptrput
   2EED A3                 1530 	inc	dptr
   2EEE EE                 1531 	mov	a,r6
   2EEF 12 DF B7           1532 	lcall	__gptrput
   2EF2 A3                 1533 	inc	dptr
   2EF3 EF                 1534 	mov	a,r7
   2EF4 12 DF B7           1535 	lcall	__gptrput
                           1536 ;	../../FreeRTOS/Source/list.c:169: pxNewListItem->pxPrevious = pxIterator;
                           1537 ;	genPlus
                           1538 ;     genPlusIncr
   2EF7 74 05              1539 	mov	a,#0x05
                           1540 ;	Peephole 236.a	used r5 instead of ar5
   2EF9 2D                 1541 	add	a,r5
   2EFA FA                 1542 	mov	r2,a
                           1543 ;	Peephole 181	changed mov to clr
   2EFB E4                 1544 	clr	a
                           1545 ;	Peephole 236.b	used r6 instead of ar6
   2EFC 3E                 1546 	addc	a,r6
   2EFD FB                 1547 	mov	r3,a
   2EFE 8F 04              1548 	mov	ar4,r7
                           1549 ;	genPointerSet
                           1550 ;	genGenPointerSet
   2F00 8A 82              1551 	mov	dpl,r2
   2F02 8B 83              1552 	mov	dph,r3
   2F04 8C F0              1553 	mov	b,r4
   2F06 E5 10              1554 	mov	a,_bp
   2F08 24 04              1555 	add	a,#0x04
   2F0A F8                 1556 	mov	r0,a
   2F0B E6                 1557 	mov	a,@r0
   2F0C 12 DF B7           1558 	lcall	__gptrput
   2F0F A3                 1559 	inc	dptr
   2F10 08                 1560 	inc	r0
   2F11 E6                 1561 	mov	a,@r0
   2F12 12 DF B7           1562 	lcall	__gptrput
   2F15 A3                 1563 	inc	dptr
   2F16 08                 1564 	inc	r0
   2F17 E6                 1565 	mov	a,@r0
   2F18 12 DF B7           1566 	lcall	__gptrput
                           1567 ;	../../FreeRTOS/Source/list.c:170: pxIterator->pxNext = ( volatile xListItem * ) pxNewListItem;
                           1568 ;	genAssign
   2F1B E5 10              1569 	mov	a,_bp
   2F1D 24 04              1570 	add	a,#0x04
   2F1F F8                 1571 	mov	r0,a
   2F20 86 02              1572 	mov	ar2,@r0
   2F22 08                 1573 	inc	r0
   2F23 86 03              1574 	mov	ar3,@r0
   2F25 08                 1575 	inc	r0
   2F26 86 04              1576 	mov	ar4,@r0
                           1577 ;	genPlus
                           1578 ;     genPlusIncr
   2F28 74 02              1579 	mov	a,#0x02
                           1580 ;	Peephole 236.a	used r2 instead of ar2
   2F2A 2A                 1581 	add	a,r2
   2F2B FA                 1582 	mov	r2,a
                           1583 ;	Peephole 181	changed mov to clr
   2F2C E4                 1584 	clr	a
                           1585 ;	Peephole 236.b	used r3 instead of ar3
   2F2D 3B                 1586 	addc	a,r3
   2F2E FB                 1587 	mov	r3,a
                           1588 ;	genPointerSet
                           1589 ;	genGenPointerSet
   2F2F 8A 82              1590 	mov	dpl,r2
   2F31 8B 83              1591 	mov	dph,r3
   2F33 8C F0              1592 	mov	b,r4
   2F35 ED                 1593 	mov	a,r5
   2F36 12 DF B7           1594 	lcall	__gptrput
   2F39 A3                 1595 	inc	dptr
   2F3A EE                 1596 	mov	a,r6
   2F3B 12 DF B7           1597 	lcall	__gptrput
   2F3E A3                 1598 	inc	dptr
   2F3F EF                 1599 	mov	a,r7
   2F40 12 DF B7           1600 	lcall	__gptrput
                           1601 ;	../../FreeRTOS/Source/list.c:174: pxNewListItem->pvContainer = ( void * ) pxList;
                           1602 ;	genPlus
                           1603 ;     genPlusIncr
   2F43 74 0B              1604 	mov	a,#0x0B
                           1605 ;	Peephole 236.a	used r5 instead of ar5
   2F45 2D                 1606 	add	a,r5
   2F46 FD                 1607 	mov	r5,a
                           1608 ;	Peephole 181	changed mov to clr
   2F47 E4                 1609 	clr	a
                           1610 ;	Peephole 236.b	used r6 instead of ar6
   2F48 3E                 1611 	addc	a,r6
   2F49 FE                 1612 	mov	r6,a
                           1613 ;	genPointerSet
                           1614 ;	genGenPointerSet
   2F4A 8D 82              1615 	mov	dpl,r5
   2F4C 8E 83              1616 	mov	dph,r6
   2F4E 8F F0              1617 	mov	b,r7
   2F50 A8 10              1618 	mov	r0,_bp
   2F52 08                 1619 	inc	r0
   2F53 E6                 1620 	mov	a,@r0
   2F54 12 DF B7           1621 	lcall	__gptrput
   2F57 A3                 1622 	inc	dptr
   2F58 08                 1623 	inc	r0
   2F59 E6                 1624 	mov	a,@r0
   2F5A 12 DF B7           1625 	lcall	__gptrput
   2F5D A3                 1626 	inc	dptr
   2F5E 08                 1627 	inc	r0
   2F5F E6                 1628 	mov	a,@r0
   2F60 12 DF B7           1629 	lcall	__gptrput
                           1630 ;	../../FreeRTOS/Source/list.c:176: ( pxList->uxNumberOfItems )++;
                           1631 ;	genPointerGet
                           1632 ;	genGenPointerGet
   2F63 A8 10              1633 	mov	r0,_bp
   2F65 08                 1634 	inc	r0
   2F66 86 82              1635 	mov	dpl,@r0
   2F68 08                 1636 	inc	r0
   2F69 86 83              1637 	mov	dph,@r0
   2F6B 08                 1638 	inc	r0
   2F6C 86 F0              1639 	mov	b,@r0
   2F6E 12 E4 9F           1640 	lcall	__gptrget
                           1641 ;	genPlus
                           1642 ;     genPlusIncr
                           1643 ;	Peephole 185	changed order of increment (acc incremented also!)
   2F71 04                 1644 	inc	a
   2F72 FA                 1645 	mov	r2,a
                           1646 ;	genPointerSet
                           1647 ;	genGenPointerSet
   2F73 A8 10              1648 	mov	r0,_bp
   2F75 08                 1649 	inc	r0
   2F76 86 82              1650 	mov	dpl,@r0
   2F78 08                 1651 	inc	r0
   2F79 86 83              1652 	mov	dph,@r0
   2F7B 08                 1653 	inc	r0
   2F7C 86 F0              1654 	mov	b,@r0
   2F7E EA                 1655 	mov	a,r2
   2F7F 12 DF B7           1656 	lcall	__gptrput
                           1657 ;	Peephole 300	removed redundant label 00108$
   2F82 85 10 81           1658 	mov	sp,_bp
   2F85 D0 10              1659 	pop	_bp
   2F87 22                 1660 	ret
                           1661 ;------------------------------------------------------------
                           1662 ;Allocation info for local variables in function 'vListRemove'
                           1663 ;------------------------------------------------------------
                           1664 ;pxItemToRemove            Allocated to stack - offset 1
                           1665 ;pxList                    Allocated to stack - offset 4
                           1666 ;sloc0                     Allocated to stack - offset 7
                           1667 ;sloc1                     Allocated to stack - offset 10
                           1668 ;------------------------------------------------------------
                           1669 ;	../../FreeRTOS/Source/list.c:180: void vListRemove( xListItem *pxItemToRemove )
                           1670 ;	-----------------------------------------
                           1671 ;	 function vListRemove
                           1672 ;	-----------------------------------------
   2F88                    1673 _vListRemove:
   2F88 C0 10              1674 	push	_bp
   2F8A 85 81 10           1675 	mov	_bp,sp
                           1676 ;     genReceive
   2F8D C0 82              1677 	push	dpl
   2F8F C0 83              1678 	push	dph
   2F91 C0 F0              1679 	push	b
   2F93 E5 81              1680 	mov	a,sp
   2F95 24 0C              1681 	add	a,#0x0c
   2F97 F5 81              1682 	mov	sp,a
                           1683 ;	../../FreeRTOS/Source/list.c:184: pxItemToRemove->pxNext->pxPrevious = pxItemToRemove->pxPrevious;
                           1684 ;	genPlus
   2F99 A8 10              1685 	mov	r0,_bp
   2F9B 08                 1686 	inc	r0
                           1687 ;     genPlusIncr
   2F9C 74 02              1688 	mov	a,#0x02
   2F9E 26                 1689 	add	a,@r0
   2F9F FD                 1690 	mov	r5,a
                           1691 ;	Peephole 181	changed mov to clr
   2FA0 E4                 1692 	clr	a
   2FA1 08                 1693 	inc	r0
   2FA2 36                 1694 	addc	a,@r0
   2FA3 FE                 1695 	mov	r6,a
   2FA4 08                 1696 	inc	r0
   2FA5 86 07              1697 	mov	ar7,@r0
                           1698 ;	genPointerGet
                           1699 ;	genGenPointerGet
   2FA7 8D 82              1700 	mov	dpl,r5
   2FA9 8E 83              1701 	mov	dph,r6
   2FAB 8F F0              1702 	mov	b,r7
   2FAD 12 E4 9F           1703 	lcall	__gptrget
   2FB0 FA                 1704 	mov	r2,a
   2FB1 A3                 1705 	inc	dptr
   2FB2 12 E4 9F           1706 	lcall	__gptrget
   2FB5 FB                 1707 	mov	r3,a
   2FB6 A3                 1708 	inc	dptr
   2FB7 12 E4 9F           1709 	lcall	__gptrget
   2FBA FC                 1710 	mov	r4,a
                           1711 ;	genPlus
   2FBB E5 10              1712 	mov	a,_bp
   2FBD 24 0A              1713 	add	a,#0x0a
   2FBF F8                 1714 	mov	r0,a
                           1715 ;     genPlusIncr
   2FC0 74 05              1716 	mov	a,#0x05
                           1717 ;	Peephole 236.a	used r2 instead of ar2
   2FC2 2A                 1718 	add	a,r2
   2FC3 F6                 1719 	mov	@r0,a
                           1720 ;	Peephole 181	changed mov to clr
   2FC4 E4                 1721 	clr	a
                           1722 ;	Peephole 236.b	used r3 instead of ar3
   2FC5 3B                 1723 	addc	a,r3
   2FC6 08                 1724 	inc	r0
   2FC7 F6                 1725 	mov	@r0,a
   2FC8 08                 1726 	inc	r0
   2FC9 A6 04              1727 	mov	@r0,ar4
                           1728 ;	genPlus
   2FCB A8 10              1729 	mov	r0,_bp
   2FCD 08                 1730 	inc	r0
   2FCE E5 10              1731 	mov	a,_bp
   2FD0 24 07              1732 	add	a,#0x07
   2FD2 F9                 1733 	mov	r1,a
                           1734 ;     genPlusIncr
   2FD3 74 05              1735 	mov	a,#0x05
   2FD5 26                 1736 	add	a,@r0
   2FD6 F7                 1737 	mov	@r1,a
                           1738 ;	Peephole 181	changed mov to clr
   2FD7 E4                 1739 	clr	a
   2FD8 08                 1740 	inc	r0
   2FD9 36                 1741 	addc	a,@r0
   2FDA 09                 1742 	inc	r1
   2FDB F7                 1743 	mov	@r1,a
   2FDC 08                 1744 	inc	r0
   2FDD 09                 1745 	inc	r1
   2FDE E6                 1746 	mov	a,@r0
   2FDF F7                 1747 	mov	@r1,a
                           1748 ;	genPointerGet
                           1749 ;	genGenPointerGet
   2FE0 E5 10              1750 	mov	a,_bp
   2FE2 24 07              1751 	add	a,#0x07
   2FE4 F8                 1752 	mov	r0,a
   2FE5 86 82              1753 	mov	dpl,@r0
   2FE7 08                 1754 	inc	r0
   2FE8 86 83              1755 	mov	dph,@r0
   2FEA 08                 1756 	inc	r0
   2FEB 86 F0              1757 	mov	b,@r0
   2FED 12 E4 9F           1758 	lcall	__gptrget
   2FF0 FA                 1759 	mov	r2,a
   2FF1 A3                 1760 	inc	dptr
   2FF2 12 E4 9F           1761 	lcall	__gptrget
   2FF5 FB                 1762 	mov	r3,a
   2FF6 A3                 1763 	inc	dptr
   2FF7 12 E4 9F           1764 	lcall	__gptrget
   2FFA FC                 1765 	mov	r4,a
                           1766 ;	genPointerSet
                           1767 ;	genGenPointerSet
   2FFB E5 10              1768 	mov	a,_bp
   2FFD 24 0A              1769 	add	a,#0x0a
   2FFF F8                 1770 	mov	r0,a
   3000 86 82              1771 	mov	dpl,@r0
   3002 08                 1772 	inc	r0
   3003 86 83              1773 	mov	dph,@r0
   3005 08                 1774 	inc	r0
   3006 86 F0              1775 	mov	b,@r0
   3008 EA                 1776 	mov	a,r2
   3009 12 DF B7           1777 	lcall	__gptrput
   300C A3                 1778 	inc	dptr
   300D EB                 1779 	mov	a,r3
   300E 12 DF B7           1780 	lcall	__gptrput
   3011 A3                 1781 	inc	dptr
   3012 EC                 1782 	mov	a,r4
   3013 12 DF B7           1783 	lcall	__gptrput
                           1784 ;	../../FreeRTOS/Source/list.c:185: pxItemToRemove->pxPrevious->pxNext = pxItemToRemove->pxNext;
                           1785 ;	genPointerGet
                           1786 ;	genGenPointerGet
   3016 E5 10              1787 	mov	a,_bp
   3018 24 07              1788 	add	a,#0x07
   301A F8                 1789 	mov	r0,a
   301B 86 82              1790 	mov	dpl,@r0
   301D 08                 1791 	inc	r0
   301E 86 83              1792 	mov	dph,@r0
   3020 08                 1793 	inc	r0
   3021 86 F0              1794 	mov	b,@r0
   3023 12 E4 9F           1795 	lcall	__gptrget
   3026 FA                 1796 	mov	r2,a
   3027 A3                 1797 	inc	dptr
   3028 12 E4 9F           1798 	lcall	__gptrget
   302B FB                 1799 	mov	r3,a
   302C A3                 1800 	inc	dptr
   302D 12 E4 9F           1801 	lcall	__gptrget
   3030 FC                 1802 	mov	r4,a
                           1803 ;	genPlus
                           1804 ;     genPlusIncr
   3031 74 02              1805 	mov	a,#0x02
                           1806 ;	Peephole 236.a	used r2 instead of ar2
   3033 2A                 1807 	add	a,r2
   3034 FA                 1808 	mov	r2,a
                           1809 ;	Peephole 181	changed mov to clr
   3035 E4                 1810 	clr	a
                           1811 ;	Peephole 236.b	used r3 instead of ar3
   3036 3B                 1812 	addc	a,r3
   3037 FB                 1813 	mov	r3,a
                           1814 ;	genPointerGet
                           1815 ;	genGenPointerGet
   3038 8D 82              1816 	mov	dpl,r5
   303A 8E 83              1817 	mov	dph,r6
   303C 8F F0              1818 	mov	b,r7
   303E 12 E4 9F           1819 	lcall	__gptrget
   3041 FD                 1820 	mov	r5,a
   3042 A3                 1821 	inc	dptr
   3043 12 E4 9F           1822 	lcall	__gptrget
   3046 FE                 1823 	mov	r6,a
   3047 A3                 1824 	inc	dptr
   3048 12 E4 9F           1825 	lcall	__gptrget
   304B FF                 1826 	mov	r7,a
                           1827 ;	genPointerSet
                           1828 ;	genGenPointerSet
   304C 8A 82              1829 	mov	dpl,r2
   304E 8B 83              1830 	mov	dph,r3
   3050 8C F0              1831 	mov	b,r4
   3052 ED                 1832 	mov	a,r5
   3053 12 DF B7           1833 	lcall	__gptrput
   3056 A3                 1834 	inc	dptr
   3057 EE                 1835 	mov	a,r6
   3058 12 DF B7           1836 	lcall	__gptrput
   305B A3                 1837 	inc	dptr
   305C EF                 1838 	mov	a,r7
   305D 12 DF B7           1839 	lcall	__gptrput
                           1840 ;	../../FreeRTOS/Source/list.c:189: pxList = ( xList * ) pxItemToRemove->pvContainer;
                           1841 ;	genPlus
   3060 A8 10              1842 	mov	r0,_bp
   3062 08                 1843 	inc	r0
                           1844 ;     genPlusIncr
   3063 74 0B              1845 	mov	a,#0x0B
   3065 26                 1846 	add	a,@r0
   3066 FA                 1847 	mov	r2,a
                           1848 ;	Peephole 181	changed mov to clr
   3067 E4                 1849 	clr	a
   3068 08                 1850 	inc	r0
   3069 36                 1851 	addc	a,@r0
   306A FB                 1852 	mov	r3,a
   306B 08                 1853 	inc	r0
   306C 86 04              1854 	mov	ar4,@r0
                           1855 ;	genPointerGet
                           1856 ;	genGenPointerGet
   306E 8A 82              1857 	mov	dpl,r2
   3070 8B 83              1858 	mov	dph,r3
   3072 8C F0              1859 	mov	b,r4
   3074 12 E4 9F           1860 	lcall	__gptrget
   3077 FD                 1861 	mov	r5,a
   3078 A3                 1862 	inc	dptr
   3079 12 E4 9F           1863 	lcall	__gptrget
   307C FE                 1864 	mov	r6,a
   307D A3                 1865 	inc	dptr
   307E 12 E4 9F           1866 	lcall	__gptrget
   3081 FF                 1867 	mov	r7,a
                           1868 ;	genAssign
   3082 E5 10              1869 	mov	a,_bp
   3084 24 04              1870 	add	a,#0x04
   3086 F8                 1871 	mov	r0,a
   3087 A6 05              1872 	mov	@r0,ar5
   3089 08                 1873 	inc	r0
   308A A6 06              1874 	mov	@r0,ar6
   308C 08                 1875 	inc	r0
   308D A6 07              1876 	mov	@r0,ar7
                           1877 ;	../../FreeRTOS/Source/list.c:192: if( pxList->pxIndex == pxItemToRemove )
                           1878 ;	genPlus
   308F E5 10              1879 	mov	a,_bp
   3091 24 04              1880 	add	a,#0x04
   3093 F8                 1881 	mov	r0,a
   3094 E5 10              1882 	mov	a,_bp
   3096 24 0A              1883 	add	a,#0x0a
   3098 F9                 1884 	mov	r1,a
                           1885 ;     genPlusIncr
   3099 74 01              1886 	mov	a,#0x01
   309B 26                 1887 	add	a,@r0
   309C F7                 1888 	mov	@r1,a
                           1889 ;	Peephole 181	changed mov to clr
   309D E4                 1890 	clr	a
   309E 08                 1891 	inc	r0
   309F 36                 1892 	addc	a,@r0
   30A0 09                 1893 	inc	r1
   30A1 F7                 1894 	mov	@r1,a
   30A2 08                 1895 	inc	r0
   30A3 09                 1896 	inc	r1
   30A4 E6                 1897 	mov	a,@r0
   30A5 F7                 1898 	mov	@r1,a
                           1899 ;	genPointerGet
                           1900 ;	genGenPointerGet
   30A6 E5 10              1901 	mov	a,_bp
   30A8 24 0A              1902 	add	a,#0x0a
   30AA F8                 1903 	mov	r0,a
   30AB 86 82              1904 	mov	dpl,@r0
   30AD 08                 1905 	inc	r0
   30AE 86 83              1906 	mov	dph,@r0
   30B0 08                 1907 	inc	r0
   30B1 86 F0              1908 	mov	b,@r0
   30B3 12 E4 9F           1909 	lcall	__gptrget
   30B6 FD                 1910 	mov	r5,a
   30B7 A3                 1911 	inc	dptr
   30B8 12 E4 9F           1912 	lcall	__gptrget
   30BB FE                 1913 	mov	r6,a
   30BC A3                 1914 	inc	dptr
   30BD 12 E4 9F           1915 	lcall	__gptrget
   30C0 FF                 1916 	mov	r7,a
                           1917 ;	genCmpEq
   30C1 A8 10              1918 	mov	r0,_bp
   30C3 08                 1919 	inc	r0
                           1920 ;	gencjneshort
   30C4 E6                 1921 	mov	a,@r0
   30C5 B5 05 0C           1922 	cjne	a,ar5,00106$
   30C8 08                 1923 	inc	r0
   30C9 E6                 1924 	mov	a,@r0
   30CA B5 06 07           1925 	cjne	a,ar6,00106$
   30CD 08                 1926 	inc	r0
   30CE E6                 1927 	mov	a,@r0
   30CF B5 07 02           1928 	cjne	a,ar7,00106$
   30D2 80 02              1929 	sjmp	00107$
   30D4                    1930 00106$:
                           1931 ;	Peephole 112.b	changed ljmp to sjmp
   30D4 80 36              1932 	sjmp	00102$
   30D6                    1933 00107$:
                           1934 ;	../../FreeRTOS/Source/list.c:194: pxList->pxIndex = pxItemToRemove->pxPrevious;
                           1935 ;	genPointerGet
                           1936 ;	genGenPointerGet
   30D6 E5 10              1937 	mov	a,_bp
   30D8 24 07              1938 	add	a,#0x07
   30DA F8                 1939 	mov	r0,a
   30DB 86 82              1940 	mov	dpl,@r0
   30DD 08                 1941 	inc	r0
   30DE 86 83              1942 	mov	dph,@r0
   30E0 08                 1943 	inc	r0
   30E1 86 F0              1944 	mov	b,@r0
   30E3 12 E4 9F           1945 	lcall	__gptrget
   30E6 FD                 1946 	mov	r5,a
   30E7 A3                 1947 	inc	dptr
   30E8 12 E4 9F           1948 	lcall	__gptrget
   30EB FE                 1949 	mov	r6,a
   30EC A3                 1950 	inc	dptr
   30ED 12 E4 9F           1951 	lcall	__gptrget
   30F0 FF                 1952 	mov	r7,a
                           1953 ;	genPointerSet
                           1954 ;	genGenPointerSet
   30F1 E5 10              1955 	mov	a,_bp
   30F3 24 0A              1956 	add	a,#0x0a
   30F5 F8                 1957 	mov	r0,a
   30F6 86 82              1958 	mov	dpl,@r0
   30F8 08                 1959 	inc	r0
   30F9 86 83              1960 	mov	dph,@r0
   30FB 08                 1961 	inc	r0
   30FC 86 F0              1962 	mov	b,@r0
   30FE ED                 1963 	mov	a,r5
   30FF 12 DF B7           1964 	lcall	__gptrput
   3102 A3                 1965 	inc	dptr
   3103 EE                 1966 	mov	a,r6
   3104 12 DF B7           1967 	lcall	__gptrput
   3107 A3                 1968 	inc	dptr
   3108 EF                 1969 	mov	a,r7
   3109 12 DF B7           1970 	lcall	__gptrput
   310C                    1971 00102$:
                           1972 ;	../../FreeRTOS/Source/list.c:197: pxItemToRemove->pvContainer = NULL;
                           1973 ;	genPointerSet
                           1974 ;	genGenPointerSet
   310C 8A 82              1975 	mov	dpl,r2
   310E 8B 83              1976 	mov	dph,r3
   3110 8C F0              1977 	mov	b,r4
                           1978 ;	Peephole 181	changed mov to clr
   3112 E4                 1979 	clr	a
   3113 12 DF B7           1980 	lcall	__gptrput
   3116 A3                 1981 	inc	dptr
                           1982 ;	Peephole 181	changed mov to clr
   3117 E4                 1983 	clr	a
   3118 12 DF B7           1984 	lcall	__gptrput
   311B A3                 1985 	inc	dptr
                           1986 ;	Peephole 181	changed mov to clr
   311C E4                 1987 	clr	a
   311D 12 DF B7           1988 	lcall	__gptrput
                           1989 ;	../../FreeRTOS/Source/list.c:198: ( pxList->uxNumberOfItems )--;
                           1990 ;	genPointerGet
                           1991 ;	genGenPointerGet
   3120 E5 10              1992 	mov	a,_bp
   3122 24 04              1993 	add	a,#0x04
   3124 F8                 1994 	mov	r0,a
   3125 86 82              1995 	mov	dpl,@r0
   3127 08                 1996 	inc	r0
   3128 86 83              1997 	mov	dph,@r0
   312A 08                 1998 	inc	r0
   312B 86 F0              1999 	mov	b,@r0
   312D 12 E4 9F           2000 	lcall	__gptrget
   3130 FA                 2001 	mov	r2,a
                           2002 ;	genMinus
                           2003 ;	genMinusDec
   3131 1A                 2004 	dec	r2
                           2005 ;	genPointerSet
                           2006 ;	genGenPointerSet
   3132 E5 10              2007 	mov	a,_bp
   3134 24 04              2008 	add	a,#0x04
   3136 F8                 2009 	mov	r0,a
   3137 86 82              2010 	mov	dpl,@r0
   3139 08                 2011 	inc	r0
   313A 86 83              2012 	mov	dph,@r0
   313C 08                 2013 	inc	r0
   313D 86 F0              2014 	mov	b,@r0
   313F EA                 2015 	mov	a,r2
   3140 12 DF B7           2016 	lcall	__gptrput
                           2017 ;	Peephole 300	removed redundant label 00103$
   3143 85 10 81           2018 	mov	sp,_bp
   3146 D0 10              2019 	pop	_bp
   3148 22                 2020 	ret
                           2021 	.area CSEG    (CODE)
                           2022 	.area CONST   (CODE)
                           2023 	.area XINIT   (CODE)
