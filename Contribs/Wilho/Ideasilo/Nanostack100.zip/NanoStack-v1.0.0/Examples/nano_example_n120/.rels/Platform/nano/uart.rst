                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Nov 10 2006)
                              4 ; This file generated Fri Feb  1 13:33:37 2008
                              5 ;--------------------------------------------------------
                              6 	.module uart
                              7 	.optsdcc -mmcs51 --model-large
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _IRCON2_P2IF
                             13 	.globl _IRCON2_UTX0IF
                             14 	.globl _IRCON2_UTX1IF
                             15 	.globl _IRCON2_P1IF
                             16 	.globl _IRCON2_WDTIF
                             17 	.globl _CY
                             18 	.globl _AC
                             19 	.globl _F0
                             20 	.globl _RS1
                             21 	.globl _RS0
                             22 	.globl _OV
                             23 	.globl _F1
                             24 	.globl _P
                             25 	.globl _IRCON_DMAIF
                             26 	.globl _IRCON_T1IF
                             27 	.globl _IRCON_T2IF
                             28 	.globl _IRCON_T3IF
                             29 	.globl _IRCON_T4IF
                             30 	.globl _IRCON_P0IF
                             31 	.globl _IRCON_STIF
                             32 	.globl _IEN1_DMAIE
                             33 	.globl _IEN1_T1IE
                             34 	.globl _IEN1_T2IE
                             35 	.globl _IEN1_T3IE
                             36 	.globl _IEN1_T4IE
                             37 	.globl _IEN1_P0IE
                             38 	.globl _IEN0_RFERRIE
                             39 	.globl _IEN0_ADCIE
                             40 	.globl _IEN0_URX0IE
                             41 	.globl _IEN0_URX1IE
                             42 	.globl _IEN0_ENCIE
                             43 	.globl _IEN0_STIE
                             44 	.globl _IEN0_EA
                             45 	.globl _EA
                             46 	.globl _P2_4
                             47 	.globl _P2_3
                             48 	.globl _P2_2
                             49 	.globl _P2_1
                             50 	.globl _P2_0
                             51 	.globl _S0CON_ENCIF_0
                             52 	.globl _S0CON_ENCIF_1
                             53 	.globl _P1_7
                             54 	.globl _P1_6
                             55 	.globl _P1_5
                             56 	.globl _P1_4
                             57 	.globl _P1_3
                             58 	.globl _P1_2
                             59 	.globl _P1_1
                             60 	.globl _P1_0
                             61 	.globl _TCON_IT0
                             62 	.globl _TCON_RFERRIF
                             63 	.globl _TCON_IT1
                             64 	.globl _TCON_URX0IF
                             65 	.globl _TCON_ADCIF
                             66 	.globl _TCON_URX1IF
                             67 	.globl _P0_0
                             68 	.globl _P0_1
                             69 	.globl _P0_2
                             70 	.globl _P0_3
                             71 	.globl _P0_4
                             72 	.globl _P0_5
                             73 	.globl _P0_6
                             74 	.globl _P0_7
                             75 	.globl _P2DIR
                             76 	.globl _P1DIR
                             77 	.globl _P0DIR
                             78 	.globl _U1GCR
                             79 	.globl _U1UCR
                             80 	.globl _U1BAUD
                             81 	.globl _U1BUF
                             82 	.globl _U1CSR
                             83 	.globl _P2INP
                             84 	.globl _P1INP
                             85 	.globl _P2SEL
                             86 	.globl _P1SEL
                             87 	.globl _P0SEL
                             88 	.globl _ADCCFG
                             89 	.globl _PERCFG
                             90 	.globl _B
                             91 	.globl _T4CC1
                             92 	.globl _T4CCTL1
                             93 	.globl _T4CC0
                             94 	.globl _T4CCTL0
                             95 	.globl _T4CTL
                             96 	.globl _T4CNT
                             97 	.globl _RFIF
                             98 	.globl _IRCON2
                             99 	.globl _T1CCTL2
                            100 	.globl _T1CCTL1
                            101 	.globl _T1CCTL0
                            102 	.globl _T1CTL
                            103 	.globl _T1CNTH
                            104 	.globl _T1CNTL
                            105 	.globl _RFST
                            106 	.globl _ACC
                            107 	.globl _T1CC2H
                            108 	.globl _T1CC2L
                            109 	.globl _T1CC1H
                            110 	.globl _T1CC1L
                            111 	.globl _T1CC0H
                            112 	.globl _T1CC0L
                            113 	.globl _RFD
                            114 	.globl _TIMIF
                            115 	.globl _DMAREQ
                            116 	.globl _DMAARM
                            117 	.globl _DMA0CFGH
                            118 	.globl _DMA0CFGL
                            119 	.globl _DMA1CFGH
                            120 	.globl _DMA1CFGL
                            121 	.globl _DMAIRQ
                            122 	.globl _PSW
                            123 	.globl _T3CC1
                            124 	.globl _T3CCTL1
                            125 	.globl _T3CC0
                            126 	.globl _T3CCTL0
                            127 	.globl _T3CTL
                            128 	.globl _T3CNT
                            129 	.globl _WDCTL
                            130 	.globl _T2CON
                            131 	.globl _MEMCTR
                            132 	.globl _CLKCON
                            133 	.globl _U0GCR
                            134 	.globl _U0UCR
                            135 	.globl _T2CNF
                            136 	.globl _U0BAUD
                            137 	.globl _U0BUF
                            138 	.globl _IRCON
                            139 	.globl _SLEEP
                            140 	.globl _RNDH
                            141 	.globl _RNDL
                            142 	.globl _ADCH
                            143 	.globl _ADCL
                            144 	.globl _IP1
                            145 	.globl _IEN1
                            146 	.globl _RCCTL
                            147 	.globl _ADCCON3
                            148 	.globl _ADCCON2
                            149 	.globl _ADCCON1
                            150 	.globl _ENCCS
                            151 	.globl _ENCDO
                            152 	.globl _ENCDI
                            153 	.globl _FWDATA
                            154 	.globl _FCTL
                            155 	.globl _FADDRH
                            156 	.globl _FADDRL
                            157 	.globl _FWT
                            158 	.globl _IP0
                            159 	.globl _IEN0
                            160 	.globl _IE
                            161 	.globl _T2THD
                            162 	.globl _T2TLD
                            163 	.globl _T2CAPHPH
                            164 	.globl _T2CAPLPL
                            165 	.globl _T2OF2
                            166 	.globl _T2OF1
                            167 	.globl _T2OF0
                            168 	.globl _P2
                            169 	.globl _T2PEROF2
                            170 	.globl _T2PEROF1
                            171 	.globl _T2PEROF0
                            172 	.globl _S1CON
                            173 	.globl _IEN2
                            174 	.globl _HSRC
                            175 	.globl _S0CON
                            176 	.globl _ST2
                            177 	.globl _ST1
                            178 	.globl _ST0
                            179 	.globl _T2CMP
                            180 	.globl __XPAGE
                            181 	.globl _DPS
                            182 	.globl _RFIM
                            183 	.globl _P1
                            184 	.globl _P0INP
                            185 	.globl _P1IEN
                            186 	.globl _PICTL
                            187 	.globl _P2IFG
                            188 	.globl _P1IFG
                            189 	.globl _P0IFG
                            190 	.globl _TCON
                            191 	.globl _PCON
                            192 	.globl _U0CSR
                            193 	.globl _DPH1
                            194 	.globl _DPL1
                            195 	.globl _DPH0
                            196 	.globl _DPL0
                            197 	.globl _SP
                            198 	.globl _P0
                            199 	.globl _uart1_tx_wr
                            200 	.globl _uart1_tx_rd
                            201 	.globl _uart1_rx
                            202 	.globl _uart1_txempty
                            203 	.globl _uart1_tx_buffer
                            204 	.globl _RFD_SHADOW
                            205 	.globl _RFSTATUS
                            206 	.globl _CHIPID
                            207 	.globl _CHVER
                            208 	.globl _FSMTC1
                            209 	.globl _RXFIFOCNT
                            210 	.globl _IOCFG3
                            211 	.globl _IOCFG2
                            212 	.globl _IOCFG1
                            213 	.globl _IOCFG0
                            214 	.globl _SHORTADDRL
                            215 	.globl _SHORTADDRH
                            216 	.globl _PANIDL
                            217 	.globl _PANIDH
                            218 	.globl _IEEE_ADDR7
                            219 	.globl _IEEE_ADDR6
                            220 	.globl _IEEE_ADDR5
                            221 	.globl _IEEE_ADDR4
                            222 	.globl _IEEE_ADDR3
                            223 	.globl _IEEE_ADDR2
                            224 	.globl _IEEE_ADDR1
                            225 	.globl _IEEE_ADDR0
                            226 	.globl _DACTSTL
                            227 	.globl _DACTSTH
                            228 	.globl _ADCTSTL
                            229 	.globl _ADCTSTH
                            230 	.globl _FSMSTATE
                            231 	.globl _AGCCTRLL
                            232 	.globl _AGCCTRLH
                            233 	.globl _MANORL
                            234 	.globl _MANORH
                            235 	.globl _MANANDL
                            236 	.globl _MANANDH
                            237 	.globl _FSMTCL
                            238 	.globl _FSMTCH
                            239 	.globl _RFPWR
                            240 	.globl _CSPT
                            241 	.globl _CSPCTRL
                            242 	.globl _CSPZ
                            243 	.globl _CSPY
                            244 	.globl _CSPX
                            245 	.globl _FSCTRLL
                            246 	.globl _FSCTRLH
                            247 	.globl _RXCTRL1L
                            248 	.globl _RXCTRL1H
                            249 	.globl _RXCTRL0L
                            250 	.globl _RXCTRL0H
                            251 	.globl _TXCTRLL
                            252 	.globl _TXCTRLH
                            253 	.globl _SYNCWORDL
                            254 	.globl _SYNCWORDH
                            255 	.globl _RSSIL
                            256 	.globl _RSSIH
                            257 	.globl _MDMCTRL1L
                            258 	.globl _MDMCTRL1H
                            259 	.globl _MDMCTRL0L
                            260 	.globl _MDMCTRL0H
                            261 	.globl _uart1_init
                            262 	.globl _uart1_get_blocking
                            263 	.globl _uart1_get
                            264 	.globl _uart1_put
                            265 	.globl _uart1_rxISR
                            266 	.globl _uart1_txISR
                            267 ;--------------------------------------------------------
                            268 ; special function registers
                            269 ;--------------------------------------------------------
                            270 	.area RSEG    (DATA)
                    0080    271 _P0	=	0x0080
                    0081    272 _SP	=	0x0081
                    0082    273 _DPL0	=	0x0082
                    0083    274 _DPH0	=	0x0083
                    0084    275 _DPL1	=	0x0084
                    0085    276 _DPH1	=	0x0085
                    0086    277 _U0CSR	=	0x0086
                    0087    278 _PCON	=	0x0087
                    0088    279 _TCON	=	0x0088
                    0089    280 _P0IFG	=	0x0089
                    008A    281 _P1IFG	=	0x008a
                    008B    282 _P2IFG	=	0x008b
                    008C    283 _PICTL	=	0x008c
                    008D    284 _P1IEN	=	0x008d
                    008F    285 _P0INP	=	0x008f
                    0090    286 _P1	=	0x0090
                    0091    287 _RFIM	=	0x0091
                    0092    288 _DPS	=	0x0092
                    0093    289 __XPAGE	=	0x0093
                    0094    290 _T2CMP	=	0x0094
                    0095    291 _ST0	=	0x0095
                    0096    292 _ST1	=	0x0096
                    0097    293 _ST2	=	0x0097
                    0098    294 _S0CON	=	0x0098
                    0099    295 _HSRC	=	0x0099
                    009A    296 _IEN2	=	0x009a
                    009B    297 _S1CON	=	0x009b
                    009C    298 _T2PEROF0	=	0x009c
                    009D    299 _T2PEROF1	=	0x009d
                    009E    300 _T2PEROF2	=	0x009e
                    00A0    301 _P2	=	0x00a0
                    00A1    302 _T2OF0	=	0x00a1
                    00A2    303 _T2OF1	=	0x00a2
                    00A3    304 _T2OF2	=	0x00a3
                    00A4    305 _T2CAPLPL	=	0x00a4
                    00A5    306 _T2CAPHPH	=	0x00a5
                    00A6    307 _T2TLD	=	0x00a6
                    00A7    308 _T2THD	=	0x00a7
                    00A8    309 _IE	=	0x00a8
                    00A8    310 _IEN0	=	0x00a8
                    00A9    311 _IP0	=	0x00a9
                    00AB    312 _FWT	=	0x00ab
                    00AC    313 _FADDRL	=	0x00ac
                    00AD    314 _FADDRH	=	0x00ad
                    00AE    315 _FCTL	=	0x00ae
                    00AF    316 _FWDATA	=	0x00af
                    00B1    317 _ENCDI	=	0x00b1
                    00B2    318 _ENCDO	=	0x00b2
                    00B3    319 _ENCCS	=	0x00b3
                    00B4    320 _ADCCON1	=	0x00b4
                    00B5    321 _ADCCON2	=	0x00b5
                    00B6    322 _ADCCON3	=	0x00b6
                    00B7    323 _RCCTL	=	0x00b7
                    00B8    324 _IEN1	=	0x00b8
                    00B9    325 _IP1	=	0x00b9
                    00BA    326 _ADCL	=	0x00ba
                    00BB    327 _ADCH	=	0x00bb
                    00BC    328 _RNDL	=	0x00bc
                    00BD    329 _RNDH	=	0x00bd
                    00BE    330 _SLEEP	=	0x00be
                    00C0    331 _IRCON	=	0x00c0
                    00C1    332 _U0BUF	=	0x00c1
                    00C2    333 _U0BAUD	=	0x00c2
                    00C3    334 _T2CNF	=	0x00c3
                    00C4    335 _U0UCR	=	0x00c4
                    00C5    336 _U0GCR	=	0x00c5
                    00C6    337 _CLKCON	=	0x00c6
                    00C7    338 _MEMCTR	=	0x00c7
                    00C8    339 _T2CON	=	0x00c8
                    00C9    340 _WDCTL	=	0x00c9
                    00CA    341 _T3CNT	=	0x00ca
                    00CB    342 _T3CTL	=	0x00cb
                    00CC    343 _T3CCTL0	=	0x00cc
                    00CD    344 _T3CC0	=	0x00cd
                    00CE    345 _T3CCTL1	=	0x00ce
                    00CF    346 _T3CC1	=	0x00cf
                    00D0    347 _PSW	=	0x00d0
                    00D1    348 _DMAIRQ	=	0x00d1
                    00D2    349 _DMA1CFGL	=	0x00d2
                    00D3    350 _DMA1CFGH	=	0x00d3
                    00D4    351 _DMA0CFGL	=	0x00d4
                    00D5    352 _DMA0CFGH	=	0x00d5
                    00D6    353 _DMAARM	=	0x00d6
                    00D7    354 _DMAREQ	=	0x00d7
                    00D8    355 _TIMIF	=	0x00d8
                    00D9    356 _RFD	=	0x00d9
                    00DA    357 _T1CC0L	=	0x00da
                    00DB    358 _T1CC0H	=	0x00db
                    00DC    359 _T1CC1L	=	0x00dc
                    00DD    360 _T1CC1H	=	0x00dd
                    00DE    361 _T1CC2L	=	0x00de
                    00DF    362 _T1CC2H	=	0x00df
                    00E0    363 _ACC	=	0x00e0
                    00E1    364 _RFST	=	0x00e1
                    00E2    365 _T1CNTL	=	0x00e2
                    00E3    366 _T1CNTH	=	0x00e3
                    00E4    367 _T1CTL	=	0x00e4
                    00E5    368 _T1CCTL0	=	0x00e5
                    00E6    369 _T1CCTL1	=	0x00e6
                    00E7    370 _T1CCTL2	=	0x00e7
                    00E8    371 _IRCON2	=	0x00e8
                    00E9    372 _RFIF	=	0x00e9
                    00EA    373 _T4CNT	=	0x00ea
                    00EB    374 _T4CTL	=	0x00eb
                    00EC    375 _T4CCTL0	=	0x00ec
                    00ED    376 _T4CC0	=	0x00ed
                    00EE    377 _T4CCTL1	=	0x00ee
                    00EF    378 _T4CC1	=	0x00ef
                    00F0    379 _B	=	0x00f0
                    00F1    380 _PERCFG	=	0x00f1
                    00F2    381 _ADCCFG	=	0x00f2
                    00F3    382 _P0SEL	=	0x00f3
                    00F4    383 _P1SEL	=	0x00f4
                    00F5    384 _P2SEL	=	0x00f5
                    00F6    385 _P1INP	=	0x00f6
                    00F7    386 _P2INP	=	0x00f7
                    00F8    387 _U1CSR	=	0x00f8
                    00F9    388 _U1BUF	=	0x00f9
                    00FA    389 _U1BAUD	=	0x00fa
                    00FB    390 _U1UCR	=	0x00fb
                    00FC    391 _U1GCR	=	0x00fc
                    00FD    392 _P0DIR	=	0x00fd
                    00FE    393 _P1DIR	=	0x00fe
                    00FF    394 _P2DIR	=	0x00ff
                            395 ;--------------------------------------------------------
                            396 ; special function bits
                            397 ;--------------------------------------------------------
                            398 	.area RSEG    (DATA)
                    0087    399 _P0_7	=	0x0087
                    0086    400 _P0_6	=	0x0086
                    0085    401 _P0_5	=	0x0085
                    0084    402 _P0_4	=	0x0084
                    0083    403 _P0_3	=	0x0083
                    0082    404 _P0_2	=	0x0082
                    0081    405 _P0_1	=	0x0081
                    0080    406 _P0_0	=	0x0080
                    008F    407 _TCON_URX1IF	=	0x008f
                    008D    408 _TCON_ADCIF	=	0x008d
                    008B    409 _TCON_URX0IF	=	0x008b
                    008A    410 _TCON_IT1	=	0x008a
                    0089    411 _TCON_RFERRIF	=	0x0089
                    0088    412 _TCON_IT0	=	0x0088
                    0090    413 _P1_0	=	0x0090
                    0091    414 _P1_1	=	0x0091
                    0092    415 _P1_2	=	0x0092
                    0093    416 _P1_3	=	0x0093
                    0094    417 _P1_4	=	0x0094
                    0095    418 _P1_5	=	0x0095
                    0096    419 _P1_6	=	0x0096
                    0097    420 _P1_7	=	0x0097
                    0099    421 _S0CON_ENCIF_1	=	0x0099
                    0098    422 _S0CON_ENCIF_0	=	0x0098
                    00A0    423 _P2_0	=	0x00a0
                    00A1    424 _P2_1	=	0x00a1
                    00A2    425 _P2_2	=	0x00a2
                    00A3    426 _P2_3	=	0x00a3
                    00A4    427 _P2_4	=	0x00a4
                    00AF    428 _EA	=	0x00af
                    00AF    429 _IEN0_EA	=	0x00af
                    00AD    430 _IEN0_STIE	=	0x00ad
                    00AC    431 _IEN0_ENCIE	=	0x00ac
                    00AB    432 _IEN0_URX1IE	=	0x00ab
                    00AA    433 _IEN0_URX0IE	=	0x00aa
                    00A9    434 _IEN0_ADCIE	=	0x00a9
                    00A8    435 _IEN0_RFERRIE	=	0x00a8
                    00BD    436 _IEN1_P0IE	=	0x00bd
                    00BC    437 _IEN1_T4IE	=	0x00bc
                    00BB    438 _IEN1_T3IE	=	0x00bb
                    00BA    439 _IEN1_T2IE	=	0x00ba
                    00B9    440 _IEN1_T1IE	=	0x00b9
                    00B8    441 _IEN1_DMAIE	=	0x00b8
                    00C7    442 _IRCON_STIF	=	0x00c7
                    00C5    443 _IRCON_P0IF	=	0x00c5
                    00C4    444 _IRCON_T4IF	=	0x00c4
                    00C3    445 _IRCON_T3IF	=	0x00c3
                    00C2    446 _IRCON_T2IF	=	0x00c2
                    00C1    447 _IRCON_T1IF	=	0x00c1
                    00C0    448 _IRCON_DMAIF	=	0x00c0
                    00D0    449 _P	=	0x00d0
                    00D1    450 _F1	=	0x00d1
                    00D2    451 _OV	=	0x00d2
                    00D3    452 _RS0	=	0x00d3
                    00D4    453 _RS1	=	0x00d4
                    00D5    454 _F0	=	0x00d5
                    00D6    455 _AC	=	0x00d6
                    00D7    456 _CY	=	0x00d7
                    00EC    457 _IRCON2_WDTIF	=	0x00ec
                    00EB    458 _IRCON2_P1IF	=	0x00eb
                    00EA    459 _IRCON2_UTX1IF	=	0x00ea
                    00E9    460 _IRCON2_UTX0IF	=	0x00e9
                    00E8    461 _IRCON2_P2IF	=	0x00e8
                            462 ;--------------------------------------------------------
                            463 ; overlayable register banks
                            464 ;--------------------------------------------------------
                            465 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     466 	.ds 8
                            467 ;--------------------------------------------------------
                            468 ; overlayable bit register bank
                            469 ;--------------------------------------------------------
                            470 	.area BIT_BANK	(REL,OVR,DATA)
   0020                     471 bits:
   0020                     472 	.ds 1
                    8000    473 	b0 = bits[0]
                    8100    474 	b1 = bits[1]
                    8200    475 	b2 = bits[2]
                    8300    476 	b3 = bits[3]
                    8400    477 	b4 = bits[4]
                    8500    478 	b5 = bits[5]
                    8600    479 	b6 = bits[6]
                    8700    480 	b7 = bits[7]
                            481 ;--------------------------------------------------------
                            482 ; internal ram data
                            483 ;--------------------------------------------------------
                            484 	.area DSEG    (DATA)
                            485 ;--------------------------------------------------------
                            486 ; overlayable items in internal ram 
                            487 ;--------------------------------------------------------
                            488 	.area OSEG    (OVR,DATA)
                            489 ;--------------------------------------------------------
                            490 ; indirectly addressable internal ram data
                            491 ;--------------------------------------------------------
                            492 	.area ISEG    (DATA)
                            493 ;--------------------------------------------------------
                            494 ; bit data
                            495 ;--------------------------------------------------------
                            496 	.area BSEG    (BIT)
                            497 ;--------------------------------------------------------
                            498 ; paged external ram data
                            499 ;--------------------------------------------------------
                            500 	.area PSEG    (PAG,XDATA)
                            501 ;--------------------------------------------------------
                            502 ; external ram data
                            503 ;--------------------------------------------------------
                            504 	.area XSEG    (XDATA)
                    DF02    505 _MDMCTRL0H	=	0xdf02
                    DF03    506 _MDMCTRL0L	=	0xdf03
                    DF04    507 _MDMCTRL1H	=	0xdf04
                    DF05    508 _MDMCTRL1L	=	0xdf05
                    DF06    509 _RSSIH	=	0xdf06
                    DF07    510 _RSSIL	=	0xdf07
                    DF08    511 _SYNCWORDH	=	0xdf08
                    DF09    512 _SYNCWORDL	=	0xdf09
                    DF0A    513 _TXCTRLH	=	0xdf0a
                    DF0B    514 _TXCTRLL	=	0xdf0b
                    DF0C    515 _RXCTRL0H	=	0xdf0c
                    DF0D    516 _RXCTRL0L	=	0xdf0d
                    DF0E    517 _RXCTRL1H	=	0xdf0e
                    DF0F    518 _RXCTRL1L	=	0xdf0f
                    DF10    519 _FSCTRLH	=	0xdf10
                    DF11    520 _FSCTRLL	=	0xdf11
                    DF12    521 _CSPX	=	0xdf12
                    DF13    522 _CSPY	=	0xdf13
                    DF14    523 _CSPZ	=	0xdf14
                    DF15    524 _CSPCTRL	=	0xdf15
                    DF16    525 _CSPT	=	0xdf16
                    DF17    526 _RFPWR	=	0xdf17
                    DF20    527 _FSMTCH	=	0xdf20
                    DF21    528 _FSMTCL	=	0xdf21
                    DF22    529 _MANANDH	=	0xdf22
                    DF23    530 _MANANDL	=	0xdf23
                    DF24    531 _MANORH	=	0xdf24
                    DF25    532 _MANORL	=	0xdf25
                    DF26    533 _AGCCTRLH	=	0xdf26
                    DF27    534 _AGCCTRLL	=	0xdf27
                    DF39    535 _FSMSTATE	=	0xdf39
                    DF3A    536 _ADCTSTH	=	0xdf3a
                    DF3B    537 _ADCTSTL	=	0xdf3b
                    DF3C    538 _DACTSTH	=	0xdf3c
                    DF3D    539 _DACTSTL	=	0xdf3d
                    DF43    540 _IEEE_ADDR0	=	0xdf43
                    DF44    541 _IEEE_ADDR1	=	0xdf44
                    DF45    542 _IEEE_ADDR2	=	0xdf45
                    DF46    543 _IEEE_ADDR3	=	0xdf46
                    DF47    544 _IEEE_ADDR4	=	0xdf47
                    DF48    545 _IEEE_ADDR5	=	0xdf48
                    DF49    546 _IEEE_ADDR6	=	0xdf49
                    DF4A    547 _IEEE_ADDR7	=	0xdf4a
                    DF4B    548 _PANIDH	=	0xdf4b
                    DF4C    549 _PANIDL	=	0xdf4c
                    DF4D    550 _SHORTADDRH	=	0xdf4d
                    DF4E    551 _SHORTADDRL	=	0xdf4e
                    DF4F    552 _IOCFG0	=	0xdf4f
                    DF50    553 _IOCFG1	=	0xdf50
                    DF51    554 _IOCFG2	=	0xdf51
                    DF52    555 _IOCFG3	=	0xdf52
                    DF53    556 _RXFIFOCNT	=	0xdf53
                    DF54    557 _FSMTC1	=	0xdf54
                    DF60    558 _CHVER	=	0xdf60
                    DF61    559 _CHIPID	=	0xdf61
                    DF62    560 _RFSTATUS	=	0xdf62
                    DFD9    561 _RFD_SHADOW	=	0xdfd9
   EE5D                     562 _uart1_tx_buffer::
   EE5D                     563 	.ds 128
                            564 ;--------------------------------------------------------
                            565 ; external initialized ram data
                            566 ;--------------------------------------------------------
                            567 	.area XISEG   (XDATA)
   F09F                     568 _uart1_txempty::
   F09F                     569 	.ds 1
   F0A0                     570 _uart1_rx::
   F0A0                     571 	.ds 3
   F0A3                     572 _uart1_tx_rd::
   F0A3                     573 	.ds 1
   F0A4                     574 _uart1_tx_wr::
   F0A4                     575 	.ds 1
                            576 	.area HOME    (CODE)
                            577 	.area GSINIT0 (CODE)
                            578 	.area GSINIT1 (CODE)
                            579 	.area GSINIT2 (CODE)
                            580 	.area GSINIT3 (CODE)
                            581 	.area GSINIT4 (CODE)
                            582 	.area GSINIT5 (CODE)
                            583 	.area GSINIT  (CODE)
                            584 	.area GSFINAL (CODE)
                            585 	.area CSEG    (CODE)
                            586 ;--------------------------------------------------------
                            587 ; global & static initialisations
                            588 ;--------------------------------------------------------
                            589 	.area HOME    (CODE)
                            590 	.area GSINIT  (CODE)
                            591 	.area GSFINAL (CODE)
                            592 	.area GSINIT  (CODE)
                            593 ;--------------------------------------------------------
                            594 ; Home
                            595 ;--------------------------------------------------------
                            596 	.area HOME    (CODE)
                            597 	.area CSEG    (CODE)
                            598 ;--------------------------------------------------------
                            599 ; code
                            600 ;--------------------------------------------------------
                            601 	.area CSEG    (CODE)
                            602 ;------------------------------------------------------------
                            603 ;Allocation info for local variables in function 'uart1_init'
                            604 ;------------------------------------------------------------
                            605 ;speed                     Allocated to registers r2 r3 r4 r5 
                            606 ;------------------------------------------------------------
                            607 ;	../../Platform/nano/uart.c:296: void uart1_init(uint32_t speed)
                            608 ;	-----------------------------------------
                            609 ;	 function uart1_init
                            610 ;	-----------------------------------------
   3D75                     611 _uart1_init:
                    0002    612 	ar2 = 0x02
                    0003    613 	ar3 = 0x03
                    0004    614 	ar4 = 0x04
                    0005    615 	ar5 = 0x05
                    0006    616 	ar6 = 0x06
                    0007    617 	ar7 = 0x07
                    0000    618 	ar0 = 0x00
                    0001    619 	ar1 = 0x01
                            620 ;     genReceive
   3D75 AA 82               621 	mov	r2,dpl
   3D77 AB 83               622 	mov	r3,dph
   3D79 AC F0               623 	mov	r4,b
   3D7B FD                  624 	mov	r5,a
                            625 ;	../../Platform/nano/uart.c:298: if (speed != 115200) return;
                            626 ;	genCmpEq
                            627 ;	gencjneshort
                            628 ;	Peephole 112.b	changed ljmp to sjmp
                            629 ;	genRet
                            630 ;	Peephole 112.b	changed ljmp to sjmp
                            631 ;	Peephole 194	optimized misc jump sequence
   3D7C BA 00 62            632 	cjne	r2,#0x00,00105$
   3D7F BB C2 5F            633 	cjne	r3,#0xC2,00105$
   3D82 BC 01 5C            634 	cjne	r4,#0x01,00105$
   3D85 BD 00 59            635 	cjne	r5,#0x00,00105$
                            636 ;	Peephole 200.b	removed redundant sjmp
                            637 ;	Peephole 300	removed redundant label 00109$
                            638 ;	Peephole 300	removed redundant label 00102$
                            639 ;	../../Platform/nano/uart.c:299: if (uart1_rx == 0)
                            640 ;	genAssign
   3D88 90 F0 A0            641 	mov	dptr,#_uart1_rx
   3D8B E0                  642 	movx	a,@dptr
   3D8C FA                  643 	mov	r2,a
   3D8D A3                  644 	inc	dptr
   3D8E E0                  645 	movx	a,@dptr
   3D8F FB                  646 	mov	r3,a
   3D90 A3                  647 	inc	dptr
   3D91 E0                  648 	movx	a,@dptr
   3D92 FC                  649 	mov	r4,a
                            650 ;	genIfx
   3D93 EA                  651 	mov	a,r2
   3D94 4B                  652 	orl	a,r3
   3D95 4C                  653 	orl	a,r4
                            654 ;	genIfxJump
                            655 ;	Peephole 108.b	removed ljmp by inverse jump logic
   3D96 70 26               656 	jnz	00104$
                            657 ;	Peephole 300	removed redundant label 00110$
                            658 ;	../../Platform/nano/uart.c:301: uart1_rx = xQueueCreate(UART1_RX_LEN, ( unsigned portBASE_TYPE ) sizeof( signed portCHAR ) );
                            659 ;	genIpush
   3D98 74 01               660 	mov	a,#0x01
   3D9A C0 E0               661 	push	acc
                            662 ;	genCall
   3D9C 75 82 04            663 	mov	dpl,#0x04
   3D9F 12 1B 2D            664 	lcall	_xQueueCreate
   3DA2 AA 82               665 	mov	r2,dpl
   3DA4 AB 83               666 	mov	r3,dph
   3DA6 AC F0               667 	mov	r4,b
   3DA8 15 81               668 	dec	sp
                            669 ;	genAssign
   3DAA 90 F0 A0            670 	mov	dptr,#_uart1_rx
   3DAD EA                  671 	mov	a,r2
   3DAE F0                  672 	movx	@dptr,a
   3DAF A3                  673 	inc	dptr
   3DB0 EB                  674 	mov	a,r3
   3DB1 F0                  675 	movx	@dptr,a
   3DB2 A3                  676 	inc	dptr
   3DB3 EC                  677 	mov	a,r4
   3DB4 F0                  678 	movx	@dptr,a
                            679 ;	../../Platform/nano/uart.c:305: uart1_tx_rd = 0;
                            680 ;	genAssign
   3DB5 90 F0 A3            681 	mov	dptr,#_uart1_tx_rd
                            682 ;	Peephole 181	changed mov to clr
                            683 ;	../../Platform/nano/uart.c:306: uart1_tx_wr = 0;
                            684 ;	genAssign
                            685 ;	Peephole 181	changed mov to clr
                            686 ;	Peephole 219.a	removed redundant clear
   3DB8 E4                  687 	clr	a
   3DB9 F0                  688 	movx	@dptr,a
   3DBA 90 F0 A4            689 	mov	dptr,#_uart1_tx_wr
   3DBD F0                  690 	movx	@dptr,a
   3DBE                     691 00104$:
                            692 ;	../../Platform/nano/uart.c:310: PERCFG |= U1CFG;	/*alternative port 2 = P1.7-4*/
                            693 ;	genOr
   3DBE 43 F1 02            694 	orl	_PERCFG,#0x02
                            695 ;	../../Platform/nano/uart.c:311: P1SEL |= 0xC0;		/*peripheral select for TX and RX*/
                            696 ;	genOr
   3DC1 43 F4 C0            697 	orl	_P1SEL,#0xC0
                            698 ;	../../Platform/nano/uart.c:312: P1DIR |= 0x20;		/*RTS out*/
                            699 ;	genOr
   3DC4 43 FE 20            700 	orl	_P1DIR,#0x20
                            701 ;	../../Platform/nano/uart.c:313: P1 |= 0x20;		/*RTS up*/	
                            702 ;	genOr
   3DC7 43 90 20            703 	orl	_P1,#0x20
                            704 ;	../../Platform/nano/uart.c:314: U1BAUD=216;		/*115200*/
                            705 ;	genAssign
   3DCA 75 FA D8            706 	mov	_U1BAUD,#0xD8
                            707 ;	../../Platform/nano/uart.c:316: U1GCR = /*U_ORDER |*/ 11; /*LSB first and 115200*/
                            708 ;	genAssign
   3DCD 75 FC 0B            709 	mov	_U1GCR,#0x0B
                            710 ;	../../Platform/nano/uart.c:317: U1UCR = 0x02;	/*defaults: 8N1, no flow control, high stop bit*/
                            711 ;	genAssign
   3DD0 75 FB 02            712 	mov	_U1UCR,#0x02
                            713 ;	../../Platform/nano/uart.c:318: U1CSR = U_MODE | U_RE |U_TXB; /*UART mode, receiver enable, TX done*/
                            714 ;	genAssign
   3DD3 75 F8 C2            715 	mov	_U1CSR,#0xC2
                            716 ;	../../Platform/nano/uart.c:320: IEN0_URX1IE = 1;
                            717 ;	genAssign
   3DD6 D2 AB               718 	setb	_IEN0_URX1IE
                            719 ;	../../Platform/nano/uart.c:321: IEN2 |= UTX1IE;
                            720 ;	genOr
   3DD8 43 9A 08            721 	orl	_IEN2,#0x08
                            722 ;	../../Platform/nano/uart.c:323: uart1_txempty = pdTRUE;
                            723 ;	genAssign
   3DDB 90 F0 9F            724 	mov	dptr,#_uart1_txempty
   3DDE 74 01               725 	mov	a,#0x01
   3DE0 F0                  726 	movx	@dptr,a
   3DE1                     727 00105$:
   3DE1 22                  728 	ret
                            729 ;------------------------------------------------------------
                            730 ;Allocation info for local variables in function 'uart1_get_blocking'
                            731 ;------------------------------------------------------------
                            732 ;time                      Allocated to stack - offset 1
                            733 ;byte                      Allocated to stack - offset 3
                            734 ;------------------------------------------------------------
                            735 ;	../../Platform/nano/uart.c:326: int16_t uart1_get_blocking(portTickType time)
                            736 ;	-----------------------------------------
                            737 ;	 function uart1_get_blocking
                            738 ;	-----------------------------------------
   3DE2                     739 _uart1_get_blocking:
   3DE2 C0 10               740 	push	_bp
   3DE4 85 81 10            741 	mov	_bp,sp
                            742 ;     genReceive
   3DE7 C0 82               743 	push	dpl
   3DE9 C0 83               744 	push	dph
   3DEB 05 81               745 	inc	sp
                            746 ;	../../Platform/nano/uart.c:330: if ( xQueueReceive(uart1_rx, &byte, time ) == pdTRUE)
                            747 ;	genAddrOf
   3DED E5 10               748 	mov	a,_bp
   3DEF 24 03               749 	add	a,#0x03
   3DF1 FC                  750 	mov	r4,a
                            751 ;	genCast
   3DF2 7D 00               752 	mov	r5,#0x00
   3DF4 7E 40               753 	mov	r6,#0x40
                            754 ;	genAssign
   3DF6 90 F0 A0            755 	mov	dptr,#_uart1_rx
   3DF9 E0                  756 	movx	a,@dptr
   3DFA FF                  757 	mov	r7,a
   3DFB A3                  758 	inc	dptr
   3DFC E0                  759 	movx	a,@dptr
   3DFD FA                  760 	mov	r2,a
   3DFE A3                  761 	inc	dptr
   3DFF E0                  762 	movx	a,@dptr
   3E00 FB                  763 	mov	r3,a
                            764 ;	genIpush
   3E01 A8 10               765 	mov	r0,_bp
   3E03 08                  766 	inc	r0
   3E04 E6                  767 	mov	a,@r0
   3E05 C0 E0               768 	push	acc
   3E07 08                  769 	inc	r0
   3E08 E6                  770 	mov	a,@r0
   3E09 C0 E0               771 	push	acc
                            772 ;	genIpush
   3E0B C0 04               773 	push	ar4
   3E0D C0 05               774 	push	ar5
   3E0F C0 06               775 	push	ar6
                            776 ;	genCall
   3E11 8F 82               777 	mov	dpl,r7
   3E13 8A 83               778 	mov	dph,r2
   3E15 8B F0               779 	mov	b,r3
   3E17 12 23 5A            780 	lcall	_xQueueReceive
   3E1A AA 82               781 	mov	r2,dpl
   3E1C E5 81               782 	mov	a,sp
   3E1E 24 FB               783 	add	a,#0xfb
   3E20 F5 81               784 	mov	sp,a
                            785 ;	genCmpEq
                            786 ;	gencjneshort
                            787 ;	Peephole 112.b	changed ljmp to sjmp
                            788 ;	Peephole 198.b	optimized misc jump sequence
   3E22 BA 01 0F            789 	cjne	r2,#0x01,00102$
                            790 ;	Peephole 200.b	removed redundant sjmp
                            791 ;	Peephole 300	removed redundant label 00107$
                            792 ;	Peephole 300	removed redundant label 00108$
                            793 ;	../../Platform/nano/uart.c:332: return 0 + (uint16_t) byte;
                            794 ;	genCast
   3E25 A8 10               795 	mov	r0,_bp
   3E27 08                  796 	inc	r0
   3E28 08                  797 	inc	r0
   3E29 08                  798 	inc	r0
   3E2A 86 02               799 	mov	ar2,@r0
   3E2C 7B 00               800 	mov	r3,#0x00
                            801 ;	genRet
   3E2E 8A 82               802 	mov	dpl,r2
   3E30 8B 83               803 	mov	dph,r3
                            804 ;	Peephole 112.b	changed ljmp to sjmp
   3E32 80 03               805 	sjmp	00104$
   3E34                     806 00102$:
                            807 ;	../../Platform/nano/uart.c:336: return -1;
                            808 ;	genRet
                            809 ;	Peephole 182.b	used 16 bit load of dptr
   3E34 90 FF FF            810 	mov	dptr,#0xFFFF
   3E37                     811 00104$:
   3E37 85 10 81            812 	mov	sp,_bp
   3E3A D0 10               813 	pop	_bp
   3E3C 22                  814 	ret
                            815 ;------------------------------------------------------------
                            816 ;Allocation info for local variables in function 'uart1_get'
                            817 ;------------------------------------------------------------
                            818 ;byte                      Allocated to stack - offset 1
                            819 ;------------------------------------------------------------
                            820 ;	../../Platform/nano/uart.c:340: int16_t uart1_get(void)
                            821 ;	-----------------------------------------
                            822 ;	 function uart1_get
                            823 ;	-----------------------------------------
   3E3D                     824 _uart1_get:
   3E3D C0 10               825 	push	_bp
   3E3F 85 81 10            826 	mov	_bp,sp
   3E42 05 81               827 	inc	sp
                            828 ;	../../Platform/nano/uart.c:344: if ( xQueueReceive(uart1_rx, &byte, (portTickType) 0 ) == pdTRUE)
                            829 ;	genAddrOf
                            830 ;	Peephole 212	reduced add sequence to inc
   3E44 AA 10               831 	mov	r2,_bp
   3E46 0A                  832 	inc	r2
                            833 ;	genCast
   3E47 7B 00               834 	mov	r3,#0x00
   3E49 7C 40               835 	mov	r4,#0x40
                            836 ;	genAssign
   3E4B 90 F0 A0            837 	mov	dptr,#_uart1_rx
   3E4E E0                  838 	movx	a,@dptr
   3E4F FD                  839 	mov	r5,a
   3E50 A3                  840 	inc	dptr
   3E51 E0                  841 	movx	a,@dptr
   3E52 FE                  842 	mov	r6,a
   3E53 A3                  843 	inc	dptr
   3E54 E0                  844 	movx	a,@dptr
   3E55 FF                  845 	mov	r7,a
                            846 ;	genIpush
                            847 ;	Peephole 181	changed mov to clr
   3E56 E4                  848 	clr	a
   3E57 C0 E0               849 	push	acc
   3E59 C0 E0               850 	push	acc
                            851 ;	genIpush
   3E5B C0 02               852 	push	ar2
   3E5D C0 03               853 	push	ar3
   3E5F C0 04               854 	push	ar4
                            855 ;	genCall
   3E61 8D 82               856 	mov	dpl,r5
   3E63 8E 83               857 	mov	dph,r6
   3E65 8F F0               858 	mov	b,r7
   3E67 12 23 5A            859 	lcall	_xQueueReceive
   3E6A AA 82               860 	mov	r2,dpl
   3E6C E5 81               861 	mov	a,sp
   3E6E 24 FB               862 	add	a,#0xfb
   3E70 F5 81               863 	mov	sp,a
                            864 ;	genCmpEq
                            865 ;	gencjneshort
                            866 ;	Peephole 112.b	changed ljmp to sjmp
                            867 ;	Peephole 198.b	optimized misc jump sequence
   3E72 BA 01 0D            868 	cjne	r2,#0x01,00102$
                            869 ;	Peephole 200.b	removed redundant sjmp
                            870 ;	Peephole 300	removed redundant label 00107$
                            871 ;	Peephole 300	removed redundant label 00108$
                            872 ;	../../Platform/nano/uart.c:346: return 0 + (uint16_t) byte;
                            873 ;	genCast
   3E75 A8 10               874 	mov	r0,_bp
   3E77 08                  875 	inc	r0
   3E78 86 02               876 	mov	ar2,@r0
   3E7A 7B 00               877 	mov	r3,#0x00
                            878 ;	genRet
   3E7C 8A 82               879 	mov	dpl,r2
   3E7E 8B 83               880 	mov	dph,r3
                            881 ;	Peephole 112.b	changed ljmp to sjmp
   3E80 80 03               882 	sjmp	00104$
   3E82                     883 00102$:
                            884 ;	../../Platform/nano/uart.c:350: return -1;
                            885 ;	genRet
                            886 ;	Peephole 182.b	used 16 bit load of dptr
   3E82 90 FF FF            887 	mov	dptr,#0xFFFF
   3E85                     888 00104$:
   3E85 85 10 81            889 	mov	sp,_bp
   3E88 D0 10               890 	pop	_bp
   3E8A 22                  891 	ret
                            892 ;------------------------------------------------------------
                            893 ;Allocation info for local variables in function 'uart1_put'
                            894 ;------------------------------------------------------------
                            895 ;byte                      Allocated to registers r2 
                            896 ;retval                    Allocated to registers r3 
                            897 ;new_ptr                   Allocated to registers r4 
                            898 ;------------------------------------------------------------
                            899 ;	../../Platform/nano/uart.c:354: int8_t uart1_put(uint8_t byte)
                            900 ;	-----------------------------------------
                            901 ;	 function uart1_put
                            902 ;	-----------------------------------------
   3E8B                     903 _uart1_put:
                            904 ;	genReceive
   3E8B AA 82               905 	mov	r2,dpl
                            906 ;	../../Platform/nano/uart.c:356: int8_t retval = 0;
                            907 ;	genAssign
   3E8D 7B 00               908 	mov	r3,#0x00
                            909 ;	../../Platform/nano/uart.c:358: if (uart1_txempty == pdTRUE)
                            910 ;	genAssign
   3E8F 90 F0 9F            911 	mov	dptr,#_uart1_txempty
   3E92 E0                  912 	movx	a,@dptr
   3E93 FC                  913 	mov	r4,a
                            914 ;	genCmpEq
                            915 ;	gencjneshort
                            916 ;	Peephole 112.b	changed ljmp to sjmp
                            917 ;	Peephole 198.b	optimized misc jump sequence
   3E94 BC 01 09            918 	cjne	r4,#0x01,00111$
                            919 ;	Peephole 200.b	removed redundant sjmp
                            920 ;	Peephole 300	removed redundant label 00120$
                            921 ;	Peephole 300	removed redundant label 00121$
                            922 ;	../../Platform/nano/uart.c:360: uart1_txempty = pdFALSE;
                            923 ;	genAssign
   3E97 90 F0 9F            924 	mov	dptr,#_uart1_txempty
                            925 ;	Peephole 181	changed mov to clr
   3E9A E4                  926 	clr	a
   3E9B F0                  927 	movx	@dptr,a
                            928 ;	../../Platform/nano/uart.c:361: U1BUF = byte;
                            929 ;	genAssign
   3E9C 8A F9               930 	mov	_U1BUF,r2
                            931 ;	Peephole 112.b	changed ljmp to sjmp
   3E9E 80 58               932 	sjmp	00112$
   3EA0                     933 00111$:
                            934 ;	../../Platform/nano/uart.c:378: uint8_t new_ptr = uart1_tx_wr +1;
                            935 ;	genAssign
   3EA0 90 F0 A4            936 	mov	dptr,#_uart1_tx_wr
   3EA3 E0                  937 	movx	a,@dptr
                            938 ;	genPlus
                            939 ;     genPlusIncr
                            940 ;	Peephole 185	changed order of increment (acc incremented also!)
   3EA4 04                  941 	inc	a
   3EA5 FC                  942 	mov	r4,a
                            943 ;	../../Platform/nano/uart.c:379: if (new_ptr >= UART1_TX_LEN) new_ptr -= UART1_TX_LEN;
                            944 ;	genCmpLt
                            945 ;	genCmp
   3EA6 BC 80 00            946 	cjne	r4,#0x80,00122$
   3EA9                     947 00122$:
                            948 ;	genIfxJump
                            949 ;	Peephole 112.b	changed ljmp to sjmp
                            950 ;	Peephole 160.a	removed sjmp by inverse jump logic
   3EA9 40 04               951 	jc	00102$
                            952 ;	Peephole 300	removed redundant label 00123$
                            953 ;	genMinus
   3EAB EC                  954 	mov	a,r4
   3EAC 24 80               955 	add	a,#0x80
   3EAE FC                  956 	mov	r4,a
   3EAF                     957 00102$:
                            958 ;	../../Platform/nano/uart.c:380: if (new_ptr == uart1_tx_rd)
                            959 ;	genAssign
   3EAF 90 F0 A3            960 	mov	dptr,#_uart1_tx_rd
   3EB2 E0                  961 	movx	a,@dptr
   3EB3 FD                  962 	mov	r5,a
                            963 ;	genCmpEq
                            964 ;	gencjneshort
   3EB4 EC                  965 	mov	a,r4
                            966 ;	Peephole 112.b	changed ljmp to sjmp
                            967 ;	Peephole 198.b	optimized misc jump sequence
   3EB5 B5 05 04            968 	cjne	a,ar5,00108$
                            969 ;	Peephole 200.b	removed redundant sjmp
                            970 ;	Peephole 300	removed redundant label 00124$
                            971 ;	Peephole 300	removed redundant label 00125$
                            972 ;	../../Platform/nano/uart.c:382: retval = -1;
                            973 ;	genAssign
   3EB8 7B FF               974 	mov	r3,#0xFF
                            975 ;	Peephole 112.b	changed ljmp to sjmp
   3EBA 80 3C               976 	sjmp	00112$
   3EBC                     977 00108$:
                            978 ;	../../Platform/nano/uart.c:386: uart1_tx_buffer[new_ptr] = byte;
                            979 ;	genPlus
                            980 ;	Peephole 236.g	used r4 instead of ar4
   3EBC EC                  981 	mov	a,r4
   3EBD 24 5D               982 	add	a,#_uart1_tx_buffer
   3EBF F5 82               983 	mov	dpl,a
                            984 ;	Peephole 181	changed mov to clr
   3EC1 E4                  985 	clr	a
   3EC2 34 EE               986 	addc	a,#(_uart1_tx_buffer >> 8)
   3EC4 F5 83               987 	mov	dph,a
                            988 ;	genPointerSet
                            989 ;     genFarPointerSet
   3EC6 EA                  990 	mov	a,r2
   3EC7 F0                  991 	movx	@dptr,a
                            992 ;	../../Platform/nano/uart.c:387: IEN0_EA = 0;
                            993 ;	genAssign
   3EC8 C2 AF               994 	clr	_IEN0_EA
                            995 ;	../../Platform/nano/uart.c:388: uart1_tx_wr = new_ptr;
                            996 ;	genAssign
   3ECA 90 F0 A4            997 	mov	dptr,#_uart1_tx_wr
   3ECD EC                  998 	mov	a,r4
   3ECE F0                  999 	movx	@dptr,a
                           1000 ;	../../Platform/nano/uart.c:389: if (uart1_txempty == pdTRUE)
                           1001 ;	genAssign
   3ECF 90 F0 9F           1002 	mov	dptr,#_uart1_txempty
   3ED2 E0                 1003 	movx	a,@dptr
   3ED3 FC                 1004 	mov	r4,a
                           1005 ;	genCmpEq
                           1006 ;	gencjneshort
                           1007 ;	Peephole 112.b	changed ljmp to sjmp
                           1008 ;	Peephole 198.b	optimized misc jump sequence
   3ED4 BC 01 1F           1009 	cjne	r4,#0x01,00106$
                           1010 ;	Peephole 200.b	removed redundant sjmp
                           1011 ;	Peephole 300	removed redundant label 00126$
                           1012 ;	Peephole 300	removed redundant label 00127$
                           1013 ;	../../Platform/nano/uart.c:391: uart1_tx_rd++;
                           1014 ;	genPlus
   3ED7 90 F0 A3           1015 	mov	dptr,#_uart1_tx_rd
                           1016 ;     genPlusIncr
   3EDA 74 01              1017 	mov	a,#0x01
                           1018 ;	Peephole 236.a	used r5 instead of ar5
   3EDC 2D                 1019 	add	a,r5
   3EDD F0                 1020 	movx	@dptr,a
                           1021 ;	../../Platform/nano/uart.c:392: if (uart1_tx_rd >= UART1_TX_LEN) uart1_tx_rd -= UART1_TX_LEN;
                           1022 ;	genAssign
   3EDE 90 F0 A3           1023 	mov	dptr,#_uart1_tx_rd
   3EE1 E0                 1024 	movx	a,@dptr
   3EE2 FC                 1025 	mov	r4,a
                           1026 ;	genCmpLt
                           1027 ;	genCmp
   3EE3 BC 80 00           1028 	cjne	r4,#0x80,00128$
   3EE6                    1029 00128$:
                           1030 ;	genIfxJump
                           1031 ;	Peephole 112.b	changed ljmp to sjmp
                           1032 ;	Peephole 160.a	removed sjmp by inverse jump logic
   3EE6 40 07              1033 	jc	00104$
                           1034 ;	Peephole 300	removed redundant label 00129$
                           1035 ;	genMinus
   3EE8 EC                 1036 	mov	a,r4
   3EE9 24 80              1037 	add	a,#0x80
                           1038 ;	genAssign
   3EEB 90 F0 A3           1039 	mov	dptr,#_uart1_tx_rd
   3EEE F0                 1040 	movx	@dptr,a
   3EEF                    1041 00104$:
                           1042 ;	../../Platform/nano/uart.c:393: uart1_txempty = pdFALSE;
                           1043 ;	genAssign
   3EEF 90 F0 9F           1044 	mov	dptr,#_uart1_txempty
                           1045 ;	Peephole 181	changed mov to clr
   3EF2 E4                 1046 	clr	a
   3EF3 F0                 1047 	movx	@dptr,a
                           1048 ;	../../Platform/nano/uart.c:394: U1BUF = byte;
                           1049 ;	genAssign
   3EF4 8A F9              1050 	mov	_U1BUF,r2
   3EF6                    1051 00106$:
                           1052 ;	../../Platform/nano/uart.c:396: IEN0_EA = 1;
                           1053 ;	genAssign
   3EF6 D2 AF              1054 	setb	_IEN0_EA
   3EF8                    1055 00112$:
                           1056 ;	../../Platform/nano/uart.c:401: return retval;
                           1057 ;	genRet
   3EF8 8B 82              1058 	mov	dpl,r3
                           1059 ;	Peephole 300	removed redundant label 00113$
   3EFA 22                 1060 	ret
                           1061 ;------------------------------------------------------------
                           1062 ;Allocation info for local variables in function 'uart1_rxISR'
                           1063 ;------------------------------------------------------------
                           1064 ;byte                      Allocated to stack - offset 1
                           1065 ;------------------------------------------------------------
                           1066 ;	../../Platform/nano/uart.c:410: void uart1_rxISR( void ) interrupt (URX1_VECTOR)
                           1067 ;	-----------------------------------------
                           1068 ;	 function uart1_rxISR
                           1069 ;	-----------------------------------------
   3EFB                    1070 _uart1_rxISR:
   3EFB C0 E0              1071 	push	acc
   3EFD C0 F0              1072 	push	b
   3EFF C0 82              1073 	push	dpl
   3F01 C0 83              1074 	push	dph
   3F03 C0 02              1075 	push	(0+2)
   3F05 C0 03              1076 	push	(0+3)
   3F07 C0 04              1077 	push	(0+4)
   3F09 C0 05              1078 	push	(0+5)
   3F0B C0 06              1079 	push	(0+6)
   3F0D C0 07              1080 	push	(0+7)
   3F0F C0 00              1081 	push	(0+0)
   3F11 C0 01              1082 	push	(0+1)
   3F13 C0 20              1083 	push	bits
   3F15 C0 D0              1084 	push	psw
   3F17 75 D0 00           1085 	mov	psw,#0x00
   3F1A C0 10              1086 	push	_bp
   3F1C 85 81 10           1087 	mov	_bp,sp
   3F1F 05 81              1088 	inc	sp
                           1089 ;	../../Platform/nano/uart.c:414: TCON_URX1IF = 0;
                           1090 ;	genAssign
   3F21 C2 8F              1091 	clr	_TCON_URX1IF
                           1092 ;	../../Platform/nano/uart.c:418: byte = U1BUF;
                           1093 ;	genAssign
   3F23 A8 10              1094 	mov	r0,_bp
   3F25 08                 1095 	inc	r0
   3F26 A6 F9              1096 	mov	@r0,_U1BUF
                           1097 ;	../../Platform/nano/uart.c:420: if( xQueueSendFromISR(uart1_rx, &byte, pdFALSE ) == pdTRUE)
                           1098 ;	genAddrOf
                           1099 ;	Peephole 212	reduced add sequence to inc
   3F28 AA 10              1100 	mov	r2,_bp
   3F2A 0A                 1101 	inc	r2
                           1102 ;	genCast
   3F2B 7B 00              1103 	mov	r3,#0x00
   3F2D 7C 40              1104 	mov	r4,#0x40
                           1105 ;	genAssign
   3F2F 90 F0 A0           1106 	mov	dptr,#_uart1_rx
   3F32 E0                 1107 	movx	a,@dptr
   3F33 FD                 1108 	mov	r5,a
   3F34 A3                 1109 	inc	dptr
   3F35 E0                 1110 	movx	a,@dptr
   3F36 FE                 1111 	mov	r6,a
   3F37 A3                 1112 	inc	dptr
   3F38 E0                 1113 	movx	a,@dptr
   3F39 FF                 1114 	mov	r7,a
                           1115 ;	genIpush
                           1116 ;	Peephole 181	changed mov to clr
   3F3A E4                 1117 	clr	a
   3F3B C0 E0              1118 	push	acc
                           1119 ;	genIpush
   3F3D C0 02              1120 	push	ar2
   3F3F C0 03              1121 	push	ar3
   3F41 C0 04              1122 	push	ar4
                           1123 ;	genCall
   3F43 8D 82              1124 	mov	dpl,r5
   3F45 8E 83              1125 	mov	dph,r6
   3F47 8F F0              1126 	mov	b,r7
   3F49 12 21 24           1127 	lcall	_xQueueSendFromISR
   3F4C AA 82              1128 	mov	r2,dpl
   3F4E E5 81              1129 	mov	a,sp
   3F50 24 FC              1130 	add	a,#0xfc
   3F52 F5 81              1131 	mov	sp,a
                           1132 ;	genCmpEq
                           1133 ;	gencjneshort
                           1134 ;	Peephole 112.b	changed ljmp to sjmp
                           1135 ;	Peephole 198.b	optimized misc jump sequence
   3F54 BA 01 03           1136 	cjne	r2,#0x01,00103$
                           1137 ;	Peephole 200.b	removed redundant sjmp
                           1138 ;	Peephole 300	removed redundant label 00106$
                           1139 ;	Peephole 300	removed redundant label 00107$
                           1140 ;	../../Platform/nano/uart.c:422: taskYIELD();
                           1141 ;	genCall
   3F57 12 33 E8           1142 	lcall	_vPortYield
   3F5A                    1143 00103$:
   3F5A 85 10 81           1144 	mov	sp,_bp
   3F5D D0 10              1145 	pop	_bp
   3F5F D0 D0              1146 	pop	psw
   3F61 D0 20              1147 	pop	bits
   3F63 D0 01              1148 	pop	(0+1)
   3F65 D0 00              1149 	pop	(0+0)
   3F67 D0 07              1150 	pop	(0+7)
   3F69 D0 06              1151 	pop	(0+6)
   3F6B D0 05              1152 	pop	(0+5)
   3F6D D0 04              1153 	pop	(0+4)
   3F6F D0 03              1154 	pop	(0+3)
   3F71 D0 02              1155 	pop	(0+2)
   3F73 D0 83              1156 	pop	dph
   3F75 D0 82              1157 	pop	dpl
   3F77 D0 F0              1158 	pop	b
   3F79 D0 E0              1159 	pop	acc
   3F7B 32                 1160 	reti
                           1161 ;------------------------------------------------------------
                           1162 ;Allocation info for local variables in function 'uart1_txISR'
                           1163 ;------------------------------------------------------------
                           1164 ;------------------------------------------------------------
                           1165 ;	../../Platform/nano/uart.c:434: void uart1_txISR( void ) interrupt (UTX1_VECTOR)
                           1166 ;	-----------------------------------------
                           1167 ;	 function uart1_txISR
                           1168 ;	-----------------------------------------
   3F7C                    1169 _uart1_txISR:
   3F7C C0 E0              1170 	push	acc
   3F7E C0 82              1171 	push	dpl
   3F80 C0 83              1172 	push	dph
   3F82 C0 02              1173 	push	ar2
   3F84 C0 03              1174 	push	ar3
   3F86 C0 D0              1175 	push	psw
   3F88 75 D0 00           1176 	mov	psw,#0x00
                           1177 ;	../../Platform/nano/uart.c:448: if (uart1_tx_rd != uart1_tx_wr)
                           1178 ;	genAssign
   3F8B 90 F0 A3           1179 	mov	dptr,#_uart1_tx_rd
   3F8E E0                 1180 	movx	a,@dptr
   3F8F FA                 1181 	mov	r2,a
                           1182 ;	genAssign
   3F90 90 F0 A4           1183 	mov	dptr,#_uart1_tx_wr
   3F93 E0                 1184 	movx	a,@dptr
   3F94 FB                 1185 	mov	r3,a
                           1186 ;	genCmpEq
                           1187 ;	gencjneshort
   3F95 EA                 1188 	mov	a,r2
   3F96 B5 03 02           1189 	cjne	a,ar3,00110$
                           1190 ;	Peephole 112.b	changed ljmp to sjmp
   3F99 80 27              1191 	sjmp	00104$
   3F9B                    1192 00110$:
                           1193 ;	../../Platform/nano/uart.c:450: U1BUF = uart1_tx_buffer[uart1_tx_rd++];
                           1194 ;	genPlus
   3F9B 90 F0 A3           1195 	mov	dptr,#_uart1_tx_rd
                           1196 ;     genPlusIncr
   3F9E 74 01              1197 	mov	a,#0x01
                           1198 ;	Peephole 236.a	used r2 instead of ar2
   3FA0 2A                 1199 	add	a,r2
   3FA1 F0                 1200 	movx	@dptr,a
                           1201 ;	genPlus
                           1202 ;	Peephole 236.g	used r2 instead of ar2
   3FA2 EA                 1203 	mov	a,r2
   3FA3 24 5D              1204 	add	a,#_uart1_tx_buffer
   3FA5 F5 82              1205 	mov	dpl,a
                           1206 ;	Peephole 181	changed mov to clr
   3FA7 E4                 1207 	clr	a
   3FA8 34 EE              1208 	addc	a,#(_uart1_tx_buffer >> 8)
   3FAA F5 83              1209 	mov	dph,a
                           1210 ;	genPointerGet
                           1211 ;	genFarPointerGet
   3FAC E0                 1212 	movx	a,@dptr
   3FAD F5 F9              1213 	mov	_U1BUF,a
                           1214 ;	../../Platform/nano/uart.c:451: if (uart1_tx_rd >= UART1_TX_LEN) uart1_tx_rd -= UART1_TX_LEN;
                           1215 ;	genAssign
   3FAF 90 F0 A3           1216 	mov	dptr,#_uart1_tx_rd
   3FB2 E0                 1217 	movx	a,@dptr
   3FB3 FA                 1218 	mov	r2,a
                           1219 ;	genCmpLt
                           1220 ;	genCmp
   3FB4 BA 80 00           1221 	cjne	r2,#0x80,00111$
   3FB7                    1222 00111$:
                           1223 ;	genIfxJump
                           1224 ;	Peephole 112.b	changed ljmp to sjmp
                           1225 ;	Peephole 160.a	removed sjmp by inverse jump logic
   3FB7 40 0F              1226 	jc	00106$
                           1227 ;	Peephole 300	removed redundant label 00112$
                           1228 ;	genMinus
   3FB9 EA                 1229 	mov	a,r2
   3FBA 24 80              1230 	add	a,#0x80
                           1231 ;	genAssign
   3FBC 90 F0 A3           1232 	mov	dptr,#_uart1_tx_rd
   3FBF F0                 1233 	movx	@dptr,a
                           1234 ;	Peephole 112.b	changed ljmp to sjmp
   3FC0 80 06              1235 	sjmp	00106$
   3FC2                    1236 00104$:
                           1237 ;	../../Platform/nano/uart.c:456: uart1_txempty = pdTRUE;
                           1238 ;	genAssign
   3FC2 90 F0 9F           1239 	mov	dptr,#_uart1_txempty
   3FC5 74 01              1240 	mov	a,#0x01
   3FC7 F0                 1241 	movx	@dptr,a
   3FC8                    1242 00106$:
   3FC8 D0 D0              1243 	pop	psw
   3FCA D0 03              1244 	pop	ar3
   3FCC D0 02              1245 	pop	ar2
   3FCE D0 83              1246 	pop	dph
   3FD0 D0 82              1247 	pop	dpl
   3FD2 D0 E0              1248 	pop	acc
   3FD4 32                 1249 	reti
                           1250 ;	eliminated unneeded push/pop b
                           1251 	.area CSEG    (CODE)
                           1252 	.area CONST   (CODE)
                           1253 	.area XINIT   (CODE)
   E89C                    1254 __xinit__uart1_txempty:
   E89C 01                 1255 	.db #0x01
   E89D                    1256 __xinit__uart1_rx:
                           1257 ; generic printIvalPtr
   E89D 00 00 00           1258 	.byte #0x00,#0x00,#0x00
   E8A0                    1259 __xinit__uart1_tx_rd:
   E8A0 00                 1260 	.db #0x00
   E8A1                    1261 __xinit__uart1_tx_wr:
   E8A1 00                 1262 	.db #0x00
