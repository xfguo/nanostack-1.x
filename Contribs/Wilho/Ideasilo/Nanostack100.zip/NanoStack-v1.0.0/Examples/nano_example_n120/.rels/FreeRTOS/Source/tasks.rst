                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Nov 10 2006)
                              4 ; This file generated Fri Feb  1 13:33:37 2008
                              5 ;--------------------------------------------------------
                              6 	.module tasks
                              7 	.optsdcc -mmcs51 --model-large
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _IRCON2_P2IF
                             13 	.globl _IRCON2_UTX0IF
                             14 	.globl _IRCON2_UTX1IF
                             15 	.globl _IRCON2_P1IF
                             16 	.globl _IRCON2_WDTIF
                             17 	.globl _CY
                             18 	.globl _AC
                             19 	.globl _F0
                             20 	.globl _RS1
                             21 	.globl _RS0
                             22 	.globl _OV
                             23 	.globl _F1
                             24 	.globl _P
                             25 	.globl _IRCON_DMAIF
                             26 	.globl _IRCON_T1IF
                             27 	.globl _IRCON_T2IF
                             28 	.globl _IRCON_T3IF
                             29 	.globl _IRCON_T4IF
                             30 	.globl _IRCON_P0IF
                             31 	.globl _IRCON_STIF
                             32 	.globl _IEN1_DMAIE
                             33 	.globl _IEN1_T1IE
                             34 	.globl _IEN1_T2IE
                             35 	.globl _IEN1_T3IE
                             36 	.globl _IEN1_T4IE
                             37 	.globl _IEN1_P0IE
                             38 	.globl _IEN0_RFERRIE
                             39 	.globl _IEN0_ADCIE
                             40 	.globl _IEN0_URX0IE
                             41 	.globl _IEN0_URX1IE
                             42 	.globl _IEN0_ENCIE
                             43 	.globl _IEN0_STIE
                             44 	.globl _IEN0_EA
                             45 	.globl _EA
                             46 	.globl _P2_4
                             47 	.globl _P2_3
                             48 	.globl _P2_2
                             49 	.globl _P2_1
                             50 	.globl _P2_0
                             51 	.globl _S0CON_ENCIF_0
                             52 	.globl _S0CON_ENCIF_1
                             53 	.globl _P1_7
                             54 	.globl _P1_6
                             55 	.globl _P1_5
                             56 	.globl _P1_4
                             57 	.globl _P1_3
                             58 	.globl _P1_2
                             59 	.globl _P1_1
                             60 	.globl _P1_0
                             61 	.globl _TCON_IT0
                             62 	.globl _TCON_RFERRIF
                             63 	.globl _TCON_IT1
                             64 	.globl _TCON_URX0IF
                             65 	.globl _TCON_ADCIF
                             66 	.globl _TCON_URX1IF
                             67 	.globl _P0_0
                             68 	.globl _P0_1
                             69 	.globl _P0_2
                             70 	.globl _P0_3
                             71 	.globl _P0_4
                             72 	.globl _P0_5
                             73 	.globl _P0_6
                             74 	.globl _P0_7
                             75 	.globl _P2DIR
                             76 	.globl _P1DIR
                             77 	.globl _P0DIR
                             78 	.globl _U1GCR
                             79 	.globl _U1UCR
                             80 	.globl _U1BAUD
                             81 	.globl _U1BUF
                             82 	.globl _U1CSR
                             83 	.globl _P2INP
                             84 	.globl _P1INP
                             85 	.globl _P2SEL
                             86 	.globl _P1SEL
                             87 	.globl _P0SEL
                             88 	.globl _ADCCFG
                             89 	.globl _PERCFG
                             90 	.globl _B
                             91 	.globl _T4CC1
                             92 	.globl _T4CCTL1
                             93 	.globl _T4CC0
                             94 	.globl _T4CCTL0
                             95 	.globl _T4CTL
                             96 	.globl _T4CNT
                             97 	.globl _RFIF
                             98 	.globl _IRCON2
                             99 	.globl _T1CCTL2
                            100 	.globl _T1CCTL1
                            101 	.globl _T1CCTL0
                            102 	.globl _T1CTL
                            103 	.globl _T1CNTH
                            104 	.globl _T1CNTL
                            105 	.globl _RFST
                            106 	.globl _ACC
                            107 	.globl _T1CC2H
                            108 	.globl _T1CC2L
                            109 	.globl _T1CC1H
                            110 	.globl _T1CC1L
                            111 	.globl _T1CC0H
                            112 	.globl _T1CC0L
                            113 	.globl _RFD
                            114 	.globl _TIMIF
                            115 	.globl _DMAREQ
                            116 	.globl _DMAARM
                            117 	.globl _DMA0CFGH
                            118 	.globl _DMA0CFGL
                            119 	.globl _DMA1CFGH
                            120 	.globl _DMA1CFGL
                            121 	.globl _DMAIRQ
                            122 	.globl _PSW
                            123 	.globl _T3CC1
                            124 	.globl _T3CCTL1
                            125 	.globl _T3CC0
                            126 	.globl _T3CCTL0
                            127 	.globl _T3CTL
                            128 	.globl _T3CNT
                            129 	.globl _WDCTL
                            130 	.globl _T2CON
                            131 	.globl _MEMCTR
                            132 	.globl _CLKCON
                            133 	.globl _U0GCR
                            134 	.globl _U0UCR
                            135 	.globl _T2CNF
                            136 	.globl _U0BAUD
                            137 	.globl _U0BUF
                            138 	.globl _IRCON
                            139 	.globl _SLEEP
                            140 	.globl _RNDH
                            141 	.globl _RNDL
                            142 	.globl _ADCH
                            143 	.globl _ADCL
                            144 	.globl _IP1
                            145 	.globl _IEN1
                            146 	.globl _RCCTL
                            147 	.globl _ADCCON3
                            148 	.globl _ADCCON2
                            149 	.globl _ADCCON1
                            150 	.globl _ENCCS
                            151 	.globl _ENCDO
                            152 	.globl _ENCDI
                            153 	.globl _FWDATA
                            154 	.globl _FCTL
                            155 	.globl _FADDRH
                            156 	.globl _FADDRL
                            157 	.globl _FWT
                            158 	.globl _IP0
                            159 	.globl _IEN0
                            160 	.globl _IE
                            161 	.globl _T2THD
                            162 	.globl _T2TLD
                            163 	.globl _T2CAPHPH
                            164 	.globl _T2CAPLPL
                            165 	.globl _T2OF2
                            166 	.globl _T2OF1
                            167 	.globl _T2OF0
                            168 	.globl _P2
                            169 	.globl _T2PEROF2
                            170 	.globl _T2PEROF1
                            171 	.globl _T2PEROF0
                            172 	.globl _S1CON
                            173 	.globl _IEN2
                            174 	.globl _HSRC
                            175 	.globl _S0CON
                            176 	.globl _ST2
                            177 	.globl _ST1
                            178 	.globl _ST0
                            179 	.globl _T2CMP
                            180 	.globl __XPAGE
                            181 	.globl _DPS
                            182 	.globl _RFIM
                            183 	.globl _P1
                            184 	.globl _P0INP
                            185 	.globl _P1IEN
                            186 	.globl _PICTL
                            187 	.globl _P2IFG
                            188 	.globl _P1IFG
                            189 	.globl _P0IFG
                            190 	.globl _TCON
                            191 	.globl _PCON
                            192 	.globl _U0CSR
                            193 	.globl _DPH1
                            194 	.globl _DPL1
                            195 	.globl _DPH0
                            196 	.globl _DPL0
                            197 	.globl _SP
                            198 	.globl _P0
                            199 	.globl _pxCurrentTCB
                            200 	.globl _RFD_SHADOW
                            201 	.globl _RFSTATUS
                            202 	.globl _CHIPID
                            203 	.globl _CHVER
                            204 	.globl _FSMTC1
                            205 	.globl _RXFIFOCNT
                            206 	.globl _IOCFG3
                            207 	.globl _IOCFG2
                            208 	.globl _IOCFG1
                            209 	.globl _IOCFG0
                            210 	.globl _SHORTADDRL
                            211 	.globl _SHORTADDRH
                            212 	.globl _PANIDL
                            213 	.globl _PANIDH
                            214 	.globl _IEEE_ADDR7
                            215 	.globl _IEEE_ADDR6
                            216 	.globl _IEEE_ADDR5
                            217 	.globl _IEEE_ADDR4
                            218 	.globl _IEEE_ADDR3
                            219 	.globl _IEEE_ADDR2
                            220 	.globl _IEEE_ADDR1
                            221 	.globl _IEEE_ADDR0
                            222 	.globl _DACTSTL
                            223 	.globl _DACTSTH
                            224 	.globl _ADCTSTL
                            225 	.globl _ADCTSTH
                            226 	.globl _FSMSTATE
                            227 	.globl _AGCCTRLL
                            228 	.globl _AGCCTRLH
                            229 	.globl _MANORL
                            230 	.globl _MANORH
                            231 	.globl _MANANDL
                            232 	.globl _MANANDH
                            233 	.globl _FSMTCL
                            234 	.globl _FSMTCH
                            235 	.globl _RFPWR
                            236 	.globl _CSPT
                            237 	.globl _CSPCTRL
                            238 	.globl _CSPZ
                            239 	.globl _CSPY
                            240 	.globl _CSPX
                            241 	.globl _FSCTRLL
                            242 	.globl _FSCTRLH
                            243 	.globl _RXCTRL1L
                            244 	.globl _RXCTRL1H
                            245 	.globl _RXCTRL0L
                            246 	.globl _RXCTRL0H
                            247 	.globl _TXCTRLL
                            248 	.globl _TXCTRLH
                            249 	.globl _SYNCWORDL
                            250 	.globl _SYNCWORDH
                            251 	.globl _RSSIL
                            252 	.globl _RSSIH
                            253 	.globl _MDMCTRL1L
                            254 	.globl _MDMCTRL1H
                            255 	.globl _MDMCTRL0L
                            256 	.globl _MDMCTRL0H
                            257 	.globl _xTaskCreate
                            258 	.globl _vTaskDelete
                            259 	.globl _vTaskDelayUntil
                            260 	.globl _vTaskDelay
                            261 	.globl _vTaskStartScheduler
                            262 	.globl _vTaskEndScheduler
                            263 	.globl _vTaskSuspendAll
                            264 	.globl _xTaskResumeAll
                            265 	.globl _xTaskGetTickCount
                            266 	.globl _uxTaskGetNumberOfTasks
                            267 	.globl _vTaskIncrementTick
                            268 	.globl _vTaskSwitchContext
                            269 	.globl _vTaskPlaceOnEventList
                            270 	.globl _xTaskRemoveFromEventList
                            271 	.globl _vTaskSetTimeOutState
                            272 	.globl _xTaskCheckForTimeOut
                            273 	.globl _vTaskMissedYield
                            274 ;--------------------------------------------------------
                            275 ; special function registers
                            276 ;--------------------------------------------------------
                            277 	.area RSEG    (DATA)
                    0080    278 _P0	=	0x0080
                    0081    279 _SP	=	0x0081
                    0082    280 _DPL0	=	0x0082
                    0083    281 _DPH0	=	0x0083
                    0084    282 _DPL1	=	0x0084
                    0085    283 _DPH1	=	0x0085
                    0086    284 _U0CSR	=	0x0086
                    0087    285 _PCON	=	0x0087
                    0088    286 _TCON	=	0x0088
                    0089    287 _P0IFG	=	0x0089
                    008A    288 _P1IFG	=	0x008a
                    008B    289 _P2IFG	=	0x008b
                    008C    290 _PICTL	=	0x008c
                    008D    291 _P1IEN	=	0x008d
                    008F    292 _P0INP	=	0x008f
                    0090    293 _P1	=	0x0090
                    0091    294 _RFIM	=	0x0091
                    0092    295 _DPS	=	0x0092
                    0093    296 __XPAGE	=	0x0093
                    0094    297 _T2CMP	=	0x0094
                    0095    298 _ST0	=	0x0095
                    0096    299 _ST1	=	0x0096
                    0097    300 _ST2	=	0x0097
                    0098    301 _S0CON	=	0x0098
                    0099    302 _HSRC	=	0x0099
                    009A    303 _IEN2	=	0x009a
                    009B    304 _S1CON	=	0x009b
                    009C    305 _T2PEROF0	=	0x009c
                    009D    306 _T2PEROF1	=	0x009d
                    009E    307 _T2PEROF2	=	0x009e
                    00A0    308 _P2	=	0x00a0
                    00A1    309 _T2OF0	=	0x00a1
                    00A2    310 _T2OF1	=	0x00a2
                    00A3    311 _T2OF2	=	0x00a3
                    00A4    312 _T2CAPLPL	=	0x00a4
                    00A5    313 _T2CAPHPH	=	0x00a5
                    00A6    314 _T2TLD	=	0x00a6
                    00A7    315 _T2THD	=	0x00a7
                    00A8    316 _IE	=	0x00a8
                    00A8    317 _IEN0	=	0x00a8
                    00A9    318 _IP0	=	0x00a9
                    00AB    319 _FWT	=	0x00ab
                    00AC    320 _FADDRL	=	0x00ac
                    00AD    321 _FADDRH	=	0x00ad
                    00AE    322 _FCTL	=	0x00ae
                    00AF    323 _FWDATA	=	0x00af
                    00B1    324 _ENCDI	=	0x00b1
                    00B2    325 _ENCDO	=	0x00b2
                    00B3    326 _ENCCS	=	0x00b3
                    00B4    327 _ADCCON1	=	0x00b4
                    00B5    328 _ADCCON2	=	0x00b5
                    00B6    329 _ADCCON3	=	0x00b6
                    00B7    330 _RCCTL	=	0x00b7
                    00B8    331 _IEN1	=	0x00b8
                    00B9    332 _IP1	=	0x00b9
                    00BA    333 _ADCL	=	0x00ba
                    00BB    334 _ADCH	=	0x00bb
                    00BC    335 _RNDL	=	0x00bc
                    00BD    336 _RNDH	=	0x00bd
                    00BE    337 _SLEEP	=	0x00be
                    00C0    338 _IRCON	=	0x00c0
                    00C1    339 _U0BUF	=	0x00c1
                    00C2    340 _U0BAUD	=	0x00c2
                    00C3    341 _T2CNF	=	0x00c3
                    00C4    342 _U0UCR	=	0x00c4
                    00C5    343 _U0GCR	=	0x00c5
                    00C6    344 _CLKCON	=	0x00c6
                    00C7    345 _MEMCTR	=	0x00c7
                    00C8    346 _T2CON	=	0x00c8
                    00C9    347 _WDCTL	=	0x00c9
                    00CA    348 _T3CNT	=	0x00ca
                    00CB    349 _T3CTL	=	0x00cb
                    00CC    350 _T3CCTL0	=	0x00cc
                    00CD    351 _T3CC0	=	0x00cd
                    00CE    352 _T3CCTL1	=	0x00ce
                    00CF    353 _T3CC1	=	0x00cf
                    00D0    354 _PSW	=	0x00d0
                    00D1    355 _DMAIRQ	=	0x00d1
                    00D2    356 _DMA1CFGL	=	0x00d2
                    00D3    357 _DMA1CFGH	=	0x00d3
                    00D4    358 _DMA0CFGL	=	0x00d4
                    00D5    359 _DMA0CFGH	=	0x00d5
                    00D6    360 _DMAARM	=	0x00d6
                    00D7    361 _DMAREQ	=	0x00d7
                    00D8    362 _TIMIF	=	0x00d8
                    00D9    363 _RFD	=	0x00d9
                    00DA    364 _T1CC0L	=	0x00da
                    00DB    365 _T1CC0H	=	0x00db
                    00DC    366 _T1CC1L	=	0x00dc
                    00DD    367 _T1CC1H	=	0x00dd
                    00DE    368 _T1CC2L	=	0x00de
                    00DF    369 _T1CC2H	=	0x00df
                    00E0    370 _ACC	=	0x00e0
                    00E1    371 _RFST	=	0x00e1
                    00E2    372 _T1CNTL	=	0x00e2
                    00E3    373 _T1CNTH	=	0x00e3
                    00E4    374 _T1CTL	=	0x00e4
                    00E5    375 _T1CCTL0	=	0x00e5
                    00E6    376 _T1CCTL1	=	0x00e6
                    00E7    377 _T1CCTL2	=	0x00e7
                    00E8    378 _IRCON2	=	0x00e8
                    00E9    379 _RFIF	=	0x00e9
                    00EA    380 _T4CNT	=	0x00ea
                    00EB    381 _T4CTL	=	0x00eb
                    00EC    382 _T4CCTL0	=	0x00ec
                    00ED    383 _T4CC0	=	0x00ed
                    00EE    384 _T4CCTL1	=	0x00ee
                    00EF    385 _T4CC1	=	0x00ef
                    00F0    386 _B	=	0x00f0
                    00F1    387 _PERCFG	=	0x00f1
                    00F2    388 _ADCCFG	=	0x00f2
                    00F3    389 _P0SEL	=	0x00f3
                    00F4    390 _P1SEL	=	0x00f4
                    00F5    391 _P2SEL	=	0x00f5
                    00F6    392 _P1INP	=	0x00f6
                    00F7    393 _P2INP	=	0x00f7
                    00F8    394 _U1CSR	=	0x00f8
                    00F9    395 _U1BUF	=	0x00f9
                    00FA    396 _U1BAUD	=	0x00fa
                    00FB    397 _U1UCR	=	0x00fb
                    00FC    398 _U1GCR	=	0x00fc
                    00FD    399 _P0DIR	=	0x00fd
                    00FE    400 _P1DIR	=	0x00fe
                    00FF    401 _P2DIR	=	0x00ff
                            402 ;--------------------------------------------------------
                            403 ; special function bits
                            404 ;--------------------------------------------------------
                            405 	.area RSEG    (DATA)
                    0087    406 _P0_7	=	0x0087
                    0086    407 _P0_6	=	0x0086
                    0085    408 _P0_5	=	0x0085
                    0084    409 _P0_4	=	0x0084
                    0083    410 _P0_3	=	0x0083
                    0082    411 _P0_2	=	0x0082
                    0081    412 _P0_1	=	0x0081
                    0080    413 _P0_0	=	0x0080
                    008F    414 _TCON_URX1IF	=	0x008f
                    008D    415 _TCON_ADCIF	=	0x008d
                    008B    416 _TCON_URX0IF	=	0x008b
                    008A    417 _TCON_IT1	=	0x008a
                    0089    418 _TCON_RFERRIF	=	0x0089
                    0088    419 _TCON_IT0	=	0x0088
                    0090    420 _P1_0	=	0x0090
                    0091    421 _P1_1	=	0x0091
                    0092    422 _P1_2	=	0x0092
                    0093    423 _P1_3	=	0x0093
                    0094    424 _P1_4	=	0x0094
                    0095    425 _P1_5	=	0x0095
                    0096    426 _P1_6	=	0x0096
                    0097    427 _P1_7	=	0x0097
                    0099    428 _S0CON_ENCIF_1	=	0x0099
                    0098    429 _S0CON_ENCIF_0	=	0x0098
                    00A0    430 _P2_0	=	0x00a0
                    00A1    431 _P2_1	=	0x00a1
                    00A2    432 _P2_2	=	0x00a2
                    00A3    433 _P2_3	=	0x00a3
                    00A4    434 _P2_4	=	0x00a4
                    00AF    435 _EA	=	0x00af
                    00AF    436 _IEN0_EA	=	0x00af
                    00AD    437 _IEN0_STIE	=	0x00ad
                    00AC    438 _IEN0_ENCIE	=	0x00ac
                    00AB    439 _IEN0_URX1IE	=	0x00ab
                    00AA    440 _IEN0_URX0IE	=	0x00aa
                    00A9    441 _IEN0_ADCIE	=	0x00a9
                    00A8    442 _IEN0_RFERRIE	=	0x00a8
                    00BD    443 _IEN1_P0IE	=	0x00bd
                    00BC    444 _IEN1_T4IE	=	0x00bc
                    00BB    445 _IEN1_T3IE	=	0x00bb
                    00BA    446 _IEN1_T2IE	=	0x00ba
                    00B9    447 _IEN1_T1IE	=	0x00b9
                    00B8    448 _IEN1_DMAIE	=	0x00b8
                    00C7    449 _IRCON_STIF	=	0x00c7
                    00C5    450 _IRCON_P0IF	=	0x00c5
                    00C4    451 _IRCON_T4IF	=	0x00c4
                    00C3    452 _IRCON_T3IF	=	0x00c3
                    00C2    453 _IRCON_T2IF	=	0x00c2
                    00C1    454 _IRCON_T1IF	=	0x00c1
                    00C0    455 _IRCON_DMAIF	=	0x00c0
                    00D0    456 _P	=	0x00d0
                    00D1    457 _F1	=	0x00d1
                    00D2    458 _OV	=	0x00d2
                    00D3    459 _RS0	=	0x00d3
                    00D4    460 _RS1	=	0x00d4
                    00D5    461 _F0	=	0x00d5
                    00D6    462 _AC	=	0x00d6
                    00D7    463 _CY	=	0x00d7
                    00EC    464 _IRCON2_WDTIF	=	0x00ec
                    00EB    465 _IRCON2_P1IF	=	0x00eb
                    00EA    466 _IRCON2_UTX1IF	=	0x00ea
                    00E9    467 _IRCON2_UTX0IF	=	0x00e9
                    00E8    468 _IRCON2_P2IF	=	0x00e8
                            469 ;--------------------------------------------------------
                            470 ; overlayable register banks
                            471 ;--------------------------------------------------------
                            472 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     473 	.ds 8
                            474 ;--------------------------------------------------------
                            475 ; internal ram data
                            476 ;--------------------------------------------------------
                            477 	.area DSEG    (DATA)
                            478 ;--------------------------------------------------------
                            479 ; overlayable items in internal ram 
                            480 ;--------------------------------------------------------
                            481 	.area OSEG    (OVR,DATA)
                            482 ;--------------------------------------------------------
                            483 ; indirectly addressable internal ram data
                            484 ;--------------------------------------------------------
                            485 	.area ISEG    (DATA)
                            486 ;--------------------------------------------------------
                            487 ; bit data
                            488 ;--------------------------------------------------------
                            489 	.area BSEG    (BIT)
                            490 ;--------------------------------------------------------
                            491 ; paged external ram data
                            492 ;--------------------------------------------------------
                            493 	.area PSEG    (PAG,XDATA)
                            494 ;--------------------------------------------------------
                            495 ; external ram data
                            496 ;--------------------------------------------------------
                            497 	.area XSEG    (XDATA)
                    DF02    498 _MDMCTRL0H	=	0xdf02
                    DF03    499 _MDMCTRL0L	=	0xdf03
                    DF04    500 _MDMCTRL1H	=	0xdf04
                    DF05    501 _MDMCTRL1L	=	0xdf05
                    DF06    502 _RSSIH	=	0xdf06
                    DF07    503 _RSSIL	=	0xdf07
                    DF08    504 _SYNCWORDH	=	0xdf08
                    DF09    505 _SYNCWORDL	=	0xdf09
                    DF0A    506 _TXCTRLH	=	0xdf0a
                    DF0B    507 _TXCTRLL	=	0xdf0b
                    DF0C    508 _RXCTRL0H	=	0xdf0c
                    DF0D    509 _RXCTRL0L	=	0xdf0d
                    DF0E    510 _RXCTRL1H	=	0xdf0e
                    DF0F    511 _RXCTRL1L	=	0xdf0f
                    DF10    512 _FSCTRLH	=	0xdf10
                    DF11    513 _FSCTRLL	=	0xdf11
                    DF12    514 _CSPX	=	0xdf12
                    DF13    515 _CSPY	=	0xdf13
                    DF14    516 _CSPZ	=	0xdf14
                    DF15    517 _CSPCTRL	=	0xdf15
                    DF16    518 _CSPT	=	0xdf16
                    DF17    519 _RFPWR	=	0xdf17
                    DF20    520 _FSMTCH	=	0xdf20
                    DF21    521 _FSMTCL	=	0xdf21
                    DF22    522 _MANANDH	=	0xdf22
                    DF23    523 _MANANDL	=	0xdf23
                    DF24    524 _MANORH	=	0xdf24
                    DF25    525 _MANORL	=	0xdf25
                    DF26    526 _AGCCTRLH	=	0xdf26
                    DF27    527 _AGCCTRLL	=	0xdf27
                    DF39    528 _FSMSTATE	=	0xdf39
                    DF3A    529 _ADCTSTH	=	0xdf3a
                    DF3B    530 _ADCTSTL	=	0xdf3b
                    DF3C    531 _DACTSTH	=	0xdf3c
                    DF3D    532 _DACTSTL	=	0xdf3d
                    DF43    533 _IEEE_ADDR0	=	0xdf43
                    DF44    534 _IEEE_ADDR1	=	0xdf44
                    DF45    535 _IEEE_ADDR2	=	0xdf45
                    DF46    536 _IEEE_ADDR3	=	0xdf46
                    DF47    537 _IEEE_ADDR4	=	0xdf47
                    DF48    538 _IEEE_ADDR5	=	0xdf48
                    DF49    539 _IEEE_ADDR6	=	0xdf49
                    DF4A    540 _IEEE_ADDR7	=	0xdf4a
                    DF4B    541 _PANIDH	=	0xdf4b
                    DF4C    542 _PANIDL	=	0xdf4c
                    DF4D    543 _SHORTADDRH	=	0xdf4d
                    DF4E    544 _SHORTADDRL	=	0xdf4e
                    DF4F    545 _IOCFG0	=	0xdf4f
                    DF50    546 _IOCFG1	=	0xdf50
                    DF51    547 _IOCFG2	=	0xdf51
                    DF52    548 _IOCFG3	=	0xdf52
                    DF53    549 _RXFIFOCNT	=	0xdf53
                    DF54    550 _FSMTC1	=	0xdf54
                    DF60    551 _CHVER	=	0xdf60
                    DF61    552 _CHIPID	=	0xdf61
                    DF62    553 _RFSTATUS	=	0xdf62
                    DFD9    554 _RFD_SHADOW	=	0xdfd9
   E006                     555 _pxReadyTasksLists:
   E006                     556 	.ds 48
   E036                     557 _xDelayedTaskList1:
   E036                     558 	.ds 12
   E042                     559 _xDelayedTaskList2:
   E042                     560 	.ds 12
   E04E                     561 _pxDelayedTaskList:
   E04E                     562 	.ds 3
   E051                     563 _pxOverflowDelayedTaskList:
   E051                     564 	.ds 3
   E054                     565 _xPendingReadyList:
   E054                     566 	.ds 12
   E060                     567 _xTasksWaitingTermination:
   E060                     568 	.ds 12
   E06C                     569 _xTaskCreate_uxTaskNumber_1_1:
   E06C                     570 	.ds 1
                            571 ;--------------------------------------------------------
                            572 ; external initialized ram data
                            573 ;--------------------------------------------------------
                            574 	.area XISEG   (XDATA)
   F075                     575 _pxCurrentTCB::
   F075                     576 	.ds 3
   F078                     577 _uxTasksDeleted:
   F078                     578 	.ds 1
   F079                     579 _uxCurrentNumberOfTasks:
   F079                     580 	.ds 1
   F07A                     581 _xTickCount:
   F07A                     582 	.ds 2
   F07C                     583 _uxTopUsedPriority:
   F07C                     584 	.ds 1
   F07D                     585 _uxTopReadyPriority:
   F07D                     586 	.ds 1
   F07E                     587 _xSchedulerRunning:
   F07E                     588 	.ds 1
   F07F                     589 _uxSchedulerSuspended:
   F07F                     590 	.ds 1
   F080                     591 _uxMissedTicks:
   F080                     592 	.ds 1
   F081                     593 _xMissedYield:
   F081                     594 	.ds 1
   F082                     595 _xNumOfOverflows:
   F082                     596 	.ds 1
                            597 	.area HOME    (CODE)
                            598 	.area GSINIT0 (CODE)
                            599 	.area GSINIT1 (CODE)
                            600 	.area GSINIT2 (CODE)
                            601 	.area GSINIT3 (CODE)
                            602 	.area GSINIT4 (CODE)
                            603 	.area GSINIT5 (CODE)
                            604 	.area GSINIT  (CODE)
                            605 	.area GSFINAL (CODE)
                            606 	.area CSEG    (CODE)
                            607 ;--------------------------------------------------------
                            608 ; global & static initialisations
                            609 ;--------------------------------------------------------
                            610 	.area HOME    (CODE)
                            611 	.area GSINIT  (CODE)
                            612 	.area GSFINAL (CODE)
                            613 	.area GSINIT  (CODE)
                            614 ;------------------------------------------------------------
                            615 ;Allocation info for local variables in function 'xTaskCreate'
                            616 ;------------------------------------------------------------
                            617 ;pcName                    Allocated to stack - offset -5
                            618 ;usStackDepth              Allocated to stack - offset -7
                            619 ;pvParameters              Allocated to stack - offset -10
                            620 ;uxPriority                Allocated to stack - offset -11
                            621 ;pxCreatedTask             Allocated to stack - offset -14
                            622 ;pvTaskCode                Allocated to stack - offset 1
                            623 ;xReturn                   Allocated to registers r2 
                            624 ;pxNewTCB                  Allocated to stack - offset 3
                            625 ;pxTopOfStack              Allocated to registers r7 r2 r3 
                            626 ;uxTaskNumber              Allocated with name '_xTaskCreate_uxTaskNumber_1_1'
                            627 ;------------------------------------------------------------
                            628 ;	../../FreeRTOS/Source/tasks.c:494: static unsigned portBASE_TYPE uxTaskNumber = 0; /*lint !e956 Static is deliberate - this is guarded before use. */
                            629 ;	genAssign
   00DF 90 E0 6C            630 	mov	dptr,#_xTaskCreate_uxTaskNumber_1_1
                            631 ;	Peephole 181	changed mov to clr
   00E2 E4                  632 	clr	a
   00E3 F0                  633 	movx	@dptr,a
                            634 ;--------------------------------------------------------
                            635 ; Home
                            636 ;--------------------------------------------------------
                            637 	.area HOME    (CODE)
                            638 	.area CSEG    (CODE)
                            639 ;--------------------------------------------------------
                            640 ; code
                            641 ;--------------------------------------------------------
                            642 	.area CSEG    (CODE)
                            643 ;------------------------------------------------------------
                            644 ;Allocation info for local variables in function 'xTaskCreate'
                            645 ;------------------------------------------------------------
                            646 ;pcName                    Allocated to stack - offset -5
                            647 ;usStackDepth              Allocated to stack - offset -7
                            648 ;pvParameters              Allocated to stack - offset -10
                            649 ;uxPriority                Allocated to stack - offset -11
                            650 ;pxCreatedTask             Allocated to stack - offset -14
                            651 ;pvTaskCode                Allocated to stack - offset 1
                            652 ;xReturn                   Allocated to registers r2 
                            653 ;pxNewTCB                  Allocated to stack - offset 3
                            654 ;pxTopOfStack              Allocated to registers r7 r2 r3 
                            655 ;uxTaskNumber              Allocated with name '_xTaskCreate_uxTaskNumber_1_1'
                            656 ;------------------------------------------------------------
                            657 ;	../../FreeRTOS/Source/tasks.c:490: signed portBASE_TYPE xTaskCreate( pdTASK_CODE pvTaskCode, const signed portCHAR * const pcName, unsigned portSHORT usStackDepth, void *pvParameters, unsigned portBASE_TYPE uxPriority, xTaskHandle *pxCreatedTask )
                            658 ;	-----------------------------------------
                            659 ;	 function xTaskCreate
                            660 ;	-----------------------------------------
   07F1                     661 _xTaskCreate:
                    0002    662 	ar2 = 0x02
                    0003    663 	ar3 = 0x03
                    0004    664 	ar4 = 0x04
                    0005    665 	ar5 = 0x05
                    0006    666 	ar6 = 0x06
                    0007    667 	ar7 = 0x07
                    0000    668 	ar0 = 0x00
                    0001    669 	ar1 = 0x01
   07F1 C0 10               670 	push	_bp
   07F3 85 81 10            671 	mov	_bp,sp
                            672 ;     genReceive
   07F6 C0 82               673 	push	dpl
   07F8 C0 83               674 	push	dph
   07FA 05 81               675 	inc	sp
   07FC 05 81               676 	inc	sp
   07FE 05 81               677 	inc	sp
                            678 ;	../../FreeRTOS/Source/tasks.c:498: pxNewTCB = prvAllocateTCBAndStack( usStackDepth );
                            679 ;	genCall
   0800 E5 10               680 	mov	a,_bp
   0802 24 F9               681 	add	a,#0xfffffff9
   0804 F8                  682 	mov	r0,a
   0805 86 82               683 	mov	dpl,@r0
   0807 08                  684 	inc	r0
   0808 86 83               685 	mov	dph,@r0
   080A 12 1A 06            686 	lcall	_prvAllocateTCBAndStack
   080D AC 82               687 	mov	r4,dpl
   080F AD 83               688 	mov	r5,dph
   0811 AE F0               689 	mov	r6,b
                            690 ;	genAssign
   0813 A8 10               691 	mov	r0,_bp
   0815 08                  692 	inc	r0
   0816 08                  693 	inc	r0
   0817 08                  694 	inc	r0
   0818 A6 04               695 	mov	@r0,ar4
   081A 08                  696 	inc	r0
   081B A6 05               697 	mov	@r0,ar5
   081D 08                  698 	inc	r0
   081E A6 06               699 	mov	@r0,ar6
                            700 ;	../../FreeRTOS/Source/tasks.c:500: if( pxNewTCB != NULL )
                            701 ;	genCmpEq
   0820 A8 10               702 	mov	r0,_bp
   0822 08                  703 	inc	r0
   0823 08                  704 	inc	r0
   0824 08                  705 	inc	r0
                            706 ;	gencjneshort
   0825 B6 00 0B            707 	cjne	@r0,#0x00,00135$
   0828 08                  708 	inc	r0
   0829 B6 00 07            709 	cjne	@r0,#0x00,00135$
   082C 08                  710 	inc	r0
   082D B6 00 03            711 	cjne	@r0,#0x00,00135$
   0830 02 09 E3            712 	ljmp	00113$
   0833                     713 00135$:
                            714 ;	../../FreeRTOS/Source/tasks.c:505: prvInitialiseTCBVariables( pxNewTCB, usStackDepth, pcName, uxPriority );
                            715 ;	genIpush
   0833 E5 10               716 	mov	a,_bp
   0835 24 F5               717 	add	a,#0xfffffff5
   0837 F8                  718 	mov	r0,a
   0838 E6                  719 	mov	a,@r0
   0839 C0 E0               720 	push	acc
                            721 ;	genIpush
   083B E5 10               722 	mov	a,_bp
   083D 24 FB               723 	add	a,#0xfffffffb
   083F F8                  724 	mov	r0,a
   0840 E6                  725 	mov	a,@r0
   0841 C0 E0               726 	push	acc
   0843 08                  727 	inc	r0
   0844 E6                  728 	mov	a,@r0
   0845 C0 E0               729 	push	acc
   0847 08                  730 	inc	r0
   0848 E6                  731 	mov	a,@r0
   0849 C0 E0               732 	push	acc
                            733 ;	genIpush
   084B E5 10               734 	mov	a,_bp
   084D 24 F9               735 	add	a,#0xfffffff9
   084F F8                  736 	mov	r0,a
   0850 E6                  737 	mov	a,@r0
   0851 C0 E0               738 	push	acc
   0853 08                  739 	inc	r0
   0854 E6                  740 	mov	a,@r0
   0855 C0 E0               741 	push	acc
                            742 ;	genCall
   0857 A8 10               743 	mov	r0,_bp
   0859 08                  744 	inc	r0
   085A 08                  745 	inc	r0
   085B 08                  746 	inc	r0
   085C 86 82               747 	mov	dpl,@r0
   085E 08                  748 	inc	r0
   085F 86 83               749 	mov	dph,@r0
   0861 08                  750 	inc	r0
   0862 86 F0               751 	mov	b,@r0
   0864 12 17 7E            752 	lcall	_prvInitialiseTCBVariables
   0867 E5 81               753 	mov	a,sp
   0869 24 FA               754 	add	a,#0xfa
   086B F5 81               755 	mov	sp,a
                            756 ;	../../FreeRTOS/Source/tasks.c:517: pxTopOfStack = pxNewTCB->pxStack;	
                            757 ;	genPlus
   086D A8 10               758 	mov	r0,_bp
   086F 08                  759 	inc	r0
   0870 08                  760 	inc	r0
   0871 08                  761 	inc	r0
                            762 ;     genPlusIncr
   0872 74 20               763 	mov	a,#0x20
   0874 26                  764 	add	a,@r0
   0875 FF                  765 	mov	r7,a
                            766 ;	Peephole 181	changed mov to clr
   0876 E4                  767 	clr	a
   0877 08                  768 	inc	r0
   0878 36                  769 	addc	a,@r0
   0879 FA                  770 	mov	r2,a
   087A 08                  771 	inc	r0
   087B 86 03               772 	mov	ar3,@r0
                            773 ;	genPointerGet
                            774 ;	genGenPointerGet
   087D 8F 82               775 	mov	dpl,r7
   087F 8A 83               776 	mov	dph,r2
   0881 8B F0               777 	mov	b,r3
   0883 12 E4 9F            778 	lcall	__gptrget
   0886 FF                  779 	mov	r7,a
   0887 A3                  780 	inc	dptr
   0888 12 E4 9F            781 	lcall	__gptrget
   088B FA                  782 	mov	r2,a
   088C A3                  783 	inc	dptr
   088D 12 E4 9F            784 	lcall	__gptrget
   0890 FB                  785 	mov	r3,a
                            786 ;	genAssign
                            787 ;	../../FreeRTOS/Source/tasks.c:525: pxNewTCB->pxTopOfStack = pxPortInitialiseStack( pxTopOfStack, pvTaskCode, pvParameters );
                            788 ;	genIpush
   0891 E5 10               789 	mov	a,_bp
   0893 24 F6               790 	add	a,#0xfffffff6
   0895 F8                  791 	mov	r0,a
   0896 E6                  792 	mov	a,@r0
   0897 C0 E0               793 	push	acc
   0899 08                  794 	inc	r0
   089A E6                  795 	mov	a,@r0
   089B C0 E0               796 	push	acc
   089D 08                  797 	inc	r0
   089E E6                  798 	mov	a,@r0
   089F C0 E0               799 	push	acc
                            800 ;	genIpush
   08A1 A8 10               801 	mov	r0,_bp
   08A3 08                  802 	inc	r0
   08A4 E6                  803 	mov	a,@r0
   08A5 C0 E0               804 	push	acc
   08A7 08                  805 	inc	r0
   08A8 E6                  806 	mov	a,@r0
   08A9 C0 E0               807 	push	acc
                            808 ;	genCall
   08AB 8F 82               809 	mov	dpl,r7
   08AD 8A 83               810 	mov	dph,r2
   08AF 8B F0               811 	mov	b,r3
   08B1 12 31 49            812 	lcall	_pxPortInitialiseStack
   08B4 AA 82               813 	mov	r2,dpl
   08B6 AB 83               814 	mov	r3,dph
   08B8 AF F0               815 	mov	r7,b
   08BA E5 81               816 	mov	a,sp
   08BC 24 FB               817 	add	a,#0xfb
   08BE F5 81               818 	mov	sp,a
                            819 ;	genPointerSet
                            820 ;	genGenPointerSet
   08C0 A8 10               821 	mov	r0,_bp
   08C2 08                  822 	inc	r0
   08C3 08                  823 	inc	r0
   08C4 08                  824 	inc	r0
   08C5 86 82               825 	mov	dpl,@r0
   08C7 08                  826 	inc	r0
   08C8 86 83               827 	mov	dph,@r0
   08CA 08                  828 	inc	r0
   08CB 86 F0               829 	mov	b,@r0
   08CD EA                  830 	mov	a,r2
   08CE 12 DF B7            831 	lcall	__gptrput
   08D1 A3                  832 	inc	dptr
   08D2 EB                  833 	mov	a,r3
   08D3 12 DF B7            834 	lcall	__gptrput
   08D6 A3                  835 	inc	dptr
   08D7 EF                  836 	mov	a,r7
   08D8 12 DF B7            837 	lcall	__gptrput
                            838 ;	../../FreeRTOS/Source/tasks.c:529: portENTER_CRITICAL();
                            839 ;	genInline
   08DB C0 E0 C0 A8         840 	 push ACC push IE 
                            841 ;	genAssign
   08DF C2 AF               842 	clr	_EA
                            843 ;	../../FreeRTOS/Source/tasks.c:531: uxCurrentNumberOfTasks++;
                            844 ;	genPlus
   08E1 90 F0 79            845 	mov	dptr,#_uxCurrentNumberOfTasks
   08E4 E0                  846 	movx	a,@dptr
   08E5 24 01               847 	add	a,#0x01
   08E7 F0                  848 	movx	@dptr,a
                            849 ;	../../FreeRTOS/Source/tasks.c:532: if( uxCurrentNumberOfTasks == ( unsigned portBASE_TYPE ) 1 )
                            850 ;	genAssign
   08E8 90 F0 79            851 	mov	dptr,#_uxCurrentNumberOfTasks
   08EB E0                  852 	movx	a,@dptr
   08EC FA                  853 	mov	r2,a
                            854 ;	genCmpEq
                            855 ;	gencjneshort
                            856 ;	Peephole 112.b	changed ljmp to sjmp
                            857 ;	Peephole 198.b	optimized misc jump sequence
   08ED BA 01 17            858 	cjne	r2,#0x01,00106$
                            859 ;	Peephole 200.b	removed redundant sjmp
                            860 ;	Peephole 300	removed redundant label 00136$
                            861 ;	Peephole 300	removed redundant label 00137$
                            862 ;	../../FreeRTOS/Source/tasks.c:535: pxCurrentTCB =  pxNewTCB;
                            863 ;	genAssign
   08F0 A8 10               864 	mov	r0,_bp
   08F2 08                  865 	inc	r0
   08F3 08                  866 	inc	r0
   08F4 08                  867 	inc	r0
   08F5 90 F0 75            868 	mov	dptr,#_pxCurrentTCB
   08F8 E6                  869 	mov	a,@r0
   08F9 F0                  870 	movx	@dptr,a
   08FA 08                  871 	inc	r0
   08FB A3                  872 	inc	dptr
   08FC E6                  873 	mov	a,@r0
   08FD F0                  874 	movx	@dptr,a
   08FE 08                  875 	inc	r0
   08FF A3                  876 	inc	dptr
   0900 E6                  877 	mov	a,@r0
   0901 F0                  878 	movx	@dptr,a
                            879 ;	../../FreeRTOS/Source/tasks.c:540: prvInitialiseTaskLists();
                            880 ;	genCall
   0902 12 18 EB            881 	lcall	_prvInitialiseTaskLists
                            882 ;	Peephole 112.b	changed ljmp to sjmp
   0905 80 3F               883 	sjmp	00107$
   0907                     884 00106$:
                            885 ;	../../FreeRTOS/Source/tasks.c:547: if( xSchedulerRunning == pdFALSE )
                            886 ;	genAssign
   0907 90 F0 7E            887 	mov	dptr,#_xSchedulerRunning
   090A E0                  888 	movx	a,@dptr
                            889 ;	genIfx
   090B FA                  890 	mov	r2,a
                            891 ;	Peephole 105	removed redundant mov
                            892 ;	genIfxJump
                            893 ;	Peephole 108.b	removed ljmp by inverse jump logic
   090C 70 38               894 	jnz	00107$
                            895 ;	Peephole 300	removed redundant label 00138$
                            896 ;	../../FreeRTOS/Source/tasks.c:549: if( pxCurrentTCB->uxPriority <= uxPriority )
                            897 ;	genAssign
   090E 90 F0 75            898 	mov	dptr,#_pxCurrentTCB
   0911 E0                  899 	movx	a,@dptr
   0912 FA                  900 	mov	r2,a
   0913 A3                  901 	inc	dptr
   0914 E0                  902 	movx	a,@dptr
   0915 FB                  903 	mov	r3,a
   0916 A3                  904 	inc	dptr
   0917 E0                  905 	movx	a,@dptr
   0918 FF                  906 	mov	r7,a
                            907 ;	genPlus
                            908 ;     genPlusIncr
   0919 74 1F               909 	mov	a,#0x1F
                            910 ;	Peephole 236.a	used r2 instead of ar2
   091B 2A                  911 	add	a,r2
   091C FA                  912 	mov	r2,a
                            913 ;	Peephole 181	changed mov to clr
   091D E4                  914 	clr	a
                            915 ;	Peephole 236.b	used r3 instead of ar3
   091E 3B                  916 	addc	a,r3
   091F FB                  917 	mov	r3,a
                            918 ;	genPointerGet
                            919 ;	genGenPointerGet
   0920 8A 82               920 	mov	dpl,r2
   0922 8B 83               921 	mov	dph,r3
   0924 8F F0               922 	mov	b,r7
   0926 12 E4 9F            923 	lcall	__gptrget
   0929 FA                  924 	mov	r2,a
                            925 ;	genCmpGt
   092A E5 10               926 	mov	a,_bp
   092C 24 F5               927 	add	a,#0xfffffff5
   092E F8                  928 	mov	r0,a
                            929 ;	genCmp
   092F C3                  930 	clr	c
   0930 E6                  931 	mov	a,@r0
   0931 9A                  932 	subb	a,r2
                            933 ;	genIfxJump
                            934 ;	Peephole 112.b	changed ljmp to sjmp
                            935 ;	Peephole 160.a	removed sjmp by inverse jump logic
   0932 40 12               936 	jc	00107$
                            937 ;	Peephole 300	removed redundant label 00139$
                            938 ;	../../FreeRTOS/Source/tasks.c:551: pxCurrentTCB = pxNewTCB;	
                            939 ;	genAssign
   0934 A8 10               940 	mov	r0,_bp
   0936 08                  941 	inc	r0
   0937 08                  942 	inc	r0
   0938 08                  943 	inc	r0
   0939 90 F0 75            944 	mov	dptr,#_pxCurrentTCB
   093C E6                  945 	mov	a,@r0
   093D F0                  946 	movx	@dptr,a
   093E 08                  947 	inc	r0
   093F A3                  948 	inc	dptr
   0940 E6                  949 	mov	a,@r0
   0941 F0                  950 	movx	@dptr,a
   0942 08                  951 	inc	r0
   0943 A3                  952 	inc	dptr
   0944 E6                  953 	mov	a,@r0
   0945 F0                  954 	movx	@dptr,a
   0946                     955 00107$:
                            956 ;	../../FreeRTOS/Source/tasks.c:558: if( pxNewTCB->uxPriority > uxTopUsedPriority )
                            957 ;	genPlus
   0946 A8 10               958 	mov	r0,_bp
   0948 08                  959 	inc	r0
   0949 08                  960 	inc	r0
   094A 08                  961 	inc	r0
                            962 ;     genPlusIncr
   094B 74 1F               963 	mov	a,#0x1F
   094D 26                  964 	add	a,@r0
   094E FA                  965 	mov	r2,a
                            966 ;	Peephole 181	changed mov to clr
   094F E4                  967 	clr	a
   0950 08                  968 	inc	r0
   0951 36                  969 	addc	a,@r0
   0952 FB                  970 	mov	r3,a
   0953 08                  971 	inc	r0
   0954 86 07               972 	mov	ar7,@r0
                            973 ;	genPointerGet
                            974 ;	genGenPointerGet
   0956 8A 82               975 	mov	dpl,r2
   0958 8B 83               976 	mov	dph,r3
   095A 8F F0               977 	mov	b,r7
   095C 12 E4 9F            978 	lcall	__gptrget
   095F FA                  979 	mov	r2,a
                            980 ;	genAssign
   0960 90 F0 7C            981 	mov	dptr,#_uxTopUsedPriority
   0963 E0                  982 	movx	a,@dptr
                            983 ;	genCmpGt
                            984 ;	genCmp
   0964 FB                  985 	mov	r3,a
   0965 C3                  986 	clr	c
                            987 ;	Peephole 106	removed redundant mov
   0966 9A                  988 	subb	a,r2
                            989 ;	genIfxJump
                            990 ;	Peephole 108.a	removed ljmp by inverse jump logic
   0967 50 05               991 	jnc	00109$
                            992 ;	Peephole 300	removed redundant label 00140$
                            993 ;	../../FreeRTOS/Source/tasks.c:560: uxTopUsedPriority = pxNewTCB->uxPriority;
                            994 ;	genAssign
   0969 90 F0 7C            995 	mov	dptr,#_uxTopUsedPriority
   096C EA                  996 	mov	a,r2
   096D F0                  997 	movx	@dptr,a
   096E                     998 00109$:
                            999 ;	../../FreeRTOS/Source/tasks.c:564: pxNewTCB->uxTCBNumber = uxTaskNumber;
                           1000 ;	genPlus
   096E A8 10              1001 	mov	r0,_bp
   0970 08                 1002 	inc	r0
   0971 08                 1003 	inc	r0
   0972 08                 1004 	inc	r0
                           1005 ;     genPlusIncr
   0973 74 23              1006 	mov	a,#0x23
   0975 26                 1007 	add	a,@r0
   0976 FB                 1008 	mov	r3,a
                           1009 ;	Peephole 181	changed mov to clr
   0977 E4                 1010 	clr	a
   0978 08                 1011 	inc	r0
   0979 36                 1012 	addc	a,@r0
   097A FF                 1013 	mov	r7,a
   097B 08                 1014 	inc	r0
   097C 86 04              1015 	mov	ar4,@r0
                           1016 ;	genAssign
   097E 90 E0 6C           1017 	mov	dptr,#_xTaskCreate_uxTaskNumber_1_1
   0981 E0                 1018 	movx	a,@dptr
                           1019 ;	genPointerSet
                           1020 ;	genGenPointerSet
   0982 FD                 1021 	mov	r5,a
   0983 8B 82              1022 	mov	dpl,r3
   0985 8F 83              1023 	mov	dph,r7
   0987 8C F0              1024 	mov	b,r4
                           1025 ;	Peephole 191	removed redundant mov
   0989 12 DF B7           1026 	lcall	__gptrput
                           1027 ;	../../FreeRTOS/Source/tasks.c:565: uxTaskNumber++;
                           1028 ;	genPlus
   098C 90 E0 6C           1029 	mov	dptr,#_xTaskCreate_uxTaskNumber_1_1
                           1030 ;     genPlusIncr
   098F 74 01              1031 	mov	a,#0x01
                           1032 ;	Peephole 236.a	used r5 instead of ar5
   0991 2D                 1033 	add	a,r5
   0992 F0                 1034 	movx	@dptr,a
                           1035 ;	../../FreeRTOS/Source/tasks.c:567: prvAddTaskToReadyQueue( pxNewTCB );
                           1036 ;	genAssign
   0993 90 F0 7D           1037 	mov	dptr,#_uxTopReadyPriority
   0996 E0                 1038 	movx	a,@dptr
                           1039 ;	genCmpGt
                           1040 ;	genCmp
   0997 FB                 1041 	mov	r3,a
   0998 C3                 1042 	clr	c
                           1043 ;	Peephole 106	removed redundant mov
   0999 9A                 1044 	subb	a,r2
                           1045 ;	genIfxJump
                           1046 ;	Peephole 108.a	removed ljmp by inverse jump logic
   099A 50 05              1047 	jnc	00111$
                           1048 ;	Peephole 300	removed redundant label 00141$
                           1049 ;	genAssign
   099C 90 F0 7D           1050 	mov	dptr,#_uxTopReadyPriority
   099F EA                 1051 	mov	a,r2
   09A0 F0                 1052 	movx	@dptr,a
   09A1                    1053 00111$:
                           1054 ;	genPlus
   09A1 A8 10              1055 	mov	r0,_bp
   09A3 08                 1056 	inc	r0
   09A4 08                 1057 	inc	r0
   09A5 08                 1058 	inc	r0
                           1059 ;     genPlusIncr
   09A6 74 03              1060 	mov	a,#0x03
   09A8 26                 1061 	add	a,@r0
   09A9 FB                 1062 	mov	r3,a
                           1063 ;	Peephole 181	changed mov to clr
   09AA E4                 1064 	clr	a
   09AB 08                 1065 	inc	r0
   09AC 36                 1066 	addc	a,@r0
   09AD FC                 1067 	mov	r4,a
   09AE 08                 1068 	inc	r0
   09AF 86 05              1069 	mov	ar5,@r0
                           1070 ;	genMult
                           1071 ;	genMultOneByte
   09B1 EA                 1072 	mov	a,r2
   09B2 75 F0 0C           1073 	mov	b,#0x0C
   09B5 A4                 1074 	mul	ab
                           1075 ;	genPlus
   09B6 24 06              1076 	add	a,#_pxReadyTasksLists
   09B8 FA                 1077 	mov	r2,a
                           1078 ;	Peephole 240	use clr instead of addc a,#0
   09B9 E4                 1079 	clr	a
   09BA 34 E0              1080 	addc	a,#(_pxReadyTasksLists >> 8)
   09BC FE                 1081 	mov	r6,a
                           1082 ;	genCast
   09BD 7F 00              1083 	mov	r7,#0x0
                           1084 ;	genIpush
   09BF C0 03              1085 	push	ar3
   09C1 C0 04              1086 	push	ar4
   09C3 C0 05              1087 	push	ar5
                           1088 ;	genCall
   09C5 8A 82              1089 	mov	dpl,r2
   09C7 8E 83              1090 	mov	dph,r6
   09C9 8F F0              1091 	mov	b,r7
   09CB 12 2B 96           1092 	lcall	_vListInsertEnd
   09CE 15 81              1093 	dec	sp
   09D0 15 81              1094 	dec	sp
   09D2 15 81              1095 	dec	sp
                           1096 ;	../../FreeRTOS/Source/tasks.c:569: xReturn = pdPASS;
                           1097 ;	genAssign
   09D4 7A 01              1098 	mov	r2,#0x01
                           1099 ;	../../FreeRTOS/Source/tasks.c:571: portEXIT_CRITICAL();
                           1100 ;	genInline
   09D6 D0 E0              1101 	 pop ACC 
                           1102 ;	genAnd
   09D8 53 E0 80           1103 	anl	_ACC,#0x80
                           1104 ;	genOr
   09DB E5 E0              1105 	mov	a,_ACC
   09DD 42 A8              1106 	orl	_IE,a
                           1107 ;	genInline
   09DF D0 E0              1108 	 pop ACC 
                           1109 ;	Peephole 112.b	changed ljmp to sjmp
   09E1 80 02              1110 	sjmp	00114$
   09E3                    1111 00113$:
                           1112 ;	../../FreeRTOS/Source/tasks.c:575: xReturn = errCOULD_NOT_ALLOCATE_REQUIRED_MEMORY;
                           1113 ;	genAssign
   09E3 7A FF              1114 	mov	r2,#0xFF
   09E5                    1115 00114$:
                           1116 ;	../../FreeRTOS/Source/tasks.c:578: if( xReturn == pdPASS )
                           1117 ;	genCmpEq
                           1118 ;	gencjneshort
                           1119 ;	Peephole 112.b	changed ljmp to sjmp
                           1120 ;	Peephole 198.b	optimized misc jump sequence
   09E5 BA 01 63           1121 	cjne	r2,#0x01,00122$
                           1122 ;	Peephole 200.b	removed redundant sjmp
                           1123 ;	Peephole 300	removed redundant label 00142$
                           1124 ;	Peephole 300	removed redundant label 00143$
                           1125 ;	../../FreeRTOS/Source/tasks.c:580: if( ( void * ) pxCreatedTask != NULL )
                           1126 ;	genAssign
   09E8 E5 10              1127 	mov	a,_bp
   09EA 24 F2              1128 	add	a,#0xfffffff2
   09EC F8                 1129 	mov	r0,a
   09ED 86 03              1130 	mov	ar3,@r0
   09EF 08                 1131 	inc	r0
   09F0 86 04              1132 	mov	ar4,@r0
   09F2 08                 1133 	inc	r0
   09F3 86 05              1134 	mov	ar5,@r0
                           1135 ;	genCmpEq
                           1136 ;	gencjneshort
   09F5 BB 00 08           1137 	cjne	r3,#0x00,00144$
   09F8 BC 00 05           1138 	cjne	r4,#0x00,00144$
   09FB BD 00 02           1139 	cjne	r5,#0x00,00144$
                           1140 ;	Peephole 112.b	changed ljmp to sjmp
   09FE 80 1B              1141 	sjmp	00116$
   0A00                    1142 00144$:
                           1143 ;	../../FreeRTOS/Source/tasks.c:585: *pxCreatedTask = ( xTaskHandle ) pxNewTCB;
                           1144 ;	genPointerSet
                           1145 ;	genGenPointerSet
   0A00 8B 82              1146 	mov	dpl,r3
   0A02 8C 83              1147 	mov	dph,r4
   0A04 8D F0              1148 	mov	b,r5
   0A06 A8 10              1149 	mov	r0,_bp
   0A08 08                 1150 	inc	r0
   0A09 08                 1151 	inc	r0
   0A0A 08                 1152 	inc	r0
   0A0B E6                 1153 	mov	a,@r0
   0A0C 12 DF B7           1154 	lcall	__gptrput
   0A0F A3                 1155 	inc	dptr
   0A10 08                 1156 	inc	r0
   0A11 E6                 1157 	mov	a,@r0
   0A12 12 DF B7           1158 	lcall	__gptrput
   0A15 A3                 1159 	inc	dptr
   0A16 08                 1160 	inc	r0
   0A17 E6                 1161 	mov	a,@r0
   0A18 12 DF B7           1162 	lcall	__gptrput
   0A1B                    1163 00116$:
                           1164 ;	../../FreeRTOS/Source/tasks.c:588: if( xSchedulerRunning != pdFALSE )
                           1165 ;	genAssign
   0A1B 90 F0 7E           1166 	mov	dptr,#_xSchedulerRunning
   0A1E E0                 1167 	movx	a,@dptr
                           1168 ;	genCmpEq
                           1169 ;	gencjneshort
                           1170 ;	Peephole 112.b	changed ljmp to sjmp
   0A1F FB                 1171 	mov	r3,a
                           1172 ;	Peephole 115.b	jump optimization
   0A20 60 29              1173 	jz	00122$
                           1174 ;	Peephole 300	removed redundant label 00145$
                           1175 ;	../../FreeRTOS/Source/tasks.c:592: if( pxCurrentTCB->uxPriority < uxPriority )
                           1176 ;	genAssign
   0A22 90 F0 75           1177 	mov	dptr,#_pxCurrentTCB
   0A25 E0                 1178 	movx	a,@dptr
   0A26 FB                 1179 	mov	r3,a
   0A27 A3                 1180 	inc	dptr
   0A28 E0                 1181 	movx	a,@dptr
   0A29 FC                 1182 	mov	r4,a
   0A2A A3                 1183 	inc	dptr
   0A2B E0                 1184 	movx	a,@dptr
   0A2C FD                 1185 	mov	r5,a
                           1186 ;	genPlus
                           1187 ;     genPlusIncr
   0A2D 74 1F              1188 	mov	a,#0x1F
                           1189 ;	Peephole 236.a	used r3 instead of ar3
   0A2F 2B                 1190 	add	a,r3
   0A30 FB                 1191 	mov	r3,a
                           1192 ;	Peephole 181	changed mov to clr
   0A31 E4                 1193 	clr	a
                           1194 ;	Peephole 236.b	used r4 instead of ar4
   0A32 3C                 1195 	addc	a,r4
   0A33 FC                 1196 	mov	r4,a
                           1197 ;	genPointerGet
                           1198 ;	genGenPointerGet
   0A34 8B 82              1199 	mov	dpl,r3
   0A36 8C 83              1200 	mov	dph,r4
   0A38 8D F0              1201 	mov	b,r5
   0A3A 12 E4 9F           1202 	lcall	__gptrget
   0A3D FB                 1203 	mov	r3,a
                           1204 ;	genCmpLt
   0A3E E5 10              1205 	mov	a,_bp
   0A40 24 F5              1206 	add	a,#0xfffffff5
   0A42 F8                 1207 	mov	r0,a
                           1208 ;	genCmp
   0A43 C3                 1209 	clr	c
   0A44 EB                 1210 	mov	a,r3
   0A45 96                 1211 	subb	a,@r0
                           1212 ;	genIfxJump
                           1213 ;	Peephole 108.a	removed ljmp by inverse jump logic
   0A46 50 03              1214 	jnc	00122$
                           1215 ;	Peephole 300	removed redundant label 00146$
                           1216 ;	../../FreeRTOS/Source/tasks.c:594: taskYIELD();
                           1217 ;	genCall
   0A48 12 33 E8           1218 	lcall	_vPortYield
   0A4B                    1219 00122$:
                           1220 ;	../../FreeRTOS/Source/tasks.c:599: return xReturn;
                           1221 ;	genRet
   0A4B 8A 82              1222 	mov	dpl,r2
                           1223 ;	Peephole 300	removed redundant label 00123$
   0A4D 85 10 81           1224 	mov	sp,_bp
   0A50 D0 10              1225 	pop	_bp
   0A52 22                 1226 	ret
                           1227 ;------------------------------------------------------------
                           1228 ;Allocation info for local variables in function 'vTaskDelete'
                           1229 ;------------------------------------------------------------
                           1230 ;pxTaskToDelete            Allocated to registers r2 r3 r4 
                           1231 ;pxTCB                     Allocated to stack - offset 1
                           1232 ;sloc0                     Allocated to stack - offset 4
                           1233 ;------------------------------------------------------------
                           1234 ;	../../FreeRTOS/Source/tasks.c:605: void vTaskDelete( xTaskHandle pxTaskToDelete )
                           1235 ;	-----------------------------------------
                           1236 ;	 function vTaskDelete
                           1237 ;	-----------------------------------------
   0A53                    1238 _vTaskDelete:
   0A53 C0 10              1239 	push	_bp
                           1240 ;	peephole 177.h	optimized mov sequence
   0A55 E5 81              1241 	mov	a,sp
   0A57 F5 10              1242 	mov	_bp,a
   0A59 24 06              1243 	add	a,#0x06
   0A5B F5 81              1244 	mov	sp,a
                           1245 ;	genReceive
   0A5D AA 82              1246 	mov	r2,dpl
   0A5F AB 83              1247 	mov	r3,dph
   0A61 AC F0              1248 	mov	r4,b
                           1249 ;	../../FreeRTOS/Source/tasks.c:609: taskENTER_CRITICAL();
                           1250 ;	genInline
   0A63 C0 E0 C0 A8        1251 	 push ACC push IE 
                           1252 ;	genAssign
   0A67 C2 AF              1253 	clr	_EA
                           1254 ;	../../FreeRTOS/Source/tasks.c:613: if( pxTaskToDelete == pxCurrentTCB )
                           1255 ;	genAssign
   0A69 90 F0 75           1256 	mov	dptr,#_pxCurrentTCB
   0A6C E0                 1257 	movx	a,@dptr
   0A6D FD                 1258 	mov	r5,a
   0A6E A3                 1259 	inc	dptr
   0A6F E0                 1260 	movx	a,@dptr
   0A70 FE                 1261 	mov	r6,a
   0A71 A3                 1262 	inc	dptr
   0A72 E0                 1263 	movx	a,@dptr
   0A73 FF                 1264 	mov	r7,a
                           1265 ;	genCmpEq
                           1266 ;	gencjneshort
   0A74 EA                 1267 	mov	a,r2
                           1268 ;	Peephole 112.b	changed ljmp to sjmp
                           1269 ;	Peephole 195.b	optimized misc jump sequence
   0A75 B5 05 0E           1270 	cjne	a,ar5,00102$
   0A78 EB                 1271 	mov	a,r3
   0A79 B5 06 0A           1272 	cjne	a,ar6,00102$
   0A7C EC                 1273 	mov	a,r4
   0A7D B5 07 06           1274 	cjne	a,ar7,00102$
                           1275 ;	Peephole 200.b	removed redundant sjmp
                           1276 ;	Peephole 300	removed redundant label 00118$
                           1277 ;	Peephole 300	removed redundant label 00119$
                           1278 ;	../../FreeRTOS/Source/tasks.c:615: pxTaskToDelete = NULL;
                           1279 ;	genAssign
   0A80 7A 00              1280 	mov	r2,#0x00
   0A82 7B 00              1281 	mov	r3,#0x00
   0A84 7C 00              1282 	mov	r4,#0x00
   0A86                    1283 00102$:
                           1284 ;	../../FreeRTOS/Source/tasks.c:619: pxTCB = prvGetTCBFromHandle( pxTaskToDelete );
                           1285 ;	genCmpEq
                           1286 ;	gencjne
                           1287 ;	gencjneshort
                           1288 ;	Peephole 241.b	optimized compare
   0A86 E4                 1289 	clr	a
   0A87 BA 00 07           1290 	cjne	r2,#0x00,00120$
   0A8A BB 00 04           1291 	cjne	r3,#0x00,00120$
   0A8D BC 00 01           1292 	cjne	r4,#0x00,00120$
   0A90 04                 1293 	inc	a
   0A91                    1294 00120$:
                           1295 ;	Peephole 300	removed redundant label 00121$
                           1296 ;	genIfx
   0A91 FD                 1297 	mov	r5,a
                           1298 ;	Peephole 105	removed redundant mov
                           1299 ;	genIfxJump
                           1300 ;	Peephole 108.c	removed ljmp by inverse jump logic
   0A92 60 12              1301 	jz	00111$
                           1302 ;	Peephole 300	removed redundant label 00122$
                           1303 ;	genAssign
   0A94 90 F0 75           1304 	mov	dptr,#_pxCurrentTCB
   0A97 A8 10              1305 	mov	r0,_bp
   0A99 08                 1306 	inc	r0
   0A9A E0                 1307 	movx	a,@dptr
   0A9B F6                 1308 	mov	@r0,a
   0A9C A3                 1309 	inc	dptr
   0A9D E0                 1310 	movx	a,@dptr
   0A9E 08                 1311 	inc	r0
   0A9F F6                 1312 	mov	@r0,a
   0AA0 A3                 1313 	inc	dptr
   0AA1 E0                 1314 	movx	a,@dptr
   0AA2 08                 1315 	inc	r0
   0AA3 F6                 1316 	mov	@r0,a
                           1317 ;	Peephole 112.b	changed ljmp to sjmp
   0AA4 80 0B              1318 	sjmp	00112$
   0AA6                    1319 00111$:
                           1320 ;	genAssign
   0AA6 A8 10              1321 	mov	r0,_bp
   0AA8 08                 1322 	inc	r0
   0AA9 A6 02              1323 	mov	@r0,ar2
   0AAB 08                 1324 	inc	r0
   0AAC A6 03              1325 	mov	@r0,ar3
   0AAE 08                 1326 	inc	r0
   0AAF A6 04              1327 	mov	@r0,ar4
   0AB1                    1328 00112$:
                           1329 ;	genIpush
   0AB1 C0 05              1330 	push	ar5
                           1331 ;	genAssign
   0AB3 A8 10              1332 	mov	r0,_bp
   0AB5 08                 1333 	inc	r0
   0AB6 86 02              1334 	mov	ar2,@r0
   0AB8 08                 1335 	inc	r0
   0AB9 86 03              1336 	mov	ar3,@r0
   0ABB 08                 1337 	inc	r0
   0ABC 86 04              1338 	mov	ar4,@r0
                           1339 ;	../../FreeRTOS/Source/tasks.c:625: vListRemove( &( pxTCB->xGenericListItem ) );
                           1340 ;	genPlus
                           1341 ;     genPlusIncr
   0ABE 74 03              1342 	mov	a,#0x03
                           1343 ;	Peephole 236.a	used r2 instead of ar2
   0AC0 2A                 1344 	add	a,r2
   0AC1 FE                 1345 	mov	r6,a
                           1346 ;	Peephole 181	changed mov to clr
   0AC2 E4                 1347 	clr	a
                           1348 ;	Peephole 236.b	used r3 instead of ar3
   0AC3 3B                 1349 	addc	a,r3
   0AC4 FF                 1350 	mov	r7,a
   0AC5 8C 05              1351 	mov	ar5,r4
                           1352 ;	genCall
   0AC7 8E 82              1353 	mov	dpl,r6
   0AC9 8F 83              1354 	mov	dph,r7
   0ACB 8D F0              1355 	mov	b,r5
   0ACD C0 02              1356 	push	ar2
   0ACF C0 03              1357 	push	ar3
   0AD1 C0 04              1358 	push	ar4
   0AD3 C0 05              1359 	push	ar5
   0AD5 12 2F 88           1360 	lcall	_vListRemove
   0AD8 D0 05              1361 	pop	ar5
   0ADA D0 04              1362 	pop	ar4
   0ADC D0 03              1363 	pop	ar3
   0ADE D0 02              1364 	pop	ar2
                           1365 ;	../../FreeRTOS/Source/tasks.c:628: if( pxTCB->xEventListItem.pvContainer )
                           1366 ;	genPlus
   0AE0 E5 10              1367 	mov	a,_bp
   0AE2 24 04              1368 	add	a,#0x04
   0AE4 F8                 1369 	mov	r0,a
                           1370 ;     genPlusIncr
   0AE5 74 11              1371 	mov	a,#0x11
                           1372 ;	Peephole 236.a	used r2 instead of ar2
   0AE7 2A                 1373 	add	a,r2
   0AE8 F6                 1374 	mov	@r0,a
                           1375 ;	Peephole 181	changed mov to clr
   0AE9 E4                 1376 	clr	a
                           1377 ;	Peephole 236.b	used r3 instead of ar3
   0AEA 3B                 1378 	addc	a,r3
   0AEB 08                 1379 	inc	r0
   0AEC F6                 1380 	mov	@r0,a
   0AED 08                 1381 	inc	r0
   0AEE A6 04              1382 	mov	@r0,ar4
                           1383 ;	genPlus
   0AF0 E5 10              1384 	mov	a,_bp
   0AF2 24 04              1385 	add	a,#0x04
   0AF4 F8                 1386 	mov	r0,a
                           1387 ;     genPlusIncr
   0AF5 74 0B              1388 	mov	a,#0x0B
   0AF7 26                 1389 	add	a,@r0
   0AF8 FD                 1390 	mov	r5,a
                           1391 ;	Peephole 181	changed mov to clr
   0AF9 E4                 1392 	clr	a
   0AFA 08                 1393 	inc	r0
   0AFB 36                 1394 	addc	a,@r0
   0AFC FE                 1395 	mov	r6,a
   0AFD 08                 1396 	inc	r0
   0AFE 86 07              1397 	mov	ar7,@r0
                           1398 ;	genPointerGet
                           1399 ;	genGenPointerGet
   0B00 8D 82              1400 	mov	dpl,r5
   0B02 8E 83              1401 	mov	dph,r6
   0B04 8F F0              1402 	mov	b,r7
   0B06 12 E4 9F           1403 	lcall	__gptrget
   0B09 FD                 1404 	mov	r5,a
   0B0A A3                 1405 	inc	dptr
   0B0B 12 E4 9F           1406 	lcall	__gptrget
   0B0E FE                 1407 	mov	r6,a
   0B0F A3                 1408 	inc	dptr
   0B10 12 E4 9F           1409 	lcall	__gptrget
   0B13 FF                 1410 	mov	r7,a
                           1411 ;	genIfx
   0B14 ED                 1412 	mov	a,r5
   0B15 4E                 1413 	orl	a,r6
   0B16 4F                 1414 	orl	a,r7
                           1415 ;	genIpop
   0B17 D0 05              1416 	pop	ar5
                           1417 ;	genIfxJump
                           1418 ;	Peephole 108.c	removed ljmp by inverse jump logic
   0B19 60 20              1419 	jz	00104$
                           1420 ;	Peephole 300	removed redundant label 00123$
                           1421 ;	../../FreeRTOS/Source/tasks.c:630: vListRemove( &( pxTCB->xEventListItem ) );
                           1422 ;	genCall
   0B1B E5 10              1423 	mov	a,_bp
   0B1D 24 04              1424 	add	a,#0x04
   0B1F F8                 1425 	mov	r0,a
   0B20 86 82              1426 	mov	dpl,@r0
   0B22 08                 1427 	inc	r0
   0B23 86 83              1428 	mov	dph,@r0
   0B25 08                 1429 	inc	r0
   0B26 86 F0              1430 	mov	b,@r0
   0B28 C0 02              1431 	push	ar2
   0B2A C0 03              1432 	push	ar3
   0B2C C0 04              1433 	push	ar4
   0B2E C0 05              1434 	push	ar5
   0B30 12 2F 88           1435 	lcall	_vListRemove
   0B33 D0 05              1436 	pop	ar5
   0B35 D0 04              1437 	pop	ar4
   0B37 D0 03              1438 	pop	ar3
   0B39 D0 02              1439 	pop	ar2
   0B3B                    1440 00104$:
                           1441 ;	../../FreeRTOS/Source/tasks.c:633: vListInsertEnd( ( xList * ) &xTasksWaitingTermination, &( pxTCB->xGenericListItem ) );
                           1442 ;	genPlus
                           1443 ;     genPlusIncr
   0B3B 74 03              1444 	mov	a,#0x03
                           1445 ;	Peephole 236.a	used r2 instead of ar2
   0B3D 2A                 1446 	add	a,r2
   0B3E FA                 1447 	mov	r2,a
                           1448 ;	Peephole 181	changed mov to clr
   0B3F E4                 1449 	clr	a
                           1450 ;	Peephole 236.b	used r3 instead of ar3
   0B40 3B                 1451 	addc	a,r3
   0B41 FB                 1452 	mov	r3,a
                           1453 ;	genIpush
   0B42 C0 05              1454 	push	ar5
   0B44 C0 02              1455 	push	ar2
   0B46 C0 03              1456 	push	ar3
   0B48 C0 04              1457 	push	ar4
                           1458 ;	genCall
                           1459 ;	Peephole 182.a	used 16 bit load of DPTR
   0B4A 90 E0 60           1460 	mov	dptr,#_xTasksWaitingTermination
   0B4D 75 F0 00           1461 	mov	b,#0x00
   0B50 12 2B 96           1462 	lcall	_vListInsertEnd
   0B53 15 81              1463 	dec	sp
   0B55 15 81              1464 	dec	sp
   0B57 15 81              1465 	dec	sp
   0B59 D0 05              1466 	pop	ar5
                           1467 ;	../../FreeRTOS/Source/tasks.c:638: ++uxTasksDeleted;
                           1468 ;	genPlus
   0B5B 90 F0 78           1469 	mov	dptr,#_uxTasksDeleted
   0B5E E0                 1470 	movx	a,@dptr
   0B5F 24 01              1471 	add	a,#0x01
   0B61 F0                 1472 	movx	@dptr,a
                           1473 ;	../../FreeRTOS/Source/tasks.c:640: taskEXIT_CRITICAL();
                           1474 ;	genInline
   0B62 D0 E0              1475 	 pop ACC 
                           1476 ;	genAnd
   0B64 53 E0 80           1477 	anl	_ACC,#0x80
                           1478 ;	genOr
   0B67 E5 E0              1479 	mov	a,_ACC
   0B69 42 A8              1480 	orl	_IE,a
                           1481 ;	genInline
   0B6B D0 E0              1482 	 pop ACC 
                           1483 ;	../../FreeRTOS/Source/tasks.c:643: if( xSchedulerRunning != pdFALSE ) 
                           1484 ;	genAssign
   0B6D 90 F0 7E           1485 	mov	dptr,#_xSchedulerRunning
   0B70 E0                 1486 	movx	a,@dptr
                           1487 ;	genCmpEq
                           1488 ;	gencjneshort
                           1489 ;	Peephole 112.b	changed ljmp to sjmp
   0B71 FA                 1490 	mov	r2,a
                           1491 ;	Peephole 115.b	jump optimization
   0B72 60 06              1492 	jz	00109$
                           1493 ;	Peephole 300	removed redundant label 00124$
                           1494 ;	../../FreeRTOS/Source/tasks.c:645: if( ( void * ) pxTaskToDelete == NULL )
                           1495 ;	genIfx
   0B74 ED                 1496 	mov	a,r5
                           1497 ;	genIfxJump
                           1498 ;	Peephole 108.c	removed ljmp by inverse jump logic
   0B75 60 03              1499 	jz	00109$
                           1500 ;	Peephole 300	removed redundant label 00125$
                           1501 ;	../../FreeRTOS/Source/tasks.c:647: taskYIELD();
                           1502 ;	genCall
   0B77 12 33 E8           1503 	lcall	_vPortYield
   0B7A                    1504 00109$:
   0B7A 85 10 81           1505 	mov	sp,_bp
   0B7D D0 10              1506 	pop	_bp
   0B7F 22                 1507 	ret
                           1508 ;------------------------------------------------------------
                           1509 ;Allocation info for local variables in function 'vTaskDelayUntil'
                           1510 ;------------------------------------------------------------
                           1511 ;xTimeIncrement            Allocated to stack - offset -4
                           1512 ;pxPreviousWakeTime        Allocated to stack - offset 1
                           1513 ;xTimeToWake               Allocated to registers r3 r2 
                           1514 ;xAlreadyYielded           Allocated to registers r2 
                           1515 ;xShouldDelay              Allocated to stack - offset 4
                           1516 ;------------------------------------------------------------
                           1517 ;	../../FreeRTOS/Source/tasks.c:665: void vTaskDelayUntil( portTickType *pxPreviousWakeTime, portTickType xTimeIncrement )
                           1518 ;	-----------------------------------------
                           1519 ;	 function vTaskDelayUntil
                           1520 ;	-----------------------------------------
   0B80                    1521 _vTaskDelayUntil:
   0B80 C0 10              1522 	push	_bp
   0B82 85 81 10           1523 	mov	_bp,sp
                           1524 ;     genReceive
   0B85 C0 82              1525 	push	dpl
   0B87 C0 83              1526 	push	dph
   0B89 C0 F0              1527 	push	b
   0B8B 05 81              1528 	inc	sp
                           1529 ;	../../FreeRTOS/Source/tasks.c:668: portBASE_TYPE xAlreadyYielded, xShouldDelay = pdFALSE;
                           1530 ;	genAssign
   0B8D E5 10              1531 	mov	a,_bp
   0B8F 24 04              1532 	add	a,#0x04
   0B91 F8                 1533 	mov	r0,a
   0B92 76 00              1534 	mov	@r0,#0x00
                           1535 ;	../../FreeRTOS/Source/tasks.c:670: vTaskSuspendAll();
                           1536 ;	genCall
   0B94 12 0E 2C           1537 	lcall	_vTaskSuspendAll
                           1538 ;	../../FreeRTOS/Source/tasks.c:673: xTimeToWake = *pxPreviousWakeTime + xTimeIncrement;
                           1539 ;	genPointerGet
                           1540 ;	genGenPointerGet
   0B97 A8 10              1541 	mov	r0,_bp
   0B99 08                 1542 	inc	r0
   0B9A 86 82              1543 	mov	dpl,@r0
   0B9C 08                 1544 	inc	r0
   0B9D 86 83              1545 	mov	dph,@r0
   0B9F 08                 1546 	inc	r0
   0BA0 86 F0              1547 	mov	b,@r0
   0BA2 12 E4 9F           1548 	lcall	__gptrget
   0BA5 FE                 1549 	mov	r6,a
   0BA6 A3                 1550 	inc	dptr
   0BA7 12 E4 9F           1551 	lcall	__gptrget
   0BAA FF                 1552 	mov	r7,a
                           1553 ;	genPlus
   0BAB E5 10              1554 	mov	a,_bp
   0BAD 24 FC              1555 	add	a,#0xfffffffc
   0BAF F8                 1556 	mov	r0,a
   0BB0 E6                 1557 	mov	a,@r0
                           1558 ;	Peephole 236.a	used r6 instead of ar6
   0BB1 2E                 1559 	add	a,r6
   0BB2 FD                 1560 	mov	r5,a
   0BB3 08                 1561 	inc	r0
   0BB4 E6                 1562 	mov	a,@r0
                           1563 ;	Peephole 236.b	used r7 instead of ar7
   0BB5 3F                 1564 	addc	a,r7
   0BB6 FA                 1565 	mov	r2,a
                           1566 ;	genAssign
   0BB7 8D 03              1567 	mov	ar3,r5
                           1568 ;	../../FreeRTOS/Source/tasks.c:675: if( xTickCount < *pxPreviousWakeTime )
                           1569 ;	genAssign
   0BB9 90 F0 7A           1570 	mov	dptr,#_xTickCount
   0BBC E0                 1571 	movx	a,@dptr
   0BBD FC                 1572 	mov	r4,a
   0BBE A3                 1573 	inc	dptr
   0BBF E0                 1574 	movx	a,@dptr
   0BC0 FD                 1575 	mov	r5,a
                           1576 ;	genCmpLt
                           1577 ;	genCmp
   0BC1 C3                 1578 	clr	c
   0BC2 EC                 1579 	mov	a,r4
   0BC3 9E                 1580 	subb	a,r6
   0BC4 ED                 1581 	mov	a,r5
   0BC5 9F                 1582 	subb	a,r7
                           1583 ;	genIfxJump
                           1584 ;	Peephole 108.a	removed ljmp by inverse jump logic
   0BC6 50 1F              1585 	jnc	00108$
                           1586 ;	Peephole 300	removed redundant label 00126$
                           1587 ;	../../FreeRTOS/Source/tasks.c:682: if( ( xTimeToWake < *pxPreviousWakeTime ) && ( xTimeToWake > xTickCount ) )
                           1588 ;	genCmpLt
                           1589 ;	genCmp
   0BC8 C3                 1590 	clr	c
   0BC9 EB                 1591 	mov	a,r3
   0BCA 9E                 1592 	subb	a,r6
   0BCB EA                 1593 	mov	a,r2
   0BCC 9F                 1594 	subb	a,r7
                           1595 ;	genIfxJump
                           1596 ;	Peephole 108.a	removed ljmp by inverse jump logic
   0BCD 50 35              1597 	jnc	00109$
                           1598 ;	Peephole 300	removed redundant label 00127$
                           1599 ;	genAssign
   0BCF 90 F0 7A           1600 	mov	dptr,#_xTickCount
   0BD2 E0                 1601 	movx	a,@dptr
   0BD3 FC                 1602 	mov	r4,a
   0BD4 A3                 1603 	inc	dptr
   0BD5 E0                 1604 	movx	a,@dptr
   0BD6 FD                 1605 	mov	r5,a
                           1606 ;	genCmpGt
                           1607 ;	genCmp
   0BD7 C3                 1608 	clr	c
   0BD8 EC                 1609 	mov	a,r4
   0BD9 9B                 1610 	subb	a,r3
   0BDA ED                 1611 	mov	a,r5
   0BDB 9A                 1612 	subb	a,r2
                           1613 ;	genIfxJump
                           1614 ;	Peephole 108.a	removed ljmp by inverse jump logic
   0BDC 50 26              1615 	jnc	00109$
                           1616 ;	Peephole 300	removed redundant label 00128$
                           1617 ;	../../FreeRTOS/Source/tasks.c:684: xShouldDelay = pdTRUE;
                           1618 ;	genAssign
   0BDE E5 10              1619 	mov	a,_bp
   0BE0 24 04              1620 	add	a,#0x04
   0BE2 F8                 1621 	mov	r0,a
   0BE3 76 01              1622 	mov	@r0,#0x01
                           1623 ;	Peephole 112.b	changed ljmp to sjmp
   0BE5 80 1D              1624 	sjmp	00109$
   0BE7                    1625 00108$:
                           1626 ;	../../FreeRTOS/Source/tasks.c:692: if( ( xTimeToWake < *pxPreviousWakeTime ) || ( xTimeToWake > xTickCount ) )
                           1627 ;	genCmpLt
                           1628 ;	genCmp
   0BE7 C3                 1629 	clr	c
   0BE8 EB                 1630 	mov	a,r3
   0BE9 9E                 1631 	subb	a,r6
   0BEA EA                 1632 	mov	a,r2
   0BEB 9F                 1633 	subb	a,r7
                           1634 ;	genIfxJump
                           1635 ;	Peephole 112.b	changed ljmp to sjmp
                           1636 ;	Peephole 160.a	removed sjmp by inverse jump logic
   0BEC 40 0F              1637 	jc	00104$
                           1638 ;	Peephole 300	removed redundant label 00129$
                           1639 ;	genAssign
   0BEE 90 F0 7A           1640 	mov	dptr,#_xTickCount
   0BF1 E0                 1641 	movx	a,@dptr
   0BF2 FC                 1642 	mov	r4,a
   0BF3 A3                 1643 	inc	dptr
   0BF4 E0                 1644 	movx	a,@dptr
   0BF5 FD                 1645 	mov	r5,a
                           1646 ;	genCmpGt
                           1647 ;	genCmp
   0BF6 C3                 1648 	clr	c
   0BF7 EC                 1649 	mov	a,r4
   0BF8 9B                 1650 	subb	a,r3
   0BF9 ED                 1651 	mov	a,r5
   0BFA 9A                 1652 	subb	a,r2
                           1653 ;	genIfxJump
                           1654 ;	Peephole 108.a	removed ljmp by inverse jump logic
   0BFB 50 07              1655 	jnc	00109$
                           1656 ;	Peephole 300	removed redundant label 00130$
   0BFD                    1657 00104$:
                           1658 ;	../../FreeRTOS/Source/tasks.c:694: xShouldDelay = pdTRUE;
                           1659 ;	genAssign
   0BFD E5 10              1660 	mov	a,_bp
   0BFF 24 04              1661 	add	a,#0x04
   0C01 F8                 1662 	mov	r0,a
   0C02 76 01              1663 	mov	@r0,#0x01
   0C04                    1664 00109$:
                           1665 ;	../../FreeRTOS/Source/tasks.c:699: *pxPreviousWakeTime = xTimeToWake;
                           1666 ;	genPointerSet
                           1667 ;	genGenPointerSet
   0C04 A8 10              1668 	mov	r0,_bp
   0C06 08                 1669 	inc	r0
   0C07 86 82              1670 	mov	dpl,@r0
   0C09 08                 1671 	inc	r0
   0C0A 86 83              1672 	mov	dph,@r0
   0C0C 08                 1673 	inc	r0
   0C0D 86 F0              1674 	mov	b,@r0
   0C0F EB                 1675 	mov	a,r3
   0C10 12 DF B7           1676 	lcall	__gptrput
   0C13 A3                 1677 	inc	dptr
   0C14 EA                 1678 	mov	a,r2
   0C15 12 DF B7           1679 	lcall	__gptrput
                           1680 ;	../../FreeRTOS/Source/tasks.c:701: if( xShouldDelay )
                           1681 ;	genIfx
   0C18 E5 10              1682 	mov	a,_bp
   0C1A 24 04              1683 	add	a,#0x04
   0C1C F8                 1684 	mov	r0,a
   0C1D E6                 1685 	mov	a,@r0
                           1686 ;	genIfxJump
   0C1E 70 03              1687 	jnz	00131$
   0C20 02 0C DC           1688 	ljmp	00114$
   0C23                    1689 00131$:
                           1690 ;	../../FreeRTOS/Source/tasks.c:706: vListRemove( ( xListItem * ) &( pxCurrentTCB->xGenericListItem ) );
                           1691 ;	genAssign
   0C23 90 F0 75           1692 	mov	dptr,#_pxCurrentTCB
   0C26 E0                 1693 	movx	a,@dptr
   0C27 FC                 1694 	mov	r4,a
   0C28 A3                 1695 	inc	dptr
   0C29 E0                 1696 	movx	a,@dptr
   0C2A FD                 1697 	mov	r5,a
   0C2B A3                 1698 	inc	dptr
   0C2C E0                 1699 	movx	a,@dptr
   0C2D FE                 1700 	mov	r6,a
                           1701 ;	genPlus
                           1702 ;     genPlusIncr
   0C2E 74 03              1703 	mov	a,#0x03
                           1704 ;	Peephole 236.a	used r4 instead of ar4
   0C30 2C                 1705 	add	a,r4
   0C31 FC                 1706 	mov	r4,a
                           1707 ;	Peephole 181	changed mov to clr
   0C32 E4                 1708 	clr	a
                           1709 ;	Peephole 236.b	used r5 instead of ar5
   0C33 3D                 1710 	addc	a,r5
   0C34 FD                 1711 	mov	r5,a
                           1712 ;	genCall
   0C35 8C 82              1713 	mov	dpl,r4
   0C37 8D 83              1714 	mov	dph,r5
   0C39 8E F0              1715 	mov	b,r6
   0C3B C0 02              1716 	push	ar2
   0C3D C0 03              1717 	push	ar3
   0C3F 12 2F 88           1718 	lcall	_vListRemove
   0C42 D0 03              1719 	pop	ar3
   0C44 D0 02              1720 	pop	ar2
                           1721 ;	../../FreeRTOS/Source/tasks.c:709: listSET_LIST_ITEM_VALUE( &( pxCurrentTCB->xGenericListItem ), xTimeToWake );
                           1722 ;	genAssign
   0C46 90 F0 75           1723 	mov	dptr,#_pxCurrentTCB
   0C49 E0                 1724 	movx	a,@dptr
   0C4A FC                 1725 	mov	r4,a
   0C4B A3                 1726 	inc	dptr
   0C4C E0                 1727 	movx	a,@dptr
   0C4D FD                 1728 	mov	r5,a
   0C4E A3                 1729 	inc	dptr
   0C4F E0                 1730 	movx	a,@dptr
   0C50 FE                 1731 	mov	r6,a
                           1732 ;	genPlus
                           1733 ;     genPlusIncr
   0C51 74 03              1734 	mov	a,#0x03
                           1735 ;	Peephole 236.a	used r4 instead of ar4
   0C53 2C                 1736 	add	a,r4
   0C54 FC                 1737 	mov	r4,a
                           1738 ;	Peephole 181	changed mov to clr
   0C55 E4                 1739 	clr	a
                           1740 ;	Peephole 236.b	used r5 instead of ar5
   0C56 3D                 1741 	addc	a,r5
   0C57 FD                 1742 	mov	r5,a
                           1743 ;	genPointerSet
                           1744 ;	genGenPointerSet
   0C58 8C 82              1745 	mov	dpl,r4
   0C5A 8D 83              1746 	mov	dph,r5
   0C5C 8E F0              1747 	mov	b,r6
   0C5E EB                 1748 	mov	a,r3
   0C5F 12 DF B7           1749 	lcall	__gptrput
   0C62 A3                 1750 	inc	dptr
   0C63 EA                 1751 	mov	a,r2
   0C64 12 DF B7           1752 	lcall	__gptrput
                           1753 ;	../../FreeRTOS/Source/tasks.c:711: if( xTimeToWake < xTickCount )
                           1754 ;	genAssign
   0C67 90 F0 7A           1755 	mov	dptr,#_xTickCount
   0C6A E0                 1756 	movx	a,@dptr
   0C6B FC                 1757 	mov	r4,a
   0C6C A3                 1758 	inc	dptr
   0C6D E0                 1759 	movx	a,@dptr
   0C6E FD                 1760 	mov	r5,a
                           1761 ;	genCmpLt
                           1762 ;	genCmp
   0C6F C3                 1763 	clr	c
   0C70 EB                 1764 	mov	a,r3
   0C71 9C                 1765 	subb	a,r4
   0C72 EA                 1766 	mov	a,r2
   0C73 9D                 1767 	subb	a,r5
                           1768 ;	genIfxJump
                           1769 ;	Peephole 108.a	removed ljmp by inverse jump logic
   0C74 50 34              1770 	jnc	00111$
                           1771 ;	Peephole 300	removed redundant label 00132$
                           1772 ;	../../FreeRTOS/Source/tasks.c:715: vListInsert( ( xList * ) pxOverflowDelayedTaskList, ( xListItem * ) &( pxCurrentTCB->xGenericListItem ) );
                           1773 ;	genAssign
   0C76 90 F0 75           1774 	mov	dptr,#_pxCurrentTCB
   0C79 E0                 1775 	movx	a,@dptr
   0C7A FA                 1776 	mov	r2,a
   0C7B A3                 1777 	inc	dptr
   0C7C E0                 1778 	movx	a,@dptr
   0C7D FB                 1779 	mov	r3,a
   0C7E A3                 1780 	inc	dptr
   0C7F E0                 1781 	movx	a,@dptr
   0C80 FC                 1782 	mov	r4,a
                           1783 ;	genPlus
                           1784 ;     genPlusIncr
   0C81 74 03              1785 	mov	a,#0x03
                           1786 ;	Peephole 236.a	used r2 instead of ar2
   0C83 2A                 1787 	add	a,r2
   0C84 FA                 1788 	mov	r2,a
                           1789 ;	Peephole 181	changed mov to clr
   0C85 E4                 1790 	clr	a
                           1791 ;	Peephole 236.b	used r3 instead of ar3
   0C86 3B                 1792 	addc	a,r3
   0C87 FB                 1793 	mov	r3,a
                           1794 ;	genAssign
   0C88 90 E0 51           1795 	mov	dptr,#_pxOverflowDelayedTaskList
   0C8B E0                 1796 	movx	a,@dptr
   0C8C FD                 1797 	mov	r5,a
   0C8D A3                 1798 	inc	dptr
   0C8E E0                 1799 	movx	a,@dptr
   0C8F FE                 1800 	mov	r6,a
   0C90 A3                 1801 	inc	dptr
   0C91 E0                 1802 	movx	a,@dptr
   0C92 FF                 1803 	mov	r7,a
                           1804 ;	genIpush
   0C93 C0 02              1805 	push	ar2
   0C95 C0 03              1806 	push	ar3
   0C97 C0 04              1807 	push	ar4
                           1808 ;	genCall
   0C99 8D 82              1809 	mov	dpl,r5
   0C9B 8E 83              1810 	mov	dph,r6
   0C9D 8F F0              1811 	mov	b,r7
   0C9F 12 2D 55           1812 	lcall	_vListInsert
   0CA2 15 81              1813 	dec	sp
   0CA4 15 81              1814 	dec	sp
   0CA6 15 81              1815 	dec	sp
                           1816 ;	Peephole 112.b	changed ljmp to sjmp
   0CA8 80 32              1817 	sjmp	00114$
   0CAA                    1818 00111$:
                           1819 ;	../../FreeRTOS/Source/tasks.c:721: vListInsert( ( xList * ) pxDelayedTaskList, ( xListItem * ) &( pxCurrentTCB->xGenericListItem ) );
                           1820 ;	genAssign
   0CAA 90 F0 75           1821 	mov	dptr,#_pxCurrentTCB
   0CAD E0                 1822 	movx	a,@dptr
   0CAE FA                 1823 	mov	r2,a
   0CAF A3                 1824 	inc	dptr
   0CB0 E0                 1825 	movx	a,@dptr
   0CB1 FB                 1826 	mov	r3,a
   0CB2 A3                 1827 	inc	dptr
   0CB3 E0                 1828 	movx	a,@dptr
   0CB4 FC                 1829 	mov	r4,a
                           1830 ;	genPlus
                           1831 ;     genPlusIncr
   0CB5 74 03              1832 	mov	a,#0x03
                           1833 ;	Peephole 236.a	used r2 instead of ar2
   0CB7 2A                 1834 	add	a,r2
   0CB8 FA                 1835 	mov	r2,a
                           1836 ;	Peephole 181	changed mov to clr
   0CB9 E4                 1837 	clr	a
                           1838 ;	Peephole 236.b	used r3 instead of ar3
   0CBA 3B                 1839 	addc	a,r3
   0CBB FB                 1840 	mov	r3,a
                           1841 ;	genAssign
   0CBC 90 E0 4E           1842 	mov	dptr,#_pxDelayedTaskList
   0CBF E0                 1843 	movx	a,@dptr
   0CC0 FD                 1844 	mov	r5,a
   0CC1 A3                 1845 	inc	dptr
   0CC2 E0                 1846 	movx	a,@dptr
   0CC3 FE                 1847 	mov	r6,a
   0CC4 A3                 1848 	inc	dptr
   0CC5 E0                 1849 	movx	a,@dptr
   0CC6 FF                 1850 	mov	r7,a
                           1851 ;	genIpush
   0CC7 C0 02              1852 	push	ar2
   0CC9 C0 03              1853 	push	ar3
   0CCB C0 04              1854 	push	ar4
                           1855 ;	genCall
   0CCD 8D 82              1856 	mov	dpl,r5
   0CCF 8E 83              1857 	mov	dph,r6
   0CD1 8F F0              1858 	mov	b,r7
   0CD3 12 2D 55           1859 	lcall	_vListInsert
   0CD6 15 81              1860 	dec	sp
   0CD8 15 81              1861 	dec	sp
   0CDA 15 81              1862 	dec	sp
   0CDC                    1863 00114$:
                           1864 ;	../../FreeRTOS/Source/tasks.c:725: xAlreadyYielded = xTaskResumeAll();
                           1865 ;	genCall
   0CDC 12 0E 45           1866 	lcall	_xTaskResumeAll
                           1867 ;	genAssign
                           1868 ;	../../FreeRTOS/Source/tasks.c:729: if( !xAlreadyYielded )
                           1869 ;	genIfx
                           1870 ;	peephole 177.g	optimized mov sequence
   0CDF E5 82              1871 	mov	a,dpl
   0CE1 FA                 1872 	mov	r2,a
                           1873 ;	genIfxJump
                           1874 ;	Peephole 108.b	removed ljmp by inverse jump logic
   0CE2 70 03              1875 	jnz	00117$
                           1876 ;	Peephole 300	removed redundant label 00133$
                           1877 ;	../../FreeRTOS/Source/tasks.c:731: taskYIELD();
                           1878 ;	genCall
   0CE4 12 33 E8           1879 	lcall	_vPortYield
   0CE7                    1880 00117$:
   0CE7 85 10 81           1881 	mov	sp,_bp
   0CEA D0 10              1882 	pop	_bp
   0CEC 22                 1883 	ret
                           1884 ;------------------------------------------------------------
                           1885 ;Allocation info for local variables in function 'vTaskDelay'
                           1886 ;------------------------------------------------------------
                           1887 ;xTicksToDelay             Allocated to registers r2 r3 
                           1888 ;xTimeToWake               Allocated to registers r2 r3 
                           1889 ;xAlreadyYielded           Allocated to registers r4 
                           1890 ;sloc0                     Allocated to stack - offset 6
                           1891 ;------------------------------------------------------------
                           1892 ;	../../FreeRTOS/Source/tasks.c:740: void vTaskDelay( portTickType xTicksToDelay )
                           1893 ;	-----------------------------------------
                           1894 ;	 function vTaskDelay
                           1895 ;	-----------------------------------------
   0CED                    1896 _vTaskDelay:
                           1897 ;	genReceive
   0CED AA 82              1898 	mov	r2,dpl
   0CEF AB 83              1899 	mov	r3,dph
                           1900 ;	../../FreeRTOS/Source/tasks.c:743: signed portBASE_TYPE xAlreadyYielded = pdFALSE;
                           1901 ;	genAssign
   0CF1 7C 00              1902 	mov	r4,#0x00
                           1903 ;	../../FreeRTOS/Source/tasks.c:746: if( xTicksToDelay > ( portTickType ) 0 )
                           1904 ;	genIfx
   0CF3 EA                 1905 	mov	a,r2
   0CF4 4B                 1906 	orl	a,r3
                           1907 ;	genIfxJump
   0CF5 70 03              1908 	jnz	00113$
   0CF7 02 0D D3           1909 	ljmp	00105$
   0CFA                    1910 00113$:
                           1911 ;	../../FreeRTOS/Source/tasks.c:748: vTaskSuspendAll();
                           1912 ;	genCall
   0CFA C0 02              1913 	push	ar2
   0CFC C0 03              1914 	push	ar3
   0CFE 12 0E 2C           1915 	lcall	_vTaskSuspendAll
   0D01 D0 03              1916 	pop	ar3
   0D03 D0 02              1917 	pop	ar2
                           1918 ;	../../FreeRTOS/Source/tasks.c:760: xTimeToWake = xTickCount + xTicksToDelay;
                           1919 ;	genAssign
   0D05 90 F0 7A           1920 	mov	dptr,#_xTickCount
   0D08 E0                 1921 	movx	a,@dptr
   0D09 FD                 1922 	mov	r5,a
   0D0A A3                 1923 	inc	dptr
   0D0B E0                 1924 	movx	a,@dptr
   0D0C FE                 1925 	mov	r6,a
                           1926 ;	genPlus
                           1927 ;	Peephole 236.g	used r2 instead of ar2
   0D0D EA                 1928 	mov	a,r2
                           1929 ;	Peephole 236.a	used r5 instead of ar5
   0D0E 2D                 1930 	add	a,r5
   0D0F FA                 1931 	mov	r2,a
                           1932 ;	Peephole 236.g	used r3 instead of ar3
   0D10 EB                 1933 	mov	a,r3
                           1934 ;	Peephole 236.b	used r6 instead of ar6
   0D11 3E                 1935 	addc	a,r6
   0D12 FB                 1936 	mov	r3,a
                           1937 ;	genAssign
                           1938 ;	../../FreeRTOS/Source/tasks.c:765: vListRemove( ( xListItem * ) &( pxCurrentTCB->xGenericListItem ) );
                           1939 ;	genAssign
   0D13 90 F0 75           1940 	mov	dptr,#_pxCurrentTCB
   0D16 E0                 1941 	movx	a,@dptr
   0D17 FD                 1942 	mov	r5,a
   0D18 A3                 1943 	inc	dptr
   0D19 E0                 1944 	movx	a,@dptr
   0D1A FE                 1945 	mov	r6,a
   0D1B A3                 1946 	inc	dptr
   0D1C E0                 1947 	movx	a,@dptr
   0D1D FF                 1948 	mov	r7,a
                           1949 ;	genPlus
                           1950 ;     genPlusIncr
   0D1E 74 03              1951 	mov	a,#0x03
                           1952 ;	Peephole 236.a	used r5 instead of ar5
   0D20 2D                 1953 	add	a,r5
   0D21 FD                 1954 	mov	r5,a
                           1955 ;	Peephole 181	changed mov to clr
   0D22 E4                 1956 	clr	a
                           1957 ;	Peephole 236.b	used r6 instead of ar6
   0D23 3E                 1958 	addc	a,r6
   0D24 FE                 1959 	mov	r6,a
                           1960 ;	genCall
   0D25 8D 82              1961 	mov	dpl,r5
   0D27 8E 83              1962 	mov	dph,r6
   0D29 8F F0              1963 	mov	b,r7
   0D2B C0 02              1964 	push	ar2
   0D2D C0 03              1965 	push	ar3
   0D2F 12 2F 88           1966 	lcall	_vListRemove
   0D32 D0 03              1967 	pop	ar3
   0D34 D0 02              1968 	pop	ar2
                           1969 ;	../../FreeRTOS/Source/tasks.c:768: listSET_LIST_ITEM_VALUE( &( pxCurrentTCB->xGenericListItem ), xTimeToWake );
                           1970 ;	genAssign
   0D36 90 F0 75           1971 	mov	dptr,#_pxCurrentTCB
   0D39 E0                 1972 	movx	a,@dptr
   0D3A FD                 1973 	mov	r5,a
   0D3B A3                 1974 	inc	dptr
   0D3C E0                 1975 	movx	a,@dptr
   0D3D FE                 1976 	mov	r6,a
   0D3E A3                 1977 	inc	dptr
   0D3F E0                 1978 	movx	a,@dptr
   0D40 FF                 1979 	mov	r7,a
                           1980 ;	genPlus
                           1981 ;     genPlusIncr
   0D41 74 03              1982 	mov	a,#0x03
                           1983 ;	Peephole 236.a	used r5 instead of ar5
   0D43 2D                 1984 	add	a,r5
   0D44 FD                 1985 	mov	r5,a
                           1986 ;	Peephole 181	changed mov to clr
   0D45 E4                 1987 	clr	a
                           1988 ;	Peephole 236.b	used r6 instead of ar6
   0D46 3E                 1989 	addc	a,r6
   0D47 FE                 1990 	mov	r6,a
                           1991 ;	genPointerSet
                           1992 ;	genGenPointerSet
   0D48 8D 82              1993 	mov	dpl,r5
   0D4A 8E 83              1994 	mov	dph,r6
   0D4C 8F F0              1995 	mov	b,r7
   0D4E EA                 1996 	mov	a,r2
   0D4F 12 DF B7           1997 	lcall	__gptrput
   0D52 A3                 1998 	inc	dptr
   0D53 EB                 1999 	mov	a,r3
   0D54 12 DF B7           2000 	lcall	__gptrput
                           2001 ;	../../FreeRTOS/Source/tasks.c:770: if( xTimeToWake < xTickCount )
                           2002 ;	genAssign
   0D57 90 F0 7A           2003 	mov	dptr,#_xTickCount
   0D5A E0                 2004 	movx	a,@dptr
   0D5B FD                 2005 	mov	r5,a
   0D5C A3                 2006 	inc	dptr
   0D5D E0                 2007 	movx	a,@dptr
   0D5E FE                 2008 	mov	r6,a
                           2009 ;	genCmpLt
                           2010 ;	genCmp
   0D5F C3                 2011 	clr	c
   0D60 EA                 2012 	mov	a,r2
   0D61 9D                 2013 	subb	a,r5
   0D62 EB                 2014 	mov	a,r3
   0D63 9E                 2015 	subb	a,r6
                           2016 ;	genIfxJump
                           2017 ;	Peephole 108.a	removed ljmp by inverse jump logic
   0D64 50 34              2018 	jnc	00102$
                           2019 ;	Peephole 300	removed redundant label 00114$
                           2020 ;	../../FreeRTOS/Source/tasks.c:774: vListInsert( ( xList * ) pxOverflowDelayedTaskList, ( xListItem * ) &( pxCurrentTCB->xGenericListItem ) );
                           2021 ;	genAssign
   0D66 90 F0 75           2022 	mov	dptr,#_pxCurrentTCB
   0D69 E0                 2023 	movx	a,@dptr
   0D6A FA                 2024 	mov	r2,a
   0D6B A3                 2025 	inc	dptr
   0D6C E0                 2026 	movx	a,@dptr
   0D6D FB                 2027 	mov	r3,a
   0D6E A3                 2028 	inc	dptr
   0D6F E0                 2029 	movx	a,@dptr
   0D70 FD                 2030 	mov	r5,a
                           2031 ;	genPlus
                           2032 ;     genPlusIncr
   0D71 74 03              2033 	mov	a,#0x03
                           2034 ;	Peephole 236.a	used r2 instead of ar2
   0D73 2A                 2035 	add	a,r2
   0D74 FC                 2036 	mov	r4,a
                           2037 ;	Peephole 181	changed mov to clr
   0D75 E4                 2038 	clr	a
                           2039 ;	Peephole 236.b	used r3 instead of ar3
   0D76 3B                 2040 	addc	a,r3
   0D77 FB                 2041 	mov	r3,a
                           2042 ;	genAssign
   0D78 90 E0 51           2043 	mov	dptr,#_pxOverflowDelayedTaskList
   0D7B E0                 2044 	movx	a,@dptr
   0D7C FE                 2045 	mov	r6,a
   0D7D A3                 2046 	inc	dptr
   0D7E E0                 2047 	movx	a,@dptr
   0D7F FF                 2048 	mov	r7,a
   0D80 A3                 2049 	inc	dptr
   0D81 E0                 2050 	movx	a,@dptr
   0D82 FA                 2051 	mov	r2,a
                           2052 ;	genIpush
   0D83 C0 04              2053 	push	ar4
   0D85 C0 03              2054 	push	ar3
   0D87 C0 05              2055 	push	ar5
                           2056 ;	genCall
   0D89 8E 82              2057 	mov	dpl,r6
   0D8B 8F 83              2058 	mov	dph,r7
   0D8D 8A F0              2059 	mov	b,r2
   0D8F 12 2D 55           2060 	lcall	_vListInsert
   0D92 15 81              2061 	dec	sp
   0D94 15 81              2062 	dec	sp
   0D96 15 81              2063 	dec	sp
                           2064 ;	Peephole 112.b	changed ljmp to sjmp
   0D98 80 32              2065 	sjmp	00103$
   0D9A                    2066 00102$:
                           2067 ;	../../FreeRTOS/Source/tasks.c:780: vListInsert( ( xList * ) pxDelayedTaskList, ( xListItem * ) &( pxCurrentTCB->xGenericListItem ) );
                           2068 ;	genAssign
   0D9A 90 F0 75           2069 	mov	dptr,#_pxCurrentTCB
   0D9D E0                 2070 	movx	a,@dptr
   0D9E FA                 2071 	mov	r2,a
   0D9F A3                 2072 	inc	dptr
   0DA0 E0                 2073 	movx	a,@dptr
   0DA1 FB                 2074 	mov	r3,a
   0DA2 A3                 2075 	inc	dptr
   0DA3 E0                 2076 	movx	a,@dptr
   0DA4 FD                 2077 	mov	r5,a
                           2078 ;	genPlus
                           2079 ;     genPlusIncr
   0DA5 74 03              2080 	mov	a,#0x03
                           2081 ;	Peephole 236.a	used r2 instead of ar2
   0DA7 2A                 2082 	add	a,r2
   0DA8 FC                 2083 	mov	r4,a
                           2084 ;	Peephole 181	changed mov to clr
   0DA9 E4                 2085 	clr	a
                           2086 ;	Peephole 236.b	used r3 instead of ar3
   0DAA 3B                 2087 	addc	a,r3
   0DAB FB                 2088 	mov	r3,a
                           2089 ;	genAssign
   0DAC 90 E0 4E           2090 	mov	dptr,#_pxDelayedTaskList
   0DAF E0                 2091 	movx	a,@dptr
   0DB0 FE                 2092 	mov	r6,a
   0DB1 A3                 2093 	inc	dptr
   0DB2 E0                 2094 	movx	a,@dptr
   0DB3 FF                 2095 	mov	r7,a
   0DB4 A3                 2096 	inc	dptr
   0DB5 E0                 2097 	movx	a,@dptr
   0DB6 FA                 2098 	mov	r2,a
                           2099 ;	genIpush
   0DB7 C0 04              2100 	push	ar4
   0DB9 C0 03              2101 	push	ar3
   0DBB C0 05              2102 	push	ar5
                           2103 ;	genCall
   0DBD 8E 82              2104 	mov	dpl,r6
   0DBF 8F 83              2105 	mov	dph,r7
   0DC1 8A F0              2106 	mov	b,r2
   0DC3 12 2D 55           2107 	lcall	_vListInsert
   0DC6 15 81              2108 	dec	sp
   0DC8 15 81              2109 	dec	sp
   0DCA 15 81              2110 	dec	sp
   0DCC                    2111 00103$:
                           2112 ;	../../FreeRTOS/Source/tasks.c:783: xAlreadyYielded = xTaskResumeAll();
                           2113 ;	genCall
   0DCC 12 0E 45           2114 	lcall	_xTaskResumeAll
   0DCF AA 82              2115 	mov	r2,dpl
                           2116 ;	genAssign
   0DD1 8A 04              2117 	mov	ar4,r2
   0DD3                    2118 00105$:
                           2119 ;	../../FreeRTOS/Source/tasks.c:788: if( !xAlreadyYielded )
                           2120 ;	genIfx
   0DD3 EC                 2121 	mov	a,r4
                           2122 ;	genIfxJump
                           2123 ;	Peephole 108.b	removed ljmp by inverse jump logic
   0DD4 70 03              2124 	jnz	00108$
                           2125 ;	Peephole 300	removed redundant label 00115$
                           2126 ;	../../FreeRTOS/Source/tasks.c:790: taskYIELD();
                           2127 ;	genCall
                           2128 ;	Peephole 253.c	replaced lcall with ljmp
   0DD6 02 33 E8           2129 	ljmp	_vPortYield
   0DD9                    2130 00108$:
   0DD9 22                 2131 	ret
                           2132 ;------------------------------------------------------------
                           2133 ;Allocation info for local variables in function 'vTaskStartScheduler'
                           2134 ;------------------------------------------------------------
                           2135 ;xReturn                   Allocated to registers r2 
                           2136 ;------------------------------------------------------------
                           2137 ;	../../FreeRTOS/Source/tasks.c:1019: void vTaskStartScheduler( void )
                           2138 ;	-----------------------------------------
                           2139 ;	 function vTaskStartScheduler
                           2140 ;	-----------------------------------------
   0DDA                    2141 _vTaskStartScheduler:
                           2142 ;	../../FreeRTOS/Source/tasks.c:1024: xReturn = xTaskCreate( prvIdleTask, ( signed portCHAR * ) "IDLE", tskIDLE_STACK_SIZE, ( void * ) NULL, tskIDLE_PRIORITY, ( xTaskHandle * ) NULL );
                           2143 ;	genIpush
                           2144 ;	Peephole 181	changed mov to clr
   0DDA E4                 2145 	clr	a
   0DDB C0 E0              2146 	push	acc
   0DDD C0 E0              2147 	push	acc
   0DDF C0 E0              2148 	push	acc
                           2149 ;	genIpush
                           2150 ;	Peephole 181	changed mov to clr
   0DE1 E4                 2151 	clr	a
   0DE2 C0 E0              2152 	push	acc
                           2153 ;	genIpush
                           2154 ;	Peephole 181	changed mov to clr
   0DE4 E4                 2155 	clr	a
   0DE5 C0 E0              2156 	push	acc
   0DE7 C0 E0              2157 	push	acc
   0DE9 C0 E0              2158 	push	acc
                           2159 ;	genIpush
   0DEB 74 50              2160 	mov	a,#0x50
   0DED C0 E0              2161 	push	acc
                           2162 ;	Peephole 181	changed mov to clr
   0DEF E4                 2163 	clr	a
   0DF0 C0 E0              2164 	push	acc
                           2165 ;	genIpush
   0DF2 74 7D              2166 	mov	a,#__str_0
   0DF4 C0 E0              2167 	push	acc
   0DF6 74 E7              2168 	mov	a,#(__str_0 >> 8)
   0DF8 C0 E0              2169 	push	acc
   0DFA 74 80              2170 	mov	a,#0x80
   0DFC C0 E0              2171 	push	acc
                           2172 ;	genCall
                           2173 ;	Peephole 182.a	used 16 bit load of DPTR
   0DFE 90 17 79           2174 	mov	dptr,#_prvIdleTask
   0E01 12 07 F1           2175 	lcall	_xTaskCreate
   0E04 AA 82              2176 	mov	r2,dpl
   0E06 E5 81              2177 	mov	a,sp
   0E08 24 F4              2178 	add	a,#0xf4
   0E0A F5 81              2179 	mov	sp,a
                           2180 ;	genAssign
                           2181 ;	../../FreeRTOS/Source/tasks.c:1026: if( xReturn == pdPASS )
                           2182 ;	genCmpEq
                           2183 ;	gencjneshort
                           2184 ;	Peephole 112.b	changed ljmp to sjmp
                           2185 ;	Peephole 198.b	optimized misc jump sequence
   0E0C BA 01 12           2186 	cjne	r2,#0x01,00105$
                           2187 ;	Peephole 200.b	removed redundant sjmp
                           2188 ;	Peephole 300	removed redundant label 00108$
                           2189 ;	Peephole 300	removed redundant label 00109$
                           2190 ;	../../FreeRTOS/Source/tasks.c:1036: portDISABLE_INTERRUPTS();
                           2191 ;	genAssign
   0E0F C2 AF              2192 	clr	_EA
                           2193 ;	../../FreeRTOS/Source/tasks.c:1038: xSchedulerRunning = pdTRUE;
                           2194 ;	genAssign
   0E11 90 F0 7E           2195 	mov	dptr,#_xSchedulerRunning
   0E14 74 01              2196 	mov	a,#0x01
   0E16 F0                 2197 	movx	@dptr,a
                           2198 ;	../../FreeRTOS/Source/tasks.c:1039: xTickCount = ( portTickType ) 0;
                           2199 ;	genAssign
   0E17 90 F0 7A           2200 	mov	dptr,#_xTickCount
   0E1A E4                 2201 	clr	a
   0E1B F0                 2202 	movx	@dptr,a
   0E1C A3                 2203 	inc	dptr
   0E1D F0                 2204 	movx	@dptr,a
                           2205 ;	../../FreeRTOS/Source/tasks.c:1043: if( xPortStartScheduler() )
                           2206 ;	genCall
                           2207 ;	Peephole 253.c	replaced lcall with ljmp
   0E1E 02 33 72           2208 	ljmp	_xPortStartScheduler
   0E21                    2209 00105$:
   0E21 22                 2210 	ret
                           2211 ;------------------------------------------------------------
                           2212 ;Allocation info for local variables in function 'vTaskEndScheduler'
                           2213 ;------------------------------------------------------------
                           2214 ;------------------------------------------------------------
                           2215 ;	../../FreeRTOS/Source/tasks.c:1056: void vTaskEndScheduler( void )
                           2216 ;	-----------------------------------------
                           2217 ;	 function vTaskEndScheduler
                           2218 ;	-----------------------------------------
   0E22                    2219 _vTaskEndScheduler:
                           2220 ;	../../FreeRTOS/Source/tasks.c:1061: portDISABLE_INTERRUPTS();
                           2221 ;	genAssign
   0E22 C2 AF              2222 	clr	_EA
                           2223 ;	../../FreeRTOS/Source/tasks.c:1062: xSchedulerRunning = pdFALSE;
                           2224 ;	genAssign
   0E24 90 F0 7E           2225 	mov	dptr,#_xSchedulerRunning
                           2226 ;	Peephole 181	changed mov to clr
   0E27 E4                 2227 	clr	a
   0E28 F0                 2228 	movx	@dptr,a
                           2229 ;	../../FreeRTOS/Source/tasks.c:1063: vPortEndScheduler();
                           2230 ;	genCall
                           2231 ;	Peephole 253.b	replaced lcall/ret with ljmp
   0E29 02 33 E7           2232 	ljmp	_vPortEndScheduler
                           2233 ;
                           2234 ;------------------------------------------------------------
                           2235 ;Allocation info for local variables in function 'vTaskSuspendAll'
                           2236 ;------------------------------------------------------------
                           2237 ;------------------------------------------------------------
                           2238 ;	../../FreeRTOS/Source/tasks.c:1067: void vTaskSuspendAll( void )
                           2239 ;	-----------------------------------------
                           2240 ;	 function vTaskSuspendAll
                           2241 ;	-----------------------------------------
   0E2C                    2242 _vTaskSuspendAll:
                           2243 ;	../../FreeRTOS/Source/tasks.c:1069: portENTER_CRITICAL();
                           2244 ;	genInline
   0E2C C0 E0 C0 A8        2245 	 push ACC push IE 
                           2246 ;	genAssign
   0E30 C2 AF              2247 	clr	_EA
                           2248 ;	../../FreeRTOS/Source/tasks.c:1070: ++uxSchedulerSuspended;
                           2249 ;	genPlus
   0E32 90 F0 7F           2250 	mov	dptr,#_uxSchedulerSuspended
   0E35 E0                 2251 	movx	a,@dptr
   0E36 24 01              2252 	add	a,#0x01
   0E38 F0                 2253 	movx	@dptr,a
                           2254 ;	../../FreeRTOS/Source/tasks.c:1071: portEXIT_CRITICAL();
                           2255 ;	genInline
   0E39 D0 E0              2256 	 pop ACC 
                           2257 ;	genAnd
   0E3B 53 E0 80           2258 	anl	_ACC,#0x80
                           2259 ;	genOr
   0E3E E5 E0              2260 	mov	a,_ACC
   0E40 42 A8              2261 	orl	_IE,a
                           2262 ;	genInline
   0E42 D0 E0              2263 	 pop ACC 
                           2264 ;	Peephole 300	removed redundant label 00101$
   0E44 22                 2265 	ret
                           2266 ;------------------------------------------------------------
                           2267 ;Allocation info for local variables in function 'xTaskResumeAll'
                           2268 ;------------------------------------------------------------
                           2269 ;pxTCB                     Allocated to registers r7 r3 r2 
                           2270 ;xAlreadyYielded           Allocated to stack - offset 1
                           2271 ;xYieldRequired            Allocated to stack - offset 2
                           2272 ;sloc0                     Allocated to stack - offset 3
                           2273 ;sloc1                     Allocated to stack - offset 4
                           2274 ;------------------------------------------------------------
                           2275 ;	../../FreeRTOS/Source/tasks.c:1075: signed portBASE_TYPE xTaskResumeAll( void )
                           2276 ;	-----------------------------------------
                           2277 ;	 function xTaskResumeAll
                           2278 ;	-----------------------------------------
   0E45                    2279 _xTaskResumeAll:
   0E45 C0 10              2280 	push	_bp
                           2281 ;	peephole 177.h	optimized mov sequence
   0E47 E5 81              2282 	mov	a,sp
   0E49 F5 10              2283 	mov	_bp,a
   0E4B 24 06              2284 	add	a,#0x06
   0E4D F5 81              2285 	mov	sp,a
                           2286 ;	../../FreeRTOS/Source/tasks.c:1078: signed portBASE_TYPE xAlreadyYielded = pdFALSE;
                           2287 ;	genAssign
   0E4F A8 10              2288 	mov	r0,_bp
   0E51 08                 2289 	inc	r0
   0E52 76 00              2290 	mov	@r0,#0x00
                           2291 ;	../../FreeRTOS/Source/tasks.c:1085: portENTER_CRITICAL();
                           2292 ;	genInline
   0E54 C0 E0 C0 A8        2293 	 push ACC push IE 
                           2294 ;	genAssign
   0E58 C2 AF              2295 	clr	_EA
                           2296 ;	../../FreeRTOS/Source/tasks.c:1087: --uxSchedulerSuspended;
                           2297 ;	genMinus
   0E5A 90 F0 7F           2298 	mov	dptr,#_uxSchedulerSuspended
                           2299 ;	genMinusDec
   0E5D E0                 2300 	movx	a,@dptr
   0E5E 14                 2301 	dec	a
                           2302 ;	genAssign
   0E5F 90 F0 7F           2303 	mov	dptr,#_uxSchedulerSuspended
   0E62 F0                 2304 	movx	@dptr,a
                           2305 ;	../../FreeRTOS/Source/tasks.c:1089: if( uxSchedulerSuspended == ( unsigned portBASE_TYPE ) pdFALSE )
                           2306 ;	genAssign
   0E63 90 F0 7F           2307 	mov	dptr,#_uxSchedulerSuspended
   0E66 E0                 2308 	movx	a,@dptr
                           2309 ;	genIfx
   0E67 FB                 2310 	mov	r3,a
                           2311 ;	Peephole 105	removed redundant mov
                           2312 ;	genIfxJump
   0E68 60 03              2313 	jz	00134$
   0E6A 02 10 1D           2314 	ljmp	00119$
   0E6D                    2315 00134$:
                           2316 ;	../../FreeRTOS/Source/tasks.c:1091: if( uxCurrentNumberOfTasks > ( unsigned portBASE_TYPE ) 0 )
                           2317 ;	genAssign
   0E6D 90 F0 79           2318 	mov	dptr,#_uxCurrentNumberOfTasks
   0E70 E0                 2319 	movx	a,@dptr
                           2320 ;	genIfx
   0E71 FB                 2321 	mov	r3,a
                           2322 ;	Peephole 105	removed redundant mov
                           2323 ;	genIfxJump
   0E72 70 03              2324 	jnz	00135$
   0E74 02 10 1D           2325 	ljmp	00119$
   0E77                    2326 00135$:
                           2327 ;	../../FreeRTOS/Source/tasks.c:1093: portBASE_TYPE xYieldRequired = pdFALSE;
                           2328 ;	genAssign
   0E77 A8 10              2329 	mov	r0,_bp
   0E79 08                 2330 	inc	r0
   0E7A 08                 2331 	inc	r0
   0E7B 76 00              2332 	mov	@r0,#0x00
                           2333 ;	../../FreeRTOS/Source/tasks.c:1097: while( ( pxTCB = ( tskTCB * ) listGET_OWNER_OF_HEAD_ENTRY(  ( ( xList * ) &xPendingReadyList ) ) ) != NULL )
   0E7D                    2334 00105$:
                           2335 ;	genPointerGet
                           2336 ;	genFarPointerGet
   0E7D 90 E0 54           2337 	mov	dptr,#_xPendingReadyList
   0E80 E0                 2338 	movx	a,@dptr
   0E81 FC                 2339 	mov	r4,a
                           2340 ;	genCmpEq
                           2341 ;	gencjne
                           2342 ;	gencjneshort
                           2343 ;	Peephole 241.d	optimized compare
   0E82 E4                 2344 	clr	a
   0E83 BC 00 01           2345 	cjne	r4,#0x00,00136$
   0E86 04                 2346 	inc	a
   0E87                    2347 00136$:
                           2348 ;	Peephole 300	removed redundant label 00137$
                           2349 ;	genNot
   0E87 FC                 2350 	mov	r4,a
                           2351 ;	Peephole 105	removed redundant mov
   0E88 B4 01 00           2352 	cjne	a,#0x01,00138$
   0E8B                    2353 00138$:
   0E8B E4                 2354 	clr	a
   0E8C 33                 2355 	rlc	a
                           2356 ;	genIfx
   0E8D FC                 2357 	mov	r4,a
                           2358 ;	Peephole 105	removed redundant mov
                           2359 ;	genIfxJump
                           2360 ;	Peephole 108.c	removed ljmp by inverse jump logic
   0E8E 60 31              2361 	jz	00122$
                           2362 ;	Peephole 300	removed redundant label 00139$
                           2363 ;	genPointerGet
                           2364 ;	genGenPointerGet
   0E90 90 E0 5A           2365 	mov	dptr,#(_xPendingReadyList + 0x0006)
   0E93 75 F0 00           2366 	mov	b,#0x00
   0E96 12 E4 9F           2367 	lcall	__gptrget
   0E99 FC                 2368 	mov	r4,a
   0E9A A3                 2369 	inc	dptr
   0E9B 12 E4 9F           2370 	lcall	__gptrget
   0E9E FD                 2371 	mov	r5,a
   0E9F A3                 2372 	inc	dptr
   0EA0 12 E4 9F           2373 	lcall	__gptrget
   0EA3 FE                 2374 	mov	r6,a
                           2375 ;	genPlus
                           2376 ;     genPlusIncr
   0EA4 74 08              2377 	mov	a,#0x08
                           2378 ;	Peephole 236.a	used r4 instead of ar4
   0EA6 2C                 2379 	add	a,r4
   0EA7 FC                 2380 	mov	r4,a
                           2381 ;	Peephole 181	changed mov to clr
   0EA8 E4                 2382 	clr	a
                           2383 ;	Peephole 236.b	used r5 instead of ar5
   0EA9 3D                 2384 	addc	a,r5
   0EAA FD                 2385 	mov	r5,a
                           2386 ;	genPointerGet
                           2387 ;	genGenPointerGet
   0EAB 8C 82              2388 	mov	dpl,r4
   0EAD 8D 83              2389 	mov	dph,r5
   0EAF 8E F0              2390 	mov	b,r6
   0EB1 12 E4 9F           2391 	lcall	__gptrget
   0EB4 FC                 2392 	mov	r4,a
   0EB5 A3                 2393 	inc	dptr
   0EB6 12 E4 9F           2394 	lcall	__gptrget
   0EB9 FD                 2395 	mov	r5,a
   0EBA A3                 2396 	inc	dptr
   0EBB 12 E4 9F           2397 	lcall	__gptrget
   0EBE FE                 2398 	mov	r6,a
                           2399 ;	Peephole 112.b	changed ljmp to sjmp
   0EBF 80 06              2400 	sjmp	00123$
   0EC1                    2401 00122$:
                           2402 ;	genAssign
   0EC1 7C 00              2403 	mov	r4,#0x00
   0EC3 7D 00              2404 	mov	r5,#0x00
   0EC5 7E 00              2405 	mov	r6,#0x00
   0EC7                    2406 00123$:
                           2407 ;	genAssign
                           2408 ;	genAssign
   0EC7 8C 07              2409 	mov	ar7,r4
   0EC9 8D 03              2410 	mov	ar3,r5
   0ECB 8E 02              2411 	mov	ar2,r6
                           2412 ;	genCmpEq
                           2413 ;	gencjneshort
   0ECD BC 00 09           2414 	cjne	r4,#0x00,00140$
   0ED0 BD 00 06           2415 	cjne	r5,#0x00,00140$
   0ED3 BE 00 03           2416 	cjne	r6,#0x00,00140$
   0ED6 02 0F DD           2417 	ljmp	00107$
   0ED9                    2418 00140$:
                           2419 ;	../../FreeRTOS/Source/tasks.c:1099: vListRemove( &( pxTCB->xEventListItem ) );
                           2420 ;	genPlus
                           2421 ;     genPlusIncr
   0ED9 74 11              2422 	mov	a,#0x11
                           2423 ;	Peephole 236.a	used r7 instead of ar7
   0EDB 2F                 2424 	add	a,r7
   0EDC FC                 2425 	mov	r4,a
                           2426 ;	Peephole 181	changed mov to clr
   0EDD E4                 2427 	clr	a
                           2428 ;	Peephole 236.b	used r3 instead of ar3
   0EDE 3B                 2429 	addc	a,r3
   0EDF FD                 2430 	mov	r5,a
   0EE0 8A 06              2431 	mov	ar6,r2
                           2432 ;	genCall
   0EE2 8C 82              2433 	mov	dpl,r4
   0EE4 8D 83              2434 	mov	dph,r5
   0EE6 8E F0              2435 	mov	b,r6
   0EE8 C0 02              2436 	push	ar2
   0EEA C0 03              2437 	push	ar3
   0EEC C0 07              2438 	push	ar7
   0EEE 12 2F 88           2439 	lcall	_vListRemove
   0EF1 D0 07              2440 	pop	ar7
   0EF3 D0 03              2441 	pop	ar3
   0EF5 D0 02              2442 	pop	ar2
                           2443 ;	../../FreeRTOS/Source/tasks.c:1100: vListRemove( &( pxTCB->xGenericListItem ) );
                           2444 ;	genPlus
                           2445 ;     genPlusIncr
   0EF7 74 03              2446 	mov	a,#0x03
                           2447 ;	Peephole 236.a	used r7 instead of ar7
   0EF9 2F                 2448 	add	a,r7
   0EFA FC                 2449 	mov	r4,a
                           2450 ;	Peephole 181	changed mov to clr
   0EFB E4                 2451 	clr	a
                           2452 ;	Peephole 236.b	used r3 instead of ar3
   0EFC 3B                 2453 	addc	a,r3
   0EFD FD                 2454 	mov	r5,a
   0EFE 8A 06              2455 	mov	ar6,r2
                           2456 ;	genCall
   0F00 8C 82              2457 	mov	dpl,r4
   0F02 8D 83              2458 	mov	dph,r5
   0F04 8E F0              2459 	mov	b,r6
   0F06 C0 02              2460 	push	ar2
   0F08 C0 03              2461 	push	ar3
   0F0A C0 07              2462 	push	ar7
   0F0C 12 2F 88           2463 	lcall	_vListRemove
   0F0F D0 07              2464 	pop	ar7
   0F11 D0 03              2465 	pop	ar3
   0F13 D0 02              2466 	pop	ar2
                           2467 ;	../../FreeRTOS/Source/tasks.c:1101: prvAddTaskToReadyQueue( pxTCB );
                           2468 ;	genPlus
                           2469 ;     genPlusIncr
   0F15 74 1F              2470 	mov	a,#0x1F
                           2471 ;	Peephole 236.a	used r7 instead of ar7
   0F17 2F                 2472 	add	a,r7
   0F18 FC                 2473 	mov	r4,a
                           2474 ;	Peephole 181	changed mov to clr
   0F19 E4                 2475 	clr	a
                           2476 ;	Peephole 236.b	used r3 instead of ar3
   0F1A 3B                 2477 	addc	a,r3
   0F1B FD                 2478 	mov	r5,a
   0F1C 8A 06              2479 	mov	ar6,r2
                           2480 ;	genPointerGet
                           2481 ;	genGenPointerGet
   0F1E 8C 82              2482 	mov	dpl,r4
   0F20 8D 83              2483 	mov	dph,r5
   0F22 8E F0              2484 	mov	b,r6
   0F24 A8 10              2485 	mov	r0,_bp
   0F26 08                 2486 	inc	r0
   0F27 08                 2487 	inc	r0
   0F28 08                 2488 	inc	r0
   0F29 12 E4 9F           2489 	lcall	__gptrget
   0F2C F6                 2490 	mov	@r0,a
                           2491 ;	genIpush
   0F2D C0 07              2492 	push	ar7
   0F2F C0 03              2493 	push	ar3
   0F31 C0 02              2494 	push	ar2
                           2495 ;	genAssign
   0F33 90 F0 7D           2496 	mov	dptr,#_uxTopReadyPriority
   0F36 E0                 2497 	movx	a,@dptr
   0F37 FA                 2498 	mov	r2,a
                           2499 ;	genCmpGt
   0F38 A8 10              2500 	mov	r0,_bp
   0F3A 08                 2501 	inc	r0
   0F3B 08                 2502 	inc	r0
   0F3C 08                 2503 	inc	r0
                           2504 ;	genCmp
   0F3D C3                 2505 	clr	c
   0F3E EA                 2506 	mov	a,r2
   0F3F 96                 2507 	subb	a,@r0
   0F40 E4                 2508 	clr	a
   0F41 33                 2509 	rlc	a
                           2510 ;	genIpop
   0F42 D0 02              2511 	pop	ar2
   0F44 D0 03              2512 	pop	ar3
   0F46 D0 07              2513 	pop	ar7
                           2514 ;	genIfx
                           2515 ;	genIfxJump
                           2516 ;	Peephole 108.c	removed ljmp by inverse jump logic
   0F48 60 0A              2517 	jz	00102$
                           2518 ;	Peephole 300	removed redundant label 00141$
                           2519 ;	genAssign
   0F4A A8 10              2520 	mov	r0,_bp
   0F4C 08                 2521 	inc	r0
   0F4D 08                 2522 	inc	r0
   0F4E 08                 2523 	inc	r0
   0F4F 90 F0 7D           2524 	mov	dptr,#_uxTopReadyPriority
   0F52 E6                 2525 	mov	a,@r0
   0F53 F0                 2526 	movx	@dptr,a
   0F54                    2527 00102$:
                           2528 ;	genPlus
   0F54 E5 10              2529 	mov	a,_bp
   0F56 24 04              2530 	add	a,#0x04
   0F58 F8                 2531 	mov	r0,a
                           2532 ;     genPlusIncr
   0F59 74 03              2533 	mov	a,#0x03
                           2534 ;	Peephole 236.a	used r7 instead of ar7
   0F5B 2F                 2535 	add	a,r7
   0F5C F6                 2536 	mov	@r0,a
                           2537 ;	Peephole 181	changed mov to clr
   0F5D E4                 2538 	clr	a
                           2539 ;	Peephole 236.b	used r3 instead of ar3
   0F5E 3B                 2540 	addc	a,r3
   0F5F 08                 2541 	inc	r0
   0F60 F6                 2542 	mov	@r0,a
   0F61 08                 2543 	inc	r0
   0F62 A6 02              2544 	mov	@r0,ar2
                           2545 ;	genPointerGet
                           2546 ;	genGenPointerGet
   0F64 8C 82              2547 	mov	dpl,r4
   0F66 8D 83              2548 	mov	dph,r5
   0F68 8E F0              2549 	mov	b,r6
   0F6A 12 E4 9F           2550 	lcall	__gptrget
                           2551 ;	genMult
                           2552 ;	genMultOneByte
   0F6D FA                 2553 	mov	r2,a
                           2554 ;	Peephole 105	removed redundant mov
   0F6E 75 F0 0C           2555 	mov	b,#0x0C
   0F71 A4                 2556 	mul	ab
                           2557 ;	genPlus
   0F72 24 06              2558 	add	a,#_pxReadyTasksLists
   0F74 FA                 2559 	mov	r2,a
                           2560 ;	Peephole 240	use clr instead of addc a,#0
   0F75 E4                 2561 	clr	a
   0F76 34 E0              2562 	addc	a,#(_pxReadyTasksLists >> 8)
   0F78 FB                 2563 	mov	r3,a
                           2564 ;	genCast
   0F79 7F 00              2565 	mov	r7,#0x0
                           2566 ;	genIpush
   0F7B C0 04              2567 	push	ar4
   0F7D C0 05              2568 	push	ar5
   0F7F C0 06              2569 	push	ar6
   0F81 E5 10              2570 	mov	a,_bp
   0F83 24 04              2571 	add	a,#0x04
   0F85 F8                 2572 	mov	r0,a
   0F86 E6                 2573 	mov	a,@r0
   0F87 C0 E0              2574 	push	acc
   0F89 08                 2575 	inc	r0
   0F8A E6                 2576 	mov	a,@r0
   0F8B C0 E0              2577 	push	acc
   0F8D 08                 2578 	inc	r0
   0F8E E6                 2579 	mov	a,@r0
   0F8F C0 E0              2580 	push	acc
                           2581 ;	genCall
   0F91 8A 82              2582 	mov	dpl,r2
   0F93 8B 83              2583 	mov	dph,r3
   0F95 8F F0              2584 	mov	b,r7
   0F97 12 2B 96           2585 	lcall	_vListInsertEnd
   0F9A 15 81              2586 	dec	sp
   0F9C 15 81              2587 	dec	sp
   0F9E 15 81              2588 	dec	sp
   0FA0 D0 06              2589 	pop	ar6
   0FA2 D0 05              2590 	pop	ar5
   0FA4 D0 04              2591 	pop	ar4
                           2592 ;	../../FreeRTOS/Source/tasks.c:1105: if( pxTCB->uxPriority >= pxCurrentTCB->uxPriority )
                           2593 ;	genPointerGet
                           2594 ;	genGenPointerGet
   0FA6 8C 82              2595 	mov	dpl,r4
   0FA8 8D 83              2596 	mov	dph,r5
   0FAA 8E F0              2597 	mov	b,r6
   0FAC 12 E4 9F           2598 	lcall	__gptrget
   0FAF FC                 2599 	mov	r4,a
                           2600 ;	genAssign
   0FB0 90 F0 75           2601 	mov	dptr,#_pxCurrentTCB
   0FB3 E0                 2602 	movx	a,@dptr
   0FB4 FA                 2603 	mov	r2,a
   0FB5 A3                 2604 	inc	dptr
   0FB6 E0                 2605 	movx	a,@dptr
   0FB7 FB                 2606 	mov	r3,a
   0FB8 A3                 2607 	inc	dptr
   0FB9 E0                 2608 	movx	a,@dptr
   0FBA FD                 2609 	mov	r5,a
                           2610 ;	genPlus
                           2611 ;     genPlusIncr
   0FBB 74 1F              2612 	mov	a,#0x1F
                           2613 ;	Peephole 236.a	used r2 instead of ar2
   0FBD 2A                 2614 	add	a,r2
   0FBE FA                 2615 	mov	r2,a
                           2616 ;	Peephole 181	changed mov to clr
   0FBF E4                 2617 	clr	a
                           2618 ;	Peephole 236.b	used r3 instead of ar3
   0FC0 3B                 2619 	addc	a,r3
   0FC1 FB                 2620 	mov	r3,a
                           2621 ;	genPointerGet
                           2622 ;	genGenPointerGet
   0FC2 8A 82              2623 	mov	dpl,r2
   0FC4 8B 83              2624 	mov	dph,r3
   0FC6 8D F0              2625 	mov	b,r5
   0FC8 12 E4 9F           2626 	lcall	__gptrget
   0FCB FA                 2627 	mov	r2,a
                           2628 ;	genCmpLt
                           2629 ;	genCmp
   0FCC C3                 2630 	clr	c
   0FCD EC                 2631 	mov	a,r4
   0FCE 9A                 2632 	subb	a,r2
                           2633 ;	genIfxJump
   0FCF 50 03              2634 	jnc	00142$
   0FD1 02 0E 7D           2635 	ljmp	00105$
   0FD4                    2636 00142$:
                           2637 ;	../../FreeRTOS/Source/tasks.c:1107: xYieldRequired = pdTRUE;
                           2638 ;	genAssign
   0FD4 A8 10              2639 	mov	r0,_bp
   0FD6 08                 2640 	inc	r0
   0FD7 08                 2641 	inc	r0
   0FD8 76 01              2642 	mov	@r0,#0x01
   0FDA 02 0E 7D           2643 	ljmp	00105$
   0FDD                    2644 00107$:
                           2645 ;	../../FreeRTOS/Source/tasks.c:1114: if( uxMissedTicks > ( unsigned portBASE_TYPE ) 0 )
                           2646 ;	genAssign
   0FDD 90 F0 80           2647 	mov	dptr,#_uxMissedTicks
   0FE0 E0                 2648 	movx	a,@dptr
                           2649 ;	genIfx
   0FE1 FA                 2650 	mov	r2,a
                           2651 ;	Peephole 105	removed redundant mov
                           2652 ;	genIfxJump
                           2653 ;	Peephole 108.c	removed ljmp by inverse jump logic
   0FE2 60 1B              2654 	jz	00112$
                           2655 ;	Peephole 300	removed redundant label 00143$
                           2656 ;	../../FreeRTOS/Source/tasks.c:1116: while( uxMissedTicks > ( unsigned portBASE_TYPE ) 0 )
   0FE4                    2657 00108$:
                           2658 ;	genAssign
   0FE4 90 F0 80           2659 	mov	dptr,#_uxMissedTicks
   0FE7 E0                 2660 	movx	a,@dptr
                           2661 ;	genIfx
   0FE8 FA                 2662 	mov	r2,a
                           2663 ;	Peephole 105	removed redundant mov
                           2664 ;	genIfxJump
                           2665 ;	Peephole 108.c	removed ljmp by inverse jump logic
   0FE9 60 0E              2666 	jz	00110$
                           2667 ;	Peephole 300	removed redundant label 00144$
                           2668 ;	../../FreeRTOS/Source/tasks.c:1118: vTaskIncrementTick();
                           2669 ;	genCall
   0FEB 12 10 6A           2670 	lcall	_vTaskIncrementTick
                           2671 ;	../../FreeRTOS/Source/tasks.c:1119: --uxMissedTicks;
                           2672 ;	genMinus
   0FEE 90 F0 80           2673 	mov	dptr,#_uxMissedTicks
                           2674 ;	genMinusDec
   0FF1 E0                 2675 	movx	a,@dptr
   0FF2 14                 2676 	dec	a
                           2677 ;	genAssign
   0FF3 90 F0 80           2678 	mov	dptr,#_uxMissedTicks
   0FF6 F0                 2679 	movx	@dptr,a
                           2680 ;	Peephole 112.b	changed ljmp to sjmp
   0FF7 80 EB              2681 	sjmp	00108$
   0FF9                    2682 00110$:
                           2683 ;	../../FreeRTOS/Source/tasks.c:1125: xYieldRequired = pdTRUE;
                           2684 ;	genAssign
   0FF9 A8 10              2685 	mov	r0,_bp
   0FFB 08                 2686 	inc	r0
   0FFC 08                 2687 	inc	r0
   0FFD 76 01              2688 	mov	@r0,#0x01
   0FFF                    2689 00112$:
                           2690 ;	../../FreeRTOS/Source/tasks.c:1128: if( ( xYieldRequired == pdTRUE ) || ( xMissedYield == pdTRUE ) )
                           2691 ;	genCmpEq
   0FFF A8 10              2692 	mov	r0,_bp
   1001 08                 2693 	inc	r0
   1002 08                 2694 	inc	r0
                           2695 ;	gencjneshort
   1003 B6 01 02           2696 	cjne	@r0,#0x01,00145$
                           2697 ;	Peephole 112.b	changed ljmp to sjmp
   1006 80 08              2698 	sjmp	00113$
   1008                    2699 00145$:
                           2700 ;	genAssign
   1008 90 F0 81           2701 	mov	dptr,#_xMissedYield
   100B E0                 2702 	movx	a,@dptr
   100C FA                 2703 	mov	r2,a
                           2704 ;	genCmpEq
                           2705 ;	gencjneshort
                           2706 ;	Peephole 112.b	changed ljmp to sjmp
                           2707 ;	Peephole 198.b	optimized misc jump sequence
   100D BA 01 0D           2708 	cjne	r2,#0x01,00119$
                           2709 ;	Peephole 200.b	removed redundant sjmp
                           2710 ;	Peephole 300	removed redundant label 00146$
                           2711 ;	Peephole 300	removed redundant label 00147$
   1010                    2712 00113$:
                           2713 ;	../../FreeRTOS/Source/tasks.c:1130: xAlreadyYielded = pdTRUE;
                           2714 ;	genAssign
   1010 A8 10              2715 	mov	r0,_bp
   1012 08                 2716 	inc	r0
   1013 76 01              2717 	mov	@r0,#0x01
                           2718 ;	../../FreeRTOS/Source/tasks.c:1131: xMissedYield = pdFALSE;
                           2719 ;	genAssign
   1015 90 F0 81           2720 	mov	dptr,#_xMissedYield
                           2721 ;	Peephole 181	changed mov to clr
   1018 E4                 2722 	clr	a
   1019 F0                 2723 	movx	@dptr,a
                           2724 ;	../../FreeRTOS/Source/tasks.c:1132: taskYIELD();
                           2725 ;	genCall
   101A 12 33 E8           2726 	lcall	_vPortYield
   101D                    2727 00119$:
                           2728 ;	../../FreeRTOS/Source/tasks.c:1137: portEXIT_CRITICAL();
                           2729 ;	genInline
   101D D0 E0              2730 	 pop ACC 
                           2731 ;	genAnd
   101F 53 E0 80           2732 	anl	_ACC,#0x80
                           2733 ;	genOr
   1022 E5 E0              2734 	mov	a,_ACC
   1024 42 A8              2735 	orl	_IE,a
                           2736 ;	genInline
   1026 D0 E0              2737 	 pop ACC 
                           2738 ;	../../FreeRTOS/Source/tasks.c:1139: return xAlreadyYielded;
                           2739 ;	genRet
   1028 A8 10              2740 	mov	r0,_bp
   102A 08                 2741 	inc	r0
   102B 86 82              2742 	mov	dpl,@r0
                           2743 ;	Peephole 300	removed redundant label 00120$
   102D 85 10 81           2744 	mov	sp,_bp
   1030 D0 10              2745 	pop	_bp
   1032 22                 2746 	ret
                           2747 ;------------------------------------------------------------
                           2748 ;Allocation info for local variables in function 'xTaskGetTickCount'
                           2749 ;------------------------------------------------------------
                           2750 ;xTicks                    Allocated to registers r2 r3 
                           2751 ;------------------------------------------------------------
                           2752 ;	../../FreeRTOS/Source/tasks.c:1153: portTickType xTaskGetTickCount( void )
                           2753 ;	-----------------------------------------
                           2754 ;	 function xTaskGetTickCount
                           2755 ;	-----------------------------------------
   1033                    2756 _xTaskGetTickCount:
                           2757 ;	../../FreeRTOS/Source/tasks.c:1158: taskENTER_CRITICAL();
                           2758 ;	genInline
   1033 C0 E0 C0 A8        2759 	 push ACC push IE 
                           2760 ;	genAssign
   1037 C2 AF              2761 	clr	_EA
                           2762 ;	../../FreeRTOS/Source/tasks.c:1160: xTicks = xTickCount;
                           2763 ;	genAssign
   1039 90 F0 7A           2764 	mov	dptr,#_xTickCount
   103C E0                 2765 	movx	a,@dptr
   103D FA                 2766 	mov	r2,a
   103E A3                 2767 	inc	dptr
   103F E0                 2768 	movx	a,@dptr
   1040 FB                 2769 	mov	r3,a
                           2770 ;	genAssign
                           2771 ;	../../FreeRTOS/Source/tasks.c:1162: taskEXIT_CRITICAL();
                           2772 ;	genInline
   1041 D0 E0              2773 	 pop ACC 
                           2774 ;	genAnd
   1043 53 E0 80           2775 	anl	_ACC,#0x80
                           2776 ;	genOr
   1046 E5 E0              2777 	mov	a,_ACC
   1048 42 A8              2778 	orl	_IE,a
                           2779 ;	genInline
   104A D0 E0              2780 	 pop ACC 
                           2781 ;	../../FreeRTOS/Source/tasks.c:1164: return xTicks;
                           2782 ;	genRet
   104C 8A 82              2783 	mov	dpl,r2
   104E 8B 83              2784 	mov	dph,r3
                           2785 ;	Peephole 300	removed redundant label 00101$
   1050 22                 2786 	ret
                           2787 ;------------------------------------------------------------
                           2788 ;Allocation info for local variables in function 'uxTaskGetNumberOfTasks'
                           2789 ;------------------------------------------------------------
                           2790 ;uxNumberOfTasks           Allocated to registers r2 
                           2791 ;------------------------------------------------------------
                           2792 ;	../../FreeRTOS/Source/tasks.c:1168: unsigned portBASE_TYPE uxTaskGetNumberOfTasks( void )
                           2793 ;	-----------------------------------------
                           2794 ;	 function uxTaskGetNumberOfTasks
                           2795 ;	-----------------------------------------
   1051                    2796 _uxTaskGetNumberOfTasks:
                           2797 ;	../../FreeRTOS/Source/tasks.c:1172: taskENTER_CRITICAL();
                           2798 ;	genInline
   1051 C0 E0 C0 A8        2799 	 push ACC push IE 
                           2800 ;	genAssign
   1055 C2 AF              2801 	clr	_EA
                           2802 ;	../../FreeRTOS/Source/tasks.c:1173: uxNumberOfTasks = uxCurrentNumberOfTasks;
                           2803 ;	genAssign
   1057 90 F0 79           2804 	mov	dptr,#_uxCurrentNumberOfTasks
   105A E0                 2805 	movx	a,@dptr
   105B FA                 2806 	mov	r2,a
                           2807 ;	genAssign
                           2808 ;	../../FreeRTOS/Source/tasks.c:1174: taskEXIT_CRITICAL();
                           2809 ;	genInline
   105C D0 E0              2810 	 pop ACC 
                           2811 ;	genAnd
   105E 53 E0 80           2812 	anl	_ACC,#0x80
                           2813 ;	genOr
   1061 E5 E0              2814 	mov	a,_ACC
   1063 42 A8              2815 	orl	_IE,a
                           2816 ;	genInline
   1065 D0 E0              2817 	 pop ACC 
                           2818 ;	../../FreeRTOS/Source/tasks.c:1176: return uxNumberOfTasks;
                           2819 ;	genRet
   1067 8A 82              2820 	mov	dpl,r2
                           2821 ;	Peephole 300	removed redundant label 00101$
   1069 22                 2822 	ret
                           2823 ;------------------------------------------------------------
                           2824 ;Allocation info for local variables in function 'vTaskIncrementTick'
                           2825 ;------------------------------------------------------------
                           2826 ;pxTemp                    Allocated to registers r2 r3 r4 
                           2827 ;pxTCB                     Allocated to registers r5 r6 r7 
                           2828 ;sloc0                     Allocated to stack - offset 1
                           2829 ;------------------------------------------------------------
                           2830 ;	../../FreeRTOS/Source/tasks.c:1277: inline void vTaskIncrementTick( void )
                           2831 ;	-----------------------------------------
                           2832 ;	 function vTaskIncrementTick
                           2833 ;	-----------------------------------------
   106A                    2834 _vTaskIncrementTick:
   106A C0 10              2835 	push	_bp
   106C 85 81 10           2836 	mov	_bp,sp
   106F 05 81              2837 	inc	sp
                           2838 ;	../../FreeRTOS/Source/tasks.c:1282: if( uxSchedulerSuspended == ( unsigned portBASE_TYPE ) pdFALSE )
                           2839 ;	genAssign
   1071 90 F0 7F           2840 	mov	dptr,#_uxSchedulerSuspended
   1074 E0                 2841 	movx	a,@dptr
                           2842 ;	genIfx
   1075 FA                 2843 	mov	r2,a
                           2844 ;	Peephole 105	removed redundant mov
                           2845 ;	genIfxJump
   1076 60 03              2846 	jz	00130$
   1078 02 12 5B           2847 	ljmp	00113$
   107B                    2848 00130$:
                           2849 ;	../../FreeRTOS/Source/tasks.c:1284: ++xTickCount;
                           2850 ;	genPlus
   107B 90 F0 7A           2851 	mov	dptr,#_xTickCount
   107E E0                 2852 	movx	a,@dptr
   107F 24 01              2853 	add	a,#0x01
   1081 F0                 2854 	movx	@dptr,a
   1082 A3                 2855 	inc	dptr
   1083 E0                 2856 	movx	a,@dptr
   1084 34 00              2857 	addc	a,#0x00
   1086 F0                 2858 	movx	@dptr,a
                           2859 ;	../../FreeRTOS/Source/tasks.c:1285: if( xTickCount == ( portTickType ) 0 )
                           2860 ;	genAssign
   1087 90 F0 7A           2861 	mov	dptr,#_xTickCount
   108A E0                 2862 	movx	a,@dptr
   108B FA                 2863 	mov	r2,a
   108C A3                 2864 	inc	dptr
   108D E0                 2865 	movx	a,@dptr
                           2866 ;	genIfx
   108E FB                 2867 	mov	r3,a
                           2868 ;	Peephole 135	removed redundant mov
   108F 4A                 2869 	orl	a,r2
                           2870 ;	genIfxJump
                           2871 ;	Peephole 108.b	removed ljmp by inverse jump logic
   1090 70 33              2872 	jnz	00109$
                           2873 ;	Peephole 300	removed redundant label 00131$
                           2874 ;	../../FreeRTOS/Source/tasks.c:1292: pxTemp = pxDelayedTaskList;
                           2875 ;	genAssign
   1092 90 E0 4E           2876 	mov	dptr,#_pxDelayedTaskList
   1095 E0                 2877 	movx	a,@dptr
   1096 FA                 2878 	mov	r2,a
   1097 A3                 2879 	inc	dptr
   1098 E0                 2880 	movx	a,@dptr
   1099 FB                 2881 	mov	r3,a
   109A A3                 2882 	inc	dptr
   109B E0                 2883 	movx	a,@dptr
   109C FC                 2884 	mov	r4,a
                           2885 ;	genAssign
                           2886 ;	../../FreeRTOS/Source/tasks.c:1293: pxDelayedTaskList = pxOverflowDelayedTaskList;
                           2887 ;	genAssign
   109D 90 E0 51           2888 	mov	dptr,#_pxOverflowDelayedTaskList
   10A0 E0                 2889 	movx	a,@dptr
   10A1 FD                 2890 	mov	r5,a
   10A2 A3                 2891 	inc	dptr
   10A3 E0                 2892 	movx	a,@dptr
   10A4 FE                 2893 	mov	r6,a
   10A5 A3                 2894 	inc	dptr
   10A6 E0                 2895 	movx	a,@dptr
   10A7 FF                 2896 	mov	r7,a
                           2897 ;	genAssign
   10A8 90 E0 4E           2898 	mov	dptr,#_pxDelayedTaskList
   10AB ED                 2899 	mov	a,r5
   10AC F0                 2900 	movx	@dptr,a
   10AD A3                 2901 	inc	dptr
   10AE EE                 2902 	mov	a,r6
   10AF F0                 2903 	movx	@dptr,a
   10B0 A3                 2904 	inc	dptr
   10B1 EF                 2905 	mov	a,r7
   10B2 F0                 2906 	movx	@dptr,a
                           2907 ;	../../FreeRTOS/Source/tasks.c:1294: pxOverflowDelayedTaskList = pxTemp;
                           2908 ;	genAssign
   10B3 90 E0 51           2909 	mov	dptr,#_pxOverflowDelayedTaskList
   10B6 EA                 2910 	mov	a,r2
   10B7 F0                 2911 	movx	@dptr,a
   10B8 A3                 2912 	inc	dptr
   10B9 EB                 2913 	mov	a,r3
   10BA F0                 2914 	movx	@dptr,a
   10BB A3                 2915 	inc	dptr
   10BC EC                 2916 	mov	a,r4
   10BD F0                 2917 	movx	@dptr,a
                           2918 ;	../../FreeRTOS/Source/tasks.c:1295: xNumOfOverflows++;
                           2919 ;	genPlus
   10BE 90 F0 82           2920 	mov	dptr,#_xNumOfOverflows
   10C1 E0                 2921 	movx	a,@dptr
   10C2 24 01              2922 	add	a,#0x01
   10C4 F0                 2923 	movx	@dptr,a
                           2924 ;	../../FreeRTOS/Source/tasks.c:1299: prvCheckDelayedTasks();
   10C5                    2925 00109$:
                           2926 ;	genAssign
   10C5 90 E0 4E           2927 	mov	dptr,#_pxDelayedTaskList
   10C8 E0                 2928 	movx	a,@dptr
   10C9 FA                 2929 	mov	r2,a
   10CA A3                 2930 	inc	dptr
   10CB E0                 2931 	movx	a,@dptr
   10CC FB                 2932 	mov	r3,a
   10CD A3                 2933 	inc	dptr
   10CE E0                 2934 	movx	a,@dptr
   10CF FC                 2935 	mov	r4,a
                           2936 ;	genPointerGet
                           2937 ;	genGenPointerGet
   10D0 8A 82              2938 	mov	dpl,r2
   10D2 8B 83              2939 	mov	dph,r3
   10D4 8C F0              2940 	mov	b,r4
   10D6 12 E4 9F           2941 	lcall	__gptrget
   10D9 FA                 2942 	mov	r2,a
                           2943 ;	genCmpEq
                           2944 ;	gencjne
                           2945 ;	gencjneshort
                           2946 ;	Peephole 241.d	optimized compare
   10DA E4                 2947 	clr	a
   10DB BA 00 01           2948 	cjne	r2,#0x00,00132$
   10DE 04                 2949 	inc	a
   10DF                    2950 00132$:
                           2951 ;	Peephole 300	removed redundant label 00133$
                           2952 ;	genNot
   10DF FA                 2953 	mov	r2,a
                           2954 ;	Peephole 105	removed redundant mov
   10E0 B4 01 00           2955 	cjne	a,#0x01,00134$
   10E3                    2956 00134$:
   10E3 E4                 2957 	clr	a
   10E4 33                 2958 	rlc	a
                           2959 ;	genIfx
   10E5 FA                 2960 	mov	r2,a
                           2961 ;	Peephole 105	removed redundant mov
                           2962 ;	genIfxJump
                           2963 ;	Peephole 108.c	removed ljmp by inverse jump logic
   10E6 60 4A              2964 	jz	00119$
                           2965 ;	Peephole 300	removed redundant label 00135$
                           2966 ;	genAssign
   10E8 90 E0 4E           2967 	mov	dptr,#_pxDelayedTaskList
   10EB E0                 2968 	movx	a,@dptr
   10EC FA                 2969 	mov	r2,a
   10ED A3                 2970 	inc	dptr
   10EE E0                 2971 	movx	a,@dptr
   10EF FB                 2972 	mov	r3,a
   10F0 A3                 2973 	inc	dptr
   10F1 E0                 2974 	movx	a,@dptr
   10F2 FC                 2975 	mov	r4,a
                           2976 ;	genPlus
                           2977 ;     genPlusIncr
   10F3 74 04              2978 	mov	a,#0x04
                           2979 ;	Peephole 236.a	used r2 instead of ar2
   10F5 2A                 2980 	add	a,r2
   10F6 FA                 2981 	mov	r2,a
                           2982 ;	Peephole 181	changed mov to clr
   10F7 E4                 2983 	clr	a
                           2984 ;	Peephole 236.b	used r3 instead of ar3
   10F8 3B                 2985 	addc	a,r3
   10F9 FB                 2986 	mov	r3,a
                           2987 ;	genPlus
                           2988 ;     genPlusIncr
   10FA 74 02              2989 	mov	a,#0x02
                           2990 ;	Peephole 236.a	used r2 instead of ar2
   10FC 2A                 2991 	add	a,r2
   10FD FA                 2992 	mov	r2,a
                           2993 ;	Peephole 181	changed mov to clr
   10FE E4                 2994 	clr	a
                           2995 ;	Peephole 236.b	used r3 instead of ar3
   10FF 3B                 2996 	addc	a,r3
   1100 FB                 2997 	mov	r3,a
                           2998 ;	genPointerGet
                           2999 ;	genGenPointerGet
   1101 8A 82              3000 	mov	dpl,r2
   1103 8B 83              3001 	mov	dph,r3
   1105 8C F0              3002 	mov	b,r4
   1107 12 E4 9F           3003 	lcall	__gptrget
   110A FA                 3004 	mov	r2,a
   110B A3                 3005 	inc	dptr
   110C 12 E4 9F           3006 	lcall	__gptrget
   110F FB                 3007 	mov	r3,a
   1110 A3                 3008 	inc	dptr
   1111 12 E4 9F           3009 	lcall	__gptrget
   1114 FC                 3010 	mov	r4,a
                           3011 ;	genPlus
                           3012 ;     genPlusIncr
   1115 74 08              3013 	mov	a,#0x08
                           3014 ;	Peephole 236.a	used r2 instead of ar2
   1117 2A                 3015 	add	a,r2
   1118 FA                 3016 	mov	r2,a
                           3017 ;	Peephole 181	changed mov to clr
   1119 E4                 3018 	clr	a
                           3019 ;	Peephole 236.b	used r3 instead of ar3
   111A 3B                 3020 	addc	a,r3
   111B FB                 3021 	mov	r3,a
                           3022 ;	genPointerGet
                           3023 ;	genGenPointerGet
   111C 8A 82              3024 	mov	dpl,r2
   111E 8B 83              3025 	mov	dph,r3
   1120 8C F0              3026 	mov	b,r4
   1122 12 E4 9F           3027 	lcall	__gptrget
   1125 FA                 3028 	mov	r2,a
   1126 A3                 3029 	inc	dptr
   1127 12 E4 9F           3030 	lcall	__gptrget
   112A FB                 3031 	mov	r3,a
   112B A3                 3032 	inc	dptr
   112C 12 E4 9F           3033 	lcall	__gptrget
   112F FC                 3034 	mov	r4,a
                           3035 ;	Peephole 112.b	changed ljmp to sjmp
   1130 80 06              3036 	sjmp	00120$
   1132                    3037 00119$:
                           3038 ;	genAssign
   1132 7A 00              3039 	mov	r2,#0x00
   1134 7B 00              3040 	mov	r3,#0x00
   1136 7C 00              3041 	mov	r4,#0x00
   1138                    3042 00120$:
                           3043 ;	genAssign
                           3044 ;	genAssign
   1138 8A 05              3045 	mov	ar5,r2
   113A 8B 06              3046 	mov	ar6,r3
   113C 8C 07              3047 	mov	ar7,r4
                           3048 ;	genCmpEq
                           3049 ;	gencjneshort
   113E BA 00 09           3050 	cjne	r2,#0x00,00136$
   1141 BB 00 06           3051 	cjne	r3,#0x00,00136$
   1144 BC 00 03           3052 	cjne	r4,#0x00,00136$
   1147 02 12 65           3053 	ljmp	00114$
   114A                    3054 00136$:
                           3055 ;	genPlus
                           3056 ;     genPlusIncr
   114A 74 03              3057 	mov	a,#0x03
                           3058 ;	Peephole 236.a	used r5 instead of ar5
   114C 2D                 3059 	add	a,r5
   114D FA                 3060 	mov	r2,a
                           3061 ;	Peephole 181	changed mov to clr
   114E E4                 3062 	clr	a
                           3063 ;	Peephole 236.b	used r6 instead of ar6
   114F 3E                 3064 	addc	a,r6
   1150 FB                 3065 	mov	r3,a
   1151 8F 04              3066 	mov	ar4,r7
                           3067 ;	genPointerGet
                           3068 ;	genGenPointerGet
   1153 8A 82              3069 	mov	dpl,r2
   1155 8B 83              3070 	mov	dph,r3
   1157 8C F0              3071 	mov	b,r4
   1159 12 E4 9F           3072 	lcall	__gptrget
   115C FA                 3073 	mov	r2,a
   115D A3                 3074 	inc	dptr
   115E 12 E4 9F           3075 	lcall	__gptrget
   1161 FB                 3076 	mov	r3,a
                           3077 ;	genIpush
   1162 C0 05              3078 	push	ar5
   1164 C0 06              3079 	push	ar6
   1166 C0 07              3080 	push	ar7
                           3081 ;	genAssign
   1168 90 F0 7A           3082 	mov	dptr,#_xTickCount
   116B E0                 3083 	movx	a,@dptr
   116C FC                 3084 	mov	r4,a
   116D A3                 3085 	inc	dptr
   116E E0                 3086 	movx	a,@dptr
   116F FD                 3087 	mov	r5,a
                           3088 ;	genCmpLt
                           3089 ;	genCmp
   1170 C3                 3090 	clr	c
   1171 EC                 3091 	mov	a,r4
   1172 9A                 3092 	subb	a,r2
   1173 ED                 3093 	mov	a,r5
   1174 9B                 3094 	subb	a,r3
   1175 E4                 3095 	clr	a
   1176 33                 3096 	rlc	a
                           3097 ;	genIpop
   1177 D0 07              3098 	pop	ar7
   1179 D0 06              3099 	pop	ar6
   117B D0 05              3100 	pop	ar5
                           3101 ;	genIfx
                           3102 ;	genIfxJump
   117D 60 03              3103 	jz	00137$
   117F 02 12 65           3104 	ljmp	00114$
   1182                    3105 00137$:
                           3106 ;	genPlus
                           3107 ;     genPlusIncr
   1182 74 03              3108 	mov	a,#0x03
                           3109 ;	Peephole 236.a	used r5 instead of ar5
   1184 2D                 3110 	add	a,r5
   1185 FA                 3111 	mov	r2,a
                           3112 ;	Peephole 181	changed mov to clr
   1186 E4                 3113 	clr	a
                           3114 ;	Peephole 236.b	used r6 instead of ar6
   1187 3E                 3115 	addc	a,r6
   1188 FB                 3116 	mov	r3,a
   1189 8F 04              3117 	mov	ar4,r7
                           3118 ;	genCall
   118B 8A 82              3119 	mov	dpl,r2
   118D 8B 83              3120 	mov	dph,r3
   118F 8C F0              3121 	mov	b,r4
   1191 C0 05              3122 	push	ar5
   1193 C0 06              3123 	push	ar6
   1195 C0 07              3124 	push	ar7
   1197 12 2F 88           3125 	lcall	_vListRemove
   119A D0 07              3126 	pop	ar7
   119C D0 06              3127 	pop	ar6
   119E D0 05              3128 	pop	ar5
                           3129 ;	genPlus
                           3130 ;     genPlusIncr
   11A0 74 11              3131 	mov	a,#0x11
                           3132 ;	Peephole 236.a	used r5 instead of ar5
   11A2 2D                 3133 	add	a,r5
   11A3 FA                 3134 	mov	r2,a
                           3135 ;	Peephole 181	changed mov to clr
   11A4 E4                 3136 	clr	a
                           3137 ;	Peephole 236.b	used r6 instead of ar6
   11A5 3E                 3138 	addc	a,r6
   11A6 FB                 3139 	mov	r3,a
   11A7 8F 04              3140 	mov	ar4,r7
                           3141 ;	genIpush
   11A9 C0 05              3142 	push	ar5
   11AB C0 06              3143 	push	ar6
   11AD C0 07              3144 	push	ar7
                           3145 ;	genPlus
                           3146 ;     genPlusIncr
   11AF 74 0B              3147 	mov	a,#0x0B
                           3148 ;	Peephole 236.a	used r2 instead of ar2
   11B1 2A                 3149 	add	a,r2
   11B2 FD                 3150 	mov	r5,a
                           3151 ;	Peephole 181	changed mov to clr
   11B3 E4                 3152 	clr	a
                           3153 ;	Peephole 236.b	used r3 instead of ar3
   11B4 3B                 3154 	addc	a,r3
   11B5 FE                 3155 	mov	r6,a
   11B6 8C 07              3156 	mov	ar7,r4
                           3157 ;	genPointerGet
                           3158 ;	genGenPointerGet
   11B8 8D 82              3159 	mov	dpl,r5
   11BA 8E 83              3160 	mov	dph,r6
   11BC 8F F0              3161 	mov	b,r7
   11BE 12 E4 9F           3162 	lcall	__gptrget
   11C1 FD                 3163 	mov	r5,a
   11C2 A3                 3164 	inc	dptr
   11C3 12 E4 9F           3165 	lcall	__gptrget
   11C6 FE                 3166 	mov	r6,a
   11C7 A3                 3167 	inc	dptr
   11C8 12 E4 9F           3168 	lcall	__gptrget
   11CB FF                 3169 	mov	r7,a
                           3170 ;	genIfx
   11CC ED                 3171 	mov	a,r5
   11CD 4E                 3172 	orl	a,r6
   11CE 4F                 3173 	orl	a,r7
                           3174 ;	genIpop
   11CF D0 07              3175 	pop	ar7
   11D1 D0 06              3176 	pop	ar6
   11D3 D0 05              3177 	pop	ar5
                           3178 ;	genIfxJump
                           3179 ;	Peephole 108.c	removed ljmp by inverse jump logic
   11D5 60 15              3180 	jz	00106$
                           3181 ;	Peephole 300	removed redundant label 00138$
                           3182 ;	genCall
   11D7 8A 82              3183 	mov	dpl,r2
   11D9 8B 83              3184 	mov	dph,r3
   11DB 8C F0              3185 	mov	b,r4
   11DD C0 05              3186 	push	ar5
   11DF C0 06              3187 	push	ar6
   11E1 C0 07              3188 	push	ar7
   11E3 12 2F 88           3189 	lcall	_vListRemove
   11E6 D0 07              3190 	pop	ar7
   11E8 D0 06              3191 	pop	ar6
   11EA D0 05              3192 	pop	ar5
   11EC                    3193 00106$:
                           3194 ;	genPlus
                           3195 ;     genPlusIncr
   11EC 74 1F              3196 	mov	a,#0x1F
                           3197 ;	Peephole 236.a	used r5 instead of ar5
   11EE 2D                 3198 	add	a,r5
   11EF FA                 3199 	mov	r2,a
                           3200 ;	Peephole 181	changed mov to clr
   11F0 E4                 3201 	clr	a
                           3202 ;	Peephole 236.b	used r6 instead of ar6
   11F1 3E                 3203 	addc	a,r6
   11F2 FB                 3204 	mov	r3,a
   11F3 8F 04              3205 	mov	ar4,r7
                           3206 ;	genPointerGet
                           3207 ;	genGenPointerGet
   11F5 8A 82              3208 	mov	dpl,r2
   11F7 8B 83              3209 	mov	dph,r3
   11F9 8C F0              3210 	mov	b,r4
   11FB A8 10              3211 	mov	r0,_bp
   11FD 08                 3212 	inc	r0
   11FE 12 E4 9F           3213 	lcall	__gptrget
   1201 F6                 3214 	mov	@r0,a
                           3215 ;	genIpush
   1202 C0 05              3216 	push	ar5
   1204 C0 06              3217 	push	ar6
   1206 C0 07              3218 	push	ar7
                           3219 ;	genAssign
   1208 90 F0 7D           3220 	mov	dptr,#_uxTopReadyPriority
   120B E0                 3221 	movx	a,@dptr
   120C FD                 3222 	mov	r5,a
                           3223 ;	genCmpGt
   120D A8 10              3224 	mov	r0,_bp
   120F 08                 3225 	inc	r0
                           3226 ;	genCmp
   1210 C3                 3227 	clr	c
   1211 ED                 3228 	mov	a,r5
   1212 96                 3229 	subb	a,@r0
   1213 E4                 3230 	clr	a
   1214 33                 3231 	rlc	a
                           3232 ;	genIpop
   1215 D0 07              3233 	pop	ar7
   1217 D0 06              3234 	pop	ar6
   1219 D0 05              3235 	pop	ar5
                           3236 ;	genIfx
                           3237 ;	genIfxJump
                           3238 ;	Peephole 108.c	removed ljmp by inverse jump logic
   121B 60 08              3239 	jz	00108$
                           3240 ;	Peephole 300	removed redundant label 00139$
                           3241 ;	genAssign
   121D A8 10              3242 	mov	r0,_bp
   121F 08                 3243 	inc	r0
   1220 90 F0 7D           3244 	mov	dptr,#_uxTopReadyPriority
   1223 E6                 3245 	mov	a,@r0
   1224 F0                 3246 	movx	@dptr,a
   1225                    3247 00108$:
                           3248 ;	genPlus
                           3249 ;     genPlusIncr
   1225 74 03              3250 	mov	a,#0x03
                           3251 ;	Peephole 236.a	used r5 instead of ar5
   1227 2D                 3252 	add	a,r5
   1228 FD                 3253 	mov	r5,a
                           3254 ;	Peephole 181	changed mov to clr
   1229 E4                 3255 	clr	a
                           3256 ;	Peephole 236.b	used r6 instead of ar6
   122A 3E                 3257 	addc	a,r6
   122B FE                 3258 	mov	r6,a
                           3259 ;	genPointerGet
                           3260 ;	genGenPointerGet
   122C 8A 82              3261 	mov	dpl,r2
   122E 8B 83              3262 	mov	dph,r3
   1230 8C F0              3263 	mov	b,r4
   1232 12 E4 9F           3264 	lcall	__gptrget
                           3265 ;	genMult
                           3266 ;	genMultOneByte
   1235 FA                 3267 	mov	r2,a
                           3268 ;	Peephole 105	removed redundant mov
   1236 75 F0 0C           3269 	mov	b,#0x0C
   1239 A4                 3270 	mul	ab
                           3271 ;	genPlus
   123A 24 06              3272 	add	a,#_pxReadyTasksLists
   123C FA                 3273 	mov	r2,a
                           3274 ;	Peephole 240	use clr instead of addc a,#0
   123D E4                 3275 	clr	a
   123E 34 E0              3276 	addc	a,#(_pxReadyTasksLists >> 8)
   1240 FB                 3277 	mov	r3,a
                           3278 ;	genCast
   1241 7C 00              3279 	mov	r4,#0x0
                           3280 ;	genIpush
   1243 C0 05              3281 	push	ar5
   1245 C0 06              3282 	push	ar6
   1247 C0 07              3283 	push	ar7
                           3284 ;	genCall
   1249 8A 82              3285 	mov	dpl,r2
   124B 8B 83              3286 	mov	dph,r3
   124D 8C F0              3287 	mov	b,r4
   124F 12 2B 96           3288 	lcall	_vListInsertEnd
   1252 15 81              3289 	dec	sp
   1254 15 81              3290 	dec	sp
   1256 15 81              3291 	dec	sp
   1258 02 10 C5           3292 	ljmp	00109$
   125B                    3293 00113$:
                           3294 ;	../../FreeRTOS/Source/tasks.c:1303: ++uxMissedTicks;
                           3295 ;	genPlus
   125B 90 F0 80           3296 	mov	dptr,#_uxMissedTicks
   125E E0                 3297 	movx	a,@dptr
   125F 24 01              3298 	add	a,#0x01
   1261 F0                 3299 	movx	@dptr,a
                           3300 ;	../../FreeRTOS/Source/tasks.c:1311: vApplicationTickHook();
                           3301 ;	genCall
   1262 12 41 E6           3302 	lcall	_vApplicationTickHook
   1265                    3303 00114$:
                           3304 ;	../../FreeRTOS/Source/tasks.c:1322: if( uxMissedTicks == 0 )
                           3305 ;	genAssign
   1265 90 F0 80           3306 	mov	dptr,#_uxMissedTicks
   1268 E0                 3307 	movx	a,@dptr
                           3308 ;	genIfx
   1269 FA                 3309 	mov	r2,a
                           3310 ;	Peephole 105	removed redundant mov
                           3311 ;	genIfxJump
                           3312 ;	Peephole 108.b	removed ljmp by inverse jump logic
   126A 70 03              3313 	jnz	00117$
                           3314 ;	Peephole 300	removed redundant label 00140$
                           3315 ;	../../FreeRTOS/Source/tasks.c:1324: vApplicationTickHook();
                           3316 ;	genCall
   126C 12 41 E6           3317 	lcall	_vApplicationTickHook
   126F                    3318 00117$:
   126F 85 10 81           3319 	mov	sp,_bp
   1272 D0 10              3320 	pop	_bp
   1274 22                 3321 	ret
                           3322 ;------------------------------------------------------------
                           3323 ;Allocation info for local variables in function 'vTaskSwitchContext'
                           3324 ;------------------------------------------------------------
                           3325 ;------------------------------------------------------------
                           3326 ;	../../FreeRTOS/Source/tasks.c:1392: void vTaskSwitchContext( void )
                           3327 ;	-----------------------------------------
                           3328 ;	 function vTaskSwitchContext
                           3329 ;	-----------------------------------------
   1275                    3330 _vTaskSwitchContext:
                           3331 ;	../../FreeRTOS/Source/tasks.c:1394: if( uxSchedulerSuspended != ( unsigned portBASE_TYPE ) pdFALSE )
                           3332 ;	genAssign
   1275 90 F0 7F           3333 	mov	dptr,#_uxSchedulerSuspended
   1278 E0                 3334 	movx	a,@dptr
                           3335 ;	genCmpEq
                           3336 ;	gencjneshort
                           3337 ;	Peephole 112.b	changed ljmp to sjmp
   1279 FA                 3338 	mov	r2,a
                           3339 ;	Peephole 115.b	jump optimization
   127A 60 07              3340 	jz	00112$
                           3341 ;	Peephole 300	removed redundant label 00114$
                           3342 ;	../../FreeRTOS/Source/tasks.c:1398: xMissedYield = pdTRUE;
                           3343 ;	genAssign
   127C 90 F0 81           3344 	mov	dptr,#_xMissedYield
   127F 74 01              3345 	mov	a,#0x01
   1281 F0                 3346 	movx	@dptr,a
                           3347 ;	../../FreeRTOS/Source/tasks.c:1399: return;
                           3348 ;	genRet
                           3349 ;	Peephole 251.a	replaced ljmp to ret with ret
   1282 22                 3350 	ret
                           3351 ;	../../FreeRTOS/Source/tasks.c:1403: while( listLIST_IS_EMPTY( &( pxReadyTasksLists[ uxTopReadyPriority ] ) ) )
   1283                    3352 00112$:
   1283                    3353 00103$:
                           3354 ;	genAssign
   1283 90 F0 7D           3355 	mov	dptr,#_uxTopReadyPriority
   1286 E0                 3356 	movx	a,@dptr
                           3357 ;	genMult
                           3358 ;	genMultOneByte
   1287 FA                 3359 	mov	r2,a
                           3360 ;	Peephole 105	removed redundant mov
   1288 75 F0 0C           3361 	mov	b,#0x0C
   128B A4                 3362 	mul	ab
                           3363 ;	genPlus
   128C 24 06              3364 	add	a,#_pxReadyTasksLists
   128E FA                 3365 	mov	r2,a
                           3366 ;	Peephole 240	use clr instead of addc a,#0
   128F E4                 3367 	clr	a
   1290 34 E0              3368 	addc	a,#(_pxReadyTasksLists >> 8)
   1292 FB                 3369 	mov	r3,a
                           3370 ;	genPointerGet
                           3371 ;	genFarPointerGet
   1293 8A 82              3372 	mov	dpl,r2
   1295 8B 83              3373 	mov	dph,r3
   1297 E0                 3374 	movx	a,@dptr
                           3375 ;	genIfxJump
                           3376 ;	Peephole 108.b	removed ljmp by inverse jump logic
   1298 70 0B              3377 	jnz	00105$
                           3378 ;	Peephole 300	removed redundant label 00115$
                           3379 ;	../../FreeRTOS/Source/tasks.c:1405: --uxTopReadyPriority;
                           3380 ;	genMinus
   129A 90 F0 7D           3381 	mov	dptr,#_uxTopReadyPriority
                           3382 ;	genMinusDec
   129D E0                 3383 	movx	a,@dptr
   129E 14                 3384 	dec	a
                           3385 ;	genAssign
   129F 90 F0 7D           3386 	mov	dptr,#_uxTopReadyPriority
   12A2 F0                 3387 	movx	@dptr,a
                           3388 ;	Peephole 112.b	changed ljmp to sjmp
   12A3 80 DE              3389 	sjmp	00103$
   12A5                    3390 00105$:
                           3391 ;	../../FreeRTOS/Source/tasks.c:1410: listGET_OWNER_OF_NEXT_ENTRY( pxCurrentTCB, &( pxReadyTasksLists[ uxTopReadyPriority ] ) );
                           3392 ;	genAssign
   12A5 90 F0 7D           3393 	mov	dptr,#_uxTopReadyPriority
   12A8 E0                 3394 	movx	a,@dptr
                           3395 ;	genMult
                           3396 ;	genMultOneByte
   12A9 FA                 3397 	mov	r2,a
                           3398 ;	Peephole 105	removed redundant mov
   12AA 75 F0 0C           3399 	mov	b,#0x0C
   12AD A4                 3400 	mul	ab
                           3401 ;	genPlus
   12AE 24 06              3402 	add	a,#_pxReadyTasksLists
   12B0 FA                 3403 	mov	r2,a
                           3404 ;	Peephole 240	use clr instead of addc a,#0
   12B1 E4                 3405 	clr	a
   12B2 34 E0              3406 	addc	a,#(_pxReadyTasksLists >> 8)
   12B4 FB                 3407 	mov	r3,a
                           3408 ;	genPlus
                           3409 ;     genPlusIncr
   12B5 0A                 3410 	inc	r2
   12B6 BA 00 01           3411 	cjne	r2,#0x00,00116$
   12B9 0B                 3412 	inc	r3
   12BA                    3413 00116$:
                           3414 ;	genAssign
   12BA 90 F0 7D           3415 	mov	dptr,#_uxTopReadyPriority
   12BD E0                 3416 	movx	a,@dptr
                           3417 ;	genMult
                           3418 ;	genMultOneByte
   12BE FC                 3419 	mov	r4,a
                           3420 ;	Peephole 105	removed redundant mov
   12BF 75 F0 0C           3421 	mov	b,#0x0C
   12C2 A4                 3422 	mul	ab
                           3423 ;	genPlus
   12C3 24 06              3424 	add	a,#_pxReadyTasksLists
   12C5 FC                 3425 	mov	r4,a
                           3426 ;	Peephole 240	use clr instead of addc a,#0
   12C6 E4                 3427 	clr	a
   12C7 34 E0              3428 	addc	a,#(_pxReadyTasksLists >> 8)
   12C9 FD                 3429 	mov	r5,a
                           3430 ;	genPlus
                           3431 ;     genPlusIncr
   12CA 8C 82              3432 	mov	dpl,r4
   12CC 8D 83              3433 	mov	dph,r5
   12CE A3                 3434 	inc	dptr
                           3435 ;	genPointerGet
                           3436 ;	genFarPointerGet
   12CF E0                 3437 	movx	a,@dptr
   12D0 FC                 3438 	mov	r4,a
   12D1 A3                 3439 	inc	dptr
   12D2 E0                 3440 	movx	a,@dptr
   12D3 FD                 3441 	mov	r5,a
   12D4 A3                 3442 	inc	dptr
   12D5 E0                 3443 	movx	a,@dptr
   12D6 FE                 3444 	mov	r6,a
                           3445 ;	genPlus
                           3446 ;     genPlusIncr
   12D7 74 02              3447 	mov	a,#0x02
                           3448 ;	Peephole 236.a	used r4 instead of ar4
   12D9 2C                 3449 	add	a,r4
   12DA FC                 3450 	mov	r4,a
                           3451 ;	Peephole 181	changed mov to clr
   12DB E4                 3452 	clr	a
                           3453 ;	Peephole 236.b	used r5 instead of ar5
   12DC 3D                 3454 	addc	a,r5
   12DD FD                 3455 	mov	r5,a
                           3456 ;	genPointerGet
                           3457 ;	genGenPointerGet
   12DE 8C 82              3458 	mov	dpl,r4
   12E0 8D 83              3459 	mov	dph,r5
   12E2 8E F0              3460 	mov	b,r6
   12E4 12 E4 9F           3461 	lcall	__gptrget
   12E7 FC                 3462 	mov	r4,a
   12E8 A3                 3463 	inc	dptr
   12E9 12 E4 9F           3464 	lcall	__gptrget
   12EC FD                 3465 	mov	r5,a
   12ED A3                 3466 	inc	dptr
   12EE 12 E4 9F           3467 	lcall	__gptrget
   12F1 FE                 3468 	mov	r6,a
                           3469 ;	genPointerSet
                           3470 ;     genFarPointerSet
   12F2 8A 82              3471 	mov	dpl,r2
   12F4 8B 83              3472 	mov	dph,r3
   12F6 EC                 3473 	mov	a,r4
   12F7 F0                 3474 	movx	@dptr,a
   12F8 A3                 3475 	inc	dptr
   12F9 ED                 3476 	mov	a,r5
   12FA F0                 3477 	movx	@dptr,a
   12FB A3                 3478 	inc	dptr
   12FC EE                 3479 	mov	a,r6
   12FD F0                 3480 	movx	@dptr,a
                           3481 ;	genAssign
   12FE 90 F0 7D           3482 	mov	dptr,#_uxTopReadyPriority
   1301 E0                 3483 	movx	a,@dptr
                           3484 ;	genMult
                           3485 ;	genMultOneByte
   1302 FA                 3486 	mov	r2,a
                           3487 ;	Peephole 105	removed redundant mov
   1303 75 F0 0C           3488 	mov	b,#0x0C
   1306 A4                 3489 	mul	ab
                           3490 ;	genPlus
   1307 24 06              3491 	add	a,#_pxReadyTasksLists
   1309 FA                 3492 	mov	r2,a
                           3493 ;	Peephole 240	use clr instead of addc a,#0
   130A E4                 3494 	clr	a
   130B 34 E0              3495 	addc	a,#(_pxReadyTasksLists >> 8)
   130D FB                 3496 	mov	r3,a
                           3497 ;	genPlus
                           3498 ;     genPlusIncr
   130E 8A 82              3499 	mov	dpl,r2
   1310 8B 83              3500 	mov	dph,r3
   1312 A3                 3501 	inc	dptr
                           3502 ;	genPointerGet
                           3503 ;	genFarPointerGet
   1313 E0                 3504 	movx	a,@dptr
   1314 FA                 3505 	mov	r2,a
   1315 A3                 3506 	inc	dptr
   1316 E0                 3507 	movx	a,@dptr
   1317 FB                 3508 	mov	r3,a
   1318 A3                 3509 	inc	dptr
   1319 E0                 3510 	movx	a,@dptr
   131A FC                 3511 	mov	r4,a
                           3512 ;	genAssign
   131B 90 F0 7D           3513 	mov	dptr,#_uxTopReadyPriority
   131E E0                 3514 	movx	a,@dptr
                           3515 ;	genMult
                           3516 ;	genMultOneByte
   131F FD                 3517 	mov	r5,a
                           3518 ;	Peephole 105	removed redundant mov
   1320 75 F0 0C           3519 	mov	b,#0x0C
   1323 A4                 3520 	mul	ab
                           3521 ;	genPlus
   1324 24 06              3522 	add	a,#_pxReadyTasksLists
   1326 FD                 3523 	mov	r5,a
                           3524 ;	Peephole 240	use clr instead of addc a,#0
   1327 E4                 3525 	clr	a
   1328 34 E0              3526 	addc	a,#(_pxReadyTasksLists >> 8)
   132A FE                 3527 	mov	r6,a
                           3528 ;	genPlus
                           3529 ;     genPlusIncr
   132B 74 04              3530 	mov	a,#0x04
                           3531 ;	Peephole 236.a	used r5 instead of ar5
   132D 2D                 3532 	add	a,r5
   132E FD                 3533 	mov	r5,a
                           3534 ;	Peephole 181	changed mov to clr
   132F E4                 3535 	clr	a
                           3536 ;	Peephole 236.b	used r6 instead of ar6
   1330 3E                 3537 	addc	a,r6
   1331 FE                 3538 	mov	r6,a
                           3539 ;	genCast
   1332 7F 00              3540 	mov	r7,#0x0
                           3541 ;	genCmpEq
                           3542 ;	gencjneshort
   1334 EA                 3543 	mov	a,r2
                           3544 ;	Peephole 112.b	changed ljmp to sjmp
                           3545 ;	Peephole 195.b	optimized misc jump sequence
   1335 B5 05 61           3546 	cjne	a,ar5,00107$
   1338 EB                 3547 	mov	a,r3
   1339 B5 06 5D           3548 	cjne	a,ar6,00107$
   133C EC                 3549 	mov	a,r4
   133D B5 07 59           3550 	cjne	a,ar7,00107$
                           3551 ;	Peephole 200.b	removed redundant sjmp
                           3552 ;	Peephole 300	removed redundant label 00117$
                           3553 ;	Peephole 300	removed redundant label 00118$
                           3554 ;	genAssign
   1340 90 F0 7D           3555 	mov	dptr,#_uxTopReadyPriority
   1343 E0                 3556 	movx	a,@dptr
                           3557 ;	genMult
                           3558 ;	genMultOneByte
   1344 FA                 3559 	mov	r2,a
                           3560 ;	Peephole 105	removed redundant mov
   1345 75 F0 0C           3561 	mov	b,#0x0C
   1348 A4                 3562 	mul	ab
                           3563 ;	genPlus
   1349 24 06              3564 	add	a,#_pxReadyTasksLists
   134B FA                 3565 	mov	r2,a
                           3566 ;	Peephole 240	use clr instead of addc a,#0
   134C E4                 3567 	clr	a
   134D 34 E0              3568 	addc	a,#(_pxReadyTasksLists >> 8)
   134F FB                 3569 	mov	r3,a
                           3570 ;	genPlus
                           3571 ;     genPlusIncr
   1350 0A                 3572 	inc	r2
   1351 BA 00 01           3573 	cjne	r2,#0x00,00119$
   1354 0B                 3574 	inc	r3
   1355                    3575 00119$:
                           3576 ;	genAssign
   1355 90 F0 7D           3577 	mov	dptr,#_uxTopReadyPriority
   1358 E0                 3578 	movx	a,@dptr
                           3579 ;	genMult
                           3580 ;	genMultOneByte
   1359 FC                 3581 	mov	r4,a
                           3582 ;	Peephole 105	removed redundant mov
   135A 75 F0 0C           3583 	mov	b,#0x0C
   135D A4                 3584 	mul	ab
                           3585 ;	genPlus
   135E 24 06              3586 	add	a,#_pxReadyTasksLists
   1360 FC                 3587 	mov	r4,a
                           3588 ;	Peephole 240	use clr instead of addc a,#0
   1361 E4                 3589 	clr	a
   1362 34 E0              3590 	addc	a,#(_pxReadyTasksLists >> 8)
   1364 FD                 3591 	mov	r5,a
                           3592 ;	genPlus
                           3593 ;     genPlusIncr
   1365 8C 82              3594 	mov	dpl,r4
   1367 8D 83              3595 	mov	dph,r5
   1369 A3                 3596 	inc	dptr
                           3597 ;	genPointerGet
                           3598 ;	genFarPointerGet
   136A E0                 3599 	movx	a,@dptr
   136B FC                 3600 	mov	r4,a
   136C A3                 3601 	inc	dptr
   136D E0                 3602 	movx	a,@dptr
   136E FD                 3603 	mov	r5,a
   136F A3                 3604 	inc	dptr
   1370 E0                 3605 	movx	a,@dptr
   1371 FE                 3606 	mov	r6,a
                           3607 ;	genPlus
                           3608 ;     genPlusIncr
   1372 74 02              3609 	mov	a,#0x02
                           3610 ;	Peephole 236.a	used r4 instead of ar4
   1374 2C                 3611 	add	a,r4
   1375 FC                 3612 	mov	r4,a
                           3613 ;	Peephole 181	changed mov to clr
   1376 E4                 3614 	clr	a
                           3615 ;	Peephole 236.b	used r5 instead of ar5
   1377 3D                 3616 	addc	a,r5
   1378 FD                 3617 	mov	r5,a
                           3618 ;	genPointerGet
                           3619 ;	genGenPointerGet
   1379 8C 82              3620 	mov	dpl,r4
   137B 8D 83              3621 	mov	dph,r5
   137D 8E F0              3622 	mov	b,r6
   137F 12 E4 9F           3623 	lcall	__gptrget
   1382 FC                 3624 	mov	r4,a
   1383 A3                 3625 	inc	dptr
   1384 12 E4 9F           3626 	lcall	__gptrget
   1387 FD                 3627 	mov	r5,a
   1388 A3                 3628 	inc	dptr
   1389 12 E4 9F           3629 	lcall	__gptrget
   138C FE                 3630 	mov	r6,a
                           3631 ;	genPointerSet
                           3632 ;     genFarPointerSet
   138D 8A 82              3633 	mov	dpl,r2
   138F 8B 83              3634 	mov	dph,r3
   1391 EC                 3635 	mov	a,r4
   1392 F0                 3636 	movx	@dptr,a
   1393 A3                 3637 	inc	dptr
   1394 ED                 3638 	mov	a,r5
   1395 F0                 3639 	movx	@dptr,a
   1396 A3                 3640 	inc	dptr
   1397 EE                 3641 	mov	a,r6
   1398 F0                 3642 	movx	@dptr,a
   1399                    3643 00107$:
                           3644 ;	genAssign
   1399 90 F0 7D           3645 	mov	dptr,#_uxTopReadyPriority
   139C E0                 3646 	movx	a,@dptr
                           3647 ;	genMult
                           3648 ;	genMultOneByte
   139D FA                 3649 	mov	r2,a
                           3650 ;	Peephole 105	removed redundant mov
   139E 75 F0 0C           3651 	mov	b,#0x0C
   13A1 A4                 3652 	mul	ab
                           3653 ;	genPlus
   13A2 24 06              3654 	add	a,#_pxReadyTasksLists
   13A4 FA                 3655 	mov	r2,a
                           3656 ;	Peephole 240	use clr instead of addc a,#0
   13A5 E4                 3657 	clr	a
   13A6 34 E0              3658 	addc	a,#(_pxReadyTasksLists >> 8)
   13A8 FB                 3659 	mov	r3,a
                           3660 ;	genPlus
                           3661 ;     genPlusIncr
   13A9 8A 82              3662 	mov	dpl,r2
   13AB 8B 83              3663 	mov	dph,r3
   13AD A3                 3664 	inc	dptr
                           3665 ;	genPointerGet
                           3666 ;	genFarPointerGet
   13AE E0                 3667 	movx	a,@dptr
   13AF FA                 3668 	mov	r2,a
   13B0 A3                 3669 	inc	dptr
   13B1 E0                 3670 	movx	a,@dptr
   13B2 FB                 3671 	mov	r3,a
   13B3 A3                 3672 	inc	dptr
   13B4 E0                 3673 	movx	a,@dptr
   13B5 FC                 3674 	mov	r4,a
                           3675 ;	genPlus
                           3676 ;     genPlusIncr
   13B6 74 08              3677 	mov	a,#0x08
                           3678 ;	Peephole 236.a	used r2 instead of ar2
   13B8 2A                 3679 	add	a,r2
   13B9 FA                 3680 	mov	r2,a
                           3681 ;	Peephole 181	changed mov to clr
   13BA E4                 3682 	clr	a
                           3683 ;	Peephole 236.b	used r3 instead of ar3
   13BB 3B                 3684 	addc	a,r3
   13BC FB                 3685 	mov	r3,a
                           3686 ;	genPointerGet
                           3687 ;	genGenPointerGet
   13BD 8A 82              3688 	mov	dpl,r2
   13BF 8B 83              3689 	mov	dph,r3
   13C1 8C F0              3690 	mov	b,r4
   13C3 12 E4 9F           3691 	lcall	__gptrget
   13C6 FA                 3692 	mov	r2,a
   13C7 A3                 3693 	inc	dptr
   13C8 12 E4 9F           3694 	lcall	__gptrget
   13CB FB                 3695 	mov	r3,a
   13CC A3                 3696 	inc	dptr
   13CD 12 E4 9F           3697 	lcall	__gptrget
   13D0 FC                 3698 	mov	r4,a
                           3699 ;	genAssign
   13D1 90 F0 75           3700 	mov	dptr,#_pxCurrentTCB
   13D4 EA                 3701 	mov	a,r2
   13D5 F0                 3702 	movx	@dptr,a
   13D6 A3                 3703 	inc	dptr
   13D7 EB                 3704 	mov	a,r3
   13D8 F0                 3705 	movx	@dptr,a
   13D9 A3                 3706 	inc	dptr
   13DA EC                 3707 	mov	a,r4
   13DB F0                 3708 	movx	@dptr,a
                           3709 ;	Peephole 300	removed redundant label 00108$
   13DC 22                 3710 	ret
                           3711 ;------------------------------------------------------------
                           3712 ;Allocation info for local variables in function 'vTaskPlaceOnEventList'
                           3713 ;------------------------------------------------------------
                           3714 ;xTicksToWait              Allocated to stack - offset -4
                           3715 ;pxEventList               Allocated to registers r2 r3 r4 
                           3716 ;xTimeToWake               Allocated to registers r2 r3 
                           3717 ;------------------------------------------------------------
                           3718 ;	../../FreeRTOS/Source/tasks.c:1415: void vTaskPlaceOnEventList( xList *pxEventList, portTickType xTicksToWait )
                           3719 ;	-----------------------------------------
                           3720 ;	 function vTaskPlaceOnEventList
                           3721 ;	-----------------------------------------
   13DD                    3722 _vTaskPlaceOnEventList:
   13DD C0 10              3723 	push	_bp
   13DF 85 81 10           3724 	mov	_bp,sp
                           3725 ;	genReceive
   13E2 AA 82              3726 	mov	r2,dpl
   13E4 AB 83              3727 	mov	r3,dph
   13E6 AC F0              3728 	mov	r4,b
                           3729 ;	../../FreeRTOS/Source/tasks.c:1425: vListInsert( ( xList * ) pxEventList, ( xListItem * ) &( pxCurrentTCB->xEventListItem ) );
                           3730 ;	genAssign
   13E8 90 F0 75           3731 	mov	dptr,#_pxCurrentTCB
   13EB E0                 3732 	movx	a,@dptr
   13EC FD                 3733 	mov	r5,a
   13ED A3                 3734 	inc	dptr
   13EE E0                 3735 	movx	a,@dptr
   13EF FE                 3736 	mov	r6,a
   13F0 A3                 3737 	inc	dptr
   13F1 E0                 3738 	movx	a,@dptr
   13F2 FF                 3739 	mov	r7,a
                           3740 ;	genPlus
                           3741 ;     genPlusIncr
   13F3 74 11              3742 	mov	a,#0x11
                           3743 ;	Peephole 236.a	used r5 instead of ar5
   13F5 2D                 3744 	add	a,r5
   13F6 FD                 3745 	mov	r5,a
                           3746 ;	Peephole 181	changed mov to clr
   13F7 E4                 3747 	clr	a
                           3748 ;	Peephole 236.b	used r6 instead of ar6
   13F8 3E                 3749 	addc	a,r6
   13F9 FE                 3750 	mov	r6,a
                           3751 ;	genIpush
   13FA C0 05              3752 	push	ar5
   13FC C0 06              3753 	push	ar6
   13FE C0 07              3754 	push	ar7
                           3755 ;	genCall
   1400 8A 82              3756 	mov	dpl,r2
   1402 8B 83              3757 	mov	dph,r3
   1404 8C F0              3758 	mov	b,r4
   1406 12 2D 55           3759 	lcall	_vListInsert
   1409 15 81              3760 	dec	sp
   140B 15 81              3761 	dec	sp
   140D 15 81              3762 	dec	sp
                           3763 ;	../../FreeRTOS/Source/tasks.c:1430: vListRemove( ( xListItem * ) &( pxCurrentTCB->xGenericListItem ) );
                           3764 ;	genAssign
   140F 90 F0 75           3765 	mov	dptr,#_pxCurrentTCB
   1412 E0                 3766 	movx	a,@dptr
   1413 FA                 3767 	mov	r2,a
   1414 A3                 3768 	inc	dptr
   1415 E0                 3769 	movx	a,@dptr
   1416 FB                 3770 	mov	r3,a
   1417 A3                 3771 	inc	dptr
   1418 E0                 3772 	movx	a,@dptr
   1419 FC                 3773 	mov	r4,a
                           3774 ;	genPlus
                           3775 ;     genPlusIncr
   141A 74 03              3776 	mov	a,#0x03
                           3777 ;	Peephole 236.a	used r2 instead of ar2
   141C 2A                 3778 	add	a,r2
   141D FA                 3779 	mov	r2,a
                           3780 ;	Peephole 181	changed mov to clr
   141E E4                 3781 	clr	a
                           3782 ;	Peephole 236.b	used r3 instead of ar3
   141F 3B                 3783 	addc	a,r3
   1420 FB                 3784 	mov	r3,a
                           3785 ;	genCall
   1421 8A 82              3786 	mov	dpl,r2
   1423 8B 83              3787 	mov	dph,r3
   1425 8C F0              3788 	mov	b,r4
   1427 12 2F 88           3789 	lcall	_vListRemove
                           3790 ;	../../FreeRTOS/Source/tasks.c:1466: xTimeToWake = xTickCount + xTicksToWait;
                           3791 ;	genAssign
   142A 90 F0 7A           3792 	mov	dptr,#_xTickCount
   142D E0                 3793 	movx	a,@dptr
   142E FA                 3794 	mov	r2,a
   142F A3                 3795 	inc	dptr
   1430 E0                 3796 	movx	a,@dptr
   1431 FB                 3797 	mov	r3,a
                           3798 ;	genPlus
   1432 E5 10              3799 	mov	a,_bp
   1434 24 FC              3800 	add	a,#0xfffffffc
   1436 F8                 3801 	mov	r0,a
   1437 E6                 3802 	mov	a,@r0
                           3803 ;	Peephole 236.a	used r2 instead of ar2
   1438 2A                 3804 	add	a,r2
   1439 FA                 3805 	mov	r2,a
   143A 08                 3806 	inc	r0
   143B E6                 3807 	mov	a,@r0
                           3808 ;	Peephole 236.b	used r3 instead of ar3
   143C 3B                 3809 	addc	a,r3
   143D FB                 3810 	mov	r3,a
                           3811 ;	genAssign
                           3812 ;	../../FreeRTOS/Source/tasks.c:1468: listSET_LIST_ITEM_VALUE( &( pxCurrentTCB->xGenericListItem ), xTimeToWake );
                           3813 ;	genAssign
   143E 90 F0 75           3814 	mov	dptr,#_pxCurrentTCB
   1441 E0                 3815 	movx	a,@dptr
   1442 FC                 3816 	mov	r4,a
   1443 A3                 3817 	inc	dptr
   1444 E0                 3818 	movx	a,@dptr
   1445 FD                 3819 	mov	r5,a
   1446 A3                 3820 	inc	dptr
   1447 E0                 3821 	movx	a,@dptr
   1448 FE                 3822 	mov	r6,a
                           3823 ;	genPlus
                           3824 ;     genPlusIncr
   1449 74 03              3825 	mov	a,#0x03
                           3826 ;	Peephole 236.a	used r4 instead of ar4
   144B 2C                 3827 	add	a,r4
   144C FC                 3828 	mov	r4,a
                           3829 ;	Peephole 181	changed mov to clr
   144D E4                 3830 	clr	a
                           3831 ;	Peephole 236.b	used r5 instead of ar5
   144E 3D                 3832 	addc	a,r5
   144F FD                 3833 	mov	r5,a
                           3834 ;	genPointerSet
                           3835 ;	genGenPointerSet
   1450 8C 82              3836 	mov	dpl,r4
   1452 8D 83              3837 	mov	dph,r5
   1454 8E F0              3838 	mov	b,r6
   1456 EA                 3839 	mov	a,r2
   1457 12 DF B7           3840 	lcall	__gptrput
   145A A3                 3841 	inc	dptr
   145B EB                 3842 	mov	a,r3
   145C 12 DF B7           3843 	lcall	__gptrput
                           3844 ;	../../FreeRTOS/Source/tasks.c:1470: if( xTimeToWake < xTickCount )
                           3845 ;	genAssign
   145F 90 F0 7A           3846 	mov	dptr,#_xTickCount
   1462 E0                 3847 	movx	a,@dptr
   1463 FC                 3848 	mov	r4,a
   1464 A3                 3849 	inc	dptr
   1465 E0                 3850 	movx	a,@dptr
   1466 FD                 3851 	mov	r5,a
                           3852 ;	genCmpLt
                           3853 ;	genCmp
   1467 C3                 3854 	clr	c
   1468 EA                 3855 	mov	a,r2
   1469 9C                 3856 	subb	a,r4
   146A EB                 3857 	mov	a,r3
   146B 9D                 3858 	subb	a,r5
                           3859 ;	genIfxJump
                           3860 ;	Peephole 108.a	removed ljmp by inverse jump logic
   146C 50 34              3861 	jnc	00102$
                           3862 ;	Peephole 300	removed redundant label 00107$
                           3863 ;	../../FreeRTOS/Source/tasks.c:1473: vListInsert( ( xList * ) pxOverflowDelayedTaskList, ( xListItem * ) &( pxCurrentTCB->xGenericListItem ) );
                           3864 ;	genAssign
   146E 90 F0 75           3865 	mov	dptr,#_pxCurrentTCB
   1471 E0                 3866 	movx	a,@dptr
   1472 FA                 3867 	mov	r2,a
   1473 A3                 3868 	inc	dptr
   1474 E0                 3869 	movx	a,@dptr
   1475 FB                 3870 	mov	r3,a
   1476 A3                 3871 	inc	dptr
   1477 E0                 3872 	movx	a,@dptr
   1478 FC                 3873 	mov	r4,a
                           3874 ;	genPlus
                           3875 ;     genPlusIncr
   1479 74 03              3876 	mov	a,#0x03
                           3877 ;	Peephole 236.a	used r2 instead of ar2
   147B 2A                 3878 	add	a,r2
   147C FA                 3879 	mov	r2,a
                           3880 ;	Peephole 181	changed mov to clr
   147D E4                 3881 	clr	a
                           3882 ;	Peephole 236.b	used r3 instead of ar3
   147E 3B                 3883 	addc	a,r3
   147F FB                 3884 	mov	r3,a
                           3885 ;	genAssign
   1480 90 E0 51           3886 	mov	dptr,#_pxOverflowDelayedTaskList
   1483 E0                 3887 	movx	a,@dptr
   1484 FD                 3888 	mov	r5,a
   1485 A3                 3889 	inc	dptr
   1486 E0                 3890 	movx	a,@dptr
   1487 FE                 3891 	mov	r6,a
   1488 A3                 3892 	inc	dptr
   1489 E0                 3893 	movx	a,@dptr
   148A FF                 3894 	mov	r7,a
                           3895 ;	genIpush
   148B C0 02              3896 	push	ar2
   148D C0 03              3897 	push	ar3
   148F C0 04              3898 	push	ar4
                           3899 ;	genCall
   1491 8D 82              3900 	mov	dpl,r5
   1493 8E 83              3901 	mov	dph,r6
   1495 8F F0              3902 	mov	b,r7
   1497 12 2D 55           3903 	lcall	_vListInsert
   149A 15 81              3904 	dec	sp
   149C 15 81              3905 	dec	sp
   149E 15 81              3906 	dec	sp
                           3907 ;	Peephole 112.b	changed ljmp to sjmp
   14A0 80 32              3908 	sjmp	00104$
   14A2                    3909 00102$:
                           3910 ;	../../FreeRTOS/Source/tasks.c:1478: vListInsert( ( xList * ) pxDelayedTaskList, ( xListItem * ) &( pxCurrentTCB->xGenericListItem ) );
                           3911 ;	genAssign
   14A2 90 F0 75           3912 	mov	dptr,#_pxCurrentTCB
   14A5 E0                 3913 	movx	a,@dptr
   14A6 FA                 3914 	mov	r2,a
   14A7 A3                 3915 	inc	dptr
   14A8 E0                 3916 	movx	a,@dptr
   14A9 FB                 3917 	mov	r3,a
   14AA A3                 3918 	inc	dptr
   14AB E0                 3919 	movx	a,@dptr
   14AC FC                 3920 	mov	r4,a
                           3921 ;	genPlus
                           3922 ;     genPlusIncr
   14AD 74 03              3923 	mov	a,#0x03
                           3924 ;	Peephole 236.a	used r2 instead of ar2
   14AF 2A                 3925 	add	a,r2
   14B0 FA                 3926 	mov	r2,a
                           3927 ;	Peephole 181	changed mov to clr
   14B1 E4                 3928 	clr	a
                           3929 ;	Peephole 236.b	used r3 instead of ar3
   14B2 3B                 3930 	addc	a,r3
   14B3 FB                 3931 	mov	r3,a
                           3932 ;	genAssign
   14B4 90 E0 4E           3933 	mov	dptr,#_pxDelayedTaskList
   14B7 E0                 3934 	movx	a,@dptr
   14B8 FD                 3935 	mov	r5,a
   14B9 A3                 3936 	inc	dptr
   14BA E0                 3937 	movx	a,@dptr
   14BB FE                 3938 	mov	r6,a
   14BC A3                 3939 	inc	dptr
   14BD E0                 3940 	movx	a,@dptr
   14BE FF                 3941 	mov	r7,a
                           3942 ;	genIpush
   14BF C0 02              3943 	push	ar2
   14C1 C0 03              3944 	push	ar3
   14C3 C0 04              3945 	push	ar4
                           3946 ;	genCall
   14C5 8D 82              3947 	mov	dpl,r5
   14C7 8E 83              3948 	mov	dph,r6
   14C9 8F F0              3949 	mov	b,r7
   14CB 12 2D 55           3950 	lcall	_vListInsert
   14CE 15 81              3951 	dec	sp
   14D0 15 81              3952 	dec	sp
   14D2 15 81              3953 	dec	sp
   14D4                    3954 00104$:
   14D4 D0 10              3955 	pop	_bp
   14D6 22                 3956 	ret
                           3957 ;------------------------------------------------------------
                           3958 ;Allocation info for local variables in function 'xTaskRemoveFromEventList'
                           3959 ;------------------------------------------------------------
                           3960 ;pxEventList               Allocated to registers r2 r3 r4 
                           3961 ;pxUnblockedTCB            Allocated to stack - offset 1
                           3962 ;xReturn                   Allocated to registers r2 
                           3963 ;------------------------------------------------------------
                           3964 ;	../../FreeRTOS/Source/tasks.c:1485: signed portBASE_TYPE xTaskRemoveFromEventList( const xList *pxEventList )
                           3965 ;	-----------------------------------------
                           3966 ;	 function xTaskRemoveFromEventList
                           3967 ;	-----------------------------------------
   14D7                    3968 _xTaskRemoveFromEventList:
   14D7 C0 10              3969 	push	_bp
   14D9 85 81 10           3970 	mov	_bp,sp
   14DC 05 81              3971 	inc	sp
   14DE 05 81              3972 	inc	sp
   14E0 05 81              3973 	inc	sp
                           3974 ;	genReceive
                           3975 ;	../../FreeRTOS/Source/tasks.c:1500: pxUnblockedTCB = ( tskTCB * ) listGET_OWNER_OF_HEAD_ENTRY( pxEventList );
                           3976 ;	genPointerGet
                           3977 ;	genGenPointerGet
   14E2 AA 82              3978 	mov	r2,dpl
   14E4 AB 83              3979 	mov	r3,dph
   14E6 AC F0              3980 	mov	r4,b
                           3981 ;	Peephole 238.d	removed 3 redundant moves
   14E8 12 E4 9F           3982 	lcall	__gptrget
   14EB FD                 3983 	mov	r5,a
                           3984 ;	genCmpEq
                           3985 ;	gencjne
                           3986 ;	gencjneshort
                           3987 ;	Peephole 241.d	optimized compare
   14EC E4                 3988 	clr	a
   14ED BD 00 01           3989 	cjne	r5,#0x00,00117$
   14F0 04                 3990 	inc	a
   14F1                    3991 00117$:
                           3992 ;	Peephole 300	removed redundant label 00118$
                           3993 ;	genNot
   14F1 FD                 3994 	mov	r5,a
                           3995 ;	Peephole 105	removed redundant mov
   14F2 B4 01 00           3996 	cjne	a,#0x01,00119$
   14F5                    3997 00119$:
   14F5 E4                 3998 	clr	a
   14F6 33                 3999 	rlc	a
                           4000 ;	genIfx
   14F7 FD                 4001 	mov	r5,a
                           4002 ;	Peephole 105	removed redundant mov
                           4003 ;	genIfxJump
                           4004 ;	Peephole 108.c	removed ljmp by inverse jump logic
   14F8 60 3F              4005 	jz	00111$
                           4006 ;	Peephole 300	removed redundant label 00120$
                           4007 ;	genPlus
                           4008 ;     genPlusIncr
   14FA 74 04              4009 	mov	a,#0x04
                           4010 ;	Peephole 236.a	used r2 instead of ar2
   14FC 2A                 4011 	add	a,r2
   14FD FA                 4012 	mov	r2,a
                           4013 ;	Peephole 181	changed mov to clr
   14FE E4                 4014 	clr	a
                           4015 ;	Peephole 236.b	used r3 instead of ar3
   14FF 3B                 4016 	addc	a,r3
   1500 FB                 4017 	mov	r3,a
                           4018 ;	genPlus
                           4019 ;     genPlusIncr
   1501 74 02              4020 	mov	a,#0x02
                           4021 ;	Peephole 236.a	used r2 instead of ar2
   1503 2A                 4022 	add	a,r2
   1504 FA                 4023 	mov	r2,a
                           4024 ;	Peephole 181	changed mov to clr
   1505 E4                 4025 	clr	a
                           4026 ;	Peephole 236.b	used r3 instead of ar3
   1506 3B                 4027 	addc	a,r3
   1507 FB                 4028 	mov	r3,a
                           4029 ;	genPointerGet
                           4030 ;	genGenPointerGet
   1508 8A 82              4031 	mov	dpl,r2
   150A 8B 83              4032 	mov	dph,r3
   150C 8C F0              4033 	mov	b,r4
   150E 12 E4 9F           4034 	lcall	__gptrget
   1511 FA                 4035 	mov	r2,a
   1512 A3                 4036 	inc	dptr
   1513 12 E4 9F           4037 	lcall	__gptrget
   1516 FB                 4038 	mov	r3,a
   1517 A3                 4039 	inc	dptr
   1518 12 E4 9F           4040 	lcall	__gptrget
   151B FC                 4041 	mov	r4,a
                           4042 ;	genPlus
                           4043 ;     genPlusIncr
   151C 74 08              4044 	mov	a,#0x08
                           4045 ;	Peephole 236.a	used r2 instead of ar2
   151E 2A                 4046 	add	a,r2
   151F FA                 4047 	mov	r2,a
                           4048 ;	Peephole 181	changed mov to clr
   1520 E4                 4049 	clr	a
                           4050 ;	Peephole 236.b	used r3 instead of ar3
   1521 3B                 4051 	addc	a,r3
   1522 FB                 4052 	mov	r3,a
                           4053 ;	genPointerGet
                           4054 ;	genGenPointerGet
   1523 8A 82              4055 	mov	dpl,r2
   1525 8B 83              4056 	mov	dph,r3
   1527 8C F0              4057 	mov	b,r4
   1529 12 E4 9F           4058 	lcall	__gptrget
   152C FA                 4059 	mov	r2,a
   152D A3                 4060 	inc	dptr
   152E 12 E4 9F           4061 	lcall	__gptrget
   1531 FB                 4062 	mov	r3,a
   1532 A3                 4063 	inc	dptr
   1533 12 E4 9F           4064 	lcall	__gptrget
   1536 FC                 4065 	mov	r4,a
                           4066 ;	Peephole 112.b	changed ljmp to sjmp
   1537 80 06              4067 	sjmp	00112$
   1539                    4068 00111$:
                           4069 ;	genAssign
   1539 7A 00              4070 	mov	r2,#0x00
   153B 7B 00              4071 	mov	r3,#0x00
   153D 7C 00              4072 	mov	r4,#0x00
   153F                    4073 00112$:
                           4074 ;	genAssign
                           4075 ;	genAssign
   153F A8 10              4076 	mov	r0,_bp
   1541 08                 4077 	inc	r0
   1542 A6 02              4078 	mov	@r0,ar2
   1544 08                 4079 	inc	r0
   1545 A6 03              4080 	mov	@r0,ar3
   1547 08                 4081 	inc	r0
   1548 A6 04              4082 	mov	@r0,ar4
                           4083 ;	../../FreeRTOS/Source/tasks.c:1501: vListRemove( &( pxUnblockedTCB->xEventListItem ) );
                           4084 ;	genPlus
   154A A8 10              4085 	mov	r0,_bp
   154C 08                 4086 	inc	r0
                           4087 ;     genPlusIncr
   154D 74 11              4088 	mov	a,#0x11
   154F 26                 4089 	add	a,@r0
   1550 FD                 4090 	mov	r5,a
                           4091 ;	Peephole 181	changed mov to clr
   1551 E4                 4092 	clr	a
   1552 08                 4093 	inc	r0
   1553 36                 4094 	addc	a,@r0
   1554 FE                 4095 	mov	r6,a
   1555 08                 4096 	inc	r0
   1556 86 07              4097 	mov	ar7,@r0
                           4098 ;	genCall
   1558 8D 82              4099 	mov	dpl,r5
   155A 8E 83              4100 	mov	dph,r6
   155C 8F F0              4101 	mov	b,r7
   155E 12 2F 88           4102 	lcall	_vListRemove
                           4103 ;	../../FreeRTOS/Source/tasks.c:1503: if( uxSchedulerSuspended == ( unsigned portBASE_TYPE ) pdFALSE )
                           4104 ;	genAssign
   1561 90 F0 7F           4105 	mov	dptr,#_uxSchedulerSuspended
   1564 E0                 4106 	movx	a,@dptr
                           4107 ;	genIfx
   1565 FD                 4108 	mov	r5,a
                           4109 ;	Peephole 105	removed redundant mov
                           4110 ;	genIfxJump
                           4111 ;	Peephole 108.b	removed ljmp by inverse jump logic
   1566 70 70              4112 	jnz	00104$
                           4113 ;	Peephole 300	removed redundant label 00121$
                           4114 ;	../../FreeRTOS/Source/tasks.c:1505: vListRemove( &( pxUnblockedTCB->xGenericListItem ) );
                           4115 ;	genPlus
   1568 A8 10              4116 	mov	r0,_bp
   156A 08                 4117 	inc	r0
                           4118 ;     genPlusIncr
   156B 74 03              4119 	mov	a,#0x03
   156D 26                 4120 	add	a,@r0
   156E FD                 4121 	mov	r5,a
                           4122 ;	Peephole 181	changed mov to clr
   156F E4                 4123 	clr	a
   1570 08                 4124 	inc	r0
   1571 36                 4125 	addc	a,@r0
   1572 FE                 4126 	mov	r6,a
   1573 08                 4127 	inc	r0
   1574 86 07              4128 	mov	ar7,@r0
                           4129 ;	genCall
   1576 8D 82              4130 	mov	dpl,r5
   1578 8E 83              4131 	mov	dph,r6
   157A 8F F0              4132 	mov	b,r7
   157C 12 2F 88           4133 	lcall	_vListRemove
                           4134 ;	../../FreeRTOS/Source/tasks.c:1506: prvAddTaskToReadyQueue( pxUnblockedTCB );
                           4135 ;	genPlus
   157F A8 10              4136 	mov	r0,_bp
   1581 08                 4137 	inc	r0
                           4138 ;     genPlusIncr
   1582 74 1F              4139 	mov	a,#0x1F
   1584 26                 4140 	add	a,@r0
   1585 FD                 4141 	mov	r5,a
                           4142 ;	Peephole 181	changed mov to clr
   1586 E4                 4143 	clr	a
   1587 08                 4144 	inc	r0
   1588 36                 4145 	addc	a,@r0
   1589 FE                 4146 	mov	r6,a
   158A 08                 4147 	inc	r0
   158B 86 07              4148 	mov	ar7,@r0
                           4149 ;	genPointerGet
                           4150 ;	genGenPointerGet
   158D 8D 82              4151 	mov	dpl,r5
   158F 8E 83              4152 	mov	dph,r6
   1591 8F F0              4153 	mov	b,r7
   1593 12 E4 9F           4154 	lcall	__gptrget
   1596 FD                 4155 	mov	r5,a
                           4156 ;	genAssign
   1597 90 F0 7D           4157 	mov	dptr,#_uxTopReadyPriority
   159A E0                 4158 	movx	a,@dptr
                           4159 ;	genCmpGt
                           4160 ;	genCmp
   159B FE                 4161 	mov	r6,a
   159C C3                 4162 	clr	c
                           4163 ;	Peephole 106	removed redundant mov
   159D 9D                 4164 	subb	a,r5
                           4165 ;	genIfxJump
                           4166 ;	Peephole 108.a	removed ljmp by inverse jump logic
   159E 50 05              4167 	jnc	00102$
                           4168 ;	Peephole 300	removed redundant label 00122$
                           4169 ;	genAssign
   15A0 90 F0 7D           4170 	mov	dptr,#_uxTopReadyPriority
   15A3 ED                 4171 	mov	a,r5
   15A4 F0                 4172 	movx	@dptr,a
   15A5                    4173 00102$:
                           4174 ;	genPlus
   15A5 A8 10              4175 	mov	r0,_bp
   15A7 08                 4176 	inc	r0
                           4177 ;     genPlusIncr
   15A8 74 03              4178 	mov	a,#0x03
   15AA 26                 4179 	add	a,@r0
   15AB FE                 4180 	mov	r6,a
                           4181 ;	Peephole 181	changed mov to clr
   15AC E4                 4182 	clr	a
   15AD 08                 4183 	inc	r0
   15AE 36                 4184 	addc	a,@r0
   15AF FF                 4185 	mov	r7,a
   15B0 08                 4186 	inc	r0
   15B1 86 02              4187 	mov	ar2,@r0
                           4188 ;	genMult
                           4189 ;	genMultOneByte
   15B3 ED                 4190 	mov	a,r5
   15B4 75 F0 0C           4191 	mov	b,#0x0C
   15B7 A4                 4192 	mul	ab
                           4193 ;	genPlus
   15B8 24 06              4194 	add	a,#_pxReadyTasksLists
   15BA FB                 4195 	mov	r3,a
                           4196 ;	Peephole 240	use clr instead of addc a,#0
   15BB E4                 4197 	clr	a
   15BC 34 E0              4198 	addc	a,#(_pxReadyTasksLists >> 8)
   15BE FC                 4199 	mov	r4,a
                           4200 ;	genCast
   15BF 7D 00              4201 	mov	r5,#0x0
                           4202 ;	genIpush
   15C1 C0 06              4203 	push	ar6
   15C3 C0 07              4204 	push	ar7
   15C5 C0 02              4205 	push	ar2
                           4206 ;	genCall
   15C7 8B 82              4207 	mov	dpl,r3
   15C9 8C 83              4208 	mov	dph,r4
   15CB 8D F0              4209 	mov	b,r5
   15CD 12 2B 96           4210 	lcall	_vListInsertEnd
   15D0 15 81              4211 	dec	sp
   15D2 15 81              4212 	dec	sp
   15D4 15 81              4213 	dec	sp
                           4214 ;	Peephole 112.b	changed ljmp to sjmp
   15D6 80 23              4215 	sjmp	00105$
   15D8                    4216 00104$:
                           4217 ;	../../FreeRTOS/Source/tasks.c:1512: vListInsertEnd( ( xList * ) &( xPendingReadyList ), &( pxUnblockedTCB->xEventListItem ) );
                           4218 ;	genPlus
   15D8 A8 10              4219 	mov	r0,_bp
   15DA 08                 4220 	inc	r0
                           4221 ;     genPlusIncr
   15DB 74 11              4222 	mov	a,#0x11
   15DD 26                 4223 	add	a,@r0
   15DE FA                 4224 	mov	r2,a
                           4225 ;	Peephole 181	changed mov to clr
   15DF E4                 4226 	clr	a
   15E0 08                 4227 	inc	r0
   15E1 36                 4228 	addc	a,@r0
   15E2 FB                 4229 	mov	r3,a
   15E3 08                 4230 	inc	r0
   15E4 86 04              4231 	mov	ar4,@r0
                           4232 ;	genIpush
   15E6 C0 02              4233 	push	ar2
   15E8 C0 03              4234 	push	ar3
   15EA C0 04              4235 	push	ar4
                           4236 ;	genCall
                           4237 ;	Peephole 182.a	used 16 bit load of DPTR
   15EC 90 E0 54           4238 	mov	dptr,#_xPendingReadyList
   15EF 75 F0 00           4239 	mov	b,#0x00
   15F2 12 2B 96           4240 	lcall	_vListInsertEnd
   15F5 15 81              4241 	dec	sp
   15F7 15 81              4242 	dec	sp
   15F9 15 81              4243 	dec	sp
   15FB                    4244 00105$:
                           4245 ;	../../FreeRTOS/Source/tasks.c:1515: if( pxUnblockedTCB->uxPriority >= pxCurrentTCB->uxPriority )
                           4246 ;	genPlus
   15FB A8 10              4247 	mov	r0,_bp
   15FD 08                 4248 	inc	r0
                           4249 ;     genPlusIncr
   15FE 74 1F              4250 	mov	a,#0x1F
   1600 26                 4251 	add	a,@r0
   1601 FA                 4252 	mov	r2,a
                           4253 ;	Peephole 181	changed mov to clr
   1602 E4                 4254 	clr	a
   1603 08                 4255 	inc	r0
   1604 36                 4256 	addc	a,@r0
   1605 FB                 4257 	mov	r3,a
   1606 08                 4258 	inc	r0
   1607 86 04              4259 	mov	ar4,@r0
                           4260 ;	genPointerGet
                           4261 ;	genGenPointerGet
   1609 8A 82              4262 	mov	dpl,r2
   160B 8B 83              4263 	mov	dph,r3
   160D 8C F0              4264 	mov	b,r4
   160F 12 E4 9F           4265 	lcall	__gptrget
   1612 FA                 4266 	mov	r2,a
                           4267 ;	genAssign
   1613 90 F0 75           4268 	mov	dptr,#_pxCurrentTCB
   1616 E0                 4269 	movx	a,@dptr
   1617 FB                 4270 	mov	r3,a
   1618 A3                 4271 	inc	dptr
   1619 E0                 4272 	movx	a,@dptr
   161A FC                 4273 	mov	r4,a
   161B A3                 4274 	inc	dptr
   161C E0                 4275 	movx	a,@dptr
   161D FD                 4276 	mov	r5,a
                           4277 ;	genPlus
                           4278 ;     genPlusIncr
   161E 74 1F              4279 	mov	a,#0x1F
                           4280 ;	Peephole 236.a	used r3 instead of ar3
   1620 2B                 4281 	add	a,r3
   1621 FB                 4282 	mov	r3,a
                           4283 ;	Peephole 181	changed mov to clr
   1622 E4                 4284 	clr	a
                           4285 ;	Peephole 236.b	used r4 instead of ar4
   1623 3C                 4286 	addc	a,r4
   1624 FC                 4287 	mov	r4,a
                           4288 ;	genPointerGet
                           4289 ;	genGenPointerGet
   1625 8B 82              4290 	mov	dpl,r3
   1627 8C 83              4291 	mov	dph,r4
   1629 8D F0              4292 	mov	b,r5
   162B 12 E4 9F           4293 	lcall	__gptrget
   162E FB                 4294 	mov	r3,a
                           4295 ;	genCmpLt
                           4296 ;	genCmp
   162F C3                 4297 	clr	c
   1630 EA                 4298 	mov	a,r2
   1631 9B                 4299 	subb	a,r3
                           4300 ;	genIfxJump
                           4301 ;	Peephole 112.b	changed ljmp to sjmp
                           4302 ;	Peephole 160.a	removed sjmp by inverse jump logic
   1632 40 04              4303 	jc	00107$
                           4304 ;	Peephole 300	removed redundant label 00123$
                           4305 ;	../../FreeRTOS/Source/tasks.c:1521: xReturn = pdTRUE;
                           4306 ;	genAssign
   1634 7A 01              4307 	mov	r2,#0x01
                           4308 ;	Peephole 112.b	changed ljmp to sjmp
   1636 80 02              4309 	sjmp	00108$
   1638                    4310 00107$:
                           4311 ;	../../FreeRTOS/Source/tasks.c:1525: xReturn = pdFALSE;
                           4312 ;	genAssign
   1638 7A 00              4313 	mov	r2,#0x00
   163A                    4314 00108$:
                           4315 ;	../../FreeRTOS/Source/tasks.c:1528: return xReturn;
                           4316 ;	genRet
   163A 8A 82              4317 	mov	dpl,r2
                           4318 ;	Peephole 300	removed redundant label 00109$
   163C 85 10 81           4319 	mov	sp,_bp
   163F D0 10              4320 	pop	_bp
   1641 22                 4321 	ret
                           4322 ;------------------------------------------------------------
                           4323 ;Allocation info for local variables in function 'vTaskSetTimeOutState'
                           4324 ;------------------------------------------------------------
                           4325 ;pxTimeOut                 Allocated to registers r2 r3 r4 
                           4326 ;------------------------------------------------------------
                           4327 ;	../../FreeRTOS/Source/tasks.c:1532: void vTaskSetTimeOutState( xTimeOutType *pxTimeOut )
                           4328 ;	-----------------------------------------
                           4329 ;	 function vTaskSetTimeOutState
                           4330 ;	-----------------------------------------
   1642                    4331 _vTaskSetTimeOutState:
                           4332 ;	genReceive
   1642 AA 82              4333 	mov	r2,dpl
   1644 AB 83              4334 	mov	r3,dph
   1646 AC F0              4335 	mov	r4,b
                           4336 ;	../../FreeRTOS/Source/tasks.c:1534: pxTimeOut->xOverflowCount = xNumOfOverflows;
                           4337 ;	genAssign
   1648 90 F0 82           4338 	mov	dptr,#_xNumOfOverflows
   164B E0                 4339 	movx	a,@dptr
                           4340 ;	genPointerSet
                           4341 ;	genGenPointerSet
   164C FD                 4342 	mov	r5,a
   164D 8A 82              4343 	mov	dpl,r2
   164F 8B 83              4344 	mov	dph,r3
   1651 8C F0              4345 	mov	b,r4
                           4346 ;	Peephole 191	removed redundant mov
   1653 12 DF B7           4347 	lcall	__gptrput
                           4348 ;	../../FreeRTOS/Source/tasks.c:1535: pxTimeOut->xTimeOnEntering = xTickCount;
                           4349 ;	genPlus
                           4350 ;     genPlusIncr
   1656 0A                 4351 	inc	r2
   1657 BA 00 01           4352 	cjne	r2,#0x00,00103$
   165A 0B                 4353 	inc	r3
   165B                    4354 00103$:
                           4355 ;	genAssign
   165B 90 F0 7A           4356 	mov	dptr,#_xTickCount
   165E E0                 4357 	movx	a,@dptr
   165F FD                 4358 	mov	r5,a
   1660 A3                 4359 	inc	dptr
   1661 E0                 4360 	movx	a,@dptr
   1662 FE                 4361 	mov	r6,a
                           4362 ;	genPointerSet
                           4363 ;	genGenPointerSet
   1663 8A 82              4364 	mov	dpl,r2
   1665 8B 83              4365 	mov	dph,r3
   1667 8C F0              4366 	mov	b,r4
   1669 ED                 4367 	mov	a,r5
   166A 12 DF B7           4368 	lcall	__gptrput
   166D A3                 4369 	inc	dptr
   166E EE                 4370 	mov	a,r6
                           4371 ;	Peephole 253.b	replaced lcall/ret with ljmp
   166F 02 DF B7           4372 	ljmp	__gptrput
                           4373 ;
                           4374 ;------------------------------------------------------------
                           4375 ;Allocation info for local variables in function 'xTaskCheckForTimeOut'
                           4376 ;------------------------------------------------------------
                           4377 ;pxTicksToWait             Allocated to stack - offset -5
                           4378 ;pxTimeOut                 Allocated to stack - offset 1
                           4379 ;xReturn                   Allocated to registers r5 
                           4380 ;sloc0                     Allocated to stack - offset 4
                           4381 ;sloc1                     Allocated to stack - offset 8
                           4382 ;------------------------------------------------------------
                           4383 ;	../../FreeRTOS/Source/tasks.c:1539: portBASE_TYPE xTaskCheckForTimeOut( xTimeOutType *pxTimeOut, portTickType *pxTicksToWait )
                           4384 ;	-----------------------------------------
                           4385 ;	 function xTaskCheckForTimeOut
                           4386 ;	-----------------------------------------
   1672                    4387 _xTaskCheckForTimeOut:
   1672 C0 10              4388 	push	_bp
   1674 85 81 10           4389 	mov	_bp,sp
                           4390 ;     genReceive
   1677 C0 82              4391 	push	dpl
   1679 C0 83              4392 	push	dph
   167B C0 F0              4393 	push	b
   167D 05 81              4394 	inc	sp
   167F 05 81              4395 	inc	sp
   1681 05 81              4396 	inc	sp
                           4397 ;	../../FreeRTOS/Source/tasks.c:1543: if( ( xNumOfOverflows != pxTimeOut->xOverflowCount ) && ( xTickCount > pxTimeOut->xTimeOnEntering ) )
                           4398 ;	genPointerGet
                           4399 ;	genGenPointerGet
   1683 A8 10              4400 	mov	r0,_bp
   1685 08                 4401 	inc	r0
   1686 86 82              4402 	mov	dpl,@r0
   1688 08                 4403 	inc	r0
   1689 86 83              4404 	mov	dph,@r0
   168B 08                 4405 	inc	r0
   168C 86 F0              4406 	mov	b,@r0
   168E 12 E4 9F           4407 	lcall	__gptrget
   1691 FD                 4408 	mov	r5,a
                           4409 ;	genAssign
   1692 90 F0 82           4410 	mov	dptr,#_xNumOfOverflows
   1695 E0                 4411 	movx	a,@dptr
                           4412 ;	genCmpEq
                           4413 ;	gencjneshort
   1696 FE                 4414 	mov	r6,a
                           4415 ;	Peephole 105	removed redundant mov
   1697 B5 05 02           4416 	cjne	a,ar5,00113$
                           4417 ;	Peephole 112.b	changed ljmp to sjmp
   169A 80 31              4418 	sjmp	00105$
   169C                    4419 00113$:
                           4420 ;	genPlus
   169C A8 10              4421 	mov	r0,_bp
   169E 08                 4422 	inc	r0
                           4423 ;     genPlusIncr
   169F 74 01              4424 	mov	a,#0x01
   16A1 26                 4425 	add	a,@r0
   16A2 FD                 4426 	mov	r5,a
                           4427 ;	Peephole 181	changed mov to clr
   16A3 E4                 4428 	clr	a
   16A4 08                 4429 	inc	r0
   16A5 36                 4430 	addc	a,@r0
   16A6 FE                 4431 	mov	r6,a
   16A7 08                 4432 	inc	r0
   16A8 86 07              4433 	mov	ar7,@r0
                           4434 ;	genPointerGet
                           4435 ;	genGenPointerGet
   16AA 8D 82              4436 	mov	dpl,r5
   16AC 8E 83              4437 	mov	dph,r6
   16AE 8F F0              4438 	mov	b,r7
   16B0 12 E4 9F           4439 	lcall	__gptrget
   16B3 FD                 4440 	mov	r5,a
   16B4 A3                 4441 	inc	dptr
   16B5 12 E4 9F           4442 	lcall	__gptrget
   16B8 FE                 4443 	mov	r6,a
                           4444 ;	genIpush
                           4445 ;	genAssign
   16B9 90 F0 7A           4446 	mov	dptr,#_xTickCount
   16BC E0                 4447 	movx	a,@dptr
   16BD FF                 4448 	mov	r7,a
   16BE A3                 4449 	inc	dptr
   16BF E0                 4450 	movx	a,@dptr
   16C0 FA                 4451 	mov	r2,a
                           4452 ;	genCmpGt
                           4453 ;	genCmp
   16C1 C3                 4454 	clr	c
   16C2 ED                 4455 	mov	a,r5
   16C3 9F                 4456 	subb	a,r7
   16C4 EE                 4457 	mov	a,r6
   16C5 9A                 4458 	subb	a,r2
                           4459 ;	genIpop
                           4460 ;	genIfx
                           4461 ;	genIfxJump
                           4462 ;	Peephole 108.c	removed ljmp by inverse jump logic
                           4463 ;	Peephole 128	jump optimization
   16C6 50 05              4464 	jnc	00105$
                           4465 ;	Peephole 300	removed redundant label 00114$
                           4466 ;	../../FreeRTOS/Source/tasks.c:1549: xReturn = pdTRUE;
                           4467 ;	genAssign
   16C8 7D 01              4468 	mov	r5,#0x01
   16CA 02 17 6A           4469 	ljmp	00106$
   16CD                    4470 00105$:
                           4471 ;	../../FreeRTOS/Source/tasks.c:1551: else if( ( xTickCount - pxTimeOut->xTimeOnEntering ) < *pxTicksToWait )
                           4472 ;	genPlus
   16CD A8 10              4473 	mov	r0,_bp
   16CF 08                 4474 	inc	r0
                           4475 ;     genPlusIncr
   16D0 74 01              4476 	mov	a,#0x01
   16D2 26                 4477 	add	a,@r0
   16D3 FE                 4478 	mov	r6,a
                           4479 ;	Peephole 181	changed mov to clr
   16D4 E4                 4480 	clr	a
   16D5 08                 4481 	inc	r0
   16D6 36                 4482 	addc	a,@r0
   16D7 FF                 4483 	mov	r7,a
   16D8 08                 4484 	inc	r0
   16D9 86 02              4485 	mov	ar2,@r0
                           4486 ;	genPointerGet
                           4487 ;	genGenPointerGet
   16DB 8E 82              4488 	mov	dpl,r6
   16DD 8F 83              4489 	mov	dph,r7
   16DF 8A F0              4490 	mov	b,r2
   16E1 12 E4 9F           4491 	lcall	__gptrget
   16E4 FA                 4492 	mov	r2,a
   16E5 A3                 4493 	inc	dptr
   16E6 12 E4 9F           4494 	lcall	__gptrget
   16E9 FB                 4495 	mov	r3,a
                           4496 ;	genAssign
   16EA 90 F0 7A           4497 	mov	dptr,#_xTickCount
   16ED E0                 4498 	movx	a,@dptr
   16EE FC                 4499 	mov	r4,a
   16EF A3                 4500 	inc	dptr
   16F0 E0                 4501 	movx	a,@dptr
   16F1 FE                 4502 	mov	r6,a
                           4503 ;	genMinus
   16F2 EC                 4504 	mov	a,r4
   16F3 C3                 4505 	clr	c
                           4506 ;	Peephole 236.l	used r2 instead of ar2
   16F4 9A                 4507 	subb	a,r2
   16F5 FC                 4508 	mov	r4,a
   16F6 EE                 4509 	mov	a,r6
                           4510 ;	Peephole 236.l	used r3 instead of ar3
   16F7 9B                 4511 	subb	a,r3
   16F8 FE                 4512 	mov	r6,a
                           4513 ;	genAssign
   16F9 E5 10              4514 	mov	a,_bp
   16FB 24 FB              4515 	add	a,#0xfffffffb
   16FD F8                 4516 	mov	r0,a
   16FE E5 10              4517 	mov	a,_bp
   1700 24 04              4518 	add	a,#0x04
   1702 F9                 4519 	mov	r1,a
   1703 E6                 4520 	mov	a,@r0
   1704 F7                 4521 	mov	@r1,a
   1705 08                 4522 	inc	r0
   1706 09                 4523 	inc	r1
   1707 E6                 4524 	mov	a,@r0
   1708 F7                 4525 	mov	@r1,a
   1709 08                 4526 	inc	r0
   170A 09                 4527 	inc	r1
   170B E6                 4528 	mov	a,@r0
   170C F7                 4529 	mov	@r1,a
                           4530 ;	genPointerGet
                           4531 ;	genGenPointerGet
   170D E5 10              4532 	mov	a,_bp
   170F 24 04              4533 	add	a,#0x04
   1711 F8                 4534 	mov	r0,a
   1712 86 82              4535 	mov	dpl,@r0
   1714 08                 4536 	inc	r0
   1715 86 83              4537 	mov	dph,@r0
   1717 08                 4538 	inc	r0
   1718 86 F0              4539 	mov	b,@r0
   171A 12 E4 9F           4540 	lcall	__gptrget
   171D FD                 4541 	mov	r5,a
   171E A3                 4542 	inc	dptr
   171F 12 E4 9F           4543 	lcall	__gptrget
   1722 FF                 4544 	mov	r7,a
                           4545 ;	genCmpLt
                           4546 ;	genCmp
   1723 C3                 4547 	clr	c
   1724 EC                 4548 	mov	a,r4
   1725 9D                 4549 	subb	a,r5
   1726 EE                 4550 	mov	a,r6
   1727 9F                 4551 	subb	a,r7
                           4552 ;	genIfxJump
                           4553 ;	Peephole 108.a	removed ljmp by inverse jump logic
   1728 50 3E              4554 	jnc	00102$
                           4555 ;	Peephole 300	removed redundant label 00115$
                           4556 ;	../../FreeRTOS/Source/tasks.c:1554: *pxTicksToWait -= ( xTickCount - pxTimeOut->xTimeOnEntering );
                           4557 ;	genAssign
   172A 90 F0 7A           4558 	mov	dptr,#_xTickCount
   172D E0                 4559 	movx	a,@dptr
   172E FC                 4560 	mov	r4,a
   172F A3                 4561 	inc	dptr
   1730 E0                 4562 	movx	a,@dptr
   1731 FE                 4563 	mov	r6,a
                           4564 ;	genMinus
   1732 EC                 4565 	mov	a,r4
   1733 C3                 4566 	clr	c
                           4567 ;	Peephole 236.l	used r2 instead of ar2
   1734 9A                 4568 	subb	a,r2
   1735 FA                 4569 	mov	r2,a
   1736 EE                 4570 	mov	a,r6
                           4571 ;	Peephole 236.l	used r3 instead of ar3
   1737 9B                 4572 	subb	a,r3
   1738 FB                 4573 	mov	r3,a
                           4574 ;	genMinus
   1739 ED                 4575 	mov	a,r5
   173A C3                 4576 	clr	c
                           4577 ;	Peephole 236.l	used r2 instead of ar2
   173B 9A                 4578 	subb	a,r2
   173C FA                 4579 	mov	r2,a
   173D EF                 4580 	mov	a,r7
                           4581 ;	Peephole 236.l	used r3 instead of ar3
   173E 9B                 4582 	subb	a,r3
   173F FB                 4583 	mov	r3,a
                           4584 ;	genPointerSet
                           4585 ;	genGenPointerSet
   1740 E5 10              4586 	mov	a,_bp
   1742 24 04              4587 	add	a,#0x04
   1744 F8                 4588 	mov	r0,a
   1745 86 82              4589 	mov	dpl,@r0
   1747 08                 4590 	inc	r0
   1748 86 83              4591 	mov	dph,@r0
   174A 08                 4592 	inc	r0
   174B 86 F0              4593 	mov	b,@r0
   174D EA                 4594 	mov	a,r2
   174E 12 DF B7           4595 	lcall	__gptrput
   1751 A3                 4596 	inc	dptr
   1752 EB                 4597 	mov	a,r3
   1753 12 DF B7           4598 	lcall	__gptrput
                           4599 ;	../../FreeRTOS/Source/tasks.c:1555: vTaskSetTimeOutState( pxTimeOut );
                           4600 ;	genCall
   1756 A8 10              4601 	mov	r0,_bp
   1758 08                 4602 	inc	r0
   1759 86 82              4603 	mov	dpl,@r0
   175B 08                 4604 	inc	r0
   175C 86 83              4605 	mov	dph,@r0
   175E 08                 4606 	inc	r0
   175F 86 F0              4607 	mov	b,@r0
   1761 12 16 42           4608 	lcall	_vTaskSetTimeOutState
                           4609 ;	../../FreeRTOS/Source/tasks.c:1556: xReturn = pdFALSE;
                           4610 ;	genAssign
   1764 7D 00              4611 	mov	r5,#0x00
                           4612 ;	Peephole 112.b	changed ljmp to sjmp
   1766 80 02              4613 	sjmp	00106$
   1768                    4614 00102$:
                           4615 ;	../../FreeRTOS/Source/tasks.c:1560: xReturn = pdTRUE;
                           4616 ;	genAssign
   1768 7D 01              4617 	mov	r5,#0x01
   176A                    4618 00106$:
                           4619 ;	../../FreeRTOS/Source/tasks.c:1563: return xReturn;
                           4620 ;	genRet
   176A 8D 82              4621 	mov	dpl,r5
                           4622 ;	Peephole 300	removed redundant label 00108$
   176C 85 10 81           4623 	mov	sp,_bp
   176F D0 10              4624 	pop	_bp
   1771 22                 4625 	ret
                           4626 ;------------------------------------------------------------
                           4627 ;Allocation info for local variables in function 'vTaskMissedYield'
                           4628 ;------------------------------------------------------------
                           4629 ;------------------------------------------------------------
                           4630 ;	../../FreeRTOS/Source/tasks.c:1567: void vTaskMissedYield( void )
                           4631 ;	-----------------------------------------
                           4632 ;	 function vTaskMissedYield
                           4633 ;	-----------------------------------------
   1772                    4634 _vTaskMissedYield:
                           4635 ;	../../FreeRTOS/Source/tasks.c:1569: xMissedYield = pdTRUE;
                           4636 ;	genAssign
   1772 90 F0 81           4637 	mov	dptr,#_xMissedYield
   1775 74 01              4638 	mov	a,#0x01
   1777 F0                 4639 	movx	@dptr,a
                           4640 ;	Peephole 300	removed redundant label 00101$
   1778 22                 4641 	ret
                           4642 ;------------------------------------------------------------
                           4643 ;Allocation info for local variables in function 'prvIdleTask'
                           4644 ;------------------------------------------------------------
                           4645 ;pvParameters              Allocated to registers 
                           4646 ;------------------------------------------------------------
                           4647 ;	../../FreeRTOS/Source/tasks.c:1583: static portTASK_FUNCTION( prvIdleTask, pvParameters )
                           4648 ;	-----------------------------------------
                           4649 ;	 function prvIdleTask
                           4650 ;	-----------------------------------------
   1779                    4651 _prvIdleTask:
                           4652 ;	../../FreeRTOS/Source/tasks.c:1586: ( void ) pvParameters;
   1779                    4653 00102$:
                           4654 ;	../../FreeRTOS/Source/tasks.c:1591: prvCheckTasksWaitingTermination();
                           4655 ;	genCall
   1779 12 19 51           4656 	lcall	_prvCheckTasksWaitingTermination
                           4657 ;	Peephole 112.b	changed ljmp to sjmp
   177C 80 FB              4658 	sjmp	00102$
                           4659 ;	Peephole 259.a	removed redundant label 00104$ and ret
                           4660 ;
                           4661 ;------------------------------------------------------------
                           4662 ;Allocation info for local variables in function 'prvInitialiseTCBVariables'
                           4663 ;------------------------------------------------------------
                           4664 ;usStackDepth              Allocated to stack - offset -4
                           4665 ;pcName                    Allocated to stack - offset -7
                           4666 ;uxPriority                Allocated to stack - offset -8
                           4667 ;pxTCB                     Allocated to stack - offset 1
                           4668 ;------------------------------------------------------------
                           4669 ;	../../FreeRTOS/Source/tasks.c:1648: static void prvInitialiseTCBVariables( tskTCB *pxTCB, unsigned portSHORT usStackDepth, const signed portCHAR * const pcName, unsigned portBASE_TYPE uxPriority )
                           4670 ;	-----------------------------------------
                           4671 ;	 function prvInitialiseTCBVariables
                           4672 ;	-----------------------------------------
   177E                    4673 _prvInitialiseTCBVariables:
   177E C0 10              4674 	push	_bp
   1780 85 81 10           4675 	mov	_bp,sp
                           4676 ;     genReceive
   1783 C0 82              4677 	push	dpl
   1785 C0 83              4678 	push	dph
   1787 C0 F0              4679 	push	b
                           4680 ;	../../FreeRTOS/Source/tasks.c:1650: pxTCB->usStackDepth = usStackDepth;
                           4681 ;	genPlus
   1789 A8 10              4682 	mov	r0,_bp
   178B 08                 4683 	inc	r0
                           4684 ;     genPlusIncr
   178C 74 2C              4685 	mov	a,#0x2C
   178E 26                 4686 	add	a,@r0
   178F FD                 4687 	mov	r5,a
                           4688 ;	Peephole 181	changed mov to clr
   1790 E4                 4689 	clr	a
   1791 08                 4690 	inc	r0
   1792 36                 4691 	addc	a,@r0
   1793 FE                 4692 	mov	r6,a
   1794 08                 4693 	inc	r0
   1795 86 07              4694 	mov	ar7,@r0
                           4695 ;	genPointerSet
                           4696 ;	genGenPointerSet
   1797 8D 82              4697 	mov	dpl,r5
   1799 8E 83              4698 	mov	dph,r6
   179B 8F F0              4699 	mov	b,r7
   179D E5 10              4700 	mov	a,_bp
   179F 24 FC              4701 	add	a,#0xfffffffc
   17A1 F8                 4702 	mov	r0,a
   17A2 E6                 4703 	mov	a,@r0
   17A3 12 DF B7           4704 	lcall	__gptrput
   17A6 A3                 4705 	inc	dptr
   17A7 08                 4706 	inc	r0
   17A8 E6                 4707 	mov	a,@r0
   17A9 12 DF B7           4708 	lcall	__gptrput
                           4709 ;	../../FreeRTOS/Source/tasks.c:1653: strncpy( ( char * ) pxTCB->pcTaskName, ( const char * ) pcName, ( unsigned portSHORT ) configMAX_TASK_NAME_LEN );
                           4710 ;	genPlus
   17AC A8 10              4711 	mov	r0,_bp
   17AE 08                 4712 	inc	r0
                           4713 ;     genPlusIncr
   17AF 74 24              4714 	mov	a,#0x24
   17B1 26                 4715 	add	a,@r0
   17B2 FD                 4716 	mov	r5,a
                           4717 ;	Peephole 181	changed mov to clr
   17B3 E4                 4718 	clr	a
   17B4 08                 4719 	inc	r0
   17B5 36                 4720 	addc	a,@r0
   17B6 FE                 4721 	mov	r6,a
   17B7 08                 4722 	inc	r0
   17B8 86 07              4723 	mov	ar7,@r0
                           4724 ;	genIpush
   17BA 74 08              4725 	mov	a,#0x08
   17BC C0 E0              4726 	push	acc
                           4727 ;	Peephole 181	changed mov to clr
   17BE E4                 4728 	clr	a
   17BF C0 E0              4729 	push	acc
                           4730 ;	genIpush
   17C1 E5 10              4731 	mov	a,_bp
   17C3 24 F9              4732 	add	a,#0xfffffff9
   17C5 F8                 4733 	mov	r0,a
   17C6 E6                 4734 	mov	a,@r0
   17C7 C0 E0              4735 	push	acc
   17C9 08                 4736 	inc	r0
   17CA E6                 4737 	mov	a,@r0
   17CB C0 E0              4738 	push	acc
   17CD 08                 4739 	inc	r0
   17CE E6                 4740 	mov	a,@r0
   17CF C0 E0              4741 	push	acc
                           4742 ;	genCall
   17D1 8D 82              4743 	mov	dpl,r5
   17D3 8E 83              4744 	mov	dph,r6
   17D5 8F F0              4745 	mov	b,r7
   17D7 12 E3 D0           4746 	lcall	_strncpy
   17DA E5 81              4747 	mov	a,sp
   17DC 24 FB              4748 	add	a,#0xfb
   17DE F5 81              4749 	mov	sp,a
                           4750 ;	../../FreeRTOS/Source/tasks.c:1654: pxTCB->pcTaskName[ ( unsigned portSHORT ) configMAX_TASK_NAME_LEN - ( unsigned portSHORT ) 1 ] = '\0';
                           4751 ;	genPlus
   17E0 A8 10              4752 	mov	r0,_bp
   17E2 08                 4753 	inc	r0
                           4754 ;     genPlusIncr
   17E3 74 24              4755 	mov	a,#0x24
   17E5 26                 4756 	add	a,@r0
   17E6 FD                 4757 	mov	r5,a
                           4758 ;	Peephole 181	changed mov to clr
   17E7 E4                 4759 	clr	a
   17E8 08                 4760 	inc	r0
   17E9 36                 4761 	addc	a,@r0
   17EA FE                 4762 	mov	r6,a
   17EB 08                 4763 	inc	r0
   17EC 86 07              4764 	mov	ar7,@r0
                           4765 ;	genPlus
                           4766 ;     genPlusIncr
   17EE 74 07              4767 	mov	a,#0x07
                           4768 ;	Peephole 236.a	used r5 instead of ar5
   17F0 2D                 4769 	add	a,r5
   17F1 FD                 4770 	mov	r5,a
                           4771 ;	Peephole 181	changed mov to clr
   17F2 E4                 4772 	clr	a
                           4773 ;	Peephole 236.b	used r6 instead of ar6
   17F3 3E                 4774 	addc	a,r6
   17F4 FE                 4775 	mov	r6,a
                           4776 ;	genPointerSet
                           4777 ;	genGenPointerSet
   17F5 8D 82              4778 	mov	dpl,r5
   17F7 8E 83              4779 	mov	dph,r6
   17F9 8F F0              4780 	mov	b,r7
                           4781 ;	Peephole 181	changed mov to clr
   17FB E4                 4782 	clr	a
   17FC 12 DF B7           4783 	lcall	__gptrput
                           4784 ;	../../FreeRTOS/Source/tasks.c:1657: if( uxPriority >= configMAX_PRIORITIES )
                           4785 ;	genCmpLt
   17FF E5 10              4786 	mov	a,_bp
   1801 24 F8              4787 	add	a,#0xfffffff8
   1803 F8                 4788 	mov	r0,a
                           4789 ;	genCmp
   1804 B6 04 00           4790 	cjne	@r0,#0x04,00106$
   1807                    4791 00106$:
                           4792 ;	genIfxJump
                           4793 ;	Peephole 112.b	changed ljmp to sjmp
                           4794 ;	Peephole 160.a	removed sjmp by inverse jump logic
   1807 40 07              4795 	jc	00102$
                           4796 ;	Peephole 300	removed redundant label 00107$
                           4797 ;	../../FreeRTOS/Source/tasks.c:1659: uxPriority = configMAX_PRIORITIES - 1;
                           4798 ;	genAssign
   1809 E5 10              4799 	mov	a,_bp
   180B 24 F8              4800 	add	a,#0xfffffff8
   180D F8                 4801 	mov	r0,a
   180E 76 03              4802 	mov	@r0,#0x03
   1810                    4803 00102$:
                           4804 ;	../../FreeRTOS/Source/tasks.c:1662: pxTCB->uxPriority = uxPriority;
                           4805 ;	genPlus
   1810 A8 10              4806 	mov	r0,_bp
   1812 08                 4807 	inc	r0
                           4808 ;     genPlusIncr
   1813 74 1F              4809 	mov	a,#0x1F
   1815 26                 4810 	add	a,@r0
   1816 FD                 4811 	mov	r5,a
                           4812 ;	Peephole 181	changed mov to clr
   1817 E4                 4813 	clr	a
   1818 08                 4814 	inc	r0
   1819 36                 4815 	addc	a,@r0
   181A FE                 4816 	mov	r6,a
   181B 08                 4817 	inc	r0
   181C 86 07              4818 	mov	ar7,@r0
                           4819 ;	genPointerSet
                           4820 ;	genGenPointerSet
   181E 8D 82              4821 	mov	dpl,r5
   1820 8E 83              4822 	mov	dph,r6
   1822 8F F0              4823 	mov	b,r7
   1824 E5 10              4824 	mov	a,_bp
   1826 24 F8              4825 	add	a,#0xfffffff8
   1828 F8                 4826 	mov	r0,a
   1829 E6                 4827 	mov	a,@r0
   182A 12 DF B7           4828 	lcall	__gptrput
                           4829 ;	../../FreeRTOS/Source/tasks.c:1664: vListInitialiseItem( &( pxTCB->xGenericListItem ) );
                           4830 ;	genPlus
   182D A8 10              4831 	mov	r0,_bp
   182F 08                 4832 	inc	r0
                           4833 ;     genPlusIncr
   1830 74 03              4834 	mov	a,#0x03
   1832 26                 4835 	add	a,@r0
   1833 FD                 4836 	mov	r5,a
                           4837 ;	Peephole 181	changed mov to clr
   1834 E4                 4838 	clr	a
   1835 08                 4839 	inc	r0
   1836 36                 4840 	addc	a,@r0
   1837 FE                 4841 	mov	r6,a
   1838 08                 4842 	inc	r0
   1839 86 07              4843 	mov	ar7,@r0
                           4844 ;	genCall
   183B 8D 82              4845 	mov	dpl,r5
   183D 8E 83              4846 	mov	dph,r6
   183F 8F F0              4847 	mov	b,r7
   1841 12 2B 75           4848 	lcall	_vListInitialiseItem
                           4849 ;	../../FreeRTOS/Source/tasks.c:1665: vListInitialiseItem( &( pxTCB->xEventListItem ) );
                           4850 ;	genPlus
   1844 A8 10              4851 	mov	r0,_bp
   1846 08                 4852 	inc	r0
                           4853 ;     genPlusIncr
   1847 74 11              4854 	mov	a,#0x11
   1849 26                 4855 	add	a,@r0
   184A FD                 4856 	mov	r5,a
                           4857 ;	Peephole 181	changed mov to clr
   184B E4                 4858 	clr	a
   184C 08                 4859 	inc	r0
   184D 36                 4860 	addc	a,@r0
   184E FE                 4861 	mov	r6,a
   184F 08                 4862 	inc	r0
   1850 86 07              4863 	mov	ar7,@r0
                           4864 ;	genCall
   1852 8D 82              4865 	mov	dpl,r5
   1854 8E 83              4866 	mov	dph,r6
   1856 8F F0              4867 	mov	b,r7
   1858 12 2B 75           4868 	lcall	_vListInitialiseItem
                           4869 ;	../../FreeRTOS/Source/tasks.c:1669: listSET_LIST_ITEM_OWNER( &( pxTCB->xGenericListItem ), pxTCB );
                           4870 ;	genPlus
   185B A8 10              4871 	mov	r0,_bp
   185D 08                 4872 	inc	r0
                           4873 ;     genPlusIncr
   185E 74 03              4874 	mov	a,#0x03
   1860 26                 4875 	add	a,@r0
   1861 FD                 4876 	mov	r5,a
                           4877 ;	Peephole 181	changed mov to clr
   1862 E4                 4878 	clr	a
   1863 08                 4879 	inc	r0
   1864 36                 4880 	addc	a,@r0
   1865 FE                 4881 	mov	r6,a
   1866 08                 4882 	inc	r0
   1867 86 07              4883 	mov	ar7,@r0
                           4884 ;	genPlus
                           4885 ;     genPlusIncr
   1869 74 08              4886 	mov	a,#0x08
                           4887 ;	Peephole 236.a	used r5 instead of ar5
   186B 2D                 4888 	add	a,r5
   186C FD                 4889 	mov	r5,a
                           4890 ;	Peephole 181	changed mov to clr
   186D E4                 4891 	clr	a
                           4892 ;	Peephole 236.b	used r6 instead of ar6
   186E 3E                 4893 	addc	a,r6
   186F FE                 4894 	mov	r6,a
                           4895 ;	genPointerSet
                           4896 ;	genGenPointerSet
   1870 8D 82              4897 	mov	dpl,r5
   1872 8E 83              4898 	mov	dph,r6
   1874 8F F0              4899 	mov	b,r7
   1876 A8 10              4900 	mov	r0,_bp
   1878 08                 4901 	inc	r0
   1879 E6                 4902 	mov	a,@r0
   187A 12 DF B7           4903 	lcall	__gptrput
   187D A3                 4904 	inc	dptr
   187E 08                 4905 	inc	r0
   187F E6                 4906 	mov	a,@r0
   1880 12 DF B7           4907 	lcall	__gptrput
   1883 A3                 4908 	inc	dptr
   1884 08                 4909 	inc	r0
   1885 E6                 4910 	mov	a,@r0
   1886 12 DF B7           4911 	lcall	__gptrput
                           4912 ;	../../FreeRTOS/Source/tasks.c:1672: listSET_LIST_ITEM_VALUE( &( pxTCB->xEventListItem ), configMAX_PRIORITIES - ( portTickType ) uxPriority );
                           4913 ;	genPlus
   1889 A8 10              4914 	mov	r0,_bp
   188B 08                 4915 	inc	r0
                           4916 ;     genPlusIncr
   188C 74 11              4917 	mov	a,#0x11
   188E 26                 4918 	add	a,@r0
   188F FD                 4919 	mov	r5,a
                           4920 ;	Peephole 181	changed mov to clr
   1890 E4                 4921 	clr	a
   1891 08                 4922 	inc	r0
   1892 36                 4923 	addc	a,@r0
   1893 FE                 4924 	mov	r6,a
   1894 08                 4925 	inc	r0
   1895 86 07              4926 	mov	ar7,@r0
                           4927 ;	genCast
   1897 E5 10              4928 	mov	a,_bp
   1899 24 F8              4929 	add	a,#0xfffffff8
   189B F8                 4930 	mov	r0,a
   189C 86 02              4931 	mov	ar2,@r0
   189E 7B 00              4932 	mov	r3,#0x00
                           4933 ;	genMinus
   18A0 74 04              4934 	mov	a,#0x04
   18A2 C3                 4935 	clr	c
                           4936 ;	Peephole 236.l	used r2 instead of ar2
   18A3 9A                 4937 	subb	a,r2
   18A4 FA                 4938 	mov	r2,a
                           4939 ;	Peephole 181	changed mov to clr
   18A5 E4                 4940 	clr	a
                           4941 ;	Peephole 236.l	used r3 instead of ar3
   18A6 9B                 4942 	subb	a,r3
   18A7 FB                 4943 	mov	r3,a
                           4944 ;	genPointerSet
                           4945 ;	genGenPointerSet
   18A8 8D 82              4946 	mov	dpl,r5
   18AA 8E 83              4947 	mov	dph,r6
   18AC 8F F0              4948 	mov	b,r7
   18AE EA                 4949 	mov	a,r2
   18AF 12 DF B7           4950 	lcall	__gptrput
   18B2 A3                 4951 	inc	dptr
   18B3 EB                 4952 	mov	a,r3
   18B4 12 DF B7           4953 	lcall	__gptrput
                           4954 ;	../../FreeRTOS/Source/tasks.c:1673: listSET_LIST_ITEM_OWNER( &( pxTCB->xEventListItem ), pxTCB );
                           4955 ;	genPlus
   18B7 A8 10              4956 	mov	r0,_bp
   18B9 08                 4957 	inc	r0
                           4958 ;     genPlusIncr
   18BA 74 11              4959 	mov	a,#0x11
   18BC 26                 4960 	add	a,@r0
   18BD FA                 4961 	mov	r2,a
                           4962 ;	Peephole 181	changed mov to clr
   18BE E4                 4963 	clr	a
   18BF 08                 4964 	inc	r0
   18C0 36                 4965 	addc	a,@r0
   18C1 FB                 4966 	mov	r3,a
   18C2 08                 4967 	inc	r0
   18C3 86 04              4968 	mov	ar4,@r0
                           4969 ;	genPlus
                           4970 ;     genPlusIncr
   18C5 74 08              4971 	mov	a,#0x08
                           4972 ;	Peephole 236.a	used r2 instead of ar2
   18C7 2A                 4973 	add	a,r2
   18C8 FA                 4974 	mov	r2,a
                           4975 ;	Peephole 181	changed mov to clr
   18C9 E4                 4976 	clr	a
                           4977 ;	Peephole 236.b	used r3 instead of ar3
   18CA 3B                 4978 	addc	a,r3
   18CB FB                 4979 	mov	r3,a
                           4980 ;	genPointerSet
                           4981 ;	genGenPointerSet
   18CC 8A 82              4982 	mov	dpl,r2
   18CE 8B 83              4983 	mov	dph,r3
   18D0 8C F0              4984 	mov	b,r4
   18D2 A8 10              4985 	mov	r0,_bp
   18D4 08                 4986 	inc	r0
   18D5 E6                 4987 	mov	a,@r0
   18D6 12 DF B7           4988 	lcall	__gptrput
   18D9 A3                 4989 	inc	dptr
   18DA 08                 4990 	inc	r0
   18DB E6                 4991 	mov	a,@r0
   18DC 12 DF B7           4992 	lcall	__gptrput
   18DF A3                 4993 	inc	dptr
   18E0 08                 4994 	inc	r0
   18E1 E6                 4995 	mov	a,@r0
   18E2 12 DF B7           4996 	lcall	__gptrput
                           4997 ;	Peephole 300	removed redundant label 00103$
   18E5 85 10 81           4998 	mov	sp,_bp
   18E8 D0 10              4999 	pop	_bp
   18EA 22                 5000 	ret
                           5001 ;------------------------------------------------------------
                           5002 ;Allocation info for local variables in function 'prvInitialiseTaskLists'
                           5003 ;------------------------------------------------------------
                           5004 ;uxPriority                Allocated to registers r2 
                           5005 ;------------------------------------------------------------
                           5006 ;	../../FreeRTOS/Source/tasks.c:1677: static void prvInitialiseTaskLists( void )
                           5007 ;	-----------------------------------------
                           5008 ;	 function prvInitialiseTaskLists
                           5009 ;	-----------------------------------------
   18EB                    5010 _prvInitialiseTaskLists:
                           5011 ;	../../FreeRTOS/Source/tasks.c:1681: for( uxPriority = 0; uxPriority < configMAX_PRIORITIES; uxPriority++ )
                           5012 ;	genAssign
   18EB 7A 00              5013 	mov	r2,#0x00
   18ED                    5014 00101$:
                           5015 ;	genCmpLt
                           5016 ;	genCmp
   18ED BA 04 00           5017 	cjne	r2,#0x04,00110$
   18F0                    5018 00110$:
                           5019 ;	genIfxJump
                           5020 ;	Peephole 108.a	removed ljmp by inverse jump logic
   18F0 50 1E              5021 	jnc	00104$
                           5022 ;	Peephole 300	removed redundant label 00111$
                           5023 ;	../../FreeRTOS/Source/tasks.c:1683: vListInitialise( ( xList * ) &( pxReadyTasksLists[ uxPriority ] ) );
                           5024 ;	genMult
                           5025 ;	genMultOneByte
   18F2 EA                 5026 	mov	a,r2
   18F3 75 F0 0C           5027 	mov	b,#0x0C
   18F6 A4                 5028 	mul	ab
                           5029 ;	genPlus
   18F7 24 06              5030 	add	a,#_pxReadyTasksLists
   18F9 FB                 5031 	mov	r3,a
                           5032 ;	Peephole 240	use clr instead of addc a,#0
   18FA E4                 5033 	clr	a
   18FB 34 E0              5034 	addc	a,#(_pxReadyTasksLists >> 8)
   18FD FC                 5035 	mov	r4,a
                           5036 ;	genCast
   18FE 7D 00              5037 	mov	r5,#0x0
                           5038 ;	genCall
   1900 8B 82              5039 	mov	dpl,r3
   1902 8C 83              5040 	mov	dph,r4
   1904 8D F0              5041 	mov	b,r5
   1906 C0 02              5042 	push	ar2
   1908 12 2A A3           5043 	lcall	_vListInitialise
   190B D0 02              5044 	pop	ar2
                           5045 ;	../../FreeRTOS/Source/tasks.c:1681: for( uxPriority = 0; uxPriority < configMAX_PRIORITIES; uxPriority++ )
                           5046 ;	genPlus
                           5047 ;     genPlusIncr
   190D 0A                 5048 	inc	r2
                           5049 ;	Peephole 112.b	changed ljmp to sjmp
   190E 80 DD              5050 	sjmp	00101$
   1910                    5051 00104$:
                           5052 ;	../../FreeRTOS/Source/tasks.c:1686: vListInitialise( ( xList * ) &xDelayedTaskList1 );
                           5053 ;	genCall
                           5054 ;	Peephole 182.a	used 16 bit load of DPTR
   1910 90 E0 36           5055 	mov	dptr,#_xDelayedTaskList1
   1913 75 F0 00           5056 	mov	b,#0x00
   1916 12 2A A3           5057 	lcall	_vListInitialise
                           5058 ;	../../FreeRTOS/Source/tasks.c:1687: vListInitialise( ( xList * ) &xDelayedTaskList2 );
                           5059 ;	genCall
                           5060 ;	Peephole 182.a	used 16 bit load of DPTR
   1919 90 E0 42           5061 	mov	dptr,#_xDelayedTaskList2
   191C 75 F0 00           5062 	mov	b,#0x00
   191F 12 2A A3           5063 	lcall	_vListInitialise
                           5064 ;	../../FreeRTOS/Source/tasks.c:1688: vListInitialise( ( xList * ) &xPendingReadyList );
                           5065 ;	genCall
                           5066 ;	Peephole 182.a	used 16 bit load of DPTR
   1922 90 E0 54           5067 	mov	dptr,#_xPendingReadyList
   1925 75 F0 00           5068 	mov	b,#0x00
   1928 12 2A A3           5069 	lcall	_vListInitialise
                           5070 ;	../../FreeRTOS/Source/tasks.c:1692: vListInitialise( ( xList * ) &xTasksWaitingTermination );
                           5071 ;	genCall
                           5072 ;	Peephole 182.a	used 16 bit load of DPTR
   192B 90 E0 60           5073 	mov	dptr,#_xTasksWaitingTermination
   192E 75 F0 00           5074 	mov	b,#0x00
   1931 12 2A A3           5075 	lcall	_vListInitialise
                           5076 ;	../../FreeRTOS/Source/tasks.c:1704: pxDelayedTaskList = &xDelayedTaskList1;
                           5077 ;	genCast
   1934 90 E0 4E           5078 	mov	dptr,#_pxDelayedTaskList
   1937 74 36              5079 	mov	a,#_xDelayedTaskList1
   1939 F0                 5080 	movx	@dptr,a
   193A A3                 5081 	inc	dptr
   193B 74 E0              5082 	mov	a,#(_xDelayedTaskList1 >> 8)
   193D F0                 5083 	movx	@dptr,a
   193E A3                 5084 	inc	dptr
   193F 74 00              5085 	mov	a,#0x0
   1941 F0                 5086 	movx	@dptr,a
                           5087 ;	../../FreeRTOS/Source/tasks.c:1705: pxOverflowDelayedTaskList = &xDelayedTaskList2;
                           5088 ;	genCast
   1942 90 E0 51           5089 	mov	dptr,#_pxOverflowDelayedTaskList
   1945 74 42              5090 	mov	a,#_xDelayedTaskList2
   1947 F0                 5091 	movx	@dptr,a
   1948 A3                 5092 	inc	dptr
   1949 74 E0              5093 	mov	a,#(_xDelayedTaskList2 >> 8)
   194B F0                 5094 	movx	@dptr,a
   194C A3                 5095 	inc	dptr
   194D 74 00              5096 	mov	a,#0x0
   194F F0                 5097 	movx	@dptr,a
                           5098 ;	Peephole 300	removed redundant label 00105$
   1950 22                 5099 	ret
                           5100 ;------------------------------------------------------------
                           5101 ;Allocation info for local variables in function 'prvCheckTasksWaitingTermination'
                           5102 ;------------------------------------------------------------
                           5103 ;xListIsEmpty              Allocated to registers r2 
                           5104 ;pxTCB                     Allocated to registers r2 r3 r4 
                           5105 ;------------------------------------------------------------
                           5106 ;	../../FreeRTOS/Source/tasks.c:1709: static void prvCheckTasksWaitingTermination( void )
                           5107 ;	-----------------------------------------
                           5108 ;	 function prvCheckTasksWaitingTermination
                           5109 ;	-----------------------------------------
   1951                    5110 _prvCheckTasksWaitingTermination:
                           5111 ;	../../FreeRTOS/Source/tasks.c:1717: if( uxTasksDeleted > ( unsigned portBASE_TYPE ) 0 )
                           5112 ;	genAssign
   1951 90 F0 78           5113 	mov	dptr,#_uxTasksDeleted
   1954 E0                 5114 	movx	a,@dptr
                           5115 ;	genIfx
   1955 FA                 5116 	mov	r2,a
                           5117 ;	Peephole 105	removed redundant mov
                           5118 ;	genIfxJump
   1956 70 01              5119 	jnz	00112$
                           5120 ;	Peephole 251.a	replaced ljmp to ret with ret
   1958 22                 5121 	ret
   1959                    5122 00112$:
                           5123 ;	../../FreeRTOS/Source/tasks.c:1719: vTaskSuspendAll();
                           5124 ;	genCall
   1959 12 0E 2C           5125 	lcall	_vTaskSuspendAll
                           5126 ;	../../FreeRTOS/Source/tasks.c:1720: xListIsEmpty = listLIST_IS_EMPTY( &xTasksWaitingTermination );				
                           5127 ;	genPointerGet
                           5128 ;	genFarPointerGet
   195C 90 E0 60           5129 	mov	dptr,#_xTasksWaitingTermination
   195F E0                 5130 	movx	a,@dptr
   1960 FA                 5131 	mov	r2,a
                           5132 ;	genCmpEq
                           5133 ;	gencjne
                           5134 ;	gencjneshort
                           5135 ;	Peephole 241.d	optimized compare
   1961 E4                 5136 	clr	a
   1962 BA 00 01           5137 	cjne	r2,#0x00,00113$
   1965 04                 5138 	inc	a
   1966                    5139 00113$:
                           5140 ;	Peephole 300	removed redundant label 00114$
   1966 FA                 5141 	mov	r2,a
                           5142 ;	../../FreeRTOS/Source/tasks.c:1721: xTaskResumeAll();
                           5143 ;	genCall
   1967 C0 02              5144 	push	ar2
   1969 12 0E 45           5145 	lcall	_xTaskResumeAll
   196C D0 02              5146 	pop	ar2
                           5147 ;	../../FreeRTOS/Source/tasks.c:1723: if( !xListIsEmpty )
                           5148 ;	genIfx
   196E EA                 5149 	mov	a,r2
                           5150 ;	genIfxJump
   196F 60 01              5151 	jz	00115$
                           5152 ;	Peephole 251.a	replaced ljmp to ret with ret
   1971 22                 5153 	ret
   1972                    5154 00115$:
                           5155 ;	../../FreeRTOS/Source/tasks.c:1727: portENTER_CRITICAL();
                           5156 ;	genInline
   1972 C0 E0 C0 A8        5157 	 push ACC push IE 
                           5158 ;	genAssign
   1976 C2 AF              5159 	clr	_EA
                           5160 ;	../../FreeRTOS/Source/tasks.c:1729: pxTCB = ( tskTCB * ) listGET_OWNER_OF_HEAD_ENTRY( ( ( xList * ) &xTasksWaitingTermination ) );
                           5161 ;	genPointerGet
                           5162 ;	genFarPointerGet
   1978 90 E0 60           5163 	mov	dptr,#_xTasksWaitingTermination
   197B E0                 5164 	movx	a,@dptr
   197C FA                 5165 	mov	r2,a
                           5166 ;	genCmpEq
                           5167 ;	gencjne
                           5168 ;	gencjneshort
                           5169 ;	Peephole 241.d	optimized compare
   197D E4                 5170 	clr	a
   197E BA 00 01           5171 	cjne	r2,#0x00,00116$
   1981 04                 5172 	inc	a
   1982                    5173 00116$:
                           5174 ;	Peephole 300	removed redundant label 00117$
                           5175 ;	genNot
   1982 FA                 5176 	mov	r2,a
                           5177 ;	Peephole 105	removed redundant mov
   1983 B4 01 00           5178 	cjne	a,#0x01,00118$
   1986                    5179 00118$:
   1986 E4                 5180 	clr	a
   1987 33                 5181 	rlc	a
                           5182 ;	genIfx
   1988 FA                 5183 	mov	r2,a
                           5184 ;	Peephole 105	removed redundant mov
                           5185 ;	genIfxJump
                           5186 ;	Peephole 108.c	removed ljmp by inverse jump logic
   1989 60 31              5187 	jz	00107$
                           5188 ;	Peephole 300	removed redundant label 00119$
                           5189 ;	genPointerGet
                           5190 ;	genGenPointerGet
   198B 90 E0 66           5191 	mov	dptr,#(_xTasksWaitingTermination + 0x0006)
   198E 75 F0 00           5192 	mov	b,#0x00
   1991 12 E4 9F           5193 	lcall	__gptrget
   1994 FA                 5194 	mov	r2,a
   1995 A3                 5195 	inc	dptr
   1996 12 E4 9F           5196 	lcall	__gptrget
   1999 FB                 5197 	mov	r3,a
   199A A3                 5198 	inc	dptr
   199B 12 E4 9F           5199 	lcall	__gptrget
   199E FC                 5200 	mov	r4,a
                           5201 ;	genPlus
                           5202 ;     genPlusIncr
   199F 74 08              5203 	mov	a,#0x08
                           5204 ;	Peephole 236.a	used r2 instead of ar2
   19A1 2A                 5205 	add	a,r2
   19A2 FA                 5206 	mov	r2,a
                           5207 ;	Peephole 181	changed mov to clr
   19A3 E4                 5208 	clr	a
                           5209 ;	Peephole 236.b	used r3 instead of ar3
   19A4 3B                 5210 	addc	a,r3
   19A5 FB                 5211 	mov	r3,a
                           5212 ;	genPointerGet
                           5213 ;	genGenPointerGet
   19A6 8A 82              5214 	mov	dpl,r2
   19A8 8B 83              5215 	mov	dph,r3
   19AA 8C F0              5216 	mov	b,r4
   19AC 12 E4 9F           5217 	lcall	__gptrget
   19AF FA                 5218 	mov	r2,a
   19B0 A3                 5219 	inc	dptr
   19B1 12 E4 9F           5220 	lcall	__gptrget
   19B4 FB                 5221 	mov	r3,a
   19B5 A3                 5222 	inc	dptr
   19B6 12 E4 9F           5223 	lcall	__gptrget
   19B9 FC                 5224 	mov	r4,a
                           5225 ;	Peephole 112.b	changed ljmp to sjmp
   19BA 80 06              5226 	sjmp	00108$
   19BC                    5227 00107$:
                           5228 ;	genAssign
   19BC 7A 00              5229 	mov	r2,#0x00
   19BE 7B 00              5230 	mov	r3,#0x00
   19C0 7C 00              5231 	mov	r4,#0x00
   19C2                    5232 00108$:
                           5233 ;	genAssign
                           5234 ;	genAssign
                           5235 ;	../../FreeRTOS/Source/tasks.c:1730: vListRemove( &( pxTCB->xGenericListItem ) );
                           5236 ;	genPlus
                           5237 ;     genPlusIncr
   19C2 74 03              5238 	mov	a,#0x03
                           5239 ;	Peephole 236.a	used r2 instead of ar2
   19C4 2A                 5240 	add	a,r2
   19C5 FD                 5241 	mov	r5,a
                           5242 ;	Peephole 181	changed mov to clr
   19C6 E4                 5243 	clr	a
                           5244 ;	Peephole 236.b	used r3 instead of ar3
   19C7 3B                 5245 	addc	a,r3
   19C8 FE                 5246 	mov	r6,a
   19C9 8C 07              5247 	mov	ar7,r4
                           5248 ;	genCall
   19CB 8D 82              5249 	mov	dpl,r5
   19CD 8E 83              5250 	mov	dph,r6
   19CF 8F F0              5251 	mov	b,r7
   19D1 C0 02              5252 	push	ar2
   19D3 C0 03              5253 	push	ar3
   19D5 C0 04              5254 	push	ar4
   19D7 12 2F 88           5255 	lcall	_vListRemove
   19DA D0 04              5256 	pop	ar4
   19DC D0 03              5257 	pop	ar3
   19DE D0 02              5258 	pop	ar2
                           5259 ;	../../FreeRTOS/Source/tasks.c:1731: --uxCurrentNumberOfTasks;
                           5260 ;	genMinus
   19E0 90 F0 79           5261 	mov	dptr,#_uxCurrentNumberOfTasks
                           5262 ;	genMinusDec
   19E3 E0                 5263 	movx	a,@dptr
   19E4 14                 5264 	dec	a
                           5265 ;	genAssign
   19E5 90 F0 79           5266 	mov	dptr,#_uxCurrentNumberOfTasks
   19E8 F0                 5267 	movx	@dptr,a
                           5268 ;	../../FreeRTOS/Source/tasks.c:1732: --uxTasksDeleted;
                           5269 ;	genMinus
   19E9 90 F0 78           5270 	mov	dptr,#_uxTasksDeleted
                           5271 ;	genMinusDec
   19EC E0                 5272 	movx	a,@dptr
   19ED 14                 5273 	dec	a
                           5274 ;	genAssign
   19EE 90 F0 78           5275 	mov	dptr,#_uxTasksDeleted
   19F1 F0                 5276 	movx	@dptr,a
                           5277 ;	../../FreeRTOS/Source/tasks.c:1734: portEXIT_CRITICAL();
                           5278 ;	genInline
   19F2 D0 E0              5279 	 pop ACC 
                           5280 ;	genAnd
   19F4 53 E0 80           5281 	anl	_ACC,#0x80
                           5282 ;	genOr
   19F7 E5 E0              5283 	mov	a,_ACC
   19F9 42 A8              5284 	orl	_IE,a
                           5285 ;	genInline
   19FB D0 E0              5286 	 pop ACC 
                           5287 ;	../../FreeRTOS/Source/tasks.c:1736: prvDeleteTCB( pxTCB );
                           5288 ;	genCall
   19FD 8A 82              5289 	mov	dpl,r2
   19FF 8B 83              5290 	mov	dph,r3
   1A01 8C F0              5291 	mov	b,r4
                           5292 ;	Peephole 253.b	replaced lcall/ret with ljmp
   1A03 02 1A EC           5293 	ljmp	_prvDeleteTCB
                           5294 ;
                           5295 ;------------------------------------------------------------
                           5296 ;Allocation info for local variables in function 'prvAllocateTCBAndStack'
                           5297 ;------------------------------------------------------------
                           5298 ;usStackDepth              Allocated to stack - offset 1
                           5299 ;pxNewTCB                  Allocated to stack - offset 3
                           5300 ;------------------------------------------------------------
                           5301 ;	../../FreeRTOS/Source/tasks.c:1744: static tskTCB *prvAllocateTCBAndStack( unsigned portSHORT usStackDepth )
                           5302 ;	-----------------------------------------
                           5303 ;	 function prvAllocateTCBAndStack
                           5304 ;	-----------------------------------------
   1A06                    5305 _prvAllocateTCBAndStack:
   1A06 C0 10              5306 	push	_bp
   1A08 85 81 10           5307 	mov	_bp,sp
                           5308 ;     genReceive
   1A0B C0 82              5309 	push	dpl
   1A0D C0 83              5310 	push	dph
   1A0F 05 81              5311 	inc	sp
   1A11 05 81              5312 	inc	sp
   1A13 05 81              5313 	inc	sp
                           5314 ;	../../FreeRTOS/Source/tasks.c:1750: pxNewTCB = ( tskTCB * ) pvPortMalloc( sizeof( tskTCB ) );
                           5315 ;	genCall
                           5316 ;	Peephole 182.b	used 16 bit load of dptr
   1A15 90 00 2E           5317 	mov	dptr,#0x002E
   1A18 12 36 8C           5318 	lcall	_pvPortMalloc
   1A1B AC 82              5319 	mov	r4,dpl
   1A1D AD 83              5320 	mov	r5,dph
   1A1F AE F0              5321 	mov	r6,b
                           5322 ;	genAssign
   1A21 A8 10              5323 	mov	r0,_bp
   1A23 08                 5324 	inc	r0
   1A24 08                 5325 	inc	r0
   1A25 08                 5326 	inc	r0
   1A26 A6 04              5327 	mov	@r0,ar4
   1A28 08                 5328 	inc	r0
   1A29 A6 05              5329 	mov	@r0,ar5
   1A2B 08                 5330 	inc	r0
   1A2C A6 06              5331 	mov	@r0,ar6
                           5332 ;	../../FreeRTOS/Source/tasks.c:1752: if( pxNewTCB != NULL )
                           5333 ;	genCmpEq
   1A2E A8 10              5334 	mov	r0,_bp
   1A30 08                 5335 	inc	r0
   1A31 08                 5336 	inc	r0
   1A32 08                 5337 	inc	r0
                           5338 ;	gencjneshort
   1A33 B6 00 0B           5339 	cjne	@r0,#0x00,00110$
   1A36 08                 5340 	inc	r0
   1A37 B6 00 07           5341 	cjne	@r0,#0x00,00110$
   1A3A 08                 5342 	inc	r0
   1A3B B6 00 03           5343 	cjne	@r0,#0x00,00110$
   1A3E 02 1A D9           5344 	ljmp	00105$
   1A41                    5345 00110$:
                           5346 ;	../../FreeRTOS/Source/tasks.c:1757: pxNewTCB->pxStack = ( portSTACK_TYPE * ) pvPortMalloc( ( ( size_t )usStackDepth ) * sizeof( portSTACK_TYPE ) );
                           5347 ;	genPlus
   1A41 A8 10              5348 	mov	r0,_bp
   1A43 08                 5349 	inc	r0
   1A44 08                 5350 	inc	r0
   1A45 08                 5351 	inc	r0
                           5352 ;     genPlusIncr
   1A46 74 20              5353 	mov	a,#0x20
   1A48 26                 5354 	add	a,@r0
   1A49 FF                 5355 	mov	r7,a
                           5356 ;	Peephole 181	changed mov to clr
   1A4A E4                 5357 	clr	a
   1A4B 08                 5358 	inc	r0
   1A4C 36                 5359 	addc	a,@r0
   1A4D FA                 5360 	mov	r2,a
   1A4E 08                 5361 	inc	r0
   1A4F 86 03              5362 	mov	ar3,@r0
                           5363 ;	genCall
   1A51 A8 10              5364 	mov	r0,_bp
   1A53 08                 5365 	inc	r0
   1A54 86 82              5366 	mov	dpl,@r0
   1A56 08                 5367 	inc	r0
   1A57 86 83              5368 	mov	dph,@r0
   1A59 C0 02              5369 	push	ar2
   1A5B C0 03              5370 	push	ar3
   1A5D C0 07              5371 	push	ar7
   1A5F 12 36 8C           5372 	lcall	_pvPortMalloc
   1A62 AC 82              5373 	mov	r4,dpl
   1A64 AD 83              5374 	mov	r5,dph
   1A66 AE F0              5375 	mov	r6,b
   1A68 D0 07              5376 	pop	ar7
   1A6A D0 03              5377 	pop	ar3
   1A6C D0 02              5378 	pop	ar2
                           5379 ;	genPointerSet
                           5380 ;	genGenPointerSet
   1A6E 8F 82              5381 	mov	dpl,r7
   1A70 8A 83              5382 	mov	dph,r2
   1A72 8B F0              5383 	mov	b,r3
   1A74 EC                 5384 	mov	a,r4
   1A75 12 DF B7           5385 	lcall	__gptrput
   1A78 A3                 5386 	inc	dptr
   1A79 ED                 5387 	mov	a,r5
   1A7A 12 DF B7           5388 	lcall	__gptrput
   1A7D A3                 5389 	inc	dptr
   1A7E EE                 5390 	mov	a,r6
   1A7F 12 DF B7           5391 	lcall	__gptrput
                           5392 ;	../../FreeRTOS/Source/tasks.c:1759: if( pxNewTCB->pxStack == NULL )
                           5393 ;	genCmpEq
                           5394 ;	gencjneshort
                           5395 ;	Peephole 112.b	changed ljmp to sjmp
                           5396 ;	Peephole 196	optimized misc jump sequence
   1A82 BC 00 23           5397 	cjne	r4,#0x00,00102$
   1A85 BD 00 20           5398 	cjne	r5,#0x00,00102$
   1A88 BE 00 1D           5399 	cjne	r6,#0x00,00102$
                           5400 ;	Peephole 200.b	removed redundant sjmp
                           5401 ;	Peephole 300	removed redundant label 00111$
                           5402 ;	Peephole 300	removed redundant label 00112$
                           5403 ;	../../FreeRTOS/Source/tasks.c:1762: vPortFree( pxNewTCB );			
                           5404 ;	genCall
   1A8B A8 10              5405 	mov	r0,_bp
   1A8D 08                 5406 	inc	r0
   1A8E 08                 5407 	inc	r0
   1A8F 08                 5408 	inc	r0
   1A90 86 82              5409 	mov	dpl,@r0
   1A92 08                 5410 	inc	r0
   1A93 86 83              5411 	mov	dph,@r0
   1A95 08                 5412 	inc	r0
   1A96 86 F0              5413 	mov	b,@r0
   1A98 12 37 35           5414 	lcall	_vPortFree
                           5415 ;	../../FreeRTOS/Source/tasks.c:1763: pxNewTCB = NULL;			
                           5416 ;	genAssign
   1A9B A8 10              5417 	mov	r0,_bp
   1A9D 08                 5418 	inc	r0
   1A9E 08                 5419 	inc	r0
   1A9F 08                 5420 	inc	r0
   1AA0 E4                 5421 	clr	a
   1AA1 F6                 5422 	mov	@r0,a
   1AA2 08                 5423 	inc	r0
   1AA3 F6                 5424 	mov	@r0,a
   1AA4 08                 5425 	inc	r0
   1AA5 F6                 5426 	mov	@r0,a
                           5427 ;	Peephole 112.b	changed ljmp to sjmp
   1AA6 80 31              5428 	sjmp	00105$
   1AA8                    5429 00102$:
                           5430 ;	../../FreeRTOS/Source/tasks.c:1768: memset( pxNewTCB->pxStack, tskSTACK_FILL_BYTE, usStackDepth * sizeof( portSTACK_TYPE ) );
                           5431 ;	genPointerGet
                           5432 ;	genGenPointerGet
   1AA8 8F 82              5433 	mov	dpl,r7
   1AAA 8A 83              5434 	mov	dph,r2
   1AAC 8B F0              5435 	mov	b,r3
   1AAE 12 E4 9F           5436 	lcall	__gptrget
   1AB1 FF                 5437 	mov	r7,a
   1AB2 A3                 5438 	inc	dptr
   1AB3 12 E4 9F           5439 	lcall	__gptrget
   1AB6 FA                 5440 	mov	r2,a
   1AB7 A3                 5441 	inc	dptr
   1AB8 12 E4 9F           5442 	lcall	__gptrget
   1ABB FB                 5443 	mov	r3,a
                           5444 ;	genIpush
   1ABC A8 10              5445 	mov	r0,_bp
   1ABE 08                 5446 	inc	r0
   1ABF E6                 5447 	mov	a,@r0
   1AC0 C0 E0              5448 	push	acc
   1AC2 08                 5449 	inc	r0
   1AC3 E6                 5450 	mov	a,@r0
   1AC4 C0 E0              5451 	push	acc
                           5452 ;	genIpush
   1AC6 74 A5              5453 	mov	a,#0xA5
   1AC8 C0 E0              5454 	push	acc
                           5455 ;	genCall
   1ACA 8F 82              5456 	mov	dpl,r7
   1ACC 8A 83              5457 	mov	dph,r2
   1ACE 8B F0              5458 	mov	b,r3
   1AD0 12 E3 65           5459 	lcall	_memset
   1AD3 15 81              5460 	dec	sp
   1AD5 15 81              5461 	dec	sp
   1AD7 15 81              5462 	dec	sp
   1AD9                    5463 00105$:
                           5464 ;	../../FreeRTOS/Source/tasks.c:1772: return pxNewTCB;
                           5465 ;	genRet
   1AD9 A8 10              5466 	mov	r0,_bp
   1ADB 08                 5467 	inc	r0
   1ADC 08                 5468 	inc	r0
   1ADD 08                 5469 	inc	r0
   1ADE 86 82              5470 	mov	dpl,@r0
   1AE0 08                 5471 	inc	r0
   1AE1 86 83              5472 	mov	dph,@r0
   1AE3 08                 5473 	inc	r0
   1AE4 86 F0              5474 	mov	b,@r0
                           5475 ;	Peephole 300	removed redundant label 00106$
   1AE6 85 10 81           5476 	mov	sp,_bp
   1AE9 D0 10              5477 	pop	_bp
   1AEB 22                 5478 	ret
                           5479 ;------------------------------------------------------------
                           5480 ;Allocation info for local variables in function 'prvDeleteTCB'
                           5481 ;------------------------------------------------------------
                           5482 ;pxTCB                     Allocated to registers r2 r3 r4 
                           5483 ;------------------------------------------------------------
                           5484 ;	../../FreeRTOS/Source/tasks.c:1821: static void prvDeleteTCB( tskTCB *pxTCB )
                           5485 ;	-----------------------------------------
                           5486 ;	 function prvDeleteTCB
                           5487 ;	-----------------------------------------
   1AEC                    5488 _prvDeleteTCB:
                           5489 ;	genReceive
   1AEC AA 82              5490 	mov	r2,dpl
   1AEE AB 83              5491 	mov	r3,dph
   1AF0 AC F0              5492 	mov	r4,b
                           5493 ;	../../FreeRTOS/Source/tasks.c:1825: vPortFree( pxTCB->pxStack );
                           5494 ;	genPlus
                           5495 ;     genPlusIncr
   1AF2 74 20              5496 	mov	a,#0x20
                           5497 ;	Peephole 236.a	used r2 instead of ar2
   1AF4 2A                 5498 	add	a,r2
   1AF5 FD                 5499 	mov	r5,a
                           5500 ;	Peephole 181	changed mov to clr
   1AF6 E4                 5501 	clr	a
                           5502 ;	Peephole 236.b	used r3 instead of ar3
   1AF7 3B                 5503 	addc	a,r3
   1AF8 FE                 5504 	mov	r6,a
   1AF9 8C 07              5505 	mov	ar7,r4
                           5506 ;	genPointerGet
                           5507 ;	genGenPointerGet
   1AFB 8D 82              5508 	mov	dpl,r5
   1AFD 8E 83              5509 	mov	dph,r6
   1AFF 8F F0              5510 	mov	b,r7
   1B01 12 E4 9F           5511 	lcall	__gptrget
   1B04 FD                 5512 	mov	r5,a
   1B05 A3                 5513 	inc	dptr
   1B06 12 E4 9F           5514 	lcall	__gptrget
   1B09 FE                 5515 	mov	r6,a
   1B0A A3                 5516 	inc	dptr
   1B0B 12 E4 9F           5517 	lcall	__gptrget
   1B0E FF                 5518 	mov	r7,a
                           5519 ;	genCall
   1B0F 8D 82              5520 	mov	dpl,r5
   1B11 8E 83              5521 	mov	dph,r6
   1B13 8F F0              5522 	mov	b,r7
   1B15 C0 02              5523 	push	ar2
   1B17 C0 03              5524 	push	ar3
   1B19 C0 04              5525 	push	ar4
   1B1B 12 37 35           5526 	lcall	_vPortFree
   1B1E D0 04              5527 	pop	ar4
   1B20 D0 03              5528 	pop	ar3
   1B22 D0 02              5529 	pop	ar2
                           5530 ;	../../FreeRTOS/Source/tasks.c:1826: vPortFree( pxTCB );
                           5531 ;	genCall
   1B24 8A 82              5532 	mov	dpl,r2
   1B26 8B 83              5533 	mov	dph,r3
   1B28 8C F0              5534 	mov	b,r4
                           5535 ;	Peephole 253.b	replaced lcall/ret with ljmp
   1B2A 02 37 35           5536 	ljmp	_vPortFree
                           5537 ;
                           5538 	.area CSEG    (CODE)
                           5539 	.area CONST   (CODE)
   E77D                    5540 __str_0:
   E77D 49 44 4C 45        5541 	.ascii "IDLE"
   E781 00                 5542 	.db 0x00
                           5543 	.area XINIT   (CODE)
   E872                    5544 __xinit__pxCurrentTCB:
                           5545 ; generic printIvalPtr
   E872 00 00 00           5546 	.byte #0x00,#0x00,#0x00
   E875                    5547 __xinit__uxTasksDeleted:
   E875 00                 5548 	.db #0x00
   E876                    5549 __xinit__uxCurrentNumberOfTasks:
   E876 00                 5550 	.db #0x00
   E877                    5551 __xinit__xTickCount:
   E877 00 00              5552 	.byte #0x00,#0x00
   E879                    5553 __xinit__uxTopUsedPriority:
   E879 00                 5554 	.db #0x00
   E87A                    5555 __xinit__uxTopReadyPriority:
   E87A 00                 5556 	.db #0x00
   E87B                    5557 __xinit__xSchedulerRunning:
   E87B 00                 5558 	.db #0x00
   E87C                    5559 __xinit__uxSchedulerSuspended:
   E87C 00                 5560 	.db #0x00
   E87D                    5561 __xinit__uxMissedTicks:
   E87D 00                 5562 	.db #0x00
   E87E                    5563 __xinit__xMissedYield:
   E87E 00                 5564 	.db #0x00
   E87F                    5565 __xinit__xNumOfOverflows:
   E87F 00                 5566 	.db #0x00
