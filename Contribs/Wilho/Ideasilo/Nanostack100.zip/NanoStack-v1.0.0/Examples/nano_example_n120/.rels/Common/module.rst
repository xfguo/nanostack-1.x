                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Nov 10 2006)
                              4 ; This file generated Fri Feb  1 13:33:38 2008
                              5 ;--------------------------------------------------------
                              6 	.module module
                              7 	.optsdcc -mmcs51 --model-large
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _IRCON2_P2IF
                             13 	.globl _IRCON2_UTX0IF
                             14 	.globl _IRCON2_UTX1IF
                             15 	.globl _IRCON2_P1IF
                             16 	.globl _IRCON2_WDTIF
                             17 	.globl _CY
                             18 	.globl _AC
                             19 	.globl _F0
                             20 	.globl _RS1
                             21 	.globl _RS0
                             22 	.globl _OV
                             23 	.globl _F1
                             24 	.globl _P
                             25 	.globl _IRCON_DMAIF
                             26 	.globl _IRCON_T1IF
                             27 	.globl _IRCON_T2IF
                             28 	.globl _IRCON_T3IF
                             29 	.globl _IRCON_T4IF
                             30 	.globl _IRCON_P0IF
                             31 	.globl _IRCON_STIF
                             32 	.globl _IEN1_DMAIE
                             33 	.globl _IEN1_T1IE
                             34 	.globl _IEN1_T2IE
                             35 	.globl _IEN1_T3IE
                             36 	.globl _IEN1_T4IE
                             37 	.globl _IEN1_P0IE
                             38 	.globl _IEN0_RFERRIE
                             39 	.globl _IEN0_ADCIE
                             40 	.globl _IEN0_URX0IE
                             41 	.globl _IEN0_URX1IE
                             42 	.globl _IEN0_ENCIE
                             43 	.globl _IEN0_STIE
                             44 	.globl _IEN0_EA
                             45 	.globl _EA
                             46 	.globl _P2_4
                             47 	.globl _P2_3
                             48 	.globl _P2_2
                             49 	.globl _P2_1
                             50 	.globl _P2_0
                             51 	.globl _S0CON_ENCIF_0
                             52 	.globl _S0CON_ENCIF_1
                             53 	.globl _P1_7
                             54 	.globl _P1_6
                             55 	.globl _P1_5
                             56 	.globl _P1_4
                             57 	.globl _P1_3
                             58 	.globl _P1_2
                             59 	.globl _P1_1
                             60 	.globl _P1_0
                             61 	.globl _TCON_IT0
                             62 	.globl _TCON_RFERRIF
                             63 	.globl _TCON_IT1
                             64 	.globl _TCON_URX0IF
                             65 	.globl _TCON_ADCIF
                             66 	.globl _TCON_URX1IF
                             67 	.globl _P0_0
                             68 	.globl _P0_1
                             69 	.globl _P0_2
                             70 	.globl _P0_3
                             71 	.globl _P0_4
                             72 	.globl _P0_5
                             73 	.globl _P0_6
                             74 	.globl _P0_7
                             75 	.globl _P2DIR
                             76 	.globl _P1DIR
                             77 	.globl _P0DIR
                             78 	.globl _U1GCR
                             79 	.globl _U1UCR
                             80 	.globl _U1BAUD
                             81 	.globl _U1BUF
                             82 	.globl _U1CSR
                             83 	.globl _P2INP
                             84 	.globl _P1INP
                             85 	.globl _P2SEL
                             86 	.globl _P1SEL
                             87 	.globl _P0SEL
                             88 	.globl _ADCCFG
                             89 	.globl _PERCFG
                             90 	.globl _B
                             91 	.globl _T4CC1
                             92 	.globl _T4CCTL1
                             93 	.globl _T4CC0
                             94 	.globl _T4CCTL0
                             95 	.globl _T4CTL
                             96 	.globl _T4CNT
                             97 	.globl _RFIF
                             98 	.globl _IRCON2
                             99 	.globl _T1CCTL2
                            100 	.globl _T1CCTL1
                            101 	.globl _T1CCTL0
                            102 	.globl _T1CTL
                            103 	.globl _T1CNTH
                            104 	.globl _T1CNTL
                            105 	.globl _RFST
                            106 	.globl _ACC
                            107 	.globl _T1CC2H
                            108 	.globl _T1CC2L
                            109 	.globl _T1CC1H
                            110 	.globl _T1CC1L
                            111 	.globl _T1CC0H
                            112 	.globl _T1CC0L
                            113 	.globl _RFD
                            114 	.globl _TIMIF
                            115 	.globl _DMAREQ
                            116 	.globl _DMAARM
                            117 	.globl _DMA0CFGH
                            118 	.globl _DMA0CFGL
                            119 	.globl _DMA1CFGH
                            120 	.globl _DMA1CFGL
                            121 	.globl _DMAIRQ
                            122 	.globl _PSW
                            123 	.globl _T3CC1
                            124 	.globl _T3CCTL1
                            125 	.globl _T3CC0
                            126 	.globl _T3CCTL0
                            127 	.globl _T3CTL
                            128 	.globl _T3CNT
                            129 	.globl _WDCTL
                            130 	.globl _T2CON
                            131 	.globl _MEMCTR
                            132 	.globl _CLKCON
                            133 	.globl _U0GCR
                            134 	.globl _U0UCR
                            135 	.globl _T2CNF
                            136 	.globl _U0BAUD
                            137 	.globl _U0BUF
                            138 	.globl _IRCON
                            139 	.globl _SLEEP
                            140 	.globl _RNDH
                            141 	.globl _RNDL
                            142 	.globl _ADCH
                            143 	.globl _ADCL
                            144 	.globl _IP1
                            145 	.globl _IEN1
                            146 	.globl _RCCTL
                            147 	.globl _ADCCON3
                            148 	.globl _ADCCON2
                            149 	.globl _ADCCON1
                            150 	.globl _ENCCS
                            151 	.globl _ENCDO
                            152 	.globl _ENCDI
                            153 	.globl _FWDATA
                            154 	.globl _FCTL
                            155 	.globl _FADDRH
                            156 	.globl _FADDRL
                            157 	.globl _FWT
                            158 	.globl _IP0
                            159 	.globl _IEN0
                            160 	.globl _IE
                            161 	.globl _T2THD
                            162 	.globl _T2TLD
                            163 	.globl _T2CAPHPH
                            164 	.globl _T2CAPLPL
                            165 	.globl _T2OF2
                            166 	.globl _T2OF1
                            167 	.globl _T2OF0
                            168 	.globl _P2
                            169 	.globl _T2PEROF2
                            170 	.globl _T2PEROF1
                            171 	.globl _T2PEROF0
                            172 	.globl _S1CON
                            173 	.globl _IEN2
                            174 	.globl _HSRC
                            175 	.globl _S0CON
                            176 	.globl _ST2
                            177 	.globl _ST1
                            178 	.globl _ST0
                            179 	.globl _T2CMP
                            180 	.globl __XPAGE
                            181 	.globl _DPS
                            182 	.globl _RFIM
                            183 	.globl _P1
                            184 	.globl _P0INP
                            185 	.globl _P1IEN
                            186 	.globl _PICTL
                            187 	.globl _P2IFG
                            188 	.globl _P1IFG
                            189 	.globl _P0IFG
                            190 	.globl _TCON
                            191 	.globl _PCON
                            192 	.globl _U0CSR
                            193 	.globl _DPH1
                            194 	.globl _DPL1
                            195 	.globl _DPH0
                            196 	.globl _DPL0
                            197 	.globl _SP
                            198 	.globl _P0
                            199 	.globl _modules
                            200 	.globl _gateway_features
                            201 	.globl _RFD_SHADOW
                            202 	.globl _RFSTATUS
                            203 	.globl _CHIPID
                            204 	.globl _CHVER
                            205 	.globl _FSMTC1
                            206 	.globl _RXFIFOCNT
                            207 	.globl _IOCFG3
                            208 	.globl _IOCFG2
                            209 	.globl _IOCFG1
                            210 	.globl _IOCFG0
                            211 	.globl _SHORTADDRL
                            212 	.globl _SHORTADDRH
                            213 	.globl _PANIDL
                            214 	.globl _PANIDH
                            215 	.globl _IEEE_ADDR7
                            216 	.globl _IEEE_ADDR6
                            217 	.globl _IEEE_ADDR5
                            218 	.globl _IEEE_ADDR4
                            219 	.globl _IEEE_ADDR3
                            220 	.globl _IEEE_ADDR2
                            221 	.globl _IEEE_ADDR1
                            222 	.globl _IEEE_ADDR0
                            223 	.globl _DACTSTL
                            224 	.globl _DACTSTH
                            225 	.globl _ADCTSTL
                            226 	.globl _ADCTSTH
                            227 	.globl _FSMSTATE
                            228 	.globl _AGCCTRLL
                            229 	.globl _AGCCTRLH
                            230 	.globl _MANORL
                            231 	.globl _MANORH
                            232 	.globl _MANANDL
                            233 	.globl _MANANDH
                            234 	.globl _FSMTCL
                            235 	.globl _FSMTCH
                            236 	.globl _RFPWR
                            237 	.globl _CSPT
                            238 	.globl _CSPCTRL
                            239 	.globl _CSPZ
                            240 	.globl _CSPY
                            241 	.globl _CSPX
                            242 	.globl _FSCTRLL
                            243 	.globl _FSCTRLH
                            244 	.globl _RXCTRL1L
                            245 	.globl _RXCTRL1H
                            246 	.globl _RXCTRL0L
                            247 	.globl _RXCTRL0H
                            248 	.globl _TXCTRLL
                            249 	.globl _TXCTRLH
                            250 	.globl _SYNCWORDL
                            251 	.globl _SYNCWORDH
                            252 	.globl _RSSIL
                            253 	.globl _RSSIH
                            254 	.globl _MDMCTRL1L
                            255 	.globl _MDMCTRL1H
                            256 	.globl _MDMCTRL0L
                            257 	.globl _MDMCTRL0H
                            258 	.globl _module_init
                            259 	.globl _module_get
                            260 	.globl _module_call
                            261 	.globl _module_setup
                            262 ;--------------------------------------------------------
                            263 ; special function registers
                            264 ;--------------------------------------------------------
                            265 	.area RSEG    (DATA)
                    0080    266 _P0	=	0x0080
                    0081    267 _SP	=	0x0081
                    0082    268 _DPL0	=	0x0082
                    0083    269 _DPH0	=	0x0083
                    0084    270 _DPL1	=	0x0084
                    0085    271 _DPH1	=	0x0085
                    0086    272 _U0CSR	=	0x0086
                    0087    273 _PCON	=	0x0087
                    0088    274 _TCON	=	0x0088
                    0089    275 _P0IFG	=	0x0089
                    008A    276 _P1IFG	=	0x008a
                    008B    277 _P2IFG	=	0x008b
                    008C    278 _PICTL	=	0x008c
                    008D    279 _P1IEN	=	0x008d
                    008F    280 _P0INP	=	0x008f
                    0090    281 _P1	=	0x0090
                    0091    282 _RFIM	=	0x0091
                    0092    283 _DPS	=	0x0092
                    0093    284 __XPAGE	=	0x0093
                    0094    285 _T2CMP	=	0x0094
                    0095    286 _ST0	=	0x0095
                    0096    287 _ST1	=	0x0096
                    0097    288 _ST2	=	0x0097
                    0098    289 _S0CON	=	0x0098
                    0099    290 _HSRC	=	0x0099
                    009A    291 _IEN2	=	0x009a
                    009B    292 _S1CON	=	0x009b
                    009C    293 _T2PEROF0	=	0x009c
                    009D    294 _T2PEROF1	=	0x009d
                    009E    295 _T2PEROF2	=	0x009e
                    00A0    296 _P2	=	0x00a0
                    00A1    297 _T2OF0	=	0x00a1
                    00A2    298 _T2OF1	=	0x00a2
                    00A3    299 _T2OF2	=	0x00a3
                    00A4    300 _T2CAPLPL	=	0x00a4
                    00A5    301 _T2CAPHPH	=	0x00a5
                    00A6    302 _T2TLD	=	0x00a6
                    00A7    303 _T2THD	=	0x00a7
                    00A8    304 _IE	=	0x00a8
                    00A8    305 _IEN0	=	0x00a8
                    00A9    306 _IP0	=	0x00a9
                    00AB    307 _FWT	=	0x00ab
                    00AC    308 _FADDRL	=	0x00ac
                    00AD    309 _FADDRH	=	0x00ad
                    00AE    310 _FCTL	=	0x00ae
                    00AF    311 _FWDATA	=	0x00af
                    00B1    312 _ENCDI	=	0x00b1
                    00B2    313 _ENCDO	=	0x00b2
                    00B3    314 _ENCCS	=	0x00b3
                    00B4    315 _ADCCON1	=	0x00b4
                    00B5    316 _ADCCON2	=	0x00b5
                    00B6    317 _ADCCON3	=	0x00b6
                    00B7    318 _RCCTL	=	0x00b7
                    00B8    319 _IEN1	=	0x00b8
                    00B9    320 _IP1	=	0x00b9
                    00BA    321 _ADCL	=	0x00ba
                    00BB    322 _ADCH	=	0x00bb
                    00BC    323 _RNDL	=	0x00bc
                    00BD    324 _RNDH	=	0x00bd
                    00BE    325 _SLEEP	=	0x00be
                    00C0    326 _IRCON	=	0x00c0
                    00C1    327 _U0BUF	=	0x00c1
                    00C2    328 _U0BAUD	=	0x00c2
                    00C3    329 _T2CNF	=	0x00c3
                    00C4    330 _U0UCR	=	0x00c4
                    00C5    331 _U0GCR	=	0x00c5
                    00C6    332 _CLKCON	=	0x00c6
                    00C7    333 _MEMCTR	=	0x00c7
                    00C8    334 _T2CON	=	0x00c8
                    00C9    335 _WDCTL	=	0x00c9
                    00CA    336 _T3CNT	=	0x00ca
                    00CB    337 _T3CTL	=	0x00cb
                    00CC    338 _T3CCTL0	=	0x00cc
                    00CD    339 _T3CC0	=	0x00cd
                    00CE    340 _T3CCTL1	=	0x00ce
                    00CF    341 _T3CC1	=	0x00cf
                    00D0    342 _PSW	=	0x00d0
                    00D1    343 _DMAIRQ	=	0x00d1
                    00D2    344 _DMA1CFGL	=	0x00d2
                    00D3    345 _DMA1CFGH	=	0x00d3
                    00D4    346 _DMA0CFGL	=	0x00d4
                    00D5    347 _DMA0CFGH	=	0x00d5
                    00D6    348 _DMAARM	=	0x00d6
                    00D7    349 _DMAREQ	=	0x00d7
                    00D8    350 _TIMIF	=	0x00d8
                    00D9    351 _RFD	=	0x00d9
                    00DA    352 _T1CC0L	=	0x00da
                    00DB    353 _T1CC0H	=	0x00db
                    00DC    354 _T1CC1L	=	0x00dc
                    00DD    355 _T1CC1H	=	0x00dd
                    00DE    356 _T1CC2L	=	0x00de
                    00DF    357 _T1CC2H	=	0x00df
                    00E0    358 _ACC	=	0x00e0
                    00E1    359 _RFST	=	0x00e1
                    00E2    360 _T1CNTL	=	0x00e2
                    00E3    361 _T1CNTH	=	0x00e3
                    00E4    362 _T1CTL	=	0x00e4
                    00E5    363 _T1CCTL0	=	0x00e5
                    00E6    364 _T1CCTL1	=	0x00e6
                    00E7    365 _T1CCTL2	=	0x00e7
                    00E8    366 _IRCON2	=	0x00e8
                    00E9    367 _RFIF	=	0x00e9
                    00EA    368 _T4CNT	=	0x00ea
                    00EB    369 _T4CTL	=	0x00eb
                    00EC    370 _T4CCTL0	=	0x00ec
                    00ED    371 _T4CC0	=	0x00ed
                    00EE    372 _T4CCTL1	=	0x00ee
                    00EF    373 _T4CC1	=	0x00ef
                    00F0    374 _B	=	0x00f0
                    00F1    375 _PERCFG	=	0x00f1
                    00F2    376 _ADCCFG	=	0x00f2
                    00F3    377 _P0SEL	=	0x00f3
                    00F4    378 _P1SEL	=	0x00f4
                    00F5    379 _P2SEL	=	0x00f5
                    00F6    380 _P1INP	=	0x00f6
                    00F7    381 _P2INP	=	0x00f7
                    00F8    382 _U1CSR	=	0x00f8
                    00F9    383 _U1BUF	=	0x00f9
                    00FA    384 _U1BAUD	=	0x00fa
                    00FB    385 _U1UCR	=	0x00fb
                    00FC    386 _U1GCR	=	0x00fc
                    00FD    387 _P0DIR	=	0x00fd
                    00FE    388 _P1DIR	=	0x00fe
                    00FF    389 _P2DIR	=	0x00ff
                            390 ;--------------------------------------------------------
                            391 ; special function bits
                            392 ;--------------------------------------------------------
                            393 	.area RSEG    (DATA)
                    0087    394 _P0_7	=	0x0087
                    0086    395 _P0_6	=	0x0086
                    0085    396 _P0_5	=	0x0085
                    0084    397 _P0_4	=	0x0084
                    0083    398 _P0_3	=	0x0083
                    0082    399 _P0_2	=	0x0082
                    0081    400 _P0_1	=	0x0081
                    0080    401 _P0_0	=	0x0080
                    008F    402 _TCON_URX1IF	=	0x008f
                    008D    403 _TCON_ADCIF	=	0x008d
                    008B    404 _TCON_URX0IF	=	0x008b
                    008A    405 _TCON_IT1	=	0x008a
                    0089    406 _TCON_RFERRIF	=	0x0089
                    0088    407 _TCON_IT0	=	0x0088
                    0090    408 _P1_0	=	0x0090
                    0091    409 _P1_1	=	0x0091
                    0092    410 _P1_2	=	0x0092
                    0093    411 _P1_3	=	0x0093
                    0094    412 _P1_4	=	0x0094
                    0095    413 _P1_5	=	0x0095
                    0096    414 _P1_6	=	0x0096
                    0097    415 _P1_7	=	0x0097
                    0099    416 _S0CON_ENCIF_1	=	0x0099
                    0098    417 _S0CON_ENCIF_0	=	0x0098
                    00A0    418 _P2_0	=	0x00a0
                    00A1    419 _P2_1	=	0x00a1
                    00A2    420 _P2_2	=	0x00a2
                    00A3    421 _P2_3	=	0x00a3
                    00A4    422 _P2_4	=	0x00a4
                    00AF    423 _EA	=	0x00af
                    00AF    424 _IEN0_EA	=	0x00af
                    00AD    425 _IEN0_STIE	=	0x00ad
                    00AC    426 _IEN0_ENCIE	=	0x00ac
                    00AB    427 _IEN0_URX1IE	=	0x00ab
                    00AA    428 _IEN0_URX0IE	=	0x00aa
                    00A9    429 _IEN0_ADCIE	=	0x00a9
                    00A8    430 _IEN0_RFERRIE	=	0x00a8
                    00BD    431 _IEN1_P0IE	=	0x00bd
                    00BC    432 _IEN1_T4IE	=	0x00bc
                    00BB    433 _IEN1_T3IE	=	0x00bb
                    00BA    434 _IEN1_T2IE	=	0x00ba
                    00B9    435 _IEN1_T1IE	=	0x00b9
                    00B8    436 _IEN1_DMAIE	=	0x00b8
                    00C7    437 _IRCON_STIF	=	0x00c7
                    00C5    438 _IRCON_P0IF	=	0x00c5
                    00C4    439 _IRCON_T4IF	=	0x00c4
                    00C3    440 _IRCON_T3IF	=	0x00c3
                    00C2    441 _IRCON_T2IF	=	0x00c2
                    00C1    442 _IRCON_T1IF	=	0x00c1
                    00C0    443 _IRCON_DMAIF	=	0x00c0
                    00D0    444 _P	=	0x00d0
                    00D1    445 _F1	=	0x00d1
                    00D2    446 _OV	=	0x00d2
                    00D3    447 _RS0	=	0x00d3
                    00D4    448 _RS1	=	0x00d4
                    00D5    449 _F0	=	0x00d5
                    00D6    450 _AC	=	0x00d6
                    00D7    451 _CY	=	0x00d7
                    00EC    452 _IRCON2_WDTIF	=	0x00ec
                    00EB    453 _IRCON2_P1IF	=	0x00eb
                    00EA    454 _IRCON2_UTX1IF	=	0x00ea
                    00E9    455 _IRCON2_UTX0IF	=	0x00e9
                    00E8    456 _IRCON2_P2IF	=	0x00e8
                            457 ;--------------------------------------------------------
                            458 ; overlayable register banks
                            459 ;--------------------------------------------------------
                            460 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     461 	.ds 8
                            462 ;--------------------------------------------------------
                            463 ; internal ram data
                            464 ;--------------------------------------------------------
                            465 	.area DSEG    (DATA)
                            466 ;--------------------------------------------------------
                            467 ; overlayable items in internal ram 
                            468 ;--------------------------------------------------------
                            469 	.area OSEG    (OVR,DATA)
                            470 ;--------------------------------------------------------
                            471 ; indirectly addressable internal ram data
                            472 ;--------------------------------------------------------
                            473 	.area ISEG    (DATA)
                            474 ;--------------------------------------------------------
                            475 ; bit data
                            476 ;--------------------------------------------------------
                            477 	.area BSEG    (BIT)
                            478 ;--------------------------------------------------------
                            479 ; paged external ram data
                            480 ;--------------------------------------------------------
                            481 	.area PSEG    (PAG,XDATA)
                            482 ;--------------------------------------------------------
                            483 ; external ram data
                            484 ;--------------------------------------------------------
                            485 	.area XSEG    (XDATA)
                    DF02    486 _MDMCTRL0H	=	0xdf02
                    DF03    487 _MDMCTRL0L	=	0xdf03
                    DF04    488 _MDMCTRL1H	=	0xdf04
                    DF05    489 _MDMCTRL1L	=	0xdf05
                    DF06    490 _RSSIH	=	0xdf06
                    DF07    491 _RSSIL	=	0xdf07
                    DF08    492 _SYNCWORDH	=	0xdf08
                    DF09    493 _SYNCWORDL	=	0xdf09
                    DF0A    494 _TXCTRLH	=	0xdf0a
                    DF0B    495 _TXCTRLL	=	0xdf0b
                    DF0C    496 _RXCTRL0H	=	0xdf0c
                    DF0D    497 _RXCTRL0L	=	0xdf0d
                    DF0E    498 _RXCTRL1H	=	0xdf0e
                    DF0F    499 _RXCTRL1L	=	0xdf0f
                    DF10    500 _FSCTRLH	=	0xdf10
                    DF11    501 _FSCTRLL	=	0xdf11
                    DF12    502 _CSPX	=	0xdf12
                    DF13    503 _CSPY	=	0xdf13
                    DF14    504 _CSPZ	=	0xdf14
                    DF15    505 _CSPCTRL	=	0xdf15
                    DF16    506 _CSPT	=	0xdf16
                    DF17    507 _RFPWR	=	0xdf17
                    DF20    508 _FSMTCH	=	0xdf20
                    DF21    509 _FSMTCL	=	0xdf21
                    DF22    510 _MANANDH	=	0xdf22
                    DF23    511 _MANANDL	=	0xdf23
                    DF24    512 _MANORH	=	0xdf24
                    DF25    513 _MANORL	=	0xdf25
                    DF26    514 _AGCCTRLH	=	0xdf26
                    DF27    515 _AGCCTRLL	=	0xdf27
                    DF39    516 _FSMSTATE	=	0xdf39
                    DF3A    517 _ADCTSTH	=	0xdf3a
                    DF3B    518 _ADCTSTL	=	0xdf3b
                    DF3C    519 _DACTSTH	=	0xdf3c
                    DF3D    520 _DACTSTL	=	0xdf3d
                    DF43    521 _IEEE_ADDR0	=	0xdf43
                    DF44    522 _IEEE_ADDR1	=	0xdf44
                    DF45    523 _IEEE_ADDR2	=	0xdf45
                    DF46    524 _IEEE_ADDR3	=	0xdf46
                    DF47    525 _IEEE_ADDR4	=	0xdf47
                    DF48    526 _IEEE_ADDR5	=	0xdf48
                    DF49    527 _IEEE_ADDR6	=	0xdf49
                    DF4A    528 _IEEE_ADDR7	=	0xdf4a
                    DF4B    529 _PANIDH	=	0xdf4b
                    DF4C    530 _PANIDL	=	0xdf4c
                    DF4D    531 _SHORTADDRH	=	0xdf4d
                    DF4E    532 _SHORTADDRL	=	0xdf4e
                    DF4F    533 _IOCFG0	=	0xdf4f
                    DF50    534 _IOCFG1	=	0xdf50
                    DF51    535 _IOCFG2	=	0xdf51
                    DF52    536 _IOCFG3	=	0xdf52
                    DF53    537 _RXFIFOCNT	=	0xdf53
                    DF54    538 _FSMTC1	=	0xdf54
                    DF60    539 _CHVER	=	0xdf60
                    DF61    540 _CHIPID	=	0xdf61
                    DF62    541 _RFSTATUS	=	0xdf62
                    DFD9    542 _RFD_SHADOW	=	0xdfd9
   EF57                     543 _gateway_features::
   EF57                     544 	.ds 1
                            545 ;--------------------------------------------------------
                            546 ; external initialized ram data
                            547 ;--------------------------------------------------------
                            548 	.area XISEG   (XDATA)
   F0A6                     549 _modules::
   F0A6                     550 	.ds 52
                            551 	.area HOME    (CODE)
                            552 	.area GSINIT0 (CODE)
                            553 	.area GSINIT1 (CODE)
                            554 	.area GSINIT2 (CODE)
                            555 	.area GSINIT3 (CODE)
                            556 	.area GSINIT4 (CODE)
                            557 	.area GSINIT5 (CODE)
                            558 	.area GSINIT  (CODE)
                            559 	.area GSFINAL (CODE)
                            560 	.area CSEG    (CODE)
                            561 ;--------------------------------------------------------
                            562 ; global & static initialisations
                            563 ;--------------------------------------------------------
                            564 	.area HOME    (CODE)
                            565 	.area GSINIT  (CODE)
                            566 	.area GSFINAL (CODE)
                            567 	.area GSINIT  (CODE)
                            568 ;--------------------------------------------------------
                            569 ; Home
                            570 ;--------------------------------------------------------
                            571 	.area HOME    (CODE)
                            572 	.area CSEG    (CODE)
                            573 ;--------------------------------------------------------
                            574 ; code
                            575 ;--------------------------------------------------------
                            576 	.area CSEG    (CODE)
                            577 ;------------------------------------------------------------
                            578 ;Allocation info for local variables in function 'module_init'
                            579 ;------------------------------------------------------------
                            580 ;i                         Allocated to registers r2 
                            581 ;------------------------------------------------------------
                            582 ;	../../Common/module.c:63: portCHAR module_init(void)
                            583 ;	-----------------------------------------
                            584 ;	 function module_init
                            585 ;	-----------------------------------------
   42E0                     586 _module_init:
                    0002    587 	ar2 = 0x02
                    0003    588 	ar3 = 0x03
                    0004    589 	ar4 = 0x04
                    0005    590 	ar5 = 0x05
                    0006    591 	ar6 = 0x06
                    0007    592 	ar7 = 0x07
                    0000    593 	ar0 = 0x00
                    0001    594 	ar1 = 0x01
                            595 ;	../../Common/module.c:70: while (modules[i].id != MODULE_NONE)
                            596 ;	genAssign
   42E0 7A 00               597 	mov	r2,#0x00
   42E2                     598 00101$:
                            599 ;	genMult
                            600 ;	genMultOneByte
   42E2 EA                  601 	mov	a,r2
   42E3 75 F0 0D            602 	mov	b,#0x0D
   42E6 A4                  603 	mul	ab
                            604 ;	genPlus
   42E7 FB                  605 	mov	r3,a
                            606 ;	Peephole 177.b	removed redundant mov
   42E8 24 A6               607 	add	a,#_modules
   42EA FC                  608 	mov	r4,a
                            609 ;	Peephole 181	changed mov to clr
   42EB E4                  610 	clr	a
   42EC 34 F0               611 	addc	a,#(_modules >> 8)
   42EE FD                  612 	mov	r5,a
                            613 ;	genPlus
                            614 ;     genPlusIncr
   42EF 74 08               615 	mov	a,#0x08
                            616 ;	Peephole 236.a	used r4 instead of ar4
   42F1 2C                  617 	add	a,r4
   42F2 F5 82               618 	mov	dpl,a
                            619 ;	Peephole 181	changed mov to clr
   42F4 E4                  620 	clr	a
                            621 ;	Peephole 236.b	used r5 instead of ar5
   42F5 3D                  622 	addc	a,r5
   42F6 F5 83               623 	mov	dph,a
                            624 ;	genPointerGet
                            625 ;	genFarPointerGet
   42F8 E0                  626 	movx	a,@dptr
                            627 ;	genCmpEq
                            628 ;	gencjneshort
                            629 ;	Peephole 112.b	changed ljmp to sjmp
   42F9 FC                  630 	mov	r4,a
                            631 ;	Peephole 115.b	jump optimization
   42FA 60 31               632 	jz	00103$
                            633 ;	Peephole 300	removed redundant label 00109$
                            634 ;	../../Common/module.c:72: modules[i].init(0);
                            635 ;	genPlus
                            636 ;	Peephole 236.g	used r3 instead of ar3
   42FC EB                  637 	mov	a,r3
   42FD 24 A6               638 	add	a,#_modules
   42FF F5 82               639 	mov	dpl,a
                            640 ;	Peephole 181	changed mov to clr
   4301 E4                  641 	clr	a
   4302 34 F0               642 	addc	a,#(_modules >> 8)
   4304 F5 83               643 	mov	dph,a
                            644 ;	genPointerGet
                            645 ;	genFarPointerGet
   4306 E0                  646 	movx	a,@dptr
   4307 FB                  647 	mov	r3,a
   4308 A3                  648 	inc	dptr
   4309 E0                  649 	movx	a,@dptr
   430A FC                  650 	mov	r4,a
                            651 ;	genPcall
   430B C0 02               652 	push	ar2
   430D C0 03               653 	push	ar3
   430F C0 04               654 	push	ar4
   4311 74 24               655 	mov	a,#00110$
   4313 C0 E0               656 	push	acc
   4315 74 43               657 	mov	a,#(00110$ >> 8)
   4317 C0 E0               658 	push	acc
   4319 C0 03               659 	push	ar3
   431B C0 04               660 	push	ar4
                            661 ;	Peephole 182.b	used 16 bit load of dptr
   431D 90 00 00            662 	mov	dptr,#0x0000
   4320 75 F0 00            663 	mov	b,#0x00
   4323 22                  664 	ret
   4324                     665 00110$:
   4324 D0 04               666 	pop	ar4
   4326 D0 03               667 	pop	ar3
   4328 D0 02               668 	pop	ar2
                            669 ;	../../Common/module.c:73: i++;
                            670 ;	genPlus
                            671 ;     genPlusIncr
   432A 0A                  672 	inc	r2
                            673 ;	Peephole 112.b	changed ljmp to sjmp
   432B 80 B5               674 	sjmp	00101$
   432D                     675 00103$:
                            676 ;	../../Common/module.c:78: return pdTRUE;
                            677 ;	genRet
   432D 75 82 01            678 	mov	dpl,#0x01
                            679 ;	Peephole 300	removed redundant label 00104$
   4330 22                  680 	ret
                            681 ;------------------------------------------------------------
                            682 ;Allocation info for local variables in function 'module_get'
                            683 ;------------------------------------------------------------
                            684 ;id                        Allocated to registers r2 
                            685 ;i                         Allocated to registers r3 
                            686 ;------------------------------------------------------------
                            687 ;	../../Common/module.c:88: module_t *module_get(module_id_t id)
                            688 ;	-----------------------------------------
                            689 ;	 function module_get
                            690 ;	-----------------------------------------
   4331                     691 _module_get:
                            692 ;	genReceive
   4331 AA 82               693 	mov	r2,dpl
                            694 ;	../../Common/module.c:92: while ((modules[i].id != MODULE_NONE) && (modules[i].id != id))
                            695 ;	genAssign
   4333 7B 00               696 	mov	r3,#0x00
   4335                     697 00102$:
                            698 ;	genMult
                            699 ;	genMultOneByte
   4335 EB                  700 	mov	a,r3
   4336 75 F0 0D            701 	mov	b,#0x0D
   4339 A4                  702 	mul	ab
                            703 ;	genPlus
   433A 24 A6               704 	add	a,#_modules
   433C FC                  705 	mov	r4,a
                            706 ;	Peephole 240	use clr instead of addc a,#0
   433D E4                  707 	clr	a
   433E 34 F0               708 	addc	a,#(_modules >> 8)
   4340 FD                  709 	mov	r5,a
                            710 ;	genPlus
                            711 ;     genPlusIncr
   4341 74 08               712 	mov	a,#0x08
                            713 ;	Peephole 236.a	used r4 instead of ar4
   4343 2C                  714 	add	a,r4
   4344 F5 82               715 	mov	dpl,a
                            716 ;	Peephole 181	changed mov to clr
   4346 E4                  717 	clr	a
                            718 ;	Peephole 236.b	used r5 instead of ar5
   4347 3D                  719 	addc	a,r5
   4348 F5 83               720 	mov	dph,a
                            721 ;	genPointerGet
                            722 ;	genFarPointerGet
   434A E0                  723 	movx	a,@dptr
                            724 ;	genCmpEq
                            725 ;	gencjneshort
                            726 ;	Peephole 112.b	changed ljmp to sjmp
   434B FC                  727 	mov	r4,a
                            728 ;	Peephole 115.b	jump optimization
   434C 60 09               729 	jz	00104$
                            730 ;	Peephole 300	removed redundant label 00114$
                            731 ;	genCmpEq
                            732 ;	gencjneshort
   434E EC                  733 	mov	a,r4
   434F B5 02 02            734 	cjne	a,ar2,00115$
                            735 ;	Peephole 112.b	changed ljmp to sjmp
   4352 80 03               736 	sjmp	00104$
   4354                     737 00115$:
                            738 ;	../../Common/module.c:94: i++;
                            739 ;	genPlus
                            740 ;     genPlusIncr
   4354 0B                  741 	inc	r3
                            742 ;	Peephole 112.b	changed ljmp to sjmp
   4355 80 DE               743 	sjmp	00102$
   4357                     744 00104$:
                            745 ;	../../Common/module.c:96: if (modules[i].id != MODULE_NONE)
                            746 ;	genMult
                            747 ;	genMultOneByte
   4357 EB                  748 	mov	a,r3
   4358 75 F0 0D            749 	mov	b,#0x0D
   435B A4                  750 	mul	ab
                            751 ;	genPlus
   435C 24 A6               752 	add	a,#_modules
   435E FA                  753 	mov	r2,a
                            754 ;	Peephole 240	use clr instead of addc a,#0
   435F E4                  755 	clr	a
   4360 34 F0               756 	addc	a,#(_modules >> 8)
   4362 FB                  757 	mov	r3,a
                            758 ;	genPlus
                            759 ;     genPlusIncr
   4363 74 08               760 	mov	a,#0x08
                            761 ;	Peephole 236.a	used r2 instead of ar2
   4365 2A                  762 	add	a,r2
   4366 F5 82               763 	mov	dpl,a
                            764 ;	Peephole 181	changed mov to clr
   4368 E4                  765 	clr	a
                            766 ;	Peephole 236.b	used r3 instead of ar3
   4369 3B                  767 	addc	a,r3
   436A F5 83               768 	mov	dph,a
                            769 ;	genPointerGet
                            770 ;	genFarPointerGet
   436C E0                  771 	movx	a,@dptr
                            772 ;	genCmpEq
                            773 ;	gencjneshort
                            774 ;	Peephole 112.b	changed ljmp to sjmp
   436D FC                  775 	mov	r4,a
                            776 ;	Peephole 115.b	jump optimization
   436E 60 09               777 	jz	00106$
                            778 ;	Peephole 300	removed redundant label 00116$
                            779 ;	../../Common/module.c:98: return &(modules[i]);
                            780 ;	genAssign
                            781 ;	genCast
   4370 7C 00               782 	mov	r4,#0x0
                            783 ;	genRet
   4372 8A 82               784 	mov	dpl,r2
   4374 8B 83               785 	mov	dph,r3
   4376 8C F0               786 	mov	b,r4
                            787 ;	Peephole 112.b	changed ljmp to sjmp
                            788 ;	Peephole 251.b	replaced sjmp to ret with ret
   4378 22                  789 	ret
   4379                     790 00106$:
                            791 ;	../../Common/module.c:100: return 0;
                            792 ;	genRet
                            793 ;	Peephole 182.b	used 16 bit load of dptr
   4379 90 00 00            794 	mov	dptr,#0x0000
   437C 75 F0 00            795 	mov	b,#0x00
                            796 ;	Peephole 300	removed redundant label 00107$
   437F 22                  797 	ret
                            798 ;------------------------------------------------------------
                            799 ;Allocation info for local variables in function 'module_call'
                            800 ;------------------------------------------------------------
                            801 ;buffer                    Allocated to stack - offset -5
                            802 ;id                        Allocated to registers r2 
                            803 ;mod                       Allocated to registers r2 r3 r4 
                            804 ;------------------------------------------------------------
                            805 ;	../../Common/module.c:112: portCHAR module_call(module_id_t id, buffer_t *buffer)
                            806 ;	-----------------------------------------
                            807 ;	 function module_call
                            808 ;	-----------------------------------------
   4380                     809 _module_call:
   4380 C0 10               810 	push	_bp
   4382 85 81 10            811 	mov	_bp,sp
                            812 ;	genReceive
                            813 ;	../../Common/module.c:114: module_t *mod = module_get(id);
                            814 ;	genCall
   4385 AA 82               815 	mov  r2,dpl
                            816 ;	Peephole 177.a	removed redundant mov
   4387 12 43 31            817 	lcall	_module_get
   438A AA 82               818 	mov	r2,dpl
   438C AB 83               819 	mov	r3,dph
   438E AC F0               820 	mov	r4,b
                            821 ;	genAssign
                            822 ;	../../Common/module.c:116: if (mod)
                            823 ;	genIfx
   4390 EA                  824 	mov	a,r2
   4391 4B                  825 	orl	a,r3
   4392 4C                  826 	orl	a,r4
                            827 ;	genIfxJump
                            828 ;	Peephole 108.c	removed ljmp by inverse jump logic
   4393 60 3A               829 	jz	00102$
                            830 ;	Peephole 300	removed redundant label 00106$
                            831 ;	../../Common/module.c:118: return mod->handle(buffer);
                            832 ;	genPlus
                            833 ;     genPlusIncr
   4395 74 02               834 	mov	a,#0x02
                            835 ;	Peephole 236.a	used r2 instead of ar2
   4397 2A                  836 	add	a,r2
   4398 FA                  837 	mov	r2,a
                            838 ;	Peephole 181	changed mov to clr
   4399 E4                  839 	clr	a
                            840 ;	Peephole 236.b	used r3 instead of ar3
   439A 3B                  841 	addc	a,r3
   439B FB                  842 	mov	r3,a
                            843 ;	genPointerGet
                            844 ;	genGenPointerGet
   439C 8A 82               845 	mov	dpl,r2
   439E 8B 83               846 	mov	dph,r3
   43A0 8C F0               847 	mov	b,r4
   43A2 12 E4 9F            848 	lcall	__gptrget
   43A5 FA                  849 	mov	r2,a
   43A6 A3                  850 	inc	dptr
   43A7 12 E4 9F            851 	lcall	__gptrget
   43AA FB                  852 	mov	r3,a
                            853 ;	genPcall
   43AB C0 03               854 	push	ar3
   43AD 74 C7               855 	mov	a,#00107$
   43AF C0 E0               856 	push	acc
   43B1 74 43               857 	mov	a,#(00107$ >> 8)
   43B3 C0 E0               858 	push	acc
   43B5 C0 02               859 	push	ar2
   43B7 C0 03               860 	push	ar3
   43B9 E5 10               861 	mov	a,_bp
   43BB 24 FB               862 	add	a,#0xfffffffb
   43BD F8                  863 	mov	r0,a
   43BE 86 82               864 	mov	dpl,@r0
   43C0 08                  865 	inc	r0
   43C1 86 83               866 	mov	dph,@r0
   43C3 08                  867 	inc	r0
   43C4 86 F0               868 	mov	b,@r0
   43C6 22                  869 	ret
   43C7                     870 00107$:
   43C7 AA 82               871 	mov	r2,dpl
   43C9 D0 03               872 	pop	ar3
                            873 ;	genRet
   43CB 8A 82               874 	mov	dpl,r2
                            875 ;	Peephole 112.b	changed ljmp to sjmp
   43CD 80 03               876 	sjmp	00103$
   43CF                     877 00102$:
                            878 ;	../../Common/module.c:121: return pdFALSE;
                            879 ;	genRet
   43CF 75 82 00            880 	mov	dpl,#0x00
   43D2                     881 00103$:
   43D2 D0 10               882 	pop	_bp
   43D4 22                  883 	ret
                            884 ;------------------------------------------------------------
                            885 ;Allocation info for local variables in function 'module_setup'
                            886 ;------------------------------------------------------------
                            887 ;i                         Allocated to registers r2 
                            888 ;------------------------------------------------------------
                            889 ;	../../Common/module.c:131: portCHAR module_setup(void)
                            890 ;	-----------------------------------------
                            891 ;	 function module_setup
                            892 ;	-----------------------------------------
   43D5                     893 _module_setup:
                            894 ;	../../Common/module.c:135: debug("Module setup:\r\n");	
                            895 ;	genCall
                            896 ;	Peephole 182.a	used 16 bit load of DPTR
   43D5 90 E7 A0            897 	mov	dptr,#__str_0
   43D8 12 38 E8            898 	lcall	_debug_constant
                            899 ;	../../Common/module.c:138: while (modules[i].id != MODULE_NONE)
                            900 ;	genAssign
   43DB 7A 00               901 	mov	r2,#0x00
   43DD                     902 00103$:
                            903 ;	genMult
                            904 ;	genMultOneByte
   43DD EA                  905 	mov	a,r2
   43DE 75 F0 0D            906 	mov	b,#0x0D
   43E1 A4                  907 	mul	ab
                            908 ;	genPlus
   43E2 24 A6               909 	add	a,#_modules
   43E4 FB                  910 	mov	r3,a
                            911 ;	Peephole 240	use clr instead of addc a,#0
   43E5 E4                  912 	clr	a
   43E6 34 F0               913 	addc	a,#(_modules >> 8)
   43E8 FC                  914 	mov	r4,a
                            915 ;	genPlus
                            916 ;     genPlusIncr
   43E9 74 08               917 	mov	a,#0x08
                            918 ;	Peephole 236.a	used r3 instead of ar3
   43EB 2B                  919 	add	a,r3
   43EC F5 82               920 	mov	dpl,a
                            921 ;	Peephole 181	changed mov to clr
   43EE E4                  922 	clr	a
                            923 ;	Peephole 236.b	used r4 instead of ar4
   43EF 3C                  924 	addc	a,r4
   43F0 F5 83               925 	mov	dph,a
                            926 ;	genPointerGet
                            927 ;	genFarPointerGet
   43F2 E0                  928 	movx	a,@dptr
                            929 ;	genCmpEq
                            930 ;	gencjneshort
                            931 ;	Peephole 112.b	changed ljmp to sjmp
   43F3 FB                  932 	mov	r3,a
                            933 ;	Peephole 115.b	jump optimization
   43F4 60 41               934 	jz	00105$
                            935 ;	Peephole 300	removed redundant label 00112$
                            936 ;	../../Common/module.c:140: if (i) debug(" ");
                            937 ;	genIfx
   43F6 EA                  938 	mov	a,r2
                            939 ;	genIfxJump
                            940 ;	Peephole 108.c	removed ljmp by inverse jump logic
   43F7 60 0A               941 	jz	00102$
                            942 ;	Peephole 300	removed redundant label 00113$
                            943 ;	genCall
                            944 ;	Peephole 182.a	used 16 bit load of DPTR
   43F9 90 E7 B0            945 	mov	dptr,#__str_1
   43FC C0 02               946 	push	ar2
   43FE 12 38 E8            947 	lcall	_debug_constant
   4401 D0 02               948 	pop	ar2
   4403                     949 00102$:
                            950 ;	../../Common/module.c:141: debug_int(modules[i].id);
                            951 ;	genMult
                            952 ;	genMultOneByte
   4403 EA                  953 	mov	a,r2
   4404 75 F0 0D            954 	mov	b,#0x0D
   4407 A4                  955 	mul	ab
                            956 ;	genPlus
   4408 24 A6               957 	add	a,#_modules
   440A FB                  958 	mov	r3,a
                            959 ;	Peephole 240	use clr instead of addc a,#0
   440B E4                  960 	clr	a
   440C 34 F0               961 	addc	a,#(_modules >> 8)
   440E FC                  962 	mov	r4,a
                            963 ;	genPlus
                            964 ;     genPlusIncr
   440F 74 08               965 	mov	a,#0x08
                            966 ;	Peephole 236.a	used r3 instead of ar3
   4411 2B                  967 	add	a,r3
   4412 F5 82               968 	mov	dpl,a
                            969 ;	Peephole 181	changed mov to clr
   4414 E4                  970 	clr	a
                            971 ;	Peephole 236.b	used r4 instead of ar4
   4415 3C                  972 	addc	a,r4
   4416 F5 83               973 	mov	dph,a
                            974 ;	genPointerGet
                            975 ;	genFarPointerGet
   4418 E0                  976 	movx	a,@dptr
   4419 FB                  977 	mov	r3,a
                            978 ;	genCast
   441A 7C 00               979 	mov	r4,#0x00
                            980 ;	genIpush
   441C C0 02               981 	push	ar2
   441E C0 03               982 	push	ar3
   4420 C0 04               983 	push	ar4
                            984 ;	genIpush
   4422 74 0A               985 	mov	a,#0x0A
   4424 C0 E0               986 	push	acc
                            987 ;	genCall
   4426 75 82 06            988 	mov	dpl,#0x06
   4429 12 39 23            989 	lcall	_debug_integer
   442C 15 81               990 	dec	sp
   442E 15 81               991 	dec	sp
   4430 15 81               992 	dec	sp
   4432 D0 02               993 	pop	ar2
                            994 ;	../../Common/module.c:142: i++;
                            995 ;	genPlus
                            996 ;     genPlusIncr
   4434 0A                  997 	inc	r2
                            998 ;	Peephole 112.b	changed ljmp to sjmp
   4435 80 A6               999 	sjmp	00103$
   4437                    1000 00105$:
                           1001 ;	../../Common/module.c:145: debug("\r\n");	
                           1002 ;	genCall
                           1003 ;	Peephole 182.a	used 16 bit load of DPTR
   4437 90 E7 B2           1004 	mov	dptr,#__str_2
   443A 12 38 E8           1005 	lcall	_debug_constant
                           1006 ;	../../Common/module.c:147: return pdTRUE;
                           1007 ;	genRet
   443D 75 82 01           1008 	mov	dpl,#0x01
                           1009 ;	Peephole 300	removed redundant label 00106$
   4440 22                 1010 	ret
                           1011 	.area CSEG    (CODE)
                           1012 	.area CONST   (CODE)
   E7A0                    1013 __str_0:
   E7A0 4D 6F 64 75 6C 65  1014 	.ascii "Module setup:"
        20 73 65 74 75 70
        3A
   E7AD 0D                 1015 	.db 0x0D
   E7AE 0A                 1016 	.db 0x0A
   E7AF 00                 1017 	.db 0x00
   E7B0                    1018 __str_1:
   E7B0 20                 1019 	.ascii " "
   E7B1 00                 1020 	.db 0x00
   E7B2                    1021 __str_2:
   E7B2 0D                 1022 	.db 0x0D
   E7B3 0A                 1023 	.db 0x0A
   E7B4 00                 1024 	.db 0x00
                           1025 	.area XINIT   (CODE)
   E8A3                    1026 __xinit__modules:
   E8A3 FF AC              1027 	.byte _cipv6_init,(_cipv6_init >> 8)
   E8A5 30 AD              1028 	.byte _cipv6_handle,(_cipv6_handle >> 8)
   E8A7 4A B0              1029 	.byte _cipv6_check,(_cipv6_check >> 8)
   E8A9 00 00              1030 	.byte #0x00,#0x00
   E8AB 01                 1031 	.db #0x01
   E8AC 29                 1032 	.db #0x29
   E8AD 01                 1033 	.db #0x01
   E8AE 00 00              1034 	.byte #0x00,#0x00
   E8B0 C3 CD              1035 	.byte _cudp_init,(_cudp_init >> 8)
   E8B2 CE CD              1036 	.byte _cudp_handle,(_cudp_handle >> 8)
   E8B4 5D DE              1037 	.byte _cudp_check,(_cudp_check >> 8)
   E8B6 00 00              1038 	.byte #0x00,#0x00
   E8B8 02                 1039 	.db #0x02
   E8B9 08                 1040 	.db #0x08
   E8BA 00                 1041 	.db #0x00
   E8BB 00 00              1042 	.byte #0x00,#0x00
   E8BD 07 7C              1043 	.byte _rf_802_15_4_init,(_rf_802_15_4_init >> 8)
   E8BF 5F 7C              1044 	.byte _rf_802_15_4_handle,(_rf_802_15_4_handle >> 8)
   E8C1 94 81              1045 	.byte _rf_802_15_4_check,(_rf_802_15_4_check >> 8)
   E8C3 00 00              1046 	.byte #0x00,#0x00
   E8C5 08                 1047 	.db #0x08
   E8C6 17                 1048 	.db #0x17
   E8C7 04                 1049 	.db #0x04
   E8C8 00 00              1050 	.byte #0x00,#0x00
   E8CA 00 00              1051 	.byte #0x00,#0x00
   E8CC 00 00              1052 	.byte #0x00,#0x00
   E8CE 00 00              1053 	.byte #0x00,#0x00
   E8D0 00 00              1054 	.byte #0x00,#0x00
   E8D2 00                 1055 	.db #0x00
   E8D3 00                 1056 	.db #0x00
   E8D4 00                 1057 	.db #0x00
   E8D5 00 00              1058 	.byte #0x00,#0x00
