                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Nov 10 2006)
                              4 ; This file generated Fri Feb  1 13:33:40 2008
                              5 ;--------------------------------------------------------
                              6 	.module cIPv6
                              7 	.optsdcc -mmcs51 --model-large
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _IRCON2_P2IF
                             13 	.globl _IRCON2_UTX0IF
                             14 	.globl _IRCON2_UTX1IF
                             15 	.globl _IRCON2_P1IF
                             16 	.globl _IRCON2_WDTIF
                             17 	.globl _CY
                             18 	.globl _AC
                             19 	.globl _F0
                             20 	.globl _RS1
                             21 	.globl _RS0
                             22 	.globl _OV
                             23 	.globl _F1
                             24 	.globl _P
                             25 	.globl _IRCON_DMAIF
                             26 	.globl _IRCON_T1IF
                             27 	.globl _IRCON_T2IF
                             28 	.globl _IRCON_T3IF
                             29 	.globl _IRCON_T4IF
                             30 	.globl _IRCON_P0IF
                             31 	.globl _IRCON_STIF
                             32 	.globl _IEN1_DMAIE
                             33 	.globl _IEN1_T1IE
                             34 	.globl _IEN1_T2IE
                             35 	.globl _IEN1_T3IE
                             36 	.globl _IEN1_T4IE
                             37 	.globl _IEN1_P0IE
                             38 	.globl _IEN0_RFERRIE
                             39 	.globl _IEN0_ADCIE
                             40 	.globl _IEN0_URX0IE
                             41 	.globl _IEN0_URX1IE
                             42 	.globl _IEN0_ENCIE
                             43 	.globl _IEN0_STIE
                             44 	.globl _IEN0_EA
                             45 	.globl _EA
                             46 	.globl _P2_4
                             47 	.globl _P2_3
                             48 	.globl _P2_2
                             49 	.globl _P2_1
                             50 	.globl _P2_0
                             51 	.globl _S0CON_ENCIF_0
                             52 	.globl _S0CON_ENCIF_1
                             53 	.globl _P1_7
                             54 	.globl _P1_6
                             55 	.globl _P1_5
                             56 	.globl _P1_4
                             57 	.globl _P1_3
                             58 	.globl _P1_2
                             59 	.globl _P1_1
                             60 	.globl _P1_0
                             61 	.globl _TCON_IT0
                             62 	.globl _TCON_RFERRIF
                             63 	.globl _TCON_IT1
                             64 	.globl _TCON_URX0IF
                             65 	.globl _TCON_ADCIF
                             66 	.globl _TCON_URX1IF
                             67 	.globl _P0_0
                             68 	.globl _P0_1
                             69 	.globl _P0_2
                             70 	.globl _P0_3
                             71 	.globl _P0_4
                             72 	.globl _P0_5
                             73 	.globl _P0_6
                             74 	.globl _P0_7
                             75 	.globl _P2DIR
                             76 	.globl _P1DIR
                             77 	.globl _P0DIR
                             78 	.globl _U1GCR
                             79 	.globl _U1UCR
                             80 	.globl _U1BAUD
                             81 	.globl _U1BUF
                             82 	.globl _U1CSR
                             83 	.globl _P2INP
                             84 	.globl _P1INP
                             85 	.globl _P2SEL
                             86 	.globl _P1SEL
                             87 	.globl _P0SEL
                             88 	.globl _ADCCFG
                             89 	.globl _PERCFG
                             90 	.globl _B
                             91 	.globl _T4CC1
                             92 	.globl _T4CCTL1
                             93 	.globl _T4CC0
                             94 	.globl _T4CCTL0
                             95 	.globl _T4CTL
                             96 	.globl _T4CNT
                             97 	.globl _RFIF
                             98 	.globl _IRCON2
                             99 	.globl _T1CCTL2
                            100 	.globl _T1CCTL1
                            101 	.globl _T1CCTL0
                            102 	.globl _T1CTL
                            103 	.globl _T1CNTH
                            104 	.globl _T1CNTL
                            105 	.globl _RFST
                            106 	.globl _ACC
                            107 	.globl _T1CC2H
                            108 	.globl _T1CC2L
                            109 	.globl _T1CC1H
                            110 	.globl _T1CC1L
                            111 	.globl _T1CC0H
                            112 	.globl _T1CC0L
                            113 	.globl _RFD
                            114 	.globl _TIMIF
                            115 	.globl _DMAREQ
                            116 	.globl _DMAARM
                            117 	.globl _DMA0CFGH
                            118 	.globl _DMA0CFGL
                            119 	.globl _DMA1CFGH
                            120 	.globl _DMA1CFGL
                            121 	.globl _DMAIRQ
                            122 	.globl _PSW
                            123 	.globl _T3CC1
                            124 	.globl _T3CCTL1
                            125 	.globl _T3CC0
                            126 	.globl _T3CCTL0
                            127 	.globl _T3CTL
                            128 	.globl _T3CNT
                            129 	.globl _WDCTL
                            130 	.globl _T2CON
                            131 	.globl _MEMCTR
                            132 	.globl _CLKCON
                            133 	.globl _U0GCR
                            134 	.globl _U0UCR
                            135 	.globl _T2CNF
                            136 	.globl _U0BAUD
                            137 	.globl _U0BUF
                            138 	.globl _IRCON
                            139 	.globl _SLEEP
                            140 	.globl _RNDH
                            141 	.globl _RNDL
                            142 	.globl _ADCH
                            143 	.globl _ADCL
                            144 	.globl _IP1
                            145 	.globl _IEN1
                            146 	.globl _RCCTL
                            147 	.globl _ADCCON3
                            148 	.globl _ADCCON2
                            149 	.globl _ADCCON1
                            150 	.globl _ENCCS
                            151 	.globl _ENCDO
                            152 	.globl _ENCDI
                            153 	.globl _FWDATA
                            154 	.globl _FCTL
                            155 	.globl _FADDRH
                            156 	.globl _FADDRL
                            157 	.globl _FWT
                            158 	.globl _IP0
                            159 	.globl _IEN0
                            160 	.globl _IE
                            161 	.globl _T2THD
                            162 	.globl _T2TLD
                            163 	.globl _T2CAPHPH
                            164 	.globl _T2CAPLPL
                            165 	.globl _T2OF2
                            166 	.globl _T2OF1
                            167 	.globl _T2OF0
                            168 	.globl _P2
                            169 	.globl _T2PEROF2
                            170 	.globl _T2PEROF1
                            171 	.globl _T2PEROF0
                            172 	.globl _S1CON
                            173 	.globl _IEN2
                            174 	.globl _HSRC
                            175 	.globl _S0CON
                            176 	.globl _ST2
                            177 	.globl _ST1
                            178 	.globl _ST0
                            179 	.globl _T2CMP
                            180 	.globl __XPAGE
                            181 	.globl _DPS
                            182 	.globl _RFIM
                            183 	.globl _P1
                            184 	.globl _P0INP
                            185 	.globl _P1IEN
                            186 	.globl _PICTL
                            187 	.globl _P2IFG
                            188 	.globl _P1IFG
                            189 	.globl _P0IFG
                            190 	.globl _TCON
                            191 	.globl _PCON
                            192 	.globl _U0CSR
                            193 	.globl _DPH1
                            194 	.globl _DPL1
                            195 	.globl _DPH0
                            196 	.globl _DPL0
                            197 	.globl _SP
                            198 	.globl _P0
                            199 	.globl _cipv6_pib
                            200 	.globl _RFD_SHADOW
                            201 	.globl _RFSTATUS
                            202 	.globl _CHIPID
                            203 	.globl _CHVER
                            204 	.globl _FSMTC1
                            205 	.globl _RXFIFOCNT
                            206 	.globl _IOCFG3
                            207 	.globl _IOCFG2
                            208 	.globl _IOCFG1
                            209 	.globl _IOCFG0
                            210 	.globl _SHORTADDRL
                            211 	.globl _SHORTADDRH
                            212 	.globl _PANIDL
                            213 	.globl _PANIDH
                            214 	.globl _IEEE_ADDR7
                            215 	.globl _IEEE_ADDR6
                            216 	.globl _IEEE_ADDR5
                            217 	.globl _IEEE_ADDR4
                            218 	.globl _IEEE_ADDR3
                            219 	.globl _IEEE_ADDR2
                            220 	.globl _IEEE_ADDR1
                            221 	.globl _IEEE_ADDR0
                            222 	.globl _DACTSTL
                            223 	.globl _DACTSTH
                            224 	.globl _ADCTSTL
                            225 	.globl _ADCTSTH
                            226 	.globl _FSMSTATE
                            227 	.globl _AGCCTRLL
                            228 	.globl _AGCCTRLH
                            229 	.globl _MANORL
                            230 	.globl _MANORH
                            231 	.globl _MANANDL
                            232 	.globl _MANANDH
                            233 	.globl _FSMTCL
                            234 	.globl _FSMTCH
                            235 	.globl _RFPWR
                            236 	.globl _CSPT
                            237 	.globl _CSPCTRL
                            238 	.globl _CSPZ
                            239 	.globl _CSPY
                            240 	.globl _CSPX
                            241 	.globl _FSCTRLL
                            242 	.globl _FSCTRLH
                            243 	.globl _RXCTRL1L
                            244 	.globl _RXCTRL1H
                            245 	.globl _RXCTRL0L
                            246 	.globl _RXCTRL0H
                            247 	.globl _TXCTRLL
                            248 	.globl _TXCTRLH
                            249 	.globl _SYNCWORDL
                            250 	.globl _SYNCWORDH
                            251 	.globl _RSSIL
                            252 	.globl _RSSIH
                            253 	.globl _MDMCTRL1L
                            254 	.globl _MDMCTRL1H
                            255 	.globl _MDMCTRL0L
                            256 	.globl _MDMCTRL0H
                            257 	.globl _cipv6_init
                            258 	.globl _cipv6_compress_mode
                            259 	.globl _cipv6_handle
                            260 	.globl _cipv6_check
                            261 	.globl _parse_hc1_message
                            262 	.globl _parse_mesh_packet
                            263 	.globl _build_lowpan_header
                            264 	.globl _add_own_address
                            265 	.globl _update_ip_sqn
                            266 	.globl _build_ipv6_header
                            267 	.globl _parse_ipv_header
                            268 	.globl _compare_ori_to_own
                            269 ;--------------------------------------------------------
                            270 ; special function registers
                            271 ;--------------------------------------------------------
                            272 	.area RSEG    (DATA)
                    0080    273 _P0	=	0x0080
                    0081    274 _SP	=	0x0081
                    0082    275 _DPL0	=	0x0082
                    0083    276 _DPH0	=	0x0083
                    0084    277 _DPL1	=	0x0084
                    0085    278 _DPH1	=	0x0085
                    0086    279 _U0CSR	=	0x0086
                    0087    280 _PCON	=	0x0087
                    0088    281 _TCON	=	0x0088
                    0089    282 _P0IFG	=	0x0089
                    008A    283 _P1IFG	=	0x008a
                    008B    284 _P2IFG	=	0x008b
                    008C    285 _PICTL	=	0x008c
                    008D    286 _P1IEN	=	0x008d
                    008F    287 _P0INP	=	0x008f
                    0090    288 _P1	=	0x0090
                    0091    289 _RFIM	=	0x0091
                    0092    290 _DPS	=	0x0092
                    0093    291 __XPAGE	=	0x0093
                    0094    292 _T2CMP	=	0x0094
                    0095    293 _ST0	=	0x0095
                    0096    294 _ST1	=	0x0096
                    0097    295 _ST2	=	0x0097
                    0098    296 _S0CON	=	0x0098
                    0099    297 _HSRC	=	0x0099
                    009A    298 _IEN2	=	0x009a
                    009B    299 _S1CON	=	0x009b
                    009C    300 _T2PEROF0	=	0x009c
                    009D    301 _T2PEROF1	=	0x009d
                    009E    302 _T2PEROF2	=	0x009e
                    00A0    303 _P2	=	0x00a0
                    00A1    304 _T2OF0	=	0x00a1
                    00A2    305 _T2OF1	=	0x00a2
                    00A3    306 _T2OF2	=	0x00a3
                    00A4    307 _T2CAPLPL	=	0x00a4
                    00A5    308 _T2CAPHPH	=	0x00a5
                    00A6    309 _T2TLD	=	0x00a6
                    00A7    310 _T2THD	=	0x00a7
                    00A8    311 _IE	=	0x00a8
                    00A8    312 _IEN0	=	0x00a8
                    00A9    313 _IP0	=	0x00a9
                    00AB    314 _FWT	=	0x00ab
                    00AC    315 _FADDRL	=	0x00ac
                    00AD    316 _FADDRH	=	0x00ad
                    00AE    317 _FCTL	=	0x00ae
                    00AF    318 _FWDATA	=	0x00af
                    00B1    319 _ENCDI	=	0x00b1
                    00B2    320 _ENCDO	=	0x00b2
                    00B3    321 _ENCCS	=	0x00b3
                    00B4    322 _ADCCON1	=	0x00b4
                    00B5    323 _ADCCON2	=	0x00b5
                    00B6    324 _ADCCON3	=	0x00b6
                    00B7    325 _RCCTL	=	0x00b7
                    00B8    326 _IEN1	=	0x00b8
                    00B9    327 _IP1	=	0x00b9
                    00BA    328 _ADCL	=	0x00ba
                    00BB    329 _ADCH	=	0x00bb
                    00BC    330 _RNDL	=	0x00bc
                    00BD    331 _RNDH	=	0x00bd
                    00BE    332 _SLEEP	=	0x00be
                    00C0    333 _IRCON	=	0x00c0
                    00C1    334 _U0BUF	=	0x00c1
                    00C2    335 _U0BAUD	=	0x00c2
                    00C3    336 _T2CNF	=	0x00c3
                    00C4    337 _U0UCR	=	0x00c4
                    00C5    338 _U0GCR	=	0x00c5
                    00C6    339 _CLKCON	=	0x00c6
                    00C7    340 _MEMCTR	=	0x00c7
                    00C8    341 _T2CON	=	0x00c8
                    00C9    342 _WDCTL	=	0x00c9
                    00CA    343 _T3CNT	=	0x00ca
                    00CB    344 _T3CTL	=	0x00cb
                    00CC    345 _T3CCTL0	=	0x00cc
                    00CD    346 _T3CC0	=	0x00cd
                    00CE    347 _T3CCTL1	=	0x00ce
                    00CF    348 _T3CC1	=	0x00cf
                    00D0    349 _PSW	=	0x00d0
                    00D1    350 _DMAIRQ	=	0x00d1
                    00D2    351 _DMA1CFGL	=	0x00d2
                    00D3    352 _DMA1CFGH	=	0x00d3
                    00D4    353 _DMA0CFGL	=	0x00d4
                    00D5    354 _DMA0CFGH	=	0x00d5
                    00D6    355 _DMAARM	=	0x00d6
                    00D7    356 _DMAREQ	=	0x00d7
                    00D8    357 _TIMIF	=	0x00d8
                    00D9    358 _RFD	=	0x00d9
                    00DA    359 _T1CC0L	=	0x00da
                    00DB    360 _T1CC0H	=	0x00db
                    00DC    361 _T1CC1L	=	0x00dc
                    00DD    362 _T1CC1H	=	0x00dd
                    00DE    363 _T1CC2L	=	0x00de
                    00DF    364 _T1CC2H	=	0x00df
                    00E0    365 _ACC	=	0x00e0
                    00E1    366 _RFST	=	0x00e1
                    00E2    367 _T1CNTL	=	0x00e2
                    00E3    368 _T1CNTH	=	0x00e3
                    00E4    369 _T1CTL	=	0x00e4
                    00E5    370 _T1CCTL0	=	0x00e5
                    00E6    371 _T1CCTL1	=	0x00e6
                    00E7    372 _T1CCTL2	=	0x00e7
                    00E8    373 _IRCON2	=	0x00e8
                    00E9    374 _RFIF	=	0x00e9
                    00EA    375 _T4CNT	=	0x00ea
                    00EB    376 _T4CTL	=	0x00eb
                    00EC    377 _T4CCTL0	=	0x00ec
                    00ED    378 _T4CC0	=	0x00ed
                    00EE    379 _T4CCTL1	=	0x00ee
                    00EF    380 _T4CC1	=	0x00ef
                    00F0    381 _B	=	0x00f0
                    00F1    382 _PERCFG	=	0x00f1
                    00F2    383 _ADCCFG	=	0x00f2
                    00F3    384 _P0SEL	=	0x00f3
                    00F4    385 _P1SEL	=	0x00f4
                    00F5    386 _P2SEL	=	0x00f5
                    00F6    387 _P1INP	=	0x00f6
                    00F7    388 _P2INP	=	0x00f7
                    00F8    389 _U1CSR	=	0x00f8
                    00F9    390 _U1BUF	=	0x00f9
                    00FA    391 _U1BAUD	=	0x00fa
                    00FB    392 _U1UCR	=	0x00fb
                    00FC    393 _U1GCR	=	0x00fc
                    00FD    394 _P0DIR	=	0x00fd
                    00FE    395 _P1DIR	=	0x00fe
                    00FF    396 _P2DIR	=	0x00ff
                            397 ;--------------------------------------------------------
                            398 ; special function bits
                            399 ;--------------------------------------------------------
                            400 	.area RSEG    (DATA)
                    0087    401 _P0_7	=	0x0087
                    0086    402 _P0_6	=	0x0086
                    0085    403 _P0_5	=	0x0085
                    0084    404 _P0_4	=	0x0084
                    0083    405 _P0_3	=	0x0083
                    0082    406 _P0_2	=	0x0082
                    0081    407 _P0_1	=	0x0081
                    0080    408 _P0_0	=	0x0080
                    008F    409 _TCON_URX1IF	=	0x008f
                    008D    410 _TCON_ADCIF	=	0x008d
                    008B    411 _TCON_URX0IF	=	0x008b
                    008A    412 _TCON_IT1	=	0x008a
                    0089    413 _TCON_RFERRIF	=	0x0089
                    0088    414 _TCON_IT0	=	0x0088
                    0090    415 _P1_0	=	0x0090
                    0091    416 _P1_1	=	0x0091
                    0092    417 _P1_2	=	0x0092
                    0093    418 _P1_3	=	0x0093
                    0094    419 _P1_4	=	0x0094
                    0095    420 _P1_5	=	0x0095
                    0096    421 _P1_6	=	0x0096
                    0097    422 _P1_7	=	0x0097
                    0099    423 _S0CON_ENCIF_1	=	0x0099
                    0098    424 _S0CON_ENCIF_0	=	0x0098
                    00A0    425 _P2_0	=	0x00a0
                    00A1    426 _P2_1	=	0x00a1
                    00A2    427 _P2_2	=	0x00a2
                    00A3    428 _P2_3	=	0x00a3
                    00A4    429 _P2_4	=	0x00a4
                    00AF    430 _EA	=	0x00af
                    00AF    431 _IEN0_EA	=	0x00af
                    00AD    432 _IEN0_STIE	=	0x00ad
                    00AC    433 _IEN0_ENCIE	=	0x00ac
                    00AB    434 _IEN0_URX1IE	=	0x00ab
                    00AA    435 _IEN0_URX0IE	=	0x00aa
                    00A9    436 _IEN0_ADCIE	=	0x00a9
                    00A8    437 _IEN0_RFERRIE	=	0x00a8
                    00BD    438 _IEN1_P0IE	=	0x00bd
                    00BC    439 _IEN1_T4IE	=	0x00bc
                    00BB    440 _IEN1_T3IE	=	0x00bb
                    00BA    441 _IEN1_T2IE	=	0x00ba
                    00B9    442 _IEN1_T1IE	=	0x00b9
                    00B8    443 _IEN1_DMAIE	=	0x00b8
                    00C7    444 _IRCON_STIF	=	0x00c7
                    00C5    445 _IRCON_P0IF	=	0x00c5
                    00C4    446 _IRCON_T4IF	=	0x00c4
                    00C3    447 _IRCON_T3IF	=	0x00c3
                    00C2    448 _IRCON_T2IF	=	0x00c2
                    00C1    449 _IRCON_T1IF	=	0x00c1
                    00C0    450 _IRCON_DMAIF	=	0x00c0
                    00D0    451 _P	=	0x00d0
                    00D1    452 _F1	=	0x00d1
                    00D2    453 _OV	=	0x00d2
                    00D3    454 _RS0	=	0x00d3
                    00D4    455 _RS1	=	0x00d4
                    00D5    456 _F0	=	0x00d5
                    00D6    457 _AC	=	0x00d6
                    00D7    458 _CY	=	0x00d7
                    00EC    459 _IRCON2_WDTIF	=	0x00ec
                    00EB    460 _IRCON2_P1IF	=	0x00eb
                    00EA    461 _IRCON2_UTX1IF	=	0x00ea
                    00E9    462 _IRCON2_UTX0IF	=	0x00e9
                    00E8    463 _IRCON2_P2IF	=	0x00e8
                            464 ;--------------------------------------------------------
                            465 ; overlayable register banks
                            466 ;--------------------------------------------------------
                            467 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     468 	.ds 8
                            469 ;--------------------------------------------------------
                            470 ; internal ram data
                            471 ;--------------------------------------------------------
                            472 	.area DSEG    (DATA)
                            473 ;--------------------------------------------------------
                            474 ; overlayable items in internal ram 
                            475 ;--------------------------------------------------------
                            476 	.area OSEG    (OVR,DATA)
                            477 ;--------------------------------------------------------
                            478 ; indirectly addressable internal ram data
                            479 ;--------------------------------------------------------
                            480 	.area ISEG    (DATA)
                            481 ;--------------------------------------------------------
                            482 ; bit data
                            483 ;--------------------------------------------------------
                            484 	.area BSEG    (BIT)
                            485 ;--------------------------------------------------------
                            486 ; paged external ram data
                            487 ;--------------------------------------------------------
                            488 	.area PSEG    (PAG,XDATA)
                            489 ;--------------------------------------------------------
                            490 ; external ram data
                            491 ;--------------------------------------------------------
                            492 	.area XSEG    (XDATA)
                    DF02    493 _MDMCTRL0H	=	0xdf02
                    DF03    494 _MDMCTRL0L	=	0xdf03
                    DF04    495 _MDMCTRL1H	=	0xdf04
                    DF05    496 _MDMCTRL1L	=	0xdf05
                    DF06    497 _RSSIH	=	0xdf06
                    DF07    498 _RSSIL	=	0xdf07
                    DF08    499 _SYNCWORDH	=	0xdf08
                    DF09    500 _SYNCWORDL	=	0xdf09
                    DF0A    501 _TXCTRLH	=	0xdf0a
                    DF0B    502 _TXCTRLL	=	0xdf0b
                    DF0C    503 _RXCTRL0H	=	0xdf0c
                    DF0D    504 _RXCTRL0L	=	0xdf0d
                    DF0E    505 _RXCTRL1H	=	0xdf0e
                    DF0F    506 _RXCTRL1L	=	0xdf0f
                    DF10    507 _FSCTRLH	=	0xdf10
                    DF11    508 _FSCTRLL	=	0xdf11
                    DF12    509 _CSPX	=	0xdf12
                    DF13    510 _CSPY	=	0xdf13
                    DF14    511 _CSPZ	=	0xdf14
                    DF15    512 _CSPCTRL	=	0xdf15
                    DF16    513 _CSPT	=	0xdf16
                    DF17    514 _RFPWR	=	0xdf17
                    DF20    515 _FSMTCH	=	0xdf20
                    DF21    516 _FSMTCL	=	0xdf21
                    DF22    517 _MANANDH	=	0xdf22
                    DF23    518 _MANANDL	=	0xdf23
                    DF24    519 _MANORH	=	0xdf24
                    DF25    520 _MANORL	=	0xdf25
                    DF26    521 _AGCCTRLH	=	0xdf26
                    DF27    522 _AGCCTRLL	=	0xdf27
                    DF39    523 _FSMSTATE	=	0xdf39
                    DF3A    524 _ADCTSTH	=	0xdf3a
                    DF3B    525 _ADCTSTL	=	0xdf3b
                    DF3C    526 _DACTSTH	=	0xdf3c
                    DF3D    527 _DACTSTL	=	0xdf3d
                    DF43    528 _IEEE_ADDR0	=	0xdf43
                    DF44    529 _IEEE_ADDR1	=	0xdf44
                    DF45    530 _IEEE_ADDR2	=	0xdf45
                    DF46    531 _IEEE_ADDR3	=	0xdf46
                    DF47    532 _IEEE_ADDR4	=	0xdf47
                    DF48    533 _IEEE_ADDR5	=	0xdf48
                    DF49    534 _IEEE_ADDR6	=	0xdf49
                    DF4A    535 _IEEE_ADDR7	=	0xdf4a
                    DF4B    536 _PANIDH	=	0xdf4b
                    DF4C    537 _PANIDL	=	0xdf4c
                    DF4D    538 _SHORTADDRH	=	0xdf4d
                    DF4E    539 _SHORTADDRL	=	0xdf4e
                    DF4F    540 _IOCFG0	=	0xdf4f
                    DF50    541 _IOCFG1	=	0xdf50
                    DF51    542 _IOCFG2	=	0xdf51
                    DF52    543 _IOCFG3	=	0xdf52
                    DF53    544 _RXFIFOCNT	=	0xdf53
                    DF54    545 _FSMTC1	=	0xdf54
                    DF60    546 _CHVER	=	0xdf60
                    DF61    547 _CHIPID	=	0xdf61
                    DF62    548 _RFSTATUS	=	0xdf62
                    DFD9    549 _RFD_SHADOW	=	0xdfd9
   F04D                     550 _cipv6_pib::
   F04D                     551 	.ds 14
                            552 ;--------------------------------------------------------
                            553 ; external initialized ram data
                            554 ;--------------------------------------------------------
                            555 	.area XISEG   (XDATA)
                            556 	.area HOME    (CODE)
                            557 	.area GSINIT0 (CODE)
                            558 	.area GSINIT1 (CODE)
                            559 	.area GSINIT2 (CODE)
                            560 	.area GSINIT3 (CODE)
                            561 	.area GSINIT4 (CODE)
                            562 	.area GSINIT5 (CODE)
                            563 	.area GSINIT  (CODE)
                            564 	.area GSFINAL (CODE)
                            565 	.area CSEG    (CODE)
                            566 ;--------------------------------------------------------
                            567 ; global & static initialisations
                            568 ;--------------------------------------------------------
                            569 	.area HOME    (CODE)
                            570 	.area GSINIT  (CODE)
                            571 	.area GSFINAL (CODE)
                            572 	.area GSINIT  (CODE)
                            573 ;--------------------------------------------------------
                            574 ; Home
                            575 ;--------------------------------------------------------
                            576 	.area HOME    (CODE)
                            577 	.area CSEG    (CODE)
                            578 ;--------------------------------------------------------
                            579 ; code
                            580 ;--------------------------------------------------------
                            581 	.area CSEG    (CODE)
                            582 ;------------------------------------------------------------
                            583 ;Allocation info for local variables in function 'cipv6_init'
                            584 ;------------------------------------------------------------
                            585 ;buf                       Allocated to registers 
                            586 ;------------------------------------------------------------
                            587 ;	../../Common/modules/cIPv6.c:87: portCHAR cipv6_init( buffer_t *buf )
                            588 ;	-----------------------------------------
                            589 ;	 function cipv6_init
                            590 ;	-----------------------------------------
   ACFF                     591 _cipv6_init:
                    0002    592 	ar2 = 0x02
                    0003    593 	ar3 = 0x03
                    0004    594 	ar4 = 0x04
                    0005    595 	ar5 = 0x05
                    0006    596 	ar6 = 0x06
                    0007    597 	ar7 = 0x07
                    0000    598 	ar0 = 0x00
                    0001    599 	ar1 = 0x01
                            600 ;	../../Common/modules/cIPv6.c:91: cipv6_pib.own_brodcast_sqn = 0;
                            601 ;	genPointerSet
                            602 ;     genFarPointerSet
   ACFF 90 F0 4D            603 	mov	dptr,#_cipv6_pib
                            604 ;	Peephole 181	changed mov to clr
   AD02 E4                  605 	clr	a
   AD03 F0                  606 	movx	@dptr,a
                            607 ;	../../Common/modules/cIPv6.c:92: cipv6_pib.last_forwarded_bc_sqn = 0xff;
                            608 ;	genPointerSet
                            609 ;     genFarPointerSet
   AD04 90 F0 4E            610 	mov	dptr,#(_cipv6_pib + 0x0001)
   AD07 74 FF               611 	mov	a,#0xFF
   AD09 F0                  612 	movx	@dptr,a
                            613 ;	../../Common/modules/cIPv6.c:93: cipv6_pib.use_short_address=0;
                            614 ;	genPointerSet
                            615 ;     genFarPointerSet
   AD0A 90 F0 59            616 	mov	dptr,#(_cipv6_pib + 0x000c)
                            617 ;	Peephole 181	changed mov to clr
   AD0D E4                  618 	clr	a
   AD0E F0                  619 	movx	@dptr,a
                            620 ;	../../Common/modules/cIPv6.c:94: cipv6_pib.short_address[0] = 0xfe;
                            621 ;	genPointerSet
                            622 ;     genFarPointerSet
   AD0F 90 F0 57            623 	mov	dptr,#(_cipv6_pib + 0x000a)
   AD12 74 FE               624 	mov	a,#0xFE
   AD14 F0                  625 	movx	@dptr,a
                            626 ;	../../Common/modules/cIPv6.c:95: cipv6_pib.short_address[1] = 0xff;
                            627 ;	genPointerSet
                            628 ;     genFarPointerSet
   AD15 90 F0 58            629 	mov	dptr,#(_cipv6_pib + 0x000b)
   AD18 74 FF               630 	mov	a,#0xFF
   AD1A F0                  631 	movx	@dptr,a
                            632 ;	../../Common/modules/cIPv6.c:96: cipv6_pib.use_full_compress = 1;
                            633 ;	genPointerSet
                            634 ;     genFarPointerSet
   AD1B 90 F0 5A            635 	mov	dptr,#(_cipv6_pib + 0x000d)
   AD1E 74 01               636 	mov	a,#0x01
   AD20 F0                  637 	movx	@dptr,a
                            638 ;	../../Common/modules/cIPv6.c:97: routing_init();
                            639 ;	genCall
   AD21 12 6B A8            640 	lcall	_routing_init
                            641 ;	../../Common/modules/cIPv6.c:98: return pdTRUE;
                            642 ;	genRet
   AD24 75 82 01            643 	mov	dpl,#0x01
                            644 ;	Peephole 300	removed redundant label 00101$
   AD27 22                  645 	ret
                            646 ;------------------------------------------------------------
                            647 ;Allocation info for local variables in function 'cipv6_compress_mode'
                            648 ;------------------------------------------------------------
                            649 ;mode                      Allocated to registers r2 
                            650 ;------------------------------------------------------------
                            651 ;	../../Common/modules/cIPv6.c:106: void cipv6_compress_mode( uint8_t mode )
                            652 ;	-----------------------------------------
                            653 ;	 function cipv6_compress_mode
                            654 ;	-----------------------------------------
   AD28                     655 _cipv6_compress_mode:
                            656 ;	genReceive
   AD28 AA 82               657 	mov	r2,dpl
                            658 ;	../../Common/modules/cIPv6.c:108: cipv6_pib.use_full_compress = mode;
                            659 ;	genPointerSet
                            660 ;     genFarPointerSet
   AD2A 90 F0 5A            661 	mov	dptr,#(_cipv6_pib + 0x000d)
   AD2D EA                  662 	mov	a,r2
   AD2E F0                  663 	movx	@dptr,a
                            664 ;	Peephole 300	removed redundant label 00101$
   AD2F 22                  665 	ret
                            666 ;------------------------------------------------------------
                            667 ;Allocation info for local variables in function 'cipv6_handle'
                            668 ;------------------------------------------------------------
                            669 ;buf                       Allocated to stack - offset 1
                            670 ;i                         Allocated to stack - offset 4
                            671 ;ptr                       Allocated to registers r5 r6 r7 
                            672 ;sloc0                     Allocated to stack - offset 5
                            673 ;------------------------------------------------------------
                            674 ;	../../Common/modules/cIPv6.c:117: portCHAR cipv6_handle( buffer_t *buf )
                            675 ;	-----------------------------------------
                            676 ;	 function cipv6_handle
                            677 ;	-----------------------------------------
   AD30                     678 _cipv6_handle:
   AD30 C0 10               679 	push	_bp
   AD32 85 81 10            680 	mov	_bp,sp
                            681 ;     genReceive
   AD35 C0 82               682 	push	dpl
   AD37 C0 83               683 	push	dph
   AD39 C0 F0               684 	push	b
   AD3B 05 81               685 	inc	sp
   AD3D 05 81               686 	inc	sp
   AD3F 05 81               687 	inc	sp
                            688 ;	../../Common/modules/cIPv6.c:122: if(cipv6_pib.own_brodcast_sqn == 0)
                            689 ;	genPointerGet
                            690 ;	genFarPointerGet
   AD41 90 F0 4D            691 	mov	dptr,#_cipv6_pib
   AD44 E0                  692 	movx	a,@dptr
                            693 ;	genIfxJump
                            694 ;	Peephole 108.b	removed ljmp by inverse jump logic
   AD45 70 09               695 	jnz	00102$
                            696 ;	Peephole 300	removed redundant label 00173$
                            697 ;	../../Common/modules/cIPv6.c:124: cipv6_pib.own_brodcast_sqn = mac_long.address[7];
                            698 ;	genPointerGet
                            699 ;	genFarPointerGet
   AD47 90 F0 9A            700 	mov	dptr,#(_mac_long + 0x0008)
   AD4A E0                  701 	movx	a,@dptr
                            702 ;	genPointerSet
                            703 ;     genFarPointerSet
   AD4B FD                  704 	mov	r5,a
   AD4C 90 F0 4D            705 	mov	dptr,#_cipv6_pib
                            706 ;	Peephole 100	removed redundant mov
   AD4F F0                  707 	movx	@dptr,a
   AD50                     708 00102$:
                            709 ;	../../Common/modules/cIPv6.c:130: if(buf->options.type == BUFFER_CONTROL && buf)		/* Control message received */
                            710 ;	genPlus
   AD50 A8 10               711 	mov	r0,_bp
   AD52 08                  712 	inc	r0
                            713 ;     genPlusIncr
   AD53 74 26               714 	mov	a,#0x26
   AD55 26                  715 	add	a,@r0
   AD56 FD                  716 	mov	r5,a
                            717 ;	Peephole 181	changed mov to clr
   AD57 E4                  718 	clr	a
   AD58 08                  719 	inc	r0
   AD59 36                  720 	addc	a,@r0
   AD5A FE                  721 	mov	r6,a
   AD5B 08                  722 	inc	r0
   AD5C 86 07               723 	mov	ar7,@r0
                            724 ;	genPointerGet
                            725 ;	genGenPointerGet
   AD5E 8D 82               726 	mov	dpl,r5
   AD60 8E 83               727 	mov	dph,r6
   AD62 8F F0               728 	mov	b,r7
   AD64 12 E4 9F            729 	lcall	__gptrget
   AD67 FD                  730 	mov	r5,a
                            731 ;	genCmpEq
                            732 ;	gencjneshort
   AD68 BD 01 02            733 	cjne	r5,#0x01,00174$
   AD6B 80 03               734 	sjmp	00175$
   AD6D                     735 00174$:
   AD6D 02 AF 09            736 	ljmp	00119$
   AD70                     737 00175$:
                            738 ;	genIfx
   AD70 A8 10               739 	mov	r0,_bp
   AD72 08                  740 	inc	r0
   AD73 E6                  741 	mov	a,@r0
   AD74 08                  742 	inc	r0
   AD75 46                  743 	orl	a,@r0
   AD76 08                  744 	inc	r0
   AD77 46                  745 	orl	a,@r0
                            746 ;	genIfxJump
   AD78 70 03               747 	jnz	00176$
   AD7A 02 AF 09            748 	ljmp	00119$
   AD7D                     749 00176$:
                            750 ;	../../Common/modules/cIPv6.c:132: control_message_t *ptr = ( control_message_t*) buf->buf;
                            751 ;	genPlus
   AD7D A8 10               752 	mov	r0,_bp
   AD7F 08                  753 	inc	r0
                            754 ;     genPlusIncr
   AD80 74 2C               755 	mov	a,#0x2C
   AD82 26                  756 	add	a,@r0
   AD83 FD                  757 	mov	r5,a
                            758 ;	Peephole 181	changed mov to clr
   AD84 E4                  759 	clr	a
   AD85 08                  760 	inc	r0
   AD86 36                  761 	addc	a,@r0
   AD87 FE                  762 	mov	r6,a
   AD88 08                  763 	inc	r0
   AD89 86 07               764 	mov	ar7,@r0
                            765 ;	../../Common/modules/cIPv6.c:133: if(ptr->message.ip_control.message_id==IP_ADDRESS__MODE_SETUP)
                            766 ;	genPointerGet
                            767 ;	genGenPointerGet
   AD8B 8D 82               768 	mov	dpl,r5
   AD8D 8E 83               769 	mov	dph,r6
   AD8F 8F F0               770 	mov	b,r7
   AD91 12 E4 9F            771 	lcall	__gptrget
                            772 ;	genIfxJump
   AD94 60 03               773 	jz	00177$
   AD96 02 AE EB            774 	ljmp	00115$
   AD99                     775 00177$:
                            776 ;	../../Common/modules/cIPv6.c:138: if(cipv6_pib.use_short_address==1 && buf)
                            777 ;	genIpush
   AD99 C0 05               778 	push	ar5
   AD9B C0 06               779 	push	ar6
   AD9D C0 07               780 	push	ar7
                            781 ;	genPointerGet
                            782 ;	genFarPointerGet
   AD9F 90 F0 59            783 	mov	dptr,#(_cipv6_pib + 0x000c)
   ADA2 E0                  784 	movx	a,@dptr
   ADA3 FD                  785 	mov	r5,a
                            786 ;	genCmpEq
                            787 ;	gencjne
                            788 ;	gencjneshort
                            789 ;	Peephole 241.d	optimized compare
   ADA4 E4                  790 	clr	a
   ADA5 BD 01 01            791 	cjne	r5,#0x01,00178$
   ADA8 04                  792 	inc	a
   ADA9                     793 00178$:
                            794 ;	Peephole 300	removed redundant label 00179$
                            795 ;	genIpop
   ADA9 D0 07               796 	pop	ar7
   ADAB D0 06               797 	pop	ar6
   ADAD D0 05               798 	pop	ar5
                            799 ;	genIfx
                            800 ;	genIfxJump
                            801 ;	Peephole 108.c	removed ljmp by inverse jump logic
   ADAF 60 4D               802 	jz	00106$
                            803 ;	Peephole 300	removed redundant label 00180$
                            804 ;	genIfx
   ADB1 A8 10               805 	mov	r0,_bp
   ADB3 08                  806 	inc	r0
   ADB4 E6                  807 	mov	a,@r0
   ADB5 08                  808 	inc	r0
   ADB6 46                  809 	orl	a,@r0
   ADB7 08                  810 	inc	r0
   ADB8 46                  811 	orl	a,@r0
                            812 ;	genIfxJump
                            813 ;	Peephole 108.c	removed ljmp by inverse jump logic
   ADB9 60 43               814 	jz	00106$
                            815 ;	Peephole 300	removed redundant label 00181$
                            816 ;	../../Common/modules/cIPv6.c:140: if(ptr->message.ip_control.message.address_setup.use_short_address==0) cipv6_pib.use_short_address=0;
                            817 ;	genIpush
                            818 ;	genPlus
                            819 ;     genPlusIncr
   ADBB 74 01               820 	mov	a,#0x01
                            821 ;	Peephole 236.a	used r5 instead of ar5
   ADBD 2D                  822 	add	a,r5
   ADBE FA                  823 	mov	r2,a
                            824 ;	Peephole 181	changed mov to clr
   ADBF E4                  825 	clr	a
                            826 ;	Peephole 236.b	used r6 instead of ar6
   ADC0 3E                  827 	addc	a,r6
   ADC1 FB                  828 	mov	r3,a
   ADC2 8F 04               829 	mov	ar4,r7
                            830 ;	genPlus
                            831 ;     genPlusIncr
   ADC4 74 08               832 	mov	a,#0x08
                            833 ;	Peephole 236.a	used r2 instead of ar2
   ADC6 2A                  834 	add	a,r2
   ADC7 FA                  835 	mov	r2,a
                            836 ;	Peephole 181	changed mov to clr
   ADC8 E4                  837 	clr	a
                            838 ;	Peephole 236.b	used r3 instead of ar3
   ADC9 3B                  839 	addc	a,r3
   ADCA FB                  840 	mov	r3,a
                            841 ;	genPointerGet
                            842 ;	genGenPointerGet
   ADCB 8A 82               843 	mov	dpl,r2
   ADCD 8B 83               844 	mov	dph,r3
   ADCF 8C F0               845 	mov	b,r4
   ADD1 12 E4 9F            846 	lcall	__gptrget
                            847 ;	genIpop
                            848 ;	genIfx
                            849 ;	genIfxJump
                            850 ;	Peephole 108.b	removed ljmp by inverse jump logic
   ADD4 70 05               851 	jnz	00104$
                            852 ;	Peephole 300	removed redundant label 00182$
                            853 ;	genPointerSet
                            854 ;     genFarPointerSet
   ADD6 90 F0 59            855 	mov	dptr,#(_cipv6_pib + 0x000c)
                            856 ;	Peephole 181	changed mov to clr
   ADD9 E4                  857 	clr	a
   ADDA F0                  858 	movx	@dptr,a
   ADDB                     859 00104$:
                            860 ;	../../Common/modules/cIPv6.c:141: stack_buffer_free(buf);
                            861 ;	genCall
   ADDB A8 10               862 	mov	r0,_bp
   ADDD 08                  863 	inc	r0
   ADDE 86 82               864 	mov	dpl,@r0
   ADE0 08                  865 	inc	r0
   ADE1 86 83               866 	mov	dph,@r0
   ADE3 08                  867 	inc	r0
   ADE4 86 F0               868 	mov	b,@r0
   ADE6 C0 05               869 	push	ar5
   ADE8 C0 06               870 	push	ar6
   ADEA C0 07               871 	push	ar7
   ADEC 12 61 FA            872 	lcall	_stack_buffer_free
   ADEF D0 07               873 	pop	ar7
   ADF1 D0 06               874 	pop	ar6
   ADF3 D0 05               875 	pop	ar5
                            876 ;	../../Common/modules/cIPv6.c:142: buf=0;
                            877 ;	genAssign
   ADF5 A8 10               878 	mov	r0,_bp
   ADF7 08                  879 	inc	r0
   ADF8 E4                  880 	clr	a
   ADF9 F6                  881 	mov	@r0,a
   ADFA 08                  882 	inc	r0
   ADFB F6                  883 	mov	@r0,a
   ADFC 08                  884 	inc	r0
   ADFD F6                  885 	mov	@r0,a
   ADFE                     886 00106$:
                            887 ;	../../Common/modules/cIPv6.c:144: if(cipv6_pib.use_short_address==0 && buf)
                            888 ;	genPointerGet
                            889 ;	genFarPointerGet
   ADFE 90 F0 59            890 	mov	dptr,#(_cipv6_pib + 0x000c)
   AE01 E0                  891 	movx	a,@dptr
                            892 ;	genIfxJump
   AE02 60 03               893 	jz	00183$
   AE04 02 AE EB            894 	ljmp	00115$
   AE07                     895 00183$:
                            896 ;	genIfx
   AE07 A8 10               897 	mov	r0,_bp
   AE09 08                  898 	inc	r0
   AE0A E6                  899 	mov	a,@r0
   AE0B 08                  900 	inc	r0
   AE0C 46                  901 	orl	a,@r0
   AE0D 08                  902 	inc	r0
   AE0E 46                  903 	orl	a,@r0
                            904 ;	genIfxJump
   AE0F 70 03               905 	jnz	00184$
   AE11 02 AE EB            906 	ljmp	00115$
   AE14                     907 00184$:
                            908 ;	../../Common/modules/cIPv6.c:146: if(ptr->message.ip_control.message.address_setup.use_short_address)
                            909 ;	genIpush
                            910 ;	genPlus
                            911 ;     genPlusIncr
   AE14 0D                  912 	inc	r5
   AE15 BD 00 01            913 	cjne	r5,#0x00,00185$
   AE18 0E                  914 	inc	r6
   AE19                     915 00185$:
                            916 ;	genPlus
                            917 ;     genPlusIncr
   AE19 74 08               918 	mov	a,#0x08
                            919 ;	Peephole 236.a	used r5 instead of ar5
   AE1B 2D                  920 	add	a,r5
   AE1C FA                  921 	mov	r2,a
                            922 ;	Peephole 181	changed mov to clr
   AE1D E4                  923 	clr	a
                            924 ;	Peephole 236.b	used r6 instead of ar6
   AE1E 3E                  925 	addc	a,r6
   AE1F FB                  926 	mov	r3,a
   AE20 8F 04               927 	mov	ar4,r7
                            928 ;	genPointerGet
                            929 ;	genGenPointerGet
   AE22 8A 82               930 	mov	dpl,r2
   AE24 8B 83               931 	mov	dph,r3
   AE26 8C F0               932 	mov	b,r4
   AE28 12 E4 9F            933 	lcall	__gptrget
                            934 ;	genIpop
                            935 ;	genIfx
                            936 ;	genIfxJump
                            937 ;	Peephole 108.c	removed ljmp by inverse jump logic
   AE2B 60 58               938 	jz	00161$
                            939 ;	Peephole 300	removed redundant label 00186$
                            940 ;	../../Common/modules/cIPv6.c:148: cipv6_pib.use_short_address=1;
                            941 ;	genPointerSet
                            942 ;     genFarPointerSet
   AE2D 90 F0 59            943 	mov	dptr,#(_cipv6_pib + 0x000c)
   AE30 74 01               944 	mov	a,#0x01
   AE32 F0                  945 	movx	@dptr,a
                            946 ;	../../Common/modules/cIPv6.c:149: for(i=0; i<2;i++)
                            947 ;	genAssign
   AE33 E5 10               948 	mov	a,_bp
   AE35 24 04               949 	add	a,#0x04
   AE37 F8                  950 	mov	r0,a
   AE38 76 00               951 	mov	@r0,#0x00
   AE3A                     952 00138$:
                            953 ;	genCmpLt
   AE3A E5 10               954 	mov	a,_bp
   AE3C 24 04               955 	add	a,#0x04
   AE3E F8                  956 	mov	r0,a
                            957 ;	genCmp
   AE3F B6 02 00            958 	cjne	@r0,#0x02,00187$
   AE42                     959 00187$:
                            960 ;	genIfxJump
   AE42 40 03               961 	jc	00188$
   AE44 02 AE D4            962 	ljmp	00110$
   AE47                     963 00188$:
                            964 ;	../../Common/modules/cIPv6.c:151: cipv6_pib.short_address[i] = ptr->message.ip_control.message.address_setup.address[i];
                            965 ;	genPlus
   AE47 E5 10               966 	mov	a,_bp
   AE49 24 04               967 	add	a,#0x04
   AE4B F8                  968 	mov	r0,a
   AE4C E5 10               969 	mov	a,_bp
   AE4E 24 05               970 	add	a,#0x05
   AE50 F9                  971 	mov	r1,a
   AE51 E6                  972 	mov	a,@r0
   AE52 24 57               973 	add	a,#(_cipv6_pib + 0x000a)
   AE54 F7                  974 	mov	@r1,a
                            975 ;	Peephole 181	changed mov to clr
   AE55 E4                  976 	clr	a
   AE56 34 F0               977 	addc	a,#((_cipv6_pib + 0x000a) >> 8)
   AE58 09                  978 	inc	r1
   AE59 F7                  979 	mov	@r1,a
                            980 ;	genPlus
   AE5A E5 10               981 	mov	a,_bp
   AE5C 24 04               982 	add	a,#0x04
   AE5E F8                  983 	mov	r0,a
   AE5F E6                  984 	mov	a,@r0
                            985 ;	Peephole 236.a	used r5 instead of ar5
   AE60 2D                  986 	add	a,r5
   AE61 FA                  987 	mov	r2,a
                            988 ;	Peephole 181	changed mov to clr
   AE62 E4                  989 	clr	a
                            990 ;	Peephole 236.b	used r6 instead of ar6
   AE63 3E                  991 	addc	a,r6
   AE64 FB                  992 	mov	r3,a
   AE65 8F 04               993 	mov	ar4,r7
                            994 ;	genPointerGet
                            995 ;	genGenPointerGet
   AE67 8A 82               996 	mov	dpl,r2
   AE69 8B 83               997 	mov	dph,r3
   AE6B 8C F0               998 	mov	b,r4
   AE6D 12 E4 9F            999 	lcall	__gptrget
   AE70 FA                 1000 	mov	r2,a
                           1001 ;	genPointerSet
                           1002 ;     genFarPointerSet
   AE71 E5 10              1003 	mov	a,_bp
   AE73 24 05              1004 	add	a,#0x05
   AE75 F8                 1005 	mov	r0,a
   AE76 86 82              1006 	mov	dpl,@r0
   AE78 08                 1007 	inc	r0
   AE79 86 83              1008 	mov	dph,@r0
   AE7B EA                 1009 	mov	a,r2
   AE7C F0                 1010 	movx	@dptr,a
                           1011 ;	../../Common/modules/cIPv6.c:149: for(i=0; i<2;i++)
                           1012 ;	genPlus
   AE7D E5 10              1013 	mov	a,_bp
   AE7F 24 04              1014 	add	a,#0x04
   AE81 F8                 1015 	mov	r0,a
                           1016 ;     genPlusIncr
   AE82 06                 1017 	inc	@r0
                           1018 ;	../../Common/modules/cIPv6.c:156: for(i=0; i<8;i++)
                           1019 ;	Peephole 112.b	changed ljmp to sjmp
   AE83 80 B5              1020 	sjmp	00138$
   AE85                    1021 00161$:
                           1022 ;	genAssign
   AE85 E5 10              1023 	mov	a,_bp
   AE87 24 04              1024 	add	a,#0x04
   AE89 F8                 1025 	mov	r0,a
   AE8A 76 00              1026 	mov	@r0,#0x00
   AE8C                    1027 00142$:
                           1028 ;	genCmpLt
   AE8C E5 10              1029 	mov	a,_bp
   AE8E 24 04              1030 	add	a,#0x04
   AE90 F8                 1031 	mov	r0,a
                           1032 ;	genCmp
   AE91 B6 08 00           1033 	cjne	@r0,#0x08,00189$
   AE94                    1034 00189$:
                           1035 ;	genIfxJump
                           1036 ;	Peephole 108.a	removed ljmp by inverse jump logic
   AE94 50 3E              1037 	jnc	00110$
                           1038 ;	Peephole 300	removed redundant label 00190$
                           1039 ;	../../Common/modules/cIPv6.c:158: cipv6_pib.long_address[i] = ptr->message.ip_control.message.address_setup.address[i] ;
                           1040 ;	genPlus
   AE96 E5 10              1041 	mov	a,_bp
   AE98 24 04              1042 	add	a,#0x04
   AE9A F8                 1043 	mov	r0,a
   AE9B E5 10              1044 	mov	a,_bp
   AE9D 24 05              1045 	add	a,#0x05
   AE9F F9                 1046 	mov	r1,a
   AEA0 E6                 1047 	mov	a,@r0
   AEA1 24 4F              1048 	add	a,#(_cipv6_pib + 0x0002)
   AEA3 F7                 1049 	mov	@r1,a
                           1050 ;	Peephole 181	changed mov to clr
   AEA4 E4                 1051 	clr	a
   AEA5 34 F0              1052 	addc	a,#((_cipv6_pib + 0x0002) >> 8)
   AEA7 09                 1053 	inc	r1
   AEA8 F7                 1054 	mov	@r1,a
                           1055 ;	genPlus
   AEA9 E5 10              1056 	mov	a,_bp
   AEAB 24 04              1057 	add	a,#0x04
   AEAD F8                 1058 	mov	r0,a
   AEAE E6                 1059 	mov	a,@r0
                           1060 ;	Peephole 236.a	used r5 instead of ar5
   AEAF 2D                 1061 	add	a,r5
   AEB0 FA                 1062 	mov	r2,a
                           1063 ;	Peephole 181	changed mov to clr
   AEB1 E4                 1064 	clr	a
                           1065 ;	Peephole 236.b	used r6 instead of ar6
   AEB2 3E                 1066 	addc	a,r6
   AEB3 FB                 1067 	mov	r3,a
   AEB4 8F 04              1068 	mov	ar4,r7
                           1069 ;	genPointerGet
                           1070 ;	genGenPointerGet
   AEB6 8A 82              1071 	mov	dpl,r2
   AEB8 8B 83              1072 	mov	dph,r3
   AEBA 8C F0              1073 	mov	b,r4
   AEBC 12 E4 9F           1074 	lcall	__gptrget
   AEBF FA                 1075 	mov	r2,a
                           1076 ;	genPointerSet
                           1077 ;     genFarPointerSet
   AEC0 E5 10              1078 	mov	a,_bp
   AEC2 24 05              1079 	add	a,#0x05
   AEC4 F8                 1080 	mov	r0,a
   AEC5 86 82              1081 	mov	dpl,@r0
   AEC7 08                 1082 	inc	r0
   AEC8 86 83              1083 	mov	dph,@r0
   AECA EA                 1084 	mov	a,r2
   AECB F0                 1085 	movx	@dptr,a
                           1086 ;	../../Common/modules/cIPv6.c:156: for(i=0; i<8;i++)
                           1087 ;	genPlus
   AECC E5 10              1088 	mov	a,_bp
   AECE 24 04              1089 	add	a,#0x04
   AED0 F8                 1090 	mov	r0,a
                           1091 ;     genPlusIncr
   AED1 06                 1092 	inc	@r0
                           1093 ;	Peephole 112.b	changed ljmp to sjmp
   AED2 80 B8              1094 	sjmp	00142$
   AED4                    1095 00110$:
                           1096 ;	../../Common/modules/cIPv6.c:161: stack_buffer_free(buf);
                           1097 ;	genCall
   AED4 A8 10              1098 	mov	r0,_bp
   AED6 08                 1099 	inc	r0
   AED7 86 82              1100 	mov	dpl,@r0
   AED9 08                 1101 	inc	r0
   AEDA 86 83              1102 	mov	dph,@r0
   AEDC 08                 1103 	inc	r0
   AEDD 86 F0              1104 	mov	b,@r0
   AEDF 12 61 FA           1105 	lcall	_stack_buffer_free
                           1106 ;	../../Common/modules/cIPv6.c:162: buf=0;
                           1107 ;	genAssign
   AEE2 A8 10              1108 	mov	r0,_bp
   AEE4 08                 1109 	inc	r0
   AEE5 E4                 1110 	clr	a
   AEE6 F6                 1111 	mov	@r0,a
   AEE7 08                 1112 	inc	r0
   AEE8 F6                 1113 	mov	@r0,a
   AEE9 08                 1114 	inc	r0
   AEEA F6                 1115 	mov	@r0,a
   AEEB                    1116 00115$:
                           1117 ;	../../Common/modules/cIPv6.c:165: if(buf)
                           1118 ;	genIfx
   AEEB A8 10              1119 	mov	r0,_bp
   AEED 08                 1120 	inc	r0
   AEEE E6                 1121 	mov	a,@r0
   AEEF 08                 1122 	inc	r0
   AEF0 46                 1123 	orl	a,@r0
   AEF1 08                 1124 	inc	r0
   AEF2 46                 1125 	orl	a,@r0
                           1126 ;	genIfxJump
                           1127 ;	Peephole 108.c	removed ljmp by inverse jump logic
   AEF3 60 0E              1128 	jz	00117$
                           1129 ;	Peephole 300	removed redundant label 00191$
                           1130 ;	../../Common/modules/cIPv6.c:167: stack_buffer_free(buf);
                           1131 ;	genCall
   AEF5 A8 10              1132 	mov	r0,_bp
   AEF7 08                 1133 	inc	r0
   AEF8 86 82              1134 	mov	dpl,@r0
   AEFA 08                 1135 	inc	r0
   AEFB 86 83              1136 	mov	dph,@r0
   AEFD 08                 1137 	inc	r0
   AEFE 86 F0              1138 	mov	b,@r0
   AF00 12 61 FA           1139 	lcall	_stack_buffer_free
                           1140 ;	../../Common/modules/cIPv6.c:168: buf=0;
   AF03                    1141 00117$:
                           1142 ;	../../Common/modules/cIPv6.c:170: return pdTRUE;
                           1143 ;	genRet
   AF03 75 82 01           1144 	mov	dpl,#0x01
   AF06 02 B0 44           1145 	ljmp	00146$
   AF09                    1146 00119$:
                           1147 ;	../../Common/modules/cIPv6.c:173: switch(buf->dir)
                           1148 ;	genPlus
   AF09 A8 10              1149 	mov	r0,_bp
   AF0B 08                 1150 	inc	r0
                           1151 ;     genPlusIncr
   AF0C 74 1F              1152 	mov	a,#0x1F
   AF0E 26                 1153 	add	a,@r0
   AF0F FA                 1154 	mov	r2,a
                           1155 ;	Peephole 181	changed mov to clr
   AF10 E4                 1156 	clr	a
   AF11 08                 1157 	inc	r0
   AF12 36                 1158 	addc	a,@r0
   AF13 FB                 1159 	mov	r3,a
   AF14 08                 1160 	inc	r0
   AF15 86 04              1161 	mov	ar4,@r0
                           1162 ;	genPointerGet
                           1163 ;	genGenPointerGet
   AF17 8A 82              1164 	mov	dpl,r2
   AF19 8B 83              1165 	mov	dph,r3
   AF1B 8C F0              1166 	mov	b,r4
   AF1D 12 E4 9F           1167 	lcall	__gptrget
                           1168 ;	genCmpEq
                           1169 ;	gencjneshort
                           1170 ;	Peephole 112.b	changed ljmp to sjmp
   AF20 FA                 1171 	mov	r2,a
                           1172 ;	Peephole 115.b	jump optimization
   AF21 60 30              1173 	jz	00125$
                           1174 ;	Peephole 300	removed redundant label 00192$
                           1175 ;	genCmpEq
                           1176 ;	gencjneshort
   AF23 BA 01 02           1177 	cjne	r2,#0x01,00193$
   AF26 80 03              1178 	sjmp	00194$
   AF28                    1179 00193$:
   AF28 02 B0 41           1180 	ljmp	00137$
   AF2B                    1181 00194$:
                           1182 ;	../../Common/modules/cIPv6.c:176: if(cipv6_pib.use_full_compress)
                           1183 ;	genPointerGet
                           1184 ;	genFarPointerGet
   AF2B 90 F0 5A           1185 	mov	dptr,#(_cipv6_pib + 0x000d)
   AF2E E0                 1186 	movx	a,@dptr
                           1187 ;	genIfxJump
                           1188 ;	Peephole 108.c	removed ljmp by inverse jump logic
   AF2F 60 11              1189 	jz	00123$
                           1190 ;	Peephole 300	removed redundant label 00195$
                           1191 ;	../../Common/modules/cIPv6.c:178: build_lowpan_header(buf);
                           1192 ;	genCall
   AF31 A8 10              1193 	mov	r0,_bp
   AF33 08                 1194 	inc	r0
   AF34 86 82              1195 	mov	dpl,@r0
   AF36 08                 1196 	inc	r0
   AF37 86 83              1197 	mov	dph,@r0
   AF39 08                 1198 	inc	r0
   AF3A 86 F0              1199 	mov	b,@r0
   AF3C 12 BB 92           1200 	lcall	_build_lowpan_header
   AF3F 02 B0 41           1201 	ljmp	00137$
   AF42                    1202 00123$:
                           1203 ;	../../Common/modules/cIPv6.c:182: build_ipv6_header(buf);
                           1204 ;	genCall
   AF42 A8 10              1205 	mov	r0,_bp
   AF44 08                 1206 	inc	r0
   AF45 86 82              1207 	mov	dpl,@r0
   AF47 08                 1208 	inc	r0
   AF48 86 83              1209 	mov	dph,@r0
   AF4A 08                 1210 	inc	r0
   AF4B 86 F0              1211 	mov	b,@r0
   AF4D 12 C4 28           1212 	lcall	_build_ipv6_header
                           1213 ;	../../Common/modules/cIPv6.c:184: break;
   AF50 02 B0 41           1214 	ljmp	00137$
                           1215 ;	../../Common/modules/cIPv6.c:186: case BUFFER_UP:			/* From Lower layer(usually RF802.15.4) */
   AF53                    1216 00125$:
                           1217 ;	../../Common/modules/cIPv6.c:189: if(buf->options.handle_type == HANDLE_BROKEN_LINK)
                           1218 ;	genPlus
   AF53 A8 10              1219 	mov	r0,_bp
   AF55 08                 1220 	inc	r0
                           1221 ;     genPlusIncr
   AF56 74 26              1222 	mov	a,#0x26
   AF58 26                 1223 	add	a,@r0
   AF59 FA                 1224 	mov	r2,a
                           1225 ;	Peephole 181	changed mov to clr
   AF5A E4                 1226 	clr	a
   AF5B 08                 1227 	inc	r0
   AF5C 36                 1228 	addc	a,@r0
   AF5D FB                 1229 	mov	r3,a
   AF5E 08                 1230 	inc	r0
   AF5F 86 04              1231 	mov	ar4,@r0
                           1232 ;	genPlus
                           1233 ;     genPlusIncr
   AF61 74 03              1234 	mov	a,#0x03
                           1235 ;	Peephole 236.a	used r2 instead of ar2
   AF63 2A                 1236 	add	a,r2
   AF64 FA                 1237 	mov	r2,a
                           1238 ;	Peephole 181	changed mov to clr
   AF65 E4                 1239 	clr	a
                           1240 ;	Peephole 236.b	used r3 instead of ar3
   AF66 3B                 1241 	addc	a,r3
   AF67 FB                 1242 	mov	r3,a
                           1243 ;	genPointerGet
                           1244 ;	genGenPointerGet
   AF68 8A 82              1245 	mov	dpl,r2
   AF6A 8B 83              1246 	mov	dph,r3
   AF6C 8C F0              1247 	mov	b,r4
   AF6E 12 E4 9F           1248 	lcall	__gptrget
   AF71 FA                 1249 	mov	r2,a
                           1250 ;	genCmpEq
                           1251 ;	gencjneshort
                           1252 ;	Peephole 112.b	changed ljmp to sjmp
                           1253 ;	Peephole 198.b	optimized misc jump sequence
   AF72 BA 04 17           1254 	cjne	r2,#0x04,00127$
                           1255 ;	Peephole 200.b	removed redundant sjmp
                           1256 ;	Peephole 300	removed redundant label 00196$
                           1257 ;	Peephole 300	removed redundant label 00197$
                           1258 ;	../../Common/modules/cIPv6.c:195: stack_buffer_free(buf);
                           1259 ;	genCall
   AF75 A8 10              1260 	mov	r0,_bp
   AF77 08                 1261 	inc	r0
   AF78 86 82              1262 	mov	dpl,@r0
   AF7A 08                 1263 	inc	r0
   AF7B 86 83              1264 	mov	dph,@r0
   AF7D 08                 1265 	inc	r0
   AF7E 86 F0              1266 	mov	b,@r0
   AF80 12 61 FA           1267 	lcall	_stack_buffer_free
                           1268 ;	../../Common/modules/cIPv6.c:196: buf=0;
                           1269 ;	genAssign
   AF83 A8 10              1270 	mov	r0,_bp
   AF85 08                 1271 	inc	r0
   AF86 E4                 1272 	clr	a
   AF87 F6                 1273 	mov	@r0,a
   AF88 08                 1274 	inc	r0
   AF89 F6                 1275 	mov	@r0,a
   AF8A 08                 1276 	inc	r0
   AF8B F6                 1277 	mov	@r0,a
   AF8C                    1278 00127$:
                           1279 ;	../../Common/modules/cIPv6.c:200: if(buf)
                           1280 ;	genIfx
   AF8C A8 10              1281 	mov	r0,_bp
   AF8E 08                 1282 	inc	r0
   AF8F E6                 1283 	mov	a,@r0
   AF90 08                 1284 	inc	r0
   AF91 46                 1285 	orl	a,@r0
   AF92 08                 1286 	inc	r0
   AF93 46                 1287 	orl	a,@r0
                           1288 ;	genIfxJump
   AF94 70 03              1289 	jnz	00198$
   AF96 02 B0 41           1290 	ljmp	00137$
   AF99                    1291 00198$:
                           1292 ;	../../Common/modules/cIPv6.c:202: if(buf->buf[buf->buf_ptr] == IPV6)
                           1293 ;	genPlus
   AF99 A8 10              1294 	mov	r0,_bp
   AF9B 08                 1295 	inc	r0
                           1296 ;     genPlusIncr
   AF9C 74 2C              1297 	mov	a,#0x2C
   AF9E 26                 1298 	add	a,@r0
   AF9F FA                 1299 	mov	r2,a
                           1300 ;	Peephole 181	changed mov to clr
   AFA0 E4                 1301 	clr	a
   AFA1 08                 1302 	inc	r0
   AFA2 36                 1303 	addc	a,@r0
   AFA3 FB                 1304 	mov	r3,a
   AFA4 08                 1305 	inc	r0
   AFA5 86 04              1306 	mov	ar4,@r0
                           1307 ;	genPlus
   AFA7 A8 10              1308 	mov	r0,_bp
   AFA9 08                 1309 	inc	r0
                           1310 ;     genPlusIncr
   AFAA 74 20              1311 	mov	a,#0x20
   AFAC 26                 1312 	add	a,@r0
   AFAD FD                 1313 	mov	r5,a
                           1314 ;	Peephole 181	changed mov to clr
   AFAE E4                 1315 	clr	a
   AFAF 08                 1316 	inc	r0
   AFB0 36                 1317 	addc	a,@r0
   AFB1 FE                 1318 	mov	r6,a
   AFB2 08                 1319 	inc	r0
   AFB3 86 07              1320 	mov	ar7,@r0
                           1321 ;	genPointerGet
                           1322 ;	genGenPointerGet
   AFB5 8D 82              1323 	mov	dpl,r5
   AFB7 8E 83              1324 	mov	dph,r6
   AFB9 8F F0              1325 	mov	b,r7
   AFBB 12 E4 9F           1326 	lcall	__gptrget
   AFBE FD                 1327 	mov	r5,a
   AFBF A3                 1328 	inc	dptr
   AFC0 12 E4 9F           1329 	lcall	__gptrget
   AFC3 FE                 1330 	mov	r6,a
                           1331 ;	genPlus
                           1332 ;	Peephole 236.g	used r5 instead of ar5
   AFC4 ED                 1333 	mov	a,r5
                           1334 ;	Peephole 236.a	used r2 instead of ar2
   AFC5 2A                 1335 	add	a,r2
   AFC6 FA                 1336 	mov	r2,a
                           1337 ;	Peephole 236.g	used r6 instead of ar6
   AFC7 EE                 1338 	mov	a,r6
                           1339 ;	Peephole 236.b	used r3 instead of ar3
   AFC8 3B                 1340 	addc	a,r3
   AFC9 FB                 1341 	mov	r3,a
                           1342 ;	genPointerGet
                           1343 ;	genGenPointerGet
   AFCA 8A 82              1344 	mov	dpl,r2
   AFCC 8B 83              1345 	mov	dph,r3
   AFCE 8C F0              1346 	mov	b,r4
   AFD0 12 E4 9F           1347 	lcall	__gptrget
   AFD3 FA                 1348 	mov	r2,a
                           1349 ;	genCmpEq
                           1350 ;	gencjneshort
                           1351 ;	Peephole 112.b	changed ljmp to sjmp
                           1352 ;	Peephole 198.b	optimized misc jump sequence
   AFD4 BA 82 10           1353 	cjne	r2,#0x82,00133$
                           1354 ;	Peephole 200.b	removed redundant sjmp
                           1355 ;	Peephole 300	removed redundant label 00199$
                           1356 ;	Peephole 300	removed redundant label 00200$
                           1357 ;	../../Common/modules/cIPv6.c:204: parse_ipv_header(buf);
                           1358 ;	genCall
   AFD7 A8 10              1359 	mov	r0,_bp
   AFD9 08                 1360 	inc	r0
   AFDA 86 82              1361 	mov	dpl,@r0
   AFDC 08                 1362 	inc	r0
   AFDD 86 83              1363 	mov	dph,@r0
   AFDF 08                 1364 	inc	r0
   AFE0 86 F0              1365 	mov	b,@r0
   AFE2 12 CA 22           1366 	lcall	_parse_ipv_header
                           1367 ;	../../Common/modules/cIPv6.c:205: buf=0;
                           1368 ;	Peephole 112.b	changed ljmp to sjmp
   AFE5 80 5A              1369 	sjmp	00137$
   AFE7                    1370 00133$:
                           1371 ;	../../Common/modules/cIPv6.c:209: switch (buf->buf[buf->buf_ptr] & LOWPAN_TYPE_BM )
                           1372 ;	genPlus
   AFE7 A8 10              1373 	mov	r0,_bp
   AFE9 08                 1374 	inc	r0
                           1375 ;     genPlusIncr
   AFEA 74 2C              1376 	mov	a,#0x2C
   AFEC 26                 1377 	add	a,@r0
   AFED FA                 1378 	mov	r2,a
                           1379 ;	Peephole 181	changed mov to clr
   AFEE E4                 1380 	clr	a
   AFEF 08                 1381 	inc	r0
   AFF0 36                 1382 	addc	a,@r0
   AFF1 FB                 1383 	mov	r3,a
   AFF2 08                 1384 	inc	r0
   AFF3 86 04              1385 	mov	ar4,@r0
                           1386 ;	genPlus
                           1387 ;	Peephole 236.g	used r5 instead of ar5
   AFF5 ED                 1388 	mov	a,r5
                           1389 ;	Peephole 236.a	used r2 instead of ar2
   AFF6 2A                 1390 	add	a,r2
   AFF7 FD                 1391 	mov	r5,a
                           1392 ;	Peephole 236.g	used r6 instead of ar6
   AFF8 EE                 1393 	mov	a,r6
                           1394 ;	Peephole 236.b	used r3 instead of ar3
   AFF9 3B                 1395 	addc	a,r3
   AFFA FE                 1396 	mov	r6,a
   AFFB 8C 07              1397 	mov	ar7,r4
                           1398 ;	genPointerGet
                           1399 ;	genGenPointerGet
   AFFD 8D 82              1400 	mov	dpl,r5
   AFFF 8E 83              1401 	mov	dph,r6
   B001 8F F0              1402 	mov	b,r7
   B003 12 E4 9F           1403 	lcall	__gptrget
   B006 FD                 1404 	mov	r5,a
                           1405 ;	genAnd
   B007 74 03              1406 	mov	a,#0x03
   B009 5D                 1407 	anl	a,r5
   B00A FA                 1408 	mov	r2,a
                           1409 ;	genCmpEq
                           1410 ;	gencjneshort
   B00B BA 01 02           1411 	cjne	r2,#0x01,00201$
                           1412 ;	Peephole 112.b	changed ljmp to sjmp
   B00E 80 13              1413 	sjmp	00129$
   B010                    1414 00201$:
                           1415 ;	genCmpEq
                           1416 ;	gencjneshort
                           1417 ;	Peephole 112.b	changed ljmp to sjmp
                           1418 ;	Peephole 198.b	optimized misc jump sequence
   B010 BA 02 20           1419 	cjne	r2,#0x02,00130$
                           1420 ;	Peephole 200.b	removed redundant sjmp
                           1421 ;	Peephole 300	removed redundant label 00202$
                           1422 ;	Peephole 300	removed redundant label 00203$
                           1423 ;	../../Common/modules/cIPv6.c:215: parse_hc1_message(buf);
                           1424 ;	genCall
   B013 A8 10              1425 	mov	r0,_bp
   B015 08                 1426 	inc	r0
   B016 86 82              1427 	mov	dpl,@r0
   B018 08                 1428 	inc	r0
   B019 86 83              1429 	mov	dph,@r0
   B01B 08                 1430 	inc	r0
   B01C 86 F0              1431 	mov	b,@r0
   B01E 12 B0 D4           1432 	lcall	_parse_hc1_message
                           1433 ;	../../Common/modules/cIPv6.c:216: break;	
                           1434 ;	../../Common/modules/cIPv6.c:219: case MESH_ROUTING_TYPE: /* Mesh Routing */
                           1435 ;	Peephole 112.b	changed ljmp to sjmp
   B021 80 1E              1436 	sjmp	00137$
   B023                    1437 00129$:
                           1438 ;	../../Common/modules/cIPv6.c:221: parse_mesh_packet(buf);
                           1439 ;	genCall
   B023 A8 10              1440 	mov	r0,_bp
   B025 08                 1441 	inc	r0
   B026 86 82              1442 	mov	dpl,@r0
   B028 08                 1443 	inc	r0
   B029 86 83              1444 	mov	dph,@r0
   B02B 08                 1445 	inc	r0
   B02C 86 F0              1446 	mov	b,@r0
   B02E 12 B3 66           1447 	lcall	_parse_mesh_packet
                           1448 ;	../../Common/modules/cIPv6.c:222: break;	/* END_OF_MESH_ROUTING_TYPE */
                           1449 ;	../../Common/modules/cIPv6.c:224: default:
                           1450 ;	Peephole 112.b	changed ljmp to sjmp
   B031 80 0E              1451 	sjmp	00137$
   B033                    1452 00130$:
                           1453 ;	../../Common/modules/cIPv6.c:225: stack_buffer_free(buf);
                           1454 ;	genCall
   B033 A8 10              1455 	mov	r0,_bp
   B035 08                 1456 	inc	r0
   B036 86 82              1457 	mov	dpl,@r0
   B038 08                 1458 	inc	r0
   B039 86 83              1459 	mov	dph,@r0
   B03B 08                 1460 	inc	r0
   B03C 86 F0              1461 	mov	b,@r0
   B03E 12 61 FA           1462 	lcall	_stack_buffer_free
                           1463 ;	../../Common/modules/cIPv6.c:232: }
   B041                    1464 00137$:
                           1465 ;	../../Common/modules/cIPv6.c:233: return pdTRUE;
                           1466 ;	genRet
   B041 75 82 01           1467 	mov	dpl,#0x01
   B044                    1468 00146$:
   B044 85 10 81           1469 	mov	sp,_bp
   B047 D0 10              1470 	pop	_bp
   B049 22                 1471 	ret
                           1472 ;------------------------------------------------------------
                           1473 ;Allocation info for local variables in function 'cipv6_check'
                           1474 ;------------------------------------------------------------
                           1475 ;buf                       Allocated to stack - offset 1
                           1476 ;temp                      Allocated to registers r2 
                           1477 ;------------------------------------------------------------
                           1478 ;	../../Common/modules/cIPv6.c:244: portCHAR cipv6_check( buffer_t *buf )
                           1479 ;	-----------------------------------------
                           1480 ;	 function cipv6_check
                           1481 ;	-----------------------------------------
   B04A                    1482 _cipv6_check:
   B04A C0 10              1483 	push	_bp
   B04C 85 81 10           1484 	mov	_bp,sp
                           1485 ;     genReceive
   B04F C0 82              1486 	push	dpl
   B051 C0 83              1487 	push	dph
   B053 C0 F0              1488 	push	b
                           1489 ;	../../Common/modules/cIPv6.c:248: if(buf->buf[buf->buf_ptr] == IPV6)
                           1490 ;	genPlus
   B055 A8 10              1491 	mov	r0,_bp
   B057 08                 1492 	inc	r0
                           1493 ;     genPlusIncr
   B058 74 2C              1494 	mov	a,#0x2C
   B05A 26                 1495 	add	a,@r0
   B05B FD                 1496 	mov	r5,a
                           1497 ;	Peephole 181	changed mov to clr
   B05C E4                 1498 	clr	a
   B05D 08                 1499 	inc	r0
   B05E 36                 1500 	addc	a,@r0
   B05F FE                 1501 	mov	r6,a
   B060 08                 1502 	inc	r0
   B061 86 07              1503 	mov	ar7,@r0
                           1504 ;	genPlus
   B063 A8 10              1505 	mov	r0,_bp
   B065 08                 1506 	inc	r0
                           1507 ;     genPlusIncr
   B066 74 20              1508 	mov	a,#0x20
   B068 26                 1509 	add	a,@r0
   B069 FA                 1510 	mov	r2,a
                           1511 ;	Peephole 181	changed mov to clr
   B06A E4                 1512 	clr	a
   B06B 08                 1513 	inc	r0
   B06C 36                 1514 	addc	a,@r0
   B06D FB                 1515 	mov	r3,a
   B06E 08                 1516 	inc	r0
   B06F 86 04              1517 	mov	ar4,@r0
                           1518 ;	genPointerGet
                           1519 ;	genGenPointerGet
   B071 8A 82              1520 	mov	dpl,r2
   B073 8B 83              1521 	mov	dph,r3
   B075 8C F0              1522 	mov	b,r4
   B077 12 E4 9F           1523 	lcall	__gptrget
   B07A FA                 1524 	mov	r2,a
   B07B A3                 1525 	inc	dptr
   B07C 12 E4 9F           1526 	lcall	__gptrget
   B07F FB                 1527 	mov	r3,a
                           1528 ;	genPlus
                           1529 ;	Peephole 236.g	used r2 instead of ar2
   B080 EA                 1530 	mov	a,r2
                           1531 ;	Peephole 236.a	used r5 instead of ar5
   B081 2D                 1532 	add	a,r5
   B082 FD                 1533 	mov	r5,a
                           1534 ;	Peephole 236.g	used r3 instead of ar3
   B083 EB                 1535 	mov	a,r3
                           1536 ;	Peephole 236.b	used r6 instead of ar6
   B084 3E                 1537 	addc	a,r6
   B085 FE                 1538 	mov	r6,a
                           1539 ;	genPointerGet
                           1540 ;	genGenPointerGet
   B086 8D 82              1541 	mov	dpl,r5
   B088 8E 83              1542 	mov	dph,r6
   B08A 8F F0              1543 	mov	b,r7
   B08C 12 E4 9F           1544 	lcall	__gptrget
   B08F FD                 1545 	mov	r5,a
                           1546 ;	genCmpEq
                           1547 ;	gencjneshort
                           1548 ;	Peephole 112.b	changed ljmp to sjmp
                           1549 ;	Peephole 198.b	optimized misc jump sequence
   B090 BD 82 05           1550 	cjne	r5,#0x82,00108$
                           1551 ;	Peephole 200.b	removed redundant sjmp
                           1552 ;	Peephole 300	removed redundant label 00115$
                           1553 ;	Peephole 300	removed redundant label 00116$
                           1554 ;	../../Common/modules/cIPv6.c:251: return pdTRUE; 
                           1555 ;	genRet
   B093 75 82 01           1556 	mov	dpl,#0x01
                           1557 ;	Peephole 112.b	changed ljmp to sjmp
   B096 80 36              1558 	sjmp	00110$
   B098                    1559 00108$:
                           1560 ;	../../Common/modules/cIPv6.c:255: temp = (buf->buf[buf->buf_ptr] & LOWPAN_TYPE_BM);
                           1561 ;	genPlus
   B098 A8 10              1562 	mov	r0,_bp
   B09A 08                 1563 	inc	r0
                           1564 ;     genPlusIncr
   B09B 74 2C              1565 	mov	a,#0x2C
   B09D 26                 1566 	add	a,@r0
   B09E FC                 1567 	mov	r4,a
                           1568 ;	Peephole 181	changed mov to clr
   B09F E4                 1569 	clr	a
   B0A0 08                 1570 	inc	r0
   B0A1 36                 1571 	addc	a,@r0
   B0A2 FD                 1572 	mov	r5,a
   B0A3 08                 1573 	inc	r0
   B0A4 86 06              1574 	mov	ar6,@r0
                           1575 ;	genPlus
                           1576 ;	Peephole 236.g	used r2 instead of ar2
   B0A6 EA                 1577 	mov	a,r2
                           1578 ;	Peephole 236.a	used r4 instead of ar4
   B0A7 2C                 1579 	add	a,r4
   B0A8 FA                 1580 	mov	r2,a
                           1581 ;	Peephole 236.g	used r3 instead of ar3
   B0A9 EB                 1582 	mov	a,r3
                           1583 ;	Peephole 236.b	used r5 instead of ar5
   B0AA 3D                 1584 	addc	a,r5
   B0AB FB                 1585 	mov	r3,a
   B0AC 8E 07              1586 	mov	ar7,r6
                           1587 ;	genPointerGet
                           1588 ;	genGenPointerGet
   B0AE 8A 82              1589 	mov	dpl,r2
   B0B0 8B 83              1590 	mov	dph,r3
   B0B2 8F F0              1591 	mov	b,r7
   B0B4 12 E4 9F           1592 	lcall	__gptrget
   B0B7 FA                 1593 	mov	r2,a
                           1594 ;	genAnd
   B0B8 53 02 03           1595 	anl	ar2,#0x03
                           1596 ;	../../Common/modules/cIPv6.c:256: if(temp == DISPATCH_TYPE)
                           1597 ;	genCmpEq
                           1598 ;	gencjneshort
                           1599 ;	Peephole 112.b	changed ljmp to sjmp
                           1600 ;	Peephole 198.b	optimized misc jump sequence
   B0BB BA 02 05           1601 	cjne	r2,#0x02,00105$
                           1602 ;	Peephole 200.b	removed redundant sjmp
                           1603 ;	Peephole 300	removed redundant label 00117$
                           1604 ;	Peephole 300	removed redundant label 00118$
                           1605 ;	../../Common/modules/cIPv6.c:258: return pdTRUE; 
                           1606 ;	genRet
   B0BE 75 82 01           1607 	mov	dpl,#0x01
                           1608 ;	Peephole 112.b	changed ljmp to sjmp
   B0C1 80 0B              1609 	sjmp	00110$
   B0C3                    1610 00105$:
                           1611 ;	../../Common/modules/cIPv6.c:266: else if(temp == MESH_ROUTING_TYPE)
                           1612 ;	genCmpEq
                           1613 ;	gencjneshort
                           1614 ;	Peephole 112.b	changed ljmp to sjmp
                           1615 ;	Peephole 198.b	optimized misc jump sequence
   B0C3 BA 01 05           1616 	cjne	r2,#0x01,00102$
                           1617 ;	Peephole 200.b	removed redundant sjmp
                           1618 ;	Peephole 300	removed redundant label 00119$
                           1619 ;	Peephole 300	removed redundant label 00120$
                           1620 ;	../../Common/modules/cIPv6.c:268: return pdTRUE; 
                           1621 ;	genRet
   B0C6 75 82 01           1622 	mov	dpl,#0x01
                           1623 ;	Peephole 112.b	changed ljmp to sjmp
   B0C9 80 03              1624 	sjmp	00110$
   B0CB                    1625 00102$:
                           1626 ;	../../Common/modules/cIPv6.c:272: return pdFALSE;
                           1627 ;	genRet
   B0CB 75 82 00           1628 	mov	dpl,#0x00
   B0CE                    1629 00110$:
   B0CE 85 10 81           1630 	mov	sp,_bp
   B0D1 D0 10              1631 	pop	_bp
   B0D3 22                 1632 	ret
                           1633 ;------------------------------------------------------------
                           1634 ;Allocation info for local variables in function 'parse_hc1_message'
                           1635 ;------------------------------------------------------------
                           1636 ;buf                       Allocated to stack - offset 1
                           1637 ;ind                       Allocated to stack - offset 4
                           1638 ;lowpan_dispatch           Allocated to registers r2 
                           1639 ;hc1                       Allocated to registers r2 
                           1640 ;hoplimit                  Allocated to registers r2 
                           1641 ;hc2_field_check           Allocated to stack - offset 5
                           1642 ;sloc0                     Allocated to stack - offset 6
                           1643 ;------------------------------------------------------------
                           1644 ;	../../Common/modules/cIPv6.c:282: void parse_hc1_message(buffer_t *buf)
                           1645 ;	-----------------------------------------
                           1646 ;	 function parse_hc1_message
                           1647 ;	-----------------------------------------
   B0D4                    1648 _parse_hc1_message:
   B0D4 C0 10              1649 	push	_bp
   B0D6 85 81 10           1650 	mov	_bp,sp
                           1651 ;     genReceive
   B0D9 C0 82              1652 	push	dpl
   B0DB C0 83              1653 	push	dph
   B0DD C0 F0              1654 	push	b
   B0DF E5 81              1655 	mov	a,sp
   B0E1 24 08              1656 	add	a,#0x08
   B0E3 F5 81              1657 	mov	sp,a
                           1658 ;	../../Common/modules/cIPv6.c:284: uint8_t ind=0, lowpan_dispatch, hc1,hoplimit=0, hc2_field_check=0;
                           1659 ;	genAssign
   B0E5 E5 10              1660 	mov	a,_bp
   B0E7 24 05              1661 	add	a,#0x05
   B0E9 F8                 1662 	mov	r0,a
   B0EA 76 00              1663 	mov	@r0,#0x00
                           1664 ;	../../Common/modules/cIPv6.c:285: ind = buf->buf_ptr;
                           1665 ;	genPlus
   B0EC A8 10              1666 	mov	r0,_bp
   B0EE 08                 1667 	inc	r0
                           1668 ;     genPlusIncr
   B0EF 74 20              1669 	mov	a,#0x20
   B0F1 26                 1670 	add	a,@r0
   B0F2 FE                 1671 	mov	r6,a
                           1672 ;	Peephole 181	changed mov to clr
   B0F3 E4                 1673 	clr	a
   B0F4 08                 1674 	inc	r0
   B0F5 36                 1675 	addc	a,@r0
   B0F6 FF                 1676 	mov	r7,a
   B0F7 08                 1677 	inc	r0
   B0F8 86 05              1678 	mov	ar5,@r0
                           1679 ;	genPointerGet
                           1680 ;	genGenPointerGet
   B0FA 8E 82              1681 	mov	dpl,r6
   B0FC 8F 83              1682 	mov	dph,r7
   B0FE 8D F0              1683 	mov	b,r5
   B100 12 E4 9F           1684 	lcall	__gptrget
   B103 FA                 1685 	mov	r2,a
   B104 A3                 1686 	inc	dptr
   B105 12 E4 9F           1687 	lcall	__gptrget
   B108 FB                 1688 	mov	r3,a
                           1689 ;	genCast
   B109 E5 10              1690 	mov	a,_bp
   B10B 24 04              1691 	add	a,#0x04
   B10D F8                 1692 	mov	r0,a
   B10E A6 02              1693 	mov	@r0,ar2
                           1694 ;	../../Common/modules/cIPv6.c:287: lowpan_dispatch = buf->buf[ind++];
                           1695 ;	genPlus
   B110 A8 10              1696 	mov	r0,_bp
   B112 08                 1697 	inc	r0
   B113 E5 10              1698 	mov	a,_bp
   B115 24 06              1699 	add	a,#0x06
   B117 F9                 1700 	mov	r1,a
                           1701 ;     genPlusIncr
   B118 74 2C              1702 	mov	a,#0x2C
   B11A 26                 1703 	add	a,@r0
   B11B F7                 1704 	mov	@r1,a
                           1705 ;	Peephole 181	changed mov to clr
   B11C E4                 1706 	clr	a
   B11D 08                 1707 	inc	r0
   B11E 36                 1708 	addc	a,@r0
   B11F 09                 1709 	inc	r1
   B120 F7                 1710 	mov	@r1,a
   B121 08                 1711 	inc	r0
   B122 09                 1712 	inc	r1
   B123 E6                 1713 	mov	a,@r0
   B124 F7                 1714 	mov	@r1,a
                           1715 ;	genAssign
   B125 E5 10              1716 	mov	a,_bp
   B127 24 04              1717 	add	a,#0x04
   B129 F8                 1718 	mov	r0,a
   B12A 86 02              1719 	mov	ar2,@r0
                           1720 ;	genPlus
   B12C E5 10              1721 	mov	a,_bp
   B12E 24 04              1722 	add	a,#0x04
   B130 F8                 1723 	mov	r0,a
                           1724 ;     genPlusIncr
   B131 06                 1725 	inc	@r0
                           1726 ;	genPlus
   B132 E5 10              1727 	mov	a,_bp
   B134 24 06              1728 	add	a,#0x06
   B136 F8                 1729 	mov	r0,a
                           1730 ;	Peephole 236.g	used r2 instead of ar2
   B137 EA                 1731 	mov	a,r2
   B138 26                 1732 	add	a,@r0
   B139 FA                 1733 	mov	r2,a
                           1734 ;	Peephole 181	changed mov to clr
   B13A E4                 1735 	clr	a
   B13B 08                 1736 	inc	r0
   B13C 36                 1737 	addc	a,@r0
   B13D FB                 1738 	mov	r3,a
   B13E 08                 1739 	inc	r0
   B13F 86 04              1740 	mov	ar4,@r0
                           1741 ;	genPointerGet
                           1742 ;	genGenPointerGet
   B141 8A 82              1743 	mov	dpl,r2
   B143 8B 83              1744 	mov	dph,r3
   B145 8C F0              1745 	mov	b,r4
   B147 12 E4 9F           1746 	lcall	__gptrget
   B14A FA                 1747 	mov	r2,a
                           1748 ;	genAssign
                           1749 ;	../../Common/modules/cIPv6.c:289: if( lowpan_dispatch == LOWPAN_HC1 )
                           1750 ;	genCmpEq
                           1751 ;	gencjneshort
   B14B BA 42 02           1752 	cjne	r2,#0x42,00133$
   B14E 80 03              1753 	sjmp	00134$
   B150                    1754 00133$:
   B150 02 B3 48           1755 	ljmp	00120$
   B153                    1756 00134$:
                           1757 ;	../../Common/modules/cIPv6.c:296: hc1 = buf->buf[ind++];
                           1758 ;	genIpush
   B153 C0 06              1759 	push	ar6
   B155 C0 07              1760 	push	ar7
   B157 C0 05              1761 	push	ar5
                           1762 ;	genPlus
   B159 A8 10              1763 	mov	r0,_bp
   B15B 08                 1764 	inc	r0
                           1765 ;     genPlusIncr
   B15C 74 2C              1766 	mov	a,#0x2C
   B15E 26                 1767 	add	a,@r0
   B15F FA                 1768 	mov	r2,a
                           1769 ;	Peephole 181	changed mov to clr
   B160 E4                 1770 	clr	a
   B161 08                 1771 	inc	r0
   B162 36                 1772 	addc	a,@r0
   B163 FB                 1773 	mov	r3,a
   B164 08                 1774 	inc	r0
   B165 86 04              1775 	mov	ar4,@r0
                           1776 ;	genAssign
   B167 E5 10              1777 	mov	a,_bp
   B169 24 04              1778 	add	a,#0x04
   B16B F8                 1779 	mov	r0,a
   B16C 86 05              1780 	mov	ar5,@r0
                           1781 ;	genPlus
   B16E E5 10              1782 	mov	a,_bp
   B170 24 04              1783 	add	a,#0x04
   B172 F8                 1784 	mov	r0,a
                           1785 ;     genPlusIncr
   B173 06                 1786 	inc	@r0
                           1787 ;	genPlus
                           1788 ;	Peephole 236.g	used r5 instead of ar5
   B174 ED                 1789 	mov	a,r5
                           1790 ;	Peephole 236.a	used r2 instead of ar2
   B175 2A                 1791 	add	a,r2
   B176 FA                 1792 	mov	r2,a
                           1793 ;	Peephole 181	changed mov to clr
   B177 E4                 1794 	clr	a
                           1795 ;	Peephole 236.b	used r3 instead of ar3
   B178 3B                 1796 	addc	a,r3
   B179 FB                 1797 	mov	r3,a
                           1798 ;	genPointerGet
                           1799 ;	genGenPointerGet
   B17A 8A 82              1800 	mov	dpl,r2
   B17C 8B 83              1801 	mov	dph,r3
   B17E 8C F0              1802 	mov	b,r4
   B180 12 E4 9F           1803 	lcall	__gptrget
   B183 FA                 1804 	mov	r2,a
                           1805 ;	genAssign
                           1806 ;	../../Common/modules/cIPv6.c:298: if((hc1==HC1_NEXT_HEADER_COMPRESSED_UDP || hc1 == HC1_NEXT_HEADER_UNCOMPRES_UDP)  || hc1==IP_HEADER_FOR_ICMP)
                           1807 ;	genCmpEq
   B184 E5 10              1808 	mov	a,_bp
   B186 24 06              1809 	add	a,#0x06
   B188 F8                 1810 	mov	r0,a
                           1811 ;	gencjne
                           1812 ;	gencjneshort
                           1813 ;	Peephole 241.d	optimized compare
   B189 E4                 1814 	clr	a
   B18A BA BF 01           1815 	cjne	r2,#0xBF,00135$
   B18D 04                 1816 	inc	a
   B18E                    1817 00135$:
                           1818 ;	Peephole 300	removed redundant label 00136$
   B18E F6                 1819 	mov	@r0,a
                           1820 ;	genIpop
   B18F D0 05              1821 	pop	ar5
   B191 D0 07              1822 	pop	ar7
   B193 D0 06              1823 	pop	ar6
                           1824 ;	genIfx
   B195 E5 10              1825 	mov	a,_bp
   B197 24 06              1826 	add	a,#0x06
   B199 F8                 1827 	mov	r0,a
   B19A E6                 1828 	mov	a,@r0
                           1829 ;	genIfxJump
                           1830 ;	Peephole 108.b	removed ljmp by inverse jump logic
   B19B 70 0D              1831 	jnz	00115$
                           1832 ;	Peephole 300	removed redundant label 00137$
                           1833 ;	genCmpEq
                           1834 ;	gencjneshort
   B19D BA 3F 02           1835 	cjne	r2,#0x3F,00138$
                           1836 ;	Peephole 112.b	changed ljmp to sjmp
   B1A0 80 08              1837 	sjmp	00115$
   B1A2                    1838 00138$:
                           1839 ;	genCmpEq
                           1840 ;	gencjneshort
   B1A2 BA 5F 02           1841 	cjne	r2,#0x5F,00139$
   B1A5 80 03              1842 	sjmp	00140$
   B1A7                    1843 00139$:
   B1A7 02 B3 48           1844 	ljmp	00120$
   B1AA                    1845 00140$:
   B1AA                    1846 00115$:
                           1847 ;	../../Common/modules/cIPv6.c:300: if((hc1==HC1_NEXT_HEADER_COMPRESSED_UDP || hc1 == HC1_NEXT_HEADER_UNCOMPRES_UDP))
                           1848 ;	genIfx
   B1AA E5 10              1849 	mov	a,_bp
   B1AC 24 06              1850 	add	a,#0x06
   B1AE F8                 1851 	mov	r0,a
   B1AF E6                 1852 	mov	a,@r0
                           1853 ;	genIfxJump
                           1854 ;	Peephole 108.b	removed ljmp by inverse jump logic
   B1B0 70 08              1855 	jnz	00107$
                           1856 ;	Peephole 300	removed redundant label 00141$
                           1857 ;	genCmpEq
                           1858 ;	gencjneshort
   B1B2 BA 3F 02           1859 	cjne	r2,#0x3F,00142$
   B1B5 80 03              1860 	sjmp	00143$
   B1B7                    1861 00142$:
   B1B7 02 B2 69           1862 	ljmp	00108$
   B1BA                    1863 00143$:
   B1BA                    1864 00107$:
                           1865 ;	../../Common/modules/cIPv6.c:302: buf->to = MODULE_CUDP;
                           1866 ;	genPlus
   B1BA A8 10              1867 	mov	r0,_bp
   B1BC 08                 1868 	inc	r0
                           1869 ;     genPlusIncr
   B1BD 74 1E              1870 	mov	a,#0x1E
   B1BF 26                 1871 	add	a,@r0
   B1C0 FA                 1872 	mov	r2,a
                           1873 ;	Peephole 181	changed mov to clr
   B1C1 E4                 1874 	clr	a
   B1C2 08                 1875 	inc	r0
   B1C3 36                 1876 	addc	a,@r0
   B1C4 FB                 1877 	mov	r3,a
   B1C5 08                 1878 	inc	r0
   B1C6 86 04              1879 	mov	ar4,@r0
                           1880 ;	genPointerSet
                           1881 ;	genGenPointerSet
   B1C8 8A 82              1882 	mov	dpl,r2
   B1CA 8B 83              1883 	mov	dph,r3
   B1CC 8C F0              1884 	mov	b,r4
   B1CE 74 02              1885 	mov	a,#0x02
   B1D0 12 DF B7           1886 	lcall	__gptrput
                           1887 ;	../../Common/modules/cIPv6.c:303: if(hc1 == HC1_NEXT_HEADER_COMPRESSED_UDP) /* Read udp encode field */
                           1888 ;	genIfx
   B1D3 E5 10              1889 	mov	a,_bp
   B1D5 24 06              1890 	add	a,#0x06
   B1D7 F8                 1891 	mov	r0,a
   B1D8 E6                 1892 	mov	a,@r0
                           1893 ;	genIfxJump
   B1D9 70 03              1894 	jnz	00144$
   B1DB 02 B2 60           1895 	ljmp	00105$
   B1DE                    1896 00144$:
                           1897 ;	../../Common/modules/cIPv6.c:305: buf->options.lowpan_compressed = buf->buf[ind++];
                           1898 ;	genIpush
   B1DE C0 06              1899 	push	ar6
   B1E0 C0 07              1900 	push	ar7
   B1E2 C0 05              1901 	push	ar5
                           1902 ;	genPlus
   B1E4 A8 10              1903 	mov	r0,_bp
   B1E6 08                 1904 	inc	r0
                           1905 ;     genPlusIncr
   B1E7 74 26              1906 	mov	a,#0x26
   B1E9 26                 1907 	add	a,@r0
   B1EA FA                 1908 	mov	r2,a
                           1909 ;	Peephole 181	changed mov to clr
   B1EB E4                 1910 	clr	a
   B1EC 08                 1911 	inc	r0
   B1ED 36                 1912 	addc	a,@r0
   B1EE FB                 1913 	mov	r3,a
   B1EF 08                 1914 	inc	r0
   B1F0 86 04              1915 	mov	ar4,@r0
                           1916 ;	genPlus
                           1917 ;     genPlusIncr
   B1F2 74 05              1918 	mov	a,#0x05
                           1919 ;	Peephole 236.a	used r2 instead of ar2
   B1F4 2A                 1920 	add	a,r2
   B1F5 FA                 1921 	mov	r2,a
                           1922 ;	Peephole 181	changed mov to clr
   B1F6 E4                 1923 	clr	a
                           1924 ;	Peephole 236.b	used r3 instead of ar3
   B1F7 3B                 1925 	addc	a,r3
   B1F8 FB                 1926 	mov	r3,a
                           1927 ;	genPlus
   B1F9 A8 10              1928 	mov	r0,_bp
   B1FB 08                 1929 	inc	r0
   B1FC E5 10              1930 	mov	a,_bp
   B1FE 24 06              1931 	add	a,#0x06
   B200 F9                 1932 	mov	r1,a
                           1933 ;     genPlusIncr
   B201 74 2C              1934 	mov	a,#0x2C
   B203 26                 1935 	add	a,@r0
   B204 F7                 1936 	mov	@r1,a
                           1937 ;	Peephole 181	changed mov to clr
   B205 E4                 1938 	clr	a
   B206 08                 1939 	inc	r0
   B207 36                 1940 	addc	a,@r0
   B208 09                 1941 	inc	r1
   B209 F7                 1942 	mov	@r1,a
   B20A 08                 1943 	inc	r0
   B20B 09                 1944 	inc	r1
   B20C E6                 1945 	mov	a,@r0
   B20D F7                 1946 	mov	@r1,a
                           1947 ;	genAssign
   B20E E5 10              1948 	mov	a,_bp
   B210 24 04              1949 	add	a,#0x04
   B212 F8                 1950 	mov	r0,a
   B213 86 05              1951 	mov	ar5,@r0
                           1952 ;	genPlus
   B215 E5 10              1953 	mov	a,_bp
   B217 24 04              1954 	add	a,#0x04
   B219 F8                 1955 	mov	r0,a
                           1956 ;     genPlusIncr
   B21A 06                 1957 	inc	@r0
                           1958 ;	genPlus
   B21B E5 10              1959 	mov	a,_bp
   B21D 24 06              1960 	add	a,#0x06
   B21F F8                 1961 	mov	r0,a
                           1962 ;	Peephole 236.g	used r5 instead of ar5
   B220 ED                 1963 	mov	a,r5
   B221 26                 1964 	add	a,@r0
   B222 FD                 1965 	mov	r5,a
                           1966 ;	Peephole 181	changed mov to clr
   B223 E4                 1967 	clr	a
   B224 08                 1968 	inc	r0
   B225 36                 1969 	addc	a,@r0
   B226 FE                 1970 	mov	r6,a
   B227 08                 1971 	inc	r0
   B228 86 07              1972 	mov	ar7,@r0
                           1973 ;	genPointerGet
                           1974 ;	genGenPointerGet
   B22A 8D 82              1975 	mov	dpl,r5
   B22C 8E 83              1976 	mov	dph,r6
   B22E 8F F0              1977 	mov	b,r7
   B230 12 E4 9F           1978 	lcall	__gptrget
                           1979 ;	genPointerSet
                           1980 ;	genGenPointerSet
   B233 FD                 1981 	mov	r5,a
   B234 8A 82              1982 	mov	dpl,r2
   B236 8B 83              1983 	mov	dph,r3
   B238 8C F0              1984 	mov	b,r4
                           1985 ;	Peephole 191	removed redundant mov
   B23A 12 DF B7           1986 	lcall	__gptrput
                           1987 ;	../../Common/modules/cIPv6.c:306: if(buf->options.lowpan_compressed==0x07 || buf->options.lowpan_compressed==0x04)
                           1988 ;	genCmpEq
                           1989 ;	gencjne
                           1990 ;	gencjneshort
                           1991 ;	Peephole 241.d	optimized compare
   B23D E4                 1992 	clr	a
   B23E BD 07 01           1993 	cjne	r5,#0x07,00145$
   B241 04                 1994 	inc	a
   B242                    1995 00145$:
                           1996 ;	Peephole 300	removed redundant label 00146$
                           1997 ;	genIpop
   B242 D0 05              1998 	pop	ar5
   B244 D0 07              1999 	pop	ar7
   B246 D0 06              2000 	pop	ar6
                           2001 ;	genIfx
                           2002 ;	genIfxJump
                           2003 ;	Peephole 108.b	removed ljmp by inverse jump logic
   B248 70 0D              2004 	jnz	00101$
                           2005 ;	Peephole 300	removed redundant label 00147$
                           2006 ;	genPointerGet
                           2007 ;	genGenPointerGet
   B24A 8A 82              2008 	mov	dpl,r2
   B24C 8B 83              2009 	mov	dph,r3
   B24E 8C F0              2010 	mov	b,r4
   B250 12 E4 9F           2011 	lcall	__gptrget
   B253 FA                 2012 	mov	r2,a
                           2013 ;	genCmpEq
                           2014 ;	gencjneshort
                           2015 ;	Peephole 112.b	changed ljmp to sjmp
                           2016 ;	Peephole 198.b	optimized misc jump sequence
   B254 BA 04 4B           2017 	cjne	r2,#0x04,00109$
                           2018 ;	Peephole 200.b	removed redundant sjmp
                           2019 ;	Peephole 300	removed redundant label 00148$
                           2020 ;	Peephole 300	removed redundant label 00149$
   B257                    2021 00101$:
                           2022 ;	../../Common/modules/cIPv6.c:307: hc2_field_check=1;
                           2023 ;	genAssign
   B257 E5 10              2024 	mov	a,_bp
   B259 24 05              2025 	add	a,#0x05
   B25B F8                 2026 	mov	r0,a
   B25C 76 01              2027 	mov	@r0,#0x01
                           2028 ;	Peephole 112.b	changed ljmp to sjmp
   B25E 80 42              2029 	sjmp	00109$
   B260                    2030 00105$:
                           2031 ;	../../Common/modules/cIPv6.c:310: hc2_field_check=1;
                           2032 ;	genAssign
   B260 E5 10              2033 	mov	a,_bp
   B262 24 05              2034 	add	a,#0x05
   B264 F8                 2035 	mov	r0,a
   B265 76 01              2036 	mov	@r0,#0x01
                           2037 ;	Peephole 112.b	changed ljmp to sjmp
   B267 80 39              2038 	sjmp	00109$
   B269                    2039 00108$:
                           2040 ;	../../Common/modules/cIPv6.c:314: buf->to = MODULE_ICMP;
                           2041 ;	genPlus
   B269 A8 10              2042 	mov	r0,_bp
   B26B 08                 2043 	inc	r0
                           2044 ;     genPlusIncr
   B26C 74 1E              2045 	mov	a,#0x1E
   B26E 26                 2046 	add	a,@r0
   B26F FA                 2047 	mov	r2,a
                           2048 ;	Peephole 181	changed mov to clr
   B270 E4                 2049 	clr	a
   B271 08                 2050 	inc	r0
   B272 36                 2051 	addc	a,@r0
   B273 FB                 2052 	mov	r3,a
   B274 08                 2053 	inc	r0
   B275 86 04              2054 	mov	ar4,@r0
                           2055 ;	genPointerSet
                           2056 ;	genGenPointerSet
   B277 8A 82              2057 	mov	dpl,r2
   B279 8B 83              2058 	mov	dph,r3
   B27B 8C F0              2059 	mov	b,r4
   B27D 74 04              2060 	mov	a,#0x04
   B27F 12 DF B7           2061 	lcall	__gptrput
                           2062 ;	../../Common/modules/cIPv6.c:315: buf->options.hop_count = 1;
                           2063 ;	genPlus
   B282 A8 10              2064 	mov	r0,_bp
   B284 08                 2065 	inc	r0
                           2066 ;     genPlusIncr
   B285 74 26              2067 	mov	a,#0x26
   B287 26                 2068 	add	a,@r0
   B288 FA                 2069 	mov	r2,a
                           2070 ;	Peephole 181	changed mov to clr
   B289 E4                 2071 	clr	a
   B28A 08                 2072 	inc	r0
   B28B 36                 2073 	addc	a,@r0
   B28C FB                 2074 	mov	r3,a
   B28D 08                 2075 	inc	r0
   B28E 86 04              2076 	mov	ar4,@r0
                           2077 ;	genPlus
                           2078 ;     genPlusIncr
   B290 74 04              2079 	mov	a,#0x04
                           2080 ;	Peephole 236.a	used r2 instead of ar2
   B292 2A                 2081 	add	a,r2
   B293 FA                 2082 	mov	r2,a
                           2083 ;	Peephole 181	changed mov to clr
   B294 E4                 2084 	clr	a
                           2085 ;	Peephole 236.b	used r3 instead of ar3
   B295 3B                 2086 	addc	a,r3
   B296 FB                 2087 	mov	r3,a
                           2088 ;	genPointerSet
                           2089 ;	genGenPointerSet
   B297 8A 82              2090 	mov	dpl,r2
   B299 8B 83              2091 	mov	dph,r3
   B29B 8C F0              2092 	mov	b,r4
   B29D 74 01              2093 	mov	a,#0x01
   B29F 12 DF B7           2094 	lcall	__gptrput
   B2A2                    2095 00109$:
                           2096 ;	../../Common/modules/cIPv6.c:318: hoplimit= buf->buf[ind++];
                           2097 ;	genIpush
   B2A2 C0 06              2098 	push	ar6
   B2A4 C0 07              2099 	push	ar7
   B2A6 C0 05              2100 	push	ar5
                           2101 ;	genPlus
   B2A8 A8 10              2102 	mov	r0,_bp
   B2AA 08                 2103 	inc	r0
                           2104 ;     genPlusIncr
   B2AB 74 2C              2105 	mov	a,#0x2C
   B2AD 26                 2106 	add	a,@r0
   B2AE FA                 2107 	mov	r2,a
                           2108 ;	Peephole 181	changed mov to clr
   B2AF E4                 2109 	clr	a
   B2B0 08                 2110 	inc	r0
   B2B1 36                 2111 	addc	a,@r0
   B2B2 FB                 2112 	mov	r3,a
   B2B3 08                 2113 	inc	r0
   B2B4 86 04              2114 	mov	ar4,@r0
                           2115 ;	genAssign
   B2B6 E5 10              2116 	mov	a,_bp
   B2B8 24 04              2117 	add	a,#0x04
   B2BA F8                 2118 	mov	r0,a
   B2BB 86 05              2119 	mov	ar5,@r0
                           2120 ;	genPlus
   B2BD E5 10              2121 	mov	a,_bp
   B2BF 24 04              2122 	add	a,#0x04
   B2C1 F8                 2123 	mov	r0,a
                           2124 ;     genPlusIncr
   B2C2 06                 2125 	inc	@r0
                           2126 ;	genPlus
                           2127 ;	Peephole 236.g	used r5 instead of ar5
   B2C3 ED                 2128 	mov	a,r5
                           2129 ;	Peephole 236.a	used r2 instead of ar2
   B2C4 2A                 2130 	add	a,r2
   B2C5 FA                 2131 	mov	r2,a
                           2132 ;	Peephole 181	changed mov to clr
   B2C6 E4                 2133 	clr	a
                           2134 ;	Peephole 236.b	used r3 instead of ar3
   B2C7 3B                 2135 	addc	a,r3
   B2C8 FB                 2136 	mov	r3,a
                           2137 ;	genPointerGet
                           2138 ;	genGenPointerGet
   B2C9 8A 82              2139 	mov	dpl,r2
   B2CB 8B 83              2140 	mov	dph,r3
   B2CD 8C F0              2141 	mov	b,r4
   B2CF 12 E4 9F           2142 	lcall	__gptrget
   B2D2 FA                 2143 	mov	r2,a
                           2144 ;	genAssign
                           2145 ;	../../Common/modules/cIPv6.c:319: hoplimit--;
                           2146 ;	genMinus
                           2147 ;	genMinusDec
   B2D3 1A                 2148 	dec	r2
                           2149 ;	../../Common/modules/cIPv6.c:320: if((hoplimit > 0 && hc2_field_check) || buf->to == MODULE_ICMP)
                           2150 ;	genIpop
   B2D4 D0 05              2151 	pop	ar5
   B2D6 D0 07              2152 	pop	ar7
   B2D8 D0 06              2153 	pop	ar6
                           2154 ;	genIfx
   B2DA EA                 2155 	mov	a,r2
                           2156 ;	genIfxJump
                           2157 ;	Peephole 108.c	removed ljmp by inverse jump logic
   B2DB 60 08              2158 	jz	00114$
                           2159 ;	Peephole 300	removed redundant label 00150$
                           2160 ;	genIfx
   B2DD E5 10              2161 	mov	a,_bp
   B2DF 24 05              2162 	add	a,#0x05
   B2E1 F8                 2163 	mov	r0,a
   B2E2 E6                 2164 	mov	a,@r0
                           2165 ;	genIfxJump
                           2166 ;	Peephole 108.b	removed ljmp by inverse jump logic
   B2E3 70 1B              2167 	jnz	00111$
                           2168 ;	Peephole 300	removed redundant label 00151$
   B2E5                    2169 00114$:
                           2170 ;	genPlus
   B2E5 A8 10              2171 	mov	r0,_bp
   B2E7 08                 2172 	inc	r0
                           2173 ;     genPlusIncr
   B2E8 74 1E              2174 	mov	a,#0x1E
   B2EA 26                 2175 	add	a,@r0
   B2EB FA                 2176 	mov	r2,a
                           2177 ;	Peephole 181	changed mov to clr
   B2EC E4                 2178 	clr	a
   B2ED 08                 2179 	inc	r0
   B2EE 36                 2180 	addc	a,@r0
   B2EF FB                 2181 	mov	r3,a
   B2F0 08                 2182 	inc	r0
   B2F1 86 04              2183 	mov	ar4,@r0
                           2184 ;	genPointerGet
                           2185 ;	genGenPointerGet
   B2F3 8A 82              2186 	mov	dpl,r2
   B2F5 8B 83              2187 	mov	dph,r3
   B2F7 8C F0              2188 	mov	b,r4
   B2F9 12 E4 9F           2189 	lcall	__gptrget
   B2FC FA                 2190 	mov	r2,a
                           2191 ;	genCmpEq
                           2192 ;	gencjneshort
                           2193 ;	Peephole 112.b	changed ljmp to sjmp
                           2194 ;	Peephole 198.b	optimized misc jump sequence
   B2FD BA 04 48           2195 	cjne	r2,#0x04,00120$
                           2196 ;	Peephole 200.b	removed redundant sjmp
                           2197 ;	Peephole 300	removed redundant label 00152$
                           2198 ;	Peephole 300	removed redundant label 00153$
   B300                    2199 00111$:
                           2200 ;	../../Common/modules/cIPv6.c:322: buf->buf_ptr = ind; /*cut header*/
                           2201 ;	genCast
   B300 E5 10              2202 	mov	a,_bp
   B302 24 04              2203 	add	a,#0x04
   B304 F8                 2204 	mov	r0,a
   B305 86 02              2205 	mov	ar2,@r0
   B307 7B 00              2206 	mov	r3,#0x00
                           2207 ;	genPointerSet
                           2208 ;	genGenPointerSet
   B309 8E 82              2209 	mov	dpl,r6
   B30B 8F 83              2210 	mov	dph,r7
   B30D 8D F0              2211 	mov	b,r5
   B30F EA                 2212 	mov	a,r2
   B310 12 DF B7           2213 	lcall	__gptrput
   B313 A3                 2214 	inc	dptr
   B314 EB                 2215 	mov	a,r3
   B315 12 DF B7           2216 	lcall	__gptrput
                           2217 ;	../../Common/modules/cIPv6.c:324: buf->from = MODULE_CIPV6;
                           2218 ;	genPlus
   B318 A8 10              2219 	mov	r0,_bp
   B31A 08                 2220 	inc	r0
                           2221 ;     genPlusIncr
   B31B 74 1D              2222 	mov	a,#0x1D
   B31D 26                 2223 	add	a,@r0
   B31E FA                 2224 	mov	r2,a
                           2225 ;	Peephole 181	changed mov to clr
   B31F E4                 2226 	clr	a
   B320 08                 2227 	inc	r0
   B321 36                 2228 	addc	a,@r0
   B322 FB                 2229 	mov	r3,a
   B323 08                 2230 	inc	r0
   B324 86 04              2231 	mov	ar4,@r0
                           2232 ;	genPointerSet
                           2233 ;	genGenPointerSet
   B326 8A 82              2234 	mov	dpl,r2
   B328 8B 83              2235 	mov	dph,r3
   B32A 8C F0              2236 	mov	b,r4
   B32C 74 01              2237 	mov	a,#0x01
   B32E 12 DF B7           2238 	lcall	__gptrput
                           2239 ;	../../Common/modules/cIPv6.c:325: stack_buffer_push(buf);
                           2240 ;	genCall
   B331 A8 10              2241 	mov	r0,_bp
   B333 08                 2242 	inc	r0
   B334 86 82              2243 	mov	dpl,@r0
   B336 08                 2244 	inc	r0
   B337 86 83              2245 	mov	dph,@r0
   B339 08                 2246 	inc	r0
   B33A 86 F0              2247 	mov	b,@r0
   B33C 12 62 C4           2248 	lcall	_stack_buffer_push
                           2249 ;	../../Common/modules/cIPv6.c:326: buf=0;
                           2250 ;	genAssign
   B33F A8 10              2251 	mov	r0,_bp
   B341 08                 2252 	inc	r0
   B342 E4                 2253 	clr	a
   B343 F6                 2254 	mov	@r0,a
   B344 08                 2255 	inc	r0
   B345 F6                 2256 	mov	@r0,a
   B346 08                 2257 	inc	r0
   B347 F6                 2258 	mov	@r0,a
   B348                    2259 00120$:
                           2260 ;	../../Common/modules/cIPv6.c:331: if(buf)
                           2261 ;	genIfx
   B348 A8 10              2262 	mov	r0,_bp
   B34A 08                 2263 	inc	r0
   B34B E6                 2264 	mov	a,@r0
   B34C 08                 2265 	inc	r0
   B34D 46                 2266 	orl	a,@r0
   B34E 08                 2267 	inc	r0
   B34F 46                 2268 	orl	a,@r0
                           2269 ;	genIfxJump
                           2270 ;	Peephole 108.c	removed ljmp by inverse jump logic
   B350 60 0E              2271 	jz	00123$
                           2272 ;	Peephole 300	removed redundant label 00154$
                           2273 ;	../../Common/modules/cIPv6.c:336: stack_buffer_free(buf);
                           2274 ;	genCall
   B352 A8 10              2275 	mov	r0,_bp
   B354 08                 2276 	inc	r0
   B355 86 82              2277 	mov	dpl,@r0
   B357 08                 2278 	inc	r0
   B358 86 83              2279 	mov	dph,@r0
   B35A 08                 2280 	inc	r0
   B35B 86 F0              2281 	mov	b,@r0
   B35D 12 61 FA           2282 	lcall	_stack_buffer_free
                           2283 ;	../../Common/modules/cIPv6.c:337: buf=0;
   B360                    2284 00123$:
   B360 85 10 81           2285 	mov	sp,_bp
   B363 D0 10              2286 	pop	_bp
   B365 22                 2287 	ret
                           2288 ;------------------------------------------------------------
                           2289 ;Allocation info for local variables in function 'parse_mesh_packet'
                           2290 ;------------------------------------------------------------
                           2291 ;buf                       Allocated to stack - offset 1
                           2292 ;tmp_8                     Allocated to registers r3 
                           2293 ;mesh_header               Allocated to registers r2 
                           2294 ;hops_left                 Allocated to registers 
                           2295 ;i                         Allocated to stack - offset 4
                           2296 ;bc_seq                    Allocated to stack - offset 27
                           2297 ;dest_length               Allocated to stack - offset 5
                           2298 ;ind                       Allocated to stack - offset 6
                           2299 ;lowpan_dispatch           Allocated to registers r3 
                           2300 ;hc1                       Allocated to registers r2 
                           2301 ;hoplimit                  Allocated to stack - offset 7
                           2302 ;tmp                       Allocated to registers r2 
                           2303 ;hops_to_ori               Allocated to stack - offset 8
                           2304 ;o_addrtype                Allocated to stack - offset 9
                           2305 ;ori_address               Allocated to stack - offset 10
                           2306 ;address_mode              Allocated to registers r2 
                           2307 ;sloc0                     Allocated to stack - offset 20
                           2308 ;sloc1                     Allocated to stack - offset 23
                           2309 ;sloc2                     Allocated to stack - offset 26
                           2310 ;sloc3                     Allocated to stack - offset 27
                           2311 ;sloc4                     Allocated to stack - offset 30
                           2312 ;sloc5                     Allocated to stack - offset 31
                           2313 ;------------------------------------------------------------
                           2314 ;	../../Common/modules/cIPv6.c:341: void parse_mesh_packet(buffer_t *buf)
                           2315 ;	-----------------------------------------
                           2316 ;	 function parse_mesh_packet
                           2317 ;	-----------------------------------------
   B366                    2318 _parse_mesh_packet:
   B366 C0 10              2319 	push	_bp
   B368 85 81 10           2320 	mov	_bp,sp
                           2321 ;     genReceive
   B36B C0 82              2322 	push	dpl
   B36D C0 83              2323 	push	dph
   B36F C0 F0              2324 	push	b
   B371 E5 81              2325 	mov	a,sp
   B373 24 21              2326 	add	a,#0x21
   B375 F5 81              2327 	mov	sp,a
                           2328 ;	../../Common/modules/cIPv6.c:358: ind = buf->buf_ptr;
                           2329 ;	genPlus
   B377 A8 10              2330 	mov	r0,_bp
   B379 08                 2331 	inc	r0
                           2332 ;     genPlusIncr
   B37A 74 20              2333 	mov	a,#0x20
   B37C 26                 2334 	add	a,@r0
   B37D FD                 2335 	mov	r5,a
                           2336 ;	Peephole 181	changed mov to clr
   B37E E4                 2337 	clr	a
   B37F 08                 2338 	inc	r0
   B380 36                 2339 	addc	a,@r0
   B381 FE                 2340 	mov	r6,a
   B382 08                 2341 	inc	r0
   B383 86 07              2342 	mov	ar7,@r0
                           2343 ;	genPointerGet
                           2344 ;	genGenPointerGet
   B385 8D 82              2345 	mov	dpl,r5
   B387 8E 83              2346 	mov	dph,r6
   B389 8F F0              2347 	mov	b,r7
   B38B 12 E4 9F           2348 	lcall	__gptrget
   B38E FA                 2349 	mov	r2,a
   B38F A3                 2350 	inc	dptr
   B390 12 E4 9F           2351 	lcall	__gptrget
   B393 FB                 2352 	mov	r3,a
                           2353 ;	genCast
   B394 E5 10              2354 	mov	a,_bp
   B396 24 06              2355 	add	a,#0x06
   B398 F8                 2356 	mov	r0,a
   B399 A6 02              2357 	mov	@r0,ar2
                           2358 ;	../../Common/modules/cIPv6.c:360: mesh_header = buf->buf[ind++];
                           2359 ;	genPlus
   B39B A8 10              2360 	mov	r0,_bp
   B39D 08                 2361 	inc	r0
   B39E E5 10              2362 	mov	a,_bp
   B3A0 24 14              2363 	add	a,#0x14
   B3A2 F9                 2364 	mov	r1,a
                           2365 ;     genPlusIncr
   B3A3 74 2C              2366 	mov	a,#0x2C
   B3A5 26                 2367 	add	a,@r0
   B3A6 F7                 2368 	mov	@r1,a
                           2369 ;	Peephole 181	changed mov to clr
   B3A7 E4                 2370 	clr	a
   B3A8 08                 2371 	inc	r0
   B3A9 36                 2372 	addc	a,@r0
   B3AA 09                 2373 	inc	r1
   B3AB F7                 2374 	mov	@r1,a
   B3AC 08                 2375 	inc	r0
   B3AD 09                 2376 	inc	r1
   B3AE E6                 2377 	mov	a,@r0
   B3AF F7                 2378 	mov	@r1,a
                           2379 ;	genAssign
   B3B0 E5 10              2380 	mov	a,_bp
   B3B2 24 06              2381 	add	a,#0x06
   B3B4 F8                 2382 	mov	r0,a
   B3B5 86 02              2383 	mov	ar2,@r0
                           2384 ;	genPlus
   B3B7 E5 10              2385 	mov	a,_bp
   B3B9 24 06              2386 	add	a,#0x06
   B3BB F8                 2387 	mov	r0,a
                           2388 ;     genPlusIncr
   B3BC 06                 2389 	inc	@r0
                           2390 ;	genPlus
   B3BD E5 10              2391 	mov	a,_bp
   B3BF 24 14              2392 	add	a,#0x14
   B3C1 F8                 2393 	mov	r0,a
                           2394 ;	Peephole 236.g	used r2 instead of ar2
   B3C2 EA                 2395 	mov	a,r2
   B3C3 26                 2396 	add	a,@r0
   B3C4 FA                 2397 	mov	r2,a
                           2398 ;	Peephole 181	changed mov to clr
   B3C5 E4                 2399 	clr	a
   B3C6 08                 2400 	inc	r0
   B3C7 36                 2401 	addc	a,@r0
   B3C8 FB                 2402 	mov	r3,a
   B3C9 08                 2403 	inc	r0
   B3CA 86 04              2404 	mov	ar4,@r0
                           2405 ;	genPointerGet
                           2406 ;	genGenPointerGet
   B3CC 8A 82              2407 	mov	dpl,r2
   B3CE 8B 83              2408 	mov	dph,r3
   B3D0 8C F0              2409 	mov	b,r4
   B3D2 12 E4 9F           2410 	lcall	__gptrget
   B3D5 FA                 2411 	mov	r2,a
                           2412 ;	genAssign
                           2413 ;	../../Common/modules/cIPv6.c:366: tmp=(mesh_header & MESH_ADDRESSTYPE_BM);
                           2414 ;	genAnd
   B3D6 53 02 0C           2415 	anl	ar2,#0x0C
                           2416 ;	../../Common/modules/cIPv6.c:367: tmp_8 = (tmp & O_ADDRESSTYPE_BM);
                           2417 ;	genAnd
   B3D9 74 04              2418 	mov	a,#0x04
   B3DB 5A                 2419 	anl	a,r2
   B3DC FB                 2420 	mov	r3,a
                           2421 ;	../../Common/modules/cIPv6.c:369: if(tmp_8 == O_ADDRESSTYPE_16)
                           2422 ;	genCmpEq
                           2423 ;	gencjneshort
                           2424 ;	Peephole 112.b	changed ljmp to sjmp
                           2425 ;	Peephole 198.b	optimized misc jump sequence
   B3DD BB 04 10           2426 	cjne	r3,#0x04,00102$
                           2427 ;	Peephole 200.b	removed redundant sjmp
                           2428 ;	Peephole 300	removed redundant label 00191$
                           2429 ;	Peephole 300	removed redundant label 00192$
                           2430 ;	../../Common/modules/cIPv6.c:371: o_addrtype=ADDR_802_15_4_PAN_SHORT;
                           2431 ;	genAssign
   B3E0 E5 10              2432 	mov	a,_bp
   B3E2 24 09              2433 	add	a,#0x09
   B3E4 F8                 2434 	mov	r0,a
   B3E5 76 03              2435 	mov	@r0,#0x03
                           2436 ;	../../Common/modules/cIPv6.c:372: dest_length=2;
                           2437 ;	genAssign
   B3E7 E5 10              2438 	mov	a,_bp
   B3E9 24 05              2439 	add	a,#0x05
   B3EB F8                 2440 	mov	r0,a
   B3EC 76 02              2441 	mov	@r0,#0x02
                           2442 ;	Peephole 112.b	changed ljmp to sjmp
   B3EE 80 0E              2443 	sjmp	00165$
   B3F0                    2444 00102$:
                           2445 ;	../../Common/modules/cIPv6.c:376: o_addrtype=ADDR_802_15_4_PAN_LONG;
                           2446 ;	genAssign
   B3F0 E5 10              2447 	mov	a,_bp
   B3F2 24 09              2448 	add	a,#0x09
   B3F4 F8                 2449 	mov	r0,a
   B3F5 76 04              2450 	mov	@r0,#0x04
                           2451 ;	../../Common/modules/cIPv6.c:377: dest_length=8;	
                           2452 ;	genAssign
   B3F7 E5 10              2453 	mov	a,_bp
   B3F9 24 05              2454 	add	a,#0x05
   B3FB F8                 2455 	mov	r0,a
   B3FC 76 08              2456 	mov	@r0,#0x08
                           2457 ;	../../Common/modules/cIPv6.c:380: for(i=0; i < dest_length; i++)
   B3FE                    2458 00165$:
                           2459 ;	genAddrOf
   B3FE E5 10              2460 	mov	a,_bp
   B400 24 14              2461 	add	a,#0x14
   B402 F8                 2462 	mov	r0,a
   B403 E5 10              2463 	mov	a,_bp
   B405 24 0A              2464 	add	a,#0x0a
   B407 F6                 2465 	mov	@r0,a
                           2466 ;	genPlus
   B408 A8 10              2467 	mov	r0,_bp
   B40A 08                 2468 	inc	r0
   B40B E5 10              2469 	mov	a,_bp
   B40D 24 17              2470 	add	a,#0x17
   B40F F9                 2471 	mov	r1,a
                           2472 ;     genPlusIncr
   B410 74 2C              2473 	mov	a,#0x2C
   B412 26                 2474 	add	a,@r0
   B413 F7                 2475 	mov	@r1,a
                           2476 ;	Peephole 181	changed mov to clr
   B414 E4                 2477 	clr	a
   B415 08                 2478 	inc	r0
   B416 36                 2479 	addc	a,@r0
   B417 09                 2480 	inc	r1
   B418 F7                 2481 	mov	@r1,a
   B419 08                 2482 	inc	r0
   B41A 09                 2483 	inc	r1
   B41B E6                 2484 	mov	a,@r0
   B41C F7                 2485 	mov	@r1,a
                           2486 ;	genAssign
   B41D E5 10              2487 	mov	a,_bp
   B41F 24 06              2488 	add	a,#0x06
   B421 F8                 2489 	mov	r0,a
   B422 86 03              2490 	mov	ar3,@r0
                           2491 ;	genAssign
   B424 7C 00              2492 	mov	r4,#0x00
   B426                    2493 00153$:
                           2494 ;	genCmpLt
   B426 E5 10              2495 	mov	a,_bp
   B428 24 05              2496 	add	a,#0x05
   B42A F8                 2497 	mov	r0,a
                           2498 ;	genCmp
   B42B C3                 2499 	clr	c
   B42C EC                 2500 	mov	a,r4
   B42D 96                 2501 	subb	a,@r0
                           2502 ;	genIfxJump
                           2503 ;	Peephole 108.a	removed ljmp by inverse jump logic
   B42E 50 34              2504 	jnc	00189$
                           2505 ;	Peephole 300	removed redundant label 00193$
                           2506 ;	../../Common/modules/cIPv6.c:382: ori_address[i] = buf->buf[ind++];
                           2507 ;	genIpush
   B430 C0 05              2508 	push	ar5
   B432 C0 06              2509 	push	ar6
   B434 C0 07              2510 	push	ar7
                           2511 ;	genPlus
   B436 E5 10              2512 	mov	a,_bp
   B438 24 14              2513 	add	a,#0x14
   B43A F9                 2514 	mov	r1,a
                           2515 ;	Peephole 236.g	used r4 instead of ar4
   B43B EC                 2516 	mov	a,r4
   B43C 27                 2517 	add	a,@r1
   B43D F8                 2518 	mov	r0,a
                           2519 ;	genAssign
   B43E 8B 05              2520 	mov	ar5,r3
                           2521 ;	genPlus
                           2522 ;     genPlusIncr
   B440 0B                 2523 	inc	r3
                           2524 ;	genPlus
   B441 E5 10              2525 	mov	a,_bp
   B443 24 17              2526 	add	a,#0x17
   B445 F9                 2527 	mov	r1,a
                           2528 ;	Peephole 236.g	used r5 instead of ar5
   B446 ED                 2529 	mov	a,r5
   B447 27                 2530 	add	a,@r1
   B448 FD                 2531 	mov	r5,a
                           2532 ;	Peephole 181	changed mov to clr
   B449 E4                 2533 	clr	a
   B44A 09                 2534 	inc	r1
   B44B 37                 2535 	addc	a,@r1
   B44C FE                 2536 	mov	r6,a
   B44D 09                 2537 	inc	r1
   B44E 87 07              2538 	mov	ar7,@r1
                           2539 ;	genPointerGet
                           2540 ;	genGenPointerGet
   B450 8D 82              2541 	mov	dpl,r5
   B452 8E 83              2542 	mov	dph,r6
   B454 8F F0              2543 	mov	b,r7
   B456 12 E4 9F           2544 	lcall	__gptrget
                           2545 ;	genPointerSet
                           2546 ;	genNearPointerSet
   B459 FD                 2547 	mov	r5,a
                           2548 ;	Peephole 192	used a instead of ar5 as source
   B45A F6                 2549 	mov	@r0,a
                           2550 ;	../../Common/modules/cIPv6.c:380: for(i=0; i < dest_length; i++)
                           2551 ;	genPlus
                           2552 ;     genPlusIncr
   B45B 0C                 2553 	inc	r4
                           2554 ;	genIpop
   B45C D0 07              2555 	pop	ar7
   B45E D0 06              2556 	pop	ar6
   B460 D0 05              2557 	pop	ar5
                           2558 ;	Peephole 112.b	changed ljmp to sjmp
   B462 80 C2              2559 	sjmp	00153$
   B464                    2560 00189$:
                           2561 ;	genAssign
   B464 E5 10              2562 	mov	a,_bp
   B466 24 06              2563 	add	a,#0x06
   B468 F8                 2564 	mov	r0,a
   B469 A6 03              2565 	mov	@r0,ar3
                           2566 ;	../../Common/modules/cIPv6.c:384: tmp_8 = (tmp & D_ADDRESSTYPE_BM);
                           2567 ;	genAnd
   B46B 74 08              2568 	mov	a,#0x08
   B46D 5A                 2569 	anl	a,r2
   B46E FB                 2570 	mov	r3,a
                           2571 ;	../../Common/modules/cIPv6.c:386: if(tmp_8 == D_ADDRESSTYPE_16)
                           2572 ;	genCmpEq
                           2573 ;	gencjneshort
                           2574 ;	Peephole 112.b	changed ljmp to sjmp
                           2575 ;	Peephole 198.b	optimized misc jump sequence
   B46F BB 08 2E           2576 	cjne	r3,#0x08,00105$
                           2577 ;	Peephole 200.b	removed redundant sjmp
                           2578 ;	Peephole 300	removed redundant label 00194$
                           2579 ;	Peephole 300	removed redundant label 00195$
                           2580 ;	../../Common/modules/cIPv6.c:388: buf->dst_sa.addr_type =  ADDR_802_15_4_PAN_SHORT;
                           2581 ;	genIpush
   B472 C0 05              2582 	push	ar5
   B474 C0 06              2583 	push	ar6
   B476 C0 07              2584 	push	ar7
                           2585 ;	genPlus
   B478 A8 10              2586 	mov	r0,_bp
   B47A 08                 2587 	inc	r0
                           2588 ;     genPlusIncr
   B47B 74 03              2589 	mov	a,#0x03
   B47D 26                 2590 	add	a,@r0
   B47E FB                 2591 	mov	r3,a
                           2592 ;	Peephole 181	changed mov to clr
   B47F E4                 2593 	clr	a
   B480 08                 2594 	inc	r0
   B481 36                 2595 	addc	a,@r0
   B482 FC                 2596 	mov	r4,a
   B483 08                 2597 	inc	r0
   B484 86 05              2598 	mov	ar5,@r0
                           2599 ;	genPointerSet
                           2600 ;	genGenPointerSet
   B486 8B 82              2601 	mov	dpl,r3
   B488 8C 83              2602 	mov	dph,r4
   B48A 8D F0              2603 	mov	b,r5
   B48C 74 03              2604 	mov	a,#0x03
   B48E 12 DF B7           2605 	lcall	__gptrput
                           2606 ;	../../Common/modules/cIPv6.c:389: dest_length=2;
                           2607 ;	genAssign
   B491 E5 10              2608 	mov	a,_bp
   B493 24 05              2609 	add	a,#0x05
   B495 F8                 2610 	mov	r0,a
   B496 76 02              2611 	mov	@r0,#0x02
                           2612 ;	genIpop
   B498 D0 07              2613 	pop	ar7
   B49A D0 06              2614 	pop	ar6
   B49C D0 05              2615 	pop	ar5
                           2616 ;	Peephole 112.b	changed ljmp to sjmp
   B49E 80 2C              2617 	sjmp	00168$
   B4A0                    2618 00105$:
                           2619 ;	../../Common/modules/cIPv6.c:393: buf->dst_sa.addr_type=ADDR_802_15_4_PAN_LONG;
                           2620 ;	genIpush
   B4A0 C0 05              2621 	push	ar5
   B4A2 C0 06              2622 	push	ar6
   B4A4 C0 07              2623 	push	ar7
                           2624 ;	genPlus
   B4A6 A8 10              2625 	mov	r0,_bp
   B4A8 08                 2626 	inc	r0
                           2627 ;     genPlusIncr
   B4A9 74 03              2628 	mov	a,#0x03
   B4AB 26                 2629 	add	a,@r0
   B4AC FB                 2630 	mov	r3,a
                           2631 ;	Peephole 181	changed mov to clr
   B4AD E4                 2632 	clr	a
   B4AE 08                 2633 	inc	r0
   B4AF 36                 2634 	addc	a,@r0
   B4B0 FC                 2635 	mov	r4,a
   B4B1 08                 2636 	inc	r0
   B4B2 86 05              2637 	mov	ar5,@r0
                           2638 ;	genPointerSet
                           2639 ;	genGenPointerSet
   B4B4 8B 82              2640 	mov	dpl,r3
   B4B6 8C 83              2641 	mov	dph,r4
   B4B8 8D F0              2642 	mov	b,r5
   B4BA 74 04              2643 	mov	a,#0x04
   B4BC 12 DF B7           2644 	lcall	__gptrput
                           2645 ;	../../Common/modules/cIPv6.c:394: dest_length=8;
                           2646 ;	genAssign
   B4BF E5 10              2647 	mov	a,_bp
   B4C1 24 05              2648 	add	a,#0x05
   B4C3 F8                 2649 	mov	r0,a
   B4C4 76 08              2650 	mov	@r0,#0x08
                           2651 ;	../../Common/modules/cIPv6.c:583: buf=0;
                           2652 ;	genIpop
   B4C6 D0 07              2653 	pop	ar7
   B4C8 D0 06              2654 	pop	ar6
   B4CA D0 05              2655 	pop	ar5
                           2656 ;	../../Common/modules/cIPv6.c:397: for(i=0; i < dest_length; i++)
   B4CC                    2657 00168$:
                           2658 ;	genIpush
   B4CC C0 05              2659 	push	ar5
   B4CE C0 06              2660 	push	ar6
   B4D0 C0 07              2661 	push	ar7
                           2662 ;	genPlus
   B4D2 A8 10              2663 	mov	r0,_bp
   B4D4 08                 2664 	inc	r0
                           2665 ;     genPlusIncr
   B4D5 74 03              2666 	mov	a,#0x03
   B4D7 26                 2667 	add	a,@r0
   B4D8 FB                 2668 	mov	r3,a
                           2669 ;	Peephole 181	changed mov to clr
   B4D9 E4                 2670 	clr	a
   B4DA 08                 2671 	inc	r0
   B4DB 36                 2672 	addc	a,@r0
   B4DC FC                 2673 	mov	r4,a
   B4DD 08                 2674 	inc	r0
   B4DE 86 05              2675 	mov	ar5,@r0
                           2676 ;	genPlus
   B4E0 E5 10              2677 	mov	a,_bp
   B4E2 24 17              2678 	add	a,#0x17
   B4E4 F8                 2679 	mov	r0,a
                           2680 ;     genPlusIncr
   B4E5 74 01              2681 	mov	a,#0x01
                           2682 ;	Peephole 236.a	used r3 instead of ar3
   B4E7 2B                 2683 	add	a,r3
   B4E8 F6                 2684 	mov	@r0,a
                           2685 ;	Peephole 181	changed mov to clr
   B4E9 E4                 2686 	clr	a
                           2687 ;	Peephole 236.b	used r4 instead of ar4
   B4EA 3C                 2688 	addc	a,r4
   B4EB 08                 2689 	inc	r0
   B4EC F6                 2690 	mov	@r0,a
   B4ED 08                 2691 	inc	r0
   B4EE A6 05              2692 	mov	@r0,ar5
                           2693 ;	genPlus
   B4F0 A8 10              2694 	mov	r0,_bp
   B4F2 08                 2695 	inc	r0
   B4F3 E5 10              2696 	mov	a,_bp
   B4F5 24 1B              2697 	add	a,#0x1b
   B4F7 F9                 2698 	mov	r1,a
                           2699 ;     genPlusIncr
   B4F8 74 2C              2700 	mov	a,#0x2C
   B4FA 26                 2701 	add	a,@r0
   B4FB F7                 2702 	mov	@r1,a
                           2703 ;	Peephole 181	changed mov to clr
   B4FC E4                 2704 	clr	a
   B4FD 08                 2705 	inc	r0
   B4FE 36                 2706 	addc	a,@r0
   B4FF 09                 2707 	inc	r1
   B500 F7                 2708 	mov	@r1,a
   B501 08                 2709 	inc	r0
   B502 09                 2710 	inc	r1
   B503 E6                 2711 	mov	a,@r0
   B504 F7                 2712 	mov	@r1,a
                           2713 ;	genAssign
   B505 E5 10              2714 	mov	a,_bp
   B507 24 06              2715 	add	a,#0x06
   B509 F8                 2716 	mov	r0,a
   B50A E5 10              2717 	mov	a,_bp
   B50C 24 1A              2718 	add	a,#0x1a
   B50E F9                 2719 	mov	r1,a
   B50F E6                 2720 	mov	a,@r0
   B510 F7                 2721 	mov	@r1,a
                           2722 ;	genAssign
   B511 E5 10              2723 	mov	a,_bp
   B513 24 04              2724 	add	a,#0x04
   B515 F8                 2725 	mov	r0,a
   B516 76 00              2726 	mov	@r0,#0x00
                           2727 ;	../../Common/modules/cIPv6.c:583: buf=0;
                           2728 ;	genIpop
   B518 D0 07              2729 	pop	ar7
   B51A D0 06              2730 	pop	ar6
   B51C D0 05              2731 	pop	ar5
                           2732 ;	../../Common/modules/cIPv6.c:397: for(i=0; i < dest_length; i++)
   B51E                    2733 00157$:
                           2734 ;	genCmpLt
   B51E E5 10              2735 	mov	a,_bp
   B520 24 04              2736 	add	a,#0x04
   B522 F8                 2737 	mov	r0,a
   B523 E5 10              2738 	mov	a,_bp
   B525 24 05              2739 	add	a,#0x05
   B527 F9                 2740 	mov	r1,a
                           2741 ;	genCmp
   B528 C3                 2742 	clr	c
   B529 E6                 2743 	mov	a,@r0
   B52A 97                 2744 	subb	a,@r1
                           2745 ;	genIfxJump
                           2746 ;	Peephole 108.a	removed ljmp by inverse jump logic
   B52B 50 57              2747 	jnc	00190$
                           2748 ;	Peephole 300	removed redundant label 00196$
                           2749 ;	../../Common/modules/cIPv6.c:399: buf->dst_sa.address[i] = buf->buf[ind++];
                           2750 ;	genIpush
   B52D C0 05              2751 	push	ar5
   B52F C0 06              2752 	push	ar6
   B531 C0 07              2753 	push	ar7
                           2754 ;	genPlus
   B533 E5 10              2755 	mov	a,_bp
   B535 24 17              2756 	add	a,#0x17
   B537 F8                 2757 	mov	r0,a
   B538 E5 10              2758 	mov	a,_bp
   B53A 24 04              2759 	add	a,#0x04
   B53C F9                 2760 	mov	r1,a
   B53D E7                 2761 	mov	a,@r1
   B53E 26                 2762 	add	a,@r0
   B53F FB                 2763 	mov	r3,a
                           2764 ;	Peephole 181	changed mov to clr
   B540 E4                 2765 	clr	a
   B541 08                 2766 	inc	r0
   B542 36                 2767 	addc	a,@r0
   B543 FC                 2768 	mov	r4,a
   B544 08                 2769 	inc	r0
   B545 86 05              2770 	mov	ar5,@r0
                           2771 ;	genAssign
   B547 E5 10              2772 	mov	a,_bp
   B549 24 1A              2773 	add	a,#0x1a
   B54B F8                 2774 	mov	r0,a
   B54C 86 06              2775 	mov	ar6,@r0
                           2776 ;	genPlus
   B54E E5 10              2777 	mov	a,_bp
   B550 24 1A              2778 	add	a,#0x1a
   B552 F8                 2779 	mov	r0,a
                           2780 ;     genPlusIncr
   B553 06                 2781 	inc	@r0
                           2782 ;	genPlus
   B554 E5 10              2783 	mov	a,_bp
   B556 24 1B              2784 	add	a,#0x1b
   B558 F8                 2785 	mov	r0,a
                           2786 ;	Peephole 236.g	used r6 instead of ar6
   B559 EE                 2787 	mov	a,r6
   B55A 26                 2788 	add	a,@r0
   B55B FE                 2789 	mov	r6,a
                           2790 ;	Peephole 181	changed mov to clr
   B55C E4                 2791 	clr	a
   B55D 08                 2792 	inc	r0
   B55E 36                 2793 	addc	a,@r0
   B55F FF                 2794 	mov	r7,a
   B560 08                 2795 	inc	r0
   B561 86 02              2796 	mov	ar2,@r0
                           2797 ;	genPointerGet
                           2798 ;	genGenPointerGet
   B563 8E 82              2799 	mov	dpl,r6
   B565 8F 83              2800 	mov	dph,r7
   B567 8A F0              2801 	mov	b,r2
   B569 12 E4 9F           2802 	lcall	__gptrget
                           2803 ;	genPointerSet
                           2804 ;	genGenPointerSet
   B56C FE                 2805 	mov	r6,a
   B56D 8B 82              2806 	mov	dpl,r3
   B56F 8C 83              2807 	mov	dph,r4
   B571 8D F0              2808 	mov	b,r5
                           2809 ;	Peephole 191	removed redundant mov
   B573 12 DF B7           2810 	lcall	__gptrput
                           2811 ;	../../Common/modules/cIPv6.c:397: for(i=0; i < dest_length; i++)
                           2812 ;	genPlus
   B576 E5 10              2813 	mov	a,_bp
   B578 24 04              2814 	add	a,#0x04
   B57A F8                 2815 	mov	r0,a
                           2816 ;     genPlusIncr
   B57B 06                 2817 	inc	@r0
                           2818 ;	genIpop
   B57C D0 07              2819 	pop	ar7
   B57E D0 06              2820 	pop	ar6
   B580 D0 05              2821 	pop	ar5
                           2822 ;	Peephole 112.b	changed ljmp to sjmp
   B582 80 9A              2823 	sjmp	00157$
   B584                    2824 00190$:
                           2825 ;	genAssign
   B584 E5 10              2826 	mov	a,_bp
   B586 24 1A              2827 	add	a,#0x1a
   B588 F8                 2828 	mov	r0,a
   B589 E5 10              2829 	mov	a,_bp
   B58B 24 06              2830 	add	a,#0x06
   B58D F9                 2831 	mov	r1,a
   B58E E6                 2832 	mov	a,@r0
   B58F F7                 2833 	mov	@r1,a
                           2834 ;	../../Common/modules/cIPv6.c:402: address_mode = OWN;
                           2835 ;	genIpush
   B590 C0 05              2836 	push	ar5
   B592 C0 06              2837 	push	ar6
   B594 C0 07              2838 	push	ar7
                           2839 ;	genAssign
   B596 7A C1              2840 	mov	r2,#0xC1
                           2841 ;	../../Common/modules/cIPv6.c:404: if(buf->dst_sa.addr_type==ADDR_802_15_4_PAN_LONG)
                           2842 ;	genPlus
   B598 A8 10              2843 	mov	r0,_bp
   B59A 08                 2844 	inc	r0
                           2845 ;     genPlusIncr
   B59B 74 03              2846 	mov	a,#0x03
   B59D 26                 2847 	add	a,@r0
   B59E FB                 2848 	mov	r3,a
                           2849 ;	Peephole 181	changed mov to clr
   B59F E4                 2850 	clr	a
   B5A0 08                 2851 	inc	r0
   B5A1 36                 2852 	addc	a,@r0
   B5A2 FC                 2853 	mov	r4,a
   B5A3 08                 2854 	inc	r0
   B5A4 86 05              2855 	mov	ar5,@r0
                           2856 ;	genPointerGet
                           2857 ;	genGenPointerGet
   B5A6 8B 82              2858 	mov	dpl,r3
   B5A8 8C 83              2859 	mov	dph,r4
   B5AA 8D F0              2860 	mov	b,r5
   B5AC 12 E4 9F           2861 	lcall	__gptrget
   B5AF FB                 2862 	mov	r3,a
                           2863 ;	genCmpEq
                           2864 ;	gencjne
                           2865 ;	gencjneshort
                           2866 ;	Peephole 241.d	optimized compare
   B5B0 E4                 2867 	clr	a
   B5B1 BB 04 01           2868 	cjne	r3,#0x04,00197$
   B5B4 04                 2869 	inc	a
   B5B5                    2870 00197$:
                           2871 ;	Peephole 300	removed redundant label 00198$
                           2872 ;	genIpop
   B5B5 D0 07              2873 	pop	ar7
   B5B7 D0 06              2874 	pop	ar6
   B5B9 D0 05              2875 	pop	ar5
                           2876 ;	genIfx
                           2877 ;	genIfxJump
   B5BB 70 03              2878 	jnz	00199$
   B5BD 02 B6 71           2879 	ljmp	00118$
   B5C0                    2880 00199$:
                           2881 ;	../../Common/modules/cIPv6.c:406: if (memcmp(buf->dst_sa.address, cipv6_pib.long_address, 8) != 0)
                           2882 ;	genIpush
   B5C0 C0 02              2883 	push	ar2
                           2884 ;	genPlus
   B5C2 A8 10              2885 	mov	r0,_bp
   B5C4 08                 2886 	inc	r0
   B5C5 E5 10              2887 	mov	a,_bp
   B5C7 24 1B              2888 	add	a,#0x1b
   B5C9 F9                 2889 	mov	r1,a
                           2890 ;     genPlusIncr
   B5CA 74 03              2891 	mov	a,#0x03
   B5CC 26                 2892 	add	a,@r0
   B5CD F7                 2893 	mov	@r1,a
                           2894 ;	Peephole 181	changed mov to clr
   B5CE E4                 2895 	clr	a
   B5CF 08                 2896 	inc	r0
   B5D0 36                 2897 	addc	a,@r0
   B5D1 09                 2898 	inc	r1
   B5D2 F7                 2899 	mov	@r1,a
   B5D3 08                 2900 	inc	r0
   B5D4 09                 2901 	inc	r1
   B5D5 E6                 2902 	mov	a,@r0
   B5D6 F7                 2903 	mov	@r1,a
                           2904 ;	genPlus
   B5D7 E5 10              2905 	mov	a,_bp
   B5D9 24 1B              2906 	add	a,#0x1b
   B5DB F8                 2907 	mov	r0,a
                           2908 ;     genPlusIncr
   B5DC 74 01              2909 	mov	a,#0x01
   B5DE 26                 2910 	add	a,@r0
   B5DF FB                 2911 	mov	r3,a
                           2912 ;	Peephole 181	changed mov to clr
   B5E0 E4                 2913 	clr	a
   B5E1 08                 2914 	inc	r0
   B5E2 36                 2915 	addc	a,@r0
   B5E3 FC                 2916 	mov	r4,a
   B5E4 08                 2917 	inc	r0
   B5E5 86 02              2918 	mov	ar2,@r0
                           2919 ;	genIpush
   B5E7 C0 05              2920 	push	ar5
   B5E9 C0 06              2921 	push	ar6
   B5EB C0 07              2922 	push	ar7
   B5ED 74 08              2923 	mov	a,#0x08
   B5EF C0 E0              2924 	push	acc
                           2925 ;	Peephole 181	changed mov to clr
   B5F1 E4                 2926 	clr	a
   B5F2 C0 E0              2927 	push	acc
                           2928 ;	genIpush
   B5F4 74 4F              2929 	mov	a,#(_cipv6_pib + 0x0002)
   B5F6 C0 E0              2930 	push	acc
   B5F8 74 F0              2931 	mov	a,#((_cipv6_pib + 0x0002) >> 8)
   B5FA C0 E0              2932 	push	acc
                           2933 ;	Peephole 181	changed mov to clr
   B5FC E4                 2934 	clr	a
   B5FD C0 E0              2935 	push	acc
                           2936 ;	genCall
   B5FF 8B 82              2937 	mov	dpl,r3
   B601 8C 83              2938 	mov	dph,r4
   B603 8A F0              2939 	mov	b,r2
   B605 12 E2 0A           2940 	lcall	_memcmp
   B608 AA 82              2941 	mov	r2,dpl
   B60A AB 83              2942 	mov	r3,dph
   B60C E5 81              2943 	mov	a,sp
   B60E 24 FB              2944 	add	a,#0xfb
   B610 F5 81              2945 	mov	sp,a
   B612 D0 07              2946 	pop	ar7
   B614 D0 06              2947 	pop	ar6
   B616 D0 05              2948 	pop	ar5
                           2949 ;	genCmpEq
                           2950 ;	gencjne
                           2951 ;	gencjneshort
                           2952 ;	Peephole 241.c	optimized compare
   B618 E4                 2953 	clr	a
   B619 BA 00 04           2954 	cjne	r2,#0x00,00200$
   B61C BB 00 01           2955 	cjne	r3,#0x00,00200$
   B61F 04                 2956 	inc	a
   B620                    2957 00200$:
                           2958 ;	Peephole 300	removed redundant label 00201$
                           2959 ;	genIpop
   B620 D0 02              2960 	pop	ar2
                           2961 ;	genIfx
                           2962 ;	genIfxJump
   B622 60 03              2963 	jz	00202$
   B624 02 B7 1B           2964 	ljmp	00119$
   B627                    2965 00202$:
                           2966 ;	../../Common/modules/cIPv6.c:408: if(stack_check_broadcast(buf->dst_sa.address, ADDR_802_15_4_PAN_LONG) != pdTRUE)
                           2967 ;	genIpush
   B627 C0 05              2968 	push	ar5
   B629 C0 06              2969 	push	ar6
   B62B C0 07              2970 	push	ar7
                           2971 ;	genPlus
   B62D E5 10              2972 	mov	a,_bp
   B62F 24 1B              2973 	add	a,#0x1b
   B631 F8                 2974 	mov	r0,a
                           2975 ;     genPlusIncr
   B632 74 01              2976 	mov	a,#0x01
   B634 26                 2977 	add	a,@r0
   B635 FB                 2978 	mov	r3,a
                           2979 ;	Peephole 181	changed mov to clr
   B636 E4                 2980 	clr	a
   B637 08                 2981 	inc	r0
   B638 36                 2982 	addc	a,@r0
   B639 FC                 2983 	mov	r4,a
   B63A 08                 2984 	inc	r0
   B63B 86 05              2985 	mov	ar5,@r0
                           2986 ;	genIpush
   B63D C0 05              2987 	push	ar5
   B63F C0 06              2988 	push	ar6
   B641 C0 07              2989 	push	ar7
   B643 74 04              2990 	mov	a,#0x04
   B645 C0 E0              2991 	push	acc
                           2992 ;	genCall
   B647 8B 82              2993 	mov	dpl,r3
   B649 8C 83              2994 	mov	dph,r4
   B64B 8D F0              2995 	mov	b,r5
   B64D 12 6B 44           2996 	lcall	_stack_check_broadcast
   B650 AB 82              2997 	mov	r3,dpl
   B652 15 81              2998 	dec	sp
   B654 D0 07              2999 	pop	ar7
   B656 D0 06              3000 	pop	ar6
   B658 D0 05              3001 	pop	ar5
                           3002 ;	genCmpEq
                           3003 ;	gencjne
                           3004 ;	gencjneshort
                           3005 ;	Peephole 241.d	optimized compare
   B65A E4                 3006 	clr	a
   B65B BB 01 01           3007 	cjne	r3,#0x01,00203$
   B65E 04                 3008 	inc	a
   B65F                    3009 00203$:
                           3010 ;	Peephole 300	removed redundant label 00204$
                           3011 ;	genIpop
   B65F D0 07              3012 	pop	ar7
   B661 D0 06              3013 	pop	ar6
   B663 D0 05              3014 	pop	ar5
                           3015 ;	genIfx
                           3016 ;	genIfxJump
                           3017 ;	Peephole 108.b	removed ljmp by inverse jump logic
   B665 70 05              3018 	jnz	00108$
                           3019 ;	Peephole 300	removed redundant label 00205$
                           3020 ;	../../Common/modules/cIPv6.c:411: address_mode = NOT_OWN;
                           3021 ;	genAssign
   B667 7A C2              3022 	mov	r2,#0xC2
   B669 02 B7 1B           3023 	ljmp	00119$
   B66C                    3024 00108$:
                           3025 ;	../../Common/modules/cIPv6.c:416: address_mode = BCAST;
                           3026 ;	genAssign
   B66C 7A C0              3027 	mov	r2,#0xC0
   B66E 02 B7 1B           3028 	ljmp	00119$
   B671                    3029 00118$:
                           3030 ;	../../Common/modules/cIPv6.c:422: if (memcmp(buf->dst_sa.address, cipv6_pib.short_address, 2) != 0)
                           3031 ;	genIpush
   B671 C0 02              3032 	push	ar2
                           3033 ;	genPlus
   B673 A8 10              3034 	mov	r0,_bp
   B675 08                 3035 	inc	r0
   B676 E5 10              3036 	mov	a,_bp
   B678 24 1B              3037 	add	a,#0x1b
   B67A F9                 3038 	mov	r1,a
                           3039 ;     genPlusIncr
   B67B 74 03              3040 	mov	a,#0x03
   B67D 26                 3041 	add	a,@r0
   B67E F7                 3042 	mov	@r1,a
                           3043 ;	Peephole 181	changed mov to clr
   B67F E4                 3044 	clr	a
   B680 08                 3045 	inc	r0
   B681 36                 3046 	addc	a,@r0
   B682 09                 3047 	inc	r1
   B683 F7                 3048 	mov	@r1,a
   B684 08                 3049 	inc	r0
   B685 09                 3050 	inc	r1
   B686 E6                 3051 	mov	a,@r0
   B687 F7                 3052 	mov	@r1,a
                           3053 ;	genPlus
   B688 E5 10              3054 	mov	a,_bp
   B68A 24 1B              3055 	add	a,#0x1b
   B68C F8                 3056 	mov	r0,a
                           3057 ;     genPlusIncr
   B68D 74 01              3058 	mov	a,#0x01
   B68F 26                 3059 	add	a,@r0
   B690 FB                 3060 	mov	r3,a
                           3061 ;	Peephole 181	changed mov to clr
   B691 E4                 3062 	clr	a
   B692 08                 3063 	inc	r0
   B693 36                 3064 	addc	a,@r0
   B694 FC                 3065 	mov	r4,a
   B695 08                 3066 	inc	r0
   B696 86 02              3067 	mov	ar2,@r0
                           3068 ;	genIpush
   B698 C0 05              3069 	push	ar5
   B69A C0 06              3070 	push	ar6
   B69C C0 07              3071 	push	ar7
   B69E 74 02              3072 	mov	a,#0x02
   B6A0 C0 E0              3073 	push	acc
                           3074 ;	Peephole 181	changed mov to clr
   B6A2 E4                 3075 	clr	a
   B6A3 C0 E0              3076 	push	acc
                           3077 ;	genIpush
   B6A5 74 57              3078 	mov	a,#(_cipv6_pib + 0x000a)
   B6A7 C0 E0              3079 	push	acc
   B6A9 74 F0              3080 	mov	a,#((_cipv6_pib + 0x000a) >> 8)
   B6AB C0 E0              3081 	push	acc
                           3082 ;	Peephole 181	changed mov to clr
   B6AD E4                 3083 	clr	a
   B6AE C0 E0              3084 	push	acc
                           3085 ;	genCall
   B6B0 8B 82              3086 	mov	dpl,r3
   B6B2 8C 83              3087 	mov	dph,r4
   B6B4 8A F0              3088 	mov	b,r2
   B6B6 12 E2 0A           3089 	lcall	_memcmp
   B6B9 AA 82              3090 	mov	r2,dpl
   B6BB AB 83              3091 	mov	r3,dph
   B6BD E5 81              3092 	mov	a,sp
   B6BF 24 FB              3093 	add	a,#0xfb
   B6C1 F5 81              3094 	mov	sp,a
   B6C3 D0 07              3095 	pop	ar7
   B6C5 D0 06              3096 	pop	ar6
   B6C7 D0 05              3097 	pop	ar5
                           3098 ;	genCmpEq
                           3099 ;	gencjne
                           3100 ;	gencjneshort
                           3101 ;	Peephole 241.c	optimized compare
   B6C9 E4                 3102 	clr	a
   B6CA BA 00 04           3103 	cjne	r2,#0x00,00206$
   B6CD BB 00 01           3104 	cjne	r3,#0x00,00206$
   B6D0 04                 3105 	inc	a
   B6D1                    3106 00206$:
                           3107 ;	Peephole 300	removed redundant label 00207$
                           3108 ;	genIpop
   B6D1 D0 02              3109 	pop	ar2
                           3110 ;	genIfx
                           3111 ;	genIfxJump
                           3112 ;	Peephole 108.b	removed ljmp by inverse jump logic
   B6D3 70 46              3113 	jnz	00119$
                           3114 ;	Peephole 300	removed redundant label 00208$
                           3115 ;	../../Common/modules/cIPv6.c:424: if(stack_check_broadcast(buf->dst_sa.address, ADDR_SHORT) != pdTRUE)
                           3116 ;	genIpush
   B6D5 C0 05              3117 	push	ar5
   B6D7 C0 06              3118 	push	ar6
   B6D9 C0 07              3119 	push	ar7
                           3120 ;	genPlus
   B6DB E5 10              3121 	mov	a,_bp
   B6DD 24 1B              3122 	add	a,#0x1b
   B6DF F8                 3123 	mov	r0,a
                           3124 ;     genPlusIncr
   B6E0 74 01              3125 	mov	a,#0x01
   B6E2 26                 3126 	add	a,@r0
   B6E3 FB                 3127 	mov	r3,a
                           3128 ;	Peephole 181	changed mov to clr
   B6E4 E4                 3129 	clr	a
   B6E5 08                 3130 	inc	r0
   B6E6 36                 3131 	addc	a,@r0
   B6E7 FC                 3132 	mov	r4,a
   B6E8 08                 3133 	inc	r0
   B6E9 86 05              3134 	mov	ar5,@r0
                           3135 ;	genIpush
   B6EB C0 05              3136 	push	ar5
   B6ED C0 06              3137 	push	ar6
   B6EF C0 07              3138 	push	ar7
   B6F1 74 05              3139 	mov	a,#0x05
   B6F3 C0 E0              3140 	push	acc
                           3141 ;	genCall
   B6F5 8B 82              3142 	mov	dpl,r3
   B6F7 8C 83              3143 	mov	dph,r4
   B6F9 8D F0              3144 	mov	b,r5
   B6FB 12 6B 44           3145 	lcall	_stack_check_broadcast
   B6FE AB 82              3146 	mov	r3,dpl
   B700 15 81              3147 	dec	sp
   B702 D0 07              3148 	pop	ar7
   B704 D0 06              3149 	pop	ar6
   B706 D0 05              3150 	pop	ar5
                           3151 ;	genCmpEq
                           3152 ;	gencjne
                           3153 ;	gencjneshort
                           3154 ;	Peephole 241.d	optimized compare
   B708 E4                 3155 	clr	a
   B709 BB 01 01           3156 	cjne	r3,#0x01,00209$
   B70C 04                 3157 	inc	a
   B70D                    3158 00209$:
                           3159 ;	Peephole 300	removed redundant label 00210$
                           3160 ;	genIpop
   B70D D0 07              3161 	pop	ar7
   B70F D0 06              3162 	pop	ar6
   B711 D0 05              3163 	pop	ar5
                           3164 ;	genIfx
                           3165 ;	genIfxJump
                           3166 ;	Peephole 108.b	removed ljmp by inverse jump logic
   B713 70 04              3167 	jnz	00113$
                           3168 ;	Peephole 300	removed redundant label 00211$
                           3169 ;	../../Common/modules/cIPv6.c:427: address_mode = NOT_OWN;
                           3170 ;	genAssign
   B715 7A C2              3171 	mov	r2,#0xC2
                           3172 ;	Peephole 112.b	changed ljmp to sjmp
   B717 80 02              3173 	sjmp	00119$
   B719                    3174 00113$:
                           3175 ;	../../Common/modules/cIPv6.c:432: address_mode = BCAST;
                           3176 ;	genAssign
   B719 7A C0              3177 	mov	r2,#0xC0
   B71B                    3178 00119$:
                           3179 ;	../../Common/modules/cIPv6.c:436: switch (address_mode)
                           3180 ;	genCmpEq
   B71B E5 10              3181 	mov	a,_bp
   B71D 24 1E              3182 	add	a,#0x1e
   B71F F8                 3183 	mov	r0,a
                           3184 ;	gencjne
                           3185 ;	gencjneshort
                           3186 ;	Peephole 241.d	optimized compare
   B720 E4                 3187 	clr	a
   B721 BA C0 01           3188 	cjne	r2,#0xC0,00212$
   B724 04                 3189 	inc	a
   B725                    3190 00212$:
                           3191 ;	Peephole 300	removed redundant label 00213$
   B725 F6                 3192 	mov	@r0,a
                           3193 ;	genIfx
   B726 E5 10              3194 	mov	a,_bp
   B728 24 1E              3195 	add	a,#0x1e
   B72A F8                 3196 	mov	r0,a
   B72B E6                 3197 	mov	a,@r0
                           3198 ;	genIfxJump
                           3199 ;	Peephole 108.b	removed ljmp by inverse jump logic
   B72C 70 08              3200 	jnz	00121$
                           3201 ;	Peephole 300	removed redundant label 00214$
                           3202 ;	genCmpEq
                           3203 ;	gencjneshort
   B72E BA C1 02           3204 	cjne	r2,#0xC1,00215$
   B731 80 03              3205 	sjmp	00216$
   B733                    3206 00215$:
   B733 02 BB 74           3207 	ljmp	00150$
   B736                    3208 00216$:
                           3209 ;	../../Common/modules/cIPv6.c:439: case BCAST:
   B736                    3210 00121$:
                           3211 ;	../../Common/modules/cIPv6.c:441: lowpan_dispatch = buf->buf[ind++];
                           3212 ;	genIpush
                           3213 ;	genPlus
   B736 A8 10              3214 	mov	r0,_bp
   B738 08                 3215 	inc	r0
   B739 E5 10              3216 	mov	a,_bp
   B73B 24 1B              3217 	add	a,#0x1b
   B73D F9                 3218 	mov	r1,a
                           3219 ;     genPlusIncr
   B73E 74 2C              3220 	mov	a,#0x2C
   B740 26                 3221 	add	a,@r0
   B741 F7                 3222 	mov	@r1,a
                           3223 ;	Peephole 181	changed mov to clr
   B742 E4                 3224 	clr	a
   B743 08                 3225 	inc	r0
   B744 36                 3226 	addc	a,@r0
   B745 09                 3227 	inc	r1
   B746 F7                 3228 	mov	@r1,a
   B747 08                 3229 	inc	r0
   B748 09                 3230 	inc	r1
   B749 E6                 3231 	mov	a,@r0
   B74A F7                 3232 	mov	@r1,a
                           3233 ;	genAssign
   B74B E5 10              3234 	mov	a,_bp
   B74D 24 06              3235 	add	a,#0x06
   B74F F8                 3236 	mov	r0,a
   B750 86 02              3237 	mov	ar2,@r0
                           3238 ;	genPlus
   B752 E5 10              3239 	mov	a,_bp
   B754 24 06              3240 	add	a,#0x06
   B756 F8                 3241 	mov	r0,a
                           3242 ;     genPlusIncr
   B757 06                 3243 	inc	@r0
                           3244 ;	genPlus
   B758 E5 10              3245 	mov	a,_bp
   B75A 24 1B              3246 	add	a,#0x1b
   B75C F8                 3247 	mov	r0,a
                           3248 ;	Peephole 236.g	used r2 instead of ar2
   B75D EA                 3249 	mov	a,r2
   B75E 26                 3250 	add	a,@r0
   B75F FA                 3251 	mov	r2,a
                           3252 ;	Peephole 181	changed mov to clr
   B760 E4                 3253 	clr	a
   B761 08                 3254 	inc	r0
   B762 36                 3255 	addc	a,@r0
   B763 FB                 3256 	mov	r3,a
   B764 08                 3257 	inc	r0
   B765 86 04              3258 	mov	ar4,@r0
                           3259 ;	genPointerGet
                           3260 ;	genGenPointerGet
   B767 8A 82              3261 	mov	dpl,r2
   B769 8B 83              3262 	mov	dph,r3
   B76B 8C F0              3263 	mov	b,r4
   B76D 12 E4 9F           3264 	lcall	__gptrget
   B770 FA                 3265 	mov	r2,a
                           3266 ;	genAssign
   B771 8A 03              3267 	mov	ar3,r2
                           3268 ;	../../Common/modules/cIPv6.c:442: bc_seq=0;
                           3269 ;	genAssign
   B773 E5 10              3270 	mov	a,_bp
   B775 24 1B              3271 	add	a,#0x1b
   B777 F8                 3272 	mov	r0,a
   B778 76 00              3273 	mov	@r0,#0x00
                           3274 ;	../../Common/modules/cIPv6.c:443: if(lowpan_dispatch == LOWPAN_BC0)
                           3275 ;	genCmpEq
                           3276 ;	gencjne
                           3277 ;	gencjneshort
                           3278 ;	Peephole 241.d	optimized compare
   B77A E4                 3279 	clr	a
   B77B BB 09 01           3280 	cjne	r3,#0x09,00217$
   B77E 04                 3281 	inc	a
   B77F                    3282 00217$:
                           3283 ;	Peephole 300	removed redundant label 00218$
                           3284 ;	genIpop
                           3285 ;	genIfx
                           3286 ;	genIfxJump
                           3287 ;	Peephole 108.c	removed ljmp by inverse jump logic
   B77F 60 6A              3288 	jz	00123$
                           3289 ;	Peephole 300	removed redundant label 00219$
                           3290 ;	../../Common/modules/cIPv6.c:445: bc_seq = buf->buf[ind++];
                           3291 ;	genIpush
                           3292 ;	genPlus
   B781 A8 10              3293 	mov	r0,_bp
   B783 08                 3294 	inc	r0
   B784 E5 10              3295 	mov	a,_bp
   B786 24 17              3296 	add	a,#0x17
   B788 F9                 3297 	mov	r1,a
                           3298 ;     genPlusIncr
   B789 74 2C              3299 	mov	a,#0x2C
   B78B 26                 3300 	add	a,@r0
   B78C F7                 3301 	mov	@r1,a
                           3302 ;	Peephole 181	changed mov to clr
   B78D E4                 3303 	clr	a
   B78E 08                 3304 	inc	r0
   B78F 36                 3305 	addc	a,@r0
   B790 09                 3306 	inc	r1
   B791 F7                 3307 	mov	@r1,a
   B792 08                 3308 	inc	r0
   B793 09                 3309 	inc	r1
   B794 E6                 3310 	mov	a,@r0
   B795 F7                 3311 	mov	@r1,a
                           3312 ;	genAssign
   B796 E5 10              3313 	mov	a,_bp
   B798 24 06              3314 	add	a,#0x06
   B79A F8                 3315 	mov	r0,a
   B79B 86 02              3316 	mov	ar2,@r0
                           3317 ;	genPlus
   B79D E5 10              3318 	mov	a,_bp
   B79F 24 06              3319 	add	a,#0x06
   B7A1 F8                 3320 	mov	r0,a
                           3321 ;     genPlusIncr
   B7A2 06                 3322 	inc	@r0
                           3323 ;	genPlus
   B7A3 E5 10              3324 	mov	a,_bp
   B7A5 24 17              3325 	add	a,#0x17
   B7A7 F8                 3326 	mov	r0,a
                           3327 ;	Peephole 236.g	used r2 instead of ar2
   B7A8 EA                 3328 	mov	a,r2
   B7A9 26                 3329 	add	a,@r0
   B7AA FA                 3330 	mov	r2,a
                           3331 ;	Peephole 181	changed mov to clr
   B7AB E4                 3332 	clr	a
   B7AC 08                 3333 	inc	r0
   B7AD 36                 3334 	addc	a,@r0
   B7AE FB                 3335 	mov	r3,a
   B7AF 08                 3336 	inc	r0
   B7B0 86 04              3337 	mov	ar4,@r0
                           3338 ;	genPointerGet
                           3339 ;	genGenPointerGet
   B7B2 8A 82              3340 	mov	dpl,r2
   B7B4 8B 83              3341 	mov	dph,r3
   B7B6 8C F0              3342 	mov	b,r4
   B7B8 12 E4 9F           3343 	lcall	__gptrget
   B7BB FA                 3344 	mov	r2,a
                           3345 ;	genAssign
   B7BC E5 10              3346 	mov	a,_bp
   B7BE 24 1B              3347 	add	a,#0x1b
   B7C0 F8                 3348 	mov	r0,a
   B7C1 A6 02              3349 	mov	@r0,ar2
                           3350 ;	../../Common/modules/cIPv6.c:447: lowpan_dispatch = buf->buf[ind++];
                           3351 ;	genAssign
   B7C3 E5 10              3352 	mov	a,_bp
   B7C5 24 06              3353 	add	a,#0x06
   B7C7 F8                 3354 	mov	r0,a
   B7C8 86 02              3355 	mov	ar2,@r0
                           3356 ;	genPlus
   B7CA E5 10              3357 	mov	a,_bp
   B7CC 24 06              3358 	add	a,#0x06
   B7CE F8                 3359 	mov	r0,a
                           3360 ;     genPlusIncr
   B7CF 06                 3361 	inc	@r0
                           3362 ;	genPlus
   B7D0 E5 10              3363 	mov	a,_bp
   B7D2 24 17              3364 	add	a,#0x17
   B7D4 F8                 3365 	mov	r0,a
                           3366 ;	Peephole 236.g	used r2 instead of ar2
   B7D5 EA                 3367 	mov	a,r2
   B7D6 26                 3368 	add	a,@r0
   B7D7 FA                 3369 	mov	r2,a
                           3370 ;	Peephole 181	changed mov to clr
   B7D8 E4                 3371 	clr	a
   B7D9 08                 3372 	inc	r0
   B7DA 36                 3373 	addc	a,@r0
   B7DB FB                 3374 	mov	r3,a
   B7DC 08                 3375 	inc	r0
   B7DD 86 04              3376 	mov	ar4,@r0
                           3377 ;	genPointerGet
                           3378 ;	genGenPointerGet
   B7DF 8A 82              3379 	mov	dpl,r2
   B7E1 8B 83              3380 	mov	dph,r3
   B7E3 8C F0              3381 	mov	b,r4
   B7E5 12 E4 9F           3382 	lcall	__gptrget
   B7E8 FA                 3383 	mov	r2,a
                           3384 ;	genAssign
   B7E9 8A 03              3385 	mov	ar3,r2
                           3386 ;	../../Common/modules/cIPv6.c:583: buf=0;
                           3387 ;	genIpop
                           3388 ;	../../Common/modules/cIPv6.c:447: lowpan_dispatch = buf->buf[ind++];
   B7EB                    3389 00123$:
                           3390 ;	../../Common/modules/cIPv6.c:449: if(lowpan_dispatch == LOWPAN_HC1)
                           3391 ;	genCmpEq
                           3392 ;	gencjneshort
   B7EB BB 42 02           3393 	cjne	r3,#0x42,00220$
   B7EE 80 03              3394 	sjmp	00221$
   B7F0                    3395 00220$:
   B7F0 02 BB 74           3396 	ljmp	00150$
   B7F3                    3397 00221$:
                           3398 ;	../../Common/modules/cIPv6.c:452: hc1= buf->buf[ind++];
                           3399 ;	genIpush
                           3400 ;	genPlus
   B7F3 A8 10              3401 	mov	r0,_bp
   B7F5 08                 3402 	inc	r0
   B7F6 E5 10              3403 	mov	a,_bp
   B7F8 24 17              3404 	add	a,#0x17
   B7FA F9                 3405 	mov	r1,a
                           3406 ;     genPlusIncr
   B7FB 74 2C              3407 	mov	a,#0x2C
   B7FD 26                 3408 	add	a,@r0
   B7FE F7                 3409 	mov	@r1,a
                           3410 ;	Peephole 181	changed mov to clr
   B7FF E4                 3411 	clr	a
   B800 08                 3412 	inc	r0
   B801 36                 3413 	addc	a,@r0
   B802 09                 3414 	inc	r1
   B803 F7                 3415 	mov	@r1,a
   B804 08                 3416 	inc	r0
   B805 09                 3417 	inc	r1
   B806 E6                 3418 	mov	a,@r0
   B807 F7                 3419 	mov	@r1,a
                           3420 ;	genAssign
   B808 E5 10              3421 	mov	a,_bp
   B80A 24 06              3422 	add	a,#0x06
   B80C F8                 3423 	mov	r0,a
   B80D 86 02              3424 	mov	ar2,@r0
                           3425 ;	genPlus
   B80F E5 10              3426 	mov	a,_bp
   B811 24 06              3427 	add	a,#0x06
   B813 F8                 3428 	mov	r0,a
                           3429 ;     genPlusIncr
   B814 06                 3430 	inc	@r0
                           3431 ;	genPlus
   B815 E5 10              3432 	mov	a,_bp
   B817 24 17              3433 	add	a,#0x17
   B819 F8                 3434 	mov	r0,a
                           3435 ;	Peephole 236.g	used r2 instead of ar2
   B81A EA                 3436 	mov	a,r2
   B81B 26                 3437 	add	a,@r0
   B81C FA                 3438 	mov	r2,a
                           3439 ;	Peephole 181	changed mov to clr
   B81D E4                 3440 	clr	a
   B81E 08                 3441 	inc	r0
   B81F 36                 3442 	addc	a,@r0
   B820 FB                 3443 	mov	r3,a
   B821 08                 3444 	inc	r0
   B822 86 04              3445 	mov	ar4,@r0
                           3446 ;	genPointerGet
                           3447 ;	genGenPointerGet
   B824 8A 82              3448 	mov	dpl,r2
   B826 8B 83              3449 	mov	dph,r3
   B828 8C F0              3450 	mov	b,r4
   B82A 12 E4 9F           3451 	lcall	__gptrget
   B82D FA                 3452 	mov	r2,a
                           3453 ;	genAssign
                           3454 ;	../../Common/modules/cIPv6.c:453: if((hc1 == HC1_NEXT_HEADER_COMPRESSED_UDP || hc1 == HC1_NEXT_HEADER_UNCOMPRES_UDP) || hc1 == IP_HEADER_FOR_ICMP)
                           3455 ;	genCmpEq
   B82E E5 10              3456 	mov	a,_bp
   B830 24 1A              3457 	add	a,#0x1a
   B832 F8                 3458 	mov	r0,a
                           3459 ;	gencjne
                           3460 ;	gencjneshort
                           3461 ;	Peephole 241.d	optimized compare
   B833 E4                 3462 	clr	a
   B834 BA BF 01           3463 	cjne	r2,#0xBF,00222$
   B837 04                 3464 	inc	a
   B838                    3465 00222$:
                           3466 ;	Peephole 300	removed redundant label 00223$
   B838 F6                 3467 	mov	@r0,a
                           3468 ;	genIpop
                           3469 ;	genIfx
   B839 E5 10              3470 	mov	a,_bp
   B83B 24 1A              3471 	add	a,#0x1a
   B83D F8                 3472 	mov	r0,a
   B83E E6                 3473 	mov	a,@r0
                           3474 ;	genIfxJump
                           3475 ;	Peephole 108.b	removed ljmp by inverse jump logic
   B83F 70 0D              3476 	jnz	00143$
                           3477 ;	Peephole 300	removed redundant label 00224$
                           3478 ;	genCmpEq
                           3479 ;	gencjneshort
   B841 BA 3F 02           3480 	cjne	r2,#0x3F,00225$
                           3481 ;	Peephole 112.b	changed ljmp to sjmp
   B844 80 08              3482 	sjmp	00143$
   B846                    3483 00225$:
                           3484 ;	genCmpEq
                           3485 ;	gencjneshort
   B846 BA 5F 02           3486 	cjne	r2,#0x5F,00226$
   B849 80 03              3487 	sjmp	00227$
   B84B                    3488 00226$:
   B84B 02 BB 74           3489 	ljmp	00150$
   B84E                    3490 00227$:
   B84E                    3491 00143$:
                           3492 ;	../../Common/modules/cIPv6.c:455: if(hc1 == IP_HEADER_FOR_ICMP)
                           3493 ;	genCmpEq
                           3494 ;	gencjne
                           3495 ;	gencjneshort
                           3496 ;	Peephole 241.d	optimized compare
   B84E E4                 3497 	clr	a
   B84F BA 5F 01           3498 	cjne	r2,#0x5F,00228$
   B852 04                 3499 	inc	a
   B853                    3500 00228$:
                           3501 ;	Peephole 300	removed redundant label 00229$
                           3502 ;	genIfx
   B853 FA                 3503 	mov	r2,a
                           3504 ;	Peephole 105	removed redundant mov
                           3505 ;	genIfxJump
                           3506 ;	Peephole 108.c	removed ljmp by inverse jump logic
   B854 60 20              3507 	jz	00127$
                           3508 ;	Peephole 300	removed redundant label 00230$
                           3509 ;	../../Common/modules/cIPv6.c:457: buf->to = MODULE_ICMP;
                           3510 ;	genIpush
   B856 C0 02              3511 	push	ar2
                           3512 ;	genPlus
   B858 A8 10              3513 	mov	r0,_bp
   B85A 08                 3514 	inc	r0
                           3515 ;     genPlusIncr
   B85B 74 1E              3516 	mov	a,#0x1E
   B85D 26                 3517 	add	a,@r0
   B85E FC                 3518 	mov	r4,a
                           3519 ;	Peephole 181	changed mov to clr
   B85F E4                 3520 	clr	a
   B860 08                 3521 	inc	r0
   B861 36                 3522 	addc	a,@r0
   B862 FA                 3523 	mov	r2,a
   B863 08                 3524 	inc	r0
   B864 86 03              3525 	mov	ar3,@r0
                           3526 ;	genPointerSet
                           3527 ;	genGenPointerSet
   B866 8C 82              3528 	mov	dpl,r4
   B868 8A 83              3529 	mov	dph,r2
   B86A 8B F0              3530 	mov	b,r3
   B86C 74 04              3531 	mov	a,#0x04
   B86E 12 DF B7           3532 	lcall	__gptrput
                           3533 ;	genIpop
   B871 D0 02              3534 	pop	ar2
   B873 02 B9 09           3535 	ljmp	00128$
   B876                    3536 00127$:
                           3537 ;	../../Common/modules/cIPv6.c:461: buf->to = MODULE_CUDP;
                           3538 ;	genIpush
   B876 C0 02              3539 	push	ar2
                           3540 ;	genPlus
   B878 A8 10              3541 	mov	r0,_bp
   B87A 08                 3542 	inc	r0
                           3543 ;     genPlusIncr
   B87B 74 1E              3544 	mov	a,#0x1E
   B87D 26                 3545 	add	a,@r0
   B87E FB                 3546 	mov	r3,a
                           3547 ;	Peephole 181	changed mov to clr
   B87F E4                 3548 	clr	a
   B880 08                 3549 	inc	r0
   B881 36                 3550 	addc	a,@r0
   B882 FC                 3551 	mov	r4,a
   B883 08                 3552 	inc	r0
   B884 86 02              3553 	mov	ar2,@r0
                           3554 ;	genPointerSet
                           3555 ;	genGenPointerSet
   B886 8B 82              3556 	mov	dpl,r3
   B888 8C 83              3557 	mov	dph,r4
   B88A 8A F0              3558 	mov	b,r2
   B88C 74 02              3559 	mov	a,#0x02
   B88E 12 DF B7           3560 	lcall	__gptrput
                           3561 ;	../../Common/modules/cIPv6.c:462: if(hc1 == HC1_NEXT_HEADER_COMPRESSED_UDP) /* Read udp encode field */
                           3562 ;	genIpop
   B891 D0 02              3563 	pop	ar2
                           3564 ;	genIfx
   B893 E5 10              3565 	mov	a,_bp
   B895 24 1A              3566 	add	a,#0x1a
   B897 F8                 3567 	mov	r0,a
   B898 E6                 3568 	mov	a,@r0
                           3569 ;	genIfxJump
                           3570 ;	Peephole 108.c	removed ljmp by inverse jump logic
   B899 60 6E              3571 	jz	00128$
                           3572 ;	Peephole 300	removed redundant label 00231$
                           3573 ;	../../Common/modules/cIPv6.c:464: buf->options.lowpan_compressed = buf->buf[ind++];
                           3574 ;	genIpush
   B89B C0 02              3575 	push	ar2
                           3576 ;	genPlus
   B89D A8 10              3577 	mov	r0,_bp
   B89F 08                 3578 	inc	r0
                           3579 ;     genPlusIncr
   B8A0 74 26              3580 	mov	a,#0x26
   B8A2 26                 3581 	add	a,@r0
   B8A3 FB                 3582 	mov	r3,a
                           3583 ;	Peephole 181	changed mov to clr
   B8A4 E4                 3584 	clr	a
   B8A5 08                 3585 	inc	r0
   B8A6 36                 3586 	addc	a,@r0
   B8A7 FC                 3587 	mov	r4,a
   B8A8 08                 3588 	inc	r0
   B8A9 86 02              3589 	mov	ar2,@r0
                           3590 ;	genPlus
   B8AB E5 10              3591 	mov	a,_bp
   B8AD 24 17              3592 	add	a,#0x17
   B8AF F8                 3593 	mov	r0,a
                           3594 ;     genPlusIncr
   B8B0 74 05              3595 	mov	a,#0x05
                           3596 ;	Peephole 236.a	used r3 instead of ar3
   B8B2 2B                 3597 	add	a,r3
   B8B3 F6                 3598 	mov	@r0,a
                           3599 ;	Peephole 181	changed mov to clr
   B8B4 E4                 3600 	clr	a
                           3601 ;	Peephole 236.b	used r4 instead of ar4
   B8B5 3C                 3602 	addc	a,r4
   B8B6 08                 3603 	inc	r0
   B8B7 F6                 3604 	mov	@r0,a
   B8B8 08                 3605 	inc	r0
   B8B9 A6 02              3606 	mov	@r0,ar2
                           3607 ;	genPlus
   B8BB A8 10              3608 	mov	r0,_bp
   B8BD 08                 3609 	inc	r0
   B8BE E5 10              3610 	mov	a,_bp
   B8C0 24 1F              3611 	add	a,#0x1f
   B8C2 F9                 3612 	mov	r1,a
                           3613 ;     genPlusIncr
   B8C3 74 2C              3614 	mov	a,#0x2C
   B8C5 26                 3615 	add	a,@r0
   B8C6 F7                 3616 	mov	@r1,a
                           3617 ;	Peephole 181	changed mov to clr
   B8C7 E4                 3618 	clr	a
   B8C8 08                 3619 	inc	r0
   B8C9 36                 3620 	addc	a,@r0
   B8CA 09                 3621 	inc	r1
   B8CB F7                 3622 	mov	@r1,a
   B8CC 08                 3623 	inc	r0
   B8CD 09                 3624 	inc	r1
   B8CE E6                 3625 	mov	a,@r0
   B8CF F7                 3626 	mov	@r1,a
                           3627 ;	genAssign
   B8D0 E5 10              3628 	mov	a,_bp
   B8D2 24 06              3629 	add	a,#0x06
   B8D4 F8                 3630 	mov	r0,a
   B8D5 86 02              3631 	mov	ar2,@r0
                           3632 ;	genPlus
   B8D7 E5 10              3633 	mov	a,_bp
   B8D9 24 06              3634 	add	a,#0x06
   B8DB F8                 3635 	mov	r0,a
                           3636 ;     genPlusIncr
   B8DC 06                 3637 	inc	@r0
                           3638 ;	genPlus
   B8DD E5 10              3639 	mov	a,_bp
   B8DF 24 1F              3640 	add	a,#0x1f
   B8E1 F8                 3641 	mov	r0,a
                           3642 ;	Peephole 236.g	used r2 instead of ar2
   B8E2 EA                 3643 	mov	a,r2
   B8E3 26                 3644 	add	a,@r0
   B8E4 FA                 3645 	mov	r2,a
                           3646 ;	Peephole 181	changed mov to clr
   B8E5 E4                 3647 	clr	a
   B8E6 08                 3648 	inc	r0
   B8E7 36                 3649 	addc	a,@r0
   B8E8 FB                 3650 	mov	r3,a
   B8E9 08                 3651 	inc	r0
   B8EA 86 04              3652 	mov	ar4,@r0
                           3653 ;	genPointerGet
                           3654 ;	genGenPointerGet
   B8EC 8A 82              3655 	mov	dpl,r2
   B8EE 8B 83              3656 	mov	dph,r3
   B8F0 8C F0              3657 	mov	b,r4
   B8F2 12 E4 9F           3658 	lcall	__gptrget
   B8F5 FA                 3659 	mov	r2,a
                           3660 ;	genPointerSet
                           3661 ;	genGenPointerSet
   B8F6 E5 10              3662 	mov	a,_bp
   B8F8 24 17              3663 	add	a,#0x17
   B8FA F8                 3664 	mov	r0,a
   B8FB 86 82              3665 	mov	dpl,@r0
   B8FD 08                 3666 	inc	r0
   B8FE 86 83              3667 	mov	dph,@r0
   B900 08                 3668 	inc	r0
   B901 86 F0              3669 	mov	b,@r0
   B903 EA                 3670 	mov	a,r2
   B904 12 DF B7           3671 	lcall	__gptrput
                           3672 ;	../../Common/modules/cIPv6.c:583: buf=0;
                           3673 ;	genIpop
   B907 D0 02              3674 	pop	ar2
                           3675 ;	../../Common/modules/cIPv6.c:464: buf->options.lowpan_compressed = buf->buf[ind++];
   B909                    3676 00128$:
                           3677 ;	../../Common/modules/cIPv6.c:467: hoplimit= buf->buf[ind];
                           3678 ;	genIpush
   B909 C0 05              3679 	push	ar5
   B90B C0 06              3680 	push	ar6
   B90D C0 07              3681 	push	ar7
                           3682 ;	genPlus
   B90F A8 10              3683 	mov	r0,_bp
   B911 08                 3684 	inc	r0
                           3685 ;     genPlusIncr
   B912 74 2C              3686 	mov	a,#0x2C
   B914 26                 3687 	add	a,@r0
   B915 FB                 3688 	mov	r3,a
                           3689 ;	Peephole 181	changed mov to clr
   B916 E4                 3690 	clr	a
   B917 08                 3691 	inc	r0
   B918 36                 3692 	addc	a,@r0
   B919 FC                 3693 	mov	r4,a
   B91A 08                 3694 	inc	r0
   B91B 86 05              3695 	mov	ar5,@r0
                           3696 ;	genPlus
   B91D E5 10              3697 	mov	a,_bp
   B91F 24 06              3698 	add	a,#0x06
   B921 F8                 3699 	mov	r0,a
   B922 E6                 3700 	mov	a,@r0
                           3701 ;	Peephole 236.a	used r3 instead of ar3
   B923 2B                 3702 	add	a,r3
   B924 FB                 3703 	mov	r3,a
                           3704 ;	Peephole 181	changed mov to clr
   B925 E4                 3705 	clr	a
                           3706 ;	Peephole 236.b	used r4 instead of ar4
   B926 3C                 3707 	addc	a,r4
   B927 FC                 3708 	mov	r4,a
                           3709 ;	genPointerGet
                           3710 ;	genGenPointerGet
   B928 8B 82              3711 	mov	dpl,r3
   B92A 8C 83              3712 	mov	dph,r4
   B92C 8D F0              3713 	mov	b,r5
   B92E 12 E4 9F           3714 	lcall	__gptrget
   B931 FE                 3715 	mov	r6,a
                           3716 ;	genAssign
   B932 E5 10              3717 	mov	a,_bp
   B934 24 07              3718 	add	a,#0x07
   B936 F8                 3719 	mov	r0,a
   B937 A6 06              3720 	mov	@r0,ar6
                           3721 ;	../../Common/modules/cIPv6.c:468: hoplimit--;
                           3722 ;	genMinus
   B939 E5 10              3723 	mov	a,_bp
   B93B 24 07              3724 	add	a,#0x07
   B93D F8                 3725 	mov	r0,a
                           3726 ;	genMinusDec
   B93E 16                 3727 	dec	@r0
                           3728 ;	../../Common/modules/cIPv6.c:469: buf->buf[ind] = hoplimit;
                           3729 ;	genPointerSet
                           3730 ;	genGenPointerSet
   B93F 8B 82              3731 	mov	dpl,r3
   B941 8C 83              3732 	mov	dph,r4
   B943 8D F0              3733 	mov	b,r5
   B945 E5 10              3734 	mov	a,_bp
   B947 24 07              3735 	add	a,#0x07
   B949 F8                 3736 	mov	r0,a
   B94A E6                 3737 	mov	a,@r0
   B94B 12 DF B7           3738 	lcall	__gptrput
                           3739 ;	../../Common/modules/cIPv6.c:470: ind++;
                           3740 ;	genPlus
   B94E E5 10              3741 	mov	a,_bp
   B950 24 06              3742 	add	a,#0x06
   B952 F8                 3743 	mov	r0,a
                           3744 ;     genPlusIncr
   B953 06                 3745 	inc	@r0
                           3746 ;	../../Common/modules/cIPv6.c:471: hops_to_ori = (GENERAL_HOPLIMIT - hoplimit);
                           3747 ;	genMinus
   B954 E5 10              3748 	mov	a,_bp
   B956 24 07              3749 	add	a,#0x07
   B958 F8                 3750 	mov	r0,a
   B959 E5 10              3751 	mov	a,_bp
   B95B 24 08              3752 	add	a,#0x08
   B95D F9                 3753 	mov	r1,a
   B95E 74 16              3754 	mov	a,#0x16
   B960 C3                 3755 	clr	c
   B961 96                 3756 	subb	a,@r0
   B962 F7                 3757 	mov	@r1,a
                           3758 ;	../../Common/modules/cIPv6.c:472: if(hc1 == IP_HEADER_FOR_ICMP) 
                           3759 ;	genIpop
   B963 D0 07              3760 	pop	ar7
   B965 D0 06              3761 	pop	ar6
   B967 D0 05              3762 	pop	ar5
                           3763 ;	genIfx
   B969 EA                 3764 	mov	a,r2
                           3765 ;	genIfxJump
                           3766 ;	Peephole 108.c	removed ljmp by inverse jump logic
   B96A 60 24              3767 	jz	00130$
                           3768 ;	Peephole 300	removed redundant label 00232$
                           3769 ;	../../Common/modules/cIPv6.c:473: buf->options.hop_count = hops_to_ori;
                           3770 ;	genPlus
   B96C A8 10              3771 	mov	r0,_bp
   B96E 08                 3772 	inc	r0
                           3773 ;     genPlusIncr
   B96F 74 26              3774 	mov	a,#0x26
   B971 26                 3775 	add	a,@r0
   B972 FA                 3776 	mov	r2,a
                           3777 ;	Peephole 181	changed mov to clr
   B973 E4                 3778 	clr	a
   B974 08                 3779 	inc	r0
   B975 36                 3780 	addc	a,@r0
   B976 FB                 3781 	mov	r3,a
   B977 08                 3782 	inc	r0
   B978 86 04              3783 	mov	ar4,@r0
                           3784 ;	genPlus
                           3785 ;     genPlusIncr
   B97A 74 04              3786 	mov	a,#0x04
                           3787 ;	Peephole 236.a	used r2 instead of ar2
   B97C 2A                 3788 	add	a,r2
   B97D FA                 3789 	mov	r2,a
                           3790 ;	Peephole 181	changed mov to clr
   B97E E4                 3791 	clr	a
                           3792 ;	Peephole 236.b	used r3 instead of ar3
   B97F 3B                 3793 	addc	a,r3
   B980 FB                 3794 	mov	r3,a
                           3795 ;	genPointerSet
                           3796 ;	genGenPointerSet
   B981 8A 82              3797 	mov	dpl,r2
   B983 8B 83              3798 	mov	dph,r3
   B985 8C F0              3799 	mov	b,r4
   B987 E5 10              3800 	mov	a,_bp
   B989 24 08              3801 	add	a,#0x08
   B98B F8                 3802 	mov	r0,a
   B98C E6                 3803 	mov	a,@r0
   B98D 12 DF B7           3804 	lcall	__gptrput
   B990                    3805 00130$:
                           3806 ;	../../Common/modules/cIPv6.c:495: if(o_addrtype == ADDR_802_15_4_PAN_LONG)
                           3807 ;	genCmpEq
   B990 E5 10              3808 	mov	a,_bp
   B992 24 09              3809 	add	a,#0x09
   B994 F8                 3810 	mov	r0,a
                           3811 ;	gencjneshort
                           3812 ;	Peephole 112.b	changed ljmp to sjmp
                           3813 ;	Peephole 198.b	optimized misc jump sequence
   B995 B6 04 54           3814 	cjne	@r0,#0x04,00132$
                           3815 ;	Peephole 200.b	removed redundant sjmp
                           3816 ;	Peephole 300	removed redundant label 00233$
                           3817 ;	Peephole 300	removed redundant label 00234$
                           3818 ;	../../Common/modules/cIPv6.c:496: memcpy(buf->src_sa.address,ori_address, 8);
                           3819 ;	genIpush
   B998 C0 05              3820 	push	ar5
   B99A C0 06              3821 	push	ar6
   B99C C0 07              3822 	push	ar7
                           3823 ;	genAssign
   B99E E5 10              3824 	mov	a,_bp
   B9A0 24 14              3825 	add	a,#0x14
   B9A2 F8                 3826 	mov	r0,a
   B9A3 86 02              3827 	mov	ar2,@r0
                           3828 ;	genCast
   B9A5 7B 00              3829 	mov	r3,#0x00
   B9A7 7C 40              3830 	mov	r4,#0x40
                           3831 ;	genPlus
   B9A9 A8 10              3832 	mov	r0,_bp
   B9AB 08                 3833 	inc	r0
                           3834 ;     genPlusIncr
   B9AC 74 10              3835 	mov	a,#0x10
   B9AE 26                 3836 	add	a,@r0
   B9AF FD                 3837 	mov	r5,a
                           3838 ;	Peephole 181	changed mov to clr
   B9B0 E4                 3839 	clr	a
   B9B1 08                 3840 	inc	r0
   B9B2 36                 3841 	addc	a,@r0
   B9B3 FE                 3842 	mov	r6,a
   B9B4 08                 3843 	inc	r0
   B9B5 86 07              3844 	mov	ar7,@r0
                           3845 ;	genPlus
                           3846 ;     genPlusIncr
   B9B7 0D                 3847 	inc	r5
   B9B8 BD 00 01           3848 	cjne	r5,#0x00,00235$
   B9BB 0E                 3849 	inc	r6
   B9BC                    3850 00235$:
                           3851 ;	genIpush
   B9BC C0 05              3852 	push	ar5
   B9BE C0 06              3853 	push	ar6
   B9C0 C0 07              3854 	push	ar7
   B9C2 74 08              3855 	mov	a,#0x08
   B9C4 C0 E0              3856 	push	acc
                           3857 ;	Peephole 181	changed mov to clr
   B9C6 E4                 3858 	clr	a
   B9C7 C0 E0              3859 	push	acc
                           3860 ;	genIpush
   B9C9 C0 02              3861 	push	ar2
   B9CB C0 03              3862 	push	ar3
   B9CD C0 04              3863 	push	ar4
                           3864 ;	genCall
   B9CF 8D 82              3865 	mov	dpl,r5
   B9D1 8E 83              3866 	mov	dph,r6
   B9D3 8F F0              3867 	mov	b,r7
   B9D5 12 E2 C7           3868 	lcall	_memcpy
   B9D8 E5 81              3869 	mov	a,sp
   B9DA 24 FB              3870 	add	a,#0xfb
   B9DC F5 81              3871 	mov	sp,a
   B9DE D0 07              3872 	pop	ar7
   B9E0 D0 06              3873 	pop	ar6
   B9E2 D0 05              3874 	pop	ar5
                           3875 ;	genIpop
   B9E4 D0 07              3876 	pop	ar7
   B9E6 D0 06              3877 	pop	ar6
   B9E8 D0 05              3878 	pop	ar5
                           3879 ;	Peephole 112.b	changed ljmp to sjmp
   B9EA 80 52              3880 	sjmp	00133$
   B9EC                    3881 00132$:
                           3882 ;	../../Common/modules/cIPv6.c:498: memcpy(buf->src_sa.address,ori_address, 2);
                           3883 ;	genIpush
   B9EC C0 05              3884 	push	ar5
   B9EE C0 06              3885 	push	ar6
   B9F0 C0 07              3886 	push	ar7
                           3887 ;	genAssign
   B9F2 E5 10              3888 	mov	a,_bp
   B9F4 24 14              3889 	add	a,#0x14
   B9F6 F8                 3890 	mov	r0,a
   B9F7 86 02              3891 	mov	ar2,@r0
                           3892 ;	genCast
   B9F9 7B 00              3893 	mov	r3,#0x00
   B9FB 7C 40              3894 	mov	r4,#0x40
                           3895 ;	genPlus
   B9FD A8 10              3896 	mov	r0,_bp
   B9FF 08                 3897 	inc	r0
                           3898 ;     genPlusIncr
   BA00 74 10              3899 	mov	a,#0x10
   BA02 26                 3900 	add	a,@r0
   BA03 FD                 3901 	mov	r5,a
                           3902 ;	Peephole 181	changed mov to clr
   BA04 E4                 3903 	clr	a
   BA05 08                 3904 	inc	r0
   BA06 36                 3905 	addc	a,@r0
   BA07 FE                 3906 	mov	r6,a
   BA08 08                 3907 	inc	r0
   BA09 86 07              3908 	mov	ar7,@r0
                           3909 ;	genPlus
                           3910 ;     genPlusIncr
   BA0B 0D                 3911 	inc	r5
   BA0C BD 00 01           3912 	cjne	r5,#0x00,00236$
   BA0F 0E                 3913 	inc	r6
   BA10                    3914 00236$:
                           3915 ;	genIpush
   BA10 C0 05              3916 	push	ar5
   BA12 C0 06              3917 	push	ar6
   BA14 C0 07              3918 	push	ar7
   BA16 74 02              3919 	mov	a,#0x02
   BA18 C0 E0              3920 	push	acc
                           3921 ;	Peephole 181	changed mov to clr
   BA1A E4                 3922 	clr	a
   BA1B C0 E0              3923 	push	acc
                           3924 ;	genIpush
   BA1D C0 02              3925 	push	ar2
   BA1F C0 03              3926 	push	ar3
   BA21 C0 04              3927 	push	ar4
                           3928 ;	genCall
   BA23 8D 82              3929 	mov	dpl,r5
   BA25 8E 83              3930 	mov	dph,r6
   BA27 8F F0              3931 	mov	b,r7
   BA29 12 E2 C7           3932 	lcall	_memcpy
   BA2C E5 81              3933 	mov	a,sp
   BA2E 24 FB              3934 	add	a,#0xfb
   BA30 F5 81              3935 	mov	sp,a
   BA32 D0 07              3936 	pop	ar7
   BA34 D0 06              3937 	pop	ar6
   BA36 D0 05              3938 	pop	ar5
                           3939 ;	../../Common/modules/cIPv6.c:583: buf=0;
                           3940 ;	genIpop
   BA38 D0 07              3941 	pop	ar7
   BA3A D0 06              3942 	pop	ar6
   BA3C D0 05              3943 	pop	ar5
                           3944 ;	../../Common/modules/cIPv6.c:498: memcpy(buf->src_sa.address,ori_address, 2);
   BA3E                    3945 00133$:
                           3946 ;	../../Common/modules/cIPv6.c:500: buf->src_sa.addr_type = o_addrtype;
                           3947 ;	genPlus
   BA3E A8 10              3948 	mov	r0,_bp
   BA40 08                 3949 	inc	r0
                           3950 ;     genPlusIncr
   BA41 74 10              3951 	mov	a,#0x10
   BA43 26                 3952 	add	a,@r0
   BA44 FA                 3953 	mov	r2,a
                           3954 ;	Peephole 181	changed mov to clr
   BA45 E4                 3955 	clr	a
   BA46 08                 3956 	inc	r0
   BA47 36                 3957 	addc	a,@r0
   BA48 FB                 3958 	mov	r3,a
   BA49 08                 3959 	inc	r0
   BA4A 86 04              3960 	mov	ar4,@r0
                           3961 ;	genPointerSet
                           3962 ;	genGenPointerSet
   BA4C 8A 82              3963 	mov	dpl,r2
   BA4E 8B 83              3964 	mov	dph,r3
   BA50 8C F0              3965 	mov	b,r4
   BA52 E5 10              3966 	mov	a,_bp
   BA54 24 09              3967 	add	a,#0x09
   BA56 F8                 3968 	mov	r0,a
   BA57 E6                 3969 	mov	a,@r0
   BA58 12 DF B7           3970 	lcall	__gptrput
                           3971 ;	../../Common/modules/cIPv6.c:501: if(address_mode == BCAST)
                           3972 ;	genIfx
   BA5B E5 10              3973 	mov	a,_bp
   BA5D 24 1E              3974 	add	a,#0x1e
   BA5F F8                 3975 	mov	r0,a
   BA60 E6                 3976 	mov	a,@r0
                           3977 ;	genIfxJump
   BA61 70 03              3978 	jnz	00237$
   BA63 02 BA EF           3979 	ljmp	00138$
   BA66                    3980 00237$:
                           3981 ;	../../Common/modules/cIPv6.c:504: if(bc_seq != cipv6_pib.last_forwarded_bc_sqn )
                           3982 ;	genPointerGet
                           3983 ;	genFarPointerGet
   BA66 90 F0 4E           3984 	mov	dptr,#(_cipv6_pib + 0x0001)
   BA69 E0                 3985 	movx	a,@dptr
   BA6A FA                 3986 	mov	r2,a
                           3987 ;	genCmpEq
   BA6B E5 10              3988 	mov	a,_bp
   BA6D 24 1B              3989 	add	a,#0x1b
   BA6F F8                 3990 	mov	r0,a
                           3991 ;	gencjneshort
   BA70 E6                 3992 	mov	a,@r0
   BA71 B5 02 02           3993 	cjne	a,ar2,00238$
                           3994 ;	Peephole 112.b	changed ljmp to sjmp
   BA74 80 62              3995 	sjmp	00135$
   BA76                    3996 00238$:
                           3997 ;	../../Common/modules/cIPv6.c:534: buf->buf_ptr = ind;
                           3998 ;	genCast
   BA76 E5 10              3999 	mov	a,_bp
   BA78 24 06              4000 	add	a,#0x06
   BA7A F8                 4001 	mov	r0,a
   BA7B 86 02              4002 	mov	ar2,@r0
   BA7D 7B 00              4003 	mov	r3,#0x00
                           4004 ;	genPointerSet
                           4005 ;	genGenPointerSet
   BA7F 8D 82              4006 	mov	dpl,r5
   BA81 8E 83              4007 	mov	dph,r6
   BA83 8F F0              4008 	mov	b,r7
   BA85 EA                 4009 	mov	a,r2
   BA86 12 DF B7           4010 	lcall	__gptrput
   BA89 A3                 4011 	inc	dptr
   BA8A EB                 4012 	mov	a,r3
   BA8B 12 DF B7           4013 	lcall	__gptrput
                           4014 ;	../../Common/modules/cIPv6.c:535: buf->to = MODULE_NONE;
                           4015 ;	genPlus
   BA8E A8 10              4016 	mov	r0,_bp
   BA90 08                 4017 	inc	r0
                           4018 ;     genPlusIncr
   BA91 74 1E              4019 	mov	a,#0x1E
   BA93 26                 4020 	add	a,@r0
   BA94 FA                 4021 	mov	r2,a
                           4022 ;	Peephole 181	changed mov to clr
   BA95 E4                 4023 	clr	a
   BA96 08                 4024 	inc	r0
   BA97 36                 4025 	addc	a,@r0
   BA98 FB                 4026 	mov	r3,a
   BA99 08                 4027 	inc	r0
   BA9A 86 04              4028 	mov	ar4,@r0
                           4029 ;	genPointerSet
                           4030 ;	genGenPointerSet
   BA9C 8A 82              4031 	mov	dpl,r2
   BA9E 8B 83              4032 	mov	dph,r3
   BAA0 8C F0              4033 	mov	b,r4
                           4034 ;	Peephole 181	changed mov to clr
   BAA2 E4                 4035 	clr	a
   BAA3 12 DF B7           4036 	lcall	__gptrput
                           4037 ;	../../Common/modules/cIPv6.c:536: buf->from = MODULE_CIPV6;
                           4038 ;	genPlus
   BAA6 A8 10              4039 	mov	r0,_bp
   BAA8 08                 4040 	inc	r0
                           4041 ;     genPlusIncr
   BAA9 74 1D              4042 	mov	a,#0x1D
   BAAB 26                 4043 	add	a,@r0
   BAAC FA                 4044 	mov	r2,a
                           4045 ;	Peephole 181	changed mov to clr
   BAAD E4                 4046 	clr	a
   BAAE 08                 4047 	inc	r0
   BAAF 36                 4048 	addc	a,@r0
   BAB0 FB                 4049 	mov	r3,a
   BAB1 08                 4050 	inc	r0
   BAB2 86 04              4051 	mov	ar4,@r0
                           4052 ;	genPointerSet
                           4053 ;	genGenPointerSet
   BAB4 8A 82              4054 	mov	dpl,r2
   BAB6 8B 83              4055 	mov	dph,r3
   BAB8 8C F0              4056 	mov	b,r4
   BABA 74 01              4057 	mov	a,#0x01
   BABC 12 DF B7           4058 	lcall	__gptrput
                           4059 ;	../../Common/modules/cIPv6.c:537: stack_buffer_push(buf);
                           4060 ;	genCall
   BABF A8 10              4061 	mov	r0,_bp
   BAC1 08                 4062 	inc	r0
   BAC2 86 82              4063 	mov	dpl,@r0
   BAC4 08                 4064 	inc	r0
   BAC5 86 83              4065 	mov	dph,@r0
   BAC7 08                 4066 	inc	r0
   BAC8 86 F0              4067 	mov	b,@r0
   BACA 12 62 C4           4068 	lcall	_stack_buffer_push
                           4069 ;	../../Common/modules/cIPv6.c:538: buf=0;
                           4070 ;	genAssign
   BACD A8 10              4071 	mov	r0,_bp
   BACF 08                 4072 	inc	r0
   BAD0 E4                 4073 	clr	a
   BAD1 F6                 4074 	mov	@r0,a
   BAD2 08                 4075 	inc	r0
   BAD3 F6                 4076 	mov	@r0,a
   BAD4 08                 4077 	inc	r0
   BAD5 F6                 4078 	mov	@r0,a
                           4079 ;	Peephole 112.b	changed ljmp to sjmp
   BAD6 80 17              4080 	sjmp	00138$
   BAD8                    4081 00135$:
                           4082 ;	../../Common/modules/cIPv6.c:542: stack_buffer_free(buf);
                           4083 ;	genCall
   BAD8 A8 10              4084 	mov	r0,_bp
   BADA 08                 4085 	inc	r0
   BADB 86 82              4086 	mov	dpl,@r0
   BADD 08                 4087 	inc	r0
   BADE 86 83              4088 	mov	dph,@r0
   BAE0 08                 4089 	inc	r0
   BAE1 86 F0              4090 	mov	b,@r0
   BAE3 12 61 FA           4091 	lcall	_stack_buffer_free
                           4092 ;	../../Common/modules/cIPv6.c:543: buf=0;
                           4093 ;	genAssign
   BAE6 A8 10              4094 	mov	r0,_bp
   BAE8 08                 4095 	inc	r0
   BAE9 E4                 4096 	clr	a
   BAEA F6                 4097 	mov	@r0,a
   BAEB 08                 4098 	inc	r0
   BAEC F6                 4099 	mov	@r0,a
   BAED 08                 4100 	inc	r0
   BAEE F6                 4101 	mov	@r0,a
   BAEF                    4102 00138$:
                           4103 ;	../../Common/modules/cIPv6.c:546: if(buf)
                           4104 ;	genIfx
   BAEF A8 10              4105 	mov	r0,_bp
   BAF1 08                 4106 	inc	r0
   BAF2 E6                 4107 	mov	a,@r0
   BAF3 08                 4108 	inc	r0
   BAF4 46                 4109 	orl	a,@r0
   BAF5 08                 4110 	inc	r0
   BAF6 46                 4111 	orl	a,@r0
                           4112 ;	genIfxJump
   BAF7 70 03              4113 	jnz	00239$
   BAF9 02 BB 74           4114 	ljmp	00150$
   BAFC                    4115 00239$:
                           4116 ;	../../Common/modules/cIPv6.c:549: if(hoplimit >= 1 )
                           4117 ;	genCmpLt
   BAFC E5 10              4118 	mov	a,_bp
   BAFE 24 07              4119 	add	a,#0x07
   BB00 F8                 4120 	mov	r0,a
                           4121 ;	genCmp
   BB01 B6 01 00           4122 	cjne	@r0,#0x01,00240$
   BB04                    4123 00240$:
                           4124 ;	genIfxJump
                           4125 ;	Peephole 112.b	changed ljmp to sjmp
                           4126 ;	Peephole 160.a	removed sjmp by inverse jump logic
   BB04 40 6E              4127 	jc	00150$
                           4128 ;	Peephole 300	removed redundant label 00241$
                           4129 ;	../../Common/modules/cIPv6.c:551: buf->buf_ptr = ind; /*cut header*/
                           4130 ;	genPlus
   BB06 A8 10              4131 	mov	r0,_bp
   BB08 08                 4132 	inc	r0
                           4133 ;     genPlusIncr
   BB09 74 20              4134 	mov	a,#0x20
   BB0B 26                 4135 	add	a,@r0
   BB0C FA                 4136 	mov	r2,a
                           4137 ;	Peephole 181	changed mov to clr
   BB0D E4                 4138 	clr	a
   BB0E 08                 4139 	inc	r0
   BB0F 36                 4140 	addc	a,@r0
   BB10 FB                 4141 	mov	r3,a
   BB11 08                 4142 	inc	r0
   BB12 86 04              4143 	mov	ar4,@r0
                           4144 ;	genCast
   BB14 E5 10              4145 	mov	a,_bp
   BB16 24 06              4146 	add	a,#0x06
   BB18 F8                 4147 	mov	r0,a
   BB19 86 05              4148 	mov	ar5,@r0
   BB1B 7E 00              4149 	mov	r6,#0x00
                           4150 ;	genPointerSet
                           4151 ;	genGenPointerSet
   BB1D 8A 82              4152 	mov	dpl,r2
   BB1F 8B 83              4153 	mov	dph,r3
   BB21 8C F0              4154 	mov	b,r4
   BB23 ED                 4155 	mov	a,r5
   BB24 12 DF B7           4156 	lcall	__gptrput
   BB27 A3                 4157 	inc	dptr
   BB28 EE                 4158 	mov	a,r6
   BB29 12 DF B7           4159 	lcall	__gptrput
                           4160 ;	../../Common/modules/cIPv6.c:552: buf->from = MODULE_CIPV6;
                           4161 ;	genPlus
   BB2C A8 10              4162 	mov	r0,_bp
   BB2E 08                 4163 	inc	r0
                           4164 ;     genPlusIncr
   BB2F 74 1D              4165 	mov	a,#0x1D
   BB31 26                 4166 	add	a,@r0
   BB32 FA                 4167 	mov	r2,a
                           4168 ;	Peephole 181	changed mov to clr
   BB33 E4                 4169 	clr	a
   BB34 08                 4170 	inc	r0
   BB35 36                 4171 	addc	a,@r0
   BB36 FB                 4172 	mov	r3,a
   BB37 08                 4173 	inc	r0
   BB38 86 04              4174 	mov	ar4,@r0
                           4175 ;	genPointerSet
                           4176 ;	genGenPointerSet
   BB3A 8A 82              4177 	mov	dpl,r2
   BB3C 8B 83              4178 	mov	dph,r3
   BB3E 8C F0              4179 	mov	b,r4
   BB40 74 01              4180 	mov	a,#0x01
   BB42 12 DF B7           4181 	lcall	__gptrput
                           4182 ;	../../Common/modules/cIPv6.c:553: buf->to = MODULE_NONE;
                           4183 ;	genPlus
   BB45 A8 10              4184 	mov	r0,_bp
   BB47 08                 4185 	inc	r0
                           4186 ;     genPlusIncr
   BB48 74 1E              4187 	mov	a,#0x1E
   BB4A 26                 4188 	add	a,@r0
   BB4B FA                 4189 	mov	r2,a
                           4190 ;	Peephole 181	changed mov to clr
   BB4C E4                 4191 	clr	a
   BB4D 08                 4192 	inc	r0
   BB4E 36                 4193 	addc	a,@r0
   BB4F FB                 4194 	mov	r3,a
   BB50 08                 4195 	inc	r0
   BB51 86 04              4196 	mov	ar4,@r0
                           4197 ;	genPointerSet
                           4198 ;	genGenPointerSet
   BB53 8A 82              4199 	mov	dpl,r2
   BB55 8B 83              4200 	mov	dph,r3
   BB57 8C F0              4201 	mov	b,r4
                           4202 ;	Peephole 181	changed mov to clr
   BB59 E4                 4203 	clr	a
   BB5A 12 DF B7           4204 	lcall	__gptrput
                           4205 ;	../../Common/modules/cIPv6.c:554: stack_buffer_push(buf);
                           4206 ;	genCall
   BB5D A8 10              4207 	mov	r0,_bp
   BB5F 08                 4208 	inc	r0
   BB60 86 82              4209 	mov	dpl,@r0
   BB62 08                 4210 	inc	r0
   BB63 86 83              4211 	mov	dph,@r0
   BB65 08                 4212 	inc	r0
   BB66 86 F0              4213 	mov	b,@r0
   BB68 12 62 C4           4214 	lcall	_stack_buffer_push
                           4215 ;	../../Common/modules/cIPv6.c:555: buf=0;
                           4216 ;	genAssign
   BB6B A8 10              4217 	mov	r0,_bp
   BB6D 08                 4218 	inc	r0
   BB6E E4                 4219 	clr	a
   BB6F F6                 4220 	mov	@r0,a
   BB70 08                 4221 	inc	r0
   BB71 F6                 4222 	mov	@r0,a
   BB72 08                 4223 	inc	r0
   BB73 F6                 4224 	mov	@r0,a
                           4225 ;	../../Common/modules/cIPv6.c:578: }
   BB74                    4226 00150$:
                           4227 ;	../../Common/modules/cIPv6.c:580: if(buf)
                           4228 ;	genIfx
   BB74 A8 10              4229 	mov	r0,_bp
   BB76 08                 4230 	inc	r0
   BB77 E6                 4231 	mov	a,@r0
   BB78 08                 4232 	inc	r0
   BB79 46                 4233 	orl	a,@r0
   BB7A 08                 4234 	inc	r0
   BB7B 46                 4235 	orl	a,@r0
                           4236 ;	genIfxJump
                           4237 ;	Peephole 108.c	removed ljmp by inverse jump logic
   BB7C 60 0E              4238 	jz	00161$
                           4239 ;	Peephole 300	removed redundant label 00242$
                           4240 ;	../../Common/modules/cIPv6.c:582: stack_buffer_free(buf);
                           4241 ;	genCall
   BB7E A8 10              4242 	mov	r0,_bp
   BB80 08                 4243 	inc	r0
   BB81 86 82              4244 	mov	dpl,@r0
   BB83 08                 4245 	inc	r0
   BB84 86 83              4246 	mov	dph,@r0
   BB86 08                 4247 	inc	r0
   BB87 86 F0              4248 	mov	b,@r0
   BB89 12 61 FA           4249 	lcall	_stack_buffer_free
                           4250 ;	../../Common/modules/cIPv6.c:583: buf=0;
   BB8C                    4251 00161$:
   BB8C 85 10 81           4252 	mov	sp,_bp
   BB8F D0 10              4253 	pop	_bp
   BB91 22                 4254 	ret
                           4255 ;------------------------------------------------------------
                           4256 ;Allocation info for local variables in function 'build_lowpan_header'
                           4257 ;------------------------------------------------------------
                           4258 ;buf                       Allocated to stack - offset 1
                           4259 ;mesh_header               Allocated to stack - offset 4
                           4260 ;header_size               Allocated to stack - offset 5
                           4261 ;destination_delivery      Allocated to registers r5 
                           4262 ;dptr                      Allocated to stack - offset 6
                           4263 ;route_check               Allocated to stack - offset 9
                           4264 ;i                         Allocated to stack - offset 22
                           4265 ;dest_length               Allocated to stack - offset 23
                           4266 ;sloc0                     Allocated to stack - offset 25
                           4267 ;sloc1                     Allocated to stack - offset 24
                           4268 ;sloc2                     Allocated to stack - offset 27
                           4269 ;sloc3                     Allocated to stack - offset 30
                           4270 ;sloc4                     Allocated to stack - offset 33
                           4271 ;------------------------------------------------------------
                           4272 ;	../../Common/modules/cIPv6.c:768: portCHAR build_lowpan_header(buffer_t *buf)
                           4273 ;	-----------------------------------------
                           4274 ;	 function build_lowpan_header
                           4275 ;	-----------------------------------------
   BB92                    4276 _build_lowpan_header:
   BB92 C0 10              4277 	push	_bp
   BB94 85 81 10           4278 	mov	_bp,sp
                           4279 ;     genReceive
   BB97 C0 82              4280 	push	dpl
   BB99 C0 83              4281 	push	dph
   BB9B C0 F0              4282 	push	b
   BB9D E5 81              4283 	mov	a,sp
   BB9F 24 23              4284 	add	a,#0x23
   BBA1 F5 81              4285 	mov	sp,a
                           4286 ;	../../Common/modules/cIPv6.c:776: route_check.status=0;
                           4287 ;	genAddrOf
   BBA3 E5 10              4288 	mov	a,_bp
   BBA5 24 09              4289 	add	a,#0x09
                           4290 ;	genPointerSet
                           4291 ;	genNearPointerSet
                           4292 ;	Peephole 239	used a instead of acc
   BBA7 F8                 4293 	mov	r0,a
   BBA8 76 00              4294 	mov	@r0,#0x00
                           4295 ;	../../Common/modules/cIPv6.c:777: mesh_header = MESH_ROUTING_TYPE;
                           4296 ;	genAssign
   BBAA E5 10              4297 	mov	a,_bp
   BBAC 24 04              4298 	add	a,#0x04
   BBAE F8                 4299 	mov	r0,a
   BBAF 76 01              4300 	mov	@r0,#0x01
                           4301 ;	../../Common/modules/cIPv6.c:779: header_size = 3;
                           4302 ;	genAssign
   BBB1 E5 10              4303 	mov	a,_bp
   BBB3 24 05              4304 	add	a,#0x05
   BBB5 F8                 4305 	mov	r0,a
   BBB6 76 03              4306 	mov	@r0,#0x03
                           4307 ;	../../Common/modules/cIPv6.c:780: if((buf->from == MODULE_CUDP) && buf->options.lowpan_compressed)
                           4308 ;	genPlus
   BBB8 A8 10              4309 	mov	r0,_bp
   BBBA 08                 4310 	inc	r0
   BBBB E5 10              4311 	mov	a,_bp
   BBBD 24 18              4312 	add	a,#0x18
   BBBF F9                 4313 	mov	r1,a
                           4314 ;     genPlusIncr
   BBC0 74 1D              4315 	mov	a,#0x1D
   BBC2 26                 4316 	add	a,@r0
   BBC3 F7                 4317 	mov	@r1,a
                           4318 ;	Peephole 181	changed mov to clr
   BBC4 E4                 4319 	clr	a
   BBC5 08                 4320 	inc	r0
   BBC6 36                 4321 	addc	a,@r0
   BBC7 09                 4322 	inc	r1
   BBC8 F7                 4323 	mov	@r1,a
   BBC9 08                 4324 	inc	r0
   BBCA 09                 4325 	inc	r1
   BBCB E6                 4326 	mov	a,@r0
   BBCC F7                 4327 	mov	@r1,a
                           4328 ;	genPointerGet
                           4329 ;	genGenPointerGet
   BBCD E5 10              4330 	mov	a,_bp
   BBCF 24 18              4331 	add	a,#0x18
   BBD1 F8                 4332 	mov	r0,a
   BBD2 86 82              4333 	mov	dpl,@r0
   BBD4 08                 4334 	inc	r0
   BBD5 86 83              4335 	mov	dph,@r0
   BBD7 08                 4336 	inc	r0
   BBD8 86 F0              4337 	mov	b,@r0
   BBDA 12 E4 9F           4338 	lcall	__gptrget
   BBDD FA                 4339 	mov	r2,a
                           4340 ;	genCmpEq
                           4341 ;	gencjneshort
                           4342 ;	Peephole 112.b	changed ljmp to sjmp
                           4343 ;	Peephole 198.b	optimized misc jump sequence
   BBDE BA 02 27           4344 	cjne	r2,#0x02,00102$
                           4345 ;	Peephole 200.b	removed redundant sjmp
                           4346 ;	Peephole 300	removed redundant label 00193$
                           4347 ;	Peephole 300	removed redundant label 00194$
                           4348 ;	genPlus
   BBE1 A8 10              4349 	mov	r0,_bp
   BBE3 08                 4350 	inc	r0
                           4351 ;     genPlusIncr
   BBE4 74 26              4352 	mov	a,#0x26
   BBE6 26                 4353 	add	a,@r0
   BBE7 FA                 4354 	mov	r2,a
                           4355 ;	Peephole 181	changed mov to clr
   BBE8 E4                 4356 	clr	a
   BBE9 08                 4357 	inc	r0
   BBEA 36                 4358 	addc	a,@r0
   BBEB FB                 4359 	mov	r3,a
   BBEC 08                 4360 	inc	r0
   BBED 86 04              4361 	mov	ar4,@r0
                           4362 ;	genPlus
                           4363 ;     genPlusIncr
   BBEF 74 05              4364 	mov	a,#0x05
                           4365 ;	Peephole 236.a	used r2 instead of ar2
   BBF1 2A                 4366 	add	a,r2
   BBF2 FA                 4367 	mov	r2,a
                           4368 ;	Peephole 181	changed mov to clr
   BBF3 E4                 4369 	clr	a
                           4370 ;	Peephole 236.b	used r3 instead of ar3
   BBF4 3B                 4371 	addc	a,r3
   BBF5 FB                 4372 	mov	r3,a
                           4373 ;	genPointerGet
                           4374 ;	genGenPointerGet
   BBF6 8A 82              4375 	mov	dpl,r2
   BBF8 8B 83              4376 	mov	dph,r3
   BBFA 8C F0              4377 	mov	b,r4
   BBFC 12 E4 9F           4378 	lcall	__gptrget
                           4379 ;	genIfxJump
                           4380 ;	Peephole 108.c	removed ljmp by inverse jump logic
   BBFF 60 07              4381 	jz	00102$
                           4382 ;	Peephole 300	removed redundant label 00195$
                           4383 ;	../../Common/modules/cIPv6.c:782: header_size++;
                           4384 ;	genAssign
   BC01 E5 10              4385 	mov	a,_bp
   BC03 24 05              4386 	add	a,#0x05
   BC05 F8                 4387 	mov	r0,a
   BC06 76 04              4388 	mov	@r0,#0x04
   BC08                    4389 00102$:
                           4390 ;	../../Common/modules/cIPv6.c:785: if(cipv6_pib.use_short_address)
                           4391 ;	genPointerGet
                           4392 ;	genFarPointerGet
   BC08 90 F0 59           4393 	mov	dptr,#(_cipv6_pib + 0x000c)
   BC0B E0                 4394 	movx	a,@dptr
                           4395 ;	genIfxJump
                           4396 ;	Peephole 108.c	removed ljmp by inverse jump logic
   BC0C 60 10              4397 	jz	00105$
                           4398 ;	Peephole 300	removed redundant label 00196$
                           4399 ;	../../Common/modules/cIPv6.c:787: mesh_header |= O_ADDRESSTYPE_16;
                           4400 ;	genAssign
   BC0E E5 10              4401 	mov	a,_bp
   BC10 24 04              4402 	add	a,#0x04
   BC12 F8                 4403 	mov	r0,a
   BC13 76 05              4404 	mov	@r0,#0x05
                           4405 ;	../../Common/modules/cIPv6.c:788: header_size +=2;
                           4406 ;	genPlus
   BC15 E5 10              4407 	mov	a,_bp
   BC17 24 05              4408 	add	a,#0x05
   BC19 F8                 4409 	mov	r0,a
                           4410 ;     genPlusIncr
   BC1A 06                 4411 	inc	@r0
   BC1B 06                 4412 	inc	@r0
                           4413 ;	Peephole 112.b	changed ljmp to sjmp
   BC1C 80 09              4414 	sjmp	00106$
   BC1E                    4415 00105$:
                           4416 ;	../../Common/modules/cIPv6.c:793: header_size +=8;
                           4417 ;	genPlus
   BC1E E5 10              4418 	mov	a,_bp
   BC20 24 05              4419 	add	a,#0x05
   BC22 F8                 4420 	mov	r0,a
                           4421 ;     genPlusIncr
   BC23 74 08              4422 	mov	a,#0x08
   BC25 26                 4423 	add	a,@r0
   BC26 F6                 4424 	mov	@r0,a
   BC27                    4425 00106$:
                           4426 ;	../../Common/modules/cIPv6.c:797: switch(buf->dst_sa.addr_type)
                           4427 ;	genPlus
   BC27 A8 10              4428 	mov	r0,_bp
   BC29 08                 4429 	inc	r0
                           4430 ;     genPlusIncr
   BC2A 74 03              4431 	mov	a,#0x03
   BC2C 26                 4432 	add	a,@r0
   BC2D FA                 4433 	mov	r2,a
                           4434 ;	Peephole 181	changed mov to clr
   BC2E E4                 4435 	clr	a
   BC2F 08                 4436 	inc	r0
   BC30 36                 4437 	addc	a,@r0
   BC31 FB                 4438 	mov	r3,a
   BC32 08                 4439 	inc	r0
   BC33 86 04              4440 	mov	ar4,@r0
                           4441 ;	genPointerGet
                           4442 ;	genGenPointerGet
   BC35 8A 82              4443 	mov	dpl,r2
   BC37 8B 83              4444 	mov	dph,r3
   BC39 8C F0              4445 	mov	b,r4
   BC3B 12 E4 9F           4446 	lcall	__gptrget
   BC3E FD                 4447 	mov	r5,a
                           4448 ;	genCmpEq
                           4449 ;	gencjneshort
   BC3F BD 01 02           4450 	cjne	r5,#0x01,00197$
                           4451 ;	Peephole 112.b	changed ljmp to sjmp
   BC42 80 3E              4452 	sjmp	00110$
   BC44                    4453 00197$:
                           4454 ;	genCmpEq
                           4455 ;	gencjneshort
   BC44 BD 03 02           4456 	cjne	r5,#0x03,00198$
                           4457 ;	Peephole 112.b	changed ljmp to sjmp
   BC47 80 27              4458 	sjmp	00109$
   BC49                    4459 00198$:
                           4460 ;	genCmpEq
                           4461 ;	gencjneshort
   BC49 BD 04 02           4462 	cjne	r5,#0x04,00199$
                           4463 ;	Peephole 112.b	changed ljmp to sjmp
   BC4C 80 3F              4464 	sjmp	00111$
   BC4E                    4465 00199$:
                           4466 ;	genCmpEq
                           4467 ;	gencjneshort
   BC4E BD 08 02           4468 	cjne	r5,#0x08,00200$
                           4469 ;	Peephole 112.b	changed ljmp to sjmp
   BC51 80 08              4470 	sjmp	00108$
   BC53                    4471 00200$:
                           4472 ;	genCmpEq
                           4473 ;	gencjneshort
                           4474 ;	Peephole 112.b	changed ljmp to sjmp
                           4475 ;	Peephole 198.b	optimized misc jump sequence
   BC53 BD 09 40           4476 	cjne	r5,#0x09,00113$
                           4477 ;	Peephole 200.b	removed redundant sjmp
                           4478 ;	Peephole 300	removed redundant label 00201$
                           4479 ;	Peephole 300	removed redundant label 00202$
                           4480 ;	../../Common/modules/cIPv6.c:800: destination_delivery = NEIGHBOR;
                           4481 ;	genAssign
   BC56 7D 01              4482 	mov	r5,#0x01
                           4483 ;	../../Common/modules/cIPv6.c:801: break;
   BC58 02 BC FC           4484 	ljmp	00117$
                           4485 ;	../../Common/modules/cIPv6.c:803: case ADDR_BROADCAST:
   BC5B                    4486 00108$:
                           4487 ;	../../Common/modules/cIPv6.c:804: mesh_header |= D_ADDRESSTYPE_16;
                           4488 ;	genOr
   BC5B E5 10              4489 	mov	a,_bp
   BC5D 24 04              4490 	add	a,#0x04
   BC5F F8                 4491 	mov	r0,a
   BC60 E6                 4492 	mov	a,@r0
   BC61 44 08              4493 	orl	a,#0x08
   BC63 F6                 4494 	mov	@r0,a
                           4495 ;	../../Common/modules/cIPv6.c:805: header_size +=2;
                           4496 ;	genPlus
   BC64 E5 10              4497 	mov	a,_bp
   BC66 24 05              4498 	add	a,#0x05
   BC68 F8                 4499 	mov	r0,a
                           4500 ;     genPlusIncr
   BC69 06                 4501 	inc	@r0
   BC6A 06                 4502 	inc	@r0
                           4503 ;	../../Common/modules/cIPv6.c:806: destination_delivery = BROADCAST;
                           4504 ;	genAssign
   BC6B 7D 00              4505 	mov	r5,#0x00
                           4506 ;	../../Common/modules/cIPv6.c:807: break;
   BC6D 02 BC FC           4507 	ljmp	00117$
                           4508 ;	../../Common/modules/cIPv6.c:809: case ADDR_802_15_4_PAN_SHORT:
   BC70                    4509 00109$:
                           4510 ;	../../Common/modules/cIPv6.c:810: mesh_header |= D_ADDRESSTYPE_16;
                           4511 ;	genOr
   BC70 E5 10              4512 	mov	a,_bp
   BC72 24 04              4513 	add	a,#0x04
   BC74 F8                 4514 	mov	r0,a
   BC75 E6                 4515 	mov	a,@r0
   BC76 44 08              4516 	orl	a,#0x08
   BC78 F6                 4517 	mov	@r0,a
                           4518 ;	../../Common/modules/cIPv6.c:811: header_size +=2;
                           4519 ;	genPlus
   BC79 E5 10              4520 	mov	a,_bp
   BC7B 24 05              4521 	add	a,#0x05
   BC7D F8                 4522 	mov	r0,a
                           4523 ;     genPlusIncr
   BC7E 06                 4524 	inc	@r0
   BC7F 06                 4525 	inc	@r0
                           4526 ;	../../Common/modules/cIPv6.c:812: goto mesh_neighbour_check;
                           4527 ;	../../Common/modules/cIPv6.c:814: case ADDR_802_15_4_LONG:
                           4528 ;	Peephole 112.b	changed ljmp to sjmp
   BC80 80 14              4529 	sjmp	00113$
   BC82                    4530 00110$:
                           4531 ;	../../Common/modules/cIPv6.c:815: buf->dst_sa.addr_type = ADDR_802_15_4_PAN_LONG;			
                           4532 ;	genPointerSet
                           4533 ;	genGenPointerSet
   BC82 8A 82              4534 	mov	dpl,r2
   BC84 8B 83              4535 	mov	dph,r3
   BC86 8C F0              4536 	mov	b,r4
   BC88 74 04              4537 	mov	a,#0x04
   BC8A 12 DF B7           4538 	lcall	__gptrput
                           4539 ;	../../Common/modules/cIPv6.c:816: case ADDR_802_15_4_PAN_LONG:
   BC8D                    4540 00111$:
                           4541 ;	../../Common/modules/cIPv6.c:818: header_size +=8;
                           4542 ;	genPlus
   BC8D E5 10              4543 	mov	a,_bp
   BC8F 24 05              4544 	add	a,#0x05
   BC91 F8                 4545 	mov	r0,a
                           4546 ;     genPlusIncr
   BC92 74 08              4547 	mov	a,#0x08
   BC94 26                 4548 	add	a,@r0
   BC95 F6                 4549 	mov	@r0,a
                           4550 ;	../../Common/modules/cIPv6.c:821: mesh_neighbour_check:			
   BC96                    4551 00113$:
                           4552 ;	../../Common/modules/cIPv6.c:823: destination_delivery = check_neighbour_table(buf->dst_sa.addr_type, buf->dst_sa.address);
                           4553 ;	genPlus
   BC96 A8 10              4554 	mov	r0,_bp
   BC98 08                 4555 	inc	r0
                           4556 ;     genPlusIncr
   BC99 74 03              4557 	mov	a,#0x03
   BC9B 26                 4558 	add	a,@r0
   BC9C FB                 4559 	mov	r3,a
                           4560 ;	Peephole 181	changed mov to clr
   BC9D E4                 4561 	clr	a
   BC9E 08                 4562 	inc	r0
   BC9F 36                 4563 	addc	a,@r0
   BCA0 FC                 4564 	mov	r4,a
   BCA1 08                 4565 	inc	r0
   BCA2 86 05              4566 	mov	ar5,@r0
                           4567 ;	genPlus
                           4568 ;     genPlusIncr
   BCA4 74 01              4569 	mov	a,#0x01
                           4570 ;	Peephole 236.a	used r3 instead of ar3
   BCA6 2B                 4571 	add	a,r3
   BCA7 FE                 4572 	mov	r6,a
                           4573 ;	Peephole 181	changed mov to clr
   BCA8 E4                 4574 	clr	a
                           4575 ;	Peephole 236.b	used r4 instead of ar4
   BCA9 3C                 4576 	addc	a,r4
   BCAA FF                 4577 	mov	r7,a
   BCAB 8D 02              4578 	mov	ar2,r5
                           4579 ;	genPointerGet
                           4580 ;	genGenPointerGet
   BCAD 8B 82              4581 	mov	dpl,r3
   BCAF 8C 83              4582 	mov	dph,r4
   BCB1 8D F0              4583 	mov	b,r5
   BCB3 12 E4 9F           4584 	lcall	__gptrget
   BCB6 FB                 4585 	mov	r3,a
                           4586 ;	genIpush
   BCB7 C0 06              4587 	push	ar6
   BCB9 C0 07              4588 	push	ar7
   BCBB C0 02              4589 	push	ar2
                           4590 ;	genCall
   BCBD 8B 82              4591 	mov	dpl,r3
   BCBF 12 74 BF           4592 	lcall	_check_neighbour_table
   BCC2 AA 82              4593 	mov	r2,dpl
   BCC4 15 81              4594 	dec	sp
   BCC6 15 81              4595 	dec	sp
   BCC8 15 81              4596 	dec	sp
                           4597 ;	genAssign
   BCCA 8A 05              4598 	mov	ar5,r2
                           4599 ;	../../Common/modules/cIPv6.c:824: if(destination_delivery==BROADCAST && buf->dst_sa.addr_type==ADDR_802_15_4_PAN_LONG)
                           4600 ;	genIfx
   BCCC ED                 4601 	mov	a,r5
                           4602 ;	genIfxJump
                           4603 ;	Peephole 108.b	removed ljmp by inverse jump logic
   BCCD 70 2D              4604 	jnz	00117$
                           4605 ;	Peephole 300	removed redundant label 00203$
                           4606 ;	genPlus
   BCCF A8 10              4607 	mov	r0,_bp
   BCD1 08                 4608 	inc	r0
                           4609 ;     genPlusIncr
   BCD2 74 03              4610 	mov	a,#0x03
   BCD4 26                 4611 	add	a,@r0
   BCD5 FA                 4612 	mov	r2,a
                           4613 ;	Peephole 181	changed mov to clr
   BCD6 E4                 4614 	clr	a
   BCD7 08                 4615 	inc	r0
   BCD8 36                 4616 	addc	a,@r0
   BCD9 FB                 4617 	mov	r3,a
   BCDA 08                 4618 	inc	r0
   BCDB 86 04              4619 	mov	ar4,@r0
                           4620 ;	genPointerGet
                           4621 ;	genGenPointerGet
   BCDD 8A 82              4622 	mov	dpl,r2
   BCDF 8B 83              4623 	mov	dph,r3
   BCE1 8C F0              4624 	mov	b,r4
   BCE3 12 E4 9F           4625 	lcall	__gptrget
   BCE6 FA                 4626 	mov	r2,a
                           4627 ;	genCmpEq
                           4628 ;	gencjneshort
                           4629 ;	Peephole 112.b	changed ljmp to sjmp
                           4630 ;	Peephole 198.b	optimized misc jump sequence
   BCE7 BA 04 12           4631 	cjne	r2,#0x04,00117$
                           4632 ;	Peephole 200.b	removed redundant sjmp
                           4633 ;	Peephole 300	removed redundant label 00204$
                           4634 ;	Peephole 300	removed redundant label 00205$
                           4635 ;	../../Common/modules/cIPv6.c:826: header_size -=6;
                           4636 ;	genMinus
   BCEA E5 10              4637 	mov	a,_bp
   BCEC 24 05              4638 	add	a,#0x05
   BCEE F8                 4639 	mov	r0,a
   BCEF E6                 4640 	mov	a,@r0
   BCF0 24 FA              4641 	add	a,#0xfa
   BCF2 F6                 4642 	mov	@r0,a
                           4643 ;	../../Common/modules/cIPv6.c:828: mesh_header |=D_ADDRESSTYPE_16;
                           4644 ;	genOr
   BCF3 E5 10              4645 	mov	a,_bp
   BCF5 24 04              4646 	add	a,#0x04
   BCF7 F8                 4647 	mov	r0,a
   BCF8 E6                 4648 	mov	a,@r0
   BCF9 44 08              4649 	orl	a,#0x08
   BCFB F6                 4650 	mov	@r0,a
                           4651 ;	../../Common/modules/cIPv6.c:831: }
   BCFC                    4652 00117$:
                           4653 ;	../../Common/modules/cIPv6.c:832: switch (destination_delivery)
                           4654 ;	genCmpEq
                           4655 ;	gencjneshort
   BCFC BD 00 03           4656 	cjne	r5,#0x00,00206$
   BCFF 02 C0 DE           4657 	ljmp	00139$
   BD02                    4658 00206$:
                           4659 ;	genCmpEq
                           4660 ;	gencjneshort
   BD02 BD 01 03           4661 	cjne	r5,#0x01,00207$
   BD05 02 BF F6           4662 	ljmp	00133$
   BD08                    4663 00207$:
                           4664 ;	genCmpEq
                           4665 ;	gencjneshort
   BD08 BD 02 02           4666 	cjne	r5,#0x02,00208$
   BD0B 80 03              4667 	sjmp	00209$
   BD0D                    4668 00208$:
   BD0D 02 C2 6B           4669 	ljmp	00142$
   BD10                    4670 00209$:
                           4671 ;	../../Common/modules/cIPv6.c:839: route_check.status = 0;
                           4672 ;	genAddrOf
   BD10 E5 10              4673 	mov	a,_bp
   BD12 24 09              4674 	add	a,#0x09
   BD14 F8                 4675 	mov	r0,a
                           4676 ;	genPointerSet
                           4677 ;	genNearPointerSet
   BD15 76 00              4678 	mov	@r0,#0x00
                           4679 ;	../../Common/modules/cIPv6.c:844: if(route_check.status == 1)
                           4680 ;	genPointerGet
                           4681 ;	genNearPointerGet
   BD17 86 02              4682 	mov	ar2,@r0
                           4683 ;	genCmpEq
                           4684 ;	gencjneshort
   BD19 BA 01 02           4685 	cjne	r2,#0x01,00210$
                           4686 ;	Peephole 112.b	changed ljmp to sjmp
   BD1C 80 40              4687 	sjmp	00123$
   BD1E                    4688 00210$:
                           4689 ;	../../Common/modules/cIPv6.c:861: header_size+=3;
                           4690 ;	genPlus
   BD1E E5 10              4691 	mov	a,_bp
   BD20 24 05              4692 	add	a,#0x05
   BD22 F8                 4693 	mov	r0,a
                           4694 ;     genPlusIncr
   BD23 06                 4695 	inc	@r0
   BD24 06                 4696 	inc	@r0
   BD25 06                 4697 	inc	@r0
                           4698 ;	../../Common/modules/cIPv6.c:865: if(stack_buffer_headroom( buf,header_size)==pdFALSE)
                           4699 ;	genCast
   BD26 E5 10              4700 	mov	a,_bp
   BD28 24 05              4701 	add	a,#0x05
   BD2A F8                 4702 	mov	r0,a
   BD2B 86 06              4703 	mov	ar6,@r0
   BD2D 7A 00              4704 	mov	r2,#0x00
                           4705 ;	genIpush
   BD2F C0 06              4706 	push	ar6
   BD31 C0 02              4707 	push	ar2
                           4708 ;	genCall
   BD33 A8 10              4709 	mov	r0,_bp
   BD35 08                 4710 	inc	r0
   BD36 86 82              4711 	mov	dpl,@r0
   BD38 08                 4712 	inc	r0
   BD39 86 83              4713 	mov	dph,@r0
   BD3B 08                 4714 	inc	r0
   BD3C 86 F0              4715 	mov	b,@r0
   BD3E 12 63 20           4716 	lcall	_stack_buffer_headroom
   BD41 AA 82              4717 	mov	r2,dpl
   BD43 15 81              4718 	dec	sp
   BD45 15 81              4719 	dec	sp
                           4720 ;	genIfx
   BD47 EA                 4721 	mov	a,r2
                           4722 ;	genIfxJump
                           4723 ;	Peephole 108.b	removed ljmp by inverse jump logic
   BD48 70 14              4724 	jnz	00123$
                           4725 ;	Peephole 300	removed redundant label 00211$
                           4726 ;	../../Common/modules/cIPv6.c:867: stack_buffer_free(buf);
                           4727 ;	genCall
   BD4A A8 10              4728 	mov	r0,_bp
   BD4C 08                 4729 	inc	r0
   BD4D 86 82              4730 	mov	dpl,@r0
   BD4F 08                 4731 	inc	r0
   BD50 86 83              4732 	mov	dph,@r0
   BD52 08                 4733 	inc	r0
   BD53 86 F0              4734 	mov	b,@r0
   BD55 12 61 FA           4735 	lcall	_stack_buffer_free
                           4736 ;	../../Common/modules/cIPv6.c:868: return pdFALSE;
                           4737 ;	genRet
   BD58 75 82 00           4738 	mov	dpl,#0x00
   BD5B 02 C3 A1           4739 	ljmp	00160$
   BD5E                    4740 00123$:
                           4741 ;	../../Common/modules/cIPv6.c:871: buf->buf_ptr -= header_size; /* mesh_header+address_field+HC1_DISPATCH+ HC1*/
                           4742 ;	genPlus
   BD5E A8 10              4743 	mov	r0,_bp
   BD60 08                 4744 	inc	r0
                           4745 ;     genPlusIncr
   BD61 74 20              4746 	mov	a,#0x20
   BD63 26                 4747 	add	a,@r0
   BD64 FA                 4748 	mov	r2,a
                           4749 ;	Peephole 181	changed mov to clr
   BD65 E4                 4750 	clr	a
   BD66 08                 4751 	inc	r0
   BD67 36                 4752 	addc	a,@r0
   BD68 FB                 4753 	mov	r3,a
   BD69 08                 4754 	inc	r0
   BD6A 86 04              4755 	mov	ar4,@r0
                           4756 ;	genPointerGet
                           4757 ;	genGenPointerGet
   BD6C 8A 82              4758 	mov	dpl,r2
   BD6E 8B 83              4759 	mov	dph,r3
   BD70 8C F0              4760 	mov	b,r4
   BD72 E5 10              4761 	mov	a,_bp
   BD74 24 1B              4762 	add	a,#0x1b
   BD76 F8                 4763 	mov	r0,a
   BD77 12 E4 9F           4764 	lcall	__gptrget
   BD7A F6                 4765 	mov	@r0,a
   BD7B A3                 4766 	inc	dptr
   BD7C 12 E4 9F           4767 	lcall	__gptrget
   BD7F 08                 4768 	inc	r0
   BD80 F6                 4769 	mov	@r0,a
                           4770 ;	genCast
   BD81 E5 10              4771 	mov	a,_bp
   BD83 24 05              4772 	add	a,#0x05
   BD85 F8                 4773 	mov	r0,a
   BD86 86 07              4774 	mov	ar7,@r0
   BD88 7D 00              4775 	mov	r5,#0x00
                           4776 ;	genMinus
   BD8A E5 10              4777 	mov	a,_bp
   BD8C 24 1B              4778 	add	a,#0x1b
   BD8E F8                 4779 	mov	r0,a
   BD8F E6                 4780 	mov	a,@r0
   BD90 C3                 4781 	clr	c
                           4782 ;	Peephole 236.l	used r7 instead of ar7
   BD91 9F                 4783 	subb	a,r7
   BD92 FF                 4784 	mov	r7,a
   BD93 08                 4785 	inc	r0
   BD94 E6                 4786 	mov	a,@r0
                           4787 ;	Peephole 236.l	used r5 instead of ar5
   BD95 9D                 4788 	subb	a,r5
   BD96 FD                 4789 	mov	r5,a
                           4790 ;	genPointerSet
                           4791 ;	genGenPointerSet
   BD97 8A 82              4792 	mov	dpl,r2
   BD99 8B 83              4793 	mov	dph,r3
   BD9B 8C F0              4794 	mov	b,r4
   BD9D EF                 4795 	mov	a,r7
   BD9E 12 DF B7           4796 	lcall	__gptrput
   BDA1 A3                 4797 	inc	dptr
   BDA2 ED                 4798 	mov	a,r5
   BDA3 12 DF B7           4799 	lcall	__gptrput
                           4800 ;	../../Common/modules/cIPv6.c:872: dptr = buffer_data_pointer(buf);
                           4801 ;	genPlus
   BDA6 A8 10              4802 	mov	r0,_bp
   BDA8 08                 4803 	inc	r0
                           4804 ;     genPlusIncr
   BDA9 74 2C              4805 	mov	a,#0x2C
   BDAB 26                 4806 	add	a,@r0
   BDAC FA                 4807 	mov	r2,a
                           4808 ;	Peephole 181	changed mov to clr
   BDAD E4                 4809 	clr	a
   BDAE 08                 4810 	inc	r0
   BDAF 36                 4811 	addc	a,@r0
   BDB0 FB                 4812 	mov	r3,a
   BDB1 08                 4813 	inc	r0
   BDB2 86 04              4814 	mov	ar4,@r0
                           4815 ;	genPlus
                           4816 ;	Peephole 236.g	used r7 instead of ar7
   BDB4 EF                 4817 	mov	a,r7
                           4818 ;	Peephole 236.a	used r2 instead of ar2
   BDB5 2A                 4819 	add	a,r2
   BDB6 FF                 4820 	mov	r7,a
                           4821 ;	Peephole 236.g	used r5 instead of ar5
   BDB7 ED                 4822 	mov	a,r5
                           4823 ;	Peephole 236.b	used r3 instead of ar3
   BDB8 3B                 4824 	addc	a,r3
   BDB9 FD                 4825 	mov	r5,a
   BDBA 8C 06              4826 	mov	ar6,r4
                           4827 ;	genAssign
   BDBC E5 10              4828 	mov	a,_bp
   BDBE 24 06              4829 	add	a,#0x06
   BDC0 F8                 4830 	mov	r0,a
   BDC1 A6 07              4831 	mov	@r0,ar7
   BDC3 08                 4832 	inc	r0
   BDC4 A6 05              4833 	mov	@r0,ar5
   BDC6 08                 4834 	inc	r0
   BDC7 A6 06              4835 	mov	@r0,ar6
                           4836 ;	../../Common/modules/cIPv6.c:873: mesh_header |= BASIC_HOP_VALUE;
                           4837 ;	genOr
   BDC9 E5 10              4838 	mov	a,_bp
   BDCB 24 04              4839 	add	a,#0x04
   BDCD F8                 4840 	mov	r0,a
   BDCE E6                 4841 	mov	a,@r0
   BDCF 44 40              4842 	orl	a,#0x40
   BDD1 F6                 4843 	mov	@r0,a
                           4844 ;	../../Common/modules/cIPv6.c:874: *dptr++ = mesh_header;
                           4845 ;	genPointerSet
                           4846 ;	genGenPointerSet
   BDD2 E5 10              4847 	mov	a,_bp
   BDD4 24 06              4848 	add	a,#0x06
   BDD6 F8                 4849 	mov	r0,a
   BDD7 86 82              4850 	mov	dpl,@r0
   BDD9 08                 4851 	inc	r0
   BDDA 86 83              4852 	mov	dph,@r0
   BDDC 08                 4853 	inc	r0
   BDDD 86 F0              4854 	mov	b,@r0
   BDDF E5 10              4855 	mov	a,_bp
   BDE1 24 04              4856 	add	a,#0x04
   BDE3 F9                 4857 	mov	r1,a
   BDE4 E7                 4858 	mov	a,@r1
   BDE5 12 DF B7           4859 	lcall	__gptrput
   BDE8 A3                 4860 	inc	dptr
   BDE9 18                 4861 	dec	r0
   BDEA 18                 4862 	dec	r0
   BDEB A6 82              4863 	mov	@r0,dpl
   BDED 08                 4864 	inc	r0
   BDEE A6 83              4865 	mov	@r0,dph
                           4866 ;	../../Common/modules/cIPv6.c:877: dptr += add_own_address(dptr);
                           4867 ;	genCall
   BDF0 E5 10              4868 	mov	a,_bp
   BDF2 24 06              4869 	add	a,#0x06
   BDF4 F8                 4870 	mov	r0,a
   BDF5 86 82              4871 	mov	dpl,@r0
   BDF7 08                 4872 	inc	r0
   BDF8 86 83              4873 	mov	dph,@r0
   BDFA 08                 4874 	inc	r0
   BDFB 86 F0              4875 	mov	b,@r0
   BDFD 12 C3 A7           4876 	lcall	_add_own_address
   BE00 AD 82              4877 	mov	r5,dpl
                           4878 ;	genPlus
   BE02 E5 10              4879 	mov	a,_bp
   BE04 24 06              4880 	add	a,#0x06
   BE06 F8                 4881 	mov	r0,a
                           4882 ;	Peephole 236.g	used r5 instead of ar5
   BE07 ED                 4883 	mov	a,r5
   BE08 26                 4884 	add	a,@r0
   BE09 F6                 4885 	mov	@r0,a
                           4886 ;	Peephole 181	changed mov to clr
   BE0A E4                 4887 	clr	a
   BE0B 08                 4888 	inc	r0
   BE0C 36                 4889 	addc	a,@r0
   BE0D F6                 4890 	mov	@r0,a
                           4891 ;	../../Common/modules/cIPv6.c:879: if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_SHORT)
                           4892 ;	genPlus
   BE0E A8 10              4893 	mov	r0,_bp
   BE10 08                 4894 	inc	r0
                           4895 ;     genPlusIncr
   BE11 74 03              4896 	mov	a,#0x03
   BE13 26                 4897 	add	a,@r0
   BE14 FD                 4898 	mov	r5,a
                           4899 ;	Peephole 181	changed mov to clr
   BE15 E4                 4900 	clr	a
   BE16 08                 4901 	inc	r0
   BE17 36                 4902 	addc	a,@r0
   BE18 FE                 4903 	mov	r6,a
   BE19 08                 4904 	inc	r0
   BE1A 86 07              4905 	mov	ar7,@r0
                           4906 ;	genPointerGet
                           4907 ;	genGenPointerGet
   BE1C 8D 82              4908 	mov	dpl,r5
   BE1E 8E 83              4909 	mov	dph,r6
   BE20 8F F0              4910 	mov	b,r7
   BE22 12 E4 9F           4911 	lcall	__gptrget
   BE25 FA                 4912 	mov	r2,a
                           4913 ;	genCmpEq
                           4914 ;	gencjneshort
                           4915 ;	Peephole 112.b	changed ljmp to sjmp
                           4916 ;	Peephole 198.b	optimized misc jump sequence
   BE26 BA 03 09           4917 	cjne	r2,#0x03,00125$
                           4918 ;	Peephole 200.b	removed redundant sjmp
                           4919 ;	Peephole 300	removed redundant label 00212$
                           4920 ;	Peephole 300	removed redundant label 00213$
                           4921 ;	../../Common/modules/cIPv6.c:881: dest_length=2;
                           4922 ;	genAssign
   BE29 E5 10              4923 	mov	a,_bp
   BE2B 24 17              4924 	add	a,#0x17
   BE2D F8                 4925 	mov	r0,a
   BE2E 76 02              4926 	mov	@r0,#0x02
                           4927 ;	Peephole 112.b	changed ljmp to sjmp
   BE30 80 07              4928 	sjmp	00179$
   BE32                    4929 00125$:
                           4930 ;	../../Common/modules/cIPv6.c:885: dest_length=8;
                           4931 ;	genAssign
   BE32 E5 10              4932 	mov	a,_bp
   BE34 24 17              4933 	add	a,#0x17
   BE36 F8                 4934 	mov	r0,a
   BE37 76 08              4935 	mov	@r0,#0x08
                           4936 ;	../../Common/modules/cIPv6.c:887: for(i=0; i<dest_length ;i++)
   BE39                    4937 00179$:
                           4938 ;	genPlus
   BE39 A8 10              4939 	mov	r0,_bp
   BE3B 08                 4940 	inc	r0
   BE3C E5 10              4941 	mov	a,_bp
   BE3E 24 1B              4942 	add	a,#0x1b
   BE40 F9                 4943 	mov	r1,a
                           4944 ;     genPlusIncr
   BE41 74 03              4945 	mov	a,#0x03
   BE43 26                 4946 	add	a,@r0
   BE44 F7                 4947 	mov	@r1,a
                           4948 ;	Peephole 181	changed mov to clr
   BE45 E4                 4949 	clr	a
   BE46 08                 4950 	inc	r0
   BE47 36                 4951 	addc	a,@r0
   BE48 09                 4952 	inc	r1
   BE49 F7                 4953 	mov	@r1,a
   BE4A 08                 4954 	inc	r0
   BE4B 09                 4955 	inc	r1
   BE4C E6                 4956 	mov	a,@r0
   BE4D F7                 4957 	mov	@r1,a
                           4958 ;	genPlus
   BE4E E5 10              4959 	mov	a,_bp
   BE50 24 1B              4960 	add	a,#0x1b
   BE52 F8                 4961 	mov	r0,a
   BE53 E5 10              4962 	mov	a,_bp
   BE55 24 1E              4963 	add	a,#0x1e
   BE57 F9                 4964 	mov	r1,a
                           4965 ;     genPlusIncr
   BE58 74 01              4966 	mov	a,#0x01
   BE5A 26                 4967 	add	a,@r0
   BE5B F7                 4968 	mov	@r1,a
                           4969 ;	Peephole 181	changed mov to clr
   BE5C E4                 4970 	clr	a
   BE5D 08                 4971 	inc	r0
   BE5E 36                 4972 	addc	a,@r0
   BE5F 09                 4973 	inc	r1
   BE60 F7                 4974 	mov	@r1,a
   BE61 08                 4975 	inc	r0
   BE62 09                 4976 	inc	r1
   BE63 E6                 4977 	mov	a,@r0
   BE64 F7                 4978 	mov	@r1,a
                           4979 ;	genAssign
   BE65 E5 10              4980 	mov	a,_bp
   BE67 24 06              4981 	add	a,#0x06
   BE69 F8                 4982 	mov	r0,a
   BE6A E5 10              4983 	mov	a,_bp
   BE6C 24 21              4984 	add	a,#0x21
   BE6E F9                 4985 	mov	r1,a
   BE6F E6                 4986 	mov	a,@r0
   BE70 F7                 4987 	mov	@r1,a
   BE71 08                 4988 	inc	r0
   BE72 09                 4989 	inc	r1
   BE73 E6                 4990 	mov	a,@r0
   BE74 F7                 4991 	mov	@r1,a
   BE75 08                 4992 	inc	r0
   BE76 09                 4993 	inc	r1
   BE77 E6                 4994 	mov	a,@r0
   BE78 F7                 4995 	mov	@r1,a
                           4996 ;	genAssign
   BE79 7B 00              4997 	mov	r3,#0x00
   BE7B                    4998 00152$:
                           4999 ;	genCmpLt
   BE7B E5 10              5000 	mov	a,_bp
   BE7D 24 17              5001 	add	a,#0x17
   BE7F F8                 5002 	mov	r0,a
                           5003 ;	genCmp
   BE80 C3                 5004 	clr	c
   BE81 EB                 5005 	mov	a,r3
   BE82 96                 5006 	subb	a,@r0
                           5007 ;	genIfxJump
                           5008 ;	Peephole 108.a	removed ljmp by inverse jump logic
   BE83 50 55              5009 	jnc	00191$
                           5010 ;	Peephole 300	removed redundant label 00214$
                           5011 ;	../../Common/modules/cIPv6.c:889: *dptr++ = buf->dst_sa.address[i];
                           5012 ;	genIpush
   BE85 C0 05              5013 	push	ar5
   BE87 C0 06              5014 	push	ar6
   BE89 C0 07              5015 	push	ar7
                           5016 ;	genPlus
   BE8B E5 10              5017 	mov	a,_bp
   BE8D 24 1E              5018 	add	a,#0x1e
   BE8F F8                 5019 	mov	r0,a
                           5020 ;	Peephole 236.g	used r3 instead of ar3
   BE90 EB                 5021 	mov	a,r3
   BE91 26                 5022 	add	a,@r0
   BE92 FC                 5023 	mov	r4,a
                           5024 ;	Peephole 181	changed mov to clr
   BE93 E4                 5025 	clr	a
   BE94 08                 5026 	inc	r0
   BE95 36                 5027 	addc	a,@r0
   BE96 FD                 5028 	mov	r5,a
   BE97 08                 5029 	inc	r0
   BE98 86 06              5030 	mov	ar6,@r0
                           5031 ;	genPointerGet
                           5032 ;	genGenPointerGet
   BE9A 8C 82              5033 	mov	dpl,r4
   BE9C 8D 83              5034 	mov	dph,r5
   BE9E 8E F0              5035 	mov	b,r6
   BEA0 12 E4 9F           5036 	lcall	__gptrget
   BEA3 FC                 5037 	mov	r4,a
                           5038 ;	genPointerSet
                           5039 ;	genGenPointerSet
   BEA4 E5 10              5040 	mov	a,_bp
   BEA6 24 21              5041 	add	a,#0x21
   BEA8 F8                 5042 	mov	r0,a
   BEA9 86 82              5043 	mov	dpl,@r0
   BEAB 08                 5044 	inc	r0
   BEAC 86 83              5045 	mov	dph,@r0
   BEAE 08                 5046 	inc	r0
   BEAF 86 F0              5047 	mov	b,@r0
   BEB1 EC                 5048 	mov	a,r4
   BEB2 12 DF B7           5049 	lcall	__gptrput
   BEB5 A3                 5050 	inc	dptr
   BEB6 18                 5051 	dec	r0
   BEB7 18                 5052 	dec	r0
   BEB8 A6 82              5053 	mov	@r0,dpl
   BEBA 08                 5054 	inc	r0
   BEBB A6 83              5055 	mov	@r0,dph
                           5056 ;	genAssign
   BEBD E5 10              5057 	mov	a,_bp
   BEBF 24 21              5058 	add	a,#0x21
   BEC1 F8                 5059 	mov	r0,a
   BEC2 E5 10              5060 	mov	a,_bp
   BEC4 24 06              5061 	add	a,#0x06
   BEC6 F9                 5062 	mov	r1,a
   BEC7 E6                 5063 	mov	a,@r0
   BEC8 F7                 5064 	mov	@r1,a
   BEC9 08                 5065 	inc	r0
   BECA 09                 5066 	inc	r1
   BECB E6                 5067 	mov	a,@r0
   BECC F7                 5068 	mov	@r1,a
   BECD 08                 5069 	inc	r0
   BECE 09                 5070 	inc	r1
   BECF E6                 5071 	mov	a,@r0
   BED0 F7                 5072 	mov	@r1,a
                           5073 ;	../../Common/modules/cIPv6.c:887: for(i=0; i<dest_length ;i++)
                           5074 ;	genPlus
                           5075 ;     genPlusIncr
   BED1 0B                 5076 	inc	r3
                           5077 ;	genIpop
   BED2 D0 07              5078 	pop	ar7
   BED4 D0 06              5079 	pop	ar6
   BED6 D0 05              5080 	pop	ar5
                           5081 ;	Peephole 112.b	changed ljmp to sjmp
   BED8 80 A1              5082 	sjmp	00152$
   BEDA                    5083 00191$:
                           5084 ;	genAssign
   BEDA E5 10              5085 	mov	a,_bp
   BEDC 24 21              5086 	add	a,#0x21
   BEDE F8                 5087 	mov	r0,a
   BEDF E5 10              5088 	mov	a,_bp
   BEE1 24 06              5089 	add	a,#0x06
   BEE3 F9                 5090 	mov	r1,a
   BEE4 E6                 5091 	mov	a,@r0
   BEE5 F7                 5092 	mov	@r1,a
   BEE6 08                 5093 	inc	r0
   BEE7 09                 5094 	inc	r1
   BEE8 E6                 5095 	mov	a,@r0
   BEE9 F7                 5096 	mov	@r1,a
   BEEA 08                 5097 	inc	r0
   BEEB 09                 5098 	inc	r1
   BEEC E6                 5099 	mov	a,@r0
   BEED F7                 5100 	mov	@r1,a
                           5101 ;	../../Common/modules/cIPv6.c:892: if( route_check.status == 0)
                           5102 ;	genAddrOf
   BEEE E5 10              5103 	mov	a,_bp
   BEF0 24 09              5104 	add	a,#0x09
   BEF2 F8                 5105 	mov	r0,a
                           5106 ;	genPointerGet
                           5107 ;	genNearPointerGet
   BEF3 E6                 5108 	mov	a,@r0
                           5109 ;	genIfxJump
                           5110 ;	Peephole 108.b	removed ljmp by inverse jump logic
   BEF4 70 58              5111 	jnz	00131$
                           5112 ;	Peephole 300	removed redundant label 00215$
                           5113 ;	../../Common/modules/cIPv6.c:897: buf->dst_sa.addr_type = ADDR_BROADCAST;
                           5114 ;	genPointerSet
                           5115 ;	genGenPointerSet
   BEF6 8D 82              5116 	mov	dpl,r5
   BEF8 8E 83              5117 	mov	dph,r6
   BEFA 8F F0              5118 	mov	b,r7
   BEFC 74 08              5119 	mov	a,#0x08
   BEFE 12 DF B7           5120 	lcall	__gptrput
                           5121 ;	../../Common/modules/cIPv6.c:899: *dptr++ = LOWPAN_BC0;
                           5122 ;	genPointerSet
                           5123 ;	genGenPointerSet
   BF01 E5 10              5124 	mov	a,_bp
   BF03 24 21              5125 	add	a,#0x21
   BF05 F8                 5126 	mov	r0,a
   BF06 86 82              5127 	mov	dpl,@r0
   BF08 08                 5128 	inc	r0
   BF09 86 83              5129 	mov	dph,@r0
   BF0B 08                 5130 	inc	r0
   BF0C 86 F0              5131 	mov	b,@r0
   BF0E 74 09              5132 	mov	a,#0x09
   BF10 12 DF B7           5133 	lcall	__gptrput
                           5134 ;	genPlus
   BF13 E5 10              5135 	mov	a,_bp
   BF15 24 21              5136 	add	a,#0x21
   BF17 F8                 5137 	mov	r0,a
   BF18 E5 10              5138 	mov	a,_bp
   BF1A 24 06              5139 	add	a,#0x06
   BF1C F9                 5140 	mov	r1,a
                           5141 ;     genPlusIncr
   BF1D 74 01              5142 	mov	a,#0x01
   BF1F 26                 5143 	add	a,@r0
   BF20 F7                 5144 	mov	@r1,a
                           5145 ;	Peephole 181	changed mov to clr
   BF21 E4                 5146 	clr	a
   BF22 08                 5147 	inc	r0
   BF23 36                 5148 	addc	a,@r0
   BF24 09                 5149 	inc	r1
   BF25 F7                 5150 	mov	@r1,a
   BF26 08                 5151 	inc	r0
   BF27 09                 5152 	inc	r1
   BF28 E6                 5153 	mov	a,@r0
   BF29 F7                 5154 	mov	@r1,a
                           5155 ;	../../Common/modules/cIPv6.c:900: *dptr++ = cipv6_pib.own_brodcast_sqn;
                           5156 ;	genPointerGet
                           5157 ;	genFarPointerGet
   BF2A 90 F0 4D           5158 	mov	dptr,#_cipv6_pib
   BF2D E0                 5159 	movx	a,@dptr
   BF2E FB                 5160 	mov	r3,a
                           5161 ;	genPointerSet
                           5162 ;	genGenPointerSet
   BF2F E5 10              5163 	mov	a,_bp
   BF31 24 06              5164 	add	a,#0x06
   BF33 F8                 5165 	mov	r0,a
   BF34 86 82              5166 	mov	dpl,@r0
   BF36 08                 5167 	inc	r0
   BF37 86 83              5168 	mov	dph,@r0
   BF39 08                 5169 	inc	r0
   BF3A 86 F0              5170 	mov	b,@r0
   BF3C EB                 5171 	mov	a,r3
   BF3D 12 DF B7           5172 	lcall	__gptrput
   BF40 A3                 5173 	inc	dptr
   BF41 18                 5174 	dec	r0
   BF42 18                 5175 	dec	r0
   BF43 A6 82              5176 	mov	@r0,dpl
   BF45 08                 5177 	inc	r0
   BF46 A6 83              5178 	mov	@r0,dph
                           5179 ;	../../Common/modules/cIPv6.c:901: update_ip_sqn();
                           5180 ;	genCall
   BF48 12 C4 09           5181 	lcall	_update_ip_sqn
   BF4B 02 C2 8D           5182 	ljmp	00143$
   BF4E                    5183 00131$:
                           5184 ;	../../Common/modules/cIPv6.c:906: if(route_check.address_type == ADDR_802_15_4_PAN_LONG)
                           5185 ;	genAddrOf
   BF4E E5 10              5186 	mov	a,_bp
   BF50 24 09              5187 	add	a,#0x09
   BF52 FB                 5188 	mov	r3,a
                           5189 ;	genPlus
                           5190 ;     genPlusIncr
   BF53 74 01              5191 	mov	a,#0x01
                           5192 ;	Peephole 236.a	used r3 instead of ar3
   BF55 2B                 5193 	add	a,r3
   BF56 F8                 5194 	mov	r0,a
                           5195 ;	genPointerGet
                           5196 ;	genNearPointerGet
   BF57 86 04              5197 	mov	ar4,@r0
                           5198 ;	genCmpEq
                           5199 ;	gencjneshort
                           5200 ;	Peephole 112.b	changed ljmp to sjmp
                           5201 ;	Peephole 198.b	optimized misc jump sequence
   BF59 BC 04 09           5202 	cjne	r4,#0x04,00128$
                           5203 ;	Peephole 200.b	removed redundant sjmp
                           5204 ;	Peephole 300	removed redundant label 00216$
                           5205 ;	Peephole 300	removed redundant label 00217$
                           5206 ;	../../Common/modules/cIPv6.c:907: dest_length=10;
                           5207 ;	genAssign
   BF5C E5 10              5208 	mov	a,_bp
   BF5E 24 17              5209 	add	a,#0x17
   BF60 F8                 5210 	mov	r0,a
   BF61 76 0A              5211 	mov	@r0,#0x0A
                           5212 ;	Peephole 112.b	changed ljmp to sjmp
   BF63 80 07              5213 	sjmp	00183$
   BF65                    5214 00128$:
                           5215 ;	../../Common/modules/cIPv6.c:909: dest_length=4;
                           5216 ;	genAssign
   BF65 E5 10              5217 	mov	a,_bp
   BF67 24 17              5218 	add	a,#0x17
   BF69 F8                 5219 	mov	r0,a
   BF6A 76 04              5220 	mov	@r0,#0x04
                           5221 ;	../../Common/modules/cIPv6.c:911: for(i=0;i<dest_length; i++)
   BF6C                    5222 00183$:
                           5223 ;	genPlus
   BF6C E5 10              5224 	mov	a,_bp
   BF6E 24 1B              5225 	add	a,#0x1b
   BF70 F8                 5226 	mov	r0,a
   BF71 E5 10              5227 	mov	a,_bp
   BF73 24 21              5228 	add	a,#0x21
   BF75 F9                 5229 	mov	r1,a
                           5230 ;     genPlusIncr
   BF76 74 01              5231 	mov	a,#0x01
   BF78 26                 5232 	add	a,@r0
   BF79 F7                 5233 	mov	@r1,a
                           5234 ;	Peephole 181	changed mov to clr
   BF7A E4                 5235 	clr	a
   BF7B 08                 5236 	inc	r0
   BF7C 36                 5237 	addc	a,@r0
   BF7D 09                 5238 	inc	r1
   BF7E F7                 5239 	mov	@r1,a
   BF7F 08                 5240 	inc	r0
   BF80 09                 5241 	inc	r1
   BF81 E6                 5242 	mov	a,@r0
   BF82 F7                 5243 	mov	@r1,a
                           5244 ;	genPlus
                           5245 ;     genPlusIncr
   BF83 0B                 5246 	inc	r3
   BF84 0B                 5247 	inc	r3
                           5248 ;	genAssign
   BF85 E5 10              5249 	mov	a,_bp
   BF87 24 16              5250 	add	a,#0x16
   BF89 F8                 5251 	mov	r0,a
   BF8A 76 00              5252 	mov	@r0,#0x00
   BF8C                    5253 00156$:
                           5254 ;	genCmpLt
   BF8C E5 10              5255 	mov	a,_bp
   BF8E 24 16              5256 	add	a,#0x16
   BF90 F8                 5257 	mov	r0,a
   BF91 E5 10              5258 	mov	a,_bp
   BF93 24 17              5259 	add	a,#0x17
   BF95 F9                 5260 	mov	r1,a
                           5261 ;	genCmp
   BF96 C3                 5262 	clr	c
   BF97 E6                 5263 	mov	a,@r0
   BF98 97                 5264 	subb	a,@r1
                           5265 ;	genIfxJump
                           5266 ;	Peephole 108.a	removed ljmp by inverse jump logic
   BF99 50 4E              5267 	jnc	00159$
                           5268 ;	Peephole 300	removed redundant label 00218$
                           5269 ;	../../Common/modules/cIPv6.c:913: buf->dst_sa.address[i]=route_check.next_hop[i];
                           5270 ;	genIpush
   BF9B C0 04              5271 	push	ar4
                           5272 ;	genPlus
   BF9D E5 10              5273 	mov	a,_bp
   BF9F 24 21              5274 	add	a,#0x21
   BFA1 F8                 5275 	mov	r0,a
   BFA2 E5 10              5276 	mov	a,_bp
   BFA4 24 16              5277 	add	a,#0x16
   BFA6 F9                 5278 	mov	r1,a
   BFA7 E7                 5279 	mov	a,@r1
   BFA8 26                 5280 	add	a,@r0
   BFA9 C0 E0              5281 	push	acc
                           5282 ;	Peephole 181	changed mov to clr
   BFAB E4                 5283 	clr	a
   BFAC 08                 5284 	inc	r0
   BFAD 36                 5285 	addc	a,@r0
   BFAE C0 E0              5286 	push	acc
   BFB0 08                 5287 	inc	r0
   BFB1 E6                 5288 	mov	a,@r0
   BFB2 C0 E0              5289 	push	acc
   BFB4 E5 10              5290 	mov	a,_bp
   BFB6 24 1D              5291 	add	a,#0x1d
   BFB8 F8                 5292 	mov	r0,a
   BFB9 D0 E0              5293 	pop	acc
   BFBB F6                 5294 	mov	@r0,a
   BFBC 18                 5295 	dec	r0
   BFBD D0 E0              5296 	pop	acc
   BFBF F6                 5297 	mov	@r0,a
   BFC0 18                 5298 	dec	r0
   BFC1 D0 E0              5299 	pop	acc
   BFC3 F6                 5300 	mov	@r0,a
                           5301 ;	genPlus
   BFC4 E5 10              5302 	mov	a,_bp
   BFC6 24 16              5303 	add	a,#0x16
   BFC8 F9                 5304 	mov	r1,a
   BFC9 E7                 5305 	mov	a,@r1
                           5306 ;	Peephole 236.a	used r3 instead of ar3
   BFCA 2B                 5307 	add	a,r3
   BFCB F8                 5308 	mov	r0,a
                           5309 ;	genPointerGet
                           5310 ;	genNearPointerGet
   BFCC 86 02              5311 	mov	ar2,@r0
                           5312 ;	genPointerSet
                           5313 ;	genGenPointerSet
   BFCE E5 10              5314 	mov	a,_bp
   BFD0 24 1B              5315 	add	a,#0x1b
   BFD2 F8                 5316 	mov	r0,a
   BFD3 86 82              5317 	mov	dpl,@r0
   BFD5 08                 5318 	inc	r0
   BFD6 86 83              5319 	mov	dph,@r0
   BFD8 08                 5320 	inc	r0
   BFD9 86 F0              5321 	mov	b,@r0
   BFDB EA                 5322 	mov	a,r2
   BFDC 12 DF B7           5323 	lcall	__gptrput
                           5324 ;	../../Common/modules/cIPv6.c:911: for(i=0;i<dest_length; i++)
                           5325 ;	genPlus
   BFDF E5 10              5326 	mov	a,_bp
   BFE1 24 16              5327 	add	a,#0x16
   BFE3 F8                 5328 	mov	r0,a
                           5329 ;     genPlusIncr
   BFE4 06                 5330 	inc	@r0
                           5331 ;	genIpop
   BFE5 D0 04              5332 	pop	ar4
                           5333 ;	Peephole 112.b	changed ljmp to sjmp
   BFE7 80 A3              5334 	sjmp	00156$
   BFE9                    5335 00159$:
                           5336 ;	../../Common/modules/cIPv6.c:915: buf->dst_sa.addr_type = route_check.address_type;
                           5337 ;	genPointerSet
                           5338 ;	genGenPointerSet
   BFE9 8D 82              5339 	mov	dpl,r5
   BFEB 8E 83              5340 	mov	dph,r6
   BFED 8F F0              5341 	mov	b,r7
   BFEF EC                 5342 	mov	a,r4
   BFF0 12 DF B7           5343 	lcall	__gptrput
                           5344 ;	../../Common/modules/cIPv6.c:917: break;
   BFF3 02 C2 8D           5345 	ljmp	00143$
                           5346 ;	../../Common/modules/cIPv6.c:919: case NEIGHBOR:
   BFF6                    5347 00133$:
                           5348 ;	../../Common/modules/cIPv6.c:923: header_size = 3;
                           5349 ;	genAssign
   BFF6 E5 10              5350 	mov	a,_bp
   BFF8 24 05              5351 	add	a,#0x05
   BFFA F8                 5352 	mov	r0,a
   BFFB 76 03              5353 	mov	@r0,#0x03
                           5354 ;	../../Common/modules/cIPv6.c:924: if(buf->options.lowpan_compressed && buf->from == MODULE_CUDP)
                           5355 ;	genPlus
   BFFD A8 10              5356 	mov	r0,_bp
   BFFF 08                 5357 	inc	r0
                           5358 ;     genPlusIncr
   C000 74 26              5359 	mov	a,#0x26
   C002 26                 5360 	add	a,@r0
   C003 FA                 5361 	mov	r2,a
                           5362 ;	Peephole 181	changed mov to clr
   C004 E4                 5363 	clr	a
   C005 08                 5364 	inc	r0
   C006 36                 5365 	addc	a,@r0
   C007 FB                 5366 	mov	r3,a
   C008 08                 5367 	inc	r0
   C009 86 04              5368 	mov	ar4,@r0
                           5369 ;	genPlus
                           5370 ;     genPlusIncr
   C00B 74 05              5371 	mov	a,#0x05
                           5372 ;	Peephole 236.a	used r2 instead of ar2
   C00D 2A                 5373 	add	a,r2
   C00E FA                 5374 	mov	r2,a
                           5375 ;	Peephole 181	changed mov to clr
   C00F E4                 5376 	clr	a
                           5377 ;	Peephole 236.b	used r3 instead of ar3
   C010 3B                 5378 	addc	a,r3
   C011 FB                 5379 	mov	r3,a
                           5380 ;	genPointerGet
                           5381 ;	genGenPointerGet
   C012 8A 82              5382 	mov	dpl,r2
   C014 8B 83              5383 	mov	dph,r3
   C016 8C F0              5384 	mov	b,r4
   C018 12 E4 9F           5385 	lcall	__gptrget
                           5386 ;	genIfxJump
                           5387 ;	Peephole 108.c	removed ljmp by inverse jump logic
   C01B 60 1B              5388 	jz	00135$
                           5389 ;	Peephole 300	removed redundant label 00219$
                           5390 ;	genPointerGet
                           5391 ;	genGenPointerGet
   C01D E5 10              5392 	mov	a,_bp
   C01F 24 18              5393 	add	a,#0x18
   C021 F8                 5394 	mov	r0,a
   C022 86 82              5395 	mov	dpl,@r0
   C024 08                 5396 	inc	r0
   C025 86 83              5397 	mov	dph,@r0
   C027 08                 5398 	inc	r0
   C028 86 F0              5399 	mov	b,@r0
   C02A 12 E4 9F           5400 	lcall	__gptrget
   C02D FA                 5401 	mov	r2,a
                           5402 ;	genCmpEq
                           5403 ;	gencjneshort
                           5404 ;	Peephole 112.b	changed ljmp to sjmp
                           5405 ;	Peephole 198.b	optimized misc jump sequence
   C02E BA 02 07           5406 	cjne	r2,#0x02,00135$
                           5407 ;	Peephole 200.b	removed redundant sjmp
                           5408 ;	Peephole 300	removed redundant label 00220$
                           5409 ;	Peephole 300	removed redundant label 00221$
                           5410 ;	../../Common/modules/cIPv6.c:925: header_size++;
                           5411 ;	genAssign
   C031 E5 10              5412 	mov	a,_bp
   C033 24 05              5413 	add	a,#0x05
   C035 F8                 5414 	mov	r0,a
   C036 76 04              5415 	mov	@r0,#0x04
   C038                    5416 00135$:
                           5417 ;	../../Common/modules/cIPv6.c:927: if(stack_buffer_headroom(buf,header_size) == pdFALSE)
                           5418 ;	genCast
   C038 E5 10              5419 	mov	a,_bp
   C03A 24 05              5420 	add	a,#0x05
   C03C F8                 5421 	mov	r0,a
   C03D 86 06              5422 	mov	ar6,@r0
   C03F 7A 00              5423 	mov	r2,#0x00
                           5424 ;	genIpush
   C041 C0 06              5425 	push	ar6
   C043 C0 02              5426 	push	ar2
                           5427 ;	genCall
   C045 A8 10              5428 	mov	r0,_bp
   C047 08                 5429 	inc	r0
   C048 86 82              5430 	mov	dpl,@r0
   C04A 08                 5431 	inc	r0
   C04B 86 83              5432 	mov	dph,@r0
   C04D 08                 5433 	inc	r0
   C04E 86 F0              5434 	mov	b,@r0
   C050 12 63 20           5435 	lcall	_stack_buffer_headroom
   C053 AA 82              5436 	mov	r2,dpl
   C055 15 81              5437 	dec	sp
   C057 15 81              5438 	dec	sp
                           5439 ;	genIfx
   C059 EA                 5440 	mov	a,r2
                           5441 ;	genIfxJump
                           5442 ;	Peephole 108.b	removed ljmp by inverse jump logic
   C05A 70 14              5443 	jnz	00138$
                           5444 ;	Peephole 300	removed redundant label 00222$
                           5445 ;	../../Common/modules/cIPv6.c:929: stack_buffer_free(buf);
                           5446 ;	genCall
   C05C A8 10              5447 	mov	r0,_bp
   C05E 08                 5448 	inc	r0
   C05F 86 82              5449 	mov	dpl,@r0
   C061 08                 5450 	inc	r0
   C062 86 83              5451 	mov	dph,@r0
   C064 08                 5452 	inc	r0
   C065 86 F0              5453 	mov	b,@r0
   C067 12 61 FA           5454 	lcall	_stack_buffer_free
                           5455 ;	../../Common/modules/cIPv6.c:931: return pdTRUE;
                           5456 ;	genRet
   C06A 75 82 01           5457 	mov	dpl,#0x01
   C06D 02 C3 A1           5458 	ljmp	00160$
   C070                    5459 00138$:
                           5460 ;	../../Common/modules/cIPv6.c:933: buf->buf_ptr -= header_size; 				/* lowpan-dispatch+HC1 = header space */
                           5461 ;	genPlus
   C070 A8 10              5462 	mov	r0,_bp
   C072 08                 5463 	inc	r0
                           5464 ;     genPlusIncr
   C073 74 20              5465 	mov	a,#0x20
   C075 26                 5466 	add	a,@r0
   C076 FA                 5467 	mov	r2,a
                           5468 ;	Peephole 181	changed mov to clr
   C077 E4                 5469 	clr	a
   C078 08                 5470 	inc	r0
   C079 36                 5471 	addc	a,@r0
   C07A FB                 5472 	mov	r3,a
   C07B 08                 5473 	inc	r0
   C07C 86 04              5474 	mov	ar4,@r0
                           5475 ;	genPointerGet
                           5476 ;	genGenPointerGet
   C07E 8A 82              5477 	mov	dpl,r2
   C080 8B 83              5478 	mov	dph,r3
   C082 8C F0              5479 	mov	b,r4
   C084 E5 10              5480 	mov	a,_bp
   C086 24 21              5481 	add	a,#0x21
   C088 F8                 5482 	mov	r0,a
   C089 12 E4 9F           5483 	lcall	__gptrget
   C08C F6                 5484 	mov	@r0,a
   C08D A3                 5485 	inc	dptr
   C08E 12 E4 9F           5486 	lcall	__gptrget
   C091 08                 5487 	inc	r0
   C092 F6                 5488 	mov	@r0,a
                           5489 ;	genCast
   C093 E5 10              5490 	mov	a,_bp
   C095 24 05              5491 	add	a,#0x05
   C097 F8                 5492 	mov	r0,a
   C098 86 07              5493 	mov	ar7,@r0
   C09A 7D 00              5494 	mov	r5,#0x00
                           5495 ;	genMinus
   C09C E5 10              5496 	mov	a,_bp
   C09E 24 21              5497 	add	a,#0x21
   C0A0 F8                 5498 	mov	r0,a
   C0A1 E6                 5499 	mov	a,@r0
   C0A2 C3                 5500 	clr	c
                           5501 ;	Peephole 236.l	used r7 instead of ar7
   C0A3 9F                 5502 	subb	a,r7
   C0A4 FF                 5503 	mov	r7,a
   C0A5 08                 5504 	inc	r0
   C0A6 E6                 5505 	mov	a,@r0
                           5506 ;	Peephole 236.l	used r5 instead of ar5
   C0A7 9D                 5507 	subb	a,r5
   C0A8 FD                 5508 	mov	r5,a
                           5509 ;	genPointerSet
                           5510 ;	genGenPointerSet
   C0A9 8A 82              5511 	mov	dpl,r2
   C0AB 8B 83              5512 	mov	dph,r3
   C0AD 8C F0              5513 	mov	b,r4
   C0AF EF                 5514 	mov	a,r7
   C0B0 12 DF B7           5515 	lcall	__gptrput
   C0B3 A3                 5516 	inc	dptr
   C0B4 ED                 5517 	mov	a,r5
   C0B5 12 DF B7           5518 	lcall	__gptrput
                           5519 ;	../../Common/modules/cIPv6.c:934: dptr = buffer_data_pointer(buf);
                           5520 ;	genPlus
   C0B8 A8 10              5521 	mov	r0,_bp
   C0BA 08                 5522 	inc	r0
                           5523 ;     genPlusIncr
   C0BB 74 2C              5524 	mov	a,#0x2C
   C0BD 26                 5525 	add	a,@r0
   C0BE FA                 5526 	mov	r2,a
                           5527 ;	Peephole 181	changed mov to clr
   C0BF E4                 5528 	clr	a
   C0C0 08                 5529 	inc	r0
   C0C1 36                 5530 	addc	a,@r0
   C0C2 FB                 5531 	mov	r3,a
   C0C3 08                 5532 	inc	r0
   C0C4 86 04              5533 	mov	ar4,@r0
                           5534 ;	genPlus
                           5535 ;	Peephole 236.g	used r7 instead of ar7
   C0C6 EF                 5536 	mov	a,r7
                           5537 ;	Peephole 236.a	used r2 instead of ar2
   C0C7 2A                 5538 	add	a,r2
   C0C8 FF                 5539 	mov	r7,a
                           5540 ;	Peephole 236.g	used r5 instead of ar5
   C0C9 ED                 5541 	mov	a,r5
                           5542 ;	Peephole 236.b	used r3 instead of ar3
   C0CA 3B                 5543 	addc	a,r3
   C0CB FD                 5544 	mov	r5,a
   C0CC 8C 06              5545 	mov	ar6,r4
                           5546 ;	genAssign
   C0CE E5 10              5547 	mov	a,_bp
   C0D0 24 06              5548 	add	a,#0x06
   C0D2 F8                 5549 	mov	r0,a
   C0D3 A6 07              5550 	mov	@r0,ar7
   C0D5 08                 5551 	inc	r0
   C0D6 A6 05              5552 	mov	@r0,ar5
   C0D8 08                 5553 	inc	r0
   C0D9 A6 06              5554 	mov	@r0,ar6
                           5555 ;	../../Common/modules/cIPv6.c:935: break;
   C0DB 02 C2 8D           5556 	ljmp	00143$
                           5557 ;	../../Common/modules/cIPv6.c:937: case BROADCAST:
   C0DE                    5558 00139$:
                           5559 ;	../../Common/modules/cIPv6.c:941: header_size +=3;
                           5560 ;	genPlus
   C0DE E5 10              5561 	mov	a,_bp
   C0E0 24 05              5562 	add	a,#0x05
   C0E2 F8                 5563 	mov	r0,a
                           5564 ;     genPlusIncr
   C0E3 06                 5565 	inc	@r0
   C0E4 06                 5566 	inc	@r0
   C0E5 06                 5567 	inc	@r0
                           5568 ;	../../Common/modules/cIPv6.c:942: if(stack_buffer_headroom(buf,header_size) == pdFALSE)
                           5569 ;	genCast
   C0E6 E5 10              5570 	mov	a,_bp
   C0E8 24 05              5571 	add	a,#0x05
   C0EA F8                 5572 	mov	r0,a
   C0EB 86 06              5573 	mov	ar6,@r0
   C0ED 7A 00              5574 	mov	r2,#0x00
                           5575 ;	genIpush
   C0EF C0 06              5576 	push	ar6
   C0F1 C0 02              5577 	push	ar2
                           5578 ;	genCall
   C0F3 A8 10              5579 	mov	r0,_bp
   C0F5 08                 5580 	inc	r0
   C0F6 86 82              5581 	mov	dpl,@r0
   C0F8 08                 5582 	inc	r0
   C0F9 86 83              5583 	mov	dph,@r0
   C0FB 08                 5584 	inc	r0
   C0FC 86 F0              5585 	mov	b,@r0
   C0FE 12 63 20           5586 	lcall	_stack_buffer_headroom
   C101 AA 82              5587 	mov	r2,dpl
   C103 15 81              5588 	dec	sp
   C105 15 81              5589 	dec	sp
                           5590 ;	genIfx
   C107 EA                 5591 	mov	a,r2
                           5592 ;	genIfxJump
                           5593 ;	Peephole 108.b	removed ljmp by inverse jump logic
   C108 70 14              5594 	jnz	00141$
                           5595 ;	Peephole 300	removed redundant label 00223$
                           5596 ;	../../Common/modules/cIPv6.c:944: stack_buffer_free(buf);
                           5597 ;	genCall
   C10A A8 10              5598 	mov	r0,_bp
   C10C 08                 5599 	inc	r0
   C10D 86 82              5600 	mov	dpl,@r0
   C10F 08                 5601 	inc	r0
   C110 86 83              5602 	mov	dph,@r0
   C112 08                 5603 	inc	r0
   C113 86 F0              5604 	mov	b,@r0
   C115 12 61 FA           5605 	lcall	_stack_buffer_free
                           5606 ;	../../Common/modules/cIPv6.c:946: return pdTRUE;
                           5607 ;	genRet
   C118 75 82 01           5608 	mov	dpl,#0x01
   C11B 02 C3 A1           5609 	ljmp	00160$
   C11E                    5610 00141$:
                           5611 ;	../../Common/modules/cIPv6.c:948: buf->buf_ptr -= header_size; /* lowpan-dispatch+HC1 = header space */
                           5612 ;	genPlus
   C11E A8 10              5613 	mov	r0,_bp
   C120 08                 5614 	inc	r0
                           5615 ;     genPlusIncr
   C121 74 20              5616 	mov	a,#0x20
   C123 26                 5617 	add	a,@r0
   C124 FA                 5618 	mov	r2,a
                           5619 ;	Peephole 181	changed mov to clr
   C125 E4                 5620 	clr	a
   C126 08                 5621 	inc	r0
   C127 36                 5622 	addc	a,@r0
   C128 FB                 5623 	mov	r3,a
   C129 08                 5624 	inc	r0
   C12A 86 04              5625 	mov	ar4,@r0
                           5626 ;	genPointerGet
                           5627 ;	genGenPointerGet
   C12C 8A 82              5628 	mov	dpl,r2
   C12E 8B 83              5629 	mov	dph,r3
   C130 8C F0              5630 	mov	b,r4
   C132 E5 10              5631 	mov	a,_bp
   C134 24 21              5632 	add	a,#0x21
   C136 F8                 5633 	mov	r0,a
   C137 12 E4 9F           5634 	lcall	__gptrget
   C13A F6                 5635 	mov	@r0,a
   C13B A3                 5636 	inc	dptr
   C13C 12 E4 9F           5637 	lcall	__gptrget
   C13F 08                 5638 	inc	r0
   C140 F6                 5639 	mov	@r0,a
                           5640 ;	genCast
   C141 E5 10              5641 	mov	a,_bp
   C143 24 05              5642 	add	a,#0x05
   C145 F8                 5643 	mov	r0,a
   C146 86 07              5644 	mov	ar7,@r0
   C148 7D 00              5645 	mov	r5,#0x00
                           5646 ;	genMinus
   C14A E5 10              5647 	mov	a,_bp
   C14C 24 21              5648 	add	a,#0x21
   C14E F8                 5649 	mov	r0,a
   C14F E6                 5650 	mov	a,@r0
   C150 C3                 5651 	clr	c
                           5652 ;	Peephole 236.l	used r7 instead of ar7
   C151 9F                 5653 	subb	a,r7
   C152 FF                 5654 	mov	r7,a
   C153 08                 5655 	inc	r0
   C154 E6                 5656 	mov	a,@r0
                           5657 ;	Peephole 236.l	used r5 instead of ar5
   C155 9D                 5658 	subb	a,r5
   C156 FD                 5659 	mov	r5,a
                           5660 ;	genPointerSet
                           5661 ;	genGenPointerSet
   C157 8A 82              5662 	mov	dpl,r2
   C159 8B 83              5663 	mov	dph,r3
   C15B 8C F0              5664 	mov	b,r4
   C15D EF                 5665 	mov	a,r7
   C15E 12 DF B7           5666 	lcall	__gptrput
   C161 A3                 5667 	inc	dptr
   C162 ED                 5668 	mov	a,r5
   C163 12 DF B7           5669 	lcall	__gptrput
                           5670 ;	../../Common/modules/cIPv6.c:949: dptr = buffer_data_pointer(buf);
                           5671 ;	genPlus
   C166 A8 10              5672 	mov	r0,_bp
   C168 08                 5673 	inc	r0
                           5674 ;     genPlusIncr
   C169 74 2C              5675 	mov	a,#0x2C
   C16B 26                 5676 	add	a,@r0
   C16C FA                 5677 	mov	r2,a
                           5678 ;	Peephole 181	changed mov to clr
   C16D E4                 5679 	clr	a
   C16E 08                 5680 	inc	r0
   C16F 36                 5681 	addc	a,@r0
   C170 FB                 5682 	mov	r3,a
   C171 08                 5683 	inc	r0
   C172 86 04              5684 	mov	ar4,@r0
                           5685 ;	genPlus
                           5686 ;	Peephole 236.g	used r7 instead of ar7
   C174 EF                 5687 	mov	a,r7
                           5688 ;	Peephole 236.a	used r2 instead of ar2
   C175 2A                 5689 	add	a,r2
   C176 FF                 5690 	mov	r7,a
                           5691 ;	Peephole 236.g	used r5 instead of ar5
   C177 ED                 5692 	mov	a,r5
                           5693 ;	Peephole 236.b	used r3 instead of ar3
   C178 3B                 5694 	addc	a,r3
   C179 FD                 5695 	mov	r5,a
   C17A 8C 06              5696 	mov	ar6,r4
                           5697 ;	genAssign
   C17C E5 10              5698 	mov	a,_bp
   C17E 24 06              5699 	add	a,#0x06
   C180 F8                 5700 	mov	r0,a
   C181 A6 07              5701 	mov	@r0,ar7
   C183 08                 5702 	inc	r0
   C184 A6 05              5703 	mov	@r0,ar5
   C186 08                 5704 	inc	r0
   C187 A6 06              5705 	mov	@r0,ar6
                           5706 ;	../../Common/modules/cIPv6.c:961: *dptr++ = (mesh_header | (1<<4));
                           5707 ;	genOr
   C189 E5 10              5708 	mov	a,_bp
   C18B 24 04              5709 	add	a,#0x04
   C18D F8                 5710 	mov	r0,a
   C18E 74 10              5711 	mov	a,#0x10
   C190 46                 5712 	orl	a,@r0
   C191 FA                 5713 	mov	r2,a
                           5714 ;	genPointerSet
                           5715 ;	genGenPointerSet
   C192 E5 10              5716 	mov	a,_bp
   C194 24 06              5717 	add	a,#0x06
   C196 F8                 5718 	mov	r0,a
   C197 86 82              5719 	mov	dpl,@r0
   C199 08                 5720 	inc	r0
   C19A 86 83              5721 	mov	dph,@r0
   C19C 08                 5722 	inc	r0
   C19D 86 F0              5723 	mov	b,@r0
   C19F EA                 5724 	mov	a,r2
   C1A0 12 DF B7           5725 	lcall	__gptrput
   C1A3 A3                 5726 	inc	dptr
   C1A4 18                 5727 	dec	r0
   C1A5 18                 5728 	dec	r0
   C1A6 A6 82              5729 	mov	@r0,dpl
   C1A8 08                 5730 	inc	r0
   C1A9 A6 83              5731 	mov	@r0,dph
                           5732 ;	../../Common/modules/cIPv6.c:964: buf->dst_sa.addr_type = ADDR_BROADCAST;
                           5733 ;	genPlus
   C1AB A8 10              5734 	mov	r0,_bp
   C1AD 08                 5735 	inc	r0
                           5736 ;     genPlusIncr
   C1AE 74 03              5737 	mov	a,#0x03
   C1B0 26                 5738 	add	a,@r0
   C1B1 FA                 5739 	mov	r2,a
                           5740 ;	Peephole 181	changed mov to clr
   C1B2 E4                 5741 	clr	a
   C1B3 08                 5742 	inc	r0
   C1B4 36                 5743 	addc	a,@r0
   C1B5 FB                 5744 	mov	r3,a
   C1B6 08                 5745 	inc	r0
   C1B7 86 04              5746 	mov	ar4,@r0
                           5747 ;	genPointerSet
                           5748 ;	genGenPointerSet
   C1B9 8A 82              5749 	mov	dpl,r2
   C1BB 8B 83              5750 	mov	dph,r3
   C1BD 8C F0              5751 	mov	b,r4
   C1BF 74 08              5752 	mov	a,#0x08
   C1C1 12 DF B7           5753 	lcall	__gptrput
                           5754 ;	../../Common/modules/cIPv6.c:965: buf->src_sa.addr_type = ADDR_NONE;
                           5755 ;	genPlus
   C1C4 A8 10              5756 	mov	r0,_bp
   C1C6 08                 5757 	inc	r0
                           5758 ;     genPlusIncr
   C1C7 74 10              5759 	mov	a,#0x10
   C1C9 26                 5760 	add	a,@r0
   C1CA FA                 5761 	mov	r2,a
                           5762 ;	Peephole 181	changed mov to clr
   C1CB E4                 5763 	clr	a
   C1CC 08                 5764 	inc	r0
   C1CD 36                 5765 	addc	a,@r0
   C1CE FB                 5766 	mov	r3,a
   C1CF 08                 5767 	inc	r0
   C1D0 86 04              5768 	mov	ar4,@r0
                           5769 ;	genPointerSet
                           5770 ;	genGenPointerSet
   C1D2 8A 82              5771 	mov	dpl,r2
   C1D4 8B 83              5772 	mov	dph,r3
   C1D6 8C F0              5773 	mov	b,r4
                           5774 ;	Peephole 181	changed mov to clr
   C1D8 E4                 5775 	clr	a
   C1D9 12 DF B7           5776 	lcall	__gptrput
                           5777 ;	../../Common/modules/cIPv6.c:967: dptr += add_own_address(dptr);
                           5778 ;	genCall
   C1DC E5 10              5779 	mov	a,_bp
   C1DE 24 06              5780 	add	a,#0x06
   C1E0 F8                 5781 	mov	r0,a
   C1E1 86 82              5782 	mov	dpl,@r0
   C1E3 08                 5783 	inc	r0
   C1E4 86 83              5784 	mov	dph,@r0
   C1E6 08                 5785 	inc	r0
   C1E7 86 F0              5786 	mov	b,@r0
   C1E9 12 C3 A7           5787 	lcall	_add_own_address
   C1EC AA 82              5788 	mov	r2,dpl
                           5789 ;	genPlus
   C1EE E5 10              5790 	mov	a,_bp
   C1F0 24 06              5791 	add	a,#0x06
   C1F2 F8                 5792 	mov	r0,a
                           5793 ;	Peephole 236.g	used r2 instead of ar2
   C1F3 EA                 5794 	mov	a,r2
   C1F4 26                 5795 	add	a,@r0
   C1F5 F6                 5796 	mov	@r0,a
                           5797 ;	Peephole 181	changed mov to clr
   C1F6 E4                 5798 	clr	a
   C1F7 08                 5799 	inc	r0
   C1F8 36                 5800 	addc	a,@r0
   C1F9 F6                 5801 	mov	@r0,a
                           5802 ;	../../Common/modules/cIPv6.c:969: *dptr++ = 0xff;
                           5803 ;	genPointerSet
                           5804 ;	genGenPointerSet
   C1FA E5 10              5805 	mov	a,_bp
   C1FC 24 06              5806 	add	a,#0x06
   C1FE F8                 5807 	mov	r0,a
   C1FF 86 82              5808 	mov	dpl,@r0
   C201 08                 5809 	inc	r0
   C202 86 83              5810 	mov	dph,@r0
   C204 08                 5811 	inc	r0
   C205 86 F0              5812 	mov	b,@r0
   C207 74 FF              5813 	mov	a,#0xFF
   C209 12 DF B7           5814 	lcall	__gptrput
   C20C A3                 5815 	inc	dptr
   C20D 18                 5816 	dec	r0
   C20E 18                 5817 	dec	r0
   C20F A6 82              5818 	mov	@r0,dpl
   C211 08                 5819 	inc	r0
   C212 A6 83              5820 	mov	@r0,dph
                           5821 ;	../../Common/modules/cIPv6.c:970: *dptr++ = 0xff;
                           5822 ;	genPointerSet
                           5823 ;	genGenPointerSet
   C214 E5 10              5824 	mov	a,_bp
   C216 24 06              5825 	add	a,#0x06
   C218 F8                 5826 	mov	r0,a
   C219 86 82              5827 	mov	dpl,@r0
   C21B 08                 5828 	inc	r0
   C21C 86 83              5829 	mov	dph,@r0
   C21E 08                 5830 	inc	r0
   C21F 86 F0              5831 	mov	b,@r0
   C221 74 FF              5832 	mov	a,#0xFF
   C223 12 DF B7           5833 	lcall	__gptrput
   C226 A3                 5834 	inc	dptr
   C227 18                 5835 	dec	r0
   C228 18                 5836 	dec	r0
   C229 A6 82              5837 	mov	@r0,dpl
   C22B 08                 5838 	inc	r0
   C22C A6 83              5839 	mov	@r0,dph
                           5840 ;	../../Common/modules/cIPv6.c:973: *dptr++ = LOWPAN_BC0;
                           5841 ;	genPointerSet
                           5842 ;	genGenPointerSet
   C22E E5 10              5843 	mov	a,_bp
   C230 24 06              5844 	add	a,#0x06
   C232 F8                 5845 	mov	r0,a
   C233 86 82              5846 	mov	dpl,@r0
   C235 08                 5847 	inc	r0
   C236 86 83              5848 	mov	dph,@r0
   C238 08                 5849 	inc	r0
   C239 86 F0              5850 	mov	b,@r0
   C23B 74 09              5851 	mov	a,#0x09
   C23D 12 DF B7           5852 	lcall	__gptrput
   C240 A3                 5853 	inc	dptr
   C241 18                 5854 	dec	r0
   C242 18                 5855 	dec	r0
   C243 A6 82              5856 	mov	@r0,dpl
   C245 08                 5857 	inc	r0
   C246 A6 83              5858 	mov	@r0,dph
                           5859 ;	../../Common/modules/cIPv6.c:974: *dptr++ = cipv6_pib.own_brodcast_sqn;
                           5860 ;	genPointerGet
                           5861 ;	genFarPointerGet
   C248 90 F0 4D           5862 	mov	dptr,#_cipv6_pib
   C24B E0                 5863 	movx	a,@dptr
   C24C FA                 5864 	mov	r2,a
                           5865 ;	genPointerSet
                           5866 ;	genGenPointerSet
   C24D E5 10              5867 	mov	a,_bp
   C24F 24 06              5868 	add	a,#0x06
   C251 F8                 5869 	mov	r0,a
   C252 86 82              5870 	mov	dpl,@r0
   C254 08                 5871 	inc	r0
   C255 86 83              5872 	mov	dph,@r0
   C257 08                 5873 	inc	r0
   C258 86 F0              5874 	mov	b,@r0
   C25A EA                 5875 	mov	a,r2
   C25B 12 DF B7           5876 	lcall	__gptrput
   C25E A3                 5877 	inc	dptr
   C25F 18                 5878 	dec	r0
   C260 18                 5879 	dec	r0
   C261 A6 82              5880 	mov	@r0,dpl
   C263 08                 5881 	inc	r0
   C264 A6 83              5882 	mov	@r0,dph
                           5883 ;	../../Common/modules/cIPv6.c:975: update_ip_sqn();
                           5884 ;	genCall
   C266 12 C4 09           5885 	lcall	_update_ip_sqn
                           5886 ;	../../Common/modules/cIPv6.c:976: break;
                           5887 ;	../../Common/modules/cIPv6.c:978: default:
                           5888 ;	Peephole 112.b	changed ljmp to sjmp
   C269 80 22              5889 	sjmp	00143$
   C26B                    5890 00142$:
                           5891 ;	../../Common/modules/cIPv6.c:982: dptr = 0;
                           5892 ;	genAssign
   C26B E5 10              5893 	mov	a,_bp
   C26D 24 06              5894 	add	a,#0x06
   C26F F8                 5895 	mov	r0,a
   C270 E4                 5896 	clr	a
   C271 F6                 5897 	mov	@r0,a
   C272 08                 5898 	inc	r0
   C273 F6                 5899 	mov	@r0,a
   C274 08                 5900 	inc	r0
   C275 F6                 5901 	mov	@r0,a
                           5902 ;	../../Common/modules/cIPv6.c:983: stack_buffer_free(buf);
                           5903 ;	genCall
   C276 A8 10              5904 	mov	r0,_bp
   C278 08                 5905 	inc	r0
   C279 86 82              5906 	mov	dpl,@r0
   C27B 08                 5907 	inc	r0
   C27C 86 83              5908 	mov	dph,@r0
   C27E 08                 5909 	inc	r0
   C27F 86 F0              5910 	mov	b,@r0
   C281 12 61 FA           5911 	lcall	_stack_buffer_free
                           5912 ;	../../Common/modules/cIPv6.c:984: buf=0;
                           5913 ;	genAssign
   C284 A8 10              5914 	mov	r0,_bp
   C286 08                 5915 	inc	r0
   C287 E4                 5916 	clr	a
   C288 F6                 5917 	mov	@r0,a
   C289 08                 5918 	inc	r0
   C28A F6                 5919 	mov	@r0,a
   C28B 08                 5920 	inc	r0
   C28C F6                 5921 	mov	@r0,a
                           5922 ;	../../Common/modules/cIPv6.c:986: }
   C28D                    5923 00143$:
                           5924 ;	../../Common/modules/cIPv6.c:988: if(buf)
                           5925 ;	genIfx
   C28D A8 10              5926 	mov	r0,_bp
   C28F 08                 5927 	inc	r0
   C290 E6                 5928 	mov	a,@r0
   C291 08                 5929 	inc	r0
   C292 46                 5930 	orl	a,@r0
   C293 08                 5931 	inc	r0
   C294 46                 5932 	orl	a,@r0
                           5933 ;	genIfxJump
   C295 70 03              5934 	jnz	00224$
   C297 02 C3 9E           5935 	ljmp	00151$
   C29A                    5936 00224$:
                           5937 ;	../../Common/modules/cIPv6.c:990: *dptr++ = LOWPAN_HC1; 	/* LowPan Dispatch	 */
                           5938 ;	genPointerSet
                           5939 ;	genGenPointerSet
   C29A E5 10              5940 	mov	a,_bp
   C29C 24 06              5941 	add	a,#0x06
   C29E F8                 5942 	mov	r0,a
   C29F 86 82              5943 	mov	dpl,@r0
   C2A1 08                 5944 	inc	r0
   C2A2 86 83              5945 	mov	dph,@r0
   C2A4 08                 5946 	inc	r0
   C2A5 86 F0              5947 	mov	b,@r0
   C2A7 74 42              5948 	mov	a,#0x42
   C2A9 12 DF B7           5949 	lcall	__gptrput
   C2AC A3                 5950 	inc	dptr
   C2AD 18                 5951 	dec	r0
   C2AE 18                 5952 	dec	r0
   C2AF A6 82              5953 	mov	@r0,dpl
   C2B1 08                 5954 	inc	r0
   C2B2 A6 83              5955 	mov	@r0,dph
                           5956 ;	../../Common/modules/cIPv6.c:992: if(buf->from == MODULE_ICMP)
                           5957 ;	genPlus
   C2B4 A8 10              5958 	mov	r0,_bp
   C2B6 08                 5959 	inc	r0
                           5960 ;     genPlusIncr
   C2B7 74 1D              5961 	mov	a,#0x1D
   C2B9 26                 5962 	add	a,@r0
   C2BA FA                 5963 	mov	r2,a
                           5964 ;	Peephole 181	changed mov to clr
   C2BB E4                 5965 	clr	a
   C2BC 08                 5966 	inc	r0
   C2BD 36                 5967 	addc	a,@r0
   C2BE FB                 5968 	mov	r3,a
   C2BF 08                 5969 	inc	r0
   C2C0 86 04              5970 	mov	ar4,@r0
                           5971 ;	genPointerGet
                           5972 ;	genGenPointerGet
   C2C2 8A 82              5973 	mov	dpl,r2
   C2C4 8B 83              5974 	mov	dph,r3
   C2C6 8C F0              5975 	mov	b,r4
   C2C8 12 E4 9F           5976 	lcall	__gptrget
   C2CB FD                 5977 	mov	r5,a
                           5978 ;	genCmpEq
                           5979 ;	gencjneshort
                           5980 ;	Peephole 112.b	changed ljmp to sjmp
                           5981 ;	Peephole 198.b	optimized misc jump sequence
   C2CC BD 04 1C           5982 	cjne	r5,#0x04,00148$
                           5983 ;	Peephole 200.b	removed redundant sjmp
                           5984 ;	Peephole 300	removed redundant label 00225$
                           5985 ;	Peephole 300	removed redundant label 00226$
                           5986 ;	../../Common/modules/cIPv6.c:993: *dptr++ = IP_HEADER_FOR_ICMP;
                           5987 ;	genPointerSet
                           5988 ;	genGenPointerSet
   C2CF E5 10              5989 	mov	a,_bp
   C2D1 24 06              5990 	add	a,#0x06
   C2D3 F8                 5991 	mov	r0,a
   C2D4 86 82              5992 	mov	dpl,@r0
   C2D6 08                 5993 	inc	r0
   C2D7 86 83              5994 	mov	dph,@r0
   C2D9 08                 5995 	inc	r0
   C2DA 86 F0              5996 	mov	b,@r0
   C2DC 74 5F              5997 	mov	a,#0x5F
   C2DE 12 DF B7           5998 	lcall	__gptrput
   C2E1 A3                 5999 	inc	dptr
   C2E2 18                 6000 	dec	r0
   C2E3 18                 6001 	dec	r0
   C2E4 A6 82              6002 	mov	@r0,dpl
   C2E6 08                 6003 	inc	r0
   C2E7 A6 83              6004 	mov	@r0,dph
                           6005 ;	Peephole 112.b	changed ljmp to sjmp
   C2E9 80 70              6006 	sjmp	00149$
   C2EB                    6007 00148$:
                           6008 ;	../../Common/modules/cIPv6.c:996: if(buf->options.lowpan_compressed)
                           6009 ;	genPlus
   C2EB A8 10              6010 	mov	r0,_bp
   C2ED 08                 6011 	inc	r0
                           6012 ;     genPlusIncr
   C2EE 74 26              6013 	mov	a,#0x26
   C2F0 26                 6014 	add	a,@r0
   C2F1 FD                 6015 	mov	r5,a
                           6016 ;	Peephole 181	changed mov to clr
   C2F2 E4                 6017 	clr	a
   C2F3 08                 6018 	inc	r0
   C2F4 36                 6019 	addc	a,@r0
   C2F5 FE                 6020 	mov	r6,a
   C2F6 08                 6021 	inc	r0
   C2F7 86 07              6022 	mov	ar7,@r0
                           6023 ;	genPlus
                           6024 ;     genPlusIncr
   C2F9 74 05              6025 	mov	a,#0x05
                           6026 ;	Peephole 236.a	used r5 instead of ar5
   C2FB 2D                 6027 	add	a,r5
   C2FC FD                 6028 	mov	r5,a
                           6029 ;	Peephole 181	changed mov to clr
   C2FD E4                 6030 	clr	a
                           6031 ;	Peephole 236.b	used r6 instead of ar6
   C2FE 3E                 6032 	addc	a,r6
   C2FF FE                 6033 	mov	r6,a
                           6034 ;	genPointerGet
                           6035 ;	genGenPointerGet
   C300 8D 82              6036 	mov	dpl,r5
   C302 8E 83              6037 	mov	dph,r6
   C304 8F F0              6038 	mov	b,r7
   C306 12 E4 9F           6039 	lcall	__gptrget
                           6040 ;	genIfx
   C309 FD                 6041 	mov	r5,a
                           6042 ;	Peephole 105	removed redundant mov
                           6043 ;	genIfxJump
                           6044 ;	Peephole 108.c	removed ljmp by inverse jump logic
   C30A 60 35              6045 	jz	00145$
                           6046 ;	Peephole 300	removed redundant label 00227$
                           6047 ;	../../Common/modules/cIPv6.c:998: *dptr++ = HC1_NEXT_HEADER_COMPRESSED_UDP;
                           6048 ;	genPointerSet
                           6049 ;	genGenPointerSet
   C30C E5 10              6050 	mov	a,_bp
   C30E 24 06              6051 	add	a,#0x06
   C310 F8                 6052 	mov	r0,a
   C311 86 82              6053 	mov	dpl,@r0
   C313 08                 6054 	inc	r0
   C314 86 83              6055 	mov	dph,@r0
   C316 08                 6056 	inc	r0
   C317 86 F0              6057 	mov	b,@r0
   C319 74 BF              6058 	mov	a,#0xBF
   C31B 12 DF B7           6059 	lcall	__gptrput
   C31E A3                 6060 	inc	dptr
   C31F 18                 6061 	dec	r0
   C320 18                 6062 	dec	r0
   C321 A6 82              6063 	mov	@r0,dpl
   C323 08                 6064 	inc	r0
   C324 A6 83              6065 	mov	@r0,dph
                           6066 ;	../../Common/modules/cIPv6.c:999: *dptr++ = buf->options.lowpan_compressed;
                           6067 ;	genPointerSet
                           6068 ;	genGenPointerSet
   C326 E5 10              6069 	mov	a,_bp
   C328 24 06              6070 	add	a,#0x06
   C32A F8                 6071 	mov	r0,a
   C32B 86 82              6072 	mov	dpl,@r0
   C32D 08                 6073 	inc	r0
   C32E 86 83              6074 	mov	dph,@r0
   C330 08                 6075 	inc	r0
   C331 86 F0              6076 	mov	b,@r0
   C333 ED                 6077 	mov	a,r5
   C334 12 DF B7           6078 	lcall	__gptrput
   C337 A3                 6079 	inc	dptr
   C338 18                 6080 	dec	r0
   C339 18                 6081 	dec	r0
   C33A A6 82              6082 	mov	@r0,dpl
   C33C 08                 6083 	inc	r0
   C33D A6 83              6084 	mov	@r0,dph
                           6085 ;	Peephole 112.b	changed ljmp to sjmp
   C33F 80 1A              6086 	sjmp	00149$
   C341                    6087 00145$:
                           6088 ;	../../Common/modules/cIPv6.c:1002: *dptr++ = HC1_NEXT_HEADER_UNCOMPRES_UDP;
                           6089 ;	genPointerSet
                           6090 ;	genGenPointerSet
   C341 E5 10              6091 	mov	a,_bp
   C343 24 06              6092 	add	a,#0x06
   C345 F8                 6093 	mov	r0,a
   C346 86 82              6094 	mov	dpl,@r0
   C348 08                 6095 	inc	r0
   C349 86 83              6096 	mov	dph,@r0
   C34B 08                 6097 	inc	r0
   C34C 86 F0              6098 	mov	b,@r0
   C34E 74 3F              6099 	mov	a,#0x3F
   C350 12 DF B7           6100 	lcall	__gptrput
   C353 A3                 6101 	inc	dptr
   C354 18                 6102 	dec	r0
   C355 18                 6103 	dec	r0
   C356 A6 82              6104 	mov	@r0,dpl
   C358 08                 6105 	inc	r0
   C359 A6 83              6106 	mov	@r0,dph
   C35B                    6107 00149$:
                           6108 ;	../../Common/modules/cIPv6.c:1004: *dptr++ = GENERAL_HOPLIMIT;	/* Hop-limit	*/
                           6109 ;	genPointerSet
                           6110 ;	genGenPointerSet
   C35B E5 10              6111 	mov	a,_bp
   C35D 24 06              6112 	add	a,#0x06
   C35F F8                 6113 	mov	r0,a
   C360 86 82              6114 	mov	dpl,@r0
   C362 08                 6115 	inc	r0
   C363 86 83              6116 	mov	dph,@r0
   C365 08                 6117 	inc	r0
   C366 86 F0              6118 	mov	b,@r0
   C368 74 16              6119 	mov	a,#0x16
   C36A 12 DF B7           6120 	lcall	__gptrput
                           6121 ;	../../Common/modules/cIPv6.c:1005: buf->from = MODULE_CIPV6;
                           6122 ;	genPointerSet
                           6123 ;	genGenPointerSet
   C36D 8A 82              6124 	mov	dpl,r2
   C36F 8B 83              6125 	mov	dph,r3
   C371 8C F0              6126 	mov	b,r4
   C373 74 01              6127 	mov	a,#0x01
   C375 12 DF B7           6128 	lcall	__gptrput
                           6129 ;	../../Common/modules/cIPv6.c:1006: buf->to = MODULE_NONE;
                           6130 ;	genPlus
   C378 A8 10              6131 	mov	r0,_bp
   C37A 08                 6132 	inc	r0
                           6133 ;     genPlusIncr
   C37B 74 1E              6134 	mov	a,#0x1E
   C37D 26                 6135 	add	a,@r0
   C37E FA                 6136 	mov	r2,a
                           6137 ;	Peephole 181	changed mov to clr
   C37F E4                 6138 	clr	a
   C380 08                 6139 	inc	r0
   C381 36                 6140 	addc	a,@r0
   C382 FB                 6141 	mov	r3,a
   C383 08                 6142 	inc	r0
   C384 86 04              6143 	mov	ar4,@r0
                           6144 ;	genPointerSet
                           6145 ;	genGenPointerSet
   C386 8A 82              6146 	mov	dpl,r2
   C388 8B 83              6147 	mov	dph,r3
   C38A 8C F0              6148 	mov	b,r4
                           6149 ;	Peephole 181	changed mov to clr
   C38C E4                 6150 	clr	a
   C38D 12 DF B7           6151 	lcall	__gptrput
                           6152 ;	../../Common/modules/cIPv6.c:1007: stack_buffer_push(buf);
                           6153 ;	genCall
   C390 A8 10              6154 	mov	r0,_bp
   C392 08                 6155 	inc	r0
   C393 86 82              6156 	mov	dpl,@r0
   C395 08                 6157 	inc	r0
   C396 86 83              6158 	mov	dph,@r0
   C398 08                 6159 	inc	r0
   C399 86 F0              6160 	mov	b,@r0
   C39B 12 62 C4           6161 	lcall	_stack_buffer_push
                           6162 ;	../../Common/modules/cIPv6.c:1008: buf=0;
   C39E                    6163 00151$:
                           6164 ;	../../Common/modules/cIPv6.c:1010: return pdTRUE;
                           6165 ;	genRet
   C39E 75 82 01           6166 	mov	dpl,#0x01
   C3A1                    6167 00160$:
   C3A1 85 10 81           6168 	mov	sp,_bp
   C3A4 D0 10              6169 	pop	_bp
   C3A6 22                 6170 	ret
                           6171 ;------------------------------------------------------------
                           6172 ;Allocation info for local variables in function 'add_own_address'
                           6173 ;------------------------------------------------------------
                           6174 ;d_ptr                     Allocated to registers r2 r3 r4 
                           6175 ;i                         Allocated to registers r0 
                           6176 ;------------------------------------------------------------
                           6177 ;	../../Common/modules/cIPv6.c:1013: uint8_t add_own_address(uint8_t *d_ptr)
                           6178 ;	-----------------------------------------
                           6179 ;	 function add_own_address
                           6180 ;	-----------------------------------------
   C3A7                    6181 _add_own_address:
                           6182 ;	genReceive
   C3A7 AA 82              6183 	mov	r2,dpl
   C3A9 AB 83              6184 	mov	r3,dph
   C3AB AC F0              6185 	mov	r4,b
                           6186 ;	../../Common/modules/cIPv6.c:1016: if(cipv6_pib.use_short_address)
                           6187 ;	genPointerGet
                           6188 ;	genFarPointerGet
   C3AD 90 F0 59           6189 	mov	dptr,#(_cipv6_pib + 0x000c)
   C3B0 E0                 6190 	movx	a,@dptr
                           6191 ;	genIfxJump
                           6192 ;	Peephole 108.c	removed ljmp by inverse jump logic
   C3B1 60 2E              6193 	jz	00118$
                           6194 ;	Peephole 300	removed redundant label 00121$
                           6195 ;	../../Common/modules/cIPv6.c:1018: for (i=0; i<2; i++)
                           6196 ;	genAssign
   C3B3 8A 05              6197 	mov	ar5,r2
   C3B5 8B 06              6198 	mov	ar6,r3
   C3B7 8C 07              6199 	mov	ar7,r4
                           6200 ;	genAssign
   C3B9 78 00              6201 	mov	r0,#0x00
   C3BB                    6202 00104$:
                           6203 ;	genCmpLt
                           6204 ;	genCmp
   C3BB B8 02 00           6205 	cjne	r0,#0x02,00122$
   C3BE                    6206 00122$:
                           6207 ;	genIfxJump
                           6208 ;	Peephole 108.a	removed ljmp by inverse jump logic
   C3BE 50 1D              6209 	jnc	00107$
                           6210 ;	Peephole 300	removed redundant label 00123$
                           6211 ;	../../Common/modules/cIPv6.c:1020: *d_ptr++ = cipv6_pib.short_address[i];
                           6212 ;	genPlus
                           6213 ;	Peephole 236.g	used r0 instead of ar0
   C3C0 E8                 6214 	mov	a,r0
   C3C1 24 57              6215 	add	a,#(_cipv6_pib + 0x000a)
   C3C3 F5 82              6216 	mov	dpl,a
                           6217 ;	Peephole 181	changed mov to clr
   C3C5 E4                 6218 	clr	a
   C3C6 34 F0              6219 	addc	a,#((_cipv6_pib + 0x000a) >> 8)
   C3C8 F5 83              6220 	mov	dph,a
                           6221 ;	genPointerGet
                           6222 ;	genFarPointerGet
   C3CA E0                 6223 	movx	a,@dptr
                           6224 ;	genPointerSet
                           6225 ;	genGenPointerSet
   C3CB F9                 6226 	mov	r1,a
   C3CC 8D 82              6227 	mov	dpl,r5
   C3CE 8E 83              6228 	mov	dph,r6
   C3D0 8F F0              6229 	mov	b,r7
                           6230 ;	Peephole 191	removed redundant mov
   C3D2 12 DF B7           6231 	lcall	__gptrput
   C3D5 A3                 6232 	inc	dptr
   C3D6 AD 82              6233 	mov	r5,dpl
   C3D8 AE 83              6234 	mov	r6,dph
                           6235 ;	../../Common/modules/cIPv6.c:1018: for (i=0; i<2; i++)
                           6236 ;	genPlus
                           6237 ;     genPlusIncr
   C3DA 08                 6238 	inc	r0
                           6239 ;	Peephole 112.b	changed ljmp to sjmp
   C3DB 80 DE              6240 	sjmp	00104$
   C3DD                    6241 00107$:
                           6242 ;	../../Common/modules/cIPv6.c:1022: return 2;
                           6243 ;	genRet
   C3DD 75 82 02           6244 	mov	dpl,#0x02
                           6245 ;	../../Common/modules/cIPv6.c:1026: for (i=0; i<8; i++)
                           6246 ;	Peephole 112.b	changed ljmp to sjmp
                           6247 ;	Peephole 251.b	replaced sjmp to ret with ret
   C3E0 22                 6248 	ret
   C3E1                    6249 00118$:
                           6250 ;	genAssign
                           6251 ;	genAssign
   C3E1 7D 00              6252 	mov	r5,#0x00
   C3E3                    6253 00108$:
                           6254 ;	genCmpLt
                           6255 ;	genCmp
   C3E3 BD 08 00           6256 	cjne	r5,#0x08,00124$
   C3E6                    6257 00124$:
                           6258 ;	genIfxJump
                           6259 ;	Peephole 108.a	removed ljmp by inverse jump logic
   C3E6 50 1D              6260 	jnc	00111$
                           6261 ;	Peephole 300	removed redundant label 00125$
                           6262 ;	../../Common/modules/cIPv6.c:1028: *d_ptr++ = cipv6_pib.long_address[i];
                           6263 ;	genPlus
                           6264 ;	Peephole 236.g	used r5 instead of ar5
   C3E8 ED                 6265 	mov	a,r5
   C3E9 24 4F              6266 	add	a,#(_cipv6_pib + 0x0002)
   C3EB F5 82              6267 	mov	dpl,a
                           6268 ;	Peephole 181	changed mov to clr
   C3ED E4                 6269 	clr	a
   C3EE 34 F0              6270 	addc	a,#((_cipv6_pib + 0x0002) >> 8)
   C3F0 F5 83              6271 	mov	dph,a
                           6272 ;	genPointerGet
                           6273 ;	genFarPointerGet
   C3F2 E0                 6274 	movx	a,@dptr
                           6275 ;	genPointerSet
                           6276 ;	genGenPointerSet
   C3F3 FE                 6277 	mov	r6,a
   C3F4 8A 82              6278 	mov	dpl,r2
   C3F6 8B 83              6279 	mov	dph,r3
   C3F8 8C F0              6280 	mov	b,r4
                           6281 ;	Peephole 191	removed redundant mov
   C3FA 12 DF B7           6282 	lcall	__gptrput
   C3FD A3                 6283 	inc	dptr
   C3FE AA 82              6284 	mov	r2,dpl
   C400 AB 83              6285 	mov	r3,dph
                           6286 ;	../../Common/modules/cIPv6.c:1026: for (i=0; i<8; i++)
                           6287 ;	genPlus
                           6288 ;     genPlusIncr
   C402 0D                 6289 	inc	r5
                           6290 ;	Peephole 112.b	changed ljmp to sjmp
   C403 80 DE              6291 	sjmp	00108$
   C405                    6292 00111$:
                           6293 ;	../../Common/modules/cIPv6.c:1030: return 8;
                           6294 ;	genRet
   C405 75 82 08           6295 	mov	dpl,#0x08
                           6296 ;	Peephole 300	removed redundant label 00112$
   C408 22                 6297 	ret
                           6298 ;------------------------------------------------------------
                           6299 ;Allocation info for local variables in function 'update_ip_sqn'
                           6300 ;------------------------------------------------------------
                           6301 ;------------------------------------------------------------
                           6302 ;	../../Common/modules/cIPv6.c:1034: void update_ip_sqn(void)
                           6303 ;	-----------------------------------------
                           6304 ;	 function update_ip_sqn
                           6305 ;	-----------------------------------------
   C409                    6306 _update_ip_sqn:
                           6307 ;	../../Common/modules/cIPv6.c:1036: cipv6_pib.last_forwarded_bc_sqn = cipv6_pib.own_brodcast_sqn;
                           6308 ;	genPointerGet
                           6309 ;	genFarPointerGet
   C409 90 F0 4D           6310 	mov	dptr,#_cipv6_pib
   C40C E0                 6311 	movx	a,@dptr
                           6312 ;	genPointerSet
                           6313 ;     genFarPointerSet
   C40D FA                 6314 	mov	r2,a
   C40E 90 F0 4E           6315 	mov	dptr,#(_cipv6_pib + 0x0001)
                           6316 ;	Peephole 100	removed redundant mov
   C411 F0                 6317 	movx	@dptr,a
                           6318 ;	../../Common/modules/cIPv6.c:1038: if(cipv6_pib.own_brodcast_sqn==0xff) cipv6_pib.own_brodcast_sqn=1;
                           6319 ;	genCmpEq
                           6320 ;	gencjneshort
                           6321 ;	Peephole 112.b	changed ljmp to sjmp
                           6322 ;	Peephole 198.b	optimized misc jump sequence
   C412 BA FF 07           6323 	cjne	r2,#0xFF,00102$
                           6324 ;	Peephole 200.b	removed redundant sjmp
                           6325 ;	Peephole 300	removed redundant label 00107$
                           6326 ;	Peephole 300	removed redundant label 00108$
                           6327 ;	genPointerSet
                           6328 ;     genFarPointerSet
   C415 90 F0 4D           6329 	mov	dptr,#_cipv6_pib
   C418 74 01              6330 	mov	a,#0x01
   C41A F0                 6331 	movx	@dptr,a
                           6332 ;	Peephole 112.b	changed ljmp to sjmp
                           6333 ;	Peephole 251.b	replaced sjmp to ret with ret
   C41B 22                 6334 	ret
   C41C                    6335 00102$:
                           6336 ;	../../Common/modules/cIPv6.c:1039: else cipv6_pib.own_brodcast_sqn++;
                           6337 ;	genPointerGet
                           6338 ;	genFarPointerGet
   C41C 90 F0 4D           6339 	mov	dptr,#_cipv6_pib
   C41F E0                 6340 	movx	a,@dptr
                           6341 ;	genPlus
                           6342 ;     genPlusIncr
                           6343 ;	Peephole 185	changed order of increment (acc incremented also!)
   C420 04                 6344 	inc	a
   C421 FA                 6345 	mov	r2,a
                           6346 ;	genPointerSet
                           6347 ;     genFarPointerSet
   C422 90 F0 4D           6348 	mov	dptr,#_cipv6_pib
   C425 EA                 6349 	mov	a,r2
   C426 F0                 6350 	movx	@dptr,a
                           6351 ;	Peephole 300	removed redundant label 00104$
   C427 22                 6352 	ret
                           6353 ;------------------------------------------------------------
                           6354 ;Allocation info for local variables in function 'build_ipv6_header'
                           6355 ;------------------------------------------------------------
                           6356 ;buf                       Allocated to stack - offset 1
                           6357 ;next_header               Allocated to stack - offset 4
                           6358 ;i                         Allocated to stack - offset 5
                           6359 ;dptr                      Allocated to stack - offset 6
                           6360 ;payload_length            Allocated to stack - offset 9
                           6361 ;ipv6_address              Allocated to stack - offset 11
                           6362 ;destination_delivery      Allocated to registers r2 
                           6363 ;sloc0                     Allocated to stack - offset 21
                           6364 ;sloc1                     Allocated to stack - offset 25
                           6365 ;sloc2                     Allocated to stack - offset 26
                           6366 ;sloc3                     Allocated to stack - offset 24
                           6367 ;------------------------------------------------------------
                           6368 ;	../../Common/modules/cIPv6.c:1048: portCHAR build_ipv6_header(buffer_t *buf)
                           6369 ;	-----------------------------------------
                           6370 ;	 function build_ipv6_header
                           6371 ;	-----------------------------------------
   C428                    6372 _build_ipv6_header:
   C428 C0 10              6373 	push	_bp
   C42A 85 81 10           6374 	mov	_bp,sp
                           6375 ;     genReceive
   C42D C0 82              6376 	push	dpl
   C42F C0 83              6377 	push	dph
   C431 C0 F0              6378 	push	b
   C433 E5 81              6379 	mov	a,sp
   C435 24 1A              6380 	add	a,#0x1a
   C437 F5 81              6381 	mov	sp,a
                           6382 ;	../../Common/modules/cIPv6.c:1055: memset(ipv6_address, 0,8);
                           6383 ;	genAddrOf
   C439 E5 10              6384 	mov	a,_bp
   C43B 24 0B              6385 	add	a,#0x0b
   C43D F8                 6386 	mov	r0,a
                           6387 ;	genCast
   C43E 88 05              6388 	mov	ar5,r0
   C440 7E 00              6389 	mov	r6,#0x00
   C442 7F 40              6390 	mov	r7,#0x40
                           6391 ;	genIpush
   C444 C0 00              6392 	push	ar0
   C446 74 08              6393 	mov	a,#0x08
   C448 C0 E0              6394 	push	acc
                           6395 ;	Peephole 181	changed mov to clr
   C44A E4                 6396 	clr	a
   C44B C0 E0              6397 	push	acc
                           6398 ;	genIpush
                           6399 ;	Peephole 181	changed mov to clr
   C44D E4                 6400 	clr	a
   C44E C0 E0              6401 	push	acc
                           6402 ;	genCall
   C450 8D 82              6403 	mov	dpl,r5
   C452 8E 83              6404 	mov	dph,r6
   C454 8F F0              6405 	mov	b,r7
   C456 12 E3 65           6406 	lcall	_memset
   C459 15 81              6407 	dec	sp
   C45B 15 81              6408 	dec	sp
   C45D 15 81              6409 	dec	sp
   C45F D0 00              6410 	pop	ar0
                           6411 ;	../../Common/modules/cIPv6.c:1056: payload_length = (buf->buf_end - buf->buf_ptr);
                           6412 ;	genPlus
   C461 A9 10              6413 	mov	r1,_bp
   C463 09                 6414 	inc	r1
                           6415 ;     genPlusIncr
   C464 74 22              6416 	mov	a,#0x22
   C466 27                 6417 	add	a,@r1
   C467 FD                 6418 	mov	r5,a
                           6419 ;	Peephole 181	changed mov to clr
   C468 E4                 6420 	clr	a
   C469 09                 6421 	inc	r1
   C46A 37                 6422 	addc	a,@r1
   C46B FE                 6423 	mov	r6,a
   C46C 09                 6424 	inc	r1
   C46D 87 07              6425 	mov	ar7,@r1
                           6426 ;	genPointerGet
                           6427 ;	genGenPointerGet
   C46F 8D 82              6428 	mov	dpl,r5
   C471 8E 83              6429 	mov	dph,r6
   C473 8F F0              6430 	mov	b,r7
   C475 12 E4 9F           6431 	lcall	__gptrget
   C478 FD                 6432 	mov	r5,a
   C479 A3                 6433 	inc	dptr
   C47A 12 E4 9F           6434 	lcall	__gptrget
   C47D FE                 6435 	mov	r6,a
                           6436 ;	genPlus
   C47E A9 10              6437 	mov	r1,_bp
   C480 09                 6438 	inc	r1
                           6439 ;     genPlusIncr
   C481 74 20              6440 	mov	a,#0x20
   C483 27                 6441 	add	a,@r1
   C484 FF                 6442 	mov	r7,a
                           6443 ;	Peephole 181	changed mov to clr
   C485 E4                 6444 	clr	a
   C486 09                 6445 	inc	r1
   C487 37                 6446 	addc	a,@r1
   C488 FA                 6447 	mov	r2,a
   C489 09                 6448 	inc	r1
   C48A 87 03              6449 	mov	ar3,@r1
                           6450 ;	genPointerGet
                           6451 ;	genGenPointerGet
   C48C 8F 82              6452 	mov	dpl,r7
   C48E 8A 83              6453 	mov	dph,r2
   C490 8B F0              6454 	mov	b,r3
   C492 12 E4 9F           6455 	lcall	__gptrget
   C495 FF                 6456 	mov	r7,a
   C496 A3                 6457 	inc	dptr
   C497 12 E4 9F           6458 	lcall	__gptrget
   C49A FA                 6459 	mov	r2,a
                           6460 ;	genMinus
   C49B ED                 6461 	mov	a,r5
   C49C C3                 6462 	clr	c
                           6463 ;	Peephole 236.l	used r7 instead of ar7
   C49D 9F                 6464 	subb	a,r7
   C49E FD                 6465 	mov	r5,a
   C49F EE                 6466 	mov	a,r6
                           6467 ;	Peephole 236.l	used r2 instead of ar2
   C4A0 9A                 6468 	subb	a,r2
   C4A1 FE                 6469 	mov	r6,a
                           6470 ;	genAssign
   C4A2 E5 10              6471 	mov	a,_bp
   C4A4 24 09              6472 	add	a,#0x09
   C4A6 F9                 6473 	mov	r1,a
   C4A7 A7 05              6474 	mov	@r1,ar5
   C4A9 09                 6475 	inc	r1
   C4AA A7 06              6476 	mov	@r1,ar6
                           6477 ;	../../Common/modules/cIPv6.c:1058: if(stack_buffer_headroom( buf,41)==pdFALSE)
                           6478 ;	genIpush
   C4AC C0 00              6479 	push	ar0
   C4AE 74 29              6480 	mov	a,#0x29
   C4B0 C0 E0              6481 	push	acc
                           6482 ;	Peephole 181	changed mov to clr
   C4B2 E4                 6483 	clr	a
   C4B3 C0 E0              6484 	push	acc
                           6485 ;	genCall
   C4B5 A9 10              6486 	mov	r1,_bp
   C4B7 09                 6487 	inc	r1
   C4B8 87 82              6488 	mov	dpl,@r1
   C4BA 09                 6489 	inc	r1
   C4BB 87 83              6490 	mov	dph,@r1
   C4BD 09                 6491 	inc	r1
   C4BE 87 F0              6492 	mov	b,@r1
   C4C0 12 63 20           6493 	lcall	_stack_buffer_headroom
   C4C3 AC 82              6494 	mov	r4,dpl
   C4C5 15 81              6495 	dec	sp
   C4C7 15 81              6496 	dec	sp
   C4C9 D0 00              6497 	pop	ar0
                           6498 ;	genIfx
   C4CB EC                 6499 	mov	a,r4
                           6500 ;	genIfxJump
                           6501 ;	Peephole 108.b	removed ljmp by inverse jump logic
   C4CC 70 14              6502 	jnz	00102$
                           6503 ;	Peephole 300	removed redundant label 00179$
                           6504 ;	../../Common/modules/cIPv6.c:1060: stack_buffer_free(buf);
                           6505 ;	genCall
   C4CE A8 10              6506 	mov	r0,_bp
   C4D0 08                 6507 	inc	r0
   C4D1 86 82              6508 	mov	dpl,@r0
   C4D3 08                 6509 	inc	r0
   C4D4 86 83              6510 	mov	dph,@r0
   C4D6 08                 6511 	inc	r0
   C4D7 86 F0              6512 	mov	b,@r0
   C4D9 12 61 FA           6513 	lcall	_stack_buffer_free
                           6514 ;	../../Common/modules/cIPv6.c:1061: return pdTRUE;
                           6515 ;	genRet
   C4DC 75 82 01           6516 	mov	dpl,#0x01
   C4DF 02 CA 1C           6517 	ljmp	00147$
   C4E2                    6518 00102$:
                           6519 ;	../../Common/modules/cIPv6.c:1063: buf->buf_ptr -= 41;
                           6520 ;	genIpush
                           6521 ;	genPlus
   C4E2 A9 10              6522 	mov	r1,_bp
   C4E4 09                 6523 	inc	r1
                           6524 ;     genPlusIncr
   C4E5 74 20              6525 	mov	a,#0x20
   C4E7 27                 6526 	add	a,@r1
   C4E8 FC                 6527 	mov	r4,a
                           6528 ;	Peephole 181	changed mov to clr
   C4E9 E4                 6529 	clr	a
   C4EA 09                 6530 	inc	r1
   C4EB 37                 6531 	addc	a,@r1
   C4EC FD                 6532 	mov	r5,a
   C4ED 09                 6533 	inc	r1
   C4EE 87 06              6534 	mov	ar6,@r1
                           6535 ;	genPointerGet
                           6536 ;	genGenPointerGet
   C4F0 8C 82              6537 	mov	dpl,r4
   C4F2 8D 83              6538 	mov	dph,r5
   C4F4 8E F0              6539 	mov	b,r6
   C4F6 12 E4 9F           6540 	lcall	__gptrget
   C4F9 FF                 6541 	mov	r7,a
   C4FA A3                 6542 	inc	dptr
   C4FB 12 E4 9F           6543 	lcall	__gptrget
   C4FE FA                 6544 	mov	r2,a
                           6545 ;	genMinus
   C4FF EF                 6546 	mov	a,r7
   C500 24 D7              6547 	add	a,#0xd7
   C502 FF                 6548 	mov	r7,a
   C503 EA                 6549 	mov	a,r2
   C504 34 FF              6550 	addc	a,#0xff
   C506 FA                 6551 	mov	r2,a
                           6552 ;	genPointerSet
                           6553 ;	genGenPointerSet
   C507 8C 82              6554 	mov	dpl,r4
   C509 8D 83              6555 	mov	dph,r5
   C50B 8E F0              6556 	mov	b,r6
   C50D EF                 6557 	mov	a,r7
   C50E 12 DF B7           6558 	lcall	__gptrput
   C511 A3                 6559 	inc	dptr
   C512 EA                 6560 	mov	a,r2
   C513 12 DF B7           6561 	lcall	__gptrput
                           6562 ;	../../Common/modules/cIPv6.c:1065: if(buf->dst_sa.addr_type != ADDR_BROADCAST && buf->dst_sa.addr_type != ADDR_COORDINATOR)
                           6563 ;	genPlus
   C516 A9 10              6564 	mov	r1,_bp
   C518 09                 6565 	inc	r1
   C519 C0 00              6566 	push	ar0
   C51B E5 10              6567 	mov	a,_bp
   C51D 24 15              6568 	add	a,#0x15
   C51F F8                 6569 	mov	r0,a
                           6570 ;     genPlusIncr
   C520 74 03              6571 	mov	a,#0x03
   C522 27                 6572 	add	a,@r1
   C523 F6                 6573 	mov	@r0,a
                           6574 ;	Peephole 181	changed mov to clr
   C524 E4                 6575 	clr	a
   C525 09                 6576 	inc	r1
   C526 37                 6577 	addc	a,@r1
   C527 08                 6578 	inc	r0
   C528 F6                 6579 	mov	@r0,a
   C529 09                 6580 	inc	r1
   C52A 08                 6581 	inc	r0
   C52B E7                 6582 	mov	a,@r1
   C52C F6                 6583 	mov	@r0,a
   C52D D0 00              6584 	pop	ar0
                           6585 ;	genPointerGet
                           6586 ;	genGenPointerGet
   C52F E5 10              6587 	mov	a,_bp
   C531 24 15              6588 	add	a,#0x15
   C533 F9                 6589 	mov	r1,a
   C534 87 82              6590 	mov	dpl,@r1
   C536 09                 6591 	inc	r1
   C537 87 83              6592 	mov	dph,@r1
   C539 09                 6593 	inc	r1
   C53A 87 F0              6594 	mov	b,@r1
   C53C 12 E4 9F           6595 	lcall	__gptrget
   C53F FA                 6596 	mov	r2,a
                           6597 ;	genCmpEq
                           6598 ;	gencjne
                           6599 ;	gencjneshort
                           6600 ;	Peephole 241.d	optimized compare
   C540 E4                 6601 	clr	a
   C541 BA 08 01           6602 	cjne	r2,#0x08,00180$
   C544 04                 6603 	inc	a
   C545                    6604 00180$:
                           6605 ;	Peephole 300	removed redundant label 00181$
                           6606 ;	genIpop
                           6607 ;	genIfx
                           6608 ;	genIfxJump
                           6609 ;	Peephole 112.b	changed ljmp to sjmp
                           6610 ;	Peephole 160.d	removed sjmp by inverse jump logic
   C545 70 76              6611 	jnz	00106$
                           6612 ;	Peephole 300	removed redundant label 00182$
                           6613 ;	genCmpEq
                           6614 ;	gencjneshort
   C547 BA 09 02           6615 	cjne	r2,#0x09,00183$
                           6616 ;	Peephole 112.b	changed ljmp to sjmp
   C54A 80 71              6617 	sjmp	00106$
   C54C                    6618 00183$:
                           6619 ;	../../Common/modules/cIPv6.c:1067: destination_delivery = check_neighbour_table(buf->dst_sa.addr_type, buf->dst_sa.address);
                           6620 ;	genIpush
                           6621 ;	genPlus
   C54C A9 10              6622 	mov	r1,_bp
   C54E 09                 6623 	inc	r1
                           6624 ;     genPlusIncr
   C54F 74 03              6625 	mov	a,#0x03
   C551 27                 6626 	add	a,@r1
   C552 FA                 6627 	mov	r2,a
                           6628 ;	Peephole 181	changed mov to clr
   C553 E4                 6629 	clr	a
   C554 09                 6630 	inc	r1
   C555 37                 6631 	addc	a,@r1
   C556 FB                 6632 	mov	r3,a
   C557 09                 6633 	inc	r1
   C558 87 07              6634 	mov	ar7,@r1
                           6635 ;	genPlus
   C55A E5 10              6636 	mov	a,_bp
   C55C 24 18              6637 	add	a,#0x18
   C55E F9                 6638 	mov	r1,a
                           6639 ;     genPlusIncr
   C55F 74 01              6640 	mov	a,#0x01
                           6641 ;	Peephole 236.a	used r2 instead of ar2
   C561 2A                 6642 	add	a,r2
   C562 F7                 6643 	mov	@r1,a
                           6644 ;	Peephole 181	changed mov to clr
   C563 E4                 6645 	clr	a
                           6646 ;	Peephole 236.b	used r3 instead of ar3
   C564 3B                 6647 	addc	a,r3
   C565 09                 6648 	inc	r1
   C566 F7                 6649 	mov	@r1,a
   C567 09                 6650 	inc	r1
   C568 A7 07              6651 	mov	@r1,ar7
                           6652 ;	genPointerGet
                           6653 ;	genGenPointerGet
   C56A 8A 82              6654 	mov	dpl,r2
   C56C 8B 83              6655 	mov	dph,r3
   C56E 8F F0              6656 	mov	b,r7
   C570 12 E4 9F           6657 	lcall	__gptrget
   C573 FA                 6658 	mov	r2,a
                           6659 ;	genIpush
   C574 C0 04              6660 	push	ar4
   C576 C0 05              6661 	push	ar5
   C578 C0 06              6662 	push	ar6
   C57A C0 00              6663 	push	ar0
   C57C E5 10              6664 	mov	a,_bp
   C57E 24 18              6665 	add	a,#0x18
   C580 F9                 6666 	mov	r1,a
   C581 E7                 6667 	mov	a,@r1
   C582 C0 E0              6668 	push	acc
   C584 09                 6669 	inc	r1
   C585 E7                 6670 	mov	a,@r1
   C586 C0 E0              6671 	push	acc
   C588 09                 6672 	inc	r1
   C589 E7                 6673 	mov	a,@r1
   C58A C0 E0              6674 	push	acc
                           6675 ;	genCall
   C58C 8A 82              6676 	mov	dpl,r2
   C58E 12 74 BF           6677 	lcall	_check_neighbour_table
   C591 AA 82              6678 	mov	r2,dpl
   C593 15 81              6679 	dec	sp
   C595 15 81              6680 	dec	sp
   C597 15 81              6681 	dec	sp
   C599 D0 00              6682 	pop	ar0
   C59B D0 06              6683 	pop	ar6
   C59D D0 05              6684 	pop	ar5
   C59F D0 04              6685 	pop	ar4
                           6686 ;	genAssign
                           6687 ;	../../Common/modules/cIPv6.c:1068: if(destination_delivery==BROADCAST)
                           6688 ;	genIfx
   C5A1 EA                 6689 	mov	a,r2
                           6690 ;	genIpop
                           6691 ;	genIfxJump
                           6692 ;	Peephole 108.b	removed ljmp by inverse jump logic
   C5A2 70 19              6693 	jnz	00106$
                           6694 ;	Peephole 300	removed redundant label 00184$
                           6695 ;	../../Common/modules/cIPv6.c:1070: buf->dst_sa.addr_type = ADDR_BROADCAST;
                           6696 ;	genPlus
   C5A4 A9 10              6697 	mov	r1,_bp
   C5A6 09                 6698 	inc	r1
                           6699 ;     genPlusIncr
   C5A7 74 03              6700 	mov	a,#0x03
   C5A9 27                 6701 	add	a,@r1
   C5AA FF                 6702 	mov	r7,a
                           6703 ;	Peephole 181	changed mov to clr
   C5AB E4                 6704 	clr	a
   C5AC 09                 6705 	inc	r1
   C5AD 37                 6706 	addc	a,@r1
   C5AE FA                 6707 	mov	r2,a
   C5AF 09                 6708 	inc	r1
   C5B0 87 03              6709 	mov	ar3,@r1
                           6710 ;	genPointerSet
                           6711 ;	genGenPointerSet
   C5B2 8F 82              6712 	mov	dpl,r7
   C5B4 8A 83              6713 	mov	dph,r2
   C5B6 8B F0              6714 	mov	b,r3
   C5B8 74 08              6715 	mov	a,#0x08
   C5BA 12 DF B7           6716 	lcall	__gptrput
   C5BD                    6717 00106$:
                           6718 ;	../../Common/modules/cIPv6.c:1073: if(buf->from == MODULE_CUDP)
                           6719 ;	genIpush
   C5BD C0 04              6720 	push	ar4
   C5BF C0 05              6721 	push	ar5
   C5C1 C0 06              6722 	push	ar6
                           6723 ;	genPlus
   C5C3 A9 10              6724 	mov	r1,_bp
   C5C5 09                 6725 	inc	r1
   C5C6 C0 00              6726 	push	ar0
   C5C8 E5 10              6727 	mov	a,_bp
   C5CA 24 18              6728 	add	a,#0x18
   C5CC F8                 6729 	mov	r0,a
                           6730 ;     genPlusIncr
   C5CD 74 1D              6731 	mov	a,#0x1D
   C5CF 27                 6732 	add	a,@r1
   C5D0 F6                 6733 	mov	@r0,a
                           6734 ;	Peephole 181	changed mov to clr
   C5D1 E4                 6735 	clr	a
   C5D2 09                 6736 	inc	r1
   C5D3 37                 6737 	addc	a,@r1
   C5D4 08                 6738 	inc	r0
   C5D5 F6                 6739 	mov	@r0,a
   C5D6 09                 6740 	inc	r1
   C5D7 08                 6741 	inc	r0
   C5D8 E7                 6742 	mov	a,@r1
   C5D9 F6                 6743 	mov	@r0,a
   C5DA D0 00              6744 	pop	ar0
                           6745 ;	genPointerGet
                           6746 ;	genGenPointerGet
   C5DC E5 10              6747 	mov	a,_bp
   C5DE 24 18              6748 	add	a,#0x18
   C5E0 F9                 6749 	mov	r1,a
   C5E1 87 82              6750 	mov	dpl,@r1
   C5E3 09                 6751 	inc	r1
   C5E4 87 83              6752 	mov	dph,@r1
   C5E6 09                 6753 	inc	r1
   C5E7 87 F0              6754 	mov	b,@r1
   C5E9 12 E4 9F           6755 	lcall	__gptrget
   C5EC FC                 6756 	mov	r4,a
                           6757 ;	genCmpEq
                           6758 ;	gencjne
                           6759 ;	gencjneshort
                           6760 ;	Peephole 241.d	optimized compare
   C5ED E4                 6761 	clr	a
   C5EE BC 02 01           6762 	cjne	r4,#0x02,00185$
   C5F1 04                 6763 	inc	a
   C5F2                    6764 00185$:
                           6765 ;	Peephole 300	removed redundant label 00186$
                           6766 ;	genIpop
   C5F2 D0 06              6767 	pop	ar6
   C5F4 D0 05              6768 	pop	ar5
   C5F6 D0 04              6769 	pop	ar4
                           6770 ;	genIfx
                           6771 ;	genIfxJump
                           6772 ;	Peephole 108.c	removed ljmp by inverse jump logic
   C5F8 60 09              6773 	jz	00109$
                           6774 ;	Peephole 300	removed redundant label 00187$
                           6775 ;	../../Common/modules/cIPv6.c:1074: next_header = NEXT_HEADER_UDP;
                           6776 ;	genAssign
   C5FA E5 10              6777 	mov	a,_bp
   C5FC 24 04              6778 	add	a,#0x04
   C5FE F9                 6779 	mov	r1,a
   C5FF 77 11              6780 	mov	@r1,#0x11
                           6781 ;	Peephole 112.b	changed ljmp to sjmp
   C601 80 07              6782 	sjmp	00110$
   C603                    6783 00109$:
                           6784 ;	../../Common/modules/cIPv6.c:1076: next_header = NEXT_HEADER_ICMP6;
                           6785 ;	genAssign
   C603 E5 10              6786 	mov	a,_bp
   C605 24 04              6787 	add	a,#0x04
   C607 F9                 6788 	mov	r1,a
   C608 77 3A              6789 	mov	@r1,#0x3A
   C60A                    6790 00110$:
                           6791 ;	../../Common/modules/cIPv6.c:1079: dptr = buf->buf + buf->buf_ptr;
                           6792 ;	genIpush
                           6793 ;	genPlus
   C60A A9 10              6794 	mov	r1,_bp
   C60C 09                 6795 	inc	r1
                           6796 ;     genPlusIncr
   C60D 74 2C              6797 	mov	a,#0x2C
   C60F 27                 6798 	add	a,@r1
   C610 FA                 6799 	mov	r2,a
                           6800 ;	Peephole 181	changed mov to clr
   C611 E4                 6801 	clr	a
   C612 09                 6802 	inc	r1
   C613 37                 6803 	addc	a,@r1
   C614 FB                 6804 	mov	r3,a
   C615 09                 6805 	inc	r1
   C616 87 07              6806 	mov	ar7,@r1
                           6807 ;	genPointerGet
                           6808 ;	genGenPointerGet
   C618 8C 82              6809 	mov	dpl,r4
   C61A 8D 83              6810 	mov	dph,r5
   C61C 8E F0              6811 	mov	b,r6
   C61E 12 E4 9F           6812 	lcall	__gptrget
   C621 FC                 6813 	mov	r4,a
   C622 A3                 6814 	inc	dptr
   C623 12 E4 9F           6815 	lcall	__gptrget
   C626 FD                 6816 	mov	r5,a
                           6817 ;	genPlus
                           6818 ;	Peephole 236.g	used r4 instead of ar4
   C627 EC                 6819 	mov	a,r4
                           6820 ;	Peephole 236.a	used r2 instead of ar2
   C628 2A                 6821 	add	a,r2
   C629 FA                 6822 	mov	r2,a
                           6823 ;	Peephole 236.g	used r5 instead of ar5
   C62A ED                 6824 	mov	a,r5
                           6825 ;	Peephole 236.b	used r3 instead of ar3
   C62B 3B                 6826 	addc	a,r3
   C62C FB                 6827 	mov	r3,a
                           6828 ;	genAssign
   C62D E5 10              6829 	mov	a,_bp
   C62F 24 06              6830 	add	a,#0x06
   C631 F9                 6831 	mov	r1,a
   C632 A7 02              6832 	mov	@r1,ar2
   C634 09                 6833 	inc	r1
   C635 A7 03              6834 	mov	@r1,ar3
   C637 09                 6835 	inc	r1
   C638 A7 07              6836 	mov	@r1,ar7
                           6837 ;	../../Common/modules/cIPv6.c:1080: *dptr++ = IPV6;
                           6838 ;	genPointerSet
                           6839 ;	genGenPointerSet
   C63A E5 10              6840 	mov	a,_bp
   C63C 24 06              6841 	add	a,#0x06
   C63E F9                 6842 	mov	r1,a
   C63F 87 82              6843 	mov	dpl,@r1
   C641 09                 6844 	inc	r1
   C642 87 83              6845 	mov	dph,@r1
   C644 09                 6846 	inc	r1
   C645 87 F0              6847 	mov	b,@r1
   C647 74 82              6848 	mov	a,#0x82
   C649 12 DF B7           6849 	lcall	__gptrput
   C64C A3                 6850 	inc	dptr
   C64D 19                 6851 	dec	r1
   C64E 19                 6852 	dec	r1
   C64F A7 82              6853 	mov	@r1,dpl
   C651 09                 6854 	inc	r1
   C652 A7 83              6855 	mov	@r1,dph
                           6856 ;	../../Common/modules/cIPv6.c:1081: *dptr++ = 0x06;
                           6857 ;	genPointerSet
                           6858 ;	genGenPointerSet
   C654 E5 10              6859 	mov	a,_bp
   C656 24 06              6860 	add	a,#0x06
   C658 F9                 6861 	mov	r1,a
   C659 87 82              6862 	mov	dpl,@r1
   C65B 09                 6863 	inc	r1
   C65C 87 83              6864 	mov	dph,@r1
   C65E 09                 6865 	inc	r1
   C65F 87 F0              6866 	mov	b,@r1
   C661 74 06              6867 	mov	a,#0x06
   C663 12 DF B7           6868 	lcall	__gptrput
   C666 A3                 6869 	inc	dptr
   C667 19                 6870 	dec	r1
   C668 19                 6871 	dec	r1
   C669 A7 82              6872 	mov	@r1,dpl
   C66B 09                 6873 	inc	r1
   C66C A7 83              6874 	mov	@r1,dph
                           6875 ;	../../Common/modules/cIPv6.c:1082: *dptr++ = 0x00;
                           6876 ;	genPointerSet
                           6877 ;	genGenPointerSet
   C66E E5 10              6878 	mov	a,_bp
   C670 24 06              6879 	add	a,#0x06
   C672 F9                 6880 	mov	r1,a
   C673 87 82              6881 	mov	dpl,@r1
   C675 09                 6882 	inc	r1
   C676 87 83              6883 	mov	dph,@r1
   C678 09                 6884 	inc	r1
   C679 87 F0              6885 	mov	b,@r1
                           6886 ;	Peephole 181	changed mov to clr
   C67B E4                 6887 	clr	a
   C67C 12 DF B7           6888 	lcall	__gptrput
   C67F A3                 6889 	inc	dptr
   C680 19                 6890 	dec	r1
   C681 19                 6891 	dec	r1
   C682 A7 82              6892 	mov	@r1,dpl
   C684 09                 6893 	inc	r1
   C685 A7 83              6894 	mov	@r1,dph
                           6895 ;	../../Common/modules/cIPv6.c:1083: *dptr++ = 0x00;
                           6896 ;	genPointerSet
                           6897 ;	genGenPointerSet
   C687 E5 10              6898 	mov	a,_bp
   C689 24 06              6899 	add	a,#0x06
   C68B F9                 6900 	mov	r1,a
   C68C 87 82              6901 	mov	dpl,@r1
   C68E 09                 6902 	inc	r1
   C68F 87 83              6903 	mov	dph,@r1
   C691 09                 6904 	inc	r1
   C692 87 F0              6905 	mov	b,@r1
                           6906 ;	Peephole 181	changed mov to clr
   C694 E4                 6907 	clr	a
   C695 12 DF B7           6908 	lcall	__gptrput
   C698 A3                 6909 	inc	dptr
   C699 19                 6910 	dec	r1
   C69A 19                 6911 	dec	r1
   C69B A7 82              6912 	mov	@r1,dpl
   C69D 09                 6913 	inc	r1
   C69E A7 83              6914 	mov	@r1,dph
                           6915 ;	../../Common/modules/cIPv6.c:1084: *dptr++ = 0x00;
                           6916 ;	genPointerSet
                           6917 ;	genGenPointerSet
   C6A0 E5 10              6918 	mov	a,_bp
   C6A2 24 06              6919 	add	a,#0x06
   C6A4 F9                 6920 	mov	r1,a
   C6A5 87 82              6921 	mov	dpl,@r1
   C6A7 09                 6922 	inc	r1
   C6A8 87 83              6923 	mov	dph,@r1
   C6AA 09                 6924 	inc	r1
   C6AB 87 F0              6925 	mov	b,@r1
                           6926 ;	Peephole 181	changed mov to clr
   C6AD E4                 6927 	clr	a
   C6AE 12 DF B7           6928 	lcall	__gptrput
   C6B1 A3                 6929 	inc	dptr
   C6B2 19                 6930 	dec	r1
   C6B3 19                 6931 	dec	r1
   C6B4 A7 82              6932 	mov	@r1,dpl
   C6B6 09                 6933 	inc	r1
   C6B7 A7 83              6934 	mov	@r1,dph
                           6935 ;	../../Common/modules/cIPv6.c:1085: *dptr++ = (payload_length >> 8);	
                           6936 ;	genGetByte
   C6B9 E5 10              6937 	mov	a,_bp
   C6BB 24 09              6938 	add	a,#0x09
                           6939 ;	Peephole 185	changed order of increment (acc incremented also!)
   C6BD 04                 6940 	inc	a
   C6BE F9                 6941 	mov	r1,a
   C6BF 87 02              6942 	mov	ar2,@r1
                           6943 ;	genPointerSet
                           6944 ;	genGenPointerSet
   C6C1 E5 10              6945 	mov	a,_bp
   C6C3 24 06              6946 	add	a,#0x06
   C6C5 F9                 6947 	mov	r1,a
   C6C6 87 82              6948 	mov	dpl,@r1
   C6C8 09                 6949 	inc	r1
   C6C9 87 83              6950 	mov	dph,@r1
   C6CB 09                 6951 	inc	r1
   C6CC 87 F0              6952 	mov	b,@r1
   C6CE EA                 6953 	mov	a,r2
   C6CF 12 DF B7           6954 	lcall	__gptrput
   C6D2 A3                 6955 	inc	dptr
   C6D3 19                 6956 	dec	r1
   C6D4 19                 6957 	dec	r1
   C6D5 A7 82              6958 	mov	@r1,dpl
   C6D7 09                 6959 	inc	r1
   C6D8 A7 83              6960 	mov	@r1,dph
                           6961 ;	../../Common/modules/cIPv6.c:1086: *dptr++ = (uint8_t) payload_length;			/* Length */
                           6962 ;	genCast
   C6DA E5 10              6963 	mov	a,_bp
   C6DC 24 09              6964 	add	a,#0x09
   C6DE F9                 6965 	mov	r1,a
   C6DF 87 02              6966 	mov	ar2,@r1
                           6967 ;	genPointerSet
                           6968 ;	genGenPointerSet
   C6E1 E5 10              6969 	mov	a,_bp
   C6E3 24 06              6970 	add	a,#0x06
   C6E5 F9                 6971 	mov	r1,a
   C6E6 87 82              6972 	mov	dpl,@r1
   C6E8 09                 6973 	inc	r1
   C6E9 87 83              6974 	mov	dph,@r1
   C6EB 09                 6975 	inc	r1
   C6EC 87 F0              6976 	mov	b,@r1
   C6EE EA                 6977 	mov	a,r2
   C6EF 12 DF B7           6978 	lcall	__gptrput
   C6F2 A3                 6979 	inc	dptr
   C6F3 19                 6980 	dec	r1
   C6F4 19                 6981 	dec	r1
   C6F5 A7 82              6982 	mov	@r1,dpl
   C6F7 09                 6983 	inc	r1
   C6F8 A7 83              6984 	mov	@r1,dph
                           6985 ;	../../Common/modules/cIPv6.c:1087: *dptr++ = next_header;
                           6986 ;	genPointerSet
                           6987 ;	genGenPointerSet
   C6FA E5 10              6988 	mov	a,_bp
   C6FC 24 06              6989 	add	a,#0x06
   C6FE F9                 6990 	mov	r1,a
   C6FF 87 82              6991 	mov	dpl,@r1
   C701 09                 6992 	inc	r1
   C702 87 83              6993 	mov	dph,@r1
   C704 09                 6994 	inc	r1
   C705 87 F0              6995 	mov	b,@r1
   C707 C0 00              6996 	push	ar0
   C709 E5 10              6997 	mov	a,_bp
   C70B 24 04              6998 	add	a,#0x04
   C70D F8                 6999 	mov	r0,a
   C70E E6                 7000 	mov	a,@r0
   C70F 12 DF B7           7001 	lcall	__gptrput
   C712 A3                 7002 	inc	dptr
   C713 19                 7003 	dec	r1
   C714 19                 7004 	dec	r1
   C715 A7 82              7005 	mov	@r1,dpl
   C717 09                 7006 	inc	r1
   C718 A7 83              7007 	mov	@r1,dph
   C71A D0 00              7008 	pop	ar0
                           7009 ;	../../Common/modules/cIPv6.c:1088: *dptr++ = GENERAL_HOPLIMIT;
                           7010 ;	genPointerSet
                           7011 ;	genGenPointerSet
   C71C E5 10              7012 	mov	a,_bp
   C71E 24 06              7013 	add	a,#0x06
   C720 F9                 7014 	mov	r1,a
   C721 87 82              7015 	mov	dpl,@r1
   C723 09                 7016 	inc	r1
   C724 87 83              7017 	mov	dph,@r1
   C726 09                 7018 	inc	r1
   C727 87 F0              7019 	mov	b,@r1
   C729 74 16              7020 	mov	a,#0x16
   C72B 12 DF B7           7021 	lcall	__gptrput
   C72E A3                 7022 	inc	dptr
   C72F 19                 7023 	dec	r1
   C730 19                 7024 	dec	r1
   C731 A7 82              7025 	mov	@r1,dpl
   C733 09                 7026 	inc	r1
   C734 A7 83              7027 	mov	@r1,dph
                           7028 ;	../../Common/modules/cIPv6.c:1090: if(cipv6_pib.use_short_address)
                           7029 ;	genPointerGet
                           7030 ;	genFarPointerGet
   C736 90 F0 59           7031 	mov	dptr,#(_cipv6_pib + 0x000c)
   C739 E0                 7032 	movx	a,@dptr
                           7033 ;	genIpop
                           7034 ;	genIfx
                           7035 ;	genIfxJump
                           7036 ;	Peephole 108.c	removed ljmp by inverse jump logic
   C73A 60 1E              7037 	jz	00156$
                           7038 ;	Peephole 300	removed redundant label 00188$
                           7039 ;	../../Common/modules/cIPv6.c:1092: ipv6_address[4]=0xff;
                           7040 ;	genPlus
                           7041 ;     genPlusIncr
   C73C 74 04              7042 	mov	a,#0x04
                           7043 ;	Peephole 236.a	used r0 instead of ar0
   C73E 28                 7044 	add	a,r0
   C73F F9                 7045 	mov	r1,a
                           7046 ;	genPointerSet
                           7047 ;	genNearPointerSet
   C740 77 FF              7048 	mov	@r1,#0xFF
                           7049 ;	../../Common/modules/cIPv6.c:1093: ipv6_address[3]=0xfe;
                           7050 ;	genPlus
                           7051 ;     genPlusIncr
   C742 74 03              7052 	mov	a,#0x03
                           7053 ;	Peephole 236.a	used r0 instead of ar0
   C744 28                 7054 	add	a,r0
   C745 F9                 7055 	mov	r1,a
                           7056 ;	genPointerSet
                           7057 ;	genNearPointerSet
   C746 77 FE              7058 	mov	@r1,#0xFE
                           7059 ;	../../Common/modules/cIPv6.c:1094: ipv6_address[1]=cipv6_pib.short_address[1];
                           7060 ;	genPlus
                           7061 ;     genPlusIncr
   C748 74 01              7062 	mov	a,#0x01
                           7063 ;	Peephole 236.a	used r0 instead of ar0
   C74A 28                 7064 	add	a,r0
   C74B F9                 7065 	mov	r1,a
                           7066 ;	genPointerGet
                           7067 ;	genFarPointerGet
   C74C 90 F0 58           7068 	mov	dptr,#(_cipv6_pib + 0x000b)
   C74F E0                 7069 	movx	a,@dptr
                           7070 ;	genPointerSet
                           7071 ;	genNearPointerSet
   C750 FC                 7072 	mov	r4,a
                           7073 ;	Peephole 192	used a instead of ar4 as source
   C751 F7                 7074 	mov	@r1,a
                           7075 ;	../../Common/modules/cIPv6.c:1095: ipv6_address[0]=cipv6_pib.short_address[0];
                           7076 ;	genPointerGet
                           7077 ;	genFarPointerGet
   C752 90 F0 57           7078 	mov	dptr,#(_cipv6_pib + 0x000a)
   C755 E0                 7079 	movx	a,@dptr
                           7080 ;	genPointerSet
                           7081 ;	genNearPointerSet
   C756 FC                 7082 	mov	r4,a
                           7083 ;	Peephole 192	used a instead of ar4 as source
   C757 F6                 7084 	mov	@r0,a
                           7085 ;	../../Common/modules/cIPv6.c:1099: for(i=0; i<8; i++)
                           7086 ;	Peephole 112.b	changed ljmp to sjmp
   C758 80 1D              7087 	sjmp	00113$
   C75A                    7088 00156$:
                           7089 ;	genAssign
   C75A 7C 00              7090 	mov	r4,#0x00
   C75C                    7091 00122$:
                           7092 ;	genCmpLt
                           7093 ;	genCmp
   C75C BC 08 00           7094 	cjne	r4,#0x08,00189$
   C75F                    7095 00189$:
                           7096 ;	genIfxJump
                           7097 ;	Peephole 108.a	removed ljmp by inverse jump logic
   C75F 50 16              7098 	jnc	00113$
                           7099 ;	Peephole 300	removed redundant label 00190$
                           7100 ;	../../Common/modules/cIPv6.c:1101: ipv6_address[i] = cipv6_pib.long_address[7-i];
                           7101 ;	genPlus
                           7102 ;	Peephole 236.g	used r4 instead of ar4
   C761 EC                 7103 	mov	a,r4
                           7104 ;	Peephole 236.a	used r0 instead of ar0
   C762 28                 7105 	add	a,r0
   C763 F9                 7106 	mov	r1,a
                           7107 ;	genMinus
   C764 74 07              7108 	mov	a,#0x07
   C766 C3                 7109 	clr	c
                           7110 ;	Peephole 236.l	used r4 instead of ar4
   C767 9C                 7111 	subb	a,r4
                           7112 ;	genPlus
   C768 24 4F              7113 	add	a,#(_cipv6_pib + 0x0002)
   C76A F5 82              7114 	mov	dpl,a
                           7115 ;	Peephole 240	use clr instead of addc a,#0
   C76C E4                 7116 	clr	a
   C76D 34 F0              7117 	addc	a,#((_cipv6_pib + 0x0002) >> 8)
   C76F F5 83              7118 	mov	dph,a
                           7119 ;	genPointerGet
                           7120 ;	genFarPointerGet
   C771 E0                 7121 	movx	a,@dptr
                           7122 ;	genPointerSet
                           7123 ;	genNearPointerSet
   C772 FD                 7124 	mov	r5,a
                           7125 ;	Peephole 192	used a instead of ar5 as source
   C773 F7                 7126 	mov	@r1,a
                           7127 ;	../../Common/modules/cIPv6.c:1099: for(i=0; i<8; i++)
                           7128 ;	genPlus
                           7129 ;     genPlusIncr
   C774 0C                 7130 	inc	r4
                           7131 ;	Peephole 112.b	changed ljmp to sjmp
   C775 80 E5              7132 	sjmp	00122$
   C777                    7133 00113$:
                           7134 ;	../../Common/modules/cIPv6.c:1104: *dptr++ =0xfe;
                           7135 ;	genPointerSet
                           7136 ;	genGenPointerSet
   C777 E5 10              7137 	mov	a,_bp
   C779 24 06              7138 	add	a,#0x06
   C77B F9                 7139 	mov	r1,a
   C77C 87 82              7140 	mov	dpl,@r1
   C77E 09                 7141 	inc	r1
   C77F 87 83              7142 	mov	dph,@r1
   C781 09                 7143 	inc	r1
   C782 87 F0              7144 	mov	b,@r1
   C784 74 FE              7145 	mov	a,#0xFE
   C786 12 DF B7           7146 	lcall	__gptrput
   C789 A3                 7147 	inc	dptr
   C78A 19                 7148 	dec	r1
   C78B 19                 7149 	dec	r1
   C78C A7 82              7150 	mov	@r1,dpl
   C78E 09                 7151 	inc	r1
   C78F A7 83              7152 	mov	@r1,dph
                           7153 ;	../../Common/modules/cIPv6.c:1105: *dptr++ = 0x80;
                           7154 ;	genPointerSet
                           7155 ;	genGenPointerSet
   C791 E5 10              7156 	mov	a,_bp
   C793 24 06              7157 	add	a,#0x06
   C795 F9                 7158 	mov	r1,a
   C796 87 82              7159 	mov	dpl,@r1
   C798 09                 7160 	inc	r1
   C799 87 83              7161 	mov	dph,@r1
   C79B 09                 7162 	inc	r1
   C79C 87 F0              7163 	mov	b,@r1
   C79E 74 80              7164 	mov	a,#0x80
   C7A0 12 DF B7           7165 	lcall	__gptrput
   C7A3 A3                 7166 	inc	dptr
   C7A4 19                 7167 	dec	r1
   C7A5 19                 7168 	dec	r1
   C7A6 A7 82              7169 	mov	@r1,dpl
   C7A8 09                 7170 	inc	r1
   C7A9 A7 83              7171 	mov	@r1,dph
                           7172 ;	../../Common/modules/cIPv6.c:1106: for(i=0; i<6; i++)
                           7173 ;	genAssign
   C7AB E5 10              7174 	mov	a,_bp
   C7AD 24 06              7175 	add	a,#0x06
   C7AF F9                 7176 	mov	r1,a
   C7B0 87 04              7177 	mov	ar4,@r1
   C7B2 09                 7178 	inc	r1
   C7B3 87 05              7179 	mov	ar5,@r1
   C7B5 09                 7180 	inc	r1
   C7B6 87 06              7181 	mov	ar6,@r1
                           7182 ;	genAssign
   C7B8 7A 06              7183 	mov	r2,#0x06
   C7BA                    7184 00128$:
                           7185 ;	../../Common/modules/cIPv6.c:1108: *dptr++ = 0x00;
                           7186 ;	genPointerSet
                           7187 ;	genGenPointerSet
   C7BA 8C 82              7188 	mov	dpl,r4
   C7BC 8D 83              7189 	mov	dph,r5
   C7BE 8E F0              7190 	mov	b,r6
                           7191 ;	Peephole 181	changed mov to clr
   C7C0 E4                 7192 	clr	a
   C7C1 12 DF B7           7193 	lcall	__gptrput
   C7C4 A3                 7194 	inc	dptr
   C7C5 AC 82              7195 	mov	r4,dpl
   C7C7 AD 83              7196 	mov	r5,dph
                           7197 ;	genAssign
   C7C9 E5 10              7198 	mov	a,_bp
   C7CB 24 06              7199 	add	a,#0x06
   C7CD F9                 7200 	mov	r1,a
   C7CE A7 04              7201 	mov	@r1,ar4
   C7D0 09                 7202 	inc	r1
   C7D1 A7 05              7203 	mov	@r1,ar5
   C7D3 09                 7204 	inc	r1
   C7D4 A7 06              7205 	mov	@r1,ar6
                           7206 ;	genDjnz
                           7207 ;	Peephole 112.b	changed ljmp to sjmp
                           7208 ;	Peephole 205	optimized misc jump sequence
   C7D6 DA E2              7209 	djnz	r2,00128$
                           7210 ;	Peephole 300	removed redundant label 00191$
                           7211 ;	Peephole 300	removed redundant label 00192$
                           7212 ;	../../Common/modules/cIPv6.c:1106: for(i=0; i<6; i++)
                           7213 ;	../../Common/modules/cIPv6.c:1110: for(i=0; i<8; i++)
                           7214 ;	genAssign
   C7D8 8D 03              7215 	mov	ar3,r5
   C7DA 8E 02              7216 	mov	ar2,r6
                           7217 ;	genAssign
   C7DC 7D 00              7218 	mov	r5,#0x00
   C7DE                    7219 00129$:
                           7220 ;	genCmpLt
                           7221 ;	genCmp
   C7DE BD 08 00           7222 	cjne	r5,#0x08,00193$
   C7E1                    7223 00193$:
                           7224 ;	genIfxJump
                           7225 ;	Peephole 108.a	removed ljmp by inverse jump logic
   C7E1 50 24              7226 	jnc	00174$
                           7227 ;	Peephole 300	removed redundant label 00194$
                           7228 ;	../../Common/modules/cIPv6.c:1112: *dptr++ = ipv6_address[i];
                           7229 ;	genPlus
                           7230 ;	Peephole 236.g	used r5 instead of ar5
   C7E3 ED                 7231 	mov	a,r5
                           7232 ;	Peephole 236.a	used r0 instead of ar0
   C7E4 28                 7233 	add	a,r0
   C7E5 F9                 7234 	mov	r1,a
                           7235 ;	genPointerGet
                           7236 ;	genNearPointerGet
   C7E6 87 06              7237 	mov	ar6,@r1
                           7238 ;	genPointerSet
                           7239 ;	genGenPointerSet
   C7E8 8C 82              7240 	mov	dpl,r4
   C7EA 8B 83              7241 	mov	dph,r3
   C7EC 8A F0              7242 	mov	b,r2
   C7EE EE                 7243 	mov	a,r6
   C7EF 12 DF B7           7244 	lcall	__gptrput
   C7F2 A3                 7245 	inc	dptr
   C7F3 AC 82              7246 	mov	r4,dpl
   C7F5 AB 83              7247 	mov	r3,dph
                           7248 ;	genAssign
   C7F7 E5 10              7249 	mov	a,_bp
   C7F9 24 06              7250 	add	a,#0x06
   C7FB F9                 7251 	mov	r1,a
   C7FC A7 04              7252 	mov	@r1,ar4
   C7FE 09                 7253 	inc	r1
   C7FF A7 03              7254 	mov	@r1,ar3
   C801 09                 7255 	inc	r1
   C802 A7 02              7256 	mov	@r1,ar2
                           7257 ;	../../Common/modules/cIPv6.c:1110: for(i=0; i<8; i++)
                           7258 ;	genPlus
                           7259 ;     genPlusIncr
   C804 0D                 7260 	inc	r5
                           7261 ;	Peephole 112.b	changed ljmp to sjmp
   C805 80 D7              7262 	sjmp	00129$
   C807                    7263 00174$:
                           7264 ;	genAssign
   C807 E5 10              7265 	mov	a,_bp
   C809 24 06              7266 	add	a,#0x06
   C80B F9                 7267 	mov	r1,a
   C80C A7 04              7268 	mov	@r1,ar4
   C80E 09                 7269 	inc	r1
   C80F A7 03              7270 	mov	@r1,ar3
   C811 09                 7271 	inc	r1
   C812 A7 02              7272 	mov	@r1,ar2
                           7273 ;	../../Common/modules/cIPv6.c:1114: memset(ipv6_address, 0,8);
                           7274 ;	genAssign
   C814 88 02              7275 	mov	ar2,r0
                           7276 ;	genCast
   C816 7B 00              7277 	mov	r3,#0x00
   C818 7C 40              7278 	mov	r4,#0x40
                           7279 ;	genIpush
   C81A C0 00              7280 	push	ar0
   C81C 74 08              7281 	mov	a,#0x08
   C81E C0 E0              7282 	push	acc
                           7283 ;	Peephole 181	changed mov to clr
   C820 E4                 7284 	clr	a
   C821 C0 E0              7285 	push	acc
                           7286 ;	genIpush
                           7287 ;	Peephole 181	changed mov to clr
   C823 E4                 7288 	clr	a
   C824 C0 E0              7289 	push	acc
                           7290 ;	genCall
   C826 8A 82              7291 	mov	dpl,r2
   C828 8B 83              7292 	mov	dph,r3
   C82A 8C F0              7293 	mov	b,r4
   C82C 12 E3 65           7294 	lcall	_memset
   C82F 15 81              7295 	dec	sp
   C831 15 81              7296 	dec	sp
   C833 15 81              7297 	dec	sp
   C835 D0 00              7298 	pop	ar0
                           7299 ;	../../Common/modules/cIPv6.c:1118: if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_SHORT ||  buf->dst_sa.addr_type == ADDR_802_15_4_PAN_LONG)
                           7300 ;	genPointerGet
                           7301 ;	genGenPointerGet
   C837 E5 10              7302 	mov	a,_bp
   C839 24 15              7303 	add	a,#0x15
   C83B F9                 7304 	mov	r1,a
   C83C 87 82              7305 	mov	dpl,@r1
   C83E 09                 7306 	inc	r1
   C83F 87 83              7307 	mov	dph,@r1
   C841 09                 7308 	inc	r1
   C842 87 F0              7309 	mov	b,@r1
   C844 12 E4 9F           7310 	lcall	__gptrget
   C847 FA                 7311 	mov	r2,a
                           7312 ;	genCmpEq
                           7313 ;	gencjneshort
   C848 BA 03 02           7314 	cjne	r2,#0x03,00195$
                           7315 ;	Peephole 112.b	changed ljmp to sjmp
   C84B 80 08              7316 	sjmp	00117$
   C84D                    7317 00195$:
                           7318 ;	genCmpEq
                           7319 ;	gencjneshort
   C84D BA 04 02           7320 	cjne	r2,#0x04,00196$
   C850 80 03              7321 	sjmp	00197$
   C852                    7322 00196$:
   C852 02 C9 7F           7323 	ljmp	00118$
   C855                    7324 00197$:
   C855                    7325 00117$:
                           7326 ;	../../Common/modules/cIPv6.c:1121: if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_LONG)
                           7327 ;	genCmpEq
                           7328 ;	gencjneshort
                           7329 ;	Peephole 112.b	changed ljmp to sjmp
                           7330 ;	Peephole 198.b	optimized misc jump sequence
   C855 BA 04 5A           7331 	cjne	r2,#0x04,00115$
                           7332 ;	Peephole 200.b	removed redundant sjmp
                           7333 ;	Peephole 300	removed redundant label 00198$
                           7334 ;	Peephole 300	removed redundant label 00199$
                           7335 ;	../../Common/modules/cIPv6.c:1123: for(i=0;i<8;i++)
                           7336 ;	genPlus
   C858 A9 10              7337 	mov	r1,_bp
   C85A 09                 7338 	inc	r1
                           7339 ;     genPlusIncr
   C85B 74 03              7340 	mov	a,#0x03
   C85D 27                 7341 	add	a,@r1
   C85E FB                 7342 	mov	r3,a
                           7343 ;	Peephole 181	changed mov to clr
   C85F E4                 7344 	clr	a
   C860 09                 7345 	inc	r1
   C861 37                 7346 	addc	a,@r1
   C862 FC                 7347 	mov	r4,a
   C863 09                 7348 	inc	r1
   C864 87 05              7349 	mov	ar5,@r1
                           7350 ;	genPlus
                           7351 ;     genPlusIncr
   C866 0B                 7352 	inc	r3
   C867 BB 00 01           7353 	cjne	r3,#0x00,00200$
   C86A 0C                 7354 	inc	r4
   C86B                    7355 00200$:
                           7356 ;	genAssign
   C86B E5 10              7357 	mov	a,_bp
   C86D 24 05              7358 	add	a,#0x05
   C86F F9                 7359 	mov	r1,a
   C870 77 00              7360 	mov	@r1,#0x00
   C872                    7361 00133$:
                           7362 ;	genCmpLt
   C872 E5 10              7363 	mov	a,_bp
   C874 24 05              7364 	add	a,#0x05
   C876 F9                 7365 	mov	r1,a
                           7366 ;	genCmp
   C877 B7 08 00           7367 	cjne	@r1,#0x08,00201$
   C87A                    7368 00201$:
                           7369 ;	genIfxJump
   C87A 40 03              7370 	jc	00202$
   C87C 02 C9 00           7371 	ljmp	00116$
   C87F                    7372 00202$:
                           7373 ;	../../Common/modules/cIPv6.c:1125: ipv6_address[i] = buf->dst_sa.address[7-i];
                           7374 ;	genIpush
   C87F C0 02              7375 	push	ar2
                           7376 ;	genPlus
   C881 E5 10              7377 	mov	a,_bp
   C883 24 05              7378 	add	a,#0x05
   C885 F9                 7379 	mov	r1,a
   C886 E7                 7380 	mov	a,@r1
                           7381 ;	Peephole 236.a	used r0 instead of ar0
   C887 28                 7382 	add	a,r0
   C888 F9                 7383 	mov	r1,a
                           7384 ;	genMinus
   C889 C0 00              7385 	push	ar0
   C88B E5 10              7386 	mov	a,_bp
   C88D 24 05              7387 	add	a,#0x05
   C88F F8                 7388 	mov	r0,a
   C890 74 07              7389 	mov	a,#0x07
   C892 C3                 7390 	clr	c
   C893 96                 7391 	subb	a,@r0
   C894 D0 00              7392 	pop	ar0
                           7393 ;	genPlus
                           7394 ;	Peephole 236.a	used r3 instead of ar3
   C896 2B                 7395 	add	a,r3
   C897 FF                 7396 	mov	r7,a
                           7397 ;	Peephole 236.g	used r4 instead of ar4
                           7398 ;	Peephole 240	use clr instead of addc a,#0
   C898 E4                 7399 	clr	a
   C899 3C                 7400 	addc	a,r4
   C89A FA                 7401 	mov	r2,a
   C89B 8D 06              7402 	mov	ar6,r5
                           7403 ;	genPointerGet
                           7404 ;	genGenPointerGet
   C89D 8F 82              7405 	mov	dpl,r7
   C89F 8A 83              7406 	mov	dph,r2
   C8A1 8E F0              7407 	mov	b,r6
   C8A3 12 E4 9F           7408 	lcall	__gptrget
                           7409 ;	genPointerSet
                           7410 ;	genNearPointerSet
   C8A6 FF                 7411 	mov	r7,a
                           7412 ;	Peephole 192	used a instead of ar7 as source
   C8A7 F7                 7413 	mov	@r1,a
                           7414 ;	../../Common/modules/cIPv6.c:1123: for(i=0;i<8;i++)
                           7415 ;	genPlus
   C8A8 E5 10              7416 	mov	a,_bp
   C8AA 24 05              7417 	add	a,#0x05
   C8AC F9                 7418 	mov	r1,a
                           7419 ;     genPlusIncr
   C8AD 07                 7420 	inc	@r1
                           7421 ;	genIpop
   C8AE D0 02              7422 	pop	ar2
                           7423 ;	Peephole 112.b	changed ljmp to sjmp
   C8B0 80 C0              7424 	sjmp	00133$
   C8B2                    7425 00115$:
                           7426 ;	../../Common/modules/cIPv6.c:1130: ipv6_address[3]=0xff;
                           7427 ;	genIpush
   C8B2 C0 02              7428 	push	ar2
                           7429 ;	genPlus
                           7430 ;     genPlusIncr
   C8B4 74 03              7431 	mov	a,#0x03
                           7432 ;	Peephole 236.a	used r0 instead of ar0
   C8B6 28                 7433 	add	a,r0
   C8B7 F9                 7434 	mov	r1,a
                           7435 ;	genPointerSet
                           7436 ;	genNearPointerSet
   C8B8 77 FF              7437 	mov	@r1,#0xFF
                           7438 ;	../../Common/modules/cIPv6.c:1131: ipv6_address[4]=0xfe;
                           7439 ;	genPlus
                           7440 ;     genPlusIncr
   C8BA 74 04              7441 	mov	a,#0x04
                           7442 ;	Peephole 236.a	used r0 instead of ar0
   C8BC 28                 7443 	add	a,r0
   C8BD F9                 7444 	mov	r1,a
                           7445 ;	genPointerSet
                           7446 ;	genNearPointerSet
   C8BE 77 FE              7447 	mov	@r1,#0xFE
                           7448 ;	../../Common/modules/cIPv6.c:1132: ipv6_address[6]=buf->dst_sa.address[1];
                           7449 ;	genPlus
                           7450 ;     genPlusIncr
   C8C0 74 06              7451 	mov	a,#0x06
                           7452 ;	Peephole 236.a	used r0 instead of ar0
   C8C2 28                 7453 	add	a,r0
   C8C3 F9                 7454 	mov	r1,a
                           7455 ;	genPlus
   C8C4 C0 00              7456 	push	ar0
   C8C6 A8 10              7457 	mov	r0,_bp
   C8C8 08                 7458 	inc	r0
                           7459 ;     genPlusIncr
   C8C9 74 03              7460 	mov	a,#0x03
   C8CB 26                 7461 	add	a,@r0
   C8CC FB                 7462 	mov	r3,a
                           7463 ;	Peephole 181	changed mov to clr
   C8CD E4                 7464 	clr	a
   C8CE 08                 7465 	inc	r0
   C8CF 36                 7466 	addc	a,@r0
   C8D0 FC                 7467 	mov	r4,a
   C8D1 08                 7468 	inc	r0
   C8D2 86 05              7469 	mov	ar5,@r0
   C8D4 D0 00              7470 	pop	ar0
                           7471 ;	genPlus
                           7472 ;     genPlusIncr
   C8D6 0B                 7473 	inc	r3
   C8D7 BB 00 01           7474 	cjne	r3,#0x00,00203$
   C8DA 0C                 7475 	inc	r4
   C8DB                    7476 00203$:
                           7477 ;	genPlus
                           7478 ;     genPlusIncr
   C8DB 74 01              7479 	mov	a,#0x01
                           7480 ;	Peephole 236.a	used r3 instead of ar3
   C8DD 2B                 7481 	add	a,r3
   C8DE FE                 7482 	mov	r6,a
                           7483 ;	Peephole 181	changed mov to clr
   C8DF E4                 7484 	clr	a
                           7485 ;	Peephole 236.b	used r4 instead of ar4
   C8E0 3C                 7486 	addc	a,r4
   C8E1 FF                 7487 	mov	r7,a
   C8E2 8D 02              7488 	mov	ar2,r5
                           7489 ;	genPointerGet
                           7490 ;	genGenPointerGet
   C8E4 8E 82              7491 	mov	dpl,r6
   C8E6 8F 83              7492 	mov	dph,r7
   C8E8 8A F0              7493 	mov	b,r2
   C8EA 12 E4 9F           7494 	lcall	__gptrget
                           7495 ;	genPointerSet
                           7496 ;	genNearPointerSet
   C8ED FE                 7497 	mov	r6,a
                           7498 ;	Peephole 192	used a instead of ar6 as source
   C8EE F7                 7499 	mov	@r1,a
                           7500 ;	../../Common/modules/cIPv6.c:1133: ipv6_address[7]=buf->dst_sa.address[0];
                           7501 ;	genPlus
                           7502 ;     genPlusIncr
   C8EF 74 07              7503 	mov	a,#0x07
                           7504 ;	Peephole 236.a	used r0 instead of ar0
   C8F1 28                 7505 	add	a,r0
   C8F2 F9                 7506 	mov	r1,a
                           7507 ;	genAssign
                           7508 ;	genCast
                           7509 ;	genPointerGet
                           7510 ;	genGenPointerGet
   C8F3 8B 82              7511 	mov	dpl,r3
   C8F5 8C 83              7512 	mov	dph,r4
   C8F7 8D F0              7513 	mov	b,r5
   C8F9 12 E4 9F           7514 	lcall	__gptrget
                           7515 ;	genPointerSet
                           7516 ;	genNearPointerSet
   C8FC FB                 7517 	mov	r3,a
                           7518 ;	Peephole 192	used a instead of ar3 as source
   C8FD F7                 7519 	mov	@r1,a
                           7520 ;	../../Common/modules/cIPv6.c:1164: return pdTRUE;
                           7521 ;	genIpop
   C8FE D0 02              7522 	pop	ar2
                           7523 ;	../../Common/modules/cIPv6.c:1133: ipv6_address[7]=buf->dst_sa.address[0];
   C900                    7524 00116$:
                           7525 ;	../../Common/modules/cIPv6.c:1136: *dptr++ =0xfe;
                           7526 ;	genPointerSet
                           7527 ;	genGenPointerSet
   C900 E5 10              7528 	mov	a,_bp
   C902 24 06              7529 	add	a,#0x06
   C904 F9                 7530 	mov	r1,a
   C905 87 82              7531 	mov	dpl,@r1
   C907 09                 7532 	inc	r1
   C908 87 83              7533 	mov	dph,@r1
   C90A 09                 7534 	inc	r1
   C90B 87 F0              7535 	mov	b,@r1
   C90D 74 FE              7536 	mov	a,#0xFE
   C90F 12 DF B7           7537 	lcall	__gptrput
   C912 A3                 7538 	inc	dptr
   C913 19                 7539 	dec	r1
   C914 19                 7540 	dec	r1
   C915 A7 82              7541 	mov	@r1,dpl
   C917 09                 7542 	inc	r1
   C918 A7 83              7543 	mov	@r1,dph
                           7544 ;	../../Common/modules/cIPv6.c:1137: *dptr++ = 0x80;
                           7545 ;	genPointerSet
                           7546 ;	genGenPointerSet
   C91A E5 10              7547 	mov	a,_bp
   C91C 24 06              7548 	add	a,#0x06
   C91E F9                 7549 	mov	r1,a
   C91F 87 82              7550 	mov	dpl,@r1
   C921 09                 7551 	inc	r1
   C922 87 83              7552 	mov	dph,@r1
   C924 09                 7553 	inc	r1
   C925 87 F0              7554 	mov	b,@r1
   C927 74 80              7555 	mov	a,#0x80
   C929 12 DF B7           7556 	lcall	__gptrput
   C92C A3                 7557 	inc	dptr
   C92D 19                 7558 	dec	r1
   C92E 19                 7559 	dec	r1
   C92F A7 82              7560 	mov	@r1,dpl
   C931 09                 7561 	inc	r1
   C932 A7 83              7562 	mov	@r1,dph
                           7563 ;	../../Common/modules/cIPv6.c:1139: for(i=0; i<6; i++)
                           7564 ;	genAssign
   C934 E5 10              7565 	mov	a,_bp
   C936 24 06              7566 	add	a,#0x06
   C938 F9                 7567 	mov	r1,a
   C939 87 03              7568 	mov	ar3,@r1
   C93B 09                 7569 	inc	r1
   C93C 87 04              7570 	mov	ar4,@r1
   C93E 09                 7571 	inc	r1
   C93F 87 05              7572 	mov	ar5,@r1
                           7573 ;	genAssign
   C941 7E 06              7574 	mov	r6,#0x06
   C943                    7575 00139$:
                           7576 ;	../../Common/modules/cIPv6.c:1141: *dptr++ = 0x00;
                           7577 ;	genPointerSet
                           7578 ;	genGenPointerSet
   C943 8B 82              7579 	mov	dpl,r3
   C945 8C 83              7580 	mov	dph,r4
   C947 8D F0              7581 	mov	b,r5
                           7582 ;	Peephole 181	changed mov to clr
   C949 E4                 7583 	clr	a
   C94A 12 DF B7           7584 	lcall	__gptrput
   C94D A3                 7585 	inc	dptr
   C94E AB 82              7586 	mov	r3,dpl
   C950 AC 83              7587 	mov	r4,dph
                           7588 ;	genDjnz
                           7589 ;	Peephole 112.b	changed ljmp to sjmp
                           7590 ;	Peephole 205	optimized misc jump sequence
   C952 DE EF              7591 	djnz	r6,00139$
                           7592 ;	Peephole 300	removed redundant label 00204$
                           7593 ;	Peephole 300	removed redundant label 00205$
                           7594 ;	../../Common/modules/cIPv6.c:1139: for(i=0; i<6; i++)
                           7595 ;	../../Common/modules/cIPv6.c:1144: for(i=0; i<8; i++)
                           7596 ;	genAssign
                           7597 ;	genAssign
   C954 7E 00              7598 	mov	r6,#0x00
   C956                    7599 00140$:
                           7600 ;	genCmpLt
                           7601 ;	genCmp
   C956 BE 08 00           7602 	cjne	r6,#0x08,00206$
   C959                    7603 00206$:
                           7604 ;	genIfxJump
                           7605 ;	Peephole 108.a	removed ljmp by inverse jump logic
   C959 50 17              7606 	jnc	00177$
                           7607 ;	Peephole 300	removed redundant label 00207$
                           7608 ;	../../Common/modules/cIPv6.c:1146: *dptr++ = ipv6_address[i];
                           7609 ;	genPlus
                           7610 ;	Peephole 236.g	used r6 instead of ar6
   C95B EE                 7611 	mov	a,r6
                           7612 ;	Peephole 236.a	used r0 instead of ar0
   C95C 28                 7613 	add	a,r0
   C95D F9                 7614 	mov	r1,a
                           7615 ;	genPointerGet
                           7616 ;	genNearPointerGet
   C95E 87 07              7617 	mov	ar7,@r1
                           7618 ;	genPointerSet
                           7619 ;	genGenPointerSet
   C960 8B 82              7620 	mov	dpl,r3
   C962 8C 83              7621 	mov	dph,r4
   C964 8D F0              7622 	mov	b,r5
   C966 EF                 7623 	mov	a,r7
   C967 12 DF B7           7624 	lcall	__gptrput
   C96A A3                 7625 	inc	dptr
   C96B AB 82              7626 	mov	r3,dpl
   C96D AC 83              7627 	mov	r4,dph
                           7628 ;	../../Common/modules/cIPv6.c:1144: for(i=0; i<8; i++)
                           7629 ;	genPlus
                           7630 ;     genPlusIncr
   C96F 0E                 7631 	inc	r6
                           7632 ;	Peephole 112.b	changed ljmp to sjmp
   C970 80 E4              7633 	sjmp	00140$
   C972                    7634 00177$:
                           7635 ;	genAssign
   C972 E5 10              7636 	mov	a,_bp
   C974 24 06              7637 	add	a,#0x06
   C976 F8                 7638 	mov	r0,a
   C977 A6 03              7639 	mov	@r0,ar3
   C979 08                 7640 	inc	r0
   C97A A6 04              7641 	mov	@r0,ar4
   C97C 08                 7642 	inc	r0
   C97D A6 05              7643 	mov	@r0,ar5
   C97F                    7644 00118$:
                           7645 ;	../../Common/modules/cIPv6.c:1149: if(buf->dst_sa.addr_type == ADDR_BROADCAST)
                           7646 ;	genCmpEq
                           7647 ;	gencjneshort
                           7648 ;	Peephole 112.b	changed ljmp to sjmp
                           7649 ;	Peephole 198.b	optimized misc jump sequence
   C97F BA 08 5F           7650 	cjne	r2,#0x08,00121$
                           7651 ;	Peephole 200.b	removed redundant sjmp
                           7652 ;	Peephole 300	removed redundant label 00208$
                           7653 ;	Peephole 300	removed redundant label 00209$
                           7654 ;	../../Common/modules/cIPv6.c:1151: *dptr++ =0xff;
                           7655 ;	genPointerSet
                           7656 ;	genGenPointerSet
   C982 E5 10              7657 	mov	a,_bp
   C984 24 06              7658 	add	a,#0x06
   C986 F8                 7659 	mov	r0,a
   C987 86 82              7660 	mov	dpl,@r0
   C989 08                 7661 	inc	r0
   C98A 86 83              7662 	mov	dph,@r0
   C98C 08                 7663 	inc	r0
   C98D 86 F0              7664 	mov	b,@r0
   C98F 74 FF              7665 	mov	a,#0xFF
   C991 12 DF B7           7666 	lcall	__gptrput
   C994 A3                 7667 	inc	dptr
   C995 18                 7668 	dec	r0
   C996 18                 7669 	dec	r0
   C997 A6 82              7670 	mov	@r0,dpl
   C999 08                 7671 	inc	r0
   C99A A6 83              7672 	mov	@r0,dph
                           7673 ;	../../Common/modules/cIPv6.c:1152: *dptr++ = 0x02;	
                           7674 ;	genPointerSet
                           7675 ;	genGenPointerSet
   C99C E5 10              7676 	mov	a,_bp
   C99E 24 06              7677 	add	a,#0x06
   C9A0 F8                 7678 	mov	r0,a
   C9A1 86 82              7679 	mov	dpl,@r0
   C9A3 08                 7680 	inc	r0
   C9A4 86 83              7681 	mov	dph,@r0
   C9A6 08                 7682 	inc	r0
   C9A7 86 F0              7683 	mov	b,@r0
   C9A9 74 02              7684 	mov	a,#0x02
   C9AB 12 DF B7           7685 	lcall	__gptrput
   C9AE A3                 7686 	inc	dptr
   C9AF 18                 7687 	dec	r0
   C9B0 18                 7688 	dec	r0
   C9B1 A6 82              7689 	mov	@r0,dpl
   C9B3 08                 7690 	inc	r0
   C9B4 A6 83              7691 	mov	@r0,dph
                           7692 ;	../../Common/modules/cIPv6.c:1153: for(i=0; i<13; i++)
                           7693 ;	genAssign
   C9B6 E5 10              7694 	mov	a,_bp
   C9B8 24 06              7695 	add	a,#0x06
   C9BA F8                 7696 	mov	r0,a
   C9BB 86 02              7697 	mov	ar2,@r0
   C9BD 08                 7698 	inc	r0
   C9BE 86 03              7699 	mov	ar3,@r0
   C9C0 08                 7700 	inc	r0
   C9C1 86 04              7701 	mov	ar4,@r0
                           7702 ;	genAssign
   C9C3 7D 0D              7703 	mov	r5,#0x0D
   C9C5                    7704 00146$:
                           7705 ;	../../Common/modules/cIPv6.c:1155: *dptr++ = 0x00;
                           7706 ;	genPointerSet
                           7707 ;	genGenPointerSet
   C9C5 8A 82              7708 	mov	dpl,r2
   C9C7 8B 83              7709 	mov	dph,r3
   C9C9 8C F0              7710 	mov	b,r4
                           7711 ;	Peephole 181	changed mov to clr
   C9CB E4                 7712 	clr	a
   C9CC 12 DF B7           7713 	lcall	__gptrput
   C9CF A3                 7714 	inc	dptr
   C9D0 AA 82              7715 	mov	r2,dpl
   C9D2 AB 83              7716 	mov	r3,dph
                           7717 ;	genDjnz
                           7718 ;	Peephole 112.b	changed ljmp to sjmp
                           7719 ;	Peephole 205	optimized misc jump sequence
   C9D4 DD EF              7720 	djnz	r5,00146$
                           7721 ;	Peephole 300	removed redundant label 00210$
                           7722 ;	Peephole 300	removed redundant label 00211$
                           7723 ;	../../Common/modules/cIPv6.c:1153: for(i=0; i<13; i++)
                           7724 ;	../../Common/modules/cIPv6.c:1157: *dptr++ = 0x01;
                           7725 ;	genPointerSet
                           7726 ;	genGenPointerSet
   C9D6 8A 82              7727 	mov	dpl,r2
   C9D8 8B 83              7728 	mov	dph,r3
   C9DA 8C F0              7729 	mov	b,r4
   C9DC 74 01              7730 	mov	a,#0x01
   C9DE 12 DF B7           7731 	lcall	__gptrput
   C9E1                    7732 00121$:
                           7733 ;	../../Common/modules/cIPv6.c:1160: buf->from = MODULE_CIPV6;
                           7734 ;	genPointerSet
                           7735 ;	genGenPointerSet
   C9E1 E5 10              7736 	mov	a,_bp
   C9E3 24 18              7737 	add	a,#0x18
   C9E5 F8                 7738 	mov	r0,a
   C9E6 86 82              7739 	mov	dpl,@r0
   C9E8 08                 7740 	inc	r0
   C9E9 86 83              7741 	mov	dph,@r0
   C9EB 08                 7742 	inc	r0
   C9EC 86 F0              7743 	mov	b,@r0
   C9EE 74 01              7744 	mov	a,#0x01
   C9F0 12 DF B7           7745 	lcall	__gptrput
                           7746 ;	../../Common/modules/cIPv6.c:1161: buf->to = MODULE_NONE;
                           7747 ;	genPlus
   C9F3 A8 10              7748 	mov	r0,_bp
   C9F5 08                 7749 	inc	r0
                           7750 ;     genPlusIncr
   C9F6 74 1E              7751 	mov	a,#0x1E
   C9F8 26                 7752 	add	a,@r0
   C9F9 FA                 7753 	mov	r2,a
                           7754 ;	Peephole 181	changed mov to clr
   C9FA E4                 7755 	clr	a
   C9FB 08                 7756 	inc	r0
   C9FC 36                 7757 	addc	a,@r0
   C9FD FB                 7758 	mov	r3,a
   C9FE 08                 7759 	inc	r0
   C9FF 86 04              7760 	mov	ar4,@r0
                           7761 ;	genPointerSet
                           7762 ;	genGenPointerSet
   CA01 8A 82              7763 	mov	dpl,r2
   CA03 8B 83              7764 	mov	dph,r3
   CA05 8C F0              7765 	mov	b,r4
                           7766 ;	Peephole 181	changed mov to clr
   CA07 E4                 7767 	clr	a
   CA08 12 DF B7           7768 	lcall	__gptrput
                           7769 ;	../../Common/modules/cIPv6.c:1162: stack_buffer_push(buf);
                           7770 ;	genCall
   CA0B A8 10              7771 	mov	r0,_bp
   CA0D 08                 7772 	inc	r0
   CA0E 86 82              7773 	mov	dpl,@r0
   CA10 08                 7774 	inc	r0
   CA11 86 83              7775 	mov	dph,@r0
   CA13 08                 7776 	inc	r0
   CA14 86 F0              7777 	mov	b,@r0
   CA16 12 62 C4           7778 	lcall	_stack_buffer_push
                           7779 ;	../../Common/modules/cIPv6.c:1164: return pdTRUE;
                           7780 ;	genRet
   CA19 75 82 01           7781 	mov	dpl,#0x01
   CA1C                    7782 00147$:
   CA1C 85 10 81           7783 	mov	sp,_bp
   CA1F D0 10              7784 	pop	_bp
   CA21 22                 7785 	ret
                           7786 ;------------------------------------------------------------
                           7787 ;Allocation info for local variables in function 'parse_ipv_header'
                           7788 ;------------------------------------------------------------
                           7789 ;buf                       Allocated to stack - offset 1
                           7790 ;ind                       Allocated to stack - offset 4
                           7791 ;ip_version                Allocated to registers r2 
                           7792 ;hoplimit                  Allocated to stack - offset 5
                           7793 ;next_header               Allocated to stack - offset 6
                           7794 ;i                         Allocated to stack - offset 7
                           7795 ;dest_match                Allocated to stack - offset 8
                           7796 ;destination               Allocated to stack - offset 9
                           7797 ;sloc0                     Allocated to stack - offset 25
                           7798 ;sloc1                     Allocated to stack - offset 28
                           7799 ;------------------------------------------------------------
                           7800 ;	../../Common/modules/cIPv6.c:1172: void parse_ipv_header(buffer_t *buf)
                           7801 ;	-----------------------------------------
                           7802 ;	 function parse_ipv_header
                           7803 ;	-----------------------------------------
   CA22                    7804 _parse_ipv_header:
   CA22 C0 10              7805 	push	_bp
   CA24 85 81 10           7806 	mov	_bp,sp
                           7807 ;     genReceive
   CA27 C0 82              7808 	push	dpl
   CA29 C0 83              7809 	push	dph
   CA2B C0 F0              7810 	push	b
   CA2D E5 81              7811 	mov	a,sp
   CA2F 24 1E              7812 	add	a,#0x1e
   CA31 F5 81              7813 	mov	sp,a
                           7814 ;	../../Common/modules/cIPv6.c:1174: uint8_t ind=0, ip_version,hoplimit=0, next_header=0, i, dest_match=0;
                           7815 ;	genAssign
   CA33 E5 10              7816 	mov	a,_bp
   CA35 24 08              7817 	add	a,#0x08
   CA37 F8                 7818 	mov	r0,a
   CA38 76 00              7819 	mov	@r0,#0x00
                           7820 ;	../../Common/modules/cIPv6.c:1176: ind = buf->buf_ptr;
                           7821 ;	genPlus
   CA3A A8 10              7822 	mov	r0,_bp
   CA3C 08                 7823 	inc	r0
   CA3D E5 10              7824 	mov	a,_bp
   CA3F 24 1C              7825 	add	a,#0x1c
   CA41 F9                 7826 	mov	r1,a
                           7827 ;     genPlusIncr
   CA42 74 20              7828 	mov	a,#0x20
   CA44 26                 7829 	add	a,@r0
   CA45 F7                 7830 	mov	@r1,a
                           7831 ;	Peephole 181	changed mov to clr
   CA46 E4                 7832 	clr	a
   CA47 08                 7833 	inc	r0
   CA48 36                 7834 	addc	a,@r0
   CA49 09                 7835 	inc	r1
   CA4A F7                 7836 	mov	@r1,a
   CA4B 08                 7837 	inc	r0
   CA4C 09                 7838 	inc	r1
   CA4D E6                 7839 	mov	a,@r0
   CA4E F7                 7840 	mov	@r1,a
                           7841 ;	genPointerGet
                           7842 ;	genGenPointerGet
   CA4F E5 10              7843 	mov	a,_bp
   CA51 24 1C              7844 	add	a,#0x1c
   CA53 F8                 7845 	mov	r0,a
   CA54 86 82              7846 	mov	dpl,@r0
   CA56 08                 7847 	inc	r0
   CA57 86 83              7848 	mov	dph,@r0
   CA59 08                 7849 	inc	r0
   CA5A 86 F0              7850 	mov	b,@r0
   CA5C 12 E4 9F           7851 	lcall	__gptrget
   CA5F FA                 7852 	mov	r2,a
   CA60 A3                 7853 	inc	dptr
   CA61 12 E4 9F           7854 	lcall	__gptrget
   CA64 FB                 7855 	mov	r3,a
                           7856 ;	genCast
   CA65 E5 10              7857 	mov	a,_bp
   CA67 24 04              7858 	add	a,#0x04
   CA69 F8                 7859 	mov	r0,a
   CA6A A6 02              7860 	mov	@r0,ar2
                           7861 ;	../../Common/modules/cIPv6.c:1177: ind++;
                           7862 ;	genPlus
   CA6C E5 10              7863 	mov	a,_bp
   CA6E 24 04              7864 	add	a,#0x04
   CA70 F8                 7865 	mov	r0,a
                           7866 ;     genPlusIncr
   CA71 06                 7867 	inc	@r0
                           7868 ;	../../Common/modules/cIPv6.c:1179: ip_version = buf->buf[ind++];
                           7869 ;	genPlus
   CA72 A8 10              7870 	mov	r0,_bp
   CA74 08                 7871 	inc	r0
                           7872 ;     genPlusIncr
   CA75 74 2C              7873 	mov	a,#0x2C
   CA77 26                 7874 	add	a,@r0
   CA78 FD                 7875 	mov	r5,a
                           7876 ;	Peephole 181	changed mov to clr
   CA79 E4                 7877 	clr	a
   CA7A 08                 7878 	inc	r0
   CA7B 36                 7879 	addc	a,@r0
   CA7C FB                 7880 	mov	r3,a
   CA7D 08                 7881 	inc	r0
   CA7E 86 04              7882 	mov	ar4,@r0
                           7883 ;	genAssign
   CA80 E5 10              7884 	mov	a,_bp
   CA82 24 04              7885 	add	a,#0x04
   CA84 F8                 7886 	mov	r0,a
   CA85 86 02              7887 	mov	ar2,@r0
                           7888 ;	genPlus
   CA87 E5 10              7889 	mov	a,_bp
   CA89 24 04              7890 	add	a,#0x04
   CA8B F8                 7891 	mov	r0,a
                           7892 ;     genPlusIncr
   CA8C 06                 7893 	inc	@r0
                           7894 ;	genPlus
                           7895 ;	Peephole 236.g	used r2 instead of ar2
   CA8D EA                 7896 	mov	a,r2
                           7897 ;	Peephole 236.a	used r5 instead of ar5
   CA8E 2D                 7898 	add	a,r5
   CA8F FA                 7899 	mov	r2,a
                           7900 ;	Peephole 181	changed mov to clr
   CA90 E4                 7901 	clr	a
                           7902 ;	Peephole 236.b	used r3 instead of ar3
   CA91 3B                 7903 	addc	a,r3
   CA92 FB                 7904 	mov	r3,a
                           7905 ;	genPointerGet
                           7906 ;	genGenPointerGet
   CA93 8A 82              7907 	mov	dpl,r2
   CA95 8B 83              7908 	mov	dph,r3
   CA97 8C F0              7909 	mov	b,r4
   CA99 12 E4 9F           7910 	lcall	__gptrget
   CA9C FA                 7911 	mov	r2,a
                           7912 ;	genAssign
                           7913 ;	../../Common/modules/cIPv6.c:1180: if( ip_version == 0x06 )
                           7914 ;	genCmpEq
                           7915 ;	gencjneshort
   CA9D BA 06 02           7916 	cjne	r2,#0x06,00148$
   CAA0 80 03              7917 	sjmp	00149$
   CAA2                    7918 00148$:
   CAA2 02 CD 1F           7919 	ljmp	00122$
   CAA5                    7920 00149$:
                           7921 ;	../../Common/modules/cIPv6.c:1186: ind +=5;
                           7922 ;	genIpush
                           7923 ;	genPlus
   CAA5 E5 10              7924 	mov	a,_bp
   CAA7 24 04              7925 	add	a,#0x04
   CAA9 F8                 7926 	mov	r0,a
                           7927 ;     genPlusIncr
   CAAA 74 05              7928 	mov	a,#0x05
   CAAC 26                 7929 	add	a,@r0
   CAAD F6                 7930 	mov	@r0,a
                           7931 ;	../../Common/modules/cIPv6.c:1187: next_header = buf->buf[ind++];
                           7932 ;	genPlus
   CAAE A8 10              7933 	mov	r0,_bp
   CAB0 08                 7934 	inc	r0
                           7935 ;     genPlusIncr
   CAB1 74 2C              7936 	mov	a,#0x2C
   CAB3 26                 7937 	add	a,@r0
   CAB4 FA                 7938 	mov	r2,a
                           7939 ;	Peephole 181	changed mov to clr
   CAB5 E4                 7940 	clr	a
   CAB6 08                 7941 	inc	r0
   CAB7 36                 7942 	addc	a,@r0
   CAB8 FB                 7943 	mov	r3,a
   CAB9 08                 7944 	inc	r0
   CABA 86 04              7945 	mov	ar4,@r0
                           7946 ;	genAssign
   CABC E5 10              7947 	mov	a,_bp
   CABE 24 04              7948 	add	a,#0x04
   CAC0 F8                 7949 	mov	r0,a
   CAC1 86 05              7950 	mov	ar5,@r0
                           7951 ;	genPlus
   CAC3 E5 10              7952 	mov	a,_bp
   CAC5 24 04              7953 	add	a,#0x04
   CAC7 F8                 7954 	mov	r0,a
                           7955 ;     genPlusIncr
   CAC8 06                 7956 	inc	@r0
                           7957 ;	genPlus
                           7958 ;	Peephole 236.g	used r5 instead of ar5
   CAC9 ED                 7959 	mov	a,r5
                           7960 ;	Peephole 236.a	used r2 instead of ar2
   CACA 2A                 7961 	add	a,r2
   CACB FD                 7962 	mov	r5,a
                           7963 ;	Peephole 181	changed mov to clr
   CACC E4                 7964 	clr	a
                           7965 ;	Peephole 236.b	used r3 instead of ar3
   CACD 3B                 7966 	addc	a,r3
   CACE FE                 7967 	mov	r6,a
   CACF 8C 07              7968 	mov	ar7,r4
                           7969 ;	genPointerGet
                           7970 ;	genGenPointerGet
   CAD1 8D 82              7971 	mov	dpl,r5
   CAD3 8E 83              7972 	mov	dph,r6
   CAD5 8F F0              7973 	mov	b,r7
   CAD7 12 E4 9F           7974 	lcall	__gptrget
   CADA FD                 7975 	mov	r5,a
                           7976 ;	genAssign
   CADB E5 10              7977 	mov	a,_bp
   CADD 24 06              7978 	add	a,#0x06
   CADF F8                 7979 	mov	r0,a
   CAE0 A6 05              7980 	mov	@r0,ar5
                           7981 ;	../../Common/modules/cIPv6.c:1188: hoplimit= buf->buf[ind++];
                           7982 ;	genAssign
   CAE2 E5 10              7983 	mov	a,_bp
   CAE4 24 04              7984 	add	a,#0x04
   CAE6 F8                 7985 	mov	r0,a
   CAE7 86 05              7986 	mov	ar5,@r0
                           7987 ;	genPlus
   CAE9 E5 10              7988 	mov	a,_bp
   CAEB 24 04              7989 	add	a,#0x04
   CAED F8                 7990 	mov	r0,a
                           7991 ;     genPlusIncr
   CAEE 06                 7992 	inc	@r0
                           7993 ;	genPlus
                           7994 ;	Peephole 236.g	used r5 instead of ar5
   CAEF ED                 7995 	mov	a,r5
                           7996 ;	Peephole 236.a	used r2 instead of ar2
   CAF0 2A                 7997 	add	a,r2
   CAF1 FA                 7998 	mov	r2,a
                           7999 ;	Peephole 181	changed mov to clr
   CAF2 E4                 8000 	clr	a
                           8001 ;	Peephole 236.b	used r3 instead of ar3
   CAF3 3B                 8002 	addc	a,r3
   CAF4 FB                 8003 	mov	r3,a
                           8004 ;	genPointerGet
                           8005 ;	genGenPointerGet
   CAF5 8A 82              8006 	mov	dpl,r2
   CAF7 8B 83              8007 	mov	dph,r3
   CAF9 8C F0              8008 	mov	b,r4
   CAFB 12 E4 9F           8009 	lcall	__gptrget
   CAFE FA                 8010 	mov	r2,a
                           8011 ;	genAssign
   CAFF E5 10              8012 	mov	a,_bp
   CB01 24 05              8013 	add	a,#0x05
   CB03 F8                 8014 	mov	r0,a
   CB04 A6 02              8015 	mov	@r0,ar2
                           8016 ;	../../Common/modules/cIPv6.c:1189: hoplimit--;
                           8017 ;	genMinus
   CB06 E5 10              8018 	mov	a,_bp
   CB08 24 05              8019 	add	a,#0x05
   CB0A F8                 8020 	mov	r0,a
                           8021 ;	genMinusDec
   CB0B 16                 8022 	dec	@r0
                           8023 ;	../../Common/modules/cIPv6.c:1190: ind +=16;
                           8024 ;	genPlus
   CB0C E5 10              8025 	mov	a,_bp
   CB0E 24 04              8026 	add	a,#0x04
   CB10 F8                 8027 	mov	r0,a
                           8028 ;     genPlusIncr
   CB11 74 10              8029 	mov	a,#0x10
   CB13 26                 8030 	add	a,@r0
   CB14 F6                 8031 	mov	@r0,a
                           8032 ;	../../Common/modules/cIPv6.c:1244: buf=0;
                           8033 ;	genIpop
                           8034 ;	../../Common/modules/cIPv6.c:1191: for(i=0; i<16; i++)
                           8035 ;	genAddrOf
   CB15 E5 10              8036 	mov	a,_bp
   CB17 24 09              8037 	add	a,#0x09
   CB19 F8                 8038 	mov	r0,a
                           8039 ;	genPlus
   CB1A A9 10              8040 	mov	r1,_bp
   CB1C 09                 8041 	inc	r1
                           8042 ;     genPlusIncr
   CB1D 74 2C              8043 	mov	a,#0x2C
   CB1F 27                 8044 	add	a,@r1
   CB20 FA                 8045 	mov	r2,a
                           8046 ;	Peephole 181	changed mov to clr
   CB21 E4                 8047 	clr	a
   CB22 09                 8048 	inc	r1
   CB23 37                 8049 	addc	a,@r1
   CB24 FB                 8050 	mov	r3,a
   CB25 09                 8051 	inc	r1
   CB26 87 04              8052 	mov	ar4,@r1
                           8053 ;	genAssign
   CB28 E5 10              8054 	mov	a,_bp
   CB2A 24 04              8055 	add	a,#0x04
   CB2C F9                 8056 	mov	r1,a
   CB2D C0 00              8057 	push	ar0
   CB2F E5 10              8058 	mov	a,_bp
   CB31 24 19              8059 	add	a,#0x19
   CB33 F8                 8060 	mov	r0,a
   CB34 E7                 8061 	mov	a,@r1
   CB35 F6                 8062 	mov	@r0,a
   CB36 D0 00              8063 	pop	ar0
                           8064 ;	genAssign
   CB38 E5 10              8065 	mov	a,_bp
   CB3A 24 07              8066 	add	a,#0x07
   CB3C F9                 8067 	mov	r1,a
   CB3D 77 00              8068 	mov	@r1,#0x00
   CB3F                    8069 00125$:
                           8070 ;	genCmpLt
   CB3F E5 10              8071 	mov	a,_bp
   CB41 24 07              8072 	add	a,#0x07
   CB43 F9                 8073 	mov	r1,a
                           8074 ;	genCmp
   CB44 B7 10 00           8075 	cjne	@r1,#0x10,00150$
   CB47                    8076 00150$:
                           8077 ;	genIfxJump
                           8078 ;	Peephole 108.a	removed ljmp by inverse jump logic
   CB47 50 40              8079 	jnc	00147$
                           8080 ;	Peephole 300	removed redundant label 00151$
                           8081 ;	../../Common/modules/cIPv6.c:1193: destination[15-i] = buf->buf[ind++];
                           8082 ;	genMinus
   CB49 E5 10              8083 	mov	a,_bp
   CB4B 24 07              8084 	add	a,#0x07
   CB4D F9                 8085 	mov	r1,a
   CB4E 74 0F              8086 	mov	a,#0x0F
   CB50 C3                 8087 	clr	c
   CB51 97                 8088 	subb	a,@r1
                           8089 ;	genPlus
   CB52 FE                 8090 	mov	r6,a
                           8091 ;	Peephole 177.b	removed redundant mov
                           8092 ;	Peephole 236.a	used r0 instead of ar0
   CB53 28                 8093 	add	a,r0
   CB54 F9                 8094 	mov	r1,a
                           8095 ;	genAssign
   CB55 C0 00              8096 	push	ar0
   CB57 E5 10              8097 	mov	a,_bp
   CB59 24 19              8098 	add	a,#0x19
   CB5B F8                 8099 	mov	r0,a
   CB5C 86 06              8100 	mov	ar6,@r0
   CB5E D0 00              8101 	pop	ar0
                           8102 ;	genPlus
   CB60 C0 00              8103 	push	ar0
   CB62 E5 10              8104 	mov	a,_bp
   CB64 24 19              8105 	add	a,#0x19
   CB66 F8                 8106 	mov	r0,a
                           8107 ;     genPlusIncr
   CB67 06                 8108 	inc	@r0
   CB68 D0 00              8109 	pop	ar0
                           8110 ;	genIpush
   CB6A C0 00              8111 	push	ar0
                           8112 ;	genPlus
                           8113 ;	Peephole 236.g	used r6 instead of ar6
   CB6C EE                 8114 	mov	a,r6
                           8115 ;	Peephole 236.a	used r2 instead of ar2
   CB6D 2A                 8116 	add	a,r2
   CB6E FE                 8117 	mov	r6,a
                           8118 ;	Peephole 181	changed mov to clr
   CB6F E4                 8119 	clr	a
                           8120 ;	Peephole 236.b	used r3 instead of ar3
   CB70 3B                 8121 	addc	a,r3
   CB71 FF                 8122 	mov	r7,a
   CB72 8C 05              8123 	mov	ar5,r4
                           8124 ;	genPointerGet
                           8125 ;	genGenPointerGet
   CB74 8E 82              8126 	mov	dpl,r6
   CB76 8F 83              8127 	mov	dph,r7
   CB78 8D F0              8128 	mov	b,r5
   CB7A 12 E4 9F           8129 	lcall	__gptrget
                           8130 ;	genPointerSet
                           8131 ;	genNearPointerSet
   CB7D FE                 8132 	mov	r6,a
                           8133 ;	Peephole 192	used a instead of ar6 as source
   CB7E F7                 8134 	mov	@r1,a
                           8135 ;	../../Common/modules/cIPv6.c:1191: for(i=0; i<16; i++)
                           8136 ;	genPlus
   CB7F E5 10              8137 	mov	a,_bp
   CB81 24 07              8138 	add	a,#0x07
   CB83 F9                 8139 	mov	r1,a
                           8140 ;     genPlusIncr
   CB84 07                 8141 	inc	@r1
                           8142 ;	genIpop
   CB85 D0 00              8143 	pop	ar0
                           8144 ;	Peephole 112.b	changed ljmp to sjmp
   CB87 80 B6              8145 	sjmp	00125$
   CB89                    8146 00147$:
                           8147 ;	genAssign
   CB89 E5 10              8148 	mov	a,_bp
   CB8B 24 19              8149 	add	a,#0x19
   CB8D F9                 8150 	mov	r1,a
   CB8E C0 00              8151 	push	ar0
   CB90 E5 10              8152 	mov	a,_bp
   CB92 24 04              8153 	add	a,#0x04
   CB94 F8                 8154 	mov	r0,a
   CB95 E7                 8155 	mov	a,@r1
   CB96 F6                 8156 	mov	@r0,a
   CB97 D0 00              8157 	pop	ar0
                           8158 ;	../../Common/modules/cIPv6.c:1195: if(destination[15] == 0xfe && destination[14] == 0x80)
                           8159 ;	genPlus
                           8160 ;     genPlusIncr
   CB99 74 0F              8161 	mov	a,#0x0F
                           8162 ;	Peephole 236.a	used r0 instead of ar0
   CB9B 28                 8163 	add	a,r0
   CB9C F9                 8164 	mov	r1,a
                           8165 ;	genPointerGet
                           8166 ;	genNearPointerGet
   CB9D 87 02              8167 	mov	ar2,@r1
                           8168 ;	genCmpEq
                           8169 ;	gencjneshort
   CB9F BA FE 02           8170 	cjne	r2,#0xFE,00152$
   CBA2 80 03              8171 	sjmp	00153$
   CBA4                    8172 00152$:
   CBA4 02 CC 53           8173 	ljmp	00110$
   CBA7                    8174 00153$:
                           8175 ;	genPlus
                           8176 ;     genPlusIncr
   CBA7 74 0E              8177 	mov	a,#0x0E
                           8178 ;	Peephole 236.a	used r0 instead of ar0
   CBA9 28                 8179 	add	a,r0
   CBAA FA                 8180 	mov	r2,a
                           8181 ;	genPointerGet
                           8182 ;	genNearPointerGet
   CBAB C0 00              8183 	push	ar0
   CBAD A8 02              8184 	mov	r0,ar2
   CBAF 86 02              8185 	mov	ar2,@r0
   CBB1 D0 00              8186 	pop	ar0
                           8187 ;	genCmpEq
                           8188 ;	gencjneshort
   CBB3 BA 80 02           8189 	cjne	r2,#0x80,00154$
   CBB6 80 03              8190 	sjmp	00155$
   CBB8                    8191 00154$:
   CBB8 02 CC 53           8192 	ljmp	00110$
   CBBB                    8193 00155$:
                           8194 ;	../../Common/modules/cIPv6.c:1200: if(destination[3] == 0xfe && destination[3] == 0xff)
                           8195 ;	genPlus
                           8196 ;     genPlusIncr
   CBBB 74 03              8197 	mov	a,#0x03
                           8198 ;	Peephole 236.a	used r0 instead of ar0
   CBBD 28                 8199 	add	a,r0
   CBBE FA                 8200 	mov	r2,a
                           8201 ;	genPointerGet
                           8202 ;	genNearPointerGet
   CBBF C0 00              8203 	push	ar0
   CBC1 A8 02              8204 	mov	r0,ar2
   CBC3 86 02              8205 	mov	ar2,@r0
   CBC5 D0 00              8206 	pop	ar0
                           8207 ;	genCmpEq
                           8208 ;	gencjneshort
                           8209 ;	Peephole 112.b	changed ljmp to sjmp
                           8210 ;	Peephole 198.b	optimized misc jump sequence
   CBC7 BA FE 47           8211 	cjne	r2,#0xFE,00106$
                           8212 ;	Peephole 200.b	removed redundant sjmp
                           8213 ;	Peephole 300	removed redundant label 00156$
                           8214 ;	Peephole 300	removed redundant label 00157$
                           8215 ;	genCmpEq
                           8216 ;	gencjneshort
                           8217 ;	Peephole 112.b	changed ljmp to sjmp
                           8218 ;	Peephole 198.b	optimized misc jump sequence
   CBCA BA FF 44           8219 	cjne	r2,#0xFF,00106$
                           8220 ;	Peephole 200.b	removed redundant sjmp
                           8221 ;	Peephole 300	removed redundant label 00158$
                           8222 ;	Peephole 300	removed redundant label 00159$
                           8223 ;	../../Common/modules/cIPv6.c:1202: if(memcmp(destination, cipv6_pib.short_address, 2) ==0)
                           8224 ;	genAssign
   CBCD 88 02              8225 	mov	ar2,r0
                           8226 ;	genCast
   CBCF 7B 00              8227 	mov	r3,#0x00
   CBD1 7C 40              8228 	mov	r4,#0x40
                           8229 ;	genIpush
   CBD3 C0 00              8230 	push	ar0
   CBD5 C0 01              8231 	push	ar1
   CBD7 74 02              8232 	mov	a,#0x02
   CBD9 C0 E0              8233 	push	acc
                           8234 ;	Peephole 181	changed mov to clr
   CBDB E4                 8235 	clr	a
   CBDC C0 E0              8236 	push	acc
                           8237 ;	genIpush
   CBDE 74 57              8238 	mov	a,#(_cipv6_pib + 0x000a)
   CBE0 C0 E0              8239 	push	acc
   CBE2 74 F0              8240 	mov	a,#((_cipv6_pib + 0x000a) >> 8)
   CBE4 C0 E0              8241 	push	acc
                           8242 ;	Peephole 181	changed mov to clr
   CBE6 E4                 8243 	clr	a
   CBE7 C0 E0              8244 	push	acc
                           8245 ;	genCall
   CBE9 8A 82              8246 	mov	dpl,r2
   CBEB 8B 83              8247 	mov	dph,r3
   CBED 8C F0              8248 	mov	b,r4
   CBEF 12 E2 0A           8249 	lcall	_memcmp
   CBF2 AA 82              8250 	mov	r2,dpl
   CBF4 AB 83              8251 	mov	r3,dph
   CBF6 E5 81              8252 	mov	a,sp
   CBF8 24 FB              8253 	add	a,#0xfb
   CBFA F5 81              8254 	mov	sp,a
   CBFC D0 01              8255 	pop	ar1
   CBFE D0 00              8256 	pop	ar0
                           8257 ;	genIfx
   CC00 EA                 8258 	mov	a,r2
   CC01 4B                 8259 	orl	a,r3
                           8260 ;	genIfxJump
                           8261 ;	Peephole 108.b	removed ljmp by inverse jump logic
   CC02 70 4F              8262 	jnz	00110$
                           8263 ;	Peephole 300	removed redundant label 00160$
                           8264 ;	../../Common/modules/cIPv6.c:1203: dest_match=1;
                           8265 ;	genAssign
   CC04 C0 00              8266 	push	ar0
   CC06 E5 10              8267 	mov	a,_bp
   CC08 24 08              8268 	add	a,#0x08
   CC0A F8                 8269 	mov	r0,a
   CC0B 76 01              8270 	mov	@r0,#0x01
   CC0D D0 00              8271 	pop	ar0
                           8272 ;	Peephole 112.b	changed ljmp to sjmp
   CC0F 80 42              8273 	sjmp	00110$
   CC11                    8274 00106$:
                           8275 ;	../../Common/modules/cIPv6.c:1207: if(memcmp(destination, cipv6_pib.long_address, 8) ==0)
                           8276 ;	genAssign
   CC11 88 02              8277 	mov	ar2,r0
                           8278 ;	genCast
   CC13 7B 00              8279 	mov	r3,#0x00
   CC15 7C 40              8280 	mov	r4,#0x40
                           8281 ;	genIpush
   CC17 C0 00              8282 	push	ar0
   CC19 C0 01              8283 	push	ar1
   CC1B 74 08              8284 	mov	a,#0x08
   CC1D C0 E0              8285 	push	acc
                           8286 ;	Peephole 181	changed mov to clr
   CC1F E4                 8287 	clr	a
   CC20 C0 E0              8288 	push	acc
                           8289 ;	genIpush
   CC22 74 4F              8290 	mov	a,#(_cipv6_pib + 0x0002)
   CC24 C0 E0              8291 	push	acc
   CC26 74 F0              8292 	mov	a,#((_cipv6_pib + 0x0002) >> 8)
   CC28 C0 E0              8293 	push	acc
                           8294 ;	Peephole 181	changed mov to clr
   CC2A E4                 8295 	clr	a
   CC2B C0 E0              8296 	push	acc
                           8297 ;	genCall
   CC2D 8A 82              8298 	mov	dpl,r2
   CC2F 8B 83              8299 	mov	dph,r3
   CC31 8C F0              8300 	mov	b,r4
   CC33 12 E2 0A           8301 	lcall	_memcmp
   CC36 AA 82              8302 	mov	r2,dpl
   CC38 AB 83              8303 	mov	r3,dph
   CC3A E5 81              8304 	mov	a,sp
   CC3C 24 FB              8305 	add	a,#0xfb
   CC3E F5 81              8306 	mov	sp,a
   CC40 D0 01              8307 	pop	ar1
   CC42 D0 00              8308 	pop	ar0
                           8309 ;	genIfx
   CC44 EA                 8310 	mov	a,r2
   CC45 4B                 8311 	orl	a,r3
                           8312 ;	genIfxJump
                           8313 ;	Peephole 108.b	removed ljmp by inverse jump logic
   CC46 70 0B              8314 	jnz	00110$
                           8315 ;	Peephole 300	removed redundant label 00161$
                           8316 ;	../../Common/modules/cIPv6.c:1208: dest_match=1;
                           8317 ;	genAssign
   CC48 C0 00              8318 	push	ar0
   CC4A E5 10              8319 	mov	a,_bp
   CC4C 24 08              8320 	add	a,#0x08
   CC4E F8                 8321 	mov	r0,a
   CC4F 76 01              8322 	mov	@r0,#0x01
   CC51 D0 00              8323 	pop	ar0
   CC53                    8324 00110$:
                           8325 ;	../../Common/modules/cIPv6.c:1212: if((destination[15] == 0xff && destination[14] == 0x02) && destination[0] == 0x01)
                           8326 ;	genPointerGet
                           8327 ;	genNearPointerGet
   CC53 87 02              8328 	mov	ar2,@r1
                           8329 ;	genCmpEq
                           8330 ;	gencjneshort
                           8331 ;	Peephole 112.b	changed ljmp to sjmp
                           8332 ;	Peephole 198.b	optimized misc jump sequence
   CC55 BA FF 15           8333 	cjne	r2,#0xFF,00113$
                           8334 ;	Peephole 200.b	removed redundant sjmp
                           8335 ;	Peephole 300	removed redundant label 00162$
                           8336 ;	Peephole 300	removed redundant label 00163$
                           8337 ;	genPlus
                           8338 ;     genPlusIncr
   CC58 74 0E              8339 	mov	a,#0x0E
                           8340 ;	Peephole 236.a	used r0 instead of ar0
   CC5A 28                 8341 	add	a,r0
   CC5B F9                 8342 	mov	r1,a
                           8343 ;	genPointerGet
                           8344 ;	genNearPointerGet
   CC5C 87 02              8345 	mov	ar2,@r1
                           8346 ;	genCmpEq
                           8347 ;	gencjneshort
                           8348 ;	Peephole 112.b	changed ljmp to sjmp
                           8349 ;	Peephole 198.b	optimized misc jump sequence
   CC5E BA 02 0C           8350 	cjne	r2,#0x02,00113$
                           8351 ;	Peephole 200.b	removed redundant sjmp
                           8352 ;	Peephole 300	removed redundant label 00164$
                           8353 ;	Peephole 300	removed redundant label 00165$
                           8354 ;	genPointerGet
                           8355 ;	genNearPointerGet
   CC61 86 02              8356 	mov	ar2,@r0
                           8357 ;	genCmpEq
                           8358 ;	gencjneshort
                           8359 ;	Peephole 112.b	changed ljmp to sjmp
                           8360 ;	Peephole 198.b	optimized misc jump sequence
   CC63 BA 01 07           8361 	cjne	r2,#0x01,00113$
                           8362 ;	Peephole 200.b	removed redundant sjmp
                           8363 ;	Peephole 300	removed redundant label 00166$
                           8364 ;	Peephole 300	removed redundant label 00167$
                           8365 ;	../../Common/modules/cIPv6.c:1217: dest_match=1;
                           8366 ;	genAssign
   CC66 E5 10              8367 	mov	a,_bp
   CC68 24 08              8368 	add	a,#0x08
   CC6A F8                 8369 	mov	r0,a
   CC6B 76 01              8370 	mov	@r0,#0x01
   CC6D                    8371 00113$:
                           8372 ;	../../Common/modules/cIPv6.c:1220: buf->options.lowpan_compressed = 0;
                           8373 ;	genPlus
   CC6D A8 10              8374 	mov	r0,_bp
   CC6F 08                 8375 	inc	r0
                           8376 ;     genPlusIncr
   CC70 74 26              8377 	mov	a,#0x26
   CC72 26                 8378 	add	a,@r0
   CC73 FA                 8379 	mov	r2,a
                           8380 ;	Peephole 181	changed mov to clr
   CC74 E4                 8381 	clr	a
   CC75 08                 8382 	inc	r0
   CC76 36                 8383 	addc	a,@r0
   CC77 FB                 8384 	mov	r3,a
   CC78 08                 8385 	inc	r0
   CC79 86 04              8386 	mov	ar4,@r0
                           8387 ;	genPlus
                           8388 ;     genPlusIncr
   CC7B 74 05              8389 	mov	a,#0x05
                           8390 ;	Peephole 236.a	used r2 instead of ar2
   CC7D 2A                 8391 	add	a,r2
   CC7E FD                 8392 	mov	r5,a
                           8393 ;	Peephole 181	changed mov to clr
   CC7F E4                 8394 	clr	a
                           8395 ;	Peephole 236.b	used r3 instead of ar3
   CC80 3B                 8396 	addc	a,r3
   CC81 FE                 8397 	mov	r6,a
   CC82 8C 07              8398 	mov	ar7,r4
                           8399 ;	genPointerSet
                           8400 ;	genGenPointerSet
   CC84 8D 82              8401 	mov	dpl,r5
   CC86 8E 83              8402 	mov	dph,r6
   CC88 8F F0              8403 	mov	b,r7
                           8404 ;	Peephole 181	changed mov to clr
   CC8A E4                 8405 	clr	a
   CC8B 12 DF B7           8406 	lcall	__gptrput
                           8407 ;	../../Common/modules/cIPv6.c:1221: if(next_header==NEXT_HEADER_ICMP6) buf->options.hop_count = 1;
                           8408 ;	genCmpEq
   CC8E E5 10              8409 	mov	a,_bp
   CC90 24 06              8410 	add	a,#0x06
   CC92 F8                 8411 	mov	r0,a
                           8412 ;	gencjneshort
                           8413 ;	Peephole 112.b	changed ljmp to sjmp
                           8414 ;	Peephole 198.b	optimized misc jump sequence
   CC93 B6 3A 12           8415 	cjne	@r0,#0x3A,00117$
                           8416 ;	Peephole 200.b	removed redundant sjmp
                           8417 ;	Peephole 300	removed redundant label 00168$
                           8418 ;	Peephole 300	removed redundant label 00169$
                           8419 ;	genPlus
                           8420 ;     genPlusIncr
   CC96 74 04              8421 	mov	a,#0x04
                           8422 ;	Peephole 236.a	used r2 instead of ar2
   CC98 2A                 8423 	add	a,r2
   CC99 FA                 8424 	mov	r2,a
                           8425 ;	Peephole 181	changed mov to clr
   CC9A E4                 8426 	clr	a
                           8427 ;	Peephole 236.b	used r3 instead of ar3
   CC9B 3B                 8428 	addc	a,r3
   CC9C FB                 8429 	mov	r3,a
                           8430 ;	genPointerSet
                           8431 ;	genGenPointerSet
   CC9D 8A 82              8432 	mov	dpl,r2
   CC9F 8B 83              8433 	mov	dph,r3
   CCA1 8C F0              8434 	mov	b,r4
   CCA3 74 01              8435 	mov	a,#0x01
   CCA5 12 DF B7           8436 	lcall	__gptrput
   CCA8                    8437 00117$:
                           8438 ;	../../Common/modules/cIPv6.c:1222: if(hoplimit > 0 && dest_match)
                           8439 ;	genIfx
   CCA8 E5 10              8440 	mov	a,_bp
   CCAA 24 05              8441 	add	a,#0x05
   CCAC F8                 8442 	mov	r0,a
   CCAD E6                 8443 	mov	a,@r0
                           8444 ;	genIfxJump
                           8445 ;	Peephole 108.c	removed ljmp by inverse jump logic
   CCAE 60 6F              8446 	jz	00122$
                           8447 ;	Peephole 300	removed redundant label 00170$
                           8448 ;	genIfx
   CCB0 E5 10              8449 	mov	a,_bp
   CCB2 24 08              8450 	add	a,#0x08
   CCB4 F8                 8451 	mov	r0,a
   CCB5 E6                 8452 	mov	a,@r0
                           8453 ;	genIfxJump
                           8454 ;	Peephole 108.c	removed ljmp by inverse jump logic
   CCB6 60 67              8455 	jz	00122$
                           8456 ;	Peephole 300	removed redundant label 00171$
                           8457 ;	../../Common/modules/cIPv6.c:1224: buf->buf_ptr = ind; /*cut header*/
                           8458 ;	genCast
   CCB8 E5 10              8459 	mov	a,_bp
   CCBA 24 04              8460 	add	a,#0x04
   CCBC F8                 8461 	mov	r0,a
   CCBD 86 02              8462 	mov	ar2,@r0
   CCBF 7B 00              8463 	mov	r3,#0x00
                           8464 ;	genPointerSet
                           8465 ;	genGenPointerSet
   CCC1 E5 10              8466 	mov	a,_bp
   CCC3 24 1C              8467 	add	a,#0x1c
   CCC5 F8                 8468 	mov	r0,a
   CCC6 86 82              8469 	mov	dpl,@r0
   CCC8 08                 8470 	inc	r0
   CCC9 86 83              8471 	mov	dph,@r0
   CCCB 08                 8472 	inc	r0
   CCCC 86 F0              8473 	mov	b,@r0
   CCCE EA                 8474 	mov	a,r2
   CCCF 12 DF B7           8475 	lcall	__gptrput
   CCD2 A3                 8476 	inc	dptr
   CCD3 EB                 8477 	mov	a,r3
   CCD4 12 DF B7           8478 	lcall	__gptrput
                           8479 ;	../../Common/modules/cIPv6.c:1225: buf->to = MODULE_NONE;
                           8480 ;	genPlus
   CCD7 A8 10              8481 	mov	r0,_bp
   CCD9 08                 8482 	inc	r0
                           8483 ;     genPlusIncr
   CCDA 74 1E              8484 	mov	a,#0x1E
   CCDC 26                 8485 	add	a,@r0
   CCDD FA                 8486 	mov	r2,a
                           8487 ;	Peephole 181	changed mov to clr
   CCDE E4                 8488 	clr	a
   CCDF 08                 8489 	inc	r0
   CCE0 36                 8490 	addc	a,@r0
   CCE1 FB                 8491 	mov	r3,a
   CCE2 08                 8492 	inc	r0
   CCE3 86 04              8493 	mov	ar4,@r0
                           8494 ;	genPointerSet
                           8495 ;	genGenPointerSet
   CCE5 8A 82              8496 	mov	dpl,r2
   CCE7 8B 83              8497 	mov	dph,r3
   CCE9 8C F0              8498 	mov	b,r4
                           8499 ;	Peephole 181	changed mov to clr
   CCEB E4                 8500 	clr	a
   CCEC 12 DF B7           8501 	lcall	__gptrput
                           8502 ;	../../Common/modules/cIPv6.c:1226: buf->from = MODULE_CIPV6;
                           8503 ;	genPlus
   CCEF A8 10              8504 	mov	r0,_bp
   CCF1 08                 8505 	inc	r0
                           8506 ;     genPlusIncr
   CCF2 74 1D              8507 	mov	a,#0x1D
   CCF4 26                 8508 	add	a,@r0
   CCF5 FA                 8509 	mov	r2,a
                           8510 ;	Peephole 181	changed mov to clr
   CCF6 E4                 8511 	clr	a
   CCF7 08                 8512 	inc	r0
   CCF8 36                 8513 	addc	a,@r0
   CCF9 FB                 8514 	mov	r3,a
   CCFA 08                 8515 	inc	r0
   CCFB 86 04              8516 	mov	ar4,@r0
                           8517 ;	genPointerSet
                           8518 ;	genGenPointerSet
   CCFD 8A 82              8519 	mov	dpl,r2
   CCFF 8B 83              8520 	mov	dph,r3
   CD01 8C F0              8521 	mov	b,r4
   CD03 74 01              8522 	mov	a,#0x01
   CD05 12 DF B7           8523 	lcall	__gptrput
                           8524 ;	../../Common/modules/cIPv6.c:1227: stack_buffer_push(buf);
                           8525 ;	genCall
   CD08 A8 10              8526 	mov	r0,_bp
   CD0A 08                 8527 	inc	r0
   CD0B 86 82              8528 	mov	dpl,@r0
   CD0D 08                 8529 	inc	r0
   CD0E 86 83              8530 	mov	dph,@r0
   CD10 08                 8531 	inc	r0
   CD11 86 F0              8532 	mov	b,@r0
   CD13 12 62 C4           8533 	lcall	_stack_buffer_push
                           8534 ;	../../Common/modules/cIPv6.c:1228: buf=0;
                           8535 ;	genAssign
   CD16 A8 10              8536 	mov	r0,_bp
   CD18 08                 8537 	inc	r0
   CD19 E4                 8538 	clr	a
   CD1A F6                 8539 	mov	@r0,a
   CD1B 08                 8540 	inc	r0
   CD1C F6                 8541 	mov	@r0,a
   CD1D 08                 8542 	inc	r0
   CD1E F6                 8543 	mov	@r0,a
   CD1F                    8544 00122$:
                           8545 ;	../../Common/modules/cIPv6.c:1238: if(buf)
                           8546 ;	genIfx
   CD1F A8 10              8547 	mov	r0,_bp
   CD21 08                 8548 	inc	r0
   CD22 E6                 8549 	mov	a,@r0
   CD23 08                 8550 	inc	r0
   CD24 46                 8551 	orl	a,@r0
   CD25 08                 8552 	inc	r0
   CD26 46                 8553 	orl	a,@r0
                           8554 ;	genIfxJump
                           8555 ;	Peephole 108.c	removed ljmp by inverse jump logic
   CD27 60 0E              8556 	jz	00129$
                           8557 ;	Peephole 300	removed redundant label 00172$
                           8558 ;	../../Common/modules/cIPv6.c:1243: stack_buffer_free(buf);
                           8559 ;	genCall
   CD29 A8 10              8560 	mov	r0,_bp
   CD2B 08                 8561 	inc	r0
   CD2C 86 82              8562 	mov	dpl,@r0
   CD2E 08                 8563 	inc	r0
   CD2F 86 83              8564 	mov	dph,@r0
   CD31 08                 8565 	inc	r0
   CD32 86 F0              8566 	mov	b,@r0
   CD34 12 61 FA           8567 	lcall	_stack_buffer_free
                           8568 ;	../../Common/modules/cIPv6.c:1244: buf=0;
   CD37                    8569 00129$:
   CD37 85 10 81           8570 	mov	sp,_bp
   CD3A D0 10              8571 	pop	_bp
   CD3C 22                 8572 	ret
                           8573 ;------------------------------------------------------------
                           8574 ;Allocation info for local variables in function 'compare_ori_to_own'
                           8575 ;------------------------------------------------------------
                           8576 ;address                   Allocated to stack - offset -5
                           8577 ;type                      Allocated to registers r2 
                           8578 ;------------------------------------------------------------
                           8579 ;	../../Common/modules/cIPv6.c:1248: portCHAR compare_ori_to_own(addrtype_t type, address_t address)
                           8580 ;	-----------------------------------------
                           8581 ;	 function compare_ori_to_own
                           8582 ;	-----------------------------------------
   CD3D                    8583 _compare_ori_to_own:
   CD3D C0 10              8584 	push	_bp
   CD3F 85 81 10           8585 	mov	_bp,sp
                           8586 ;	genReceive
   CD42 AA 82              8587 	mov	r2,dpl
                           8588 ;	../../Common/modules/cIPv6.c:1250: if(type==ADDR_802_15_4_PAN_LONG)
                           8589 ;	genCmpEq
                           8590 ;	gencjneshort
                           8591 ;	Peephole 112.b	changed ljmp to sjmp
                           8592 ;	Peephole 198.b	optimized misc jump sequence
   CD44 BA 04 3B           8593 	cjne	r2,#0x04,00106$
                           8594 ;	Peephole 200.b	removed redundant sjmp
                           8595 ;	Peephole 300	removed redundant label 00113$
                           8596 ;	Peephole 300	removed redundant label 00114$
                           8597 ;	../../Common/modules/cIPv6.c:1252: if(memcmp(address,cipv6_pib.long_address , 8)==0)
                           8598 ;	genAssign
   CD47 E5 10              8599 	mov	a,_bp
   CD49 24 FB              8600 	add	a,#0xfffffffb
   CD4B F8                 8601 	mov	r0,a
   CD4C 86 02              8602 	mov	ar2,@r0
   CD4E 08                 8603 	inc	r0
   CD4F 86 03              8604 	mov	ar3,@r0
   CD51 08                 8605 	inc	r0
   CD52 86 04              8606 	mov	ar4,@r0
                           8607 ;	genIpush
   CD54 74 08              8608 	mov	a,#0x08
   CD56 C0 E0              8609 	push	acc
                           8610 ;	Peephole 181	changed mov to clr
   CD58 E4                 8611 	clr	a
   CD59 C0 E0              8612 	push	acc
                           8613 ;	genIpush
   CD5B 74 4F              8614 	mov	a,#(_cipv6_pib + 0x0002)
   CD5D C0 E0              8615 	push	acc
   CD5F 74 F0              8616 	mov	a,#((_cipv6_pib + 0x0002) >> 8)
   CD61 C0 E0              8617 	push	acc
                           8618 ;	Peephole 181	changed mov to clr
   CD63 E4                 8619 	clr	a
   CD64 C0 E0              8620 	push	acc
                           8621 ;	genCall
   CD66 8A 82              8622 	mov	dpl,r2
   CD68 8B 83              8623 	mov	dph,r3
   CD6A 8C F0              8624 	mov	b,r4
   CD6C 12 E2 0A           8625 	lcall	_memcmp
   CD6F AA 82              8626 	mov	r2,dpl
   CD71 AB 83              8627 	mov	r3,dph
   CD73 E5 81              8628 	mov	a,sp
   CD75 24 FB              8629 	add	a,#0xfb
   CD77 F5 81              8630 	mov	sp,a
                           8631 ;	genIfx
   CD79 EA                 8632 	mov	a,r2
   CD7A 4B                 8633 	orl	a,r3
                           8634 ;	genIfxJump
                           8635 ;	Peephole 108.b	removed ljmp by inverse jump logic
   CD7B 70 40              8636 	jnz	00107$
                           8637 ;	Peephole 300	removed redundant label 00115$
                           8638 ;	../../Common/modules/cIPv6.c:1253: return pdTRUE;
                           8639 ;	genRet
   CD7D 75 82 01           8640 	mov	dpl,#0x01
                           8641 ;	Peephole 112.b	changed ljmp to sjmp
   CD80 80 3E              8642 	sjmp	00108$
   CD82                    8643 00106$:
                           8644 ;	../../Common/modules/cIPv6.c:1257: if(memcmp(address,cipv6_pib.short_address ,2)==0)
                           8645 ;	genAssign
   CD82 E5 10              8646 	mov	a,_bp
   CD84 24 FB              8647 	add	a,#0xfffffffb
   CD86 F8                 8648 	mov	r0,a
   CD87 86 02              8649 	mov	ar2,@r0
   CD89 08                 8650 	inc	r0
   CD8A 86 03              8651 	mov	ar3,@r0
   CD8C 08                 8652 	inc	r0
   CD8D 86 04              8653 	mov	ar4,@r0
                           8654 ;	genIpush
   CD8F 74 02              8655 	mov	a,#0x02
   CD91 C0 E0              8656 	push	acc
                           8657 ;	Peephole 181	changed mov to clr
   CD93 E4                 8658 	clr	a
   CD94 C0 E0              8659 	push	acc
                           8660 ;	genIpush
   CD96 74 57              8661 	mov	a,#(_cipv6_pib + 0x000a)
   CD98 C0 E0              8662 	push	acc
   CD9A 74 F0              8663 	mov	a,#((_cipv6_pib + 0x000a) >> 8)
   CD9C C0 E0              8664 	push	acc
                           8665 ;	Peephole 181	changed mov to clr
   CD9E E4                 8666 	clr	a
   CD9F C0 E0              8667 	push	acc
                           8668 ;	genCall
   CDA1 8A 82              8669 	mov	dpl,r2
   CDA3 8B 83              8670 	mov	dph,r3
   CDA5 8C F0              8671 	mov	b,r4
   CDA7 12 E2 0A           8672 	lcall	_memcmp
   CDAA AA 82              8673 	mov	r2,dpl
   CDAC AB 83              8674 	mov	r3,dph
   CDAE E5 81              8675 	mov	a,sp
   CDB0 24 FB              8676 	add	a,#0xfb
   CDB2 F5 81              8677 	mov	sp,a
                           8678 ;	genIfx
   CDB4 EA                 8679 	mov	a,r2
   CDB5 4B                 8680 	orl	a,r3
                           8681 ;	genIfxJump
                           8682 ;	Peephole 108.b	removed ljmp by inverse jump logic
   CDB6 70 05              8683 	jnz	00107$
                           8684 ;	Peephole 300	removed redundant label 00116$
                           8685 ;	../../Common/modules/cIPv6.c:1258: return pdTRUE;
                           8686 ;	genRet
   CDB8 75 82 01           8687 	mov	dpl,#0x01
                           8688 ;	Peephole 112.b	changed ljmp to sjmp
   CDBB 80 03              8689 	sjmp	00108$
   CDBD                    8690 00107$:
                           8691 ;	../../Common/modules/cIPv6.c:1260: return pdFALSE;
                           8692 ;	genRet
   CDBD 75 82 00           8693 	mov	dpl,#0x00
   CDC0                    8694 00108$:
   CDC0 D0 10              8695 	pop	_bp
   CDC2 22                 8696 	ret
                           8697 	.area CSEG    (CODE)
                           8698 	.area CONST   (CODE)
                           8699 	.area XINIT   (CODE)
