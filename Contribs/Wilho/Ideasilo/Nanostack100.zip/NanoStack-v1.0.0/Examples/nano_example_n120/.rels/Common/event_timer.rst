                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Nov 10 2006)
                              4 ; This file generated Fri Feb  1 13:33:38 2008
                              5 ;--------------------------------------------------------
                              6 	.module event_timer
                              7 	.optsdcc -mmcs51 --model-large
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _IRCON2_P2IF
                             13 	.globl _IRCON2_UTX0IF
                             14 	.globl _IRCON2_UTX1IF
                             15 	.globl _IRCON2_P1IF
                             16 	.globl _IRCON2_WDTIF
                             17 	.globl _CY
                             18 	.globl _AC
                             19 	.globl _F0
                             20 	.globl _RS1
                             21 	.globl _RS0
                             22 	.globl _OV
                             23 	.globl _F1
                             24 	.globl _P
                             25 	.globl _IRCON_DMAIF
                             26 	.globl _IRCON_T1IF
                             27 	.globl _IRCON_T2IF
                             28 	.globl _IRCON_T3IF
                             29 	.globl _IRCON_T4IF
                             30 	.globl _IRCON_P0IF
                             31 	.globl _IRCON_STIF
                             32 	.globl _IEN1_DMAIE
                             33 	.globl _IEN1_T1IE
                             34 	.globl _IEN1_T2IE
                             35 	.globl _IEN1_T3IE
                             36 	.globl _IEN1_T4IE
                             37 	.globl _IEN1_P0IE
                             38 	.globl _IEN0_RFERRIE
                             39 	.globl _IEN0_ADCIE
                             40 	.globl _IEN0_URX0IE
                             41 	.globl _IEN0_URX1IE
                             42 	.globl _IEN0_ENCIE
                             43 	.globl _IEN0_STIE
                             44 	.globl _IEN0_EA
                             45 	.globl _EA
                             46 	.globl _P2_4
                             47 	.globl _P2_3
                             48 	.globl _P2_2
                             49 	.globl _P2_1
                             50 	.globl _P2_0
                             51 	.globl _S0CON_ENCIF_0
                             52 	.globl _S0CON_ENCIF_1
                             53 	.globl _P1_7
                             54 	.globl _P1_6
                             55 	.globl _P1_5
                             56 	.globl _P1_4
                             57 	.globl _P1_3
                             58 	.globl _P1_2
                             59 	.globl _P1_1
                             60 	.globl _P1_0
                             61 	.globl _TCON_IT0
                             62 	.globl _TCON_RFERRIF
                             63 	.globl _TCON_IT1
                             64 	.globl _TCON_URX0IF
                             65 	.globl _TCON_ADCIF
                             66 	.globl _TCON_URX1IF
                             67 	.globl _P0_0
                             68 	.globl _P0_1
                             69 	.globl _P0_2
                             70 	.globl _P0_3
                             71 	.globl _P0_4
                             72 	.globl _P0_5
                             73 	.globl _P0_6
                             74 	.globl _P0_7
                             75 	.globl _P2DIR
                             76 	.globl _P1DIR
                             77 	.globl _P0DIR
                             78 	.globl _U1GCR
                             79 	.globl _U1UCR
                             80 	.globl _U1BAUD
                             81 	.globl _U1BUF
                             82 	.globl _U1CSR
                             83 	.globl _P2INP
                             84 	.globl _P1INP
                             85 	.globl _P2SEL
                             86 	.globl _P1SEL
                             87 	.globl _P0SEL
                             88 	.globl _ADCCFG
                             89 	.globl _PERCFG
                             90 	.globl _B
                             91 	.globl _T4CC1
                             92 	.globl _T4CCTL1
                             93 	.globl _T4CC0
                             94 	.globl _T4CCTL0
                             95 	.globl _T4CTL
                             96 	.globl _T4CNT
                             97 	.globl _RFIF
                             98 	.globl _IRCON2
                             99 	.globl _T1CCTL2
                            100 	.globl _T1CCTL1
                            101 	.globl _T1CCTL0
                            102 	.globl _T1CTL
                            103 	.globl _T1CNTH
                            104 	.globl _T1CNTL
                            105 	.globl _RFST
                            106 	.globl _ACC
                            107 	.globl _T1CC2H
                            108 	.globl _T1CC2L
                            109 	.globl _T1CC1H
                            110 	.globl _T1CC1L
                            111 	.globl _T1CC0H
                            112 	.globl _T1CC0L
                            113 	.globl _RFD
                            114 	.globl _TIMIF
                            115 	.globl _DMAREQ
                            116 	.globl _DMAARM
                            117 	.globl _DMA0CFGH
                            118 	.globl _DMA0CFGL
                            119 	.globl _DMA1CFGH
                            120 	.globl _DMA1CFGL
                            121 	.globl _DMAIRQ
                            122 	.globl _PSW
                            123 	.globl _T3CC1
                            124 	.globl _T3CCTL1
                            125 	.globl _T3CC0
                            126 	.globl _T3CCTL0
                            127 	.globl _T3CTL
                            128 	.globl _T3CNT
                            129 	.globl _WDCTL
                            130 	.globl _T2CON
                            131 	.globl _MEMCTR
                            132 	.globl _CLKCON
                            133 	.globl _U0GCR
                            134 	.globl _U0UCR
                            135 	.globl _T2CNF
                            136 	.globl _U0BAUD
                            137 	.globl _U0BUF
                            138 	.globl _IRCON
                            139 	.globl _SLEEP
                            140 	.globl _RNDH
                            141 	.globl _RNDL
                            142 	.globl _ADCH
                            143 	.globl _ADCL
                            144 	.globl _IP1
                            145 	.globl _IEN1
                            146 	.globl _RCCTL
                            147 	.globl _ADCCON3
                            148 	.globl _ADCCON2
                            149 	.globl _ADCCON1
                            150 	.globl _ENCCS
                            151 	.globl _ENCDO
                            152 	.globl _ENCDI
                            153 	.globl _FWDATA
                            154 	.globl _FCTL
                            155 	.globl _FADDRH
                            156 	.globl _FADDRL
                            157 	.globl _FWT
                            158 	.globl _IP0
                            159 	.globl _IEN0
                            160 	.globl _IE
                            161 	.globl _T2THD
                            162 	.globl _T2TLD
                            163 	.globl _T2CAPHPH
                            164 	.globl _T2CAPLPL
                            165 	.globl _T2OF2
                            166 	.globl _T2OF1
                            167 	.globl _T2OF0
                            168 	.globl _P2
                            169 	.globl _T2PEROF2
                            170 	.globl _T2PEROF1
                            171 	.globl _T2PEROF0
                            172 	.globl _S1CON
                            173 	.globl _IEN2
                            174 	.globl _HSRC
                            175 	.globl _S0CON
                            176 	.globl _ST2
                            177 	.globl _ST1
                            178 	.globl _ST0
                            179 	.globl _T2CMP
                            180 	.globl __XPAGE
                            181 	.globl _DPS
                            182 	.globl _RFIM
                            183 	.globl _P1
                            184 	.globl _P0INP
                            185 	.globl _P1IEN
                            186 	.globl _PICTL
                            187 	.globl _P2IFG
                            188 	.globl _P1IFG
                            189 	.globl _P0IFG
                            190 	.globl _TCON
                            191 	.globl _PCON
                            192 	.globl _U0CSR
                            193 	.globl _DPH1
                            194 	.globl _DPL1
                            195 	.globl _DPH0
                            196 	.globl _DPL0
                            197 	.globl _SP
                            198 	.globl _P0
                            199 	.globl _evtInit
                            200 	.globl _evtTickCount
                            201 	.globl _evtTimers
                            202 	.globl _RFD_SHADOW
                            203 	.globl _RFSTATUS
                            204 	.globl _CHIPID
                            205 	.globl _CHVER
                            206 	.globl _FSMTC1
                            207 	.globl _RXFIFOCNT
                            208 	.globl _IOCFG3
                            209 	.globl _IOCFG2
                            210 	.globl _IOCFG1
                            211 	.globl _IOCFG0
                            212 	.globl _SHORTADDRL
                            213 	.globl _SHORTADDRH
                            214 	.globl _PANIDL
                            215 	.globl _PANIDH
                            216 	.globl _IEEE_ADDR7
                            217 	.globl _IEEE_ADDR6
                            218 	.globl _IEEE_ADDR5
                            219 	.globl _IEEE_ADDR4
                            220 	.globl _IEEE_ADDR3
                            221 	.globl _IEEE_ADDR2
                            222 	.globl _IEEE_ADDR1
                            223 	.globl _IEEE_ADDR0
                            224 	.globl _DACTSTL
                            225 	.globl _DACTSTH
                            226 	.globl _ADCTSTL
                            227 	.globl _ADCTSTH
                            228 	.globl _FSMSTATE
                            229 	.globl _AGCCTRLL
                            230 	.globl _AGCCTRLH
                            231 	.globl _MANORL
                            232 	.globl _MANORH
                            233 	.globl _MANANDL
                            234 	.globl _MANANDH
                            235 	.globl _FSMTCL
                            236 	.globl _FSMTCH
                            237 	.globl _RFPWR
                            238 	.globl _CSPT
                            239 	.globl _CSPCTRL
                            240 	.globl _CSPZ
                            241 	.globl _CSPY
                            242 	.globl _CSPX
                            243 	.globl _FSCTRLL
                            244 	.globl _FSCTRLH
                            245 	.globl _RXCTRL1L
                            246 	.globl _RXCTRL1H
                            247 	.globl _RXCTRL0L
                            248 	.globl _RXCTRL0H
                            249 	.globl _TXCTRLL
                            250 	.globl _TXCTRLH
                            251 	.globl _SYNCWORDL
                            252 	.globl _SYNCWORDH
                            253 	.globl _RSSIL
                            254 	.globl _RSSIH
                            255 	.globl _MDMCTRL1L
                            256 	.globl _MDMCTRL1H
                            257 	.globl _MDMCTRL0L
                            258 	.globl _MDMCTRL0H
                            259 	.globl _evtTimerInit
                            260 	.globl _evtTimerAlloc
                            261 	.globl _evtTimerFree
                            262 	.globl _evtTimerStart
                            263 	.globl _evtTimerStop
                            264 	.globl _evtTimerCheck
                            265 	.globl _vApplicationTickHook
                            266 ;--------------------------------------------------------
                            267 ; special function registers
                            268 ;--------------------------------------------------------
                            269 	.area RSEG    (DATA)
                    0080    270 _P0	=	0x0080
                    0081    271 _SP	=	0x0081
                    0082    272 _DPL0	=	0x0082
                    0083    273 _DPH0	=	0x0083
                    0084    274 _DPL1	=	0x0084
                    0085    275 _DPH1	=	0x0085
                    0086    276 _U0CSR	=	0x0086
                    0087    277 _PCON	=	0x0087
                    0088    278 _TCON	=	0x0088
                    0089    279 _P0IFG	=	0x0089
                    008A    280 _P1IFG	=	0x008a
                    008B    281 _P2IFG	=	0x008b
                    008C    282 _PICTL	=	0x008c
                    008D    283 _P1IEN	=	0x008d
                    008F    284 _P0INP	=	0x008f
                    0090    285 _P1	=	0x0090
                    0091    286 _RFIM	=	0x0091
                    0092    287 _DPS	=	0x0092
                    0093    288 __XPAGE	=	0x0093
                    0094    289 _T2CMP	=	0x0094
                    0095    290 _ST0	=	0x0095
                    0096    291 _ST1	=	0x0096
                    0097    292 _ST2	=	0x0097
                    0098    293 _S0CON	=	0x0098
                    0099    294 _HSRC	=	0x0099
                    009A    295 _IEN2	=	0x009a
                    009B    296 _S1CON	=	0x009b
                    009C    297 _T2PEROF0	=	0x009c
                    009D    298 _T2PEROF1	=	0x009d
                    009E    299 _T2PEROF2	=	0x009e
                    00A0    300 _P2	=	0x00a0
                    00A1    301 _T2OF0	=	0x00a1
                    00A2    302 _T2OF1	=	0x00a2
                    00A3    303 _T2OF2	=	0x00a3
                    00A4    304 _T2CAPLPL	=	0x00a4
                    00A5    305 _T2CAPHPH	=	0x00a5
                    00A6    306 _T2TLD	=	0x00a6
                    00A7    307 _T2THD	=	0x00a7
                    00A8    308 _IE	=	0x00a8
                    00A8    309 _IEN0	=	0x00a8
                    00A9    310 _IP0	=	0x00a9
                    00AB    311 _FWT	=	0x00ab
                    00AC    312 _FADDRL	=	0x00ac
                    00AD    313 _FADDRH	=	0x00ad
                    00AE    314 _FCTL	=	0x00ae
                    00AF    315 _FWDATA	=	0x00af
                    00B1    316 _ENCDI	=	0x00b1
                    00B2    317 _ENCDO	=	0x00b2
                    00B3    318 _ENCCS	=	0x00b3
                    00B4    319 _ADCCON1	=	0x00b4
                    00B5    320 _ADCCON2	=	0x00b5
                    00B6    321 _ADCCON3	=	0x00b6
                    00B7    322 _RCCTL	=	0x00b7
                    00B8    323 _IEN1	=	0x00b8
                    00B9    324 _IP1	=	0x00b9
                    00BA    325 _ADCL	=	0x00ba
                    00BB    326 _ADCH	=	0x00bb
                    00BC    327 _RNDL	=	0x00bc
                    00BD    328 _RNDH	=	0x00bd
                    00BE    329 _SLEEP	=	0x00be
                    00C0    330 _IRCON	=	0x00c0
                    00C1    331 _U0BUF	=	0x00c1
                    00C2    332 _U0BAUD	=	0x00c2
                    00C3    333 _T2CNF	=	0x00c3
                    00C4    334 _U0UCR	=	0x00c4
                    00C5    335 _U0GCR	=	0x00c5
                    00C6    336 _CLKCON	=	0x00c6
                    00C7    337 _MEMCTR	=	0x00c7
                    00C8    338 _T2CON	=	0x00c8
                    00C9    339 _WDCTL	=	0x00c9
                    00CA    340 _T3CNT	=	0x00ca
                    00CB    341 _T3CTL	=	0x00cb
                    00CC    342 _T3CCTL0	=	0x00cc
                    00CD    343 _T3CC0	=	0x00cd
                    00CE    344 _T3CCTL1	=	0x00ce
                    00CF    345 _T3CC1	=	0x00cf
                    00D0    346 _PSW	=	0x00d0
                    00D1    347 _DMAIRQ	=	0x00d1
                    00D2    348 _DMA1CFGL	=	0x00d2
                    00D3    349 _DMA1CFGH	=	0x00d3
                    00D4    350 _DMA0CFGL	=	0x00d4
                    00D5    351 _DMA0CFGH	=	0x00d5
                    00D6    352 _DMAARM	=	0x00d6
                    00D7    353 _DMAREQ	=	0x00d7
                    00D8    354 _TIMIF	=	0x00d8
                    00D9    355 _RFD	=	0x00d9
                    00DA    356 _T1CC0L	=	0x00da
                    00DB    357 _T1CC0H	=	0x00db
                    00DC    358 _T1CC1L	=	0x00dc
                    00DD    359 _T1CC1H	=	0x00dd
                    00DE    360 _T1CC2L	=	0x00de
                    00DF    361 _T1CC2H	=	0x00df
                    00E0    362 _ACC	=	0x00e0
                    00E1    363 _RFST	=	0x00e1
                    00E2    364 _T1CNTL	=	0x00e2
                    00E3    365 _T1CNTH	=	0x00e3
                    00E4    366 _T1CTL	=	0x00e4
                    00E5    367 _T1CCTL0	=	0x00e5
                    00E6    368 _T1CCTL1	=	0x00e6
                    00E7    369 _T1CCTL2	=	0x00e7
                    00E8    370 _IRCON2	=	0x00e8
                    00E9    371 _RFIF	=	0x00e9
                    00EA    372 _T4CNT	=	0x00ea
                    00EB    373 _T4CTL	=	0x00eb
                    00EC    374 _T4CCTL0	=	0x00ec
                    00ED    375 _T4CC0	=	0x00ed
                    00EE    376 _T4CCTL1	=	0x00ee
                    00EF    377 _T4CC1	=	0x00ef
                    00F0    378 _B	=	0x00f0
                    00F1    379 _PERCFG	=	0x00f1
                    00F2    380 _ADCCFG	=	0x00f2
                    00F3    381 _P0SEL	=	0x00f3
                    00F4    382 _P1SEL	=	0x00f4
                    00F5    383 _P2SEL	=	0x00f5
                    00F6    384 _P1INP	=	0x00f6
                    00F7    385 _P2INP	=	0x00f7
                    00F8    386 _U1CSR	=	0x00f8
                    00F9    387 _U1BUF	=	0x00f9
                    00FA    388 _U1BAUD	=	0x00fa
                    00FB    389 _U1UCR	=	0x00fb
                    00FC    390 _U1GCR	=	0x00fc
                    00FD    391 _P0DIR	=	0x00fd
                    00FE    392 _P1DIR	=	0x00fe
                    00FF    393 _P2DIR	=	0x00ff
                            394 ;--------------------------------------------------------
                            395 ; special function bits
                            396 ;--------------------------------------------------------
                            397 	.area RSEG    (DATA)
                    0087    398 _P0_7	=	0x0087
                    0086    399 _P0_6	=	0x0086
                    0085    400 _P0_5	=	0x0085
                    0084    401 _P0_4	=	0x0084
                    0083    402 _P0_3	=	0x0083
                    0082    403 _P0_2	=	0x0082
                    0081    404 _P0_1	=	0x0081
                    0080    405 _P0_0	=	0x0080
                    008F    406 _TCON_URX1IF	=	0x008f
                    008D    407 _TCON_ADCIF	=	0x008d
                    008B    408 _TCON_URX0IF	=	0x008b
                    008A    409 _TCON_IT1	=	0x008a
                    0089    410 _TCON_RFERRIF	=	0x0089
                    0088    411 _TCON_IT0	=	0x0088
                    0090    412 _P1_0	=	0x0090
                    0091    413 _P1_1	=	0x0091
                    0092    414 _P1_2	=	0x0092
                    0093    415 _P1_3	=	0x0093
                    0094    416 _P1_4	=	0x0094
                    0095    417 _P1_5	=	0x0095
                    0096    418 _P1_6	=	0x0096
                    0097    419 _P1_7	=	0x0097
                    0099    420 _S0CON_ENCIF_1	=	0x0099
                    0098    421 _S0CON_ENCIF_0	=	0x0098
                    00A0    422 _P2_0	=	0x00a0
                    00A1    423 _P2_1	=	0x00a1
                    00A2    424 _P2_2	=	0x00a2
                    00A3    425 _P2_3	=	0x00a3
                    00A4    426 _P2_4	=	0x00a4
                    00AF    427 _EA	=	0x00af
                    00AF    428 _IEN0_EA	=	0x00af
                    00AD    429 _IEN0_STIE	=	0x00ad
                    00AC    430 _IEN0_ENCIE	=	0x00ac
                    00AB    431 _IEN0_URX1IE	=	0x00ab
                    00AA    432 _IEN0_URX0IE	=	0x00aa
                    00A9    433 _IEN0_ADCIE	=	0x00a9
                    00A8    434 _IEN0_RFERRIE	=	0x00a8
                    00BD    435 _IEN1_P0IE	=	0x00bd
                    00BC    436 _IEN1_T4IE	=	0x00bc
                    00BB    437 _IEN1_T3IE	=	0x00bb
                    00BA    438 _IEN1_T2IE	=	0x00ba
                    00B9    439 _IEN1_T1IE	=	0x00b9
                    00B8    440 _IEN1_DMAIE	=	0x00b8
                    00C7    441 _IRCON_STIF	=	0x00c7
                    00C5    442 _IRCON_P0IF	=	0x00c5
                    00C4    443 _IRCON_T4IF	=	0x00c4
                    00C3    444 _IRCON_T3IF	=	0x00c3
                    00C2    445 _IRCON_T2IF	=	0x00c2
                    00C1    446 _IRCON_T1IF	=	0x00c1
                    00C0    447 _IRCON_DMAIF	=	0x00c0
                    00D0    448 _P	=	0x00d0
                    00D1    449 _F1	=	0x00d1
                    00D2    450 _OV	=	0x00d2
                    00D3    451 _RS0	=	0x00d3
                    00D4    452 _RS1	=	0x00d4
                    00D5    453 _F0	=	0x00d5
                    00D6    454 _AC	=	0x00d6
                    00D7    455 _CY	=	0x00d7
                    00EC    456 _IRCON2_WDTIF	=	0x00ec
                    00EB    457 _IRCON2_P1IF	=	0x00eb
                    00EA    458 _IRCON2_UTX1IF	=	0x00ea
                    00E9    459 _IRCON2_UTX0IF	=	0x00e9
                    00E8    460 _IRCON2_P2IF	=	0x00e8
                            461 ;--------------------------------------------------------
                            462 ; overlayable register banks
                            463 ;--------------------------------------------------------
                            464 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     465 	.ds 8
                            466 ;--------------------------------------------------------
                            467 ; internal ram data
                            468 ;--------------------------------------------------------
                            469 	.area DSEG    (DATA)
                            470 ;--------------------------------------------------------
                            471 ; overlayable items in internal ram 
                            472 ;--------------------------------------------------------
                            473 	.area OSEG    (OVR,DATA)
                            474 ;--------------------------------------------------------
                            475 ; indirectly addressable internal ram data
                            476 ;--------------------------------------------------------
                            477 	.area ISEG    (DATA)
                            478 ;--------------------------------------------------------
                            479 ; bit data
                            480 ;--------------------------------------------------------
                            481 	.area BSEG    (BIT)
                            482 ;--------------------------------------------------------
                            483 ; paged external ram data
                            484 ;--------------------------------------------------------
                            485 	.area PSEG    (PAG,XDATA)
                            486 ;--------------------------------------------------------
                            487 ; external ram data
                            488 ;--------------------------------------------------------
                            489 	.area XSEG    (XDATA)
                    DF02    490 _MDMCTRL0H	=	0xdf02
                    DF03    491 _MDMCTRL0L	=	0xdf03
                    DF04    492 _MDMCTRL1H	=	0xdf04
                    DF05    493 _MDMCTRL1L	=	0xdf05
                    DF06    494 _RSSIH	=	0xdf06
                    DF07    495 _RSSIL	=	0xdf07
                    DF08    496 _SYNCWORDH	=	0xdf08
                    DF09    497 _SYNCWORDL	=	0xdf09
                    DF0A    498 _TXCTRLH	=	0xdf0a
                    DF0B    499 _TXCTRLL	=	0xdf0b
                    DF0C    500 _RXCTRL0H	=	0xdf0c
                    DF0D    501 _RXCTRL0L	=	0xdf0d
                    DF0E    502 _RXCTRL1H	=	0xdf0e
                    DF0F    503 _RXCTRL1L	=	0xdf0f
                    DF10    504 _FSCTRLH	=	0xdf10
                    DF11    505 _FSCTRLL	=	0xdf11
                    DF12    506 _CSPX	=	0xdf12
                    DF13    507 _CSPY	=	0xdf13
                    DF14    508 _CSPZ	=	0xdf14
                    DF15    509 _CSPCTRL	=	0xdf15
                    DF16    510 _CSPT	=	0xdf16
                    DF17    511 _RFPWR	=	0xdf17
                    DF20    512 _FSMTCH	=	0xdf20
                    DF21    513 _FSMTCL	=	0xdf21
                    DF22    514 _MANANDH	=	0xdf22
                    DF23    515 _MANANDL	=	0xdf23
                    DF24    516 _MANORH	=	0xdf24
                    DF25    517 _MANORL	=	0xdf25
                    DF26    518 _AGCCTRLH	=	0xdf26
                    DF27    519 _AGCCTRLL	=	0xdf27
                    DF39    520 _FSMSTATE	=	0xdf39
                    DF3A    521 _ADCTSTH	=	0xdf3a
                    DF3B    522 _ADCTSTL	=	0xdf3b
                    DF3C    523 _DACTSTH	=	0xdf3c
                    DF3D    524 _DACTSTL	=	0xdf3d
                    DF43    525 _IEEE_ADDR0	=	0xdf43
                    DF44    526 _IEEE_ADDR1	=	0xdf44
                    DF45    527 _IEEE_ADDR2	=	0xdf45
                    DF46    528 _IEEE_ADDR3	=	0xdf46
                    DF47    529 _IEEE_ADDR4	=	0xdf47
                    DF48    530 _IEEE_ADDR5	=	0xdf48
                    DF49    531 _IEEE_ADDR6	=	0xdf49
                    DF4A    532 _IEEE_ADDR7	=	0xdf4a
                    DF4B    533 _PANIDH	=	0xdf4b
                    DF4C    534 _PANIDL	=	0xdf4c
                    DF4D    535 _SHORTADDRH	=	0xdf4d
                    DF4E    536 _SHORTADDRL	=	0xdf4e
                    DF4F    537 _IOCFG0	=	0xdf4f
                    DF50    538 _IOCFG1	=	0xdf50
                    DF51    539 _IOCFG2	=	0xdf51
                    DF52    540 _IOCFG3	=	0xdf52
                    DF53    541 _RXFIFOCNT	=	0xdf53
                    DF54    542 _FSMTC1	=	0xdf54
                    DF60    543 _CHVER	=	0xdf60
                    DF61    544 _CHIPID	=	0xdf61
                    DF62    545 _RFSTATUS	=	0xdf62
                    DFD9    546 _RFD_SHADOW	=	0xdfd9
   EEDD                     547 _evtTimers::
   EEDD                     548 	.ds 120
   EF55                     549 _evtTickCount::
   EF55                     550 	.ds 2
                            551 ;--------------------------------------------------------
                            552 ; external initialized ram data
                            553 ;--------------------------------------------------------
                            554 	.area XISEG   (XDATA)
   F0A5                     555 _evtInit::
   F0A5                     556 	.ds 1
                            557 	.area HOME    (CODE)
                            558 	.area GSINIT0 (CODE)
                            559 	.area GSINIT1 (CODE)
                            560 	.area GSINIT2 (CODE)
                            561 	.area GSINIT3 (CODE)
                            562 	.area GSINIT4 (CODE)
                            563 	.area GSINIT5 (CODE)
                            564 	.area GSINIT  (CODE)
                            565 	.area GSFINAL (CODE)
                            566 	.area CSEG    (CODE)
                            567 ;--------------------------------------------------------
                            568 ; global & static initialisations
                            569 ;--------------------------------------------------------
                            570 	.area HOME    (CODE)
                            571 	.area GSINIT  (CODE)
                            572 	.area GSFINAL (CODE)
                            573 	.area GSINIT  (CODE)
                            574 ;--------------------------------------------------------
                            575 ; Home
                            576 ;--------------------------------------------------------
                            577 	.area HOME    (CODE)
                            578 	.area CSEG    (CODE)
                            579 ;--------------------------------------------------------
                            580 ; code
                            581 ;--------------------------------------------------------
                            582 	.area CSEG    (CODE)
                            583 ;------------------------------------------------------------
                            584 ;Allocation info for local variables in function 'evtTimerInit'
                            585 ;------------------------------------------------------------
                            586 ;i                         Allocated to registers r2 
                            587 ;------------------------------------------------------------
                            588 ;	../../Common/event_timer.c:76: void evtTimerInit(void)
                            589 ;	-----------------------------------------
                            590 ;	 function evtTimerInit
                            591 ;	-----------------------------------------
   3FD5                     592 _evtTimerInit:
                    0002    593 	ar2 = 0x02
                    0003    594 	ar3 = 0x03
                    0004    595 	ar4 = 0x04
                    0005    596 	ar5 = 0x05
                    0006    597 	ar6 = 0x06
                    0007    598 	ar7 = 0x07
                    0000    599 	ar0 = 0x00
                    0001    600 	ar1 = 0x01
                            601 ;	../../Common/event_timer.c:78: if (evtInit == -1)
                            602 ;	genAssign
   3FD5 90 F0 A5            603 	mov	dptr,#_evtInit
   3FD8 E0                  604 	movx	a,@dptr
   3FD9 FA                  605 	mov	r2,a
                            606 ;	genCmpEq
                            607 ;	gencjneshort
                            608 ;	Peephole 112.b	changed ljmp to sjmp
                            609 ;	Peephole 198.b	optimized misc jump sequence
   3FDA BA FF 3E            610 	cjne	r2,#0xFF,00106$
                            611 ;	Peephole 200.b	removed redundant sjmp
                            612 ;	Peephole 300	removed redundant label 00111$
                            613 ;	Peephole 300	removed redundant label 00112$
                            614 ;	../../Common/event_timer.c:81: evtTickCount = 0;
                            615 ;	genAssign
   3FDD 90 EF 55            616 	mov	dptr,#_evtTickCount
   3FE0 E4                  617 	clr	a
   3FE1 F0                  618 	movx	@dptr,a
   3FE2 A3                  619 	inc	dptr
   3FE3 F0                  620 	movx	@dptr,a
                            621 ;	../../Common/event_timer.c:82: for (i=0; i<HAVE_EVENT_TIMERS ; i++)
                            622 ;	genAssign
   3FE4 7A 08               623 	mov	r2,#0x08
   3FE6                     624 00105$:
                            625 ;	../../Common/event_timer.c:84: evtTimers[i].evtQueue = 0;
                            626 ;	genMinus
                            627 ;	genMinusDec
   3FE6 EA                  628 	mov	a,r2
   3FE7 14                  629 	dec	a
                            630 ;	genMult
                            631 ;	genMultOneByte
   3FE8 FB                  632 	mov	r3,a
                            633 ;	Peephole 105	removed redundant mov
   3FE9 75 F0 0F            634 	mov	b,#0x0F
   3FEC A4                  635 	mul	ab
                            636 ;	genPlus
   3FED FC                  637 	mov	r4,a
                            638 ;	Peephole 177.b	removed redundant mov
   3FEE 24 DD               639 	add	a,#_evtTimers
   3FF0 F5 82               640 	mov	dpl,a
                            641 ;	Peephole 181	changed mov to clr
   3FF2 E4                  642 	clr	a
   3FF3 34 EE               643 	addc	a,#(_evtTimers >> 8)
   3FF5 F5 83               644 	mov	dph,a
                            645 ;	genPointerSet
                            646 ;     genFarPointerSet
                            647 ;	Peephole 181	changed mov to clr
                            648 ;	Peephole 101	removed redundant mov
                            649 ;	Peephole 181	changed mov to clr
   3FF7 E4                  650 	clr	a
   3FF8 F0                  651 	movx	@dptr,a
   3FF9 A3                  652 	inc	dptr
   3FFA F0                  653 	movx	@dptr,a
   3FFB A3                  654 	inc	dptr
                            655 ;	Peephole 226.b	removed unnecessary clr
   3FFC F0                  656 	movx	@dptr,a
                            657 ;	../../Common/event_timer.c:85: evtTimers[i].evtRunning = 0;
                            658 ;	genPlus
                            659 ;	Peephole 236.g	used r4 instead of ar4
   3FFD EC                  660 	mov	a,r4
   3FFE 24 DD               661 	add	a,#_evtTimers
   4000 FC                  662 	mov	r4,a
                            663 ;	Peephole 181	changed mov to clr
   4001 E4                  664 	clr	a
   4002 34 EE               665 	addc	a,#(_evtTimers >> 8)
   4004 FD                  666 	mov	r5,a
                            667 ;	genPlus
                            668 ;     genPlusIncr
   4005 74 06               669 	mov	a,#0x06
                            670 ;	Peephole 236.a	used r4 instead of ar4
   4007 2C                  671 	add	a,r4
   4008 F5 82               672 	mov	dpl,a
                            673 ;	Peephole 181	changed mov to clr
   400A E4                  674 	clr	a
                            675 ;	Peephole 236.b	used r5 instead of ar5
   400B 3D                  676 	addc	a,r5
   400C F5 83               677 	mov	dph,a
                            678 ;	genPointerSet
                            679 ;     genFarPointerSet
                            680 ;	Peephole 181	changed mov to clr
   400E E4                  681 	clr	a
   400F F0                  682 	movx	@dptr,a
                            683 ;	genAssign
                            684 ;	genAssign
   4010 8B 02               685 	mov	ar2,r3
                            686 ;	../../Common/event_timer.c:82: for (i=0; i<HAVE_EVENT_TIMERS ; i++)
                            687 ;	genIfx
   4012 EA                  688 	mov	a,r2
                            689 ;	genIfxJump
                            690 ;	Peephole 108.b	removed ljmp by inverse jump logic
   4013 70 D1               691 	jnz	00105$
                            692 ;	Peephole 300	removed redundant label 00113$
                            693 ;	../../Common/event_timer.c:87: evtInit = 1;
                            694 ;	genAssign
   4015 90 F0 A5            695 	mov	dptr,#_evtInit
   4018 74 01               696 	mov	a,#0x01
   401A F0                  697 	movx	@dptr,a
   401B                     698 00106$:
   401B 22                  699 	ret
                            700 ;------------------------------------------------------------
                            701 ;Allocation info for local variables in function 'evtTimerAlloc'
                            702 ;------------------------------------------------------------
                            703 ;size                      Allocated to stack - offset -3
                            704 ;queue                     Allocated to stack - offset 1
                            705 ;i                         Allocated to registers r5 
                            706 ;sloc0                     Allocated to stack - offset 4
                            707 ;------------------------------------------------------------
                            708 ;	../../Common/event_timer.c:101: portCHAR evtTimerAlloc(xQueueHandle queue, unsigned portCHAR size)
                            709 ;	-----------------------------------------
                            710 ;	 function evtTimerAlloc
                            711 ;	-----------------------------------------
   401C                     712 _evtTimerAlloc:
   401C C0 10               713 	push	_bp
   401E 85 81 10            714 	mov	_bp,sp
                            715 ;     genReceive
   4021 C0 82               716 	push	dpl
   4023 C0 83               717 	push	dph
   4025 C0 F0               718 	push	b
   4027 05 81               719 	inc	sp
   4029 05 81               720 	inc	sp
                            721 ;	../../Common/event_timer.c:105: if (evtInit == -1)
                            722 ;	genAssign
   402B 90 F0 A5            723 	mov	dptr,#_evtInit
   402E E0                  724 	movx	a,@dptr
   402F FD                  725 	mov	r5,a
                            726 ;	genCmpEq
                            727 ;	gencjneshort
                            728 ;	Peephole 112.b	changed ljmp to sjmp
                            729 ;	Peephole 198.b	optimized misc jump sequence
   4030 BD FF 03            730 	cjne	r5,#0xFF,00102$
                            731 ;	Peephole 200.b	removed redundant sjmp
                            732 ;	Peephole 300	removed redundant label 00115$
                            733 ;	Peephole 300	removed redundant label 00116$
                            734 ;	../../Common/event_timer.c:107: evtTimerInit();
                            735 ;	genCall
   4033 12 3F D5            736 	lcall	_evtTimerInit
   4036                     737 00102$:
                            738 ;	../../Common/event_timer.c:109: for (i=0; i<HAVE_EVENT_TIMERS ; i++)
                            739 ;	genAssign
   4036 7D 00               740 	mov	r5,#0x00
                            741 ;	genAssign
   4038 7E 00               742 	mov	r6,#0x00
   403A                     743 00105$:
                            744 ;	genCmpLt
                            745 ;	genCmp
   403A BE 08 00            746 	cjne	r6,#0x08,00117$
   403D                     747 00117$:
                            748 ;	genIfxJump
                            749 ;	Peephole 112.b	changed ljmp to sjmp
                            750 ;	Peephole 160.b	removed sjmp by inverse jump logic
   403D 50 6E               751 	jnc	00108$
                            752 ;	Peephole 300	removed redundant label 00118$
                            753 ;	../../Common/event_timer.c:111: if (evtTimers[i].evtQueue == 0)
                            754 ;	genMult
                            755 ;	genMultOneByte
   403F EE                  756 	mov	a,r6
   4040 75 F0 0F            757 	mov	b,#0x0F
   4043 A4                  758 	mul	ab
   4044 FF                  759 	mov	r7,a
                            760 ;	genPlus
   4045 E5 10               761 	mov	a,_bp
   4047 24 04               762 	add	a,#0x04
   4049 F8                  763 	mov	r0,a
                            764 ;	Peephole 236.g	used r7 instead of ar7
   404A EF                  765 	mov	a,r7
   404B 24 DD               766 	add	a,#_evtTimers
   404D F6                  767 	mov	@r0,a
                            768 ;	Peephole 181	changed mov to clr
   404E E4                  769 	clr	a
   404F 34 EE               770 	addc	a,#(_evtTimers >> 8)
   4051 08                  771 	inc	r0
   4052 F6                  772 	mov	@r0,a
                            773 ;	genPointerGet
                            774 ;	genFarPointerGet
   4053 E5 10               775 	mov	a,_bp
   4055 24 04               776 	add	a,#0x04
   4057 F8                  777 	mov	r0,a
   4058 86 82               778 	mov	dpl,@r0
   405A 08                  779 	inc	r0
   405B 86 83               780 	mov	dph,@r0
   405D E0                  781 	movx	a,@dptr
   405E FA                  782 	mov	r2,a
   405F A3                  783 	inc	dptr
   4060 E0                  784 	movx	a,@dptr
   4061 FB                  785 	mov	r3,a
   4062 A3                  786 	inc	dptr
   4063 E0                  787 	movx	a,@dptr
   4064 FC                  788 	mov	r4,a
                            789 ;	genIfx
   4065 EA                  790 	mov	a,r2
   4066 4B                  791 	orl	a,r3
   4067 4C                  792 	orl	a,r4
                            793 ;	genIfxJump
                            794 ;	Peephole 108.b	removed ljmp by inverse jump logic
   4068 70 3E               795 	jnz	00107$
                            796 ;	Peephole 300	removed redundant label 00119$
                            797 ;	../../Common/event_timer.c:113: evtTimers[i].evtQueue = queue;
                            798 ;	genPointerSet
                            799 ;     genFarPointerSet
   406A E5 10               800 	mov	a,_bp
   406C 24 04               801 	add	a,#0x04
   406E F8                  802 	mov	r0,a
   406F 86 82               803 	mov	dpl,@r0
   4071 08                  804 	inc	r0
   4072 86 83               805 	mov	dph,@r0
   4074 A9 10               806 	mov	r1,_bp
   4076 09                  807 	inc	r1
   4077 E7                  808 	mov	a,@r1
   4078 F0                  809 	movx	@dptr,a
   4079 A3                  810 	inc	dptr
   407A 09                  811 	inc	r1
   407B E7                  812 	mov	a,@r1
   407C F0                  813 	movx	@dptr,a
   407D A3                  814 	inc	dptr
   407E 09                  815 	inc	r1
   407F E7                  816 	mov	a,@r1
   4080 F0                  817 	movx	@dptr,a
                            818 ;	../../Common/event_timer.c:114: evtTimers[i].evtRunning = 0;
                            819 ;	genPlus
                            820 ;	Peephole 236.g	used r7 instead of ar7
   4081 EF                  821 	mov	a,r7
   4082 24 DD               822 	add	a,#_evtTimers
   4084 FF                  823 	mov	r7,a
                            824 ;	Peephole 181	changed mov to clr
   4085 E4                  825 	clr	a
   4086 34 EE               826 	addc	a,#(_evtTimers >> 8)
   4088 FA                  827 	mov	r2,a
                            828 ;	genPlus
                            829 ;     genPlusIncr
   4089 74 06               830 	mov	a,#0x06
                            831 ;	Peephole 236.a	used r7 instead of ar7
   408B 2F                  832 	add	a,r7
   408C F5 82               833 	mov	dpl,a
                            834 ;	Peephole 181	changed mov to clr
   408E E4                  835 	clr	a
                            836 ;	Peephole 236.b	used r2 instead of ar2
   408F 3A                  837 	addc	a,r2
   4090 F5 83               838 	mov	dph,a
                            839 ;	genPointerSet
                            840 ;     genFarPointerSet
                            841 ;	Peephole 181	changed mov to clr
   4092 E4                  842 	clr	a
   4093 F0                  843 	movx	@dptr,a
                            844 ;	../../Common/event_timer.c:115: evtTimers[i].evtSize = size;
                            845 ;	genPlus
                            846 ;     genPlusIncr
   4094 8F 82               847 	mov	dpl,r7
   4096 8A 83               848 	mov	dph,r2
   4098 A3                  849 	inc	dptr
   4099 A3                  850 	inc	dptr
   409A A3                  851 	inc	dptr
   409B A3                  852 	inc	dptr
   409C A3                  853 	inc	dptr
                            854 ;	genPointerSet
                            855 ;     genFarPointerSet
   409D A8 10               856 	mov	r0,_bp
   409F 18                  857 	dec	r0
   40A0 18                  858 	dec	r0
   40A1 18                  859 	dec	r0
   40A2 E6                  860 	mov	a,@r0
   40A3 F0                  861 	movx	@dptr,a
                            862 ;	../../Common/event_timer.c:116: return i;
                            863 ;	genRet
   40A4 8D 82               864 	mov	dpl,r5
                            865 ;	Peephole 112.b	changed ljmp to sjmp
   40A6 80 08               866 	sjmp	00109$
   40A8                     867 00107$:
                            868 ;	../../Common/event_timer.c:109: for (i=0; i<HAVE_EVENT_TIMERS ; i++)
                            869 ;	genPlus
                            870 ;     genPlusIncr
   40A8 0E                  871 	inc	r6
                            872 ;	genAssign
   40A9 8E 05               873 	mov	ar5,r6
                            874 ;	Peephole 112.b	changed ljmp to sjmp
   40AB 80 8D               875 	sjmp	00105$
   40AD                     876 00108$:
                            877 ;	../../Common/event_timer.c:119: return -1;
                            878 ;	genRet
   40AD 75 82 FF            879 	mov	dpl,#0xFF
   40B0                     880 00109$:
   40B0 85 10 81            881 	mov	sp,_bp
   40B3 D0 10               882 	pop	_bp
   40B5 22                  883 	ret
                            884 ;------------------------------------------------------------
                            885 ;Allocation info for local variables in function 'evtTimerFree'
                            886 ;------------------------------------------------------------
                            887 ;timer                     Allocated to registers r2 
                            888 ;------------------------------------------------------------
                            889 ;	../../Common/event_timer.c:130: void evtTimerFree(unsigned portCHAR timer)
                            890 ;	-----------------------------------------
                            891 ;	 function evtTimerFree
                            892 ;	-----------------------------------------
   40B6                     893 _evtTimerFree:
                            894 ;	genReceive
   40B6 AA 82               895 	mov	r2,dpl
                            896 ;	../../Common/event_timer.c:132: if (timer < HAVE_EVENT_TIMERS)
                            897 ;	genCmpLt
                            898 ;	genCmp
   40B8 BA 08 00            899 	cjne	r2,#0x08,00106$
   40BB                     900 00106$:
                            901 ;	genIfxJump
                            902 ;	Peephole 108.a	removed ljmp by inverse jump logic
   40BB 50 28               903 	jnc	00103$
                            904 ;	Peephole 300	removed redundant label 00107$
                            905 ;	../../Common/event_timer.c:134: evtTimers[timer].evtQueue = 0;
                            906 ;	genMult
                            907 ;	genMultOneByte
   40BD EA                  908 	mov	a,r2
   40BE 75 F0 0F            909 	mov	b,#0x0F
   40C1 A4                  910 	mul	ab
                            911 ;	genPlus
   40C2 FA                  912 	mov	r2,a
                            913 ;	Peephole 177.b	removed redundant mov
   40C3 24 DD               914 	add	a,#_evtTimers
   40C5 F5 82               915 	mov	dpl,a
                            916 ;	Peephole 181	changed mov to clr
   40C7 E4                  917 	clr	a
   40C8 34 EE               918 	addc	a,#(_evtTimers >> 8)
   40CA F5 83               919 	mov	dph,a
                            920 ;	genPointerSet
                            921 ;     genFarPointerSet
                            922 ;	Peephole 181	changed mov to clr
                            923 ;	Peephole 101	removed redundant mov
                            924 ;	Peephole 181	changed mov to clr
   40CC E4                  925 	clr	a
   40CD F0                  926 	movx	@dptr,a
   40CE A3                  927 	inc	dptr
   40CF F0                  928 	movx	@dptr,a
   40D0 A3                  929 	inc	dptr
                            930 ;	Peephole 226.b	removed unnecessary clr
   40D1 F0                  931 	movx	@dptr,a
                            932 ;	../../Common/event_timer.c:135: evtTimers[timer].evtRunning = 0;	
                            933 ;	genPlus
                            934 ;	Peephole 236.g	used r2 instead of ar2
   40D2 EA                  935 	mov	a,r2
   40D3 24 DD               936 	add	a,#_evtTimers
   40D5 FA                  937 	mov	r2,a
                            938 ;	Peephole 181	changed mov to clr
   40D6 E4                  939 	clr	a
   40D7 34 EE               940 	addc	a,#(_evtTimers >> 8)
   40D9 FB                  941 	mov	r3,a
                            942 ;	genPlus
                            943 ;     genPlusIncr
   40DA 74 06               944 	mov	a,#0x06
                            945 ;	Peephole 236.a	used r2 instead of ar2
   40DC 2A                  946 	add	a,r2
   40DD F5 82               947 	mov	dpl,a
                            948 ;	Peephole 181	changed mov to clr
   40DF E4                  949 	clr	a
                            950 ;	Peephole 236.b	used r3 instead of ar3
   40E0 3B                  951 	addc	a,r3
   40E1 F5 83               952 	mov	dph,a
                            953 ;	genPointerSet
                            954 ;     genFarPointerSet
                            955 ;	Peephole 181	changed mov to clr
   40E3 E4                  956 	clr	a
   40E4 F0                  957 	movx	@dptr,a
   40E5                     958 00103$:
   40E5 22                  959 	ret
                            960 ;------------------------------------------------------------
                            961 ;Allocation info for local variables in function 'evtTimerStart'
                            962 ;------------------------------------------------------------
                            963 ;tmr_data                  Allocated to stack - offset -5
                            964 ;ticks                     Allocated to stack - offset -7
                            965 ;timer                     Allocated to registers r2 
                            966 ;------------------------------------------------------------
                            967 ;	../../Common/event_timer.c:150: portCHAR evtTimerStart(unsigned portCHAR timer, unsigned portCHAR *tmr_data, portTickType ticks)
                            968 ;	-----------------------------------------
                            969 ;	 function evtTimerStart
                            970 ;	-----------------------------------------
   40E6                     971 _evtTimerStart:
   40E6 C0 10               972 	push	_bp
   40E8 85 81 10            973 	mov	_bp,sp
                            974 ;	genReceive
   40EB AA 82               975 	mov	r2,dpl
                            976 ;	../../Common/event_timer.c:152: if (timer < HAVE_EVENT_TIMERS) 
                            977 ;	genCmpLt
                            978 ;	genCmp
   40ED BA 08 00            979 	cjne	r2,#0x08,00106$
   40F0                     980 00106$:
                            981 ;	genIfxJump
   40F0 40 03               982 	jc	00107$
   40F2 02 41 92            983 	ljmp	00102$
   40F5                     984 00107$:
                            985 ;	../../Common/event_timer.c:154: portENTER_CRITICAL();
                            986 ;	genInline
   40F5 C0 E0 C0 A8         987 	 push ACC push IE 
                            988 ;	genAssign
   40F9 C2 AF               989 	clr	_EA
                            990 ;	../../Common/event_timer.c:155: memcpy(evtTimers[timer].evtData, tmr_data, evtTimers[timer].evtSize);
                            991 ;	genMult
                            992 ;	genMultOneByte
   40FB EA                  993 	mov	a,r2
   40FC 75 F0 0F            994 	mov	b,#0x0F
   40FF A4                  995 	mul	ab
                            996 ;	genPlus
   4100 FA                  997 	mov	r2,a
                            998 ;	Peephole 177.b	removed redundant mov
   4101 24 DD               999 	add	a,#_evtTimers
   4103 FB                 1000 	mov	r3,a
                           1001 ;	Peephole 181	changed mov to clr
   4104 E4                 1002 	clr	a
   4105 34 EE              1003 	addc	a,#(_evtTimers >> 8)
   4107 FC                 1004 	mov	r4,a
                           1005 ;	genPlus
                           1006 ;     genPlusIncr
   4108 8B 82              1007 	mov	dpl,r3
   410A 8C 83              1008 	mov	dph,r4
   410C A3                 1009 	inc	dptr
   410D A3                 1010 	inc	dptr
   410E A3                 1011 	inc	dptr
   410F A3                 1012 	inc	dptr
   4110 A3                 1013 	inc	dptr
                           1014 ;	genPointerGet
                           1015 ;	genFarPointerGet
   4111 E0                 1016 	movx	a,@dptr
   4112 FD                 1017 	mov	r5,a
                           1018 ;	genCast
   4113 7E 00              1019 	mov	r6,#0x00
                           1020 ;	genPlus
                           1021 ;     genPlusIncr
   4115 74 07              1022 	mov	a,#0x07
                           1023 ;	Peephole 236.a	used r3 instead of ar3
   4117 2B                 1024 	add	a,r3
   4118 FB                 1025 	mov	r3,a
                           1026 ;	Peephole 181	changed mov to clr
   4119 E4                 1027 	clr	a
                           1028 ;	Peephole 236.b	used r4 instead of ar4
   411A 3C                 1029 	addc	a,r4
   411B FC                 1030 	mov	r4,a
                           1031 ;	genCast
   411C 7F 00              1032 	mov	r7,#0x0
                           1033 ;	genIpush
   411E C0 02              1034 	push	ar2
   4120 C0 05              1035 	push	ar5
   4122 C0 06              1036 	push	ar6
                           1037 ;	genIpush
   4124 E5 10              1038 	mov	a,_bp
   4126 24 FB              1039 	add	a,#0xfffffffb
   4128 F8                 1040 	mov	r0,a
   4129 E6                 1041 	mov	a,@r0
   412A C0 E0              1042 	push	acc
   412C 08                 1043 	inc	r0
   412D E6                 1044 	mov	a,@r0
   412E C0 E0              1045 	push	acc
   4130 08                 1046 	inc	r0
   4131 E6                 1047 	mov	a,@r0
   4132 C0 E0              1048 	push	acc
                           1049 ;	genCall
   4134 8B 82              1050 	mov	dpl,r3
   4136 8C 83              1051 	mov	dph,r4
   4138 8F F0              1052 	mov	b,r7
   413A 12 E2 C7           1053 	lcall	_memcpy
   413D E5 81              1054 	mov	a,sp
   413F 24 FB              1055 	add	a,#0xfb
   4141 F5 81              1056 	mov	sp,a
   4143 D0 02              1057 	pop	ar2
                           1058 ;	../../Common/event_timer.c:157: evtTimers[timer].evtTick = evtTickCount + ticks + 1;
                           1059 ;	genPlus
                           1060 ;	Peephole 236.g	used r2 instead of ar2
   4145 EA                 1061 	mov	a,r2
   4146 24 DD              1062 	add	a,#_evtTimers
   4148 FA                 1063 	mov	r2,a
                           1064 ;	Peephole 181	changed mov to clr
   4149 E4                 1065 	clr	a
   414A 34 EE              1066 	addc	a,#(_evtTimers >> 8)
   414C FB                 1067 	mov	r3,a
                           1068 ;	genPlus
                           1069 ;     genPlusIncr
   414D 74 03              1070 	mov	a,#0x03
                           1071 ;	Peephole 236.a	used r2 instead of ar2
   414F 2A                 1072 	add	a,r2
   4150 FC                 1073 	mov	r4,a
                           1074 ;	Peephole 181	changed mov to clr
   4151 E4                 1075 	clr	a
                           1076 ;	Peephole 236.b	used r3 instead of ar3
   4152 3B                 1077 	addc	a,r3
   4153 FD                 1078 	mov	r5,a
                           1079 ;	genAssign
   4154 90 EF 55           1080 	mov	dptr,#_evtTickCount
   4157 E0                 1081 	movx	a,@dptr
   4158 FE                 1082 	mov	r6,a
   4159 A3                 1083 	inc	dptr
   415A E0                 1084 	movx	a,@dptr
   415B FF                 1085 	mov	r7,a
                           1086 ;	genPlus
   415C E5 10              1087 	mov	a,_bp
   415E 24 F9              1088 	add	a,#0xfffffff9
   4160 F8                 1089 	mov	r0,a
   4161 E6                 1090 	mov	a,@r0
                           1091 ;	Peephole 236.a	used r6 instead of ar6
   4162 2E                 1092 	add	a,r6
   4163 FE                 1093 	mov	r6,a
   4164 08                 1094 	inc	r0
   4165 E6                 1095 	mov	a,@r0
                           1096 ;	Peephole 236.b	used r7 instead of ar7
   4166 3F                 1097 	addc	a,r7
   4167 FF                 1098 	mov	r7,a
                           1099 ;	genPlus
                           1100 ;     genPlusIncr
   4168 0E                 1101 	inc	r6
   4169 BE 00 01           1102 	cjne	r6,#0x00,00108$
   416C 0F                 1103 	inc	r7
   416D                    1104 00108$:
                           1105 ;	genPointerSet
                           1106 ;     genFarPointerSet
   416D 8C 82              1107 	mov	dpl,r4
   416F 8D 83              1108 	mov	dph,r5
   4171 EE                 1109 	mov	a,r6
   4172 F0                 1110 	movx	@dptr,a
   4173 A3                 1111 	inc	dptr
   4174 EF                 1112 	mov	a,r7
   4175 F0                 1113 	movx	@dptr,a
                           1114 ;	../../Common/event_timer.c:158: evtTimers[timer].evtRunning = 1;	
                           1115 ;	genPlus
                           1116 ;     genPlusIncr
   4176 74 06              1117 	mov	a,#0x06
                           1118 ;	Peephole 236.a	used r2 instead of ar2
   4178 2A                 1119 	add	a,r2
   4179 F5 82              1120 	mov	dpl,a
                           1121 ;	Peephole 181	changed mov to clr
   417B E4                 1122 	clr	a
                           1123 ;	Peephole 236.b	used r3 instead of ar3
   417C 3B                 1124 	addc	a,r3
   417D F5 83              1125 	mov	dph,a
                           1126 ;	genPointerSet
                           1127 ;     genFarPointerSet
   417F 74 01              1128 	mov	a,#0x01
   4181 F0                 1129 	movx	@dptr,a
                           1130 ;	../../Common/event_timer.c:160: portEXIT_CRITICAL();
                           1131 ;	genInline
   4182 D0 E0              1132 	 pop ACC 
                           1133 ;	genAnd
   4184 53 E0 80           1134 	anl	_ACC,#0x80
                           1135 ;	genOr
   4187 E5 E0              1136 	mov	a,_ACC
   4189 42 A8              1137 	orl	_IE,a
                           1138 ;	genInline
   418B D0 E0              1139 	 pop ACC 
                           1140 ;	../../Common/event_timer.c:161: return 1;
                           1141 ;	genRet
   418D 75 82 01           1142 	mov	dpl,#0x01
                           1143 ;	Peephole 112.b	changed ljmp to sjmp
   4190 80 03              1144 	sjmp	00103$
   4192                    1145 00102$:
                           1146 ;	../../Common/event_timer.c:163: return 0;
                           1147 ;	genRet
   4192 75 82 00           1148 	mov	dpl,#0x00
   4195                    1149 00103$:
   4195 D0 10              1150 	pop	_bp
   4197 22                 1151 	ret
                           1152 ;------------------------------------------------------------
                           1153 ;Allocation info for local variables in function 'evtTimerStop'
                           1154 ;------------------------------------------------------------
                           1155 ;timer                     Allocated to registers r2 
                           1156 ;------------------------------------------------------------
                           1157 ;	../../Common/event_timer.c:175: portCHAR evtTimerStop(unsigned portCHAR timer)
                           1158 ;	-----------------------------------------
                           1159 ;	 function evtTimerStop
                           1160 ;	-----------------------------------------
   4198                    1161 _evtTimerStop:
                           1162 ;	genReceive
   4198 AA 82              1163 	mov	r2,dpl
                           1164 ;	../../Common/event_timer.c:177: if (timer < HAVE_EVENT_TIMERS) 
                           1165 ;	genCmpLt
                           1166 ;	genCmp
   419A BA 08 00           1167 	cjne	r2,#0x08,00106$
   419D                    1168 00106$:
                           1169 ;	genIfxJump
                           1170 ;	Peephole 108.a	removed ljmp by inverse jump logic
   419D 50 1B              1171 	jnc	00102$
                           1172 ;	Peephole 300	removed redundant label 00107$
                           1173 ;	../../Common/event_timer.c:179: evtTimers[timer].evtRunning = 0;
                           1174 ;	genMult
                           1175 ;	genMultOneByte
   419F EA                 1176 	mov	a,r2
   41A0 75 F0 0F           1177 	mov	b,#0x0F
   41A3 A4                 1178 	mul	ab
                           1179 ;	genPlus
   41A4 24 DD              1180 	add	a,#_evtTimers
   41A6 FA                 1181 	mov	r2,a
                           1182 ;	Peephole 240	use clr instead of addc a,#0
   41A7 E4                 1183 	clr	a
   41A8 34 EE              1184 	addc	a,#(_evtTimers >> 8)
   41AA FB                 1185 	mov	r3,a
                           1186 ;	genPlus
                           1187 ;     genPlusIncr
   41AB 74 06              1188 	mov	a,#0x06
                           1189 ;	Peephole 236.a	used r2 instead of ar2
   41AD 2A                 1190 	add	a,r2
   41AE F5 82              1191 	mov	dpl,a
                           1192 ;	Peephole 181	changed mov to clr
   41B0 E4                 1193 	clr	a
                           1194 ;	Peephole 236.b	used r3 instead of ar3
   41B1 3B                 1195 	addc	a,r3
   41B2 F5 83              1196 	mov	dph,a
                           1197 ;	genPointerSet
                           1198 ;     genFarPointerSet
                           1199 ;	Peephole 181	changed mov to clr
   41B4 E4                 1200 	clr	a
   41B5 F0                 1201 	movx	@dptr,a
                           1202 ;	../../Common/event_timer.c:180: return 1;
                           1203 ;	genRet
   41B6 75 82 01           1204 	mov	dpl,#0x01
                           1205 ;	Peephole 112.b	changed ljmp to sjmp
                           1206 ;	../../Common/event_timer.c:182: return 0;
                           1207 ;	genRet
                           1208 ;	Peephole 237.a	removed sjmp to ret
   41B9 22                 1209 	ret
   41BA                    1210 00102$:
   41BA 75 82 00           1211 	mov	dpl,#0x00
                           1212 ;	Peephole 300	removed redundant label 00103$
   41BD 22                 1213 	ret
                           1214 ;------------------------------------------------------------
                           1215 ;Allocation info for local variables in function 'evtTimerCheck'
                           1216 ;------------------------------------------------------------
                           1217 ;timer                     Allocated to registers r2 
                           1218 ;------------------------------------------------------------
                           1219 ;	../../Common/event_timer.c:194: portCHAR evtTimerCheck(unsigned portCHAR timer)
                           1220 ;	-----------------------------------------
                           1221 ;	 function evtTimerCheck
                           1222 ;	-----------------------------------------
   41BE                    1223 _evtTimerCheck:
                           1224 ;	genReceive
   41BE AA 82              1225 	mov	r2,dpl
                           1226 ;	../../Common/event_timer.c:196: if (timer < HAVE_EVENT_TIMERS) 
                           1227 ;	genCmpLt
                           1228 ;	genCmp
   41C0 BA 08 00           1229 	cjne	r2,#0x08,00109$
   41C3                    1230 00109$:
                           1231 ;	genIfxJump
                           1232 ;	Peephole 108.a	removed ljmp by inverse jump logic
   41C3 50 1D              1233 	jnc	00104$
                           1234 ;	Peephole 300	removed redundant label 00110$
                           1235 ;	../../Common/event_timer.c:198: if (evtTimers[timer].evtRunning != 0)	return pdTRUE;
                           1236 ;	genMult
                           1237 ;	genMultOneByte
   41C5 EA                 1238 	mov	a,r2
   41C6 75 F0 0F           1239 	mov	b,#0x0F
   41C9 A4                 1240 	mul	ab
                           1241 ;	genPlus
   41CA 24 DD              1242 	add	a,#_evtTimers
   41CC FA                 1243 	mov	r2,a
                           1244 ;	Peephole 240	use clr instead of addc a,#0
   41CD E4                 1245 	clr	a
   41CE 34 EE              1246 	addc	a,#(_evtTimers >> 8)
   41D0 FB                 1247 	mov	r3,a
                           1248 ;	genPlus
                           1249 ;     genPlusIncr
   41D1 74 06              1250 	mov	a,#0x06
                           1251 ;	Peephole 236.a	used r2 instead of ar2
   41D3 2A                 1252 	add	a,r2
   41D4 F5 82              1253 	mov	dpl,a
                           1254 ;	Peephole 181	changed mov to clr
   41D6 E4                 1255 	clr	a
                           1256 ;	Peephole 236.b	used r3 instead of ar3
   41D7 3B                 1257 	addc	a,r3
   41D8 F5 83              1258 	mov	dph,a
                           1259 ;	genPointerGet
                           1260 ;	genFarPointerGet
   41DA E0                 1261 	movx	a,@dptr
                           1262 ;	genCmpEq
                           1263 ;	gencjneshort
                           1264 ;	Peephole 112.b	changed ljmp to sjmp
   41DB FA                 1265 	mov	r2,a
                           1266 ;	Peephole 115.b	jump optimization
   41DC 60 04              1267 	jz	00104$
                           1268 ;	Peephole 300	removed redundant label 00111$
                           1269 ;	genRet
   41DE 75 82 01           1270 	mov	dpl,#0x01
                           1271 ;	Peephole 112.b	changed ljmp to sjmp
                           1272 ;	../../Common/event_timer.c:200: return pdFALSE;
                           1273 ;	genRet
                           1274 ;	Peephole 237.a	removed sjmp to ret
   41E1 22                 1275 	ret
   41E2                    1276 00104$:
   41E2 75 82 00           1277 	mov	dpl,#0x00
                           1278 ;	Peephole 300	removed redundant label 00105$
   41E5 22                 1279 	ret
                           1280 ;------------------------------------------------------------
                           1281 ;Allocation info for local variables in function 'vApplicationTickHook'
                           1282 ;------------------------------------------------------------
                           1283 ;i                         Allocated to stack - offset 1
                           1284 ;prev_task                 Allocated to stack - offset 4
                           1285 ;sloc0                     Allocated to stack - offset 2
                           1286 ;sloc1                     Allocated to stack - offset 4
                           1287 ;sloc2                     Allocated to stack - offset 5
                           1288 ;------------------------------------------------------------
                           1289 ;	../../Common/event_timer.c:211: void vApplicationTickHook(void)
                           1290 ;	-----------------------------------------
                           1291 ;	 function vApplicationTickHook
                           1292 ;	-----------------------------------------
   41E6                    1293 _vApplicationTickHook:
   41E6 C0 10              1294 	push	_bp
                           1295 ;	peephole 177.h	optimized mov sequence
   41E8 E5 81              1296 	mov	a,sp
   41EA F5 10              1297 	mov	_bp,a
   41EC 24 07              1298 	add	a,#0x07
   41EE F5 81              1299 	mov	sp,a
                           1300 ;	../../Common/event_timer.c:214: portBASE_TYPE prev_task = pdFALSE;
                           1301 ;	genAssign
   41F0 E5 10              1302 	mov	a,_bp
   41F2 24 04              1303 	add	a,#0x04
   41F4 F8                 1304 	mov	r0,a
   41F5 76 00              1305 	mov	@r0,#0x00
                           1306 ;	../../Common/event_timer.c:216: if (evtInit == -1)
                           1307 ;	genAssign
   41F7 90 F0 A5           1308 	mov	dptr,#_evtInit
   41FA E0                 1309 	movx	a,@dptr
   41FB FB                 1310 	mov	r3,a
                           1311 ;	genCmpEq
                           1312 ;	gencjneshort
                           1313 ;	Peephole 112.b	changed ljmp to sjmp
                           1314 ;	Peephole 198.b	optimized misc jump sequence
   41FC BB FF 03           1315 	cjne	r3,#0xFF,00102$
                           1316 ;	Peephole 200.b	removed redundant sjmp
                           1317 ;	Peephole 300	removed redundant label 00119$
                           1318 ;	Peephole 300	removed redundant label 00120$
                           1319 ;	../../Common/event_timer.c:218: evtTimerInit();
                           1320 ;	genCall
   41FF 12 3F D5           1321 	lcall	_evtTimerInit
   4202                    1322 00102$:
                           1323 ;	../../Common/event_timer.c:223: evtTickCount++;
                           1324 ;	genPlus
   4202 90 EF 55           1325 	mov	dptr,#_evtTickCount
   4205 E0                 1326 	movx	a,@dptr
   4206 24 01              1327 	add	a,#0x01
   4208 F0                 1328 	movx	@dptr,a
   4209 A3                 1329 	inc	dptr
   420A E0                 1330 	movx	a,@dptr
   420B 34 00              1331 	addc	a,#0x00
   420D F0                 1332 	movx	@dptr,a
                           1333 ;	../../Common/event_timer.c:225: for (i=0; i< HAVE_EVENT_TIMERS ; i++)
                           1334 ;	genAssign
   420E A8 10              1335 	mov	r0,_bp
   4210 08                 1336 	inc	r0
   4211 76 00              1337 	mov	@r0,#0x00
   4213                    1338 00107$:
                           1339 ;	genCmpLt
   4213 A8 10              1340 	mov	r0,_bp
   4215 08                 1341 	inc	r0
                           1342 ;	genCmp
   4216 B6 08 00           1343 	cjne	@r0,#0x08,00121$
   4219                    1344 00121$:
                           1345 ;	genIfxJump
   4219 40 03              1346 	jc	00122$
   421B 02 42 DA           1347 	ljmp	00111$
   421E                    1348 00122$:
                           1349 ;	../../Common/event_timer.c:227: if (evtTimers[i].evtRunning)
                           1350 ;	genIpush
                           1351 ;	genMult
   421E A8 10              1352 	mov	r0,_bp
   4220 08                 1353 	inc	r0
                           1354 ;	genMultOneByte
   4221 E6                 1355 	mov	a,@r0
   4222 75 F0 0F           1356 	mov	b,#0x0F
   4225 A4                 1357 	mul	ab
                           1358 ;	genPlus
   4226 FC                 1359 	mov	r4,a
                           1360 ;	Peephole 177.b	removed redundant mov
   4227 24 DD              1361 	add	a,#_evtTimers
   4229 FD                 1362 	mov	r5,a
                           1363 ;	Peephole 181	changed mov to clr
   422A E4                 1364 	clr	a
   422B 34 EE              1365 	addc	a,#(_evtTimers >> 8)
   422D FE                 1366 	mov	r6,a
                           1367 ;	genPlus
                           1368 ;     genPlusIncr
   422E 74 06              1369 	mov	a,#0x06
                           1370 ;	Peephole 236.a	used r5 instead of ar5
   4230 2D                 1371 	add	a,r5
   4231 FF                 1372 	mov	r7,a
                           1373 ;	Peephole 181	changed mov to clr
   4232 E4                 1374 	clr	a
                           1375 ;	Peephole 236.b	used r6 instead of ar6
   4233 3E                 1376 	addc	a,r6
   4234 FA                 1377 	mov	r2,a
                           1378 ;	genPointerGet
                           1379 ;	genFarPointerGet
   4235 8F 82              1380 	mov	dpl,r7
   4237 8A 83              1381 	mov	dph,r2
   4239 E0                 1382 	movx	a,@dptr
                           1383 ;	genIpop
                           1384 ;	genIfx
                           1385 ;	genIfxJump
   423A 70 03              1386 	jnz	00123$
   423C 02 42 D3           1387 	ljmp	00109$
   423F                    1388 00123$:
                           1389 ;	../../Common/event_timer.c:229: if (evtTimers[i].evtTick == evtTickCount)
                           1390 ;	genIpush
                           1391 ;	genPlus
                           1392 ;     genPlusIncr
   423F 8D 82              1393 	mov	dpl,r5
   4241 8E 83              1394 	mov	dph,r6
   4243 A3                 1395 	inc	dptr
   4244 A3                 1396 	inc	dptr
   4245 A3                 1397 	inc	dptr
                           1398 ;	genPointerGet
                           1399 ;	genFarPointerGet
   4246 A8 10              1400 	mov	r0,_bp
   4248 08                 1401 	inc	r0
   4249 08                 1402 	inc	r0
   424A E0                 1403 	movx	a,@dptr
   424B F6                 1404 	mov	@r0,a
   424C A3                 1405 	inc	dptr
   424D E0                 1406 	movx	a,@dptr
   424E 08                 1407 	inc	r0
   424F F6                 1408 	mov	@r0,a
                           1409 ;	genAssign
   4250 90 EF 55           1410 	mov	dptr,#_evtTickCount
   4253 E0                 1411 	movx	a,@dptr
   4254 FB                 1412 	mov	r3,a
   4255 A3                 1413 	inc	dptr
   4256 E0                 1414 	movx	a,@dptr
   4257 FA                 1415 	mov	r2,a
                           1416 ;	genCmpEq
   4258 A8 10              1417 	mov	r0,_bp
   425A 08                 1418 	inc	r0
   425B 08                 1419 	inc	r0
                           1420 ;	gencjne
                           1421 ;	gencjneshort
   425C E6                 1422 	mov	a,@r0
   425D B5 03 09           1423 	cjne	a,ar3,00124$
   4260 08                 1424 	inc	r0
   4261 E6                 1425 	mov	a,@r0
   4262 B5 02 04           1426 	cjne	a,ar2,00124$
   4265 74 01              1427 	mov	a,#0x01
   4267 80 01              1428 	sjmp	00125$
   4269                    1429 00124$:
   4269 E4                 1430 	clr	a
   426A                    1431 00125$:
                           1432 ;	genIpop
                           1433 ;	genIfx
                           1434 ;	genIfxJump
                           1435 ;	Peephole 108.c	removed ljmp by inverse jump logic
   426A 60 67              1436 	jz	00109$
                           1437 ;	Peephole 300	removed redundant label 00126$
                           1438 ;	../../Common/event_timer.c:232: evtTimers[i].evtData,
                           1439 ;	genPlus
                           1440 ;     genPlusIncr
   426C 74 07              1441 	mov	a,#0x07
                           1442 ;	Peephole 236.a	used r5 instead of ar5
   426E 2D                 1443 	add	a,r5
   426F FB                 1444 	mov	r3,a
                           1445 ;	Peephole 181	changed mov to clr
   4270 E4                 1446 	clr	a
                           1447 ;	Peephole 236.b	used r6 instead of ar6
   4271 3E                 1448 	addc	a,r6
   4272 FF                 1449 	mov	r7,a
                           1450 ;	genCast
   4273 E5 10              1451 	mov	a,_bp
   4275 24 05              1452 	add	a,#0x05
   4277 F8                 1453 	mov	r0,a
   4278 A6 03              1454 	mov	@r0,ar3
   427A 08                 1455 	inc	r0
   427B A6 07              1456 	mov	@r0,ar7
   427D 08                 1457 	inc	r0
   427E 76 00              1458 	mov	@r0,#0x0
                           1459 ;	../../Common/event_timer.c:231: prev_task = xQueueSendFromISR(evtTimers[i].evtQueue, 
                           1460 ;	genPointerGet
                           1461 ;	genFarPointerGet
   4280 8D 82              1462 	mov	dpl,r5
   4282 8E 83              1463 	mov	dph,r6
   4284 E0                 1464 	movx	a,@dptr
   4285 FD                 1465 	mov	r5,a
   4286 A3                 1466 	inc	dptr
   4287 E0                 1467 	movx	a,@dptr
   4288 FE                 1468 	mov	r6,a
   4289 A3                 1469 	inc	dptr
   428A E0                 1470 	movx	a,@dptr
   428B FA                 1471 	mov	r2,a
                           1472 ;	genIpush
   428C C0 04              1473 	push	ar4
   428E E5 10              1474 	mov	a,_bp
   4290 24 04              1475 	add	a,#0x04
   4292 F8                 1476 	mov	r0,a
   4293 E6                 1477 	mov	a,@r0
   4294 C0 E0              1478 	push	acc
                           1479 ;	genIpush
   4296 E5 10              1480 	mov	a,_bp
   4298 24 05              1481 	add	a,#0x05
   429A F8                 1482 	mov	r0,a
   429B E6                 1483 	mov	a,@r0
   429C C0 E0              1484 	push	acc
   429E 08                 1485 	inc	r0
   429F E6                 1486 	mov	a,@r0
   42A0 C0 E0              1487 	push	acc
   42A2 08                 1488 	inc	r0
   42A3 E6                 1489 	mov	a,@r0
   42A4 C0 E0              1490 	push	acc
                           1491 ;	genCall
   42A6 8D 82              1492 	mov	dpl,r5
   42A8 8E 83              1493 	mov	dph,r6
   42AA 8A F0              1494 	mov	b,r2
   42AC 12 21 24           1495 	lcall	_xQueueSendFromISR
   42AF AA 82              1496 	mov	r2,dpl
   42B1 E5 81              1497 	mov	a,sp
   42B3 24 FC              1498 	add	a,#0xfc
   42B5 F5 81              1499 	mov	sp,a
   42B7 D0 04              1500 	pop	ar4
                           1501 ;	genAssign
   42B9 E5 10              1502 	mov	a,_bp
   42BB 24 04              1503 	add	a,#0x04
   42BD F8                 1504 	mov	r0,a
   42BE A6 02              1505 	mov	@r0,ar2
                           1506 ;	../../Common/event_timer.c:234: evtTimers[i].evtRunning = 0;
                           1507 ;	genPlus
                           1508 ;	Peephole 236.g	used r4 instead of ar4
   42C0 EC                 1509 	mov	a,r4
   42C1 24 DD              1510 	add	a,#_evtTimers
   42C3 FC                 1511 	mov	r4,a
                           1512 ;	Peephole 181	changed mov to clr
   42C4 E4                 1513 	clr	a
   42C5 34 EE              1514 	addc	a,#(_evtTimers >> 8)
   42C7 FA                 1515 	mov	r2,a
                           1516 ;	genPlus
                           1517 ;     genPlusIncr
   42C8 74 06              1518 	mov	a,#0x06
                           1519 ;	Peephole 236.a	used r4 instead of ar4
   42CA 2C                 1520 	add	a,r4
   42CB F5 82              1521 	mov	dpl,a
                           1522 ;	Peephole 181	changed mov to clr
   42CD E4                 1523 	clr	a
                           1524 ;	Peephole 236.b	used r2 instead of ar2
   42CE 3A                 1525 	addc	a,r2
   42CF F5 83              1526 	mov	dph,a
                           1527 ;	genPointerSet
                           1528 ;     genFarPointerSet
                           1529 ;	Peephole 181	changed mov to clr
   42D1 E4                 1530 	clr	a
   42D2 F0                 1531 	movx	@dptr,a
   42D3                    1532 00109$:
                           1533 ;	../../Common/event_timer.c:225: for (i=0; i< HAVE_EVENT_TIMERS ; i++)
                           1534 ;	genPlus
   42D3 A8 10              1535 	mov	r0,_bp
   42D5 08                 1536 	inc	r0
                           1537 ;     genPlusIncr
   42D6 06                 1538 	inc	@r0
   42D7 02 42 13           1539 	ljmp	00107$
   42DA                    1540 00111$:
   42DA 85 10 81           1541 	mov	sp,_bp
   42DD D0 10              1542 	pop	_bp
   42DF 22                 1543 	ret
                           1544 	.area CSEG    (CODE)
                           1545 	.area CONST   (CODE)
                           1546 	.area XINIT   (CODE)
   E8A2                    1547 __xinit__evtInit:
   E8A2 FF                 1548 	.db #0xFF
