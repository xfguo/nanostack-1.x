                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Nov 10 2006)
                              4 ; This file generated Fri Feb  1 13:33:37 2008
                              5 ;--------------------------------------------------------
                              6 	.module debug
                              7 	.optsdcc -mmcs51 --model-large
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _debug_hex_table
                             13 	.globl _IRCON2_P2IF
                             14 	.globl _IRCON2_UTX0IF
                             15 	.globl _IRCON2_UTX1IF
                             16 	.globl _IRCON2_P1IF
                             17 	.globl _IRCON2_WDTIF
                             18 	.globl _CY
                             19 	.globl _AC
                             20 	.globl _F0
                             21 	.globl _RS1
                             22 	.globl _RS0
                             23 	.globl _OV
                             24 	.globl _F1
                             25 	.globl _P
                             26 	.globl _IRCON_DMAIF
                             27 	.globl _IRCON_T1IF
                             28 	.globl _IRCON_T2IF
                             29 	.globl _IRCON_T3IF
                             30 	.globl _IRCON_T4IF
                             31 	.globl _IRCON_P0IF
                             32 	.globl _IRCON_STIF
                             33 	.globl _IEN1_DMAIE
                             34 	.globl _IEN1_T1IE
                             35 	.globl _IEN1_T2IE
                             36 	.globl _IEN1_T3IE
                             37 	.globl _IEN1_T4IE
                             38 	.globl _IEN1_P0IE
                             39 	.globl _IEN0_RFERRIE
                             40 	.globl _IEN0_ADCIE
                             41 	.globl _IEN0_URX0IE
                             42 	.globl _IEN0_URX1IE
                             43 	.globl _IEN0_ENCIE
                             44 	.globl _IEN0_STIE
                             45 	.globl _IEN0_EA
                             46 	.globl _EA
                             47 	.globl _P2_4
                             48 	.globl _P2_3
                             49 	.globl _P2_2
                             50 	.globl _P2_1
                             51 	.globl _P2_0
                             52 	.globl _S0CON_ENCIF_0
                             53 	.globl _S0CON_ENCIF_1
                             54 	.globl _P1_7
                             55 	.globl _P1_6
                             56 	.globl _P1_5
                             57 	.globl _P1_4
                             58 	.globl _P1_3
                             59 	.globl _P1_2
                             60 	.globl _P1_1
                             61 	.globl _P1_0
                             62 	.globl _TCON_IT0
                             63 	.globl _TCON_RFERRIF
                             64 	.globl _TCON_IT1
                             65 	.globl _TCON_URX0IF
                             66 	.globl _TCON_ADCIF
                             67 	.globl _TCON_URX1IF
                             68 	.globl _P0_0
                             69 	.globl _P0_1
                             70 	.globl _P0_2
                             71 	.globl _P0_3
                             72 	.globl _P0_4
                             73 	.globl _P0_5
                             74 	.globl _P0_6
                             75 	.globl _P0_7
                             76 	.globl _P2DIR
                             77 	.globl _P1DIR
                             78 	.globl _P0DIR
                             79 	.globl _U1GCR
                             80 	.globl _U1UCR
                             81 	.globl _U1BAUD
                             82 	.globl _U1BUF
                             83 	.globl _U1CSR
                             84 	.globl _P2INP
                             85 	.globl _P1INP
                             86 	.globl _P2SEL
                             87 	.globl _P1SEL
                             88 	.globl _P0SEL
                             89 	.globl _ADCCFG
                             90 	.globl _PERCFG
                             91 	.globl _B
                             92 	.globl _T4CC1
                             93 	.globl _T4CCTL1
                             94 	.globl _T4CC0
                             95 	.globl _T4CCTL0
                             96 	.globl _T4CTL
                             97 	.globl _T4CNT
                             98 	.globl _RFIF
                             99 	.globl _IRCON2
                            100 	.globl _T1CCTL2
                            101 	.globl _T1CCTL1
                            102 	.globl _T1CCTL0
                            103 	.globl _T1CTL
                            104 	.globl _T1CNTH
                            105 	.globl _T1CNTL
                            106 	.globl _RFST
                            107 	.globl _ACC
                            108 	.globl _T1CC2H
                            109 	.globl _T1CC2L
                            110 	.globl _T1CC1H
                            111 	.globl _T1CC1L
                            112 	.globl _T1CC0H
                            113 	.globl _T1CC0L
                            114 	.globl _RFD
                            115 	.globl _TIMIF
                            116 	.globl _DMAREQ
                            117 	.globl _DMAARM
                            118 	.globl _DMA0CFGH
                            119 	.globl _DMA0CFGL
                            120 	.globl _DMA1CFGH
                            121 	.globl _DMA1CFGL
                            122 	.globl _DMAIRQ
                            123 	.globl _PSW
                            124 	.globl _T3CC1
                            125 	.globl _T3CCTL1
                            126 	.globl _T3CC0
                            127 	.globl _T3CCTL0
                            128 	.globl _T3CTL
                            129 	.globl _T3CNT
                            130 	.globl _WDCTL
                            131 	.globl _T2CON
                            132 	.globl _MEMCTR
                            133 	.globl _CLKCON
                            134 	.globl _U0GCR
                            135 	.globl _U0UCR
                            136 	.globl _T2CNF
                            137 	.globl _U0BAUD
                            138 	.globl _U0BUF
                            139 	.globl _IRCON
                            140 	.globl _SLEEP
                            141 	.globl _RNDH
                            142 	.globl _RNDL
                            143 	.globl _ADCH
                            144 	.globl _ADCL
                            145 	.globl _IP1
                            146 	.globl _IEN1
                            147 	.globl _RCCTL
                            148 	.globl _ADCCON3
                            149 	.globl _ADCCON2
                            150 	.globl _ADCCON1
                            151 	.globl _ENCCS
                            152 	.globl _ENCDO
                            153 	.globl _ENCDI
                            154 	.globl _FWDATA
                            155 	.globl _FCTL
                            156 	.globl _FADDRH
                            157 	.globl _FADDRL
                            158 	.globl _FWT
                            159 	.globl _IP0
                            160 	.globl _IEN0
                            161 	.globl _IE
                            162 	.globl _T2THD
                            163 	.globl _T2TLD
                            164 	.globl _T2CAPHPH
                            165 	.globl _T2CAPLPL
                            166 	.globl _T2OF2
                            167 	.globl _T2OF1
                            168 	.globl _T2OF0
                            169 	.globl _P2
                            170 	.globl _T2PEROF2
                            171 	.globl _T2PEROF1
                            172 	.globl _T2PEROF0
                            173 	.globl _S1CON
                            174 	.globl _IEN2
                            175 	.globl _HSRC
                            176 	.globl _S0CON
                            177 	.globl _ST2
                            178 	.globl _ST1
                            179 	.globl _ST0
                            180 	.globl _T2CMP
                            181 	.globl __XPAGE
                            182 	.globl _DPS
                            183 	.globl _RFIM
                            184 	.globl _P1
                            185 	.globl _P0INP
                            186 	.globl _P1IEN
                            187 	.globl _PICTL
                            188 	.globl _P2IFG
                            189 	.globl _P1IFG
                            190 	.globl _P0IFG
                            191 	.globl _TCON
                            192 	.globl _PCON
                            193 	.globl _U0CSR
                            194 	.globl _DPH1
                            195 	.globl _DPL1
                            196 	.globl _DPH0
                            197 	.globl _DPL0
                            198 	.globl _SP
                            199 	.globl _P0
                            200 	.globl _debug_buffer
                            201 	.globl _RFD_SHADOW
                            202 	.globl _RFSTATUS
                            203 	.globl _CHIPID
                            204 	.globl _CHVER
                            205 	.globl _FSMTC1
                            206 	.globl _RXFIFOCNT
                            207 	.globl _IOCFG3
                            208 	.globl _IOCFG2
                            209 	.globl _IOCFG1
                            210 	.globl _IOCFG0
                            211 	.globl _SHORTADDRL
                            212 	.globl _SHORTADDRH
                            213 	.globl _PANIDL
                            214 	.globl _PANIDH
                            215 	.globl _IEEE_ADDR7
                            216 	.globl _IEEE_ADDR6
                            217 	.globl _IEEE_ADDR5
                            218 	.globl _IEEE_ADDR4
                            219 	.globl _IEEE_ADDR3
                            220 	.globl _IEEE_ADDR2
                            221 	.globl _IEEE_ADDR1
                            222 	.globl _IEEE_ADDR0
                            223 	.globl _DACTSTL
                            224 	.globl _DACTSTH
                            225 	.globl _ADCTSTL
                            226 	.globl _ADCTSTH
                            227 	.globl _FSMSTATE
                            228 	.globl _AGCCTRLL
                            229 	.globl _AGCCTRLH
                            230 	.globl _MANORL
                            231 	.globl _MANORH
                            232 	.globl _MANANDL
                            233 	.globl _MANANDH
                            234 	.globl _FSMTCL
                            235 	.globl _FSMTCH
                            236 	.globl _RFPWR
                            237 	.globl _CSPT
                            238 	.globl _CSPCTRL
                            239 	.globl _CSPZ
                            240 	.globl _CSPY
                            241 	.globl _CSPX
                            242 	.globl _FSCTRLL
                            243 	.globl _FSCTRLH
                            244 	.globl _RXCTRL1L
                            245 	.globl _RXCTRL1H
                            246 	.globl _RXCTRL0L
                            247 	.globl _RXCTRL0H
                            248 	.globl _TXCTRLL
                            249 	.globl _TXCTRLH
                            250 	.globl _SYNCWORDL
                            251 	.globl _SYNCWORDH
                            252 	.globl _RSSIL
                            253 	.globl _RSSIH
                            254 	.globl _MDMCTRL1L
                            255 	.globl _MDMCTRL1H
                            256 	.globl _MDMCTRL0L
                            257 	.globl _MDMCTRL0H
                            258 	.globl _debug_init
                            259 	.globl _debug_read_blocking
                            260 	.globl _debug_put
                            261 	.globl _debug_constant
                            262 	.globl _debug_integer
                            263 	.globl _debug_send
                            264 	.globl _debug_address
                            265 ;--------------------------------------------------------
                            266 ; special function registers
                            267 ;--------------------------------------------------------
                            268 	.area RSEG    (DATA)
                    0080    269 _P0	=	0x0080
                    0081    270 _SP	=	0x0081
                    0082    271 _DPL0	=	0x0082
                    0083    272 _DPH0	=	0x0083
                    0084    273 _DPL1	=	0x0084
                    0085    274 _DPH1	=	0x0085
                    0086    275 _U0CSR	=	0x0086
                    0087    276 _PCON	=	0x0087
                    0088    277 _TCON	=	0x0088
                    0089    278 _P0IFG	=	0x0089
                    008A    279 _P1IFG	=	0x008a
                    008B    280 _P2IFG	=	0x008b
                    008C    281 _PICTL	=	0x008c
                    008D    282 _P1IEN	=	0x008d
                    008F    283 _P0INP	=	0x008f
                    0090    284 _P1	=	0x0090
                    0091    285 _RFIM	=	0x0091
                    0092    286 _DPS	=	0x0092
                    0093    287 __XPAGE	=	0x0093
                    0094    288 _T2CMP	=	0x0094
                    0095    289 _ST0	=	0x0095
                    0096    290 _ST1	=	0x0096
                    0097    291 _ST2	=	0x0097
                    0098    292 _S0CON	=	0x0098
                    0099    293 _HSRC	=	0x0099
                    009A    294 _IEN2	=	0x009a
                    009B    295 _S1CON	=	0x009b
                    009C    296 _T2PEROF0	=	0x009c
                    009D    297 _T2PEROF1	=	0x009d
                    009E    298 _T2PEROF2	=	0x009e
                    00A0    299 _P2	=	0x00a0
                    00A1    300 _T2OF0	=	0x00a1
                    00A2    301 _T2OF1	=	0x00a2
                    00A3    302 _T2OF2	=	0x00a3
                    00A4    303 _T2CAPLPL	=	0x00a4
                    00A5    304 _T2CAPHPH	=	0x00a5
                    00A6    305 _T2TLD	=	0x00a6
                    00A7    306 _T2THD	=	0x00a7
                    00A8    307 _IE	=	0x00a8
                    00A8    308 _IEN0	=	0x00a8
                    00A9    309 _IP0	=	0x00a9
                    00AB    310 _FWT	=	0x00ab
                    00AC    311 _FADDRL	=	0x00ac
                    00AD    312 _FADDRH	=	0x00ad
                    00AE    313 _FCTL	=	0x00ae
                    00AF    314 _FWDATA	=	0x00af
                    00B1    315 _ENCDI	=	0x00b1
                    00B2    316 _ENCDO	=	0x00b2
                    00B3    317 _ENCCS	=	0x00b3
                    00B4    318 _ADCCON1	=	0x00b4
                    00B5    319 _ADCCON2	=	0x00b5
                    00B6    320 _ADCCON3	=	0x00b6
                    00B7    321 _RCCTL	=	0x00b7
                    00B8    322 _IEN1	=	0x00b8
                    00B9    323 _IP1	=	0x00b9
                    00BA    324 _ADCL	=	0x00ba
                    00BB    325 _ADCH	=	0x00bb
                    00BC    326 _RNDL	=	0x00bc
                    00BD    327 _RNDH	=	0x00bd
                    00BE    328 _SLEEP	=	0x00be
                    00C0    329 _IRCON	=	0x00c0
                    00C1    330 _U0BUF	=	0x00c1
                    00C2    331 _U0BAUD	=	0x00c2
                    00C3    332 _T2CNF	=	0x00c3
                    00C4    333 _U0UCR	=	0x00c4
                    00C5    334 _U0GCR	=	0x00c5
                    00C6    335 _CLKCON	=	0x00c6
                    00C7    336 _MEMCTR	=	0x00c7
                    00C8    337 _T2CON	=	0x00c8
                    00C9    338 _WDCTL	=	0x00c9
                    00CA    339 _T3CNT	=	0x00ca
                    00CB    340 _T3CTL	=	0x00cb
                    00CC    341 _T3CCTL0	=	0x00cc
                    00CD    342 _T3CC0	=	0x00cd
                    00CE    343 _T3CCTL1	=	0x00ce
                    00CF    344 _T3CC1	=	0x00cf
                    00D0    345 _PSW	=	0x00d0
                    00D1    346 _DMAIRQ	=	0x00d1
                    00D2    347 _DMA1CFGL	=	0x00d2
                    00D3    348 _DMA1CFGH	=	0x00d3
                    00D4    349 _DMA0CFGL	=	0x00d4
                    00D5    350 _DMA0CFGH	=	0x00d5
                    00D6    351 _DMAARM	=	0x00d6
                    00D7    352 _DMAREQ	=	0x00d7
                    00D8    353 _TIMIF	=	0x00d8
                    00D9    354 _RFD	=	0x00d9
                    00DA    355 _T1CC0L	=	0x00da
                    00DB    356 _T1CC0H	=	0x00db
                    00DC    357 _T1CC1L	=	0x00dc
                    00DD    358 _T1CC1H	=	0x00dd
                    00DE    359 _T1CC2L	=	0x00de
                    00DF    360 _T1CC2H	=	0x00df
                    00E0    361 _ACC	=	0x00e0
                    00E1    362 _RFST	=	0x00e1
                    00E2    363 _T1CNTL	=	0x00e2
                    00E3    364 _T1CNTH	=	0x00e3
                    00E4    365 _T1CTL	=	0x00e4
                    00E5    366 _T1CCTL0	=	0x00e5
                    00E6    367 _T1CCTL1	=	0x00e6
                    00E7    368 _T1CCTL2	=	0x00e7
                    00E8    369 _IRCON2	=	0x00e8
                    00E9    370 _RFIF	=	0x00e9
                    00EA    371 _T4CNT	=	0x00ea
                    00EB    372 _T4CTL	=	0x00eb
                    00EC    373 _T4CCTL0	=	0x00ec
                    00ED    374 _T4CC0	=	0x00ed
                    00EE    375 _T4CCTL1	=	0x00ee
                    00EF    376 _T4CC1	=	0x00ef
                    00F0    377 _B	=	0x00f0
                    00F1    378 _PERCFG	=	0x00f1
                    00F2    379 _ADCCFG	=	0x00f2
                    00F3    380 _P0SEL	=	0x00f3
                    00F4    381 _P1SEL	=	0x00f4
                    00F5    382 _P2SEL	=	0x00f5
                    00F6    383 _P1INP	=	0x00f6
                    00F7    384 _P2INP	=	0x00f7
                    00F8    385 _U1CSR	=	0x00f8
                    00F9    386 _U1BUF	=	0x00f9
                    00FA    387 _U1BAUD	=	0x00fa
                    00FB    388 _U1UCR	=	0x00fb
                    00FC    389 _U1GCR	=	0x00fc
                    00FD    390 _P0DIR	=	0x00fd
                    00FE    391 _P1DIR	=	0x00fe
                    00FF    392 _P2DIR	=	0x00ff
                            393 ;--------------------------------------------------------
                            394 ; special function bits
                            395 ;--------------------------------------------------------
                            396 	.area RSEG    (DATA)
                    0087    397 _P0_7	=	0x0087
                    0086    398 _P0_6	=	0x0086
                    0085    399 _P0_5	=	0x0085
                    0084    400 _P0_4	=	0x0084
                    0083    401 _P0_3	=	0x0083
                    0082    402 _P0_2	=	0x0082
                    0081    403 _P0_1	=	0x0081
                    0080    404 _P0_0	=	0x0080
                    008F    405 _TCON_URX1IF	=	0x008f
                    008D    406 _TCON_ADCIF	=	0x008d
                    008B    407 _TCON_URX0IF	=	0x008b
                    008A    408 _TCON_IT1	=	0x008a
                    0089    409 _TCON_RFERRIF	=	0x0089
                    0088    410 _TCON_IT0	=	0x0088
                    0090    411 _P1_0	=	0x0090
                    0091    412 _P1_1	=	0x0091
                    0092    413 _P1_2	=	0x0092
                    0093    414 _P1_3	=	0x0093
                    0094    415 _P1_4	=	0x0094
                    0095    416 _P1_5	=	0x0095
                    0096    417 _P1_6	=	0x0096
                    0097    418 _P1_7	=	0x0097
                    0099    419 _S0CON_ENCIF_1	=	0x0099
                    0098    420 _S0CON_ENCIF_0	=	0x0098
                    00A0    421 _P2_0	=	0x00a0
                    00A1    422 _P2_1	=	0x00a1
                    00A2    423 _P2_2	=	0x00a2
                    00A3    424 _P2_3	=	0x00a3
                    00A4    425 _P2_4	=	0x00a4
                    00AF    426 _EA	=	0x00af
                    00AF    427 _IEN0_EA	=	0x00af
                    00AD    428 _IEN0_STIE	=	0x00ad
                    00AC    429 _IEN0_ENCIE	=	0x00ac
                    00AB    430 _IEN0_URX1IE	=	0x00ab
                    00AA    431 _IEN0_URX0IE	=	0x00aa
                    00A9    432 _IEN0_ADCIE	=	0x00a9
                    00A8    433 _IEN0_RFERRIE	=	0x00a8
                    00BD    434 _IEN1_P0IE	=	0x00bd
                    00BC    435 _IEN1_T4IE	=	0x00bc
                    00BB    436 _IEN1_T3IE	=	0x00bb
                    00BA    437 _IEN1_T2IE	=	0x00ba
                    00B9    438 _IEN1_T1IE	=	0x00b9
                    00B8    439 _IEN1_DMAIE	=	0x00b8
                    00C7    440 _IRCON_STIF	=	0x00c7
                    00C5    441 _IRCON_P0IF	=	0x00c5
                    00C4    442 _IRCON_T4IF	=	0x00c4
                    00C3    443 _IRCON_T3IF	=	0x00c3
                    00C2    444 _IRCON_T2IF	=	0x00c2
                    00C1    445 _IRCON_T1IF	=	0x00c1
                    00C0    446 _IRCON_DMAIF	=	0x00c0
                    00D0    447 _P	=	0x00d0
                    00D1    448 _F1	=	0x00d1
                    00D2    449 _OV	=	0x00d2
                    00D3    450 _RS0	=	0x00d3
                    00D4    451 _RS1	=	0x00d4
                    00D5    452 _F0	=	0x00d5
                    00D6    453 _AC	=	0x00d6
                    00D7    454 _CY	=	0x00d7
                    00EC    455 _IRCON2_WDTIF	=	0x00ec
                    00EB    456 _IRCON2_P1IF	=	0x00eb
                    00EA    457 _IRCON2_UTX1IF	=	0x00ea
                    00E9    458 _IRCON2_UTX0IF	=	0x00e9
                    00E8    459 _IRCON2_P2IF	=	0x00e8
                            460 ;--------------------------------------------------------
                            461 ; overlayable register banks
                            462 ;--------------------------------------------------------
                            463 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     464 	.ds 8
                            465 ;--------------------------------------------------------
                            466 ; internal ram data
                            467 ;--------------------------------------------------------
                            468 	.area DSEG    (DATA)
                            469 ;--------------------------------------------------------
                            470 ; overlayable items in internal ram 
                            471 ;--------------------------------------------------------
                            472 	.area OSEG    (OVR,DATA)
                            473 ;--------------------------------------------------------
                            474 ; indirectly addressable internal ram data
                            475 ;--------------------------------------------------------
                            476 	.area ISEG    (DATA)
                            477 ;--------------------------------------------------------
                            478 ; bit data
                            479 ;--------------------------------------------------------
                            480 	.area BSEG    (BIT)
                            481 ;--------------------------------------------------------
                            482 ; paged external ram data
                            483 ;--------------------------------------------------------
                            484 	.area PSEG    (PAG,XDATA)
                            485 ;--------------------------------------------------------
                            486 ; external ram data
                            487 ;--------------------------------------------------------
                            488 	.area XSEG    (XDATA)
                    DF02    489 _MDMCTRL0H	=	0xdf02
                    DF03    490 _MDMCTRL0L	=	0xdf03
                    DF04    491 _MDMCTRL1H	=	0xdf04
                    DF05    492 _MDMCTRL1L	=	0xdf05
                    DF06    493 _RSSIH	=	0xdf06
                    DF07    494 _RSSIL	=	0xdf07
                    DF08    495 _SYNCWORDH	=	0xdf08
                    DF09    496 _SYNCWORDL	=	0xdf09
                    DF0A    497 _TXCTRLH	=	0xdf0a
                    DF0B    498 _TXCTRLL	=	0xdf0b
                    DF0C    499 _RXCTRL0H	=	0xdf0c
                    DF0D    500 _RXCTRL0L	=	0xdf0d
                    DF0E    501 _RXCTRL1H	=	0xdf0e
                    DF0F    502 _RXCTRL1L	=	0xdf0f
                    DF10    503 _FSCTRLH	=	0xdf10
                    DF11    504 _FSCTRLL	=	0xdf11
                    DF12    505 _CSPX	=	0xdf12
                    DF13    506 _CSPY	=	0xdf13
                    DF14    507 _CSPZ	=	0xdf14
                    DF15    508 _CSPCTRL	=	0xdf15
                    DF16    509 _CSPT	=	0xdf16
                    DF17    510 _RFPWR	=	0xdf17
                    DF20    511 _FSMTCH	=	0xdf20
                    DF21    512 _FSMTCL	=	0xdf21
                    DF22    513 _MANANDH	=	0xdf22
                    DF23    514 _MANANDL	=	0xdf23
                    DF24    515 _MANORH	=	0xdf24
                    DF25    516 _MANORL	=	0xdf25
                    DF26    517 _AGCCTRLH	=	0xdf26
                    DF27    518 _AGCCTRLL	=	0xdf27
                    DF39    519 _FSMSTATE	=	0xdf39
                    DF3A    520 _ADCTSTH	=	0xdf3a
                    DF3B    521 _ADCTSTL	=	0xdf3b
                    DF3C    522 _DACTSTH	=	0xdf3c
                    DF3D    523 _DACTSTL	=	0xdf3d
                    DF43    524 _IEEE_ADDR0	=	0xdf43
                    DF44    525 _IEEE_ADDR1	=	0xdf44
                    DF45    526 _IEEE_ADDR2	=	0xdf45
                    DF46    527 _IEEE_ADDR3	=	0xdf46
                    DF47    528 _IEEE_ADDR4	=	0xdf47
                    DF48    529 _IEEE_ADDR5	=	0xdf48
                    DF49    530 _IEEE_ADDR6	=	0xdf49
                    DF4A    531 _IEEE_ADDR7	=	0xdf4a
                    DF4B    532 _PANIDH	=	0xdf4b
                    DF4C    533 _PANIDL	=	0xdf4c
                    DF4D    534 _SHORTADDRH	=	0xdf4d
                    DF4E    535 _SHORTADDRL	=	0xdf4e
                    DF4F    536 _IOCFG0	=	0xdf4f
                    DF50    537 _IOCFG1	=	0xdf50
                    DF51    538 _IOCFG2	=	0xdf51
                    DF52    539 _IOCFG3	=	0xdf52
                    DF53    540 _RXFIFOCNT	=	0xdf53
                    DF54    541 _FSMTC1	=	0xdf54
                    DF60    542 _CHVER	=	0xdf60
                    DF61    543 _CHIPID	=	0xdf61
                    DF62    544 _RFSTATUS	=	0xdf62
                    DFD9    545 _RFD_SHADOW	=	0xdfd9
   EE1D                     546 _debug_buffer::
   EE1D                     547 	.ds 64
                            548 ;--------------------------------------------------------
                            549 ; external initialized ram data
                            550 ;--------------------------------------------------------
                            551 	.area XISEG   (XDATA)
                            552 	.area HOME    (CODE)
                            553 	.area GSINIT0 (CODE)
                            554 	.area GSINIT1 (CODE)
                            555 	.area GSINIT2 (CODE)
                            556 	.area GSINIT3 (CODE)
                            557 	.area GSINIT4 (CODE)
                            558 	.area GSINIT5 (CODE)
                            559 	.area GSINIT  (CODE)
                            560 	.area GSFINAL (CODE)
                            561 	.area CSEG    (CODE)
                            562 ;--------------------------------------------------------
                            563 ; global & static initialisations
                            564 ;--------------------------------------------------------
                            565 	.area HOME    (CODE)
                            566 	.area GSINIT  (CODE)
                            567 	.area GSFINAL (CODE)
                            568 	.area GSINIT  (CODE)
                            569 ;--------------------------------------------------------
                            570 ; Home
                            571 ;--------------------------------------------------------
                            572 	.area HOME    (CODE)
                            573 	.area CSEG    (CODE)
                            574 ;--------------------------------------------------------
                            575 ; code
                            576 ;--------------------------------------------------------
                            577 	.area CSEG    (CODE)
                            578 ;------------------------------------------------------------
                            579 ;Allocation info for local variables in function 'debug_init'
                            580 ;------------------------------------------------------------
                            581 ;speed                     Allocated to registers r2 r3 r4 r5 
                            582 ;------------------------------------------------------------
                            583 ;	../../Platform/nano/debug.c:96: void debug_init(uint32_t speed)
                            584 ;	-----------------------------------------
                            585 ;	 function debug_init
                            586 ;	-----------------------------------------
   38CF                     587 _debug_init:
                    0002    588 	ar2 = 0x02
                    0003    589 	ar3 = 0x03
                    0004    590 	ar4 = 0x04
                    0005    591 	ar5 = 0x05
                    0006    592 	ar6 = 0x06
                    0007    593 	ar7 = 0x07
                    0000    594 	ar0 = 0x00
                    0001    595 	ar1 = 0x01
                            596 ;     genReceive
                            597 ;	../../Platform/nano/debug.c:98: uart1_init(speed);
                            598 ;	genCall
   38CF AA 82               599 	mov	r2,dpl
   38D1 AB 83               600 	mov	r3,dph
   38D3 AC F0               601 	mov	r4,b
   38D5 FD                  602 	mov	r5,a
                            603 ;	Peephole 238.b	removed 3 redundant moves
                            604 ;	Peephole 191	removed redundant mov
                            605 ;	Peephole 253.b	replaced lcall/ret with ljmp
   38D6 02 3D 75            606 	ljmp	_uart1_init
                            607 ;
                            608 ;------------------------------------------------------------
                            609 ;Allocation info for local variables in function 'debug_read_blocking'
                            610 ;------------------------------------------------------------
                            611 ;time                      Allocated to registers r2 r3 r4 r5 
                            612 ;------------------------------------------------------------
                            613 ;	../../Platform/nano/debug.c:101: int16_t debug_read_blocking(uint32_t time)
                            614 ;	-----------------------------------------
                            615 ;	 function debug_read_blocking
                            616 ;	-----------------------------------------
   38D9                     617 _debug_read_blocking:
                            618 ;     genReceive
                            619 ;	../../Platform/nano/debug.c:103: return uart1_get_blocking(time);
                            620 ;	genCast
                            621 ;	genCall
   38D9 AA 82               622 	mov	r2,dpl
   38DB AB 83               623 	mov	r3,dph
   38DD AC F0               624 	mov	r4,b
   38DF FD                  625 	mov	r5,a
                            626 ;	Peephole 238.c	removed 2 redundant moves
                            627 ;	genRet
                            628 ;	Peephole 150.b	removed misc moves via dph, dpl before return
                            629 ;	Peephole 253.b	replaced lcall/ret with ljmp
   38E0 02 3D E2            630 	ljmp	_uart1_get_blocking
                            631 ;
                            632 ;------------------------------------------------------------
                            633 ;Allocation info for local variables in function 'debug_put'
                            634 ;------------------------------------------------------------
                            635 ;byte                      Allocated to registers r2 
                            636 ;------------------------------------------------------------
                            637 ;	../../Platform/nano/debug.c:106: int8_t debug_put(uint8_t byte)
                            638 ;	-----------------------------------------
                            639 ;	 function debug_put
                            640 ;	-----------------------------------------
   38E3                     641 _debug_put:
                            642 ;	genReceive
                            643 ;	../../Platform/nano/debug.c:108: return uart1_put(byte);
                            644 ;	genCall
   38E3 AA 82               645 	mov  r2,dpl
                            646 ;	Peephole 177.a	removed redundant mov
                            647 ;	genRet
                            648 ;	Peephole 150.a	removed misc moves via dpl before return
                            649 ;	Peephole 253.b	replaced lcall/ret with ljmp
   38E5 02 3E 8B            650 	ljmp	_uart1_put
                            651 ;
                            652 ;------------------------------------------------------------
                            653 ;Allocation info for local variables in function 'debug_constant'
                            654 ;------------------------------------------------------------
                            655 ;s                         Allocated to registers r2 r3 
                            656 ;i                         Allocated to registers r4 
                            657 ;------------------------------------------------------------
                            658 ;	../../Platform/nano/debug.c:112: int8_t debug_constant(const prog_char *s)
                            659 ;	-----------------------------------------
                            660 ;	 function debug_constant
                            661 ;	-----------------------------------------
   38E8                     662 _debug_constant:
                            663 ;	genReceive
   38E8 AA 82               664 	mov	r2,dpl
   38EA AB 83               665 	mov	r3,dph
                            666 ;	../../Platform/nano/debug.c:114: uint8_t i = 0;
                            667 ;	genAssign
   38EC 7C 00               668 	mov	r4,#0x00
                            669 ;	../../Platform/nano/debug.c:116: while(*s)
                            670 ;	genAssign
                            671 ;	genAssign
   38EE 7D 00               672 	mov	r5,#0x00
   38F0                     673 00104$:
                            674 ;	genPointerGet
                            675 ;	genCodePointerGet
   38F0 8A 82               676 	mov	dpl,r2
   38F2 8B 83               677 	mov	dph,r3
   38F4 E4                  678 	clr	a
   38F5 93                  679 	movc	a,@a+dptr
                            680 ;	genIfx
   38F6 FE                  681 	mov	r6,a
                            682 ;	Peephole 105	removed redundant mov
                            683 ;	genIfxJump
                            684 ;	Peephole 108.c	removed ljmp by inverse jump logic
   38F7 60 27               685 	jz	00106$
                            686 ;	Peephole 300	removed redundant label 00112$
                            687 ;	../../Platform/nano/debug.c:118: if (debug_put(*s) == -1)
                            688 ;	genCall
   38F9 8E 82               689 	mov	dpl,r6
   38FB C0 02               690 	push	ar2
   38FD C0 03               691 	push	ar3
   38FF C0 04               692 	push	ar4
   3901 C0 05               693 	push	ar5
   3903 12 38 E3            694 	lcall	_debug_put
   3906 AE 82               695 	mov	r6,dpl
   3908 D0 05               696 	pop	ar5
   390A D0 04               697 	pop	ar4
   390C D0 03               698 	pop	ar3
   390E D0 02               699 	pop	ar2
                            700 ;	genCmpEq
                            701 ;	gencjneshort
                            702 ;	Peephole 112.b	changed ljmp to sjmp
                            703 ;	Peephole 198.b	optimized misc jump sequence
   3910 BE FF 03            704 	cjne	r6,#0xFF,00102$
                            705 ;	Peephole 200.b	removed redundant sjmp
                            706 ;	Peephole 300	removed redundant label 00113$
                            707 ;	Peephole 300	removed redundant label 00114$
                            708 ;	../../Platform/nano/debug.c:120: return i;
                            709 ;	genRet
   3913 8C 82               710 	mov	dpl,r4
                            711 ;	Peephole 112.b	changed ljmp to sjmp
                            712 ;	Peephole 251.b	replaced sjmp to ret with ret
   3915 22                  713 	ret
   3916                     714 00102$:
                            715 ;	../../Platform/nano/debug.c:124: s++;
                            716 ;	genPlus
                            717 ;     genPlusIncr
   3916 0A                  718 	inc	r2
   3917 BA 00 01            719 	cjne	r2,#0x00,00115$
   391A 0B                  720 	inc	r3
   391B                     721 00115$:
                            722 ;	../../Platform/nano/debug.c:125: i++;
                            723 ;	genPlus
                            724 ;     genPlusIncr
   391B 0D                  725 	inc	r5
                            726 ;	genAssign
   391C 8D 04               727 	mov	ar4,r5
                            728 ;	Peephole 112.b	changed ljmp to sjmp
   391E 80 D0               729 	sjmp	00104$
   3920                     730 00106$:
                            731 ;	../../Platform/nano/debug.c:128: return i;
                            732 ;	genRet
   3920 8C 82               733 	mov	dpl,r4
                            734 ;	Peephole 300	removed redundant label 00107$
   3922 22                  735 	ret
                            736 ;------------------------------------------------------------
                            737 ;Allocation info for local variables in function 'debug_integer'
                            738 ;------------------------------------------------------------
                            739 ;base                      Allocated to stack - offset -3
                            740 ;n                         Allocated to stack - offset -5
                            741 ;width                     Allocated to registers 
                            742 ;i                         Allocated to registers 
                            743 ;ptr                       Allocated to registers r2 r3 r4 
                            744 ;negative                  Allocated to registers r7 
                            745 ;sloc0                     Allocated to stack - offset 1
                            746 ;------------------------------------------------------------
                            747 ;	../../Platform/nano/debug.c:146: uint8_t *debug_integer(uint8_t width, uint8_t base, int n)
                            748 ;	-----------------------------------------
                            749 ;	 function debug_integer
                            750 ;	-----------------------------------------
   3923                     751 _debug_integer:
   3923 C0 10               752 	push	_bp
   3925 85 81 10            753 	mov	_bp,sp
   3928 05 81               754 	inc	sp
   392A 05 81               755 	inc	sp
   392C 05 81               756 	inc	sp
                            757 ;	../../Platform/nano/debug.c:149: uint8_t *ptr = debug_buffer + sizeof(debug_buffer) - 1;
                            758 ;	genCast
   392E 7A 5C               759 	mov	r2,#(_debug_buffer + 0x003f)
   3930 7B EE               760 	mov	r3,#((_debug_buffer + 0x003f) >> 8)
   3932 7C 00               761 	mov	r4,#0x0
                            762 ;	../../Platform/nano/debug.c:151: *ptr-- = 0;
                            763 ;	genPointerSet
                            764 ;	genGenPointerSet
   3934 8A 82               765 	mov	dpl,r2
   3936 8B 83               766 	mov	dph,r3
   3938 8C F0               767 	mov	b,r4
                            768 ;	Peephole 181	changed mov to clr
   393A E4                  769 	clr	a
   393B 12 DF B7            770 	lcall	__gptrput
                            771 ;	genMinus
                            772 ;	genMinusDec
   393E 1A                  773 	dec	r2
   393F BA FF 01            774 	cjne	r2,#0xff,00124$
   3942 1B                  775 	dec	r3
   3943                     776 00124$:
                            777 ;	../../Platform/nano/debug.c:153: if (base == 16)
                            778 ;	genCmpEq
   3943 A8 10               779 	mov	r0,_bp
   3945 18                  780 	dec	r0
   3946 18                  781 	dec	r0
   3947 18                  782 	dec	r0
                            783 ;	gencjneshort
   3948 B6 10 02            784 	cjne	@r0,#0x10,00125$
   394B 80 03               785 	sjmp	00126$
   394D                     786 00125$:
   394D 02 39 E2            787 	ljmp	00113$
   3950                     788 00126$:
                            789 ;	../../Platform/nano/debug.c:155: do
   3950                     790 00101$:
                            791 ;	../../Platform/nano/debug.c:157: *ptr-- = debug_hex_table[n & 0x0F];
                            792 ;	genAnd
   3950 E5 10               793 	mov	a,_bp
   3952 24 FB               794 	add	a,#0xfffffffb
   3954 F8                  795 	mov	r0,a
   3955 74 0F               796 	mov	a,#0x0F
   3957 56                  797 	anl	a,@r0
   3958 FD                  798 	mov	r5,a
   3959 7E 00               799 	mov	r6,#0x00
                            800 ;	genPlus
                            801 ;	Peephole 236.g	used r5 instead of ar5
   395B ED                  802 	mov	a,r5
   395C 24 82               803 	add	a,#_debug_hex_table
   395E F5 82               804 	mov	dpl,a
                            805 ;	Peephole 236.g	used r6 instead of ar6
   3960 EE                  806 	mov	a,r6
   3961 34 E7               807 	addc	a,#(_debug_hex_table >> 8)
   3963 F5 83               808 	mov	dph,a
                            809 ;	genPointerGet
                            810 ;	genCodePointerGet
   3965 E4                  811 	clr	a
   3966 93                  812 	movc	a,@a+dptr
                            813 ;	genPointerSet
                            814 ;	genGenPointerSet
   3967 FD                  815 	mov	r5,a
   3968 8A 82               816 	mov	dpl,r2
   396A 8B 83               817 	mov	dph,r3
   396C 8C F0               818 	mov	b,r4
                            819 ;	Peephole 191	removed redundant mov
   396E 12 DF B7            820 	lcall	__gptrput
                            821 ;	genMinus
                            822 ;	genMinusDec
   3971 1A                  823 	dec	r2
   3972 BA FF 01            824 	cjne	r2,#0xff,00127$
   3975 1B                  825 	dec	r3
   3976                     826 00127$:
                            827 ;	../../Platform/nano/debug.c:158: n >>= 4;
                            828 ;	genRightShift
                            829 ;	genSignedRightShift
                            830 ;	genRightShiftLiteral
   3976 E5 10               831 	mov	a,_bp
   3978 24 FB               832 	add	a,#0xfffffffb
                            833 ;	genrshTwo
                            834 ;	Peephole 185	changed order of increment (acc incremented also!)
   397A 04                  835 	inc	a
   397B F8                  836 	mov	r0,a
   397C E6                  837 	mov	a,@r0
   397D 18                  838 	dec	r0
   397E C4                  839 	swap	a
   397F C6                  840 	xch	a,@r0
   3980 C4                  841 	swap	a
   3981 54 0F               842 	anl	a,#0x0f
   3983 66                  843 	xrl	a,@r0
   3984 C6                  844 	xch	a,@r0
   3985 54 0F               845 	anl	a,#0x0f
   3987 C6                  846 	xch	a,@r0
   3988 66                  847 	xrl	a,@r0
   3989 C6                  848 	xch	a,@r0
   398A 30 E3 02            849 	jnb	acc.3,00128$
   398D 44 F0               850 	orl	a,#0xf0
   398F                     851 00128$:
   398F 08                  852 	inc	r0
   3990 F6                  853 	mov	@r0,a
                            854 ;	../../Platform/nano/debug.c:159: *ptr-- = debug_hex_table[n & 0x0F];
                            855 ;	genAnd
   3991 E5 10               856 	mov	a,_bp
   3993 24 FB               857 	add	a,#0xfffffffb
   3995 F8                  858 	mov	r0,a
   3996 74 0F               859 	mov	a,#0x0F
   3998 56                  860 	anl	a,@r0
   3999 FD                  861 	mov	r5,a
   399A 7E 00               862 	mov	r6,#0x00
                            863 ;	genPlus
                            864 ;	Peephole 236.g	used r5 instead of ar5
   399C ED                  865 	mov	a,r5
   399D 24 82               866 	add	a,#_debug_hex_table
   399F F5 82               867 	mov	dpl,a
                            868 ;	Peephole 236.g	used r6 instead of ar6
   39A1 EE                  869 	mov	a,r6
   39A2 34 E7               870 	addc	a,#(_debug_hex_table >> 8)
   39A4 F5 83               871 	mov	dph,a
                            872 ;	genPointerGet
                            873 ;	genCodePointerGet
   39A6 E4                  874 	clr	a
   39A7 93                  875 	movc	a,@a+dptr
                            876 ;	genPointerSet
                            877 ;	genGenPointerSet
   39A8 FD                  878 	mov	r5,a
   39A9 8A 82               879 	mov	dpl,r2
   39AB 8B 83               880 	mov	dph,r3
   39AD 8C F0               881 	mov	b,r4
                            882 ;	Peephole 191	removed redundant mov
   39AF 12 DF B7            883 	lcall	__gptrput
                            884 ;	genMinus
                            885 ;	genMinusDec
   39B2 1A                  886 	dec	r2
   39B3 BA FF 01            887 	cjne	r2,#0xff,00129$
   39B6 1B                  888 	dec	r3
   39B7                     889 00129$:
                            890 ;	../../Platform/nano/debug.c:160: n >>= 4;
                            891 ;	genRightShift
                            892 ;	genSignedRightShift
                            893 ;	genRightShiftLiteral
   39B7 E5 10               894 	mov	a,_bp
   39B9 24 FB               895 	add	a,#0xfffffffb
                            896 ;	genrshTwo
                            897 ;	Peephole 185	changed order of increment (acc incremented also!)
   39BB 04                  898 	inc	a
   39BC F8                  899 	mov	r0,a
   39BD E6                  900 	mov	a,@r0
   39BE 18                  901 	dec	r0
   39BF C4                  902 	swap	a
   39C0 C6                  903 	xch	a,@r0
   39C1 C4                  904 	swap	a
   39C2 54 0F               905 	anl	a,#0x0f
   39C4 66                  906 	xrl	a,@r0
   39C5 C6                  907 	xch	a,@r0
   39C6 54 0F               908 	anl	a,#0x0f
   39C8 C6                  909 	xch	a,@r0
   39C9 66                  910 	xrl	a,@r0
   39CA C6                  911 	xch	a,@r0
   39CB 30 E3 02            912 	jnb	acc.3,00130$
   39CE 44 F0               913 	orl	a,#0xf0
   39D0                     914 00130$:
   39D0 08                  915 	inc	r0
   39D1 F6                  916 	mov	@r0,a
                            917 ;	../../Platform/nano/debug.c:161: }while(n);
                            918 ;	genIfx
   39D2 E5 10               919 	mov	a,_bp
   39D4 24 FB               920 	add	a,#0xfffffffb
   39D6 F8                  921 	mov	r0,a
   39D7 E6                  922 	mov	a,@r0
   39D8 08                  923 	inc	r0
   39D9 46                  924 	orl	a,@r0
                            925 ;	genIfxJump
   39DA 60 03               926 	jz	00131$
   39DC 02 39 50            927 	ljmp	00101$
   39DF                     928 00131$:
   39DF 02 3A BE            929 	ljmp	00114$
   39E2                     930 00113$:
                            931 ;	../../Platform/nano/debug.c:165: uint8_t negative = 0;
                            932 ;	genAssign
   39E2 7F 00               933 	mov	r7,#0x00
                            934 ;	../../Platform/nano/debug.c:166: if (n < 0)
                            935 ;	genCmpLt
   39E4 E5 10               936 	mov	a,_bp
   39E6 24 FB               937 	add	a,#0xfffffffb
                            938 ;	genCmp
                            939 ;	Peephole 185	changed order of increment (acc incremented also!)
   39E8 04                  940 	inc	a
   39E9 F8                  941 	mov	r0,a
   39EA E6                  942 	mov	a,@r0
                            943 ;	genIfxJump
                            944 ;	Peephole 108.d	removed ljmp by inverse jump logic
   39EB 30 E7 0F            945 	jnb	acc.7,00120$
                            946 ;	Peephole 300	removed redundant label 00132$
                            947 ;	../../Platform/nano/debug.c:167: { negative = 1;
                            948 ;	genAssign
   39EE 7F 01               949 	mov	r7,#0x01
                            950 ;	../../Platform/nano/debug.c:168: n = -n;
                            951 ;	genUminus
   39F0 E5 10               952 	mov	a,_bp
   39F2 24 FB               953 	add	a,#0xfffffffb
   39F4 F8                  954 	mov	r0,a
   39F5 C3                  955 	clr	c
   39F6 E4                  956 	clr	a
   39F7 96                  957 	subb	a,@r0
   39F8 F6                  958 	mov	@r0,a
   39F9 08                  959 	inc	r0
   39FA E4                  960 	clr	a
   39FB 96                  961 	subb	a,@r0
   39FC F6                  962 	mov	@r0,a
                            963 ;	../../Platform/nano/debug.c:170: do
   39FD                     964 00120$:
                            965 ;	genAssign
   39FD A8 10               966 	mov	r0,_bp
   39FF 08                  967 	inc	r0
   3A00 A6 02               968 	mov	@r0,ar2
   3A02 08                  969 	inc	r0
   3A03 A6 03               970 	mov	@r0,ar3
   3A05 08                  971 	inc	r0
   3A06 A6 04               972 	mov	@r0,ar4
   3A08                     973 00106$:
                            974 ;	../../Platform/nano/debug.c:172: *ptr-- = (n % 10) + '0';
                            975 ;	genIpush
   3A08 C0 07               976 	push	ar7
   3A0A 74 0A               977 	mov	a,#0x0A
   3A0C C0 E0               978 	push	acc
                            979 ;	Peephole 181	changed mov to clr
   3A0E E4                  980 	clr	a
   3A0F C0 E0               981 	push	acc
                            982 ;	genCall
   3A11 E5 10               983 	mov	a,_bp
   3A13 24 FB               984 	add	a,#0xfffffffb
   3A15 F8                  985 	mov	r0,a
   3A16 86 82               986 	mov	dpl,@r0
   3A18 08                  987 	inc	r0
   3A19 86 83               988 	mov	dph,@r0
   3A1B 12 E4 BB            989 	lcall	__modsint
   3A1E AD 82               990 	mov	r5,dpl
   3A20 AE 83               991 	mov	r6,dph
   3A22 15 81               992 	dec	sp
   3A24 15 81               993 	dec	sp
   3A26 D0 07               994 	pop	ar7
                            995 ;	genCast
                            996 ;	genPlus
                            997 ;     genPlusIncr
   3A28 74 30               998 	mov	a,#0x30
                            999 ;	Peephole 236.a	used r5 instead of ar5
   3A2A 2D                 1000 	add	a,r5
   3A2B FD                 1001 	mov	r5,a
                           1002 ;	genPointerSet
                           1003 ;	genGenPointerSet
   3A2C A8 10              1004 	mov	r0,_bp
   3A2E 08                 1005 	inc	r0
   3A2F 86 82              1006 	mov	dpl,@r0
   3A31 08                 1007 	inc	r0
   3A32 86 83              1008 	mov	dph,@r0
   3A34 08                 1009 	inc	r0
   3A35 86 F0              1010 	mov	b,@r0
   3A37 ED                 1011 	mov	a,r5
   3A38 12 DF B7           1012 	lcall	__gptrput
                           1013 ;	genMinus
   3A3B A8 10              1014 	mov	r0,_bp
   3A3D 08                 1015 	inc	r0
                           1016 ;	genMinusDec
   3A3E E6                 1017 	mov	a,@r0
   3A3F 24 FF              1018 	add	a,#0xff
   3A41 F6                 1019 	mov	@r0,a
   3A42 08                 1020 	inc	r0
   3A43 E6                 1021 	mov	a,@r0
   3A44 34 FF              1022 	addc	a,#0xff
   3A46 F6                 1023 	mov	@r0,a
                           1024 ;	../../Platform/nano/debug.c:173: n /= 10;
                           1025 ;	genIpush
   3A47 C0 07              1026 	push	ar7
   3A49 74 0A              1027 	mov	a,#0x0A
   3A4B C0 E0              1028 	push	acc
                           1029 ;	Peephole 181	changed mov to clr
   3A4D E4                 1030 	clr	a
   3A4E C0 E0              1031 	push	acc
                           1032 ;	genCall
   3A50 E5 10              1033 	mov	a,_bp
   3A52 24 FB              1034 	add	a,#0xfffffffb
   3A54 F8                 1035 	mov	r0,a
   3A55 86 82              1036 	mov	dpl,@r0
   3A57 08                 1037 	inc	r0
   3A58 86 83              1038 	mov	dph,@r0
   3A5A 12 E5 BE           1039 	lcall	__divsint
   3A5D AD 82              1040 	mov	r5,dpl
   3A5F AE 83              1041 	mov	r6,dph
   3A61 15 81              1042 	dec	sp
   3A63 15 81              1043 	dec	sp
   3A65 D0 07              1044 	pop	ar7
                           1045 ;	genAssign
   3A67 E5 10              1046 	mov	a,_bp
   3A69 24 FB              1047 	add	a,#0xfffffffb
   3A6B F8                 1048 	mov	r0,a
   3A6C A6 05              1049 	mov	@r0,ar5
   3A6E 08                 1050 	inc	r0
   3A6F A6 06              1051 	mov	@r0,ar6
                           1052 ;	../../Platform/nano/debug.c:174: }while (n);
                           1053 ;	genIfx
   3A71 E5 10              1054 	mov	a,_bp
   3A73 24 FB              1055 	add	a,#0xfffffffb
   3A75 F8                 1056 	mov	r0,a
   3A76 E6                 1057 	mov	a,@r0
   3A77 08                 1058 	inc	r0
   3A78 46                 1059 	orl	a,@r0
                           1060 ;	genIfxJump
                           1061 ;	Peephole 108.b	removed ljmp by inverse jump logic
   3A79 70 8D              1062 	jnz	00106$
                           1063 ;	Peephole 300	removed redundant label 00133$
                           1064 ;	../../Platform/nano/debug.c:175: if (negative)
                           1065 ;	genIfx
   3A7B EF                 1066 	mov	a,r7
                           1067 ;	genIfxJump
                           1068 ;	Peephole 108.c	removed ljmp by inverse jump logic
   3A7C 60 21              1069 	jz	00110$
                           1070 ;	Peephole 300	removed redundant label 00134$
                           1071 ;	../../Platform/nano/debug.c:177: *ptr-- = '-';
                           1072 ;	genPointerSet
                           1073 ;	genGenPointerSet
   3A7E A8 10              1074 	mov	r0,_bp
   3A80 08                 1075 	inc	r0
   3A81 86 82              1076 	mov	dpl,@r0
   3A83 08                 1077 	inc	r0
   3A84 86 83              1078 	mov	dph,@r0
   3A86 08                 1079 	inc	r0
   3A87 86 F0              1080 	mov	b,@r0
   3A89 74 2D              1081 	mov	a,#0x2D
   3A8B 12 DF B7           1082 	lcall	__gptrput
                           1083 ;	genMinus
   3A8E A8 10              1084 	mov	r0,_bp
   3A90 08                 1085 	inc	r0
                           1086 ;	genMinusDec
   3A91 E6                 1087 	mov	a,@r0
   3A92 24 FF              1088 	add	a,#0xff
   3A94 FA                 1089 	mov	r2,a
   3A95 08                 1090 	inc	r0
   3A96 E6                 1091 	mov	a,@r0
   3A97 34 FF              1092 	addc	a,#0xff
   3A99 FB                 1093 	mov	r3,a
   3A9A 08                 1094 	inc	r0
   3A9B 86 04              1095 	mov	ar4,@r0
                           1096 ;	Peephole 112.b	changed ljmp to sjmp
   3A9D 80 1F              1097 	sjmp	00114$
   3A9F                    1098 00110$:
                           1099 ;	../../Platform/nano/debug.c:181: *ptr-- = ' ';
                           1100 ;	genPointerSet
                           1101 ;	genGenPointerSet
   3A9F A8 10              1102 	mov	r0,_bp
   3AA1 08                 1103 	inc	r0
   3AA2 86 82              1104 	mov	dpl,@r0
   3AA4 08                 1105 	inc	r0
   3AA5 86 83              1106 	mov	dph,@r0
   3AA7 08                 1107 	inc	r0
   3AA8 86 F0              1108 	mov	b,@r0
   3AAA 74 20              1109 	mov	a,#0x20
   3AAC 12 DF B7           1110 	lcall	__gptrput
                           1111 ;	genMinus
   3AAF A8 10              1112 	mov	r0,_bp
   3AB1 08                 1113 	inc	r0
                           1114 ;	genMinusDec
   3AB2 E6                 1115 	mov	a,@r0
   3AB3 24 FF              1116 	add	a,#0xff
   3AB5 FA                 1117 	mov	r2,a
   3AB6 08                 1118 	inc	r0
   3AB7 E6                 1119 	mov	a,@r0
   3AB8 34 FF              1120 	addc	a,#0xff
   3ABA FB                 1121 	mov	r3,a
   3ABB 08                 1122 	inc	r0
   3ABC 86 04              1123 	mov	ar4,@r0
   3ABE                    1124 00114$:
                           1125 ;	../../Platform/nano/debug.c:184: ptr++;
                           1126 ;	genPlus
                           1127 ;     genPlusIncr
   3ABE 0A                 1128 	inc	r2
   3ABF BA 00 01           1129 	cjne	r2,#0x00,00135$
   3AC2 0B                 1130 	inc	r3
   3AC3                    1131 00135$:
                           1132 ;	../../Platform/nano/debug.c:185: debug_send(ptr, strlen(ptr) );
                           1133 ;	genCall
   3AC3 8A 82              1134 	mov	dpl,r2
   3AC5 8B 83              1135 	mov	dph,r3
   3AC7 8C F0              1136 	mov	b,r4
   3AC9 C0 02              1137 	push	ar2
   3ACB C0 03              1138 	push	ar3
   3ACD C0 04              1139 	push	ar4
   3ACF 12 E4 87           1140 	lcall	_strlen
   3AD2 AD 82              1141 	mov	r5,dpl
   3AD4 AE 83              1142 	mov	r6,dph
   3AD6 D0 04              1143 	pop	ar4
   3AD8 D0 03              1144 	pop	ar3
   3ADA D0 02              1145 	pop	ar2
                           1146 ;	genCast
                           1147 ;	genIpush
   3ADC C0 02              1148 	push	ar2
   3ADE C0 03              1149 	push	ar3
   3AE0 C0 04              1150 	push	ar4
   3AE2 C0 05              1151 	push	ar5
                           1152 ;	genCall
   3AE4 8A 82              1153 	mov	dpl,r2
   3AE6 8B 83              1154 	mov	dph,r3
   3AE8 8C F0              1155 	mov	b,r4
   3AEA 12 3B 01           1156 	lcall	_debug_send
   3AED 15 81              1157 	dec	sp
   3AEF D0 04              1158 	pop	ar4
   3AF1 D0 03              1159 	pop	ar3
   3AF3 D0 02              1160 	pop	ar2
                           1161 ;	../../Platform/nano/debug.c:186: return ptr;
                           1162 ;	genRet
   3AF5 8A 82              1163 	mov	dpl,r2
   3AF7 8B 83              1164 	mov	dph,r3
   3AF9 8C F0              1165 	mov	b,r4
                           1166 ;	Peephole 300	removed redundant label 00115$
   3AFB 85 10 81           1167 	mov	sp,_bp
   3AFE D0 10              1168 	pop	_bp
   3B00 22                 1169 	ret
                           1170 ;------------------------------------------------------------
                           1171 ;Allocation info for local variables in function 'debug_send'
                           1172 ;------------------------------------------------------------
                           1173 ;length                    Allocated to stack - offset -3
                           1174 ;buffer                    Allocated to stack - offset 1
                           1175 ;i                         Allocated to registers r5 
                           1176 ;------------------------------------------------------------
                           1177 ;	../../Platform/nano/debug.c:199: int8_t debug_send(uint8_t *buffer, uint8_t length)
                           1178 ;	-----------------------------------------
                           1179 ;	 function debug_send
                           1180 ;	-----------------------------------------
   3B01                    1181 _debug_send:
   3B01 C0 10              1182 	push	_bp
   3B03 85 81 10           1183 	mov	_bp,sp
                           1184 ;     genReceive
   3B06 C0 82              1185 	push	dpl
   3B08 C0 83              1186 	push	dph
   3B0A C0 F0              1187 	push	b
                           1188 ;	../../Platform/nano/debug.c:201: uint8_t i = 0;
                           1189 ;	genAssign
   3B0C 7D 00              1190 	mov	r5,#0x00
                           1191 ;	../../Platform/nano/debug.c:203: while(i < length)
                           1192 ;	genAssign
   3B0E 7E 00              1193 	mov	r6,#0x00
   3B10                    1194 00103$:
                           1195 ;	genCmpLt
   3B10 A8 10              1196 	mov	r0,_bp
   3B12 18                 1197 	dec	r0
   3B13 18                 1198 	dec	r0
   3B14 18                 1199 	dec	r0
                           1200 ;	genCmp
   3B15 C3                 1201 	clr	c
   3B16 EE                 1202 	mov	a,r6
   3B17 96                 1203 	subb	a,@r0
                           1204 ;	genIfxJump
                           1205 ;	Peephole 108.a	removed ljmp by inverse jump logic
   3B18 50 3A              1206 	jnc	00105$
                           1207 ;	Peephole 300	removed redundant label 00111$
                           1208 ;	../../Platform/nano/debug.c:205: if (debug_put(buffer[i]) == -1)
                           1209 ;	genIpush
   3B1A C0 05              1210 	push	ar5
                           1211 ;	genPlus
   3B1C A8 10              1212 	mov	r0,_bp
   3B1E 08                 1213 	inc	r0
                           1214 ;	Peephole 236.g	used r6 instead of ar6
   3B1F EE                 1215 	mov	a,r6
   3B20 26                 1216 	add	a,@r0
   3B21 FF                 1217 	mov	r7,a
                           1218 ;	Peephole 181	changed mov to clr
   3B22 E4                 1219 	clr	a
   3B23 08                 1220 	inc	r0
   3B24 36                 1221 	addc	a,@r0
   3B25 FD                 1222 	mov	r5,a
   3B26 08                 1223 	inc	r0
   3B27 86 02              1224 	mov	ar2,@r0
                           1225 ;	genPointerGet
                           1226 ;	genGenPointerGet
   3B29 8F 82              1227 	mov	dpl,r7
   3B2B 8D 83              1228 	mov	dph,r5
   3B2D 8A F0              1229 	mov	b,r2
   3B2F 12 E4 9F           1230 	lcall	__gptrget
                           1231 ;	genCall
   3B32 FF                 1232 	mov	r7,a
                           1233 ;	Peephole 244.c	loading dpl from a instead of r7
   3B33 F5 82              1234 	mov	dpl,a
   3B35 C0 05              1235 	push	ar5
   3B37 C0 06              1236 	push	ar6
   3B39 12 38 E3           1237 	lcall	_debug_put
   3B3C AA 82              1238 	mov	r2,dpl
   3B3E D0 06              1239 	pop	ar6
   3B40 D0 05              1240 	pop	ar5
                           1241 ;	genCmpEq
                           1242 ;	gencjne
                           1243 ;	gencjneshort
                           1244 ;	Peephole 241.d	optimized compare
   3B42 E4                 1245 	clr	a
   3B43 BA FF 01           1246 	cjne	r2,#0xFF,00112$
   3B46 04                 1247 	inc	a
   3B47                    1248 00112$:
                           1249 ;	Peephole 300	removed redundant label 00113$
                           1250 ;	genIpop
   3B47 D0 05              1251 	pop	ar5
                           1252 ;	genIfx
                           1253 ;	genIfxJump
                           1254 ;	Peephole 108.c	removed ljmp by inverse jump logic
   3B49 60 04              1255 	jz	00102$
                           1256 ;	Peephole 300	removed redundant label 00114$
                           1257 ;	../../Platform/nano/debug.c:207: return i;
                           1258 ;	genRet
   3B4B 8D 82              1259 	mov	dpl,r5
                           1260 ;	Peephole 112.b	changed ljmp to sjmp
   3B4D 80 07              1261 	sjmp	00106$
   3B4F                    1262 00102$:
                           1263 ;	../../Platform/nano/debug.c:209: i++;
                           1264 ;	genPlus
                           1265 ;     genPlusIncr
   3B4F 0E                 1266 	inc	r6
                           1267 ;	genAssign
   3B50 8E 05              1268 	mov	ar5,r6
                           1269 ;	Peephole 112.b	changed ljmp to sjmp
   3B52 80 BC              1270 	sjmp	00103$
   3B54                    1271 00105$:
                           1272 ;	../../Platform/nano/debug.c:211: return i;
                           1273 ;	genRet
   3B54 8D 82              1274 	mov	dpl,r5
   3B56                    1275 00106$:
   3B56 85 10 81           1276 	mov	sp,_bp
   3B59 D0 10              1277 	pop	_bp
   3B5B 22                 1278 	ret
                           1279 ;------------------------------------------------------------
                           1280 ;Allocation info for local variables in function 'debug_address'
                           1281 ;------------------------------------------------------------
                           1282 ;addr                      Allocated to registers r2 r3 r4 
                           1283 ;i                         Allocated to registers r2 
                           1284 ;ptr                       Allocated to registers r5 r6 r7 
                           1285 ;sloc0                     Allocated to stack - offset 1
                           1286 ;------------------------------------------------------------
                           1287 ;	../../Platform/nano/debug.c:220: void debug_address(sockaddr_t *addr)
                           1288 ;	-----------------------------------------
                           1289 ;	 function debug_address
                           1290 ;	-----------------------------------------
   3B5C                    1291 _debug_address:
   3B5C C0 10              1292 	push	_bp
   3B5E 85 81 10           1293 	mov	_bp,sp
   3B61 05 81              1294 	inc	sp
   3B63 05 81              1295 	inc	sp
   3B65 05 81              1296 	inc	sp
                           1297 ;	genReceive
   3B67 AA 82              1298 	mov	r2,dpl
   3B69 AB 83              1299 	mov	r3,dph
   3B6B AC F0              1300 	mov	r4,b
                           1301 ;	../../Platform/nano/debug.c:225: ptr = addr->address;
                           1302 ;	genPlus
                           1303 ;     genPlusIncr
   3B6D 74 01              1304 	mov	a,#0x01
                           1305 ;	Peephole 236.a	used r2 instead of ar2
   3B6F 2A                 1306 	add	a,r2
   3B70 FD                 1307 	mov	r5,a
                           1308 ;	Peephole 181	changed mov to clr
   3B71 E4                 1309 	clr	a
                           1310 ;	Peephole 236.b	used r3 instead of ar3
   3B72 3B                 1311 	addc	a,r3
   3B73 FE                 1312 	mov	r6,a
   3B74 8C 07              1313 	mov	ar7,r4
                           1314 ;	../../Platform/nano/debug.c:226: switch (addr->addr_type)
                           1315 ;	genPointerGet
                           1316 ;	genGenPointerGet
   3B76 8A 82              1317 	mov	dpl,r2
   3B78 8B 83              1318 	mov	dph,r3
   3B7A 8C F0              1319 	mov	b,r4
   3B7C 12 E4 9F           1320 	lcall	__gptrget
   3B7F FA                 1321 	mov	r2,a
                           1322 ;	genCmpEq
                           1323 ;	gencjneshort
   3B80 BA 01 03           1324 	cjne	r2,#0x01,00134$
   3B83 02 3C 23           1325 	ljmp	00102$
   3B86                    1326 00134$:
                           1327 ;	genCmpEq
                           1328 ;	gencjneshort
   3B86 BA 02 03           1329 	cjne	r2,#0x02,00135$
   3B89 02 3D 09           1330 	ljmp	00106$
   3B8C                    1331 00135$:
                           1332 ;	genCmpEq
                           1333 ;	gencjneshort
   3B8C BA 03 03           1334 	cjne	r2,#0x03,00136$
   3B8F 02 3C 86           1335 	ljmp	00105$
   3B92                    1336 00136$:
                           1337 ;	genCmpEq
                           1338 ;	gencjneshort
   3B92 BA 04 02           1339 	cjne	r2,#0x04,00137$
                           1340 ;	Peephole 112.b	changed ljmp to sjmp
   3B95 80 09              1341 	sjmp	00101$
   3B97                    1342 00137$:
                           1343 ;	genCmpEq
                           1344 ;	gencjneshort
   3B97 BA 08 03           1345 	cjne	r2,#0x08,00138$
   3B9A 02 3D 69           1346 	ljmp	00109$
   3B9D                    1347 00138$:
   3B9D 02 3D 6F           1348 	ljmp	00119$
                           1349 ;	../../Platform/nano/debug.c:228: case ADDR_802_15_4_PAN_LONG:
   3BA0                    1350 00101$:
                           1351 ;	../../Platform/nano/debug.c:229: ptr += 8;
                           1352 ;	genPlus
                           1353 ;     genPlusIncr
   3BA0 74 08              1354 	mov	a,#0x08
                           1355 ;	Peephole 236.a	used r5 instead of ar5
   3BA2 2D                 1356 	add	a,r5
   3BA3 FD                 1357 	mov	r5,a
                           1358 ;	Peephole 181	changed mov to clr
   3BA4 E4                 1359 	clr	a
                           1360 ;	Peephole 236.b	used r6 instead of ar6
   3BA5 3E                 1361 	addc	a,r6
   3BA6 FE                 1362 	mov	r6,a
                           1363 ;	../../Platform/nano/debug.c:230: debug_hex(*ptr++);
                           1364 ;	genPointerGet
                           1365 ;	genGenPointerGet
   3BA7 8D 82              1366 	mov	dpl,r5
   3BA9 8E 83              1367 	mov	dph,r6
   3BAB 8F F0              1368 	mov	b,r7
   3BAD 12 E4 9F           1369 	lcall	__gptrget
   3BB0 FA                 1370 	mov	r2,a
   3BB1 A3                 1371 	inc	dptr
   3BB2 AD 82              1372 	mov	r5,dpl
   3BB4 AE 83              1373 	mov	r6,dph
                           1374 ;	genCast
   3BB6 7B 00              1375 	mov	r3,#0x00
                           1376 ;	genIpush
   3BB8 C0 05              1377 	push	ar5
   3BBA C0 06              1378 	push	ar6
   3BBC C0 07              1379 	push	ar7
   3BBE C0 02              1380 	push	ar2
   3BC0 C0 03              1381 	push	ar3
                           1382 ;	genIpush
   3BC2 74 10              1383 	mov	a,#0x10
   3BC4 C0 E0              1384 	push	acc
                           1385 ;	genCall
   3BC6 75 82 02           1386 	mov	dpl,#0x02
   3BC9 12 39 23           1387 	lcall	_debug_integer
   3BCC 15 81              1388 	dec	sp
   3BCE 15 81              1389 	dec	sp
   3BD0 15 81              1390 	dec	sp
   3BD2 D0 07              1391 	pop	ar7
   3BD4 D0 06              1392 	pop	ar6
   3BD6 D0 05              1393 	pop	ar5
                           1394 ;	../../Platform/nano/debug.c:231: debug_hex(*ptr++);
                           1395 ;	genPointerGet
                           1396 ;	genGenPointerGet
   3BD8 8D 82              1397 	mov	dpl,r5
   3BDA 8E 83              1398 	mov	dph,r6
   3BDC 8F F0              1399 	mov	b,r7
   3BDE 12 E4 9F           1400 	lcall	__gptrget
   3BE1 FA                 1401 	mov	r2,a
   3BE2 A3                 1402 	inc	dptr
   3BE3 AD 82              1403 	mov	r5,dpl
   3BE5 AE 83              1404 	mov	r6,dph
                           1405 ;	genCast
   3BE7 7B 00              1406 	mov	r3,#0x00
                           1407 ;	genIpush
   3BE9 C0 05              1408 	push	ar5
   3BEB C0 06              1409 	push	ar6
   3BED C0 07              1410 	push	ar7
   3BEF C0 02              1411 	push	ar2
   3BF1 C0 03              1412 	push	ar3
                           1413 ;	genIpush
   3BF3 74 10              1414 	mov	a,#0x10
   3BF5 C0 E0              1415 	push	acc
                           1416 ;	genCall
   3BF7 75 82 02           1417 	mov	dpl,#0x02
   3BFA 12 39 23           1418 	lcall	_debug_integer
   3BFD 15 81              1419 	dec	sp
   3BFF 15 81              1420 	dec	sp
   3C01 15 81              1421 	dec	sp
   3C03 D0 07              1422 	pop	ar7
   3C05 D0 06              1423 	pop	ar6
   3C07 D0 05              1424 	pop	ar5
                           1425 ;	../../Platform/nano/debug.c:232: debug(" ");
                           1426 ;	genCall
                           1427 ;	Peephole 182.a	used 16 bit load of DPTR
   3C09 90 E7 92           1428 	mov	dptr,#__str_0
   3C0C C0 05              1429 	push	ar5
   3C0E C0 06              1430 	push	ar6
   3C10 C0 07              1431 	push	ar7
   3C12 12 38 E8           1432 	lcall	_debug_constant
   3C15 D0 07              1433 	pop	ar7
   3C17 D0 06              1434 	pop	ar6
   3C19 D0 05              1435 	pop	ar5
                           1436 ;	../../Platform/nano/debug.c:233: ptr -= 10;
                           1437 ;	genMinus
   3C1B ED                 1438 	mov	a,r5
   3C1C 24 F6              1439 	add	a,#0xf6
   3C1E FD                 1440 	mov	r5,a
   3C1F EE                 1441 	mov	a,r6
   3C20 34 FF              1442 	addc	a,#0xff
   3C22 FE                 1443 	mov	r6,a
                           1444 ;	../../Platform/nano/debug.c:234: case ADDR_802_15_4_LONG:
   3C23                    1445 00102$:
                           1446 ;	../../Platform/nano/debug.c:235: ptr += 8;
                           1447 ;	genPlus
                           1448 ;     genPlusIncr
   3C23 74 08              1449 	mov	a,#0x08
                           1450 ;	Peephole 236.a	used r5 instead of ar5
   3C25 2D                 1451 	add	a,r5
   3C26 FD                 1452 	mov	r5,a
                           1453 ;	Peephole 181	changed mov to clr
   3C27 E4                 1454 	clr	a
                           1455 ;	Peephole 236.b	used r6 instead of ar6
   3C28 3E                 1456 	addc	a,r6
   3C29 FE                 1457 	mov	r6,a
                           1458 ;	../../Platform/nano/debug.c:236: for (i=0; i<8; i++)
                           1459 ;	genAssign
   3C2A A8 10              1460 	mov	r0,_bp
   3C2C 08                 1461 	inc	r0
   3C2D A6 05              1462 	mov	@r0,ar5
   3C2F 08                 1463 	inc	r0
   3C30 A6 06              1464 	mov	@r0,ar6
   3C32 08                 1465 	inc	r0
   3C33 A6 07              1466 	mov	@r0,ar7
                           1467 ;	genAssign
   3C35 7A 00              1468 	mov	r2,#0x00
   3C37                    1469 00112$:
                           1470 ;	genCmpLt
                           1471 ;	genCmp
   3C37 BA 08 00           1472 	cjne	r2,#0x08,00139$
   3C3A                    1473 00139$:
                           1474 ;	genIfxJump
   3C3A 40 03              1475 	jc	00140$
   3C3C 02 3D 6F           1476 	ljmp	00119$
   3C3F                    1477 00140$:
                           1478 ;	../../Platform/nano/debug.c:238: debug_hex(*--ptr);
                           1479 ;	genMinus
   3C3F A8 10              1480 	mov	r0,_bp
   3C41 08                 1481 	inc	r0
                           1482 ;	genMinusDec
   3C42 E6                 1483 	mov	a,@r0
   3C43 24 FF              1484 	add	a,#0xff
   3C45 F6                 1485 	mov	@r0,a
   3C46 08                 1486 	inc	r0
   3C47 E6                 1487 	mov	a,@r0
   3C48 34 FF              1488 	addc	a,#0xff
   3C4A F6                 1489 	mov	@r0,a
                           1490 ;	genPointerGet
                           1491 ;	genGenPointerGet
   3C4B A8 10              1492 	mov	r0,_bp
   3C4D 08                 1493 	inc	r0
   3C4E 86 82              1494 	mov	dpl,@r0
   3C50 08                 1495 	inc	r0
   3C51 86 83              1496 	mov	dph,@r0
   3C53 08                 1497 	inc	r0
   3C54 86 F0              1498 	mov	b,@r0
   3C56 12 E4 9F           1499 	lcall	__gptrget
   3C59 FB                 1500 	mov	r3,a
                           1501 ;	genCast
   3C5A 7C 00              1502 	mov	r4,#0x00
                           1503 ;	genIpush
   3C5C C0 02              1504 	push	ar2
   3C5E C0 03              1505 	push	ar3
   3C60 C0 04              1506 	push	ar4
                           1507 ;	genIpush
   3C62 74 10              1508 	mov	a,#0x10
   3C64 C0 E0              1509 	push	acc
                           1510 ;	genCall
   3C66 75 82 02           1511 	mov	dpl,#0x02
   3C69 12 39 23           1512 	lcall	_debug_integer
   3C6C 15 81              1513 	dec	sp
   3C6E 15 81              1514 	dec	sp
   3C70 15 81              1515 	dec	sp
   3C72 D0 02              1516 	pop	ar2
                           1517 ;	../../Platform/nano/debug.c:239: if (i < 7) debug(":");
                           1518 ;	genCmpLt
                           1519 ;	genCmp
   3C74 BA 07 00           1520 	cjne	r2,#0x07,00141$
   3C77                    1521 00141$:
                           1522 ;	genIfxJump
                           1523 ;	Peephole 108.a	removed ljmp by inverse jump logic
   3C77 50 0A              1524 	jnc	00114$
                           1525 ;	Peephole 300	removed redundant label 00142$
                           1526 ;	genCall
                           1527 ;	Peephole 182.a	used 16 bit load of DPTR
   3C79 90 E7 94           1528 	mov	dptr,#__str_1
   3C7C C0 02              1529 	push	ar2
   3C7E 12 38 E8           1530 	lcall	_debug_constant
   3C81 D0 02              1531 	pop	ar2
   3C83                    1532 00114$:
                           1533 ;	../../Platform/nano/debug.c:236: for (i=0; i<8; i++)
                           1534 ;	genPlus
                           1535 ;     genPlusIncr
   3C83 0A                 1536 	inc	r2
                           1537 ;	../../Platform/nano/debug.c:242: case ADDR_802_15_4_PAN_SHORT:
                           1538 ;	Peephole 112.b	changed ljmp to sjmp
   3C84 80 B1              1539 	sjmp	00112$
   3C86                    1540 00105$:
                           1541 ;	../../Platform/nano/debug.c:243: ptr += 2;
                           1542 ;	genPlus
                           1543 ;     genPlusIncr
   3C86 74 02              1544 	mov	a,#0x02
                           1545 ;	Peephole 236.a	used r5 instead of ar5
   3C88 2D                 1546 	add	a,r5
   3C89 FD                 1547 	mov	r5,a
                           1548 ;	Peephole 181	changed mov to clr
   3C8A E4                 1549 	clr	a
                           1550 ;	Peephole 236.b	used r6 instead of ar6
   3C8B 3E                 1551 	addc	a,r6
   3C8C FE                 1552 	mov	r6,a
                           1553 ;	../../Platform/nano/debug.c:244: debug_hex(*ptr++);
                           1554 ;	genPointerGet
                           1555 ;	genGenPointerGet
   3C8D 8D 82              1556 	mov	dpl,r5
   3C8F 8E 83              1557 	mov	dph,r6
   3C91 8F F0              1558 	mov	b,r7
   3C93 12 E4 9F           1559 	lcall	__gptrget
   3C96 FA                 1560 	mov	r2,a
   3C97 A3                 1561 	inc	dptr
   3C98 AD 82              1562 	mov	r5,dpl
   3C9A AE 83              1563 	mov	r6,dph
                           1564 ;	genCast
   3C9C 7B 00              1565 	mov	r3,#0x00
                           1566 ;	genIpush
   3C9E C0 05              1567 	push	ar5
   3CA0 C0 06              1568 	push	ar6
   3CA2 C0 07              1569 	push	ar7
   3CA4 C0 02              1570 	push	ar2
   3CA6 C0 03              1571 	push	ar3
                           1572 ;	genIpush
   3CA8 74 10              1573 	mov	a,#0x10
   3CAA C0 E0              1574 	push	acc
                           1575 ;	genCall
   3CAC 75 82 02           1576 	mov	dpl,#0x02
   3CAF 12 39 23           1577 	lcall	_debug_integer
   3CB2 15 81              1578 	dec	sp
   3CB4 15 81              1579 	dec	sp
   3CB6 15 81              1580 	dec	sp
   3CB8 D0 07              1581 	pop	ar7
   3CBA D0 06              1582 	pop	ar6
   3CBC D0 05              1583 	pop	ar5
                           1584 ;	../../Platform/nano/debug.c:245: debug_hex(*ptr++);
                           1585 ;	genPointerGet
                           1586 ;	genGenPointerGet
   3CBE 8D 82              1587 	mov	dpl,r5
   3CC0 8E 83              1588 	mov	dph,r6
   3CC2 8F F0              1589 	mov	b,r7
   3CC4 12 E4 9F           1590 	lcall	__gptrget
   3CC7 FA                 1591 	mov	r2,a
   3CC8 A3                 1592 	inc	dptr
   3CC9 AD 82              1593 	mov	r5,dpl
   3CCB AE 83              1594 	mov	r6,dph
                           1595 ;	genCast
   3CCD 7B 00              1596 	mov	r3,#0x00
                           1597 ;	genIpush
   3CCF C0 05              1598 	push	ar5
   3CD1 C0 06              1599 	push	ar6
   3CD3 C0 07              1600 	push	ar7
   3CD5 C0 02              1601 	push	ar2
   3CD7 C0 03              1602 	push	ar3
                           1603 ;	genIpush
   3CD9 74 10              1604 	mov	a,#0x10
   3CDB C0 E0              1605 	push	acc
                           1606 ;	genCall
   3CDD 75 82 02           1607 	mov	dpl,#0x02
   3CE0 12 39 23           1608 	lcall	_debug_integer
   3CE3 15 81              1609 	dec	sp
   3CE5 15 81              1610 	dec	sp
   3CE7 15 81              1611 	dec	sp
   3CE9 D0 07              1612 	pop	ar7
   3CEB D0 06              1613 	pop	ar6
   3CED D0 05              1614 	pop	ar5
                           1615 ;	../../Platform/nano/debug.c:246: debug(" ");
                           1616 ;	genCall
                           1617 ;	Peephole 182.a	used 16 bit load of DPTR
   3CEF 90 E7 92           1618 	mov	dptr,#__str_0
   3CF2 C0 05              1619 	push	ar5
   3CF4 C0 06              1620 	push	ar6
   3CF6 C0 07              1621 	push	ar7
   3CF8 12 38 E8           1622 	lcall	_debug_constant
   3CFB D0 07              1623 	pop	ar7
   3CFD D0 06              1624 	pop	ar6
   3CFF D0 05              1625 	pop	ar5
                           1626 ;	../../Platform/nano/debug.c:247: ptr -= 4;
                           1627 ;	genMinus
                           1628 ;	genMinusDec
   3D01 ED                 1629 	mov	a,r5
   3D02 24 FC              1630 	add	a,#0xfc
   3D04 FD                 1631 	mov	r5,a
   3D05 EE                 1632 	mov	a,r6
   3D06 34 FF              1633 	addc	a,#0xff
   3D08 FE                 1634 	mov	r6,a
                           1635 ;	../../Platform/nano/debug.c:248: case ADDR_802_15_4_SHORT:
   3D09                    1636 00106$:
                           1637 ;	../../Platform/nano/debug.c:249: ptr += 2;
                           1638 ;	genPlus
                           1639 ;     genPlusIncr
   3D09 74 02              1640 	mov	a,#0x02
                           1641 ;	Peephole 236.a	used r5 instead of ar5
   3D0B 2D                 1642 	add	a,r5
   3D0C FD                 1643 	mov	r5,a
                           1644 ;	Peephole 181	changed mov to clr
   3D0D E4                 1645 	clr	a
                           1646 ;	Peephole 236.b	used r6 instead of ar6
   3D0E 3E                 1647 	addc	a,r6
   3D0F FE                 1648 	mov	r6,a
                           1649 ;	../../Platform/nano/debug.c:250: for (i=0; i<2; i++)
                           1650 ;	genAssign
   3D10 7A 02              1651 	mov	r2,#0x02
                           1652 ;	genAssign
   3D12 8E 04              1653 	mov	ar4,r6
   3D14 8F 03              1654 	mov	ar3,r7
   3D16                    1655 00118$:
                           1656 ;	../../Platform/nano/debug.c:252: debug_hex(*--ptr);
                           1657 ;	genMinus
                           1658 ;	genMinusDec
   3D16 1D                 1659 	dec	r5
   3D17 BD FF 01           1660 	cjne	r5,#0xff,00143$
   3D1A 1C                 1661 	dec	r4
   3D1B                    1662 00143$:
                           1663 ;	genPointerGet
                           1664 ;	genGenPointerGet
   3D1B 8D 82              1665 	mov	dpl,r5
   3D1D 8C 83              1666 	mov	dph,r4
   3D1F 8B F0              1667 	mov	b,r3
   3D21 12 E4 9F           1668 	lcall	__gptrget
   3D24 FE                 1669 	mov	r6,a
                           1670 ;	genCast
   3D25 7F 00              1671 	mov	r7,#0x00
                           1672 ;	genIpush
   3D27 C0 02              1673 	push	ar2
   3D29 C0 03              1674 	push	ar3
   3D2B C0 04              1675 	push	ar4
   3D2D C0 05              1676 	push	ar5
   3D2F C0 06              1677 	push	ar6
   3D31 C0 07              1678 	push	ar7
                           1679 ;	genIpush
   3D33 74 10              1680 	mov	a,#0x10
   3D35 C0 E0              1681 	push	acc
                           1682 ;	genCall
   3D37 75 82 02           1683 	mov	dpl,#0x02
   3D3A 12 39 23           1684 	lcall	_debug_integer
   3D3D 15 81              1685 	dec	sp
   3D3F 15 81              1686 	dec	sp
   3D41 15 81              1687 	dec	sp
   3D43 D0 05              1688 	pop	ar5
   3D45 D0 04              1689 	pop	ar4
   3D47 D0 03              1690 	pop	ar3
   3D49 D0 02              1691 	pop	ar2
                           1692 ;	../../Platform/nano/debug.c:253: if (i == 0) debug(":");
                           1693 ;	genMinus
                           1694 ;	genMinusDec
   3D4B EA                 1695 	mov	a,r2
   3D4C 14                 1696 	dec	a
                           1697 ;	genIfx
                           1698 ;	genIfxJump
                           1699 ;	Peephole 108.b	removed ljmp by inverse jump logic
   3D4D 70 16              1700 	jnz	00108$
                           1701 ;	Peephole 300	removed redundant label 00144$
                           1702 ;	genCall
                           1703 ;	Peephole 182.a	used 16 bit load of DPTR
   3D4F 90 E7 94           1704 	mov	dptr,#__str_1
   3D52 C0 02              1705 	push	ar2
   3D54 C0 03              1706 	push	ar3
   3D56 C0 04              1707 	push	ar4
   3D58 C0 05              1708 	push	ar5
   3D5A 12 38 E8           1709 	lcall	_debug_constant
   3D5D D0 05              1710 	pop	ar5
   3D5F D0 04              1711 	pop	ar4
   3D61 D0 03              1712 	pop	ar3
   3D63 D0 02              1713 	pop	ar2
   3D65                    1714 00108$:
                           1715 ;	genDjnz
                           1716 ;	Peephole 112.b	changed ljmp to sjmp
                           1717 ;	Peephole 205	optimized misc jump sequence
   3D65 DA AF              1718 	djnz	r2,00118$
                           1719 ;	Peephole 300	removed redundant label 00145$
                           1720 ;	Peephole 300	removed redundant label 00146$
                           1721 ;	../../Platform/nano/debug.c:250: for (i=0; i<2; i++)
                           1722 ;	../../Platform/nano/debug.c:255: break;
                           1723 ;	../../Platform/nano/debug.c:256: case ADDR_BROADCAST:
                           1724 ;	Peephole 112.b	changed ljmp to sjmp
   3D67 80 06              1725 	sjmp	00119$
   3D69                    1726 00109$:
                           1727 ;	../../Platform/nano/debug.c:257: debug("Broadcast");
                           1728 ;	genCall
                           1729 ;	Peephole 182.a	used 16 bit load of DPTR
   3D69 90 E7 96           1730 	mov	dptr,#__str_2
   3D6C 12 38 E8           1731 	lcall	_debug_constant
                           1732 ;	../../Platform/nano/debug.c:261: }
   3D6F                    1733 00119$:
   3D6F 85 10 81           1734 	mov	sp,_bp
   3D72 D0 10              1735 	pop	_bp
   3D74 22                 1736 	ret
                           1737 	.area CSEG    (CODE)
                           1738 	.area CONST   (CODE)
   E782                    1739 _debug_hex_table:
   E782 30                 1740 	.db #0x30
   E783 31                 1741 	.db #0x31
   E784 32                 1742 	.db #0x32
   E785 33                 1743 	.db #0x33
   E786 34                 1744 	.db #0x34
   E787 35                 1745 	.db #0x35
   E788 36                 1746 	.db #0x36
   E789 37                 1747 	.db #0x37
   E78A 38                 1748 	.db #0x38
   E78B 39                 1749 	.db #0x39
   E78C 41                 1750 	.db #0x41
   E78D 42                 1751 	.db #0x42
   E78E 43                 1752 	.db #0x43
   E78F 44                 1753 	.db #0x44
   E790 45                 1754 	.db #0x45
   E791 46                 1755 	.db #0x46
   E792                    1756 __str_0:
   E792 20                 1757 	.ascii " "
   E793 00                 1758 	.db 0x00
   E794                    1759 __str_1:
   E794 3A                 1760 	.ascii ":"
   E795 00                 1761 	.db 0x00
   E796                    1762 __str_2:
   E796 42 72 6F 61 64 63  1763 	.ascii "Broadcast"
        61 73 74
   E79F 00                 1764 	.db 0x00
                           1765 	.area XINIT   (CODE)
