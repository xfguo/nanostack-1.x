                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Nov 10 2006)
                              4 ; This file generated Fri Feb  1 13:33:37 2008
                              5 ;--------------------------------------------------------
                              6 	.module bus
                              7 	.optsdcc -mmcs51 --model-large
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _IRCON2_P2IF
                             13 	.globl _IRCON2_UTX0IF
                             14 	.globl _IRCON2_UTX1IF
                             15 	.globl _IRCON2_P1IF
                             16 	.globl _IRCON2_WDTIF
                             17 	.globl _CY
                             18 	.globl _AC
                             19 	.globl _F0
                             20 	.globl _RS1
                             21 	.globl _RS0
                             22 	.globl _OV
                             23 	.globl _F1
                             24 	.globl _P
                             25 	.globl _IRCON_DMAIF
                             26 	.globl _IRCON_T1IF
                             27 	.globl _IRCON_T2IF
                             28 	.globl _IRCON_T3IF
                             29 	.globl _IRCON_T4IF
                             30 	.globl _IRCON_P0IF
                             31 	.globl _IRCON_STIF
                             32 	.globl _IEN1_DMAIE
                             33 	.globl _IEN1_T1IE
                             34 	.globl _IEN1_T2IE
                             35 	.globl _IEN1_T3IE
                             36 	.globl _IEN1_T4IE
                             37 	.globl _IEN1_P0IE
                             38 	.globl _IEN0_RFERRIE
                             39 	.globl _IEN0_ADCIE
                             40 	.globl _IEN0_URX0IE
                             41 	.globl _IEN0_URX1IE
                             42 	.globl _IEN0_ENCIE
                             43 	.globl _IEN0_STIE
                             44 	.globl _IEN0_EA
                             45 	.globl _EA
                             46 	.globl _P2_4
                             47 	.globl _P2_3
                             48 	.globl _P2_2
                             49 	.globl _P2_1
                             50 	.globl _P2_0
                             51 	.globl _S0CON_ENCIF_0
                             52 	.globl _S0CON_ENCIF_1
                             53 	.globl _P1_7
                             54 	.globl _P1_6
                             55 	.globl _P1_5
                             56 	.globl _P1_4
                             57 	.globl _P1_3
                             58 	.globl _P1_2
                             59 	.globl _P1_1
                             60 	.globl _P1_0
                             61 	.globl _TCON_IT0
                             62 	.globl _TCON_RFERRIF
                             63 	.globl _TCON_IT1
                             64 	.globl _TCON_URX0IF
                             65 	.globl _TCON_ADCIF
                             66 	.globl _TCON_URX1IF
                             67 	.globl _P0_0
                             68 	.globl _P0_1
                             69 	.globl _P0_2
                             70 	.globl _P0_3
                             71 	.globl _P0_4
                             72 	.globl _P0_5
                             73 	.globl _P0_6
                             74 	.globl _P0_7
                             75 	.globl _P2DIR
                             76 	.globl _P1DIR
                             77 	.globl _P0DIR
                             78 	.globl _U1GCR
                             79 	.globl _U1UCR
                             80 	.globl _U1BAUD
                             81 	.globl _U1BUF
                             82 	.globl _U1CSR
                             83 	.globl _P2INP
                             84 	.globl _P1INP
                             85 	.globl _P2SEL
                             86 	.globl _P1SEL
                             87 	.globl _P0SEL
                             88 	.globl _ADCCFG
                             89 	.globl _PERCFG
                             90 	.globl _B
                             91 	.globl _T4CC1
                             92 	.globl _T4CCTL1
                             93 	.globl _T4CC0
                             94 	.globl _T4CCTL0
                             95 	.globl _T4CTL
                             96 	.globl _T4CNT
                             97 	.globl _RFIF
                             98 	.globl _IRCON2
                             99 	.globl _T1CCTL2
                            100 	.globl _T1CCTL1
                            101 	.globl _T1CCTL0
                            102 	.globl _T1CTL
                            103 	.globl _T1CNTH
                            104 	.globl _T1CNTL
                            105 	.globl _RFST
                            106 	.globl _ACC
                            107 	.globl _T1CC2H
                            108 	.globl _T1CC2L
                            109 	.globl _T1CC1H
                            110 	.globl _T1CC1L
                            111 	.globl _T1CC0H
                            112 	.globl _T1CC0L
                            113 	.globl _RFD
                            114 	.globl _TIMIF
                            115 	.globl _DMAREQ
                            116 	.globl _DMAARM
                            117 	.globl _DMA0CFGH
                            118 	.globl _DMA0CFGL
                            119 	.globl _DMA1CFGH
                            120 	.globl _DMA1CFGL
                            121 	.globl _DMAIRQ
                            122 	.globl _PSW
                            123 	.globl _T3CC1
                            124 	.globl _T3CCTL1
                            125 	.globl _T3CC0
                            126 	.globl _T3CCTL0
                            127 	.globl _T3CTL
                            128 	.globl _T3CNT
                            129 	.globl _WDCTL
                            130 	.globl _T2CON
                            131 	.globl _MEMCTR
                            132 	.globl _CLKCON
                            133 	.globl _U0GCR
                            134 	.globl _U0UCR
                            135 	.globl _T2CNF
                            136 	.globl _U0BAUD
                            137 	.globl _U0BUF
                            138 	.globl _IRCON
                            139 	.globl _SLEEP
                            140 	.globl _RNDH
                            141 	.globl _RNDL
                            142 	.globl _ADCH
                            143 	.globl _ADCL
                            144 	.globl _IP1
                            145 	.globl _IEN1
                            146 	.globl _RCCTL
                            147 	.globl _ADCCON3
                            148 	.globl _ADCCON2
                            149 	.globl _ADCCON1
                            150 	.globl _ENCCS
                            151 	.globl _ENCDO
                            152 	.globl _ENCDI
                            153 	.globl _FWDATA
                            154 	.globl _FCTL
                            155 	.globl _FADDRH
                            156 	.globl _FADDRL
                            157 	.globl _FWT
                            158 	.globl _IP0
                            159 	.globl _IEN0
                            160 	.globl _IE
                            161 	.globl _T2THD
                            162 	.globl _T2TLD
                            163 	.globl _T2CAPHPH
                            164 	.globl _T2CAPLPL
                            165 	.globl _T2OF2
                            166 	.globl _T2OF1
                            167 	.globl _T2OF0
                            168 	.globl _P2
                            169 	.globl _T2PEROF2
                            170 	.globl _T2PEROF1
                            171 	.globl _T2PEROF0
                            172 	.globl _S1CON
                            173 	.globl _IEN2
                            174 	.globl _HSRC
                            175 	.globl _S0CON
                            176 	.globl _ST2
                            177 	.globl _ST1
                            178 	.globl _ST0
                            179 	.globl _T2CMP
                            180 	.globl __XPAGE
                            181 	.globl _DPS
                            182 	.globl _RFIM
                            183 	.globl _P1
                            184 	.globl _P0INP
                            185 	.globl _P1IEN
                            186 	.globl _PICTL
                            187 	.globl _P2IFG
                            188 	.globl _P1IFG
                            189 	.globl _P0IFG
                            190 	.globl _TCON
                            191 	.globl _PCON
                            192 	.globl _U0CSR
                            193 	.globl _DPH1
                            194 	.globl _DPL1
                            195 	.globl _DPH0
                            196 	.globl _DPL0
                            197 	.globl _SP
                            198 	.globl _P0
                            199 	.globl _RFD_SHADOW
                            200 	.globl _RFSTATUS
                            201 	.globl _CHIPID
                            202 	.globl _CHVER
                            203 	.globl _FSMTC1
                            204 	.globl _RXFIFOCNT
                            205 	.globl _IOCFG3
                            206 	.globl _IOCFG2
                            207 	.globl _IOCFG1
                            208 	.globl _IOCFG0
                            209 	.globl _SHORTADDRL
                            210 	.globl _SHORTADDRH
                            211 	.globl _PANIDL
                            212 	.globl _PANIDH
                            213 	.globl _IEEE_ADDR7
                            214 	.globl _IEEE_ADDR6
                            215 	.globl _IEEE_ADDR5
                            216 	.globl _IEEE_ADDR4
                            217 	.globl _IEEE_ADDR3
                            218 	.globl _IEEE_ADDR2
                            219 	.globl _IEEE_ADDR1
                            220 	.globl _IEEE_ADDR0
                            221 	.globl _DACTSTL
                            222 	.globl _DACTSTH
                            223 	.globl _ADCTSTL
                            224 	.globl _ADCTSTH
                            225 	.globl _FSMSTATE
                            226 	.globl _AGCCTRLL
                            227 	.globl _AGCCTRLH
                            228 	.globl _MANORL
                            229 	.globl _MANORH
                            230 	.globl _MANANDL
                            231 	.globl _MANANDH
                            232 	.globl _FSMTCL
                            233 	.globl _FSMTCH
                            234 	.globl _RFPWR
                            235 	.globl _CSPT
                            236 	.globl _CSPCTRL
                            237 	.globl _CSPZ
                            238 	.globl _CSPY
                            239 	.globl _CSPX
                            240 	.globl _FSCTRLL
                            241 	.globl _FSCTRLH
                            242 	.globl _RXCTRL1L
                            243 	.globl _RXCTRL1H
                            244 	.globl _RXCTRL0L
                            245 	.globl _RXCTRL0H
                            246 	.globl _TXCTRLL
                            247 	.globl _TXCTRLH
                            248 	.globl _SYNCWORDL
                            249 	.globl _SYNCWORDH
                            250 	.globl _RSSIL
                            251 	.globl _RSSIH
                            252 	.globl _MDMCTRL1L
                            253 	.globl _MDMCTRL1H
                            254 	.globl _MDMCTRL0L
                            255 	.globl _MDMCTRL0H
                            256 	.globl _LED_INIT
                            257 	.globl _LED1_ON
                            258 	.globl _LED1_OFF
                            259 	.globl _LED2_ON
                            260 	.globl _LED2_OFF
                            261 	.globl _bus_init
                            262 	.globl _flash_read
                            263 	.globl _pause_us
                            264 	.globl _pause
                            265 ;--------------------------------------------------------
                            266 ; special function registers
                            267 ;--------------------------------------------------------
                            268 	.area RSEG    (DATA)
                    0080    269 _P0	=	0x0080
                    0081    270 _SP	=	0x0081
                    0082    271 _DPL0	=	0x0082
                    0083    272 _DPH0	=	0x0083
                    0084    273 _DPL1	=	0x0084
                    0085    274 _DPH1	=	0x0085
                    0086    275 _U0CSR	=	0x0086
                    0087    276 _PCON	=	0x0087
                    0088    277 _TCON	=	0x0088
                    0089    278 _P0IFG	=	0x0089
                    008A    279 _P1IFG	=	0x008a
                    008B    280 _P2IFG	=	0x008b
                    008C    281 _PICTL	=	0x008c
                    008D    282 _P1IEN	=	0x008d
                    008F    283 _P0INP	=	0x008f
                    0090    284 _P1	=	0x0090
                    0091    285 _RFIM	=	0x0091
                    0092    286 _DPS	=	0x0092
                    0093    287 __XPAGE	=	0x0093
                    0094    288 _T2CMP	=	0x0094
                    0095    289 _ST0	=	0x0095
                    0096    290 _ST1	=	0x0096
                    0097    291 _ST2	=	0x0097
                    0098    292 _S0CON	=	0x0098
                    0099    293 _HSRC	=	0x0099
                    009A    294 _IEN2	=	0x009a
                    009B    295 _S1CON	=	0x009b
                    009C    296 _T2PEROF0	=	0x009c
                    009D    297 _T2PEROF1	=	0x009d
                    009E    298 _T2PEROF2	=	0x009e
                    00A0    299 _P2	=	0x00a0
                    00A1    300 _T2OF0	=	0x00a1
                    00A2    301 _T2OF1	=	0x00a2
                    00A3    302 _T2OF2	=	0x00a3
                    00A4    303 _T2CAPLPL	=	0x00a4
                    00A5    304 _T2CAPHPH	=	0x00a5
                    00A6    305 _T2TLD	=	0x00a6
                    00A7    306 _T2THD	=	0x00a7
                    00A8    307 _IE	=	0x00a8
                    00A8    308 _IEN0	=	0x00a8
                    00A9    309 _IP0	=	0x00a9
                    00AB    310 _FWT	=	0x00ab
                    00AC    311 _FADDRL	=	0x00ac
                    00AD    312 _FADDRH	=	0x00ad
                    00AE    313 _FCTL	=	0x00ae
                    00AF    314 _FWDATA	=	0x00af
                    00B1    315 _ENCDI	=	0x00b1
                    00B2    316 _ENCDO	=	0x00b2
                    00B3    317 _ENCCS	=	0x00b3
                    00B4    318 _ADCCON1	=	0x00b4
                    00B5    319 _ADCCON2	=	0x00b5
                    00B6    320 _ADCCON3	=	0x00b6
                    00B7    321 _RCCTL	=	0x00b7
                    00B8    322 _IEN1	=	0x00b8
                    00B9    323 _IP1	=	0x00b9
                    00BA    324 _ADCL	=	0x00ba
                    00BB    325 _ADCH	=	0x00bb
                    00BC    326 _RNDL	=	0x00bc
                    00BD    327 _RNDH	=	0x00bd
                    00BE    328 _SLEEP	=	0x00be
                    00C0    329 _IRCON	=	0x00c0
                    00C1    330 _U0BUF	=	0x00c1
                    00C2    331 _U0BAUD	=	0x00c2
                    00C3    332 _T2CNF	=	0x00c3
                    00C4    333 _U0UCR	=	0x00c4
                    00C5    334 _U0GCR	=	0x00c5
                    00C6    335 _CLKCON	=	0x00c6
                    00C7    336 _MEMCTR	=	0x00c7
                    00C8    337 _T2CON	=	0x00c8
                    00C9    338 _WDCTL	=	0x00c9
                    00CA    339 _T3CNT	=	0x00ca
                    00CB    340 _T3CTL	=	0x00cb
                    00CC    341 _T3CCTL0	=	0x00cc
                    00CD    342 _T3CC0	=	0x00cd
                    00CE    343 _T3CCTL1	=	0x00ce
                    00CF    344 _T3CC1	=	0x00cf
                    00D0    345 _PSW	=	0x00d0
                    00D1    346 _DMAIRQ	=	0x00d1
                    00D2    347 _DMA1CFGL	=	0x00d2
                    00D3    348 _DMA1CFGH	=	0x00d3
                    00D4    349 _DMA0CFGL	=	0x00d4
                    00D5    350 _DMA0CFGH	=	0x00d5
                    00D6    351 _DMAARM	=	0x00d6
                    00D7    352 _DMAREQ	=	0x00d7
                    00D8    353 _TIMIF	=	0x00d8
                    00D9    354 _RFD	=	0x00d9
                    00DA    355 _T1CC0L	=	0x00da
                    00DB    356 _T1CC0H	=	0x00db
                    00DC    357 _T1CC1L	=	0x00dc
                    00DD    358 _T1CC1H	=	0x00dd
                    00DE    359 _T1CC2L	=	0x00de
                    00DF    360 _T1CC2H	=	0x00df
                    00E0    361 _ACC	=	0x00e0
                    00E1    362 _RFST	=	0x00e1
                    00E2    363 _T1CNTL	=	0x00e2
                    00E3    364 _T1CNTH	=	0x00e3
                    00E4    365 _T1CTL	=	0x00e4
                    00E5    366 _T1CCTL0	=	0x00e5
                    00E6    367 _T1CCTL1	=	0x00e6
                    00E7    368 _T1CCTL2	=	0x00e7
                    00E8    369 _IRCON2	=	0x00e8
                    00E9    370 _RFIF	=	0x00e9
                    00EA    371 _T4CNT	=	0x00ea
                    00EB    372 _T4CTL	=	0x00eb
                    00EC    373 _T4CCTL0	=	0x00ec
                    00ED    374 _T4CC0	=	0x00ed
                    00EE    375 _T4CCTL1	=	0x00ee
                    00EF    376 _T4CC1	=	0x00ef
                    00F0    377 _B	=	0x00f0
                    00F1    378 _PERCFG	=	0x00f1
                    00F2    379 _ADCCFG	=	0x00f2
                    00F3    380 _P0SEL	=	0x00f3
                    00F4    381 _P1SEL	=	0x00f4
                    00F5    382 _P2SEL	=	0x00f5
                    00F6    383 _P1INP	=	0x00f6
                    00F7    384 _P2INP	=	0x00f7
                    00F8    385 _U1CSR	=	0x00f8
                    00F9    386 _U1BUF	=	0x00f9
                    00FA    387 _U1BAUD	=	0x00fa
                    00FB    388 _U1UCR	=	0x00fb
                    00FC    389 _U1GCR	=	0x00fc
                    00FD    390 _P0DIR	=	0x00fd
                    00FE    391 _P1DIR	=	0x00fe
                    00FF    392 _P2DIR	=	0x00ff
                            393 ;--------------------------------------------------------
                            394 ; special function bits
                            395 ;--------------------------------------------------------
                            396 	.area RSEG    (DATA)
                    0087    397 _P0_7	=	0x0087
                    0086    398 _P0_6	=	0x0086
                    0085    399 _P0_5	=	0x0085
                    0084    400 _P0_4	=	0x0084
                    0083    401 _P0_3	=	0x0083
                    0082    402 _P0_2	=	0x0082
                    0081    403 _P0_1	=	0x0081
                    0080    404 _P0_0	=	0x0080
                    008F    405 _TCON_URX1IF	=	0x008f
                    008D    406 _TCON_ADCIF	=	0x008d
                    008B    407 _TCON_URX0IF	=	0x008b
                    008A    408 _TCON_IT1	=	0x008a
                    0089    409 _TCON_RFERRIF	=	0x0089
                    0088    410 _TCON_IT0	=	0x0088
                    0090    411 _P1_0	=	0x0090
                    0091    412 _P1_1	=	0x0091
                    0092    413 _P1_2	=	0x0092
                    0093    414 _P1_3	=	0x0093
                    0094    415 _P1_4	=	0x0094
                    0095    416 _P1_5	=	0x0095
                    0096    417 _P1_6	=	0x0096
                    0097    418 _P1_7	=	0x0097
                    0099    419 _S0CON_ENCIF_1	=	0x0099
                    0098    420 _S0CON_ENCIF_0	=	0x0098
                    00A0    421 _P2_0	=	0x00a0
                    00A1    422 _P2_1	=	0x00a1
                    00A2    423 _P2_2	=	0x00a2
                    00A3    424 _P2_3	=	0x00a3
                    00A4    425 _P2_4	=	0x00a4
                    00AF    426 _EA	=	0x00af
                    00AF    427 _IEN0_EA	=	0x00af
                    00AD    428 _IEN0_STIE	=	0x00ad
                    00AC    429 _IEN0_ENCIE	=	0x00ac
                    00AB    430 _IEN0_URX1IE	=	0x00ab
                    00AA    431 _IEN0_URX0IE	=	0x00aa
                    00A9    432 _IEN0_ADCIE	=	0x00a9
                    00A8    433 _IEN0_RFERRIE	=	0x00a8
                    00BD    434 _IEN1_P0IE	=	0x00bd
                    00BC    435 _IEN1_T4IE	=	0x00bc
                    00BB    436 _IEN1_T3IE	=	0x00bb
                    00BA    437 _IEN1_T2IE	=	0x00ba
                    00B9    438 _IEN1_T1IE	=	0x00b9
                    00B8    439 _IEN1_DMAIE	=	0x00b8
                    00C7    440 _IRCON_STIF	=	0x00c7
                    00C5    441 _IRCON_P0IF	=	0x00c5
                    00C4    442 _IRCON_T4IF	=	0x00c4
                    00C3    443 _IRCON_T3IF	=	0x00c3
                    00C2    444 _IRCON_T2IF	=	0x00c2
                    00C1    445 _IRCON_T1IF	=	0x00c1
                    00C0    446 _IRCON_DMAIF	=	0x00c0
                    00D0    447 _P	=	0x00d0
                    00D1    448 _F1	=	0x00d1
                    00D2    449 _OV	=	0x00d2
                    00D3    450 _RS0	=	0x00d3
                    00D4    451 _RS1	=	0x00d4
                    00D5    452 _F0	=	0x00d5
                    00D6    453 _AC	=	0x00d6
                    00D7    454 _CY	=	0x00d7
                    00EC    455 _IRCON2_WDTIF	=	0x00ec
                    00EB    456 _IRCON2_P1IF	=	0x00eb
                    00EA    457 _IRCON2_UTX1IF	=	0x00ea
                    00E9    458 _IRCON2_UTX0IF	=	0x00e9
                    00E8    459 _IRCON2_P2IF	=	0x00e8
                            460 ;--------------------------------------------------------
                            461 ; overlayable register banks
                            462 ;--------------------------------------------------------
                            463 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     464 	.ds 8
                            465 ;--------------------------------------------------------
                            466 ; internal ram data
                            467 ;--------------------------------------------------------
                            468 	.area DSEG    (DATA)
                            469 ;--------------------------------------------------------
                            470 ; overlayable items in internal ram 
                            471 ;--------------------------------------------------------
                            472 	.area OSEG    (OVR,DATA)
                            473 ;--------------------------------------------------------
                            474 ; indirectly addressable internal ram data
                            475 ;--------------------------------------------------------
                            476 	.area ISEG    (DATA)
                            477 ;--------------------------------------------------------
                            478 ; bit data
                            479 ;--------------------------------------------------------
                            480 	.area BSEG    (BIT)
                            481 ;--------------------------------------------------------
                            482 ; paged external ram data
                            483 ;--------------------------------------------------------
                            484 	.area PSEG    (PAG,XDATA)
                            485 ;--------------------------------------------------------
                            486 ; external ram data
                            487 ;--------------------------------------------------------
                            488 	.area XSEG    (XDATA)
                    DF02    489 _MDMCTRL0H	=	0xdf02
                    DF03    490 _MDMCTRL0L	=	0xdf03
                    DF04    491 _MDMCTRL1H	=	0xdf04
                    DF05    492 _MDMCTRL1L	=	0xdf05
                    DF06    493 _RSSIH	=	0xdf06
                    DF07    494 _RSSIL	=	0xdf07
                    DF08    495 _SYNCWORDH	=	0xdf08
                    DF09    496 _SYNCWORDL	=	0xdf09
                    DF0A    497 _TXCTRLH	=	0xdf0a
                    DF0B    498 _TXCTRLL	=	0xdf0b
                    DF0C    499 _RXCTRL0H	=	0xdf0c
                    DF0D    500 _RXCTRL0L	=	0xdf0d
                    DF0E    501 _RXCTRL1H	=	0xdf0e
                    DF0F    502 _RXCTRL1L	=	0xdf0f
                    DF10    503 _FSCTRLH	=	0xdf10
                    DF11    504 _FSCTRLL	=	0xdf11
                    DF12    505 _CSPX	=	0xdf12
                    DF13    506 _CSPY	=	0xdf13
                    DF14    507 _CSPZ	=	0xdf14
                    DF15    508 _CSPCTRL	=	0xdf15
                    DF16    509 _CSPT	=	0xdf16
                    DF17    510 _RFPWR	=	0xdf17
                    DF20    511 _FSMTCH	=	0xdf20
                    DF21    512 _FSMTCL	=	0xdf21
                    DF22    513 _MANANDH	=	0xdf22
                    DF23    514 _MANANDL	=	0xdf23
                    DF24    515 _MANORH	=	0xdf24
                    DF25    516 _MANORL	=	0xdf25
                    DF26    517 _AGCCTRLH	=	0xdf26
                    DF27    518 _AGCCTRLL	=	0xdf27
                    DF39    519 _FSMSTATE	=	0xdf39
                    DF3A    520 _ADCTSTH	=	0xdf3a
                    DF3B    521 _ADCTSTL	=	0xdf3b
                    DF3C    522 _DACTSTH	=	0xdf3c
                    DF3D    523 _DACTSTL	=	0xdf3d
                    DF43    524 _IEEE_ADDR0	=	0xdf43
                    DF44    525 _IEEE_ADDR1	=	0xdf44
                    DF45    526 _IEEE_ADDR2	=	0xdf45
                    DF46    527 _IEEE_ADDR3	=	0xdf46
                    DF47    528 _IEEE_ADDR4	=	0xdf47
                    DF48    529 _IEEE_ADDR5	=	0xdf48
                    DF49    530 _IEEE_ADDR6	=	0xdf49
                    DF4A    531 _IEEE_ADDR7	=	0xdf4a
                    DF4B    532 _PANIDH	=	0xdf4b
                    DF4C    533 _PANIDL	=	0xdf4c
                    DF4D    534 _SHORTADDRH	=	0xdf4d
                    DF4E    535 _SHORTADDRL	=	0xdf4e
                    DF4F    536 _IOCFG0	=	0xdf4f
                    DF50    537 _IOCFG1	=	0xdf50
                    DF51    538 _IOCFG2	=	0xdf51
                    DF52    539 _IOCFG3	=	0xdf52
                    DF53    540 _RXFIFOCNT	=	0xdf53
                    DF54    541 _FSMTC1	=	0xdf54
                    DF60    542 _CHVER	=	0xdf60
                    DF61    543 _CHIPID	=	0xdf61
                    DF62    544 _RFSTATUS	=	0xdf62
                    DFD9    545 _RFD_SHADOW	=	0xdfd9
                            546 ;--------------------------------------------------------
                            547 ; external initialized ram data
                            548 ;--------------------------------------------------------
                            549 	.area XISEG   (XDATA)
                            550 	.area HOME    (CODE)
                            551 	.area GSINIT0 (CODE)
                            552 	.area GSINIT1 (CODE)
                            553 	.area GSINIT2 (CODE)
                            554 	.area GSINIT3 (CODE)
                            555 	.area GSINIT4 (CODE)
                            556 	.area GSINIT5 (CODE)
                            557 	.area GSINIT  (CODE)
                            558 	.area GSFINAL (CODE)
                            559 	.area CSEG    (CODE)
                            560 ;--------------------------------------------------------
                            561 ; global & static initialisations
                            562 ;--------------------------------------------------------
                            563 	.area HOME    (CODE)
                            564 	.area GSINIT  (CODE)
                            565 	.area GSFINAL (CODE)
                            566 	.area GSINIT  (CODE)
                            567 ;--------------------------------------------------------
                            568 ; Home
                            569 ;--------------------------------------------------------
                            570 	.area HOME    (CODE)
                            571 	.area CSEG    (CODE)
                            572 ;--------------------------------------------------------
                            573 ; code
                            574 ;--------------------------------------------------------
                            575 	.area CSEG    (CODE)
                            576 ;------------------------------------------------------------
                            577 ;Allocation info for local variables in function 'LED_INIT'
                            578 ;------------------------------------------------------------
                            579 ;------------------------------------------------------------
                            580 ;	../../Platform/nano/bus.c:70: void LED_INIT(void) { P0DIR |= 0xC0; }
                            581 ;	-----------------------------------------
                            582 ;	 function LED_INIT
                            583 ;	-----------------------------------------
   373E                     584 _LED_INIT:
                    0002    585 	ar2 = 0x02
                    0003    586 	ar3 = 0x03
                    0004    587 	ar4 = 0x04
                    0005    588 	ar5 = 0x05
                    0006    589 	ar6 = 0x06
                    0007    590 	ar7 = 0x07
                    0000    591 	ar0 = 0x00
                    0001    592 	ar1 = 0x01
                            593 ;	genOr
   373E 43 FD C0            594 	orl	_P0DIR,#0xC0
                            595 ;	Peephole 300	removed redundant label 00101$
   3741 22                  596 	ret
                            597 ;------------------------------------------------------------
                            598 ;Allocation info for local variables in function 'LED1_ON'
                            599 ;------------------------------------------------------------
                            600 ;------------------------------------------------------------
                            601 ;	../../Platform/nano/bus.c:71: void LED1_ON(void) {P0_6 = 1;}
                            602 ;	-----------------------------------------
                            603 ;	 function LED1_ON
                            604 ;	-----------------------------------------
   3742                     605 _LED1_ON:
                            606 ;	genAssign
   3742 D2 86               607 	setb	_P0_6
                            608 ;	Peephole 300	removed redundant label 00101$
   3744 22                  609 	ret
                            610 ;------------------------------------------------------------
                            611 ;Allocation info for local variables in function 'LED1_OFF'
                            612 ;------------------------------------------------------------
                            613 ;------------------------------------------------------------
                            614 ;	../../Platform/nano/bus.c:72: void LED1_OFF(void) {P0_6 = 0;}
                            615 ;	-----------------------------------------
                            616 ;	 function LED1_OFF
                            617 ;	-----------------------------------------
   3745                     618 _LED1_OFF:
                            619 ;	genAssign
   3745 C2 86               620 	clr	_P0_6
                            621 ;	Peephole 300	removed redundant label 00101$
   3747 22                  622 	ret
                            623 ;------------------------------------------------------------
                            624 ;Allocation info for local variables in function 'LED2_ON'
                            625 ;------------------------------------------------------------
                            626 ;------------------------------------------------------------
                            627 ;	../../Platform/nano/bus.c:74: void LED2_ON(void) {P0_7 = 1;}
                            628 ;	-----------------------------------------
                            629 ;	 function LED2_ON
                            630 ;	-----------------------------------------
   3748                     631 _LED2_ON:
                            632 ;	genAssign
   3748 D2 87               633 	setb	_P0_7
                            634 ;	Peephole 300	removed redundant label 00101$
   374A 22                  635 	ret
                            636 ;------------------------------------------------------------
                            637 ;Allocation info for local variables in function 'LED2_OFF'
                            638 ;------------------------------------------------------------
                            639 ;------------------------------------------------------------
                            640 ;	../../Platform/nano/bus.c:75: void LED2_OFF(void) {P0_7 = 0;}
                            641 ;	-----------------------------------------
                            642 ;	 function LED2_OFF
                            643 ;	-----------------------------------------
   374B                     644 _LED2_OFF:
                            645 ;	genAssign
   374B C2 87               646 	clr	_P0_7
                            647 ;	Peephole 300	removed redundant label 00101$
   374D 22                  648 	ret
                            649 ;------------------------------------------------------------
                            650 ;Allocation info for local variables in function 'bus_init'
                            651 ;------------------------------------------------------------
                            652 ;------------------------------------------------------------
                            653 ;	../../Platform/nano/bus.c:87: portCHAR bus_init(void)
                            654 ;	-----------------------------------------
                            655 ;	 function bus_init
                            656 ;	-----------------------------------------
   374E                     657 _bus_init:
                            658 ;	../../Platform/nano/bus.c:89: LED_INIT();
                            659 ;	genCall
   374E 12 37 3E            660 	lcall	_LED_INIT
                            661 ;	../../Platform/nano/bus.c:91: CLKCON |= OSC32K;
                            662 ;	genOr
   3751 43 C6 80            663 	orl	_CLKCON,#0x80
                            664 ;	../../Platform/nano/bus.c:92: CLKCON &= ~(OSC | CLKSPD); /*Osc on*/
                            665 ;	genAnd
   3754 53 C6 BE            666 	anl	_CLKCON,#0xBE
                            667 ;	../../Platform/nano/bus.c:94: return pdTRUE;
                            668 ;	genRet
   3757 75 82 01            669 	mov	dpl,#0x01
                            670 ;	Peephole 300	removed redundant label 00101$
   375A 22                  671 	ret
                            672 ;------------------------------------------------------------
                            673 ;Allocation info for local variables in function 'flash_read'
                            674 ;------------------------------------------------------------
                            675 ;address                   Allocated to stack - offset -6
                            676 ;size                      Allocated to stack - offset -7
                            677 ;buffer                    Allocated to registers r2 r3 r4 
                            678 ;------------------------------------------------------------
                            679 ;	../../Platform/nano/bus.c:106: void flash_read(uint8_t *buffer, uint32_t address, uint8_t size)
                            680 ;	-----------------------------------------
                            681 ;	 function flash_read
                            682 ;	-----------------------------------------
   375B                     683 _flash_read:
   375B C0 10               684 	push	_bp
   375D 85 81 10            685 	mov	_bp,sp
                            686 ;	genReceive
   3760 AA 82               687 	mov	r2,dpl
   3762 AB 83               688 	mov	r3,dph
   3764 AC F0               689 	mov	r4,b
                            690 ;	../../Platform/nano/bus.c:114: portDISABLE_INTERRUPTS();
                            691 ;	genAssign
   3766 C2 AF               692 	clr	_EA
                            693 ;	../../Platform/nano/bus.c:162: _endasm;
                            694 ;	genInline
   3768 8A 82               695 	                        mov dpl, r2
   376A 8B 83               696 	                        mov dph, r3
   376C E8                  697 	                        mov a, r0
   376D C0 E0               698 	                        push acc
   376F EA                  699 	                        mov a, r2
   3770 C0 E0               700 	                        push acc
   3772 E5 10               701 	                        mov a, _bp
   3774 24 F9               702 	                        add a, #0xf9 ;stack - 7 = size
   3776 F8                  703 	                        mov r0,a
   3777 E6                  704 	                        mov a, @r0 ;r2 = size
   3778 FA                  705 	                        mov r2, a ;r2 = size
   3779 08                  706 	                        inc r0
   377A E6                  707 	                        mov a, @r0
   377B F5 84               708 	                        mov _DPL1, a ;DPTR1 = address & 0x7FFF | 0x8000
   377D 08                  709 	                        inc r0
   377E E6                  710 	                        mov a, @r0
   377F 44 80               711 	                        orl a, #0x80
   3781 F5 85               712 	                        mov _DPH1, a
   3783 08                  713 	                        inc r0 ;MEMCTR = ((address >> 15 & 3) << 4) | 0x01 (bank select)
   3784 E6                  714 	                        mov a, @r0
   3785 18                  715 	                        dec r0
   3786 13                  716 	                        rrc a
   3787 E6                  717 	                        mov a, @r0
   3788 13                  718 	                        rrc a
   3789 03                  719 	                        rr a
   378A 03                  720 	                        rr a
   378B 54 30               721 	                        anl a, #0x30
   378D 44 01               722 	                        orl a, #1
   378F F5 C7               723 	                        mov _MEMCTR,a
   3791                     724 lp1:
   3791 75 92 01            725 	                        mov _DPS, #1 ;active DPTR = 1
   3794 E4                  726 	                        clr a
   3795 93                  727 	                        movc a, @a+dptr ;read flash (DPTR1)
   3796 A3                  728 	                        inc dptr
   3797 75 92 00            729 	                        mov _DPS, #0 ;active DPTR = 0
   379A F0                  730 	                        movx @dptr,a ;write to DPTR0
   379B A3                  731 	                        inc dptr
   379C DA F3               732 	                        djnz r2,lp1 ;while (--size)
   379E 75 C7 11            733 	                        mov _MEMCTR, #0x11 ;restore bank to 1
   37A1 D0 E0               734 	                        pop acc
   37A3 FA                  735 	                        mov r2,a
   37A4 D0 E0               736 	                        pop acc
   37A6 F8                  737 	                        mov r0,a
                            738 ;	../../Platform/nano/bus.c:163: portENABLE_INTERRUPTS();
                            739 ;	genAssign
   37A7 D2 AF               740 	setb	_EA
                            741 ;	../../Platform/nano/bus.c:164: DPL1 = *buffer++;
                            742 ;	genPointerGet
                            743 ;	genGenPointerGet
   37A9 8A 82               744 	mov	dpl,r2
   37AB 8B 83               745 	mov	dph,r3
   37AD 8C F0               746 	mov	b,r4
   37AF 12 E4 9F            747 	lcall	__gptrget
   37B2 F5 84               748 	mov	_DPL1,a
                            749 ;	Peephole 300	removed redundant label 00101$
   37B4 D0 10               750 	pop	_bp
   37B6 22                  751 	ret
                            752 ;------------------------------------------------------------
                            753 ;Allocation info for local variables in function 'pause_us'
                            754 ;------------------------------------------------------------
                            755 ;time                      Allocated to registers r2 r3 
                            756 ;i                         Allocated to registers r4 r5 
                            757 ;------------------------------------------------------------
                            758 ;	../../Platform/nano/bus.c:175: void pause_us(uint16_t time)
                            759 ;	-----------------------------------------
                            760 ;	 function pause_us
                            761 ;	-----------------------------------------
   37B7                     762 _pause_us:
                            763 ;	genReceive
   37B7 AA 82               764 	mov	r2,dpl
   37B9 AB 83               765 	mov	r3,dph
                            766 ;	../../Platform/nano/bus.c:178: for (i = 0; i< time; i++)
                            767 ;	genAssign
   37BB 7C 00               768 	mov	r4,#0x00
   37BD 7D 00               769 	mov	r5,#0x00
   37BF                     770 00101$:
                            771 ;	genCmpLt
                            772 ;	genCmp
   37BF C3                  773 	clr	c
   37C0 EC                  774 	mov	a,r4
   37C1 9A                  775 	subb	a,r2
   37C2 ED                  776 	mov	a,r5
   37C3 9B                  777 	subb	a,r3
                            778 ;	genIfxJump
                            779 ;	Peephole 108.a	removed ljmp by inverse jump logic
   37C4 50 08               780 	jnc	00105$
                            781 ;	Peephole 300	removed redundant label 00110$
                            782 ;	../../Platform/nano/bus.c:180: portNOP();
                            783 ;	genInline
   37C6 00                  784 	 nop 
                            785 ;	../../Platform/nano/bus.c:178: for (i = 0; i< time; i++)
                            786 ;	genPlus
                            787 ;     genPlusIncr
                            788 ;	tail increment optimized (range 4)
   37C7 0C                  789 	inc	r4
   37C8 BC 00 F4            790 	cjne	r4,#0x00,00101$
   37CB 0D                  791 	inc	r5
                            792 ;	Peephole 112.b	changed ljmp to sjmp
   37CC 80 F1               793 	sjmp	00101$
   37CE                     794 00105$:
   37CE 22                  795 	ret
                            796 ;------------------------------------------------------------
                            797 ;Allocation info for local variables in function 'pause'
                            798 ;------------------------------------------------------------
                            799 ;time                      Allocated to registers r2 r3 
                            800 ;i                         Allocated to registers r4 r5 
                            801 ;------------------------------------------------------------
                            802 ;	../../Platform/nano/bus.c:192: void pause(uint16_t time)
                            803 ;	-----------------------------------------
                            804 ;	 function pause
                            805 ;	-----------------------------------------
   37CF                     806 _pause:
                            807 ;	genReceive
   37CF AA 82               808 	mov	r2,dpl
   37D1 AB 83               809 	mov	r3,dph
                            810 ;	../../Platform/nano/bus.c:195: for (i = 0; i< time; i++)
                            811 ;	genAssign
   37D3 7C 00               812 	mov	r4,#0x00
   37D5 7D 00               813 	mov	r5,#0x00
   37D7                     814 00101$:
                            815 ;	genCmpLt
                            816 ;	genCmp
   37D7 C3                  817 	clr	c
   37D8 EC                  818 	mov	a,r4
   37D9 9A                  819 	subb	a,r2
   37DA ED                  820 	mov	a,r5
   37DB 9B                  821 	subb	a,r3
                            822 ;	genIfxJump
                            823 ;	Peephole 108.a	removed ljmp by inverse jump logic
   37DC 50 1D               824 	jnc	00105$
                            825 ;	Peephole 300	removed redundant label 00110$
                            826 ;	../../Platform/nano/bus.c:197: pause_us(1000);
                            827 ;	genCall
                            828 ;	Peephole 182.b	used 16 bit load of dptr
   37DE 90 03 E8            829 	mov	dptr,#0x03E8
   37E1 C0 02               830 	push	ar2
   37E3 C0 03               831 	push	ar3
   37E5 C0 04               832 	push	ar4
   37E7 C0 05               833 	push	ar5
   37E9 12 37 B7            834 	lcall	_pause_us
   37EC D0 05               835 	pop	ar5
   37EE D0 04               836 	pop	ar4
   37F0 D0 03               837 	pop	ar3
   37F2 D0 02               838 	pop	ar2
                            839 ;	../../Platform/nano/bus.c:195: for (i = 0; i< time; i++)
                            840 ;	genPlus
                            841 ;     genPlusIncr
                            842 ;	tail increment optimized (range 5)
   37F4 0C                  843 	inc	r4
   37F5 BC 00 DF            844 	cjne	r4,#0x00,00101$
   37F8 0D                  845 	inc	r5
                            846 ;	Peephole 112.b	changed ljmp to sjmp
   37F9 80 DC               847 	sjmp	00101$
   37FB                     848 00105$:
   37FB 22                  849 	ret
                            850 	.area CSEG    (CODE)
                            851 	.area CONST   (CODE)
                            852 	.area XINIT   (CODE)
