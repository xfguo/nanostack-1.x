                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Nov 10 2006)
                              4 ; This file generated Fri Feb  1 13:33:37 2008
                              5 ;--------------------------------------------------------
                              6 	.module queue
                              7 	.optsdcc -mmcs51 --model-large
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _IRCON2_P2IF
                             13 	.globl _IRCON2_UTX0IF
                             14 	.globl _IRCON2_UTX1IF
                             15 	.globl _IRCON2_P1IF
                             16 	.globl _IRCON2_WDTIF
                             17 	.globl _CY
                             18 	.globl _AC
                             19 	.globl _F0
                             20 	.globl _RS1
                             21 	.globl _RS0
                             22 	.globl _OV
                             23 	.globl _F1
                             24 	.globl _P
                             25 	.globl _IRCON_DMAIF
                             26 	.globl _IRCON_T1IF
                             27 	.globl _IRCON_T2IF
                             28 	.globl _IRCON_T3IF
                             29 	.globl _IRCON_T4IF
                             30 	.globl _IRCON_P0IF
                             31 	.globl _IRCON_STIF
                             32 	.globl _IEN1_DMAIE
                             33 	.globl _IEN1_T1IE
                             34 	.globl _IEN1_T2IE
                             35 	.globl _IEN1_T3IE
                             36 	.globl _IEN1_T4IE
                             37 	.globl _IEN1_P0IE
                             38 	.globl _IEN0_RFERRIE
                             39 	.globl _IEN0_ADCIE
                             40 	.globl _IEN0_URX0IE
                             41 	.globl _IEN0_URX1IE
                             42 	.globl _IEN0_ENCIE
                             43 	.globl _IEN0_STIE
                             44 	.globl _IEN0_EA
                             45 	.globl _EA
                             46 	.globl _P2_4
                             47 	.globl _P2_3
                             48 	.globl _P2_2
                             49 	.globl _P2_1
                             50 	.globl _P2_0
                             51 	.globl _S0CON_ENCIF_0
                             52 	.globl _S0CON_ENCIF_1
                             53 	.globl _P1_7
                             54 	.globl _P1_6
                             55 	.globl _P1_5
                             56 	.globl _P1_4
                             57 	.globl _P1_3
                             58 	.globl _P1_2
                             59 	.globl _P1_1
                             60 	.globl _P1_0
                             61 	.globl _TCON_IT0
                             62 	.globl _TCON_RFERRIF
                             63 	.globl _TCON_IT1
                             64 	.globl _TCON_URX0IF
                             65 	.globl _TCON_ADCIF
                             66 	.globl _TCON_URX1IF
                             67 	.globl _P0_0
                             68 	.globl _P0_1
                             69 	.globl _P0_2
                             70 	.globl _P0_3
                             71 	.globl _P0_4
                             72 	.globl _P0_5
                             73 	.globl _P0_6
                             74 	.globl _P0_7
                             75 	.globl _P2DIR
                             76 	.globl _P1DIR
                             77 	.globl _P0DIR
                             78 	.globl _U1GCR
                             79 	.globl _U1UCR
                             80 	.globl _U1BAUD
                             81 	.globl _U1BUF
                             82 	.globl _U1CSR
                             83 	.globl _P2INP
                             84 	.globl _P1INP
                             85 	.globl _P2SEL
                             86 	.globl _P1SEL
                             87 	.globl _P0SEL
                             88 	.globl _ADCCFG
                             89 	.globl _PERCFG
                             90 	.globl _B
                             91 	.globl _T4CC1
                             92 	.globl _T4CCTL1
                             93 	.globl _T4CC0
                             94 	.globl _T4CCTL0
                             95 	.globl _T4CTL
                             96 	.globl _T4CNT
                             97 	.globl _RFIF
                             98 	.globl _IRCON2
                             99 	.globl _T1CCTL2
                            100 	.globl _T1CCTL1
                            101 	.globl _T1CCTL0
                            102 	.globl _T1CTL
                            103 	.globl _T1CNTH
                            104 	.globl _T1CNTL
                            105 	.globl _RFST
                            106 	.globl _ACC
                            107 	.globl _T1CC2H
                            108 	.globl _T1CC2L
                            109 	.globl _T1CC1H
                            110 	.globl _T1CC1L
                            111 	.globl _T1CC0H
                            112 	.globl _T1CC0L
                            113 	.globl _RFD
                            114 	.globl _TIMIF
                            115 	.globl _DMAREQ
                            116 	.globl _DMAARM
                            117 	.globl _DMA0CFGH
                            118 	.globl _DMA0CFGL
                            119 	.globl _DMA1CFGH
                            120 	.globl _DMA1CFGL
                            121 	.globl _DMAIRQ
                            122 	.globl _PSW
                            123 	.globl _T3CC1
                            124 	.globl _T3CCTL1
                            125 	.globl _T3CC0
                            126 	.globl _T3CCTL0
                            127 	.globl _T3CTL
                            128 	.globl _T3CNT
                            129 	.globl _WDCTL
                            130 	.globl _T2CON
                            131 	.globl _MEMCTR
                            132 	.globl _CLKCON
                            133 	.globl _U0GCR
                            134 	.globl _U0UCR
                            135 	.globl _T2CNF
                            136 	.globl _U0BAUD
                            137 	.globl _U0BUF
                            138 	.globl _IRCON
                            139 	.globl _SLEEP
                            140 	.globl _RNDH
                            141 	.globl _RNDL
                            142 	.globl _ADCH
                            143 	.globl _ADCL
                            144 	.globl _IP1
                            145 	.globl _IEN1
                            146 	.globl _RCCTL
                            147 	.globl _ADCCON3
                            148 	.globl _ADCCON2
                            149 	.globl _ADCCON1
                            150 	.globl _ENCCS
                            151 	.globl _ENCDO
                            152 	.globl _ENCDI
                            153 	.globl _FWDATA
                            154 	.globl _FCTL
                            155 	.globl _FADDRH
                            156 	.globl _FADDRL
                            157 	.globl _FWT
                            158 	.globl _IP0
                            159 	.globl _IEN0
                            160 	.globl _IE
                            161 	.globl _T2THD
                            162 	.globl _T2TLD
                            163 	.globl _T2CAPHPH
                            164 	.globl _T2CAPLPL
                            165 	.globl _T2OF2
                            166 	.globl _T2OF1
                            167 	.globl _T2OF0
                            168 	.globl _P2
                            169 	.globl _T2PEROF2
                            170 	.globl _T2PEROF1
                            171 	.globl _T2PEROF0
                            172 	.globl _S1CON
                            173 	.globl _IEN2
                            174 	.globl _HSRC
                            175 	.globl _S0CON
                            176 	.globl _ST2
                            177 	.globl _ST1
                            178 	.globl _ST0
                            179 	.globl _T2CMP
                            180 	.globl __XPAGE
                            181 	.globl _DPS
                            182 	.globl _RFIM
                            183 	.globl _P1
                            184 	.globl _P0INP
                            185 	.globl _P1IEN
                            186 	.globl _PICTL
                            187 	.globl _P2IFG
                            188 	.globl _P1IFG
                            189 	.globl _P0IFG
                            190 	.globl _TCON
                            191 	.globl _PCON
                            192 	.globl _U0CSR
                            193 	.globl _DPH1
                            194 	.globl _DPL1
                            195 	.globl _DPH0
                            196 	.globl _DPL0
                            197 	.globl _SP
                            198 	.globl _P0
                            199 	.globl _RFD_SHADOW
                            200 	.globl _RFSTATUS
                            201 	.globl _CHIPID
                            202 	.globl _CHVER
                            203 	.globl _FSMTC1
                            204 	.globl _RXFIFOCNT
                            205 	.globl _IOCFG3
                            206 	.globl _IOCFG2
                            207 	.globl _IOCFG1
                            208 	.globl _IOCFG0
                            209 	.globl _SHORTADDRL
                            210 	.globl _SHORTADDRH
                            211 	.globl _PANIDL
                            212 	.globl _PANIDH
                            213 	.globl _IEEE_ADDR7
                            214 	.globl _IEEE_ADDR6
                            215 	.globl _IEEE_ADDR5
                            216 	.globl _IEEE_ADDR4
                            217 	.globl _IEEE_ADDR3
                            218 	.globl _IEEE_ADDR2
                            219 	.globl _IEEE_ADDR1
                            220 	.globl _IEEE_ADDR0
                            221 	.globl _DACTSTL
                            222 	.globl _DACTSTH
                            223 	.globl _ADCTSTL
                            224 	.globl _ADCTSTH
                            225 	.globl _FSMSTATE
                            226 	.globl _AGCCTRLL
                            227 	.globl _AGCCTRLH
                            228 	.globl _MANORL
                            229 	.globl _MANORH
                            230 	.globl _MANANDL
                            231 	.globl _MANANDH
                            232 	.globl _FSMTCL
                            233 	.globl _FSMTCH
                            234 	.globl _RFPWR
                            235 	.globl _CSPT
                            236 	.globl _CSPCTRL
                            237 	.globl _CSPZ
                            238 	.globl _CSPY
                            239 	.globl _CSPX
                            240 	.globl _FSCTRLL
                            241 	.globl _FSCTRLH
                            242 	.globl _RXCTRL1L
                            243 	.globl _RXCTRL1H
                            244 	.globl _RXCTRL0L
                            245 	.globl _RXCTRL0H
                            246 	.globl _TXCTRLL
                            247 	.globl _TXCTRLH
                            248 	.globl _SYNCWORDL
                            249 	.globl _SYNCWORDH
                            250 	.globl _RSSIL
                            251 	.globl _RSSIH
                            252 	.globl _MDMCTRL1L
                            253 	.globl _MDMCTRL1H
                            254 	.globl _MDMCTRL0L
                            255 	.globl _MDMCTRL0H
                            256 	.globl _xQueueCreate
                            257 	.globl _xQueueSend
                            258 	.globl _xQueueSendFromISR
                            259 	.globl _xQueueReceive
                            260 	.globl _xQueueReceiveFromISR
                            261 	.globl _uxQueueMessagesWaiting
                            262 	.globl _vQueueDelete
                            263 ;--------------------------------------------------------
                            264 ; special function registers
                            265 ;--------------------------------------------------------
                            266 	.area RSEG    (DATA)
                    0080    267 _P0	=	0x0080
                    0081    268 _SP	=	0x0081
                    0082    269 _DPL0	=	0x0082
                    0083    270 _DPH0	=	0x0083
                    0084    271 _DPL1	=	0x0084
                    0085    272 _DPH1	=	0x0085
                    0086    273 _U0CSR	=	0x0086
                    0087    274 _PCON	=	0x0087
                    0088    275 _TCON	=	0x0088
                    0089    276 _P0IFG	=	0x0089
                    008A    277 _P1IFG	=	0x008a
                    008B    278 _P2IFG	=	0x008b
                    008C    279 _PICTL	=	0x008c
                    008D    280 _P1IEN	=	0x008d
                    008F    281 _P0INP	=	0x008f
                    0090    282 _P1	=	0x0090
                    0091    283 _RFIM	=	0x0091
                    0092    284 _DPS	=	0x0092
                    0093    285 __XPAGE	=	0x0093
                    0094    286 _T2CMP	=	0x0094
                    0095    287 _ST0	=	0x0095
                    0096    288 _ST1	=	0x0096
                    0097    289 _ST2	=	0x0097
                    0098    290 _S0CON	=	0x0098
                    0099    291 _HSRC	=	0x0099
                    009A    292 _IEN2	=	0x009a
                    009B    293 _S1CON	=	0x009b
                    009C    294 _T2PEROF0	=	0x009c
                    009D    295 _T2PEROF1	=	0x009d
                    009E    296 _T2PEROF2	=	0x009e
                    00A0    297 _P2	=	0x00a0
                    00A1    298 _T2OF0	=	0x00a1
                    00A2    299 _T2OF1	=	0x00a2
                    00A3    300 _T2OF2	=	0x00a3
                    00A4    301 _T2CAPLPL	=	0x00a4
                    00A5    302 _T2CAPHPH	=	0x00a5
                    00A6    303 _T2TLD	=	0x00a6
                    00A7    304 _T2THD	=	0x00a7
                    00A8    305 _IE	=	0x00a8
                    00A8    306 _IEN0	=	0x00a8
                    00A9    307 _IP0	=	0x00a9
                    00AB    308 _FWT	=	0x00ab
                    00AC    309 _FADDRL	=	0x00ac
                    00AD    310 _FADDRH	=	0x00ad
                    00AE    311 _FCTL	=	0x00ae
                    00AF    312 _FWDATA	=	0x00af
                    00B1    313 _ENCDI	=	0x00b1
                    00B2    314 _ENCDO	=	0x00b2
                    00B3    315 _ENCCS	=	0x00b3
                    00B4    316 _ADCCON1	=	0x00b4
                    00B5    317 _ADCCON2	=	0x00b5
                    00B6    318 _ADCCON3	=	0x00b6
                    00B7    319 _RCCTL	=	0x00b7
                    00B8    320 _IEN1	=	0x00b8
                    00B9    321 _IP1	=	0x00b9
                    00BA    322 _ADCL	=	0x00ba
                    00BB    323 _ADCH	=	0x00bb
                    00BC    324 _RNDL	=	0x00bc
                    00BD    325 _RNDH	=	0x00bd
                    00BE    326 _SLEEP	=	0x00be
                    00C0    327 _IRCON	=	0x00c0
                    00C1    328 _U0BUF	=	0x00c1
                    00C2    329 _U0BAUD	=	0x00c2
                    00C3    330 _T2CNF	=	0x00c3
                    00C4    331 _U0UCR	=	0x00c4
                    00C5    332 _U0GCR	=	0x00c5
                    00C6    333 _CLKCON	=	0x00c6
                    00C7    334 _MEMCTR	=	0x00c7
                    00C8    335 _T2CON	=	0x00c8
                    00C9    336 _WDCTL	=	0x00c9
                    00CA    337 _T3CNT	=	0x00ca
                    00CB    338 _T3CTL	=	0x00cb
                    00CC    339 _T3CCTL0	=	0x00cc
                    00CD    340 _T3CC0	=	0x00cd
                    00CE    341 _T3CCTL1	=	0x00ce
                    00CF    342 _T3CC1	=	0x00cf
                    00D0    343 _PSW	=	0x00d0
                    00D1    344 _DMAIRQ	=	0x00d1
                    00D2    345 _DMA1CFGL	=	0x00d2
                    00D3    346 _DMA1CFGH	=	0x00d3
                    00D4    347 _DMA0CFGL	=	0x00d4
                    00D5    348 _DMA0CFGH	=	0x00d5
                    00D6    349 _DMAARM	=	0x00d6
                    00D7    350 _DMAREQ	=	0x00d7
                    00D8    351 _TIMIF	=	0x00d8
                    00D9    352 _RFD	=	0x00d9
                    00DA    353 _T1CC0L	=	0x00da
                    00DB    354 _T1CC0H	=	0x00db
                    00DC    355 _T1CC1L	=	0x00dc
                    00DD    356 _T1CC1H	=	0x00dd
                    00DE    357 _T1CC2L	=	0x00de
                    00DF    358 _T1CC2H	=	0x00df
                    00E0    359 _ACC	=	0x00e0
                    00E1    360 _RFST	=	0x00e1
                    00E2    361 _T1CNTL	=	0x00e2
                    00E3    362 _T1CNTH	=	0x00e3
                    00E4    363 _T1CTL	=	0x00e4
                    00E5    364 _T1CCTL0	=	0x00e5
                    00E6    365 _T1CCTL1	=	0x00e6
                    00E7    366 _T1CCTL2	=	0x00e7
                    00E8    367 _IRCON2	=	0x00e8
                    00E9    368 _RFIF	=	0x00e9
                    00EA    369 _T4CNT	=	0x00ea
                    00EB    370 _T4CTL	=	0x00eb
                    00EC    371 _T4CCTL0	=	0x00ec
                    00ED    372 _T4CC0	=	0x00ed
                    00EE    373 _T4CCTL1	=	0x00ee
                    00EF    374 _T4CC1	=	0x00ef
                    00F0    375 _B	=	0x00f0
                    00F1    376 _PERCFG	=	0x00f1
                    00F2    377 _ADCCFG	=	0x00f2
                    00F3    378 _P0SEL	=	0x00f3
                    00F4    379 _P1SEL	=	0x00f4
                    00F5    380 _P2SEL	=	0x00f5
                    00F6    381 _P1INP	=	0x00f6
                    00F7    382 _P2INP	=	0x00f7
                    00F8    383 _U1CSR	=	0x00f8
                    00F9    384 _U1BUF	=	0x00f9
                    00FA    385 _U1BAUD	=	0x00fa
                    00FB    386 _U1UCR	=	0x00fb
                    00FC    387 _U1GCR	=	0x00fc
                    00FD    388 _P0DIR	=	0x00fd
                    00FE    389 _P1DIR	=	0x00fe
                    00FF    390 _P2DIR	=	0x00ff
                            391 ;--------------------------------------------------------
                            392 ; special function bits
                            393 ;--------------------------------------------------------
                            394 	.area RSEG    (DATA)
                    0087    395 _P0_7	=	0x0087
                    0086    396 _P0_6	=	0x0086
                    0085    397 _P0_5	=	0x0085
                    0084    398 _P0_4	=	0x0084
                    0083    399 _P0_3	=	0x0083
                    0082    400 _P0_2	=	0x0082
                    0081    401 _P0_1	=	0x0081
                    0080    402 _P0_0	=	0x0080
                    008F    403 _TCON_URX1IF	=	0x008f
                    008D    404 _TCON_ADCIF	=	0x008d
                    008B    405 _TCON_URX0IF	=	0x008b
                    008A    406 _TCON_IT1	=	0x008a
                    0089    407 _TCON_RFERRIF	=	0x0089
                    0088    408 _TCON_IT0	=	0x0088
                    0090    409 _P1_0	=	0x0090
                    0091    410 _P1_1	=	0x0091
                    0092    411 _P1_2	=	0x0092
                    0093    412 _P1_3	=	0x0093
                    0094    413 _P1_4	=	0x0094
                    0095    414 _P1_5	=	0x0095
                    0096    415 _P1_6	=	0x0096
                    0097    416 _P1_7	=	0x0097
                    0099    417 _S0CON_ENCIF_1	=	0x0099
                    0098    418 _S0CON_ENCIF_0	=	0x0098
                    00A0    419 _P2_0	=	0x00a0
                    00A1    420 _P2_1	=	0x00a1
                    00A2    421 _P2_2	=	0x00a2
                    00A3    422 _P2_3	=	0x00a3
                    00A4    423 _P2_4	=	0x00a4
                    00AF    424 _EA	=	0x00af
                    00AF    425 _IEN0_EA	=	0x00af
                    00AD    426 _IEN0_STIE	=	0x00ad
                    00AC    427 _IEN0_ENCIE	=	0x00ac
                    00AB    428 _IEN0_URX1IE	=	0x00ab
                    00AA    429 _IEN0_URX0IE	=	0x00aa
                    00A9    430 _IEN0_ADCIE	=	0x00a9
                    00A8    431 _IEN0_RFERRIE	=	0x00a8
                    00BD    432 _IEN1_P0IE	=	0x00bd
                    00BC    433 _IEN1_T4IE	=	0x00bc
                    00BB    434 _IEN1_T3IE	=	0x00bb
                    00BA    435 _IEN1_T2IE	=	0x00ba
                    00B9    436 _IEN1_T1IE	=	0x00b9
                    00B8    437 _IEN1_DMAIE	=	0x00b8
                    00C7    438 _IRCON_STIF	=	0x00c7
                    00C5    439 _IRCON_P0IF	=	0x00c5
                    00C4    440 _IRCON_T4IF	=	0x00c4
                    00C3    441 _IRCON_T3IF	=	0x00c3
                    00C2    442 _IRCON_T2IF	=	0x00c2
                    00C1    443 _IRCON_T1IF	=	0x00c1
                    00C0    444 _IRCON_DMAIF	=	0x00c0
                    00D0    445 _P	=	0x00d0
                    00D1    446 _F1	=	0x00d1
                    00D2    447 _OV	=	0x00d2
                    00D3    448 _RS0	=	0x00d3
                    00D4    449 _RS1	=	0x00d4
                    00D5    450 _F0	=	0x00d5
                    00D6    451 _AC	=	0x00d6
                    00D7    452 _CY	=	0x00d7
                    00EC    453 _IRCON2_WDTIF	=	0x00ec
                    00EB    454 _IRCON2_P1IF	=	0x00eb
                    00EA    455 _IRCON2_UTX1IF	=	0x00ea
                    00E9    456 _IRCON2_UTX0IF	=	0x00e9
                    00E8    457 _IRCON2_P2IF	=	0x00e8
                            458 ;--------------------------------------------------------
                            459 ; overlayable register banks
                            460 ;--------------------------------------------------------
                            461 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     462 	.ds 8
                            463 ;--------------------------------------------------------
                            464 ; internal ram data
                            465 ;--------------------------------------------------------
                            466 	.area DSEG    (DATA)
                            467 ;--------------------------------------------------------
                            468 ; overlayable items in internal ram 
                            469 ;--------------------------------------------------------
                            470 	.area OSEG    (OVR,DATA)
                            471 ;--------------------------------------------------------
                            472 ; indirectly addressable internal ram data
                            473 ;--------------------------------------------------------
                            474 	.area ISEG    (DATA)
                            475 ;--------------------------------------------------------
                            476 ; bit data
                            477 ;--------------------------------------------------------
                            478 	.area BSEG    (BIT)
                            479 ;--------------------------------------------------------
                            480 ; paged external ram data
                            481 ;--------------------------------------------------------
                            482 	.area PSEG    (PAG,XDATA)
                            483 ;--------------------------------------------------------
                            484 ; external ram data
                            485 ;--------------------------------------------------------
                            486 	.area XSEG    (XDATA)
                    DF02    487 _MDMCTRL0H	=	0xdf02
                    DF03    488 _MDMCTRL0L	=	0xdf03
                    DF04    489 _MDMCTRL1H	=	0xdf04
                    DF05    490 _MDMCTRL1L	=	0xdf05
                    DF06    491 _RSSIH	=	0xdf06
                    DF07    492 _RSSIL	=	0xdf07
                    DF08    493 _SYNCWORDH	=	0xdf08
                    DF09    494 _SYNCWORDL	=	0xdf09
                    DF0A    495 _TXCTRLH	=	0xdf0a
                    DF0B    496 _TXCTRLL	=	0xdf0b
                    DF0C    497 _RXCTRL0H	=	0xdf0c
                    DF0D    498 _RXCTRL0L	=	0xdf0d
                    DF0E    499 _RXCTRL1H	=	0xdf0e
                    DF0F    500 _RXCTRL1L	=	0xdf0f
                    DF10    501 _FSCTRLH	=	0xdf10
                    DF11    502 _FSCTRLL	=	0xdf11
                    DF12    503 _CSPX	=	0xdf12
                    DF13    504 _CSPY	=	0xdf13
                    DF14    505 _CSPZ	=	0xdf14
                    DF15    506 _CSPCTRL	=	0xdf15
                    DF16    507 _CSPT	=	0xdf16
                    DF17    508 _RFPWR	=	0xdf17
                    DF20    509 _FSMTCH	=	0xdf20
                    DF21    510 _FSMTCL	=	0xdf21
                    DF22    511 _MANANDH	=	0xdf22
                    DF23    512 _MANANDL	=	0xdf23
                    DF24    513 _MANORH	=	0xdf24
                    DF25    514 _MANORL	=	0xdf25
                    DF26    515 _AGCCTRLH	=	0xdf26
                    DF27    516 _AGCCTRLL	=	0xdf27
                    DF39    517 _FSMSTATE	=	0xdf39
                    DF3A    518 _ADCTSTH	=	0xdf3a
                    DF3B    519 _ADCTSTL	=	0xdf3b
                    DF3C    520 _DACTSTH	=	0xdf3c
                    DF3D    521 _DACTSTL	=	0xdf3d
                    DF43    522 _IEEE_ADDR0	=	0xdf43
                    DF44    523 _IEEE_ADDR1	=	0xdf44
                    DF45    524 _IEEE_ADDR2	=	0xdf45
                    DF46    525 _IEEE_ADDR3	=	0xdf46
                    DF47    526 _IEEE_ADDR4	=	0xdf47
                    DF48    527 _IEEE_ADDR5	=	0xdf48
                    DF49    528 _IEEE_ADDR6	=	0xdf49
                    DF4A    529 _IEEE_ADDR7	=	0xdf4a
                    DF4B    530 _PANIDH	=	0xdf4b
                    DF4C    531 _PANIDL	=	0xdf4c
                    DF4D    532 _SHORTADDRH	=	0xdf4d
                    DF4E    533 _SHORTADDRL	=	0xdf4e
                    DF4F    534 _IOCFG0	=	0xdf4f
                    DF50    535 _IOCFG1	=	0xdf50
                    DF51    536 _IOCFG2	=	0xdf51
                    DF52    537 _IOCFG3	=	0xdf52
                    DF53    538 _RXFIFOCNT	=	0xdf53
                    DF54    539 _FSMTC1	=	0xdf54
                    DF60    540 _CHVER	=	0xdf60
                    DF61    541 _CHIPID	=	0xdf61
                    DF62    542 _RFSTATUS	=	0xdf62
                    DFD9    543 _RFD_SHADOW	=	0xdfd9
                            544 ;--------------------------------------------------------
                            545 ; external initialized ram data
                            546 ;--------------------------------------------------------
                            547 	.area XISEG   (XDATA)
                            548 	.area HOME    (CODE)
                            549 	.area GSINIT0 (CODE)
                            550 	.area GSINIT1 (CODE)
                            551 	.area GSINIT2 (CODE)
                            552 	.area GSINIT3 (CODE)
                            553 	.area GSINIT4 (CODE)
                            554 	.area GSINIT5 (CODE)
                            555 	.area GSINIT  (CODE)
                            556 	.area GSFINAL (CODE)
                            557 	.area CSEG    (CODE)
                            558 ;--------------------------------------------------------
                            559 ; global & static initialisations
                            560 ;--------------------------------------------------------
                            561 	.area HOME    (CODE)
                            562 	.area GSINIT  (CODE)
                            563 	.area GSFINAL (CODE)
                            564 	.area GSINIT  (CODE)
                            565 ;--------------------------------------------------------
                            566 ; Home
                            567 ;--------------------------------------------------------
                            568 	.area HOME    (CODE)
                            569 	.area CSEG    (CODE)
                            570 ;--------------------------------------------------------
                            571 ; code
                            572 ;--------------------------------------------------------
                            573 	.area CSEG    (CODE)
                            574 ;------------------------------------------------------------
                            575 ;Allocation info for local variables in function 'xQueueCreate'
                            576 ;------------------------------------------------------------
                            577 ;uxItemSize                Allocated to stack - offset -3
                            578 ;uxQueueLength             Allocated to stack - offset 1
                            579 ;pxNewQueue                Allocated to stack - offset 2
                            580 ;xQueueSizeInBytes         Allocated to registers r2 r3 
                            581 ;sloc0                     Allocated to stack - offset 5
                            582 ;sloc1                     Allocated to stack - offset 8
                            583 ;------------------------------------------------------------
                            584 ;	../../FreeRTOS/Source/queue.c:193: xQueueHandle xQueueCreate( unsigned portBASE_TYPE uxQueueLength, unsigned portBASE_TYPE uxItemSize )
                            585 ;	-----------------------------------------
                            586 ;	 function xQueueCreate
                            587 ;	-----------------------------------------
   1B2D                     588 _xQueueCreate:
                    0002    589 	ar2 = 0x02
                    0003    590 	ar3 = 0x03
                    0004    591 	ar4 = 0x04
                    0005    592 	ar5 = 0x05
                    0006    593 	ar6 = 0x06
                    0007    594 	ar7 = 0x07
                    0000    595 	ar0 = 0x00
                    0001    596 	ar1 = 0x01
   1B2D C0 10               597 	push	_bp
   1B2F 85 81 10            598 	mov	_bp,sp
                            599 ;     genReceive
   1B32 C0 82               600 	push	dpl
   1B34 E5 81               601 	mov	a,sp
   1B36 24 09               602 	add	a,#0x09
   1B38 F5 81               603 	mov	sp,a
                            604 ;	../../FreeRTOS/Source/queue.c:199: if( uxQueueLength > ( unsigned portBASE_TYPE ) 0 )
                            605 ;	genIfx
   1B3A A8 10               606 	mov	r0,_bp
   1B3C 08                  607 	inc	r0
   1B3D E6                  608 	mov	a,@r0
                            609 ;	genIfxJump
   1B3E 70 03               610 	jnz	00113$
   1B40 02 1D 82            611 	ljmp	00107$
   1B43                     612 00113$:
                            613 ;	../../FreeRTOS/Source/queue.c:201: pxNewQueue = ( xQUEUE * ) pvPortMalloc( sizeof( xQUEUE ) );
                            614 ;	genCall
                            615 ;	Peephole 182.b	used 16 bit load of dptr
   1B43 90 00 29            616 	mov	dptr,#0x0029
   1B46 12 36 8C            617 	lcall	_pvPortMalloc
   1B49 AB 82               618 	mov	r3,dpl
   1B4B AC 83               619 	mov	r4,dph
   1B4D AD F0               620 	mov	r5,b
                            621 ;	genAssign
   1B4F A8 10               622 	mov	r0,_bp
   1B51 08                  623 	inc	r0
   1B52 08                  624 	inc	r0
   1B53 A6 03               625 	mov	@r0,ar3
   1B55 08                  626 	inc	r0
   1B56 A6 04               627 	mov	@r0,ar4
   1B58 08                  628 	inc	r0
   1B59 A6 05               629 	mov	@r0,ar5
                            630 ;	../../FreeRTOS/Source/queue.c:202: if( pxNewQueue != NULL )
                            631 ;	genCmpEq
   1B5B A8 10               632 	mov	r0,_bp
   1B5D 08                  633 	inc	r0
   1B5E 08                  634 	inc	r0
                            635 ;	gencjneshort
   1B5F B6 00 0B            636 	cjne	@r0,#0x00,00114$
   1B62 08                  637 	inc	r0
   1B63 B6 00 07            638 	cjne	@r0,#0x00,00114$
   1B66 08                  639 	inc	r0
   1B67 B6 00 03            640 	cjne	@r0,#0x00,00114$
   1B6A 02 1D 82            641 	ljmp	00107$
   1B6D                     642 00114$:
                            643 ;	../../FreeRTOS/Source/queue.c:206: xQueueSizeInBytes = ( size_t ) ( uxQueueLength * uxItemSize ) + ( size_t ) 1;
                            644 ;	genMult
   1B6D A8 10               645 	mov	r0,_bp
   1B6F 08                  646 	inc	r0
   1B70 A9 10               647 	mov	r1,_bp
   1B72 19                  648 	dec	r1
   1B73 19                  649 	dec	r1
   1B74 19                  650 	dec	r1
                            651 ;	genMultOneByte
   1B75 86 F0               652 	mov	b,@r0
   1B77 E7                  653 	mov	a,@r1
   1B78 A4                  654 	mul	ab
   1B79 FE                  655 	mov	r6,a
   1B7A AF F0               656 	mov	r7,b
                            657 ;	genPlus
                            658 ;     genPlusIncr
   1B7C 74 01               659 	mov	a,#0x01
                            660 ;	Peephole 236.a	used r6 instead of ar6
   1B7E 2E                  661 	add	a,r6
   1B7F FA                  662 	mov	r2,a
                            663 ;	Peephole 181	changed mov to clr
   1B80 E4                  664 	clr	a
                            665 ;	Peephole 236.b	used r7 instead of ar7
   1B81 3F                  666 	addc	a,r7
   1B82 FB                  667 	mov	r3,a
                            668 ;	../../FreeRTOS/Source/queue.c:208: pxNewQueue->pcHead = ( signed portCHAR * ) pvPortMalloc( xQueueSizeInBytes );
                            669 ;	genCall
   1B83 8A 82               670 	mov	dpl,r2
   1B85 8B 83               671 	mov	dph,r3
   1B87 C0 06               672 	push	ar6
   1B89 C0 07               673 	push	ar7
   1B8B 12 36 8C            674 	lcall	_pvPortMalloc
   1B8E AA 82               675 	mov	r2,dpl
   1B90 AB 83               676 	mov	r3,dph
   1B92 AC F0               677 	mov	r4,b
   1B94 D0 07               678 	pop	ar7
   1B96 D0 06               679 	pop	ar6
                            680 ;	genPointerSet
                            681 ;	genGenPointerSet
   1B98 A8 10               682 	mov	r0,_bp
   1B9A 08                  683 	inc	r0
   1B9B 08                  684 	inc	r0
   1B9C 86 82               685 	mov	dpl,@r0
   1B9E 08                  686 	inc	r0
   1B9F 86 83               687 	mov	dph,@r0
   1BA1 08                  688 	inc	r0
   1BA2 86 F0               689 	mov	b,@r0
   1BA4 EA                  690 	mov	a,r2
   1BA5 12 DF B7            691 	lcall	__gptrput
   1BA8 A3                  692 	inc	dptr
   1BA9 EB                  693 	mov	a,r3
   1BAA 12 DF B7            694 	lcall	__gptrput
   1BAD A3                  695 	inc	dptr
   1BAE EC                  696 	mov	a,r4
   1BAF 12 DF B7            697 	lcall	__gptrput
                            698 ;	../../FreeRTOS/Source/queue.c:209: if( pxNewQueue->pcHead != NULL )
                            699 ;	genCmpEq
                            700 ;	gencjneshort
   1BB2 BA 00 09            701 	cjne	r2,#0x00,00115$
   1BB5 BB 00 06            702 	cjne	r3,#0x00,00115$
   1BB8 BC 00 03            703 	cjne	r4,#0x00,00115$
   1BBB 02 1D 73            704 	ljmp	00102$
   1BBE                     705 00115$:
                            706 ;	../../FreeRTOS/Source/queue.c:213: pxNewQueue->pcTail = pxNewQueue->pcHead + ( uxQueueLength * uxItemSize );
                            707 ;	genPlus
   1BBE A8 10               708 	mov	r0,_bp
   1BC0 08                  709 	inc	r0
   1BC1 08                  710 	inc	r0
   1BC2 E5 10               711 	mov	a,_bp
   1BC4 24 05               712 	add	a,#0x05
   1BC6 F9                  713 	mov	r1,a
                            714 ;     genPlusIncr
   1BC7 74 03               715 	mov	a,#0x03
   1BC9 26                  716 	add	a,@r0
   1BCA F7                  717 	mov	@r1,a
                            718 ;	Peephole 181	changed mov to clr
   1BCB E4                  719 	clr	a
   1BCC 08                  720 	inc	r0
   1BCD 36                  721 	addc	a,@r0
   1BCE 09                  722 	inc	r1
   1BCF F7                  723 	mov	@r1,a
   1BD0 08                  724 	inc	r0
   1BD1 09                  725 	inc	r1
   1BD2 E6                  726 	mov	a,@r0
   1BD3 F7                  727 	mov	@r1,a
                            728 ;	genPointerGet
                            729 ;	genGenPointerGet
   1BD4 A8 10               730 	mov	r0,_bp
   1BD6 08                  731 	inc	r0
   1BD7 08                  732 	inc	r0
   1BD8 86 82               733 	mov	dpl,@r0
   1BDA 08                  734 	inc	r0
   1BDB 86 83               735 	mov	dph,@r0
   1BDD 08                  736 	inc	r0
   1BDE 86 F0               737 	mov	b,@r0
   1BE0 12 E4 9F            738 	lcall	__gptrget
   1BE3 FD                  739 	mov	r5,a
   1BE4 A3                  740 	inc	dptr
   1BE5 12 E4 9F            741 	lcall	__gptrget
   1BE8 FA                  742 	mov	r2,a
   1BE9 A3                  743 	inc	dptr
   1BEA 12 E4 9F            744 	lcall	__gptrget
   1BED FB                  745 	mov	r3,a
                            746 ;	genPlus
                            747 ;	Peephole 236.g	used r6 instead of ar6
   1BEE EE                  748 	mov	a,r6
                            749 ;	Peephole 236.a	used r5 instead of ar5
   1BEF 2D                  750 	add	a,r5
   1BF0 FE                  751 	mov	r6,a
                            752 ;	Peephole 236.g	used r7 instead of ar7
   1BF1 EF                  753 	mov	a,r7
                            754 ;	Peephole 236.b	used r2 instead of ar2
   1BF2 3A                  755 	addc	a,r2
   1BF3 FF                  756 	mov	r7,a
   1BF4 8B 04               757 	mov	ar4,r3
                            758 ;	genPointerSet
                            759 ;	genGenPointerSet
   1BF6 E5 10               760 	mov	a,_bp
   1BF8 24 05               761 	add	a,#0x05
   1BFA F8                  762 	mov	r0,a
   1BFB 86 82               763 	mov	dpl,@r0
   1BFD 08                  764 	inc	r0
   1BFE 86 83               765 	mov	dph,@r0
   1C00 08                  766 	inc	r0
   1C01 86 F0               767 	mov	b,@r0
   1C03 EE                  768 	mov	a,r6
   1C04 12 DF B7            769 	lcall	__gptrput
   1C07 A3                  770 	inc	dptr
   1C08 EF                  771 	mov	a,r7
   1C09 12 DF B7            772 	lcall	__gptrput
   1C0C A3                  773 	inc	dptr
   1C0D EC                  774 	mov	a,r4
   1C0E 12 DF B7            775 	lcall	__gptrput
                            776 ;	../../FreeRTOS/Source/queue.c:214: pxNewQueue->uxMessagesWaiting = 0;
                            777 ;	genPlus
   1C11 A8 10               778 	mov	r0,_bp
   1C13 08                  779 	inc	r0
   1C14 08                  780 	inc	r0
                            781 ;     genPlusIncr
   1C15 74 24               782 	mov	a,#0x24
   1C17 26                  783 	add	a,@r0
   1C18 FC                  784 	mov	r4,a
                            785 ;	Peephole 181	changed mov to clr
   1C19 E4                  786 	clr	a
   1C1A 08                  787 	inc	r0
   1C1B 36                  788 	addc	a,@r0
   1C1C FE                  789 	mov	r6,a
   1C1D 08                  790 	inc	r0
   1C1E 86 07               791 	mov	ar7,@r0
                            792 ;	genPointerSet
                            793 ;	genGenPointerSet
   1C20 8C 82               794 	mov	dpl,r4
   1C22 8E 83               795 	mov	dph,r6
   1C24 8F F0               796 	mov	b,r7
                            797 ;	Peephole 181	changed mov to clr
   1C26 E4                  798 	clr	a
   1C27 12 DF B7            799 	lcall	__gptrput
                            800 ;	../../FreeRTOS/Source/queue.c:215: pxNewQueue->pcWriteTo = pxNewQueue->pcHead;
                            801 ;	genPlus
   1C2A A8 10               802 	mov	r0,_bp
   1C2C 08                  803 	inc	r0
   1C2D 08                  804 	inc	r0
                            805 ;     genPlusIncr
   1C2E 74 06               806 	mov	a,#0x06
   1C30 26                  807 	add	a,@r0
   1C31 FC                  808 	mov	r4,a
                            809 ;	Peephole 181	changed mov to clr
   1C32 E4                  810 	clr	a
   1C33 08                  811 	inc	r0
   1C34 36                  812 	addc	a,@r0
   1C35 FE                  813 	mov	r6,a
   1C36 08                  814 	inc	r0
   1C37 86 07               815 	mov	ar7,@r0
                            816 ;	genPointerSet
                            817 ;	genGenPointerSet
   1C39 8C 82               818 	mov	dpl,r4
   1C3B 8E 83               819 	mov	dph,r6
   1C3D 8F F0               820 	mov	b,r7
   1C3F ED                  821 	mov	a,r5
   1C40 12 DF B7            822 	lcall	__gptrput
   1C43 A3                  823 	inc	dptr
   1C44 EA                  824 	mov	a,r2
   1C45 12 DF B7            825 	lcall	__gptrput
   1C48 A3                  826 	inc	dptr
   1C49 EB                  827 	mov	a,r3
   1C4A 12 DF B7            828 	lcall	__gptrput
                            829 ;	../../FreeRTOS/Source/queue.c:216: pxNewQueue->pcReadFrom = pxNewQueue->pcHead + ( ( uxQueueLength - 1 ) * uxItemSize );
                            830 ;	genPlus
   1C4D A8 10               831 	mov	r0,_bp
   1C4F 08                  832 	inc	r0
   1C50 08                  833 	inc	r0
   1C51 E5 10               834 	mov	a,_bp
   1C53 24 05               835 	add	a,#0x05
   1C55 F9                  836 	mov	r1,a
                            837 ;     genPlusIncr
   1C56 74 09               838 	mov	a,#0x09
   1C58 26                  839 	add	a,@r0
   1C59 F7                  840 	mov	@r1,a
                            841 ;	Peephole 181	changed mov to clr
   1C5A E4                  842 	clr	a
   1C5B 08                  843 	inc	r0
   1C5C 36                  844 	addc	a,@r0
   1C5D 09                  845 	inc	r1
   1C5E F7                  846 	mov	@r1,a
   1C5F 08                  847 	inc	r0
   1C60 09                  848 	inc	r1
   1C61 E6                  849 	mov	a,@r0
   1C62 F7                  850 	mov	@r1,a
                            851 ;	genCast
   1C63 A8 10               852 	mov	r0,_bp
   1C65 08                  853 	inc	r0
   1C66 86 04               854 	mov	ar4,@r0
   1C68 7E 00               855 	mov	r6,#0x00
                            856 ;	genMinus
   1C6A E5 10               857 	mov	a,_bp
   1C6C 24 08               858 	add	a,#0x08
   1C6E F8                  859 	mov	r0,a
                            860 ;	genMinusDec
   1C6F EC                  861 	mov	a,r4
   1C70 24 FF               862 	add	a,#0xff
   1C72 F6                  863 	mov	@r0,a
   1C73 EE                  864 	mov	a,r6
   1C74 34 FF               865 	addc	a,#0xff
   1C76 08                  866 	inc	r0
   1C77 F6                  867 	mov	@r0,a
                            868 ;	genCast
   1C78 A8 10               869 	mov	r0,_bp
   1C7A 18                  870 	dec	r0
   1C7B 18                  871 	dec	r0
   1C7C 18                  872 	dec	r0
   1C7D 86 07               873 	mov	ar7,@r0
   1C7F 7C 00               874 	mov	r4,#0x00
                            875 ;	genIpush
   1C81 C0 02               876 	push	ar2
   1C83 C0 03               877 	push	ar3
   1C85 C0 05               878 	push	ar5
   1C87 C0 07               879 	push	ar7
   1C89 C0 04               880 	push	ar4
                            881 ;	genCall
   1C8B E5 10               882 	mov	a,_bp
   1C8D 24 08               883 	add	a,#0x08
   1C8F F8                  884 	mov	r0,a
   1C90 86 82               885 	mov	dpl,@r0
   1C92 08                  886 	inc	r0
   1C93 86 83               887 	mov	dph,@r0
   1C95 12 E1 6A            888 	lcall	__mulint
   1C98 AC 82               889 	mov	r4,dpl
   1C9A AE 83               890 	mov	r6,dph
   1C9C 15 81               891 	dec	sp
   1C9E 15 81               892 	dec	sp
   1CA0 D0 05               893 	pop	ar5
   1CA2 D0 03               894 	pop	ar3
   1CA4 D0 02               895 	pop	ar2
                            896 ;	genPlus
                            897 ;	Peephole 236.g	used r4 instead of ar4
   1CA6 EC                  898 	mov	a,r4
                            899 ;	Peephole 236.a	used r5 instead of ar5
   1CA7 2D                  900 	add	a,r5
   1CA8 FD                  901 	mov	r5,a
                            902 ;	Peephole 236.g	used r6 instead of ar6
   1CA9 EE                  903 	mov	a,r6
                            904 ;	Peephole 236.b	used r2 instead of ar2
   1CAA 3A                  905 	addc	a,r2
   1CAB FA                  906 	mov	r2,a
                            907 ;	genPointerSet
                            908 ;	genGenPointerSet
   1CAC E5 10               909 	mov	a,_bp
   1CAE 24 05               910 	add	a,#0x05
   1CB0 F8                  911 	mov	r0,a
   1CB1 86 82               912 	mov	dpl,@r0
   1CB3 08                  913 	inc	r0
   1CB4 86 83               914 	mov	dph,@r0
   1CB6 08                  915 	inc	r0
   1CB7 86 F0               916 	mov	b,@r0
   1CB9 ED                  917 	mov	a,r5
   1CBA 12 DF B7            918 	lcall	__gptrput
   1CBD A3                  919 	inc	dptr
   1CBE EA                  920 	mov	a,r2
   1CBF 12 DF B7            921 	lcall	__gptrput
   1CC2 A3                  922 	inc	dptr
   1CC3 EB                  923 	mov	a,r3
   1CC4 12 DF B7            924 	lcall	__gptrput
                            925 ;	../../FreeRTOS/Source/queue.c:217: pxNewQueue->uxLength = uxQueueLength;
                            926 ;	genPlus
   1CC7 A8 10               927 	mov	r0,_bp
   1CC9 08                  928 	inc	r0
   1CCA 08                  929 	inc	r0
                            930 ;     genPlusIncr
   1CCB 74 25               931 	mov	a,#0x25
   1CCD 26                  932 	add	a,@r0
   1CCE FA                  933 	mov	r2,a
                            934 ;	Peephole 181	changed mov to clr
   1CCF E4                  935 	clr	a
   1CD0 08                  936 	inc	r0
   1CD1 36                  937 	addc	a,@r0
   1CD2 FB                  938 	mov	r3,a
   1CD3 08                  939 	inc	r0
   1CD4 86 04               940 	mov	ar4,@r0
                            941 ;	genPointerSet
                            942 ;	genGenPointerSet
   1CD6 8A 82               943 	mov	dpl,r2
   1CD8 8B 83               944 	mov	dph,r3
   1CDA 8C F0               945 	mov	b,r4
   1CDC A8 10               946 	mov	r0,_bp
   1CDE 08                  947 	inc	r0
   1CDF E6                  948 	mov	a,@r0
   1CE0 12 DF B7            949 	lcall	__gptrput
                            950 ;	../../FreeRTOS/Source/queue.c:218: pxNewQueue->uxItemSize = uxItemSize;
                            951 ;	genPlus
   1CE3 A8 10               952 	mov	r0,_bp
   1CE5 08                  953 	inc	r0
   1CE6 08                  954 	inc	r0
                            955 ;     genPlusIncr
   1CE7 74 26               956 	mov	a,#0x26
   1CE9 26                  957 	add	a,@r0
   1CEA FA                  958 	mov	r2,a
                            959 ;	Peephole 181	changed mov to clr
   1CEB E4                  960 	clr	a
   1CEC 08                  961 	inc	r0
   1CED 36                  962 	addc	a,@r0
   1CEE FB                  963 	mov	r3,a
   1CEF 08                  964 	inc	r0
   1CF0 86 04               965 	mov	ar4,@r0
                            966 ;	genPointerSet
                            967 ;	genGenPointerSet
   1CF2 8A 82               968 	mov	dpl,r2
   1CF4 8B 83               969 	mov	dph,r3
   1CF6 8C F0               970 	mov	b,r4
   1CF8 A8 10               971 	mov	r0,_bp
   1CFA 18                  972 	dec	r0
   1CFB 18                  973 	dec	r0
   1CFC 18                  974 	dec	r0
   1CFD E6                  975 	mov	a,@r0
   1CFE 12 DF B7            976 	lcall	__gptrput
                            977 ;	../../FreeRTOS/Source/queue.c:219: pxNewQueue->xRxLock = queueUNLOCKED;
                            978 ;	genPlus
   1D01 A8 10               979 	mov	r0,_bp
   1D03 08                  980 	inc	r0
   1D04 08                  981 	inc	r0
                            982 ;     genPlusIncr
   1D05 74 27               983 	mov	a,#0x27
   1D07 26                  984 	add	a,@r0
   1D08 FA                  985 	mov	r2,a
                            986 ;	Peephole 181	changed mov to clr
   1D09 E4                  987 	clr	a
   1D0A 08                  988 	inc	r0
   1D0B 36                  989 	addc	a,@r0
   1D0C FB                  990 	mov	r3,a
   1D0D 08                  991 	inc	r0
   1D0E 86 04               992 	mov	ar4,@r0
                            993 ;	genPointerSet
                            994 ;	genGenPointerSet
   1D10 8A 82               995 	mov	dpl,r2
   1D12 8B 83               996 	mov	dph,r3
   1D14 8C F0               997 	mov	b,r4
   1D16 74 FF               998 	mov	a,#0xFF
   1D18 12 DF B7            999 	lcall	__gptrput
                           1000 ;	../../FreeRTOS/Source/queue.c:220: pxNewQueue->xTxLock = queueUNLOCKED;
                           1001 ;	genPlus
   1D1B A8 10              1002 	mov	r0,_bp
   1D1D 08                 1003 	inc	r0
   1D1E 08                 1004 	inc	r0
                           1005 ;     genPlusIncr
   1D1F 74 28              1006 	mov	a,#0x28
   1D21 26                 1007 	add	a,@r0
   1D22 FA                 1008 	mov	r2,a
                           1009 ;	Peephole 181	changed mov to clr
   1D23 E4                 1010 	clr	a
   1D24 08                 1011 	inc	r0
   1D25 36                 1012 	addc	a,@r0
   1D26 FB                 1013 	mov	r3,a
   1D27 08                 1014 	inc	r0
   1D28 86 04              1015 	mov	ar4,@r0
                           1016 ;	genPointerSet
                           1017 ;	genGenPointerSet
   1D2A 8A 82              1018 	mov	dpl,r2
   1D2C 8B 83              1019 	mov	dph,r3
   1D2E 8C F0              1020 	mov	b,r4
   1D30 74 FF              1021 	mov	a,#0xFF
   1D32 12 DF B7           1022 	lcall	__gptrput
                           1023 ;	../../FreeRTOS/Source/queue.c:223: vListInitialise( &( pxNewQueue->xTasksWaitingToSend ) );
                           1024 ;	genPlus
   1D35 A8 10              1025 	mov	r0,_bp
   1D37 08                 1026 	inc	r0
   1D38 08                 1027 	inc	r0
                           1028 ;     genPlusIncr
   1D39 74 0C              1029 	mov	a,#0x0C
   1D3B 26                 1030 	add	a,@r0
   1D3C FA                 1031 	mov	r2,a
                           1032 ;	Peephole 181	changed mov to clr
   1D3D E4                 1033 	clr	a
   1D3E 08                 1034 	inc	r0
   1D3F 36                 1035 	addc	a,@r0
   1D40 FB                 1036 	mov	r3,a
   1D41 08                 1037 	inc	r0
   1D42 86 04              1038 	mov	ar4,@r0
                           1039 ;	genCall
   1D44 8A 82              1040 	mov	dpl,r2
   1D46 8B 83              1041 	mov	dph,r3
   1D48 8C F0              1042 	mov	b,r4
   1D4A 12 2A A3           1043 	lcall	_vListInitialise
                           1044 ;	../../FreeRTOS/Source/queue.c:224: vListInitialise( &( pxNewQueue->xTasksWaitingToReceive ) );
                           1045 ;	genPlus
   1D4D A8 10              1046 	mov	r0,_bp
   1D4F 08                 1047 	inc	r0
   1D50 08                 1048 	inc	r0
                           1049 ;     genPlusIncr
   1D51 74 18              1050 	mov	a,#0x18
   1D53 26                 1051 	add	a,@r0
   1D54 FA                 1052 	mov	r2,a
                           1053 ;	Peephole 181	changed mov to clr
   1D55 E4                 1054 	clr	a
   1D56 08                 1055 	inc	r0
   1D57 36                 1056 	addc	a,@r0
   1D58 FB                 1057 	mov	r3,a
   1D59 08                 1058 	inc	r0
   1D5A 86 04              1059 	mov	ar4,@r0
                           1060 ;	genCall
   1D5C 8A 82              1061 	mov	dpl,r2
   1D5E 8B 83              1062 	mov	dph,r3
   1D60 8C F0              1063 	mov	b,r4
   1D62 12 2A A3           1064 	lcall	_vListInitialise
                           1065 ;	../../FreeRTOS/Source/queue.c:226: return  pxNewQueue;
                           1066 ;	genRet
   1D65 A8 10              1067 	mov	r0,_bp
   1D67 08                 1068 	inc	r0
   1D68 08                 1069 	inc	r0
   1D69 86 82              1070 	mov	dpl,@r0
   1D6B 08                 1071 	inc	r0
   1D6C 86 83              1072 	mov	dph,@r0
   1D6E 08                 1073 	inc	r0
   1D6F 86 F0              1074 	mov	b,@r0
                           1075 ;	Peephole 112.b	changed ljmp to sjmp
   1D71 80 15              1076 	sjmp	00108$
   1D73                    1077 00102$:
                           1078 ;	../../FreeRTOS/Source/queue.c:230: vPortFree( pxNewQueue );
                           1079 ;	genCall
   1D73 A8 10              1080 	mov	r0,_bp
   1D75 08                 1081 	inc	r0
   1D76 08                 1082 	inc	r0
   1D77 86 82              1083 	mov	dpl,@r0
   1D79 08                 1084 	inc	r0
   1D7A 86 83              1085 	mov	dph,@r0
   1D7C 08                 1086 	inc	r0
   1D7D 86 F0              1087 	mov	b,@r0
   1D7F 12 37 35           1088 	lcall	_vPortFree
   1D82                    1089 00107$:
                           1090 ;	../../FreeRTOS/Source/queue.c:237: return NULL;
                           1091 ;	genRet
                           1092 ;	Peephole 182.b	used 16 bit load of dptr
   1D82 90 00 00           1093 	mov	dptr,#0x0000
   1D85 75 F0 00           1094 	mov	b,#0x00
   1D88                    1095 00108$:
   1D88 85 10 81           1096 	mov	sp,_bp
   1D8B D0 10              1097 	pop	_bp
   1D8D 22                 1098 	ret
                           1099 ;------------------------------------------------------------
                           1100 ;Allocation info for local variables in function 'xQueueSend'
                           1101 ;------------------------------------------------------------
                           1102 ;pvItemToQueue             Allocated to stack - offset -5
                           1103 ;xTicksToWait              Allocated to stack - offset -7
                           1104 ;pxQueue                   Allocated to stack - offset 1
                           1105 ;xReturn                   Allocated to registers r2 
                           1106 ;xTimeOut                  Allocated to stack - offset 4
                           1107 ;sloc0                     Allocated to stack - offset 7
                           1108 ;sloc1                     Allocated to stack - offset 10
                           1109 ;sloc2                     Allocated to stack - offset 13
                           1110 ;sloc3                     Allocated to stack - offset 16
                           1111 ;sloc4                     Allocated to stack - offset 19
                           1112 ;------------------------------------------------------------
                           1113 ;	../../FreeRTOS/Source/queue.c:241: signed portBASE_TYPE xQueueSend( xQueueHandle pxQueue, const void *pvItemToQueue, portTickType xTicksToWait )
                           1114 ;	-----------------------------------------
                           1115 ;	 function xQueueSend
                           1116 ;	-----------------------------------------
   1D8E                    1117 _xQueueSend:
   1D8E C0 10              1118 	push	_bp
   1D90 85 81 10           1119 	mov	_bp,sp
                           1120 ;     genReceive
   1D93 C0 82              1121 	push	dpl
   1D95 C0 83              1122 	push	dph
   1D97 C0 F0              1123 	push	b
   1D99 E5 81              1124 	mov	a,sp
   1D9B 24 14              1125 	add	a,#0x14
   1D9D F5 81              1126 	mov	sp,a
                           1127 ;	../../FreeRTOS/Source/queue.c:247: vTaskSuspendAll();
                           1128 ;	genCall
   1D9F 12 0E 2C           1129 	lcall	_vTaskSuspendAll
                           1130 ;	../../FreeRTOS/Source/queue.c:250: vTaskSetTimeOutState( &xTimeOut );
                           1131 ;	genAddrOf
   1DA2 E5 10              1132 	mov	a,_bp
   1DA4 24 04              1133 	add	a,#0x04
   1DA6 FD                 1134 	mov	r5,a
                           1135 ;	genCast
   1DA7 7E 00              1136 	mov	r6,#0x00
   1DA9 7F 40              1137 	mov	r7,#0x40
                           1138 ;	genCall
   1DAB 8D 82              1139 	mov	dpl,r5
   1DAD 8E 83              1140 	mov	dph,r6
   1DAF 8F F0              1141 	mov	b,r7
   1DB1 12 16 42           1142 	lcall	_vTaskSetTimeOutState
                           1143 ;	../../FreeRTOS/Source/queue.c:272: prvLockQueue( pxQueue );
                           1144 ;	genInline
   1DB4 C0 E0 C0 A8        1145 	 push ACC push IE 
                           1146 ;	genAssign
   1DB8 C2 AF              1147 	clr	_EA
                           1148 ;	genPlus
   1DBA A8 10              1149 	mov	r0,_bp
   1DBC 08                 1150 	inc	r0
                           1151 ;     genPlusIncr
   1DBD 74 27              1152 	mov	a,#0x27
   1DBF 26                 1153 	add	a,@r0
   1DC0 FD                 1154 	mov	r5,a
                           1155 ;	Peephole 181	changed mov to clr
   1DC1 E4                 1156 	clr	a
   1DC2 08                 1157 	inc	r0
   1DC3 36                 1158 	addc	a,@r0
   1DC4 FE                 1159 	mov	r6,a
   1DC5 08                 1160 	inc	r0
   1DC6 86 07              1161 	mov	ar7,@r0
                           1162 ;	genPointerGet
                           1163 ;	genGenPointerGet
   1DC8 8D 82              1164 	mov	dpl,r5
   1DCA 8E 83              1165 	mov	dph,r6
   1DCC 8F F0              1166 	mov	b,r7
   1DCE 12 E4 9F           1167 	lcall	__gptrget
                           1168 ;	genPlus
                           1169 ;     genPlusIncr
                           1170 ;	Peephole 185	changed order of increment (acc incremented also!)
   1DD1 04                 1171 	inc	a
                           1172 ;	genPointerSet
                           1173 ;	genGenPointerSet
   1DD2 FA                 1174 	mov	r2,a
   1DD3 8D 82              1175 	mov	dpl,r5
   1DD5 8E 83              1176 	mov	dph,r6
   1DD7 8F F0              1177 	mov	b,r7
                           1178 ;	Peephole 191	removed redundant mov
   1DD9 12 DF B7           1179 	lcall	__gptrput
                           1180 ;	genPlus
   1DDC A8 10              1181 	mov	r0,_bp
   1DDE 08                 1182 	inc	r0
                           1183 ;     genPlusIncr
   1DDF 74 28              1184 	mov	a,#0x28
   1DE1 26                 1185 	add	a,@r0
   1DE2 FA                 1186 	mov	r2,a
                           1187 ;	Peephole 181	changed mov to clr
   1DE3 E4                 1188 	clr	a
   1DE4 08                 1189 	inc	r0
   1DE5 36                 1190 	addc	a,@r0
   1DE6 FB                 1191 	mov	r3,a
   1DE7 08                 1192 	inc	r0
   1DE8 86 04              1193 	mov	ar4,@r0
                           1194 ;	genPointerGet
                           1195 ;	genGenPointerGet
   1DEA 8A 82              1196 	mov	dpl,r2
   1DEC 8B 83              1197 	mov	dph,r3
   1DEE 8C F0              1198 	mov	b,r4
   1DF0 12 E4 9F           1199 	lcall	__gptrget
                           1200 ;	genPlus
                           1201 ;     genPlusIncr
                           1202 ;	Peephole 185	changed order of increment (acc incremented also!)
   1DF3 04                 1203 	inc	a
                           1204 ;	genPointerSet
                           1205 ;	genGenPointerSet
   1DF4 FD                 1206 	mov	r5,a
   1DF5 8A 82              1207 	mov	dpl,r2
   1DF7 8B 83              1208 	mov	dph,r3
   1DF9 8C F0              1209 	mov	b,r4
                           1210 ;	Peephole 191	removed redundant mov
   1DFB 12 DF B7           1211 	lcall	__gptrput
                           1212 ;	genInline
   1DFE D0 E0              1213 	 pop ACC 
                           1214 ;	genAnd
   1E00 53 E0 80           1215 	anl	_ACC,#0x80
                           1216 ;	genOr
   1E03 E5 E0              1217 	mov	a,_ACC
   1E05 42 A8              1218 	orl	_IE,a
                           1219 ;	genInline
   1E07 D0 E0              1220 	 pop ACC 
                           1221 ;	../../FreeRTOS/Source/queue.c:290: do
                           1222 ;	genPlus
   1E09 A8 10              1223 	mov	r0,_bp
   1E0B 08                 1224 	inc	r0
   1E0C E5 10              1225 	mov	a,_bp
   1E0E 24 0A              1226 	add	a,#0x0a
   1E10 F9                 1227 	mov	r1,a
                           1228 ;     genPlusIncr
   1E11 74 26              1229 	mov	a,#0x26
   1E13 26                 1230 	add	a,@r0
   1E14 F7                 1231 	mov	@r1,a
                           1232 ;	Peephole 181	changed mov to clr
   1E15 E4                 1233 	clr	a
   1E16 08                 1234 	inc	r0
   1E17 36                 1235 	addc	a,@r0
   1E18 09                 1236 	inc	r1
   1E19 F7                 1237 	mov	@r1,a
   1E1A 08                 1238 	inc	r0
   1E1B 09                 1239 	inc	r1
   1E1C E6                 1240 	mov	a,@r0
   1E1D F7                 1241 	mov	@r1,a
                           1242 ;	genPlus
   1E1E A8 10              1243 	mov	r0,_bp
   1E20 08                 1244 	inc	r0
   1E21 E5 10              1245 	mov	a,_bp
   1E23 24 0D              1246 	add	a,#0x0d
   1E25 F9                 1247 	mov	r1,a
                           1248 ;     genPlusIncr
   1E26 74 03              1249 	mov	a,#0x03
   1E28 26                 1250 	add	a,@r0
   1E29 F7                 1251 	mov	@r1,a
                           1252 ;	Peephole 181	changed mov to clr
   1E2A E4                 1253 	clr	a
   1E2B 08                 1254 	inc	r0
   1E2C 36                 1255 	addc	a,@r0
   1E2D 09                 1256 	inc	r1
   1E2E F7                 1257 	mov	@r1,a
   1E2F 08                 1258 	inc	r0
   1E30 09                 1259 	inc	r1
   1E31 E6                 1260 	mov	a,@r0
   1E32 F7                 1261 	mov	@r1,a
                           1262 ;	genPlus
   1E33 A8 10              1263 	mov	r0,_bp
   1E35 08                 1264 	inc	r0
   1E36 E5 10              1265 	mov	a,_bp
   1E38 24 07              1266 	add	a,#0x07
   1E3A F9                 1267 	mov	r1,a
                           1268 ;     genPlusIncr
   1E3B 74 25              1269 	mov	a,#0x25
   1E3D 26                 1270 	add	a,@r0
   1E3E F7                 1271 	mov	@r1,a
                           1272 ;	Peephole 181	changed mov to clr
   1E3F E4                 1273 	clr	a
   1E40 08                 1274 	inc	r0
   1E41 36                 1275 	addc	a,@r0
   1E42 09                 1276 	inc	r1
   1E43 F7                 1277 	mov	@r1,a
   1E44 08                 1278 	inc	r0
   1E45 09                 1279 	inc	r1
   1E46 E6                 1280 	mov	a,@r0
   1E47 F7                 1281 	mov	@r1,a
   1E48                    1282 00118$:
                           1283 ;	../../FreeRTOS/Source/queue.c:292: if( prvIsQueueFull( pxQueue ) )
                           1284 ;	genCall
   1E48 A8 10              1285 	mov	r0,_bp
   1E4A 08                 1286 	inc	r0
   1E4B 86 82              1287 	mov	dpl,@r0
   1E4D 08                 1288 	inc	r0
   1E4E 86 83              1289 	mov	dph,@r0
   1E50 08                 1290 	inc	r0
   1E51 86 F0              1291 	mov	b,@r0
   1E53 12 2A 5B           1292 	lcall	_prvIsQueueFull
   1E56 E5 82              1293 	mov	a,dpl
                           1294 ;	genIfx
                           1295 ;	genIfxJump
   1E58 70 03              1296 	jnz	00133$
   1E5A 02 1F 12           1297 	ljmp	00106$
   1E5D                    1298 00133$:
                           1299 ;	../../FreeRTOS/Source/queue.c:296: if( xTicksToWait > ( portTickType ) 0 )
                           1300 ;	genIfx
   1E5D E5 10              1301 	mov	a,_bp
   1E5F 24 F9              1302 	add	a,#0xfffffff9
   1E61 F8                 1303 	mov	r0,a
   1E62 E6                 1304 	mov	a,@r0
   1E63 08                 1305 	inc	r0
   1E64 46                 1306 	orl	a,@r0
                           1307 ;	genIfxJump
   1E65 70 03              1308 	jnz	00134$
   1E67 02 1F 12           1309 	ljmp	00106$
   1E6A                    1310 00134$:
                           1311 ;	../../FreeRTOS/Source/queue.c:311: vTaskPlaceOnEventList( &( pxQueue->xTasksWaitingToSend ), xTicksToWait );
                           1312 ;	genIpush
                           1313 ;	genPlus
   1E6A A8 10              1314 	mov	r0,_bp
   1E6C 08                 1315 	inc	r0
                           1316 ;     genPlusIncr
   1E6D 74 0C              1317 	mov	a,#0x0C
   1E6F 26                 1318 	add	a,@r0
   1E70 FD                 1319 	mov	r5,a
                           1320 ;	Peephole 181	changed mov to clr
   1E71 E4                 1321 	clr	a
   1E72 08                 1322 	inc	r0
   1E73 36                 1323 	addc	a,@r0
   1E74 FE                 1324 	mov	r6,a
   1E75 08                 1325 	inc	r0
   1E76 86 07              1326 	mov	ar7,@r0
                           1327 ;	genIpush
   1E78 E5 10              1328 	mov	a,_bp
   1E7A 24 F9              1329 	add	a,#0xfffffff9
   1E7C F8                 1330 	mov	r0,a
   1E7D E6                 1331 	mov	a,@r0
   1E7E C0 E0              1332 	push	acc
   1E80 08                 1333 	inc	r0
   1E81 E6                 1334 	mov	a,@r0
   1E82 C0 E0              1335 	push	acc
                           1336 ;	genCall
   1E84 8D 82              1337 	mov	dpl,r5
   1E86 8E 83              1338 	mov	dph,r6
   1E88 8F F0              1339 	mov	b,r7
   1E8A 12 13 DD           1340 	lcall	_vTaskPlaceOnEventList
   1E8D 15 81              1341 	dec	sp
   1E8F 15 81              1342 	dec	sp
                           1343 ;	../../FreeRTOS/Source/queue.c:323: taskENTER_CRITICAL();
                           1344 ;	genInline
   1E91 C0 E0 C0 A8        1345 	 push ACC push IE 
                           1346 ;	genAssign
   1E95 C2 AF              1347 	clr	_EA
                           1348 ;	../../FreeRTOS/Source/queue.c:332: prvUnlockQueue( pxQueue );
                           1349 ;	genCall
   1E97 A8 10              1350 	mov	r0,_bp
   1E99 08                 1351 	inc	r0
   1E9A 86 82              1352 	mov	dpl,@r0
   1E9C 08                 1353 	inc	r0
   1E9D 86 83              1354 	mov	dph,@r0
   1E9F 08                 1355 	inc	r0
   1EA0 86 F0              1356 	mov	b,@r0
   1EA2 12 29 21           1357 	lcall	_prvUnlockQueue
                           1358 ;	../../FreeRTOS/Source/queue.c:336: if( !xTaskResumeAll() )
                           1359 ;	genCall
   1EA5 12 0E 45           1360 	lcall	_xTaskResumeAll
   1EA8 E5 82              1361 	mov	a,dpl
                           1362 ;	genIpop
                           1363 ;	genIfx
                           1364 ;	genIfxJump
                           1365 ;	Peephole 108.b	removed ljmp by inverse jump logic
   1EAA 70 03              1366 	jnz	00102$
                           1367 ;	Peephole 300	removed redundant label 00135$
                           1368 ;	../../FreeRTOS/Source/queue.c:338: taskYIELD();
                           1369 ;	genCall
   1EAC 12 33 E8           1370 	lcall	_vPortYield
   1EAF                    1371 00102$:
                           1372 ;	../../FreeRTOS/Source/queue.c:343: vTaskSuspendAll();
                           1373 ;	genIpush
                           1374 ;	genCall
   1EAF 12 0E 2C           1375 	lcall	_vTaskSuspendAll
                           1376 ;	../../FreeRTOS/Source/queue.c:344: prvLockQueue( pxQueue );				
                           1377 ;	genInline
   1EB2 C0 E0 C0 A8        1378 	 push ACC push IE 
                           1379 ;	genAssign
   1EB6 C2 AF              1380 	clr	_EA
                           1381 ;	genPlus
   1EB8 A8 10              1382 	mov	r0,_bp
   1EBA 08                 1383 	inc	r0
                           1384 ;     genPlusIncr
   1EBB 74 27              1385 	mov	a,#0x27
   1EBD 26                 1386 	add	a,@r0
   1EBE FD                 1387 	mov	r5,a
                           1388 ;	Peephole 181	changed mov to clr
   1EBF E4                 1389 	clr	a
   1EC0 08                 1390 	inc	r0
   1EC1 36                 1391 	addc	a,@r0
   1EC2 FE                 1392 	mov	r6,a
   1EC3 08                 1393 	inc	r0
   1EC4 86 07              1394 	mov	ar7,@r0
                           1395 ;	genPointerGet
                           1396 ;	genGenPointerGet
   1EC6 8D 82              1397 	mov	dpl,r5
   1EC8 8E 83              1398 	mov	dph,r6
   1ECA 8F F0              1399 	mov	b,r7
   1ECC 12 E4 9F           1400 	lcall	__gptrget
                           1401 ;	genPlus
                           1402 ;     genPlusIncr
                           1403 ;	Peephole 185	changed order of increment (acc incremented also!)
   1ECF 04                 1404 	inc	a
                           1405 ;	genPointerSet
                           1406 ;	genGenPointerSet
   1ED0 FA                 1407 	mov	r2,a
   1ED1 8D 82              1408 	mov	dpl,r5
   1ED3 8E 83              1409 	mov	dph,r6
   1ED5 8F F0              1410 	mov	b,r7
                           1411 ;	Peephole 191	removed redundant mov
   1ED7 12 DF B7           1412 	lcall	__gptrput
                           1413 ;	genPlus
   1EDA A8 10              1414 	mov	r0,_bp
   1EDC 08                 1415 	inc	r0
                           1416 ;     genPlusIncr
   1EDD 74 28              1417 	mov	a,#0x28
   1EDF 26                 1418 	add	a,@r0
   1EE0 FA                 1419 	mov	r2,a
                           1420 ;	Peephole 181	changed mov to clr
   1EE1 E4                 1421 	clr	a
   1EE2 08                 1422 	inc	r0
   1EE3 36                 1423 	addc	a,@r0
   1EE4 FB                 1424 	mov	r3,a
   1EE5 08                 1425 	inc	r0
   1EE6 86 04              1426 	mov	ar4,@r0
                           1427 ;	genPointerGet
                           1428 ;	genGenPointerGet
   1EE8 8A 82              1429 	mov	dpl,r2
   1EEA 8B 83              1430 	mov	dph,r3
   1EEC 8C F0              1431 	mov	b,r4
   1EEE 12 E4 9F           1432 	lcall	__gptrget
                           1433 ;	genPlus
                           1434 ;     genPlusIncr
                           1435 ;	Peephole 185	changed order of increment (acc incremented also!)
   1EF1 04                 1436 	inc	a
                           1437 ;	genPointerSet
                           1438 ;	genGenPointerSet
   1EF2 FD                 1439 	mov	r5,a
   1EF3 8A 82              1440 	mov	dpl,r2
   1EF5 8B 83              1441 	mov	dph,r3
   1EF7 8C F0              1442 	mov	b,r4
                           1443 ;	Peephole 191	removed redundant mov
   1EF9 12 DF B7           1444 	lcall	__gptrput
                           1445 ;	genInline
   1EFC D0 E0              1446 	 pop ACC 
                           1447 ;	genAnd
   1EFE 53 E0 80           1448 	anl	_ACC,#0x80
                           1449 ;	genOr
   1F01 E5 E0              1450 	mov	a,_ACC
   1F03 42 A8              1451 	orl	_IE,a
                           1452 ;	genInline
   1F05 D0 E0              1453 	 pop ACC 
                           1454 ;	../../FreeRTOS/Source/queue.c:346: taskEXIT_CRITICAL();
                           1455 ;	genInline
   1F07 D0 E0              1456 	 pop ACC 
                           1457 ;	genAnd
   1F09 53 E0 80           1458 	anl	_ACC,#0x80
                           1459 ;	genOr
   1F0C E5 E0              1460 	mov	a,_ACC
   1F0E 42 A8              1461 	orl	_IE,a
                           1462 ;	genInline
   1F10 D0 E0              1463 	 pop ACC 
                           1464 ;	../../FreeRTOS/Source/queue.c:390: return xReturn;
                           1465 ;	genIpop
                           1466 ;	../../FreeRTOS/Source/queue.c:346: taskEXIT_CRITICAL();
   1F12                    1467 00106$:
                           1468 ;	../../FreeRTOS/Source/queue.c:355: taskENTER_CRITICAL();
                           1469 ;	genIpush
                           1470 ;	genInline
   1F12 C0 E0 C0 A8        1471 	 push ACC push IE 
                           1472 ;	genAssign
   1F16 C2 AF              1473 	clr	_EA
                           1474 ;	../../FreeRTOS/Source/queue.c:357: if( pxQueue->uxMessagesWaiting < pxQueue->uxLength )
                           1475 ;	genPlus
   1F18 A8 10              1476 	mov	r0,_bp
   1F1A 08                 1477 	inc	r0
                           1478 ;     genPlusIncr
   1F1B 74 24              1479 	mov	a,#0x24
   1F1D 26                 1480 	add	a,@r0
   1F1E FA                 1481 	mov	r2,a
                           1482 ;	Peephole 181	changed mov to clr
   1F1F E4                 1483 	clr	a
   1F20 08                 1484 	inc	r0
   1F21 36                 1485 	addc	a,@r0
   1F22 FB                 1486 	mov	r3,a
   1F23 08                 1487 	inc	r0
   1F24 86 04              1488 	mov	ar4,@r0
                           1489 ;	genPointerGet
                           1490 ;	genGenPointerGet
   1F26 8A 82              1491 	mov	dpl,r2
   1F28 8B 83              1492 	mov	dph,r3
   1F2A 8C F0              1493 	mov	b,r4
   1F2C 12 E4 9F           1494 	lcall	__gptrget
   1F2F FD                 1495 	mov	r5,a
                           1496 ;	genPointerGet
                           1497 ;	genGenPointerGet
   1F30 E5 10              1498 	mov	a,_bp
   1F32 24 07              1499 	add	a,#0x07
   1F34 F8                 1500 	mov	r0,a
   1F35 86 82              1501 	mov	dpl,@r0
   1F37 08                 1502 	inc	r0
   1F38 86 83              1503 	mov	dph,@r0
   1F3A 08                 1504 	inc	r0
   1F3B 86 F0              1505 	mov	b,@r0
   1F3D 12 E4 9F           1506 	lcall	__gptrget
   1F40 FE                 1507 	mov	r6,a
                           1508 ;	genCmpLt
                           1509 ;	genCmp
   1F41 C3                 1510 	clr	c
   1F42 ED                 1511 	mov	a,r5
   1F43 9E                 1512 	subb	a,r6
                           1513 ;	genIpop
                           1514 ;	genIfx
                           1515 ;	genIfxJump
                           1516 ;	Peephole 129.a	jump optimization
   1F44 40 03              1517 	jc	00136$
   1F46 02 20 B1           1518 	ljmp	00110$
   1F49                    1519 00136$:
                           1520 ;	../../FreeRTOS/Source/queue.c:360: prvCopyQueueData( pxQueue, pvItemToQueue );		
                           1521 ;	genPointerGet
                           1522 ;	genGenPointerGet
   1F49 E5 10              1523 	mov	a,_bp
   1F4B 24 0A              1524 	add	a,#0x0a
   1F4D F8                 1525 	mov	r0,a
   1F4E 86 82              1526 	mov	dpl,@r0
   1F50 08                 1527 	inc	r0
   1F51 86 83              1528 	mov	dph,@r0
   1F53 08                 1529 	inc	r0
   1F54 86 F0              1530 	mov	b,@r0
   1F56 12 E4 9F           1531 	lcall	__gptrget
   1F59 FD                 1532 	mov	r5,a
                           1533 ;	genCast
   1F5A E5 10              1534 	mov	a,_bp
   1F5C 24 13              1535 	add	a,#0x13
   1F5E F8                 1536 	mov	r0,a
   1F5F A6 05              1537 	mov	@r0,ar5
   1F61 08                 1538 	inc	r0
   1F62 76 00              1539 	mov	@r0,#0x00
                           1540 ;	genPlus
   1F64 A8 10              1541 	mov	r0,_bp
   1F66 08                 1542 	inc	r0
   1F67 E5 10              1543 	mov	a,_bp
   1F69 24 10              1544 	add	a,#0x10
   1F6B F9                 1545 	mov	r1,a
                           1546 ;     genPlusIncr
   1F6C 74 06              1547 	mov	a,#0x06
   1F6E 26                 1548 	add	a,@r0
   1F6F F7                 1549 	mov	@r1,a
                           1550 ;	Peephole 181	changed mov to clr
   1F70 E4                 1551 	clr	a
   1F71 08                 1552 	inc	r0
   1F72 36                 1553 	addc	a,@r0
   1F73 09                 1554 	inc	r1
   1F74 F7                 1555 	mov	@r1,a
   1F75 08                 1556 	inc	r0
   1F76 09                 1557 	inc	r1
   1F77 E6                 1558 	mov	a,@r0
   1F78 F7                 1559 	mov	@r1,a
                           1560 ;	genPointerGet
                           1561 ;	genGenPointerGet
   1F79 E5 10              1562 	mov	a,_bp
   1F7B 24 10              1563 	add	a,#0x10
   1F7D F8                 1564 	mov	r0,a
   1F7E 86 82              1565 	mov	dpl,@r0
   1F80 08                 1566 	inc	r0
   1F81 86 83              1567 	mov	dph,@r0
   1F83 08                 1568 	inc	r0
   1F84 86 F0              1569 	mov	b,@r0
   1F86 12 E4 9F           1570 	lcall	__gptrget
   1F89 FF                 1571 	mov	r7,a
   1F8A A3                 1572 	inc	dptr
   1F8B 12 E4 9F           1573 	lcall	__gptrget
   1F8E FD                 1574 	mov	r5,a
   1F8F A3                 1575 	inc	dptr
   1F90 12 E4 9F           1576 	lcall	__gptrget
   1F93 FE                 1577 	mov	r6,a
                           1578 ;	genIpush
   1F94 C0 02              1579 	push	ar2
   1F96 C0 03              1580 	push	ar3
   1F98 C0 04              1581 	push	ar4
   1F9A E5 10              1582 	mov	a,_bp
   1F9C 24 13              1583 	add	a,#0x13
   1F9E F8                 1584 	mov	r0,a
   1F9F E6                 1585 	mov	a,@r0
   1FA0 C0 E0              1586 	push	acc
   1FA2 08                 1587 	inc	r0
   1FA3 E6                 1588 	mov	a,@r0
   1FA4 C0 E0              1589 	push	acc
                           1590 ;	genIpush
   1FA6 E5 10              1591 	mov	a,_bp
   1FA8 24 FB              1592 	add	a,#0xfffffffb
   1FAA F8                 1593 	mov	r0,a
   1FAB E6                 1594 	mov	a,@r0
   1FAC C0 E0              1595 	push	acc
   1FAE 08                 1596 	inc	r0
   1FAF E6                 1597 	mov	a,@r0
   1FB0 C0 E0              1598 	push	acc
   1FB2 08                 1599 	inc	r0
   1FB3 E6                 1600 	mov	a,@r0
   1FB4 C0 E0              1601 	push	acc
                           1602 ;	genCall
   1FB6 8F 82              1603 	mov	dpl,r7
   1FB8 8D 83              1604 	mov	dph,r5
   1FBA 8E F0              1605 	mov	b,r6
   1FBC 12 E2 C7           1606 	lcall	_memcpy
   1FBF E5 81              1607 	mov	a,sp
   1FC1 24 FB              1608 	add	a,#0xfb
   1FC3 F5 81              1609 	mov	sp,a
   1FC5 D0 04              1610 	pop	ar4
   1FC7 D0 03              1611 	pop	ar3
   1FC9 D0 02              1612 	pop	ar2
                           1613 ;	genPointerGet
                           1614 ;	genGenPointerGet
   1FCB 8A 82              1615 	mov	dpl,r2
   1FCD 8B 83              1616 	mov	dph,r3
   1FCF 8C F0              1617 	mov	b,r4
   1FD1 12 E4 9F           1618 	lcall	__gptrget
                           1619 ;	genPlus
                           1620 ;     genPlusIncr
                           1621 ;	Peephole 185	changed order of increment (acc incremented also!)
   1FD4 04                 1622 	inc	a
                           1623 ;	genPointerSet
                           1624 ;	genGenPointerSet
   1FD5 FD                 1625 	mov	r5,a
   1FD6 8A 82              1626 	mov	dpl,r2
   1FD8 8B 83              1627 	mov	dph,r3
   1FDA 8C F0              1628 	mov	b,r4
                           1629 ;	Peephole 191	removed redundant mov
   1FDC 12 DF B7           1630 	lcall	__gptrput
                           1631 ;	genPointerGet
                           1632 ;	genGenPointerGet
   1FDF E5 10              1633 	mov	a,_bp
   1FE1 24 10              1634 	add	a,#0x10
   1FE3 F8                 1635 	mov	r0,a
   1FE4 86 82              1636 	mov	dpl,@r0
   1FE6 08                 1637 	inc	r0
   1FE7 86 83              1638 	mov	dph,@r0
   1FE9 08                 1639 	inc	r0
   1FEA 86 F0              1640 	mov	b,@r0
   1FEC 12 E4 9F           1641 	lcall	__gptrget
   1FEF FA                 1642 	mov	r2,a
   1FF0 A3                 1643 	inc	dptr
   1FF1 12 E4 9F           1644 	lcall	__gptrget
   1FF4 FB                 1645 	mov	r3,a
   1FF5 A3                 1646 	inc	dptr
   1FF6 12 E4 9F           1647 	lcall	__gptrget
   1FF9 FC                 1648 	mov	r4,a
                           1649 ;	genPointerGet
                           1650 ;	genGenPointerGet
   1FFA E5 10              1651 	mov	a,_bp
   1FFC 24 0A              1652 	add	a,#0x0a
   1FFE F8                 1653 	mov	r0,a
   1FFF 86 82              1654 	mov	dpl,@r0
   2001 08                 1655 	inc	r0
   2002 86 83              1656 	mov	dph,@r0
   2004 08                 1657 	inc	r0
   2005 86 F0              1658 	mov	b,@r0
   2007 12 E4 9F           1659 	lcall	__gptrget
                           1660 ;	genPlus
   200A FD                 1661 	mov	r5,a
                           1662 ;	Peephole 177.b	removed redundant mov
                           1663 ;	Peephole 236.a	used r2 instead of ar2
   200B 2A                 1664 	add	a,r2
   200C FA                 1665 	mov	r2,a
                           1666 ;	Peephole 181	changed mov to clr
   200D E4                 1667 	clr	a
                           1668 ;	Peephole 236.b	used r3 instead of ar3
   200E 3B                 1669 	addc	a,r3
   200F FB                 1670 	mov	r3,a
                           1671 ;	genPointerSet
                           1672 ;	genGenPointerSet
   2010 E5 10              1673 	mov	a,_bp
   2012 24 10              1674 	add	a,#0x10
   2014 F8                 1675 	mov	r0,a
   2015 86 82              1676 	mov	dpl,@r0
   2017 08                 1677 	inc	r0
   2018 86 83              1678 	mov	dph,@r0
   201A 08                 1679 	inc	r0
   201B 86 F0              1680 	mov	b,@r0
   201D EA                 1681 	mov	a,r2
   201E 12 DF B7           1682 	lcall	__gptrput
   2021 A3                 1683 	inc	dptr
   2022 EB                 1684 	mov	a,r3
   2023 12 DF B7           1685 	lcall	__gptrput
   2026 A3                 1686 	inc	dptr
   2027 EC                 1687 	mov	a,r4
   2028 12 DF B7           1688 	lcall	__gptrput
                           1689 ;	genPointerGet
                           1690 ;	genGenPointerGet
   202B E5 10              1691 	mov	a,_bp
   202D 24 0D              1692 	add	a,#0x0d
   202F F8                 1693 	mov	r0,a
   2030 86 82              1694 	mov	dpl,@r0
   2032 08                 1695 	inc	r0
   2033 86 83              1696 	mov	dph,@r0
   2035 08                 1697 	inc	r0
   2036 86 F0              1698 	mov	b,@r0
   2038 12 E4 9F           1699 	lcall	__gptrget
   203B FD                 1700 	mov	r5,a
   203C A3                 1701 	inc	dptr
   203D 12 E4 9F           1702 	lcall	__gptrget
   2040 FE                 1703 	mov	r6,a
   2041 A3                 1704 	inc	dptr
   2042 12 E4 9F           1705 	lcall	__gptrget
   2045 FF                 1706 	mov	r7,a
                           1707 ;	genCmpLt
                           1708 ;	genCmp
   2046 C3                 1709 	clr	c
   2047 EA                 1710 	mov	a,r2
   2048 9D                 1711 	subb	a,r5
   2049 EB                 1712 	mov	a,r3
   204A 9E                 1713 	subb	a,r6
   204B EC                 1714 	mov	a,r4
   204C 64 80              1715 	xrl	a,#0x80
   204E 8F F0              1716 	mov	b,r7
   2050 63 F0 80           1717 	xrl	b,#0x80
   2053 95 F0              1718 	subb	a,b
                           1719 ;	genIfxJump
                           1720 ;	Peephole 112.b	changed ljmp to sjmp
                           1721 ;	Peephole 160.a	removed sjmp by inverse jump logic
   2055 40 34              1722 	jc	00108$
                           1723 ;	Peephole 300	removed redundant label 00137$
                           1724 ;	genPointerGet
                           1725 ;	genGenPointerGet
   2057 A8 10              1726 	mov	r0,_bp
   2059 08                 1727 	inc	r0
   205A 86 82              1728 	mov	dpl,@r0
   205C 08                 1729 	inc	r0
   205D 86 83              1730 	mov	dph,@r0
   205F 08                 1731 	inc	r0
   2060 86 F0              1732 	mov	b,@r0
   2062 12 E4 9F           1733 	lcall	__gptrget
   2065 FA                 1734 	mov	r2,a
   2066 A3                 1735 	inc	dptr
   2067 12 E4 9F           1736 	lcall	__gptrget
   206A FB                 1737 	mov	r3,a
   206B A3                 1738 	inc	dptr
   206C 12 E4 9F           1739 	lcall	__gptrget
   206F FC                 1740 	mov	r4,a
                           1741 ;	genPointerSet
                           1742 ;	genGenPointerSet
   2070 E5 10              1743 	mov	a,_bp
   2072 24 10              1744 	add	a,#0x10
   2074 F8                 1745 	mov	r0,a
   2075 86 82              1746 	mov	dpl,@r0
   2077 08                 1747 	inc	r0
   2078 86 83              1748 	mov	dph,@r0
   207A 08                 1749 	inc	r0
   207B 86 F0              1750 	mov	b,@r0
   207D EA                 1751 	mov	a,r2
   207E 12 DF B7           1752 	lcall	__gptrput
   2081 A3                 1753 	inc	dptr
   2082 EB                 1754 	mov	a,r3
   2083 12 DF B7           1755 	lcall	__gptrput
   2086 A3                 1756 	inc	dptr
   2087 EC                 1757 	mov	a,r4
   2088 12 DF B7           1758 	lcall	__gptrput
   208B                    1759 00108$:
                           1760 ;	../../FreeRTOS/Source/queue.c:361: xReturn = pdPASS;
                           1761 ;	genAssign
   208B 7A 01              1762 	mov	r2,#0x01
                           1763 ;	../../FreeRTOS/Source/queue.c:365: ++( pxQueue->xTxLock );
                           1764 ;	genPlus
   208D A8 10              1765 	mov	r0,_bp
   208F 08                 1766 	inc	r0
                           1767 ;     genPlusIncr
   2090 74 28              1768 	mov	a,#0x28
   2092 26                 1769 	add	a,@r0
   2093 FB                 1770 	mov	r3,a
                           1771 ;	Peephole 181	changed mov to clr
   2094 E4                 1772 	clr	a
   2095 08                 1773 	inc	r0
   2096 36                 1774 	addc	a,@r0
   2097 FC                 1775 	mov	r4,a
   2098 08                 1776 	inc	r0
   2099 86 05              1777 	mov	ar5,@r0
                           1778 ;	genPointerGet
                           1779 ;	genGenPointerGet
   209B 8B 82              1780 	mov	dpl,r3
   209D 8C 83              1781 	mov	dph,r4
   209F 8D F0              1782 	mov	b,r5
   20A1 12 E4 9F           1783 	lcall	__gptrget
                           1784 ;	genPlus
                           1785 ;     genPlusIncr
                           1786 ;	Peephole 185	changed order of increment (acc incremented also!)
   20A4 04                 1787 	inc	a
                           1788 ;	genPointerSet
                           1789 ;	genGenPointerSet
   20A5 FE                 1790 	mov	r6,a
   20A6 8B 82              1791 	mov	dpl,r3
   20A8 8C 83              1792 	mov	dph,r4
   20AA 8D F0              1793 	mov	b,r5
                           1794 ;	Peephole 191	removed redundant mov
   20AC 12 DF B7           1795 	lcall	__gptrput
                           1796 ;	Peephole 112.b	changed ljmp to sjmp
   20AF 80 02              1797 	sjmp	00111$
   20B1                    1798 00110$:
                           1799 ;	../../FreeRTOS/Source/queue.c:369: xReturn = errQUEUE_FULL;
                           1800 ;	genAssign
   20B1 7A 00              1801 	mov	r2,#0x00
   20B3                    1802 00111$:
                           1803 ;	../../FreeRTOS/Source/queue.c:372: taskEXIT_CRITICAL();
                           1804 ;	genInline
   20B3 D0 E0              1805 	 pop ACC 
                           1806 ;	genAnd
   20B5 53 E0 80           1807 	anl	_ACC,#0x80
                           1808 ;	genOr
   20B8 E5 E0              1809 	mov	a,_ACC
   20BA 42 A8              1810 	orl	_IE,a
                           1811 ;	genInline
   20BC D0 E0              1812 	 pop ACC 
                           1813 ;	../../FreeRTOS/Source/queue.c:374: if( xReturn == errQUEUE_FULL )
                           1814 ;	genIfx
   20BE EA                 1815 	mov	a,r2
                           1816 ;	genIfxJump
                           1817 ;	Peephole 108.b	removed ljmp by inverse jump logic
   20BF 70 3C              1818 	jnz	00119$
                           1819 ;	Peephole 300	removed redundant label 00138$
                           1820 ;	../../FreeRTOS/Source/queue.c:376: if( xTicksToWait > 0 )
                           1821 ;	genIfx
   20C1 E5 10              1822 	mov	a,_bp
   20C3 24 F9              1823 	add	a,#0xfffffff9
   20C5 F8                 1824 	mov	r0,a
   20C6 E6                 1825 	mov	a,@r0
   20C7 08                 1826 	inc	r0
   20C8 46                 1827 	orl	a,@r0
                           1828 ;	genIfxJump
                           1829 ;	Peephole 108.c	removed ljmp by inverse jump logic
   20C9 60 32              1830 	jz	00119$
                           1831 ;	Peephole 300	removed redundant label 00139$
                           1832 ;	../../FreeRTOS/Source/queue.c:378: if( xTaskCheckForTimeOut( &xTimeOut, &xTicksToWait ) == pdFALSE )
                           1833 ;	genIpush
   20CB C0 02              1834 	push	ar2
                           1835 ;	genAddrOf
   20CD E5 10              1836 	mov	a,_bp
   20CF 24 F9              1837 	add	a,#0xf9
   20D1 FB                 1838 	mov	r3,a
                           1839 ;	genCast
   20D2 7C 00              1840 	mov	r4,#0x00
   20D4 7D 40              1841 	mov	r5,#0x40
                           1842 ;	genAddrOf
   20D6 E5 10              1843 	mov	a,_bp
   20D8 24 04              1844 	add	a,#0x04
   20DA FE                 1845 	mov	r6,a
                           1846 ;	genCast
   20DB 7F 00              1847 	mov	r7,#0x00
   20DD 7A 40              1848 	mov	r2,#0x40
                           1849 ;	genIpush
   20DF C0 03              1850 	push	ar3
   20E1 C0 04              1851 	push	ar4
   20E3 C0 05              1852 	push	ar5
                           1853 ;	genCall
   20E5 8E 82              1854 	mov	dpl,r6
   20E7 8F 83              1855 	mov	dph,r7
   20E9 8A F0              1856 	mov	b,r2
   20EB 12 16 72           1857 	lcall	_xTaskCheckForTimeOut
   20EE AA 82              1858 	mov	r2,dpl
   20F0 15 81              1859 	dec	sp
   20F2 15 81              1860 	dec	sp
   20F4 15 81              1861 	dec	sp
                           1862 ;	genIfx
   20F6 EA                 1863 	mov	a,r2
                           1864 ;	genIpop
   20F7 D0 02              1865 	pop	ar2
                           1866 ;	genIfxJump
                           1867 ;	Peephole 108.b	removed ljmp by inverse jump logic
   20F9 70 02              1868 	jnz	00119$
                           1869 ;	Peephole 300	removed redundant label 00140$
                           1870 ;	../../FreeRTOS/Source/queue.c:380: xReturn = queueERRONEOUS_UNBLOCK;
                           1871 ;	genAssign
   20FB 7A FF              1872 	mov	r2,#0xFF
   20FD                    1873 00119$:
                           1874 ;	../../FreeRTOS/Source/queue.c:385: while( xReturn == queueERRONEOUS_UNBLOCK );
                           1875 ;	genCmpEq
                           1876 ;	gencjneshort
   20FD BA FF 03           1877 	cjne	r2,#0xFF,00141$
   2100 02 1E 48           1878 	ljmp	00118$
   2103                    1879 00141$:
                           1880 ;	../../FreeRTOS/Source/queue.c:387: prvUnlockQueue( pxQueue );
                           1881 ;	genCall
   2103 A8 10              1882 	mov	r0,_bp
   2105 08                 1883 	inc	r0
   2106 86 82              1884 	mov	dpl,@r0
   2108 08                 1885 	inc	r0
   2109 86 83              1886 	mov	dph,@r0
   210B 08                 1887 	inc	r0
   210C 86 F0              1888 	mov	b,@r0
   210E C0 02              1889 	push	ar2
   2110 12 29 21           1890 	lcall	_prvUnlockQueue
   2113 D0 02              1891 	pop	ar2
                           1892 ;	../../FreeRTOS/Source/queue.c:388: xTaskResumeAll();
                           1893 ;	genCall
   2115 C0 02              1894 	push	ar2
   2117 12 0E 45           1895 	lcall	_xTaskResumeAll
   211A D0 02              1896 	pop	ar2
                           1897 ;	../../FreeRTOS/Source/queue.c:390: return xReturn;
                           1898 ;	genRet
   211C 8A 82              1899 	mov	dpl,r2
                           1900 ;	Peephole 300	removed redundant label 00121$
   211E 85 10 81           1901 	mov	sp,_bp
   2121 D0 10              1902 	pop	_bp
   2123 22                 1903 	ret
                           1904 ;------------------------------------------------------------
                           1905 ;Allocation info for local variables in function 'xQueueSendFromISR'
                           1906 ;------------------------------------------------------------
                           1907 ;pvItemToQueue             Allocated to stack - offset -5
                           1908 ;xTaskPreviouslyWoken      Allocated to stack - offset -6
                           1909 ;pxQueue                   Allocated to stack - offset 1
                           1910 ;sloc0                     Allocated to stack - offset 4
                           1911 ;sloc1                     Allocated to stack - offset 5
                           1912 ;sloc2                     Allocated to stack - offset 8
                           1913 ;sloc3                     Allocated to stack - offset 11
                           1914 ;------------------------------------------------------------
                           1915 ;	../../FreeRTOS/Source/queue.c:394: signed portBASE_TYPE xQueueSendFromISR( xQueueHandle pxQueue, const void *pvItemToQueue, signed portBASE_TYPE xTaskPreviouslyWoken )
                           1916 ;	-----------------------------------------
                           1917 ;	 function xQueueSendFromISR
                           1918 ;	-----------------------------------------
   2124                    1919 _xQueueSendFromISR:
   2124 C0 10              1920 	push	_bp
   2126 85 81 10           1921 	mov	_bp,sp
                           1922 ;     genReceive
   2129 C0 82              1923 	push	dpl
   212B C0 83              1924 	push	dph
   212D C0 F0              1925 	push	b
   212F E5 81              1926 	mov	a,sp
   2131 24 0C              1927 	add	a,#0x0c
   2133 F5 81              1928 	mov	sp,a
                           1929 ;	../../FreeRTOS/Source/queue.c:401: if( pxQueue->uxMessagesWaiting < pxQueue->uxLength )
                           1930 ;	genPlus
   2135 A8 10              1931 	mov	r0,_bp
   2137 08                 1932 	inc	r0
                           1933 ;     genPlusIncr
   2138 74 24              1934 	mov	a,#0x24
   213A 26                 1935 	add	a,@r0
   213B FD                 1936 	mov	r5,a
                           1937 ;	Peephole 181	changed mov to clr
   213C E4                 1938 	clr	a
   213D 08                 1939 	inc	r0
   213E 36                 1940 	addc	a,@r0
   213F FE                 1941 	mov	r6,a
   2140 08                 1942 	inc	r0
   2141 86 07              1943 	mov	ar7,@r0
                           1944 ;	genPointerGet
                           1945 ;	genGenPointerGet
   2143 8D 82              1946 	mov	dpl,r5
   2145 8E 83              1947 	mov	dph,r6
   2147 8F F0              1948 	mov	b,r7
   2149 E5 10              1949 	mov	a,_bp
   214B 24 04              1950 	add	a,#0x04
   214D F8                 1951 	mov	r0,a
   214E 12 E4 9F           1952 	lcall	__gptrget
   2151 F6                 1953 	mov	@r0,a
                           1954 ;	genPlus
   2152 A8 10              1955 	mov	r0,_bp
   2154 08                 1956 	inc	r0
                           1957 ;     genPlusIncr
   2155 74 25              1958 	mov	a,#0x25
   2157 26                 1959 	add	a,@r0
   2158 FB                 1960 	mov	r3,a
                           1961 ;	Peephole 181	changed mov to clr
   2159 E4                 1962 	clr	a
   215A 08                 1963 	inc	r0
   215B 36                 1964 	addc	a,@r0
   215C FC                 1965 	mov	r4,a
   215D 08                 1966 	inc	r0
   215E 86 02              1967 	mov	ar2,@r0
                           1968 ;	genPointerGet
                           1969 ;	genGenPointerGet
   2160 8B 82              1970 	mov	dpl,r3
   2162 8C 83              1971 	mov	dph,r4
   2164 8A F0              1972 	mov	b,r2
   2166 12 E4 9F           1973 	lcall	__gptrget
   2169 FB                 1974 	mov	r3,a
                           1975 ;	genCmpLt
   216A E5 10              1976 	mov	a,_bp
   216C 24 04              1977 	add	a,#0x04
   216E F8                 1978 	mov	r0,a
                           1979 ;	genCmp
   216F C3                 1980 	clr	c
   2170 E6                 1981 	mov	a,@r0
   2171 9B                 1982 	subb	a,r3
                           1983 ;	genIfxJump
   2172 40 03              1984 	jc	00122$
   2174 02 23 4D           1985 	ljmp	00113$
   2177                    1986 00122$:
                           1987 ;	../../FreeRTOS/Source/queue.c:403: prvCopyQueueData( pxQueue, pvItemToQueue );
                           1988 ;	genPlus
   2177 A8 10              1989 	mov	r0,_bp
   2179 08                 1990 	inc	r0
   217A E5 10              1991 	mov	a,_bp
   217C 24 05              1992 	add	a,#0x05
   217E F9                 1993 	mov	r1,a
                           1994 ;     genPlusIncr
   217F 74 26              1995 	mov	a,#0x26
   2181 26                 1996 	add	a,@r0
   2182 F7                 1997 	mov	@r1,a
                           1998 ;	Peephole 181	changed mov to clr
   2183 E4                 1999 	clr	a
   2184 08                 2000 	inc	r0
   2185 36                 2001 	addc	a,@r0
   2186 09                 2002 	inc	r1
   2187 F7                 2003 	mov	@r1,a
   2188 08                 2004 	inc	r0
   2189 09                 2005 	inc	r1
   218A E6                 2006 	mov	a,@r0
   218B F7                 2007 	mov	@r1,a
                           2008 ;	genPointerGet
                           2009 ;	genGenPointerGet
   218C E5 10              2010 	mov	a,_bp
   218E 24 05              2011 	add	a,#0x05
   2190 F8                 2012 	mov	r0,a
   2191 86 82              2013 	mov	dpl,@r0
   2193 08                 2014 	inc	r0
   2194 86 83              2015 	mov	dph,@r0
   2196 08                 2016 	inc	r0
   2197 86 F0              2017 	mov	b,@r0
   2199 12 E4 9F           2018 	lcall	__gptrget
   219C FA                 2019 	mov	r2,a
                           2020 ;	genCast
   219D E5 10              2021 	mov	a,_bp
   219F 24 0B              2022 	add	a,#0x0b
   21A1 F8                 2023 	mov	r0,a
   21A2 A6 02              2024 	mov	@r0,ar2
   21A4 08                 2025 	inc	r0
   21A5 76 00              2026 	mov	@r0,#0x00
                           2027 ;	genPlus
   21A7 A8 10              2028 	mov	r0,_bp
   21A9 08                 2029 	inc	r0
   21AA E5 10              2030 	mov	a,_bp
   21AC 24 08              2031 	add	a,#0x08
   21AE F9                 2032 	mov	r1,a
                           2033 ;     genPlusIncr
   21AF 74 06              2034 	mov	a,#0x06
   21B1 26                 2035 	add	a,@r0
   21B2 F7                 2036 	mov	@r1,a
                           2037 ;	Peephole 181	changed mov to clr
   21B3 E4                 2038 	clr	a
   21B4 08                 2039 	inc	r0
   21B5 36                 2040 	addc	a,@r0
   21B6 09                 2041 	inc	r1
   21B7 F7                 2042 	mov	@r1,a
   21B8 08                 2043 	inc	r0
   21B9 09                 2044 	inc	r1
   21BA E6                 2045 	mov	a,@r0
   21BB F7                 2046 	mov	@r1,a
                           2047 ;	genPointerGet
                           2048 ;	genGenPointerGet
   21BC E5 10              2049 	mov	a,_bp
   21BE 24 08              2050 	add	a,#0x08
   21C0 F8                 2051 	mov	r0,a
   21C1 86 82              2052 	mov	dpl,@r0
   21C3 08                 2053 	inc	r0
   21C4 86 83              2054 	mov	dph,@r0
   21C6 08                 2055 	inc	r0
   21C7 86 F0              2056 	mov	b,@r0
   21C9 12 E4 9F           2057 	lcall	__gptrget
   21CC FC                 2058 	mov	r4,a
   21CD A3                 2059 	inc	dptr
   21CE 12 E4 9F           2060 	lcall	__gptrget
   21D1 FA                 2061 	mov	r2,a
   21D2 A3                 2062 	inc	dptr
   21D3 12 E4 9F           2063 	lcall	__gptrget
   21D6 FB                 2064 	mov	r3,a
                           2065 ;	genIpush
   21D7 C0 05              2066 	push	ar5
   21D9 C0 06              2067 	push	ar6
   21DB C0 07              2068 	push	ar7
   21DD E5 10              2069 	mov	a,_bp
   21DF 24 0B              2070 	add	a,#0x0b
   21E1 F8                 2071 	mov	r0,a
   21E2 E6                 2072 	mov	a,@r0
   21E3 C0 E0              2073 	push	acc
   21E5 08                 2074 	inc	r0
   21E6 E6                 2075 	mov	a,@r0
   21E7 C0 E0              2076 	push	acc
                           2077 ;	genIpush
   21E9 E5 10              2078 	mov	a,_bp
   21EB 24 FB              2079 	add	a,#0xfffffffb
   21ED F8                 2080 	mov	r0,a
   21EE E6                 2081 	mov	a,@r0
   21EF C0 E0              2082 	push	acc
   21F1 08                 2083 	inc	r0
   21F2 E6                 2084 	mov	a,@r0
   21F3 C0 E0              2085 	push	acc
   21F5 08                 2086 	inc	r0
   21F6 E6                 2087 	mov	a,@r0
   21F7 C0 E0              2088 	push	acc
                           2089 ;	genCall
   21F9 8C 82              2090 	mov	dpl,r4
   21FB 8A 83              2091 	mov	dph,r2
   21FD 8B F0              2092 	mov	b,r3
   21FF 12 E2 C7           2093 	lcall	_memcpy
   2202 E5 81              2094 	mov	a,sp
   2204 24 FB              2095 	add	a,#0xfb
   2206 F5 81              2096 	mov	sp,a
   2208 D0 07              2097 	pop	ar7
   220A D0 06              2098 	pop	ar6
   220C D0 05              2099 	pop	ar5
                           2100 ;	genPointerGet
                           2101 ;	genGenPointerGet
   220E 8D 82              2102 	mov	dpl,r5
   2210 8E 83              2103 	mov	dph,r6
   2212 8F F0              2104 	mov	b,r7
   2214 12 E4 9F           2105 	lcall	__gptrget
                           2106 ;	genPlus
                           2107 ;     genPlusIncr
                           2108 ;	Peephole 185	changed order of increment (acc incremented also!)
   2217 04                 2109 	inc	a
                           2110 ;	genPointerSet
                           2111 ;	genGenPointerSet
   2218 FA                 2112 	mov	r2,a
   2219 8D 82              2113 	mov	dpl,r5
   221B 8E 83              2114 	mov	dph,r6
   221D 8F F0              2115 	mov	b,r7
                           2116 ;	Peephole 191	removed redundant mov
   221F 12 DF B7           2117 	lcall	__gptrput
                           2118 ;	genPointerGet
                           2119 ;	genGenPointerGet
   2222 E5 10              2120 	mov	a,_bp
   2224 24 08              2121 	add	a,#0x08
   2226 F8                 2122 	mov	r0,a
   2227 86 82              2123 	mov	dpl,@r0
   2229 08                 2124 	inc	r0
   222A 86 83              2125 	mov	dph,@r0
   222C 08                 2126 	inc	r0
   222D 86 F0              2127 	mov	b,@r0
   222F 12 E4 9F           2128 	lcall	__gptrget
   2232 FA                 2129 	mov	r2,a
   2233 A3                 2130 	inc	dptr
   2234 12 E4 9F           2131 	lcall	__gptrget
   2237 FB                 2132 	mov	r3,a
   2238 A3                 2133 	inc	dptr
   2239 12 E4 9F           2134 	lcall	__gptrget
   223C FC                 2135 	mov	r4,a
                           2136 ;	genPointerGet
                           2137 ;	genGenPointerGet
   223D E5 10              2138 	mov	a,_bp
   223F 24 05              2139 	add	a,#0x05
   2241 F8                 2140 	mov	r0,a
   2242 86 82              2141 	mov	dpl,@r0
   2244 08                 2142 	inc	r0
   2245 86 83              2143 	mov	dph,@r0
   2247 08                 2144 	inc	r0
   2248 86 F0              2145 	mov	b,@r0
   224A 12 E4 9F           2146 	lcall	__gptrget
                           2147 ;	genPlus
   224D FD                 2148 	mov	r5,a
                           2149 ;	Peephole 177.b	removed redundant mov
                           2150 ;	Peephole 236.a	used r2 instead of ar2
   224E 2A                 2151 	add	a,r2
   224F FA                 2152 	mov	r2,a
                           2153 ;	Peephole 181	changed mov to clr
   2250 E4                 2154 	clr	a
                           2155 ;	Peephole 236.b	used r3 instead of ar3
   2251 3B                 2156 	addc	a,r3
   2252 FB                 2157 	mov	r3,a
                           2158 ;	genPointerSet
                           2159 ;	genGenPointerSet
   2253 E5 10              2160 	mov	a,_bp
   2255 24 08              2161 	add	a,#0x08
   2257 F8                 2162 	mov	r0,a
   2258 86 82              2163 	mov	dpl,@r0
   225A 08                 2164 	inc	r0
   225B 86 83              2165 	mov	dph,@r0
   225D 08                 2166 	inc	r0
   225E 86 F0              2167 	mov	b,@r0
   2260 EA                 2168 	mov	a,r2
   2261 12 DF B7           2169 	lcall	__gptrput
   2264 A3                 2170 	inc	dptr
   2265 EB                 2171 	mov	a,r3
   2266 12 DF B7           2172 	lcall	__gptrput
   2269 A3                 2173 	inc	dptr
   226A EC                 2174 	mov	a,r4
   226B 12 DF B7           2175 	lcall	__gptrput
                           2176 ;	genPlus
   226E A8 10              2177 	mov	r0,_bp
   2270 08                 2178 	inc	r0
                           2179 ;     genPlusIncr
   2271 74 03              2180 	mov	a,#0x03
   2273 26                 2181 	add	a,@r0
   2274 FD                 2182 	mov	r5,a
                           2183 ;	Peephole 181	changed mov to clr
   2275 E4                 2184 	clr	a
   2276 08                 2185 	inc	r0
   2277 36                 2186 	addc	a,@r0
   2278 FE                 2187 	mov	r6,a
   2279 08                 2188 	inc	r0
   227A 86 07              2189 	mov	ar7,@r0
                           2190 ;	genPointerGet
                           2191 ;	genGenPointerGet
   227C 8D 82              2192 	mov	dpl,r5
   227E 8E 83              2193 	mov	dph,r6
   2280 8F F0              2194 	mov	b,r7
   2282 12 E4 9F           2195 	lcall	__gptrget
   2285 FD                 2196 	mov	r5,a
   2286 A3                 2197 	inc	dptr
   2287 12 E4 9F           2198 	lcall	__gptrget
   228A FE                 2199 	mov	r6,a
   228B A3                 2200 	inc	dptr
   228C 12 E4 9F           2201 	lcall	__gptrget
   228F FF                 2202 	mov	r7,a
                           2203 ;	genCmpLt
                           2204 ;	genCmp
   2290 C3                 2205 	clr	c
   2291 EA                 2206 	mov	a,r2
   2292 9D                 2207 	subb	a,r5
   2293 EB                 2208 	mov	a,r3
   2294 9E                 2209 	subb	a,r6
   2295 EC                 2210 	mov	a,r4
   2296 64 80              2211 	xrl	a,#0x80
   2298 8F F0              2212 	mov	b,r7
   229A 63 F0 80           2213 	xrl	b,#0x80
   229D 95 F0              2214 	subb	a,b
                           2215 ;	genIfxJump
                           2216 ;	Peephole 112.b	changed ljmp to sjmp
                           2217 ;	Peephole 160.a	removed sjmp by inverse jump logic
   229F 40 34              2218 	jc	00102$
                           2219 ;	Peephole 300	removed redundant label 00123$
                           2220 ;	genPointerGet
                           2221 ;	genGenPointerGet
   22A1 A8 10              2222 	mov	r0,_bp
   22A3 08                 2223 	inc	r0
   22A4 86 82              2224 	mov	dpl,@r0
   22A6 08                 2225 	inc	r0
   22A7 86 83              2226 	mov	dph,@r0
   22A9 08                 2227 	inc	r0
   22AA 86 F0              2228 	mov	b,@r0
   22AC 12 E4 9F           2229 	lcall	__gptrget
   22AF FA                 2230 	mov	r2,a
   22B0 A3                 2231 	inc	dptr
   22B1 12 E4 9F           2232 	lcall	__gptrget
   22B4 FB                 2233 	mov	r3,a
   22B5 A3                 2234 	inc	dptr
   22B6 12 E4 9F           2235 	lcall	__gptrget
   22B9 FC                 2236 	mov	r4,a
                           2237 ;	genPointerSet
                           2238 ;	genGenPointerSet
   22BA E5 10              2239 	mov	a,_bp
   22BC 24 08              2240 	add	a,#0x08
   22BE F8                 2241 	mov	r0,a
   22BF 86 82              2242 	mov	dpl,@r0
   22C1 08                 2243 	inc	r0
   22C2 86 83              2244 	mov	dph,@r0
   22C4 08                 2245 	inc	r0
   22C5 86 F0              2246 	mov	b,@r0
   22C7 EA                 2247 	mov	a,r2
   22C8 12 DF B7           2248 	lcall	__gptrput
   22CB A3                 2249 	inc	dptr
   22CC EB                 2250 	mov	a,r3
   22CD 12 DF B7           2251 	lcall	__gptrput
   22D0 A3                 2252 	inc	dptr
   22D1 EC                 2253 	mov	a,r4
   22D2 12 DF B7           2254 	lcall	__gptrput
   22D5                    2255 00102$:
                           2256 ;	../../FreeRTOS/Source/queue.c:407: if( pxQueue->xTxLock == queueUNLOCKED )
                           2257 ;	genPlus
   22D5 A8 10              2258 	mov	r0,_bp
   22D7 08                 2259 	inc	r0
                           2260 ;     genPlusIncr
   22D8 74 28              2261 	mov	a,#0x28
   22DA 26                 2262 	add	a,@r0
   22DB FA                 2263 	mov	r2,a
                           2264 ;	Peephole 181	changed mov to clr
   22DC E4                 2265 	clr	a
   22DD 08                 2266 	inc	r0
   22DE 36                 2267 	addc	a,@r0
   22DF FB                 2268 	mov	r3,a
   22E0 08                 2269 	inc	r0
   22E1 86 04              2270 	mov	ar4,@r0
                           2271 ;	genPointerGet
                           2272 ;	genGenPointerGet
   22E3 8A 82              2273 	mov	dpl,r2
   22E5 8B 83              2274 	mov	dph,r3
   22E7 8C F0              2275 	mov	b,r4
   22E9 12 E4 9F           2276 	lcall	__gptrget
   22EC FD                 2277 	mov	r5,a
                           2278 ;	genCmpEq
                           2279 ;	gencjneshort
                           2280 ;	Peephole 112.b	changed ljmp to sjmp
                           2281 ;	Peephole 198.b	optimized misc jump sequence
   22ED BD FF 52           2282 	cjne	r5,#0xFF,00110$
                           2283 ;	Peephole 200.b	removed redundant sjmp
                           2284 ;	Peephole 300	removed redundant label 00124$
                           2285 ;	Peephole 300	removed redundant label 00125$
                           2286 ;	../../FreeRTOS/Source/queue.c:411: if( !xTaskPreviouslyWoken )		
                           2287 ;	genIfx
   22F0 E5 10              2288 	mov	a,_bp
   22F2 24 FA              2289 	add	a,#0xfffffffa
   22F4 F8                 2290 	mov	r0,a
   22F5 E6                 2291 	mov	a,@r0
                           2292 ;	genIfxJump
                           2293 ;	Peephole 108.b	removed ljmp by inverse jump logic
   22F6 70 55              2294 	jnz	00113$
                           2295 ;	Peephole 300	removed redundant label 00126$
                           2296 ;	../../FreeRTOS/Source/queue.c:413: if( !listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToReceive ) ) )
                           2297 ;	genPlus
   22F8 A8 10              2298 	mov	r0,_bp
   22FA 08                 2299 	inc	r0
                           2300 ;     genPlusIncr
   22FB 74 18              2301 	mov	a,#0x18
   22FD 26                 2302 	add	a,@r0
   22FE FA                 2303 	mov	r2,a
                           2304 ;	Peephole 181	changed mov to clr
   22FF E4                 2305 	clr	a
   2300 08                 2306 	inc	r0
   2301 36                 2307 	addc	a,@r0
   2302 FB                 2308 	mov	r3,a
   2303 08                 2309 	inc	r0
   2304 86 04              2310 	mov	ar4,@r0
                           2311 ;	genPointerGet
                           2312 ;	genGenPointerGet
   2306 8A 82              2313 	mov	dpl,r2
   2308 8B 83              2314 	mov	dph,r3
   230A 8C F0              2315 	mov	b,r4
   230C 12 E4 9F           2316 	lcall	__gptrget
                           2317 ;	genIfxJump
                           2318 ;	Peephole 108.c	removed ljmp by inverse jump logic
   230F 60 3C              2319 	jz	00113$
                           2320 ;	Peephole 300	removed redundant label 00127$
                           2321 ;	../../FreeRTOS/Source/queue.c:415: if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToReceive ) ) != pdFALSE )
                           2322 ;	genPlus
   2311 A8 10              2323 	mov	r0,_bp
   2313 08                 2324 	inc	r0
   2314 E5 10              2325 	mov	a,_bp
   2316 24 08              2326 	add	a,#0x08
   2318 F9                 2327 	mov	r1,a
                           2328 ;     genPlusIncr
   2319 74 18              2329 	mov	a,#0x18
   231B 26                 2330 	add	a,@r0
   231C F7                 2331 	mov	@r1,a
                           2332 ;	Peephole 181	changed mov to clr
   231D E4                 2333 	clr	a
   231E 08                 2334 	inc	r0
   231F 36                 2335 	addc	a,@r0
   2320 09                 2336 	inc	r1
   2321 F7                 2337 	mov	@r1,a
   2322 08                 2338 	inc	r0
   2323 09                 2339 	inc	r1
   2324 E6                 2340 	mov	a,@r0
   2325 F7                 2341 	mov	@r1,a
                           2342 ;	genCall
   2326 E5 10              2343 	mov	a,_bp
   2328 24 08              2344 	add	a,#0x08
   232A F8                 2345 	mov	r0,a
   232B 86 82              2346 	mov	dpl,@r0
   232D 08                 2347 	inc	r0
   232E 86 83              2348 	mov	dph,@r0
   2330 08                 2349 	inc	r0
   2331 86 F0              2350 	mov	b,@r0
   2333 12 14 D7           2351 	lcall	_xTaskRemoveFromEventList
   2336 AE 82              2352 	mov	r6,dpl
                           2353 ;	genCmpEq
                           2354 ;	gencjneshort
   2338 BE 00 02           2355 	cjne	r6,#0x00,00128$
                           2356 ;	Peephole 112.b	changed ljmp to sjmp
   233B 80 10              2357 	sjmp	00113$
   233D                    2358 00128$:
                           2359 ;	../../FreeRTOS/Source/queue.c:419: return pdTRUE;
                           2360 ;	genRet
   233D 75 82 01           2361 	mov	dpl,#0x01
                           2362 ;	Peephole 112.b	changed ljmp to sjmp
   2340 80 12              2363 	sjmp	00114$
   2342                    2364 00110$:
                           2365 ;	../../FreeRTOS/Source/queue.c:428: ++( pxQueue->xTxLock );
                           2366 ;	genPlus
                           2367 ;     genPlusIncr
   2342 0D                 2368 	inc	r5
                           2369 ;	genPointerSet
                           2370 ;	genGenPointerSet
   2343 8A 82              2371 	mov	dpl,r2
   2345 8B 83              2372 	mov	dph,r3
   2347 8C F0              2373 	mov	b,r4
   2349 ED                 2374 	mov	a,r5
   234A 12 DF B7           2375 	lcall	__gptrput
   234D                    2376 00113$:
                           2377 ;	../../FreeRTOS/Source/queue.c:432: return xTaskPreviouslyWoken;
                           2378 ;	genRet
   234D E5 10              2379 	mov	a,_bp
   234F 24 FA              2380 	add	a,#0xfffffffa
   2351 F8                 2381 	mov	r0,a
   2352 86 82              2382 	mov	dpl,@r0
   2354                    2383 00114$:
   2354 85 10 81           2384 	mov	sp,_bp
   2357 D0 10              2385 	pop	_bp
   2359 22                 2386 	ret
                           2387 ;------------------------------------------------------------
                           2388 ;Allocation info for local variables in function 'xQueueReceive'
                           2389 ;------------------------------------------------------------
                           2390 ;pvBuffer                  Allocated to stack - offset -5
                           2391 ;xTicksToWait              Allocated to stack - offset -7
                           2392 ;pxQueue                   Allocated to stack - offset 1
                           2393 ;xReturn                   Allocated to registers r2 
                           2394 ;xTimeOut                  Allocated to stack - offset 4
                           2395 ;sloc0                     Allocated to stack - offset 7
                           2396 ;sloc1                     Allocated to stack - offset 10
                           2397 ;sloc2                     Allocated to stack - offset 13
                           2398 ;------------------------------------------------------------
                           2399 ;	../../FreeRTOS/Source/queue.c:436: signed portBASE_TYPE xQueueReceive( xQueueHandle pxQueue, void *pvBuffer, portTickType xTicksToWait )
                           2400 ;	-----------------------------------------
                           2401 ;	 function xQueueReceive
                           2402 ;	-----------------------------------------
   235A                    2403 _xQueueReceive:
   235A C0 10              2404 	push	_bp
   235C 85 81 10           2405 	mov	_bp,sp
                           2406 ;     genReceive
   235F C0 82              2407 	push	dpl
   2361 C0 83              2408 	push	dph
   2363 C0 F0              2409 	push	b
   2365 E5 81              2410 	mov	a,sp
   2367 24 0F              2411 	add	a,#0x0f
   2369 F5 81              2412 	mov	sp,a
                           2413 ;	../../FreeRTOS/Source/queue.c:445: vTaskSuspendAll();
                           2414 ;	genCall
   236B 12 0E 2C           2415 	lcall	_vTaskSuspendAll
                           2416 ;	../../FreeRTOS/Source/queue.c:448: vTaskSetTimeOutState( &xTimeOut );
                           2417 ;	genAddrOf
   236E E5 10              2418 	mov	a,_bp
   2370 24 04              2419 	add	a,#0x04
   2372 FD                 2420 	mov	r5,a
                           2421 ;	genCast
   2373 7E 00              2422 	mov	r6,#0x00
   2375 7F 40              2423 	mov	r7,#0x40
                           2424 ;	genCall
   2377 8D 82              2425 	mov	dpl,r5
   2379 8E 83              2426 	mov	dph,r6
   237B 8F F0              2427 	mov	b,r7
   237D 12 16 42           2428 	lcall	_vTaskSetTimeOutState
                           2429 ;	../../FreeRTOS/Source/queue.c:451: prvLockQueue( pxQueue );
                           2430 ;	genInline
   2380 C0 E0 C0 A8        2431 	 push ACC push IE 
                           2432 ;	genAssign
   2384 C2 AF              2433 	clr	_EA
                           2434 ;	genPlus
   2386 A8 10              2435 	mov	r0,_bp
   2388 08                 2436 	inc	r0
                           2437 ;     genPlusIncr
   2389 74 27              2438 	mov	a,#0x27
   238B 26                 2439 	add	a,@r0
   238C FD                 2440 	mov	r5,a
                           2441 ;	Peephole 181	changed mov to clr
   238D E4                 2442 	clr	a
   238E 08                 2443 	inc	r0
   238F 36                 2444 	addc	a,@r0
   2390 FE                 2445 	mov	r6,a
   2391 08                 2446 	inc	r0
   2392 86 07              2447 	mov	ar7,@r0
                           2448 ;	genPointerGet
                           2449 ;	genGenPointerGet
   2394 8D 82              2450 	mov	dpl,r5
   2396 8E 83              2451 	mov	dph,r6
   2398 8F F0              2452 	mov	b,r7
   239A 12 E4 9F           2453 	lcall	__gptrget
                           2454 ;	genPlus
                           2455 ;     genPlusIncr
                           2456 ;	Peephole 185	changed order of increment (acc incremented also!)
   239D 04                 2457 	inc	a
                           2458 ;	genPointerSet
                           2459 ;	genGenPointerSet
   239E FA                 2460 	mov	r2,a
   239F 8D 82              2461 	mov	dpl,r5
   23A1 8E 83              2462 	mov	dph,r6
   23A3 8F F0              2463 	mov	b,r7
                           2464 ;	Peephole 191	removed redundant mov
   23A5 12 DF B7           2465 	lcall	__gptrput
                           2466 ;	genPlus
   23A8 A8 10              2467 	mov	r0,_bp
   23AA 08                 2468 	inc	r0
                           2469 ;     genPlusIncr
   23AB 74 28              2470 	mov	a,#0x28
   23AD 26                 2471 	add	a,@r0
   23AE FA                 2472 	mov	r2,a
                           2473 ;	Peephole 181	changed mov to clr
   23AF E4                 2474 	clr	a
   23B0 08                 2475 	inc	r0
   23B1 36                 2476 	addc	a,@r0
   23B2 FB                 2477 	mov	r3,a
   23B3 08                 2478 	inc	r0
   23B4 86 04              2479 	mov	ar4,@r0
                           2480 ;	genPointerGet
                           2481 ;	genGenPointerGet
   23B6 8A 82              2482 	mov	dpl,r2
   23B8 8B 83              2483 	mov	dph,r3
   23BA 8C F0              2484 	mov	b,r4
   23BC 12 E4 9F           2485 	lcall	__gptrget
                           2486 ;	genPlus
                           2487 ;     genPlusIncr
                           2488 ;	Peephole 185	changed order of increment (acc incremented also!)
   23BF 04                 2489 	inc	a
                           2490 ;	genPointerSet
                           2491 ;	genGenPointerSet
   23C0 FD                 2492 	mov	r5,a
   23C1 8A 82              2493 	mov	dpl,r2
   23C3 8B 83              2494 	mov	dph,r3
   23C5 8C F0              2495 	mov	b,r4
                           2496 ;	Peephole 191	removed redundant mov
   23C7 12 DF B7           2497 	lcall	__gptrput
                           2498 ;	genInline
   23CA D0 E0              2499 	 pop ACC 
                           2500 ;	genAnd
   23CC 53 E0 80           2501 	anl	_ACC,#0x80
                           2502 ;	genOr
   23CF E5 E0              2503 	mov	a,_ACC
   23D1 42 A8              2504 	orl	_IE,a
                           2505 ;	genInline
   23D3 D0 E0              2506 	 pop ACC 
                           2507 ;	../../FreeRTOS/Source/queue.c:453: do
                           2508 ;	genPlus
   23D5 A8 10              2509 	mov	r0,_bp
   23D7 08                 2510 	inc	r0
   23D8 E5 10              2511 	mov	a,_bp
   23DA 24 07              2512 	add	a,#0x07
   23DC F9                 2513 	mov	r1,a
                           2514 ;     genPlusIncr
   23DD 74 26              2515 	mov	a,#0x26
   23DF 26                 2516 	add	a,@r0
   23E0 F7                 2517 	mov	@r1,a
                           2518 ;	Peephole 181	changed mov to clr
   23E1 E4                 2519 	clr	a
   23E2 08                 2520 	inc	r0
   23E3 36                 2521 	addc	a,@r0
   23E4 09                 2522 	inc	r1
   23E5 F7                 2523 	mov	@r1,a
   23E6 08                 2524 	inc	r0
   23E7 09                 2525 	inc	r1
   23E8 E6                 2526 	mov	a,@r0
   23E9 F7                 2527 	mov	@r1,a
                           2528 ;	genPlus
   23EA A8 10              2529 	mov	r0,_bp
   23EC 08                 2530 	inc	r0
   23ED E5 10              2531 	mov	a,_bp
   23EF 24 0D              2532 	add	a,#0x0d
   23F1 F9                 2533 	mov	r1,a
                           2534 ;     genPlusIncr
   23F2 74 03              2535 	mov	a,#0x03
   23F4 26                 2536 	add	a,@r0
   23F5 F7                 2537 	mov	@r1,a
                           2538 ;	Peephole 181	changed mov to clr
   23F6 E4                 2539 	clr	a
   23F7 08                 2540 	inc	r0
   23F8 36                 2541 	addc	a,@r0
   23F9 09                 2542 	inc	r1
   23FA F7                 2543 	mov	@r1,a
   23FB 08                 2544 	inc	r0
   23FC 09                 2545 	inc	r1
   23FD E6                 2546 	mov	a,@r0
   23FE F7                 2547 	mov	@r1,a
   23FF                    2548 00118$:
                           2549 ;	../../FreeRTOS/Source/queue.c:456: if( prvIsQueueEmpty( pxQueue ) )
                           2550 ;	genCall
   23FF A8 10              2551 	mov	r0,_bp
   2401 08                 2552 	inc	r0
   2402 86 82              2553 	mov	dpl,@r0
   2404 08                 2554 	inc	r0
   2405 86 83              2555 	mov	dph,@r0
   2407 08                 2556 	inc	r0
   2408 86 F0              2557 	mov	b,@r0
   240A 12 2A 2A           2558 	lcall	_prvIsQueueEmpty
   240D E5 82              2559 	mov	a,dpl
                           2560 ;	genIfx
                           2561 ;	genIfxJump
   240F 70 03              2562 	jnz	00133$
   2411 02 24 C9           2563 	ljmp	00106$
   2414                    2564 00133$:
                           2565 ;	../../FreeRTOS/Source/queue.c:460: if( xTicksToWait > ( portTickType ) 0 )
                           2566 ;	genIfx
   2414 E5 10              2567 	mov	a,_bp
   2416 24 F9              2568 	add	a,#0xfffffff9
   2418 F8                 2569 	mov	r0,a
   2419 E6                 2570 	mov	a,@r0
   241A 08                 2571 	inc	r0
   241B 46                 2572 	orl	a,@r0
                           2573 ;	genIfxJump
   241C 70 03              2574 	jnz	00134$
   241E 02 24 C9           2575 	ljmp	00106$
   2421                    2576 00134$:
                           2577 ;	../../FreeRTOS/Source/queue.c:462: vTaskPlaceOnEventList( &( pxQueue->xTasksWaitingToReceive ), xTicksToWait );
                           2578 ;	genIpush
                           2579 ;	genPlus
   2421 A8 10              2580 	mov	r0,_bp
   2423 08                 2581 	inc	r0
                           2582 ;     genPlusIncr
   2424 74 18              2583 	mov	a,#0x18
   2426 26                 2584 	add	a,@r0
   2427 FD                 2585 	mov	r5,a
                           2586 ;	Peephole 181	changed mov to clr
   2428 E4                 2587 	clr	a
   2429 08                 2588 	inc	r0
   242A 36                 2589 	addc	a,@r0
   242B FE                 2590 	mov	r6,a
   242C 08                 2591 	inc	r0
   242D 86 07              2592 	mov	ar7,@r0
                           2593 ;	genIpush
   242F E5 10              2594 	mov	a,_bp
   2431 24 F9              2595 	add	a,#0xfffffff9
   2433 F8                 2596 	mov	r0,a
   2434 E6                 2597 	mov	a,@r0
   2435 C0 E0              2598 	push	acc
   2437 08                 2599 	inc	r0
   2438 E6                 2600 	mov	a,@r0
   2439 C0 E0              2601 	push	acc
                           2602 ;	genCall
   243B 8D 82              2603 	mov	dpl,r5
   243D 8E 83              2604 	mov	dph,r6
   243F 8F F0              2605 	mov	b,r7
   2441 12 13 DD           2606 	lcall	_vTaskPlaceOnEventList
   2444 15 81              2607 	dec	sp
   2446 15 81              2608 	dec	sp
                           2609 ;	../../FreeRTOS/Source/queue.c:463: taskENTER_CRITICAL();
                           2610 ;	genInline
   2448 C0 E0 C0 A8        2611 	 push ACC push IE 
                           2612 ;	genAssign
   244C C2 AF              2613 	clr	_EA
                           2614 ;	../../FreeRTOS/Source/queue.c:465: prvUnlockQueue( pxQueue );
                           2615 ;	genCall
   244E A8 10              2616 	mov	r0,_bp
   2450 08                 2617 	inc	r0
   2451 86 82              2618 	mov	dpl,@r0
   2453 08                 2619 	inc	r0
   2454 86 83              2620 	mov	dph,@r0
   2456 08                 2621 	inc	r0
   2457 86 F0              2622 	mov	b,@r0
   2459 12 29 21           2623 	lcall	_prvUnlockQueue
                           2624 ;	../../FreeRTOS/Source/queue.c:466: if( !xTaskResumeAll() )
                           2625 ;	genCall
   245C 12 0E 45           2626 	lcall	_xTaskResumeAll
   245F E5 82              2627 	mov	a,dpl
                           2628 ;	genIpop
                           2629 ;	genIfx
                           2630 ;	genIfxJump
                           2631 ;	Peephole 108.b	removed ljmp by inverse jump logic
   2461 70 03              2632 	jnz	00102$
                           2633 ;	Peephole 300	removed redundant label 00135$
                           2634 ;	../../FreeRTOS/Source/queue.c:468: taskYIELD();
                           2635 ;	genCall
   2463 12 33 E8           2636 	lcall	_vPortYield
   2466                    2637 00102$:
                           2638 ;	../../FreeRTOS/Source/queue.c:471: vTaskSuspendAll();
                           2639 ;	genIpush
                           2640 ;	genCall
   2466 12 0E 2C           2641 	lcall	_vTaskSuspendAll
                           2642 ;	../../FreeRTOS/Source/queue.c:472: prvLockQueue( pxQueue );
                           2643 ;	genInline
   2469 C0 E0 C0 A8        2644 	 push ACC push IE 
                           2645 ;	genAssign
   246D C2 AF              2646 	clr	_EA
                           2647 ;	genPlus
   246F A8 10              2648 	mov	r0,_bp
   2471 08                 2649 	inc	r0
                           2650 ;     genPlusIncr
   2472 74 27              2651 	mov	a,#0x27
   2474 26                 2652 	add	a,@r0
   2475 FD                 2653 	mov	r5,a
                           2654 ;	Peephole 181	changed mov to clr
   2476 E4                 2655 	clr	a
   2477 08                 2656 	inc	r0
   2478 36                 2657 	addc	a,@r0
   2479 FE                 2658 	mov	r6,a
   247A 08                 2659 	inc	r0
   247B 86 07              2660 	mov	ar7,@r0
                           2661 ;	genPointerGet
                           2662 ;	genGenPointerGet
   247D 8D 82              2663 	mov	dpl,r5
   247F 8E 83              2664 	mov	dph,r6
   2481 8F F0              2665 	mov	b,r7
   2483 12 E4 9F           2666 	lcall	__gptrget
                           2667 ;	genPlus
                           2668 ;     genPlusIncr
                           2669 ;	Peephole 185	changed order of increment (acc incremented also!)
   2486 04                 2670 	inc	a
                           2671 ;	genPointerSet
                           2672 ;	genGenPointerSet
   2487 FA                 2673 	mov	r2,a
   2488 8D 82              2674 	mov	dpl,r5
   248A 8E 83              2675 	mov	dph,r6
   248C 8F F0              2676 	mov	b,r7
                           2677 ;	Peephole 191	removed redundant mov
   248E 12 DF B7           2678 	lcall	__gptrput
                           2679 ;	genPlus
   2491 A8 10              2680 	mov	r0,_bp
   2493 08                 2681 	inc	r0
                           2682 ;     genPlusIncr
   2494 74 28              2683 	mov	a,#0x28
   2496 26                 2684 	add	a,@r0
   2497 FA                 2685 	mov	r2,a
                           2686 ;	Peephole 181	changed mov to clr
   2498 E4                 2687 	clr	a
   2499 08                 2688 	inc	r0
   249A 36                 2689 	addc	a,@r0
   249B FB                 2690 	mov	r3,a
   249C 08                 2691 	inc	r0
   249D 86 04              2692 	mov	ar4,@r0
                           2693 ;	genPointerGet
                           2694 ;	genGenPointerGet
   249F 8A 82              2695 	mov	dpl,r2
   24A1 8B 83              2696 	mov	dph,r3
   24A3 8C F0              2697 	mov	b,r4
   24A5 12 E4 9F           2698 	lcall	__gptrget
                           2699 ;	genPlus
                           2700 ;     genPlusIncr
                           2701 ;	Peephole 185	changed order of increment (acc incremented also!)
   24A8 04                 2702 	inc	a
                           2703 ;	genPointerSet
                           2704 ;	genGenPointerSet
   24A9 FD                 2705 	mov	r5,a
   24AA 8A 82              2706 	mov	dpl,r2
   24AC 8B 83              2707 	mov	dph,r3
   24AE 8C F0              2708 	mov	b,r4
                           2709 ;	Peephole 191	removed redundant mov
   24B0 12 DF B7           2710 	lcall	__gptrput
                           2711 ;	genInline
   24B3 D0 E0              2712 	 pop ACC 
                           2713 ;	genAnd
   24B5 53 E0 80           2714 	anl	_ACC,#0x80
                           2715 ;	genOr
   24B8 E5 E0              2716 	mov	a,_ACC
   24BA 42 A8              2717 	orl	_IE,a
                           2718 ;	genInline
   24BC D0 E0              2719 	 pop ACC 
                           2720 ;	../../FreeRTOS/Source/queue.c:474: taskEXIT_CRITICAL();
                           2721 ;	genInline
   24BE D0 E0              2722 	 pop ACC 
                           2723 ;	genAnd
   24C0 53 E0 80           2724 	anl	_ACC,#0x80
                           2725 ;	genOr
   24C3 E5 E0              2726 	mov	a,_ACC
   24C5 42 A8              2727 	orl	_IE,a
                           2728 ;	genInline
   24C7 D0 E0              2729 	 pop ACC 
                           2730 ;	../../FreeRTOS/Source/queue.c:518: return xReturn;
                           2731 ;	genIpop
                           2732 ;	../../FreeRTOS/Source/queue.c:474: taskEXIT_CRITICAL();
   24C9                    2733 00106$:
                           2734 ;	../../FreeRTOS/Source/queue.c:478: taskENTER_CRITICAL();
                           2735 ;	genInline
   24C9 C0 E0 C0 A8        2736 	 push ACC push IE 
                           2737 ;	genAssign
   24CD C2 AF              2738 	clr	_EA
                           2739 ;	../../FreeRTOS/Source/queue.c:480: if( pxQueue->uxMessagesWaiting > ( unsigned portBASE_TYPE ) 0 )
                           2740 ;	genPlus
   24CF A8 10              2741 	mov	r0,_bp
   24D1 08                 2742 	inc	r0
                           2743 ;     genPlusIncr
   24D2 74 24              2744 	mov	a,#0x24
   24D4 26                 2745 	add	a,@r0
   24D5 FA                 2746 	mov	r2,a
                           2747 ;	Peephole 181	changed mov to clr
   24D6 E4                 2748 	clr	a
   24D7 08                 2749 	inc	r0
   24D8 36                 2750 	addc	a,@r0
   24D9 FB                 2751 	mov	r3,a
   24DA 08                 2752 	inc	r0
   24DB 86 04              2753 	mov	ar4,@r0
                           2754 ;	genPointerGet
                           2755 ;	genGenPointerGet
   24DD 8A 82              2756 	mov	dpl,r2
   24DF 8B 83              2757 	mov	dph,r3
   24E1 8C F0              2758 	mov	b,r4
   24E3 12 E4 9F           2759 	lcall	__gptrget
                           2760 ;	genIfxJump
   24E6 70 03              2761 	jnz	00136$
   24E8 02 26 41           2762 	ljmp	00110$
   24EB                    2763 00136$:
                           2764 ;	../../FreeRTOS/Source/queue.c:482: pxQueue->pcReadFrom += pxQueue->uxItemSize;
                           2765 ;	genIpush
   24EB C0 02              2766 	push	ar2
   24ED C0 03              2767 	push	ar3
   24EF C0 04              2768 	push	ar4
                           2769 ;	genPlus
   24F1 A8 10              2770 	mov	r0,_bp
   24F3 08                 2771 	inc	r0
   24F4 E5 10              2772 	mov	a,_bp
   24F6 24 0A              2773 	add	a,#0x0a
   24F8 F9                 2774 	mov	r1,a
                           2775 ;     genPlusIncr
   24F9 74 09              2776 	mov	a,#0x09
   24FB 26                 2777 	add	a,@r0
   24FC F7                 2778 	mov	@r1,a
                           2779 ;	Peephole 181	changed mov to clr
   24FD E4                 2780 	clr	a
   24FE 08                 2781 	inc	r0
   24FF 36                 2782 	addc	a,@r0
   2500 09                 2783 	inc	r1
   2501 F7                 2784 	mov	@r1,a
   2502 08                 2785 	inc	r0
   2503 09                 2786 	inc	r1
   2504 E6                 2787 	mov	a,@r0
   2505 F7                 2788 	mov	@r1,a
                           2789 ;	genPointerGet
                           2790 ;	genGenPointerGet
   2506 E5 10              2791 	mov	a,_bp
   2508 24 0A              2792 	add	a,#0x0a
   250A F8                 2793 	mov	r0,a
   250B 86 82              2794 	mov	dpl,@r0
   250D 08                 2795 	inc	r0
   250E 86 83              2796 	mov	dph,@r0
   2510 08                 2797 	inc	r0
   2511 86 F0              2798 	mov	b,@r0
   2513 12 E4 9F           2799 	lcall	__gptrget
   2516 FA                 2800 	mov	r2,a
   2517 A3                 2801 	inc	dptr
   2518 12 E4 9F           2802 	lcall	__gptrget
   251B FB                 2803 	mov	r3,a
   251C A3                 2804 	inc	dptr
   251D 12 E4 9F           2805 	lcall	__gptrget
   2520 FC                 2806 	mov	r4,a
                           2807 ;	genPointerGet
                           2808 ;	genGenPointerGet
   2521 E5 10              2809 	mov	a,_bp
   2523 24 07              2810 	add	a,#0x07
   2525 F8                 2811 	mov	r0,a
   2526 86 82              2812 	mov	dpl,@r0
   2528 08                 2813 	inc	r0
   2529 86 83              2814 	mov	dph,@r0
   252B 08                 2815 	inc	r0
   252C 86 F0              2816 	mov	b,@r0
   252E 12 E4 9F           2817 	lcall	__gptrget
                           2818 ;	genPlus
   2531 FD                 2819 	mov	r5,a
                           2820 ;	Peephole 177.b	removed redundant mov
                           2821 ;	Peephole 236.a	used r2 instead of ar2
   2532 2A                 2822 	add	a,r2
   2533 FA                 2823 	mov	r2,a
                           2824 ;	Peephole 181	changed mov to clr
   2534 E4                 2825 	clr	a
                           2826 ;	Peephole 236.b	used r3 instead of ar3
   2535 3B                 2827 	addc	a,r3
   2536 FB                 2828 	mov	r3,a
                           2829 ;	genPointerSet
                           2830 ;	genGenPointerSet
   2537 E5 10              2831 	mov	a,_bp
   2539 24 0A              2832 	add	a,#0x0a
   253B F8                 2833 	mov	r0,a
   253C 86 82              2834 	mov	dpl,@r0
   253E 08                 2835 	inc	r0
   253F 86 83              2836 	mov	dph,@r0
   2541 08                 2837 	inc	r0
   2542 86 F0              2838 	mov	b,@r0
   2544 EA                 2839 	mov	a,r2
   2545 12 DF B7           2840 	lcall	__gptrput
   2548 A3                 2841 	inc	dptr
   2549 EB                 2842 	mov	a,r3
   254A 12 DF B7           2843 	lcall	__gptrput
   254D A3                 2844 	inc	dptr
   254E EC                 2845 	mov	a,r4
   254F 12 DF B7           2846 	lcall	__gptrput
                           2847 ;	../../FreeRTOS/Source/queue.c:483: if( pxQueue->pcReadFrom >= pxQueue->pcTail )
                           2848 ;	genPointerGet
                           2849 ;	genGenPointerGet
   2552 E5 10              2850 	mov	a,_bp
   2554 24 0D              2851 	add	a,#0x0d
   2556 F8                 2852 	mov	r0,a
   2557 86 82              2853 	mov	dpl,@r0
   2559 08                 2854 	inc	r0
   255A 86 83              2855 	mov	dph,@r0
   255C 08                 2856 	inc	r0
   255D 86 F0              2857 	mov	b,@r0
   255F 12 E4 9F           2858 	lcall	__gptrget
   2562 FD                 2859 	mov	r5,a
   2563 A3                 2860 	inc	dptr
   2564 12 E4 9F           2861 	lcall	__gptrget
   2567 FE                 2862 	mov	r6,a
   2568 A3                 2863 	inc	dptr
   2569 12 E4 9F           2864 	lcall	__gptrget
   256C FF                 2865 	mov	r7,a
                           2866 ;	genCmpLt
                           2867 ;	genCmp
   256D C3                 2868 	clr	c
   256E EA                 2869 	mov	a,r2
   256F 9D                 2870 	subb	a,r5
   2570 EB                 2871 	mov	a,r3
   2571 9E                 2872 	subb	a,r6
   2572 EC                 2873 	mov	a,r4
   2573 64 80              2874 	xrl	a,#0x80
   2575 8F F0              2875 	mov	b,r7
   2577 63 F0 80           2876 	xrl	b,#0x80
   257A 95 F0              2877 	subb	a,b
                           2878 ;	genIpop
                           2879 ;	genIfx
                           2880 ;	genIfxJump
                           2881 ;	Peephole 108.b	removed ljmp by inverse jump logic
                           2882 ;	Peephole 129.d	optimized condition
   257C D0 04              2883 	pop	ar4
   257E D0 03              2884 	pop	ar3
   2580 D0 02              2885 	pop	ar2
   2582 40 34              2886 	jc	00108$
                           2887 ;	Peephole 300	removed redundant label 00137$
                           2888 ;	../../FreeRTOS/Source/queue.c:485: pxQueue->pcReadFrom = pxQueue->pcHead;
                           2889 ;	genPointerGet
                           2890 ;	genGenPointerGet
   2584 A8 10              2891 	mov	r0,_bp
   2586 08                 2892 	inc	r0
   2587 86 82              2893 	mov	dpl,@r0
   2589 08                 2894 	inc	r0
   258A 86 83              2895 	mov	dph,@r0
   258C 08                 2896 	inc	r0
   258D 86 F0              2897 	mov	b,@r0
   258F 12 E4 9F           2898 	lcall	__gptrget
   2592 FD                 2899 	mov	r5,a
   2593 A3                 2900 	inc	dptr
   2594 12 E4 9F           2901 	lcall	__gptrget
   2597 FE                 2902 	mov	r6,a
   2598 A3                 2903 	inc	dptr
   2599 12 E4 9F           2904 	lcall	__gptrget
   259C FF                 2905 	mov	r7,a
                           2906 ;	genPointerSet
                           2907 ;	genGenPointerSet
   259D E5 10              2908 	mov	a,_bp
   259F 24 0A              2909 	add	a,#0x0a
   25A1 F8                 2910 	mov	r0,a
   25A2 86 82              2911 	mov	dpl,@r0
   25A4 08                 2912 	inc	r0
   25A5 86 83              2913 	mov	dph,@r0
   25A7 08                 2914 	inc	r0
   25A8 86 F0              2915 	mov	b,@r0
   25AA ED                 2916 	mov	a,r5
   25AB 12 DF B7           2917 	lcall	__gptrput
   25AE A3                 2918 	inc	dptr
   25AF EE                 2919 	mov	a,r6
   25B0 12 DF B7           2920 	lcall	__gptrput
   25B3 A3                 2921 	inc	dptr
   25B4 EF                 2922 	mov	a,r7
   25B5 12 DF B7           2923 	lcall	__gptrput
   25B8                    2924 00108$:
                           2925 ;	../../FreeRTOS/Source/queue.c:487: --( pxQueue->uxMessagesWaiting );
                           2926 ;	genPointerGet
                           2927 ;	genGenPointerGet
   25B8 8A 82              2928 	mov	dpl,r2
   25BA 8B 83              2929 	mov	dph,r3
   25BC 8C F0              2930 	mov	b,r4
   25BE 12 E4 9F           2931 	lcall	__gptrget
   25C1 FD                 2932 	mov	r5,a
                           2933 ;	genMinus
                           2934 ;	genMinusDec
   25C2 1D                 2935 	dec	r5
                           2936 ;	genPointerSet
                           2937 ;	genGenPointerSet
   25C3 8A 82              2938 	mov	dpl,r2
   25C5 8B 83              2939 	mov	dph,r3
   25C7 8C F0              2940 	mov	b,r4
   25C9 ED                 2941 	mov	a,r5
   25CA 12 DF B7           2942 	lcall	__gptrput
                           2943 ;	../../FreeRTOS/Source/queue.c:488: memcpy( ( void * ) pvBuffer, ( void * ) pxQueue->pcReadFrom, ( unsigned ) pxQueue->uxItemSize );
                           2944 ;	genPointerGet
                           2945 ;	genGenPointerGet
   25CD E5 10              2946 	mov	a,_bp
   25CF 24 07              2947 	add	a,#0x07
   25D1 F8                 2948 	mov	r0,a
   25D2 86 82              2949 	mov	dpl,@r0
   25D4 08                 2950 	inc	r0
   25D5 86 83              2951 	mov	dph,@r0
   25D7 08                 2952 	inc	r0
   25D8 86 F0              2953 	mov	b,@r0
   25DA 12 E4 9F           2954 	lcall	__gptrget
   25DD FA                 2955 	mov	r2,a
                           2956 ;	genCast
   25DE 7B 00              2957 	mov	r3,#0x00
                           2958 ;	genPointerGet
                           2959 ;	genGenPointerGet
   25E0 E5 10              2960 	mov	a,_bp
   25E2 24 0A              2961 	add	a,#0x0a
   25E4 F8                 2962 	mov	r0,a
   25E5 86 82              2963 	mov	dpl,@r0
   25E7 08                 2964 	inc	r0
   25E8 86 83              2965 	mov	dph,@r0
   25EA 08                 2966 	inc	r0
   25EB 86 F0              2967 	mov	b,@r0
   25ED 12 E4 9F           2968 	lcall	__gptrget
   25F0 FC                 2969 	mov	r4,a
   25F1 A3                 2970 	inc	dptr
   25F2 12 E4 9F           2971 	lcall	__gptrget
   25F5 FD                 2972 	mov	r5,a
   25F6 A3                 2973 	inc	dptr
   25F7 12 E4 9F           2974 	lcall	__gptrget
   25FA FE                 2975 	mov	r6,a
                           2976 ;	genIpush
   25FB C0 02              2977 	push	ar2
   25FD C0 03              2978 	push	ar3
                           2979 ;	genIpush
   25FF C0 04              2980 	push	ar4
   2601 C0 05              2981 	push	ar5
   2603 C0 06              2982 	push	ar6
                           2983 ;	genCall
   2605 E5 10              2984 	mov	a,_bp
   2607 24 FB              2985 	add	a,#0xfffffffb
   2609 F8                 2986 	mov	r0,a
   260A 86 82              2987 	mov	dpl,@r0
   260C 08                 2988 	inc	r0
   260D 86 83              2989 	mov	dph,@r0
   260F 08                 2990 	inc	r0
   2610 86 F0              2991 	mov	b,@r0
   2612 12 E2 C7           2992 	lcall	_memcpy
   2615 E5 81              2993 	mov	a,sp
   2617 24 FB              2994 	add	a,#0xfb
   2619 F5 81              2995 	mov	sp,a
                           2996 ;	../../FreeRTOS/Source/queue.c:492: ++( pxQueue->xRxLock );
                           2997 ;	genPlus
   261B A8 10              2998 	mov	r0,_bp
   261D 08                 2999 	inc	r0
                           3000 ;     genPlusIncr
   261E 74 27              3001 	mov	a,#0x27
   2620 26                 3002 	add	a,@r0
   2621 FA                 3003 	mov	r2,a
                           3004 ;	Peephole 181	changed mov to clr
   2622 E4                 3005 	clr	a
   2623 08                 3006 	inc	r0
   2624 36                 3007 	addc	a,@r0
   2625 FB                 3008 	mov	r3,a
   2626 08                 3009 	inc	r0
   2627 86 04              3010 	mov	ar4,@r0
                           3011 ;	genPointerGet
                           3012 ;	genGenPointerGet
   2629 8A 82              3013 	mov	dpl,r2
   262B 8B 83              3014 	mov	dph,r3
   262D 8C F0              3015 	mov	b,r4
   262F 12 E4 9F           3016 	lcall	__gptrget
                           3017 ;	genPlus
                           3018 ;     genPlusIncr
                           3019 ;	Peephole 185	changed order of increment (acc incremented also!)
   2632 04                 3020 	inc	a
                           3021 ;	genPointerSet
                           3022 ;	genGenPointerSet
   2633 FD                 3023 	mov	r5,a
   2634 8A 82              3024 	mov	dpl,r2
   2636 8B 83              3025 	mov	dph,r3
   2638 8C F0              3026 	mov	b,r4
                           3027 ;	Peephole 191	removed redundant mov
   263A 12 DF B7           3028 	lcall	__gptrput
                           3029 ;	../../FreeRTOS/Source/queue.c:493: xReturn = pdPASS;
                           3030 ;	genAssign
   263D 7A 01              3031 	mov	r2,#0x01
                           3032 ;	Peephole 112.b	changed ljmp to sjmp
   263F 80 02              3033 	sjmp	00111$
   2641                    3034 00110$:
                           3035 ;	../../FreeRTOS/Source/queue.c:497: xReturn = errQUEUE_EMPTY;
                           3036 ;	genAssign
   2641 7A 00              3037 	mov	r2,#0x00
   2643                    3038 00111$:
                           3039 ;	../../FreeRTOS/Source/queue.c:500: taskEXIT_CRITICAL();
                           3040 ;	genInline
   2643 D0 E0              3041 	 pop ACC 
                           3042 ;	genAnd
   2645 53 E0 80           3043 	anl	_ACC,#0x80
                           3044 ;	genOr
   2648 E5 E0              3045 	mov	a,_ACC
   264A 42 A8              3046 	orl	_IE,a
                           3047 ;	genInline
   264C D0 E0              3048 	 pop ACC 
                           3049 ;	../../FreeRTOS/Source/queue.c:502: if( xReturn == errQUEUE_EMPTY )
                           3050 ;	genIfx
   264E EA                 3051 	mov	a,r2
                           3052 ;	genIfxJump
                           3053 ;	Peephole 108.b	removed ljmp by inverse jump logic
   264F 70 3C              3054 	jnz	00119$
                           3055 ;	Peephole 300	removed redundant label 00138$
                           3056 ;	../../FreeRTOS/Source/queue.c:504: if( xTicksToWait > 0 )
                           3057 ;	genIfx
   2651 E5 10              3058 	mov	a,_bp
   2653 24 F9              3059 	add	a,#0xfffffff9
   2655 F8                 3060 	mov	r0,a
   2656 E6                 3061 	mov	a,@r0
   2657 08                 3062 	inc	r0
   2658 46                 3063 	orl	a,@r0
                           3064 ;	genIfxJump
                           3065 ;	Peephole 108.c	removed ljmp by inverse jump logic
   2659 60 32              3066 	jz	00119$
                           3067 ;	Peephole 300	removed redundant label 00139$
                           3068 ;	../../FreeRTOS/Source/queue.c:506: if( xTaskCheckForTimeOut( &xTimeOut, &xTicksToWait ) == pdFALSE )
                           3069 ;	genIpush
   265B C0 02              3070 	push	ar2
                           3071 ;	genAddrOf
   265D E5 10              3072 	mov	a,_bp
   265F 24 F9              3073 	add	a,#0xf9
   2661 FB                 3074 	mov	r3,a
                           3075 ;	genCast
   2662 7C 00              3076 	mov	r4,#0x00
   2664 7D 40              3077 	mov	r5,#0x40
                           3078 ;	genAddrOf
   2666 E5 10              3079 	mov	a,_bp
   2668 24 04              3080 	add	a,#0x04
   266A FE                 3081 	mov	r6,a
                           3082 ;	genCast
   266B 7F 00              3083 	mov	r7,#0x00
   266D 7A 40              3084 	mov	r2,#0x40
                           3085 ;	genIpush
   266F C0 03              3086 	push	ar3
   2671 C0 04              3087 	push	ar4
   2673 C0 05              3088 	push	ar5
                           3089 ;	genCall
   2675 8E 82              3090 	mov	dpl,r6
   2677 8F 83              3091 	mov	dph,r7
   2679 8A F0              3092 	mov	b,r2
   267B 12 16 72           3093 	lcall	_xTaskCheckForTimeOut
   267E AA 82              3094 	mov	r2,dpl
   2680 15 81              3095 	dec	sp
   2682 15 81              3096 	dec	sp
   2684 15 81              3097 	dec	sp
                           3098 ;	genIfx
   2686 EA                 3099 	mov	a,r2
                           3100 ;	genIpop
   2687 D0 02              3101 	pop	ar2
                           3102 ;	genIfxJump
                           3103 ;	Peephole 108.b	removed ljmp by inverse jump logic
   2689 70 02              3104 	jnz	00119$
                           3105 ;	Peephole 300	removed redundant label 00140$
                           3106 ;	../../FreeRTOS/Source/queue.c:508: xReturn = queueERRONEOUS_UNBLOCK;
                           3107 ;	genAssign
   268B 7A FF              3108 	mov	r2,#0xFF
   268D                    3109 00119$:
                           3110 ;	../../FreeRTOS/Source/queue.c:512: } while( xReturn == queueERRONEOUS_UNBLOCK );
                           3111 ;	genCmpEq
                           3112 ;	gencjneshort
   268D BA FF 03           3113 	cjne	r2,#0xFF,00141$
   2690 02 23 FF           3114 	ljmp	00118$
   2693                    3115 00141$:
                           3116 ;	../../FreeRTOS/Source/queue.c:515: prvUnlockQueue( pxQueue );
                           3117 ;	genCall
   2693 A8 10              3118 	mov	r0,_bp
   2695 08                 3119 	inc	r0
   2696 86 82              3120 	mov	dpl,@r0
   2698 08                 3121 	inc	r0
   2699 86 83              3122 	mov	dph,@r0
   269B 08                 3123 	inc	r0
   269C 86 F0              3124 	mov	b,@r0
   269E C0 02              3125 	push	ar2
   26A0 12 29 21           3126 	lcall	_prvUnlockQueue
   26A3 D0 02              3127 	pop	ar2
                           3128 ;	../../FreeRTOS/Source/queue.c:516: xTaskResumeAll();
                           3129 ;	genCall
   26A5 C0 02              3130 	push	ar2
   26A7 12 0E 45           3131 	lcall	_xTaskResumeAll
   26AA D0 02              3132 	pop	ar2
                           3133 ;	../../FreeRTOS/Source/queue.c:518: return xReturn;
                           3134 ;	genRet
   26AC 8A 82              3135 	mov	dpl,r2
                           3136 ;	Peephole 300	removed redundant label 00121$
   26AE 85 10 81           3137 	mov	sp,_bp
   26B1 D0 10              3138 	pop	_bp
   26B3 22                 3139 	ret
                           3140 ;------------------------------------------------------------
                           3141 ;Allocation info for local variables in function 'xQueueReceiveFromISR'
                           3142 ;------------------------------------------------------------
                           3143 ;pvBuffer                  Allocated to stack - offset -5
                           3144 ;pxTaskWoken               Allocated to stack - offset -8
                           3145 ;pxQueue                   Allocated to stack - offset 1
                           3146 ;xReturn                   Allocated to registers r2 
                           3147 ;sloc0                     Allocated to stack - offset 4
                           3148 ;sloc1                     Allocated to stack - offset 5
                           3149 ;sloc2                     Allocated to stack - offset 8
                           3150 ;sloc3                     Allocated to stack - offset 10
                           3151 ;------------------------------------------------------------
                           3152 ;	../../FreeRTOS/Source/queue.c:522: signed portBASE_TYPE xQueueReceiveFromISR( xQueueHandle pxQueue, void *pvBuffer, signed portBASE_TYPE *pxTaskWoken )
                           3153 ;	-----------------------------------------
                           3154 ;	 function xQueueReceiveFromISR
                           3155 ;	-----------------------------------------
   26B4                    3156 _xQueueReceiveFromISR:
   26B4 C0 10              3157 	push	_bp
   26B6 85 81 10           3158 	mov	_bp,sp
                           3159 ;     genReceive
   26B9 C0 82              3160 	push	dpl
   26BB C0 83              3161 	push	dph
   26BD C0 F0              3162 	push	b
   26BF E5 81              3163 	mov	a,sp
   26C1 24 08              3164 	add	a,#0x08
   26C3 F5 81              3165 	mov	sp,a
                           3166 ;	../../FreeRTOS/Source/queue.c:527: if( pxQueue->uxMessagesWaiting > ( unsigned portBASE_TYPE ) 0 )
                           3167 ;	genPlus
   26C5 A8 10              3168 	mov	r0,_bp
   26C7 08                 3169 	inc	r0
                           3170 ;     genPlusIncr
   26C8 74 24              3171 	mov	a,#0x24
   26CA 26                 3172 	add	a,@r0
   26CB FD                 3173 	mov	r5,a
                           3174 ;	Peephole 181	changed mov to clr
   26CC E4                 3175 	clr	a
   26CD 08                 3176 	inc	r0
   26CE 36                 3177 	addc	a,@r0
   26CF FE                 3178 	mov	r6,a
   26D0 08                 3179 	inc	r0
   26D1 86 07              3180 	mov	ar7,@r0
                           3181 ;	genPointerGet
                           3182 ;	genGenPointerGet
   26D3 8D 82              3183 	mov	dpl,r5
   26D5 8E 83              3184 	mov	dph,r6
   26D7 8F F0              3185 	mov	b,r7
   26D9 E5 10              3186 	mov	a,_bp
   26DB 24 04              3187 	add	a,#0x04
   26DD F8                 3188 	mov	r0,a
   26DE 12 E4 9F           3189 	lcall	__gptrget
   26E1 F6                 3190 	mov	@r0,a
                           3191 ;	genIfx
   26E2 E5 10              3192 	mov	a,_bp
   26E4 24 04              3193 	add	a,#0x04
   26E6 F8                 3194 	mov	r0,a
   26E7 E6                 3195 	mov	a,@r0
                           3196 ;	genIfxJump
   26E8 70 03              3197 	jnz	00123$
   26EA 02 28 BA           3198 	ljmp	00113$
   26ED                    3199 00123$:
                           3200 ;	../../FreeRTOS/Source/queue.c:530: pxQueue->pcReadFrom += pxQueue->uxItemSize;
                           3201 ;	genIpush
   26ED C0 05              3202 	push	ar5
   26EF C0 06              3203 	push	ar6
   26F1 C0 07              3204 	push	ar7
                           3205 ;	genPlus
   26F3 A8 10              3206 	mov	r0,_bp
   26F5 08                 3207 	inc	r0
   26F6 E5 10              3208 	mov	a,_bp
   26F8 24 05              3209 	add	a,#0x05
   26FA F9                 3210 	mov	r1,a
                           3211 ;     genPlusIncr
   26FB 74 09              3212 	mov	a,#0x09
   26FD 26                 3213 	add	a,@r0
   26FE F7                 3214 	mov	@r1,a
                           3215 ;	Peephole 181	changed mov to clr
   26FF E4                 3216 	clr	a
   2700 08                 3217 	inc	r0
   2701 36                 3218 	addc	a,@r0
   2702 09                 3219 	inc	r1
   2703 F7                 3220 	mov	@r1,a
   2704 08                 3221 	inc	r0
   2705 09                 3222 	inc	r1
   2706 E6                 3223 	mov	a,@r0
   2707 F7                 3224 	mov	@r1,a
                           3225 ;	genPointerGet
                           3226 ;	genGenPointerGet
   2708 E5 10              3227 	mov	a,_bp
   270A 24 05              3228 	add	a,#0x05
   270C F8                 3229 	mov	r0,a
   270D 86 82              3230 	mov	dpl,@r0
   270F 08                 3231 	inc	r0
   2710 86 83              3232 	mov	dph,@r0
   2712 08                 3233 	inc	r0
   2713 86 F0              3234 	mov	b,@r0
   2715 12 E4 9F           3235 	lcall	__gptrget
   2718 FD                 3236 	mov	r5,a
   2719 A3                 3237 	inc	dptr
   271A 12 E4 9F           3238 	lcall	__gptrget
   271D FE                 3239 	mov	r6,a
   271E A3                 3240 	inc	dptr
   271F 12 E4 9F           3241 	lcall	__gptrget
   2722 FF                 3242 	mov	r7,a
                           3243 ;	genPlus
   2723 A8 10              3244 	mov	r0,_bp
   2725 08                 3245 	inc	r0
                           3246 ;     genPlusIncr
   2726 74 26              3247 	mov	a,#0x26
   2728 26                 3248 	add	a,@r0
   2729 FA                 3249 	mov	r2,a
                           3250 ;	Peephole 181	changed mov to clr
   272A E4                 3251 	clr	a
   272B 08                 3252 	inc	r0
   272C 36                 3253 	addc	a,@r0
   272D FB                 3254 	mov	r3,a
   272E 08                 3255 	inc	r0
   272F 86 04              3256 	mov	ar4,@r0
                           3257 ;	genPointerGet
                           3258 ;	genGenPointerGet
   2731 8A 82              3259 	mov	dpl,r2
   2733 8B 83              3260 	mov	dph,r3
   2735 8C F0              3261 	mov	b,r4
   2737 E5 10              3262 	mov	a,_bp
   2739 24 08              3263 	add	a,#0x08
   273B F8                 3264 	mov	r0,a
   273C 12 E4 9F           3265 	lcall	__gptrget
   273F F6                 3266 	mov	@r0,a
                           3267 ;	genPlus
   2740 E5 10              3268 	mov	a,_bp
   2742 24 08              3269 	add	a,#0x08
   2744 F8                 3270 	mov	r0,a
   2745 E6                 3271 	mov	a,@r0
                           3272 ;	Peephole 236.a	used r5 instead of ar5
   2746 2D                 3273 	add	a,r5
   2747 FD                 3274 	mov	r5,a
                           3275 ;	Peephole 181	changed mov to clr
   2748 E4                 3276 	clr	a
                           3277 ;	Peephole 236.b	used r6 instead of ar6
   2749 3E                 3278 	addc	a,r6
   274A FE                 3279 	mov	r6,a
                           3280 ;	genPointerSet
                           3281 ;	genGenPointerSet
   274B E5 10              3282 	mov	a,_bp
   274D 24 05              3283 	add	a,#0x05
   274F F8                 3284 	mov	r0,a
   2750 86 82              3285 	mov	dpl,@r0
   2752 08                 3286 	inc	r0
   2753 86 83              3287 	mov	dph,@r0
   2755 08                 3288 	inc	r0
   2756 86 F0              3289 	mov	b,@r0
   2758 ED                 3290 	mov	a,r5
   2759 12 DF B7           3291 	lcall	__gptrput
   275C A3                 3292 	inc	dptr
   275D EE                 3293 	mov	a,r6
   275E 12 DF B7           3294 	lcall	__gptrput
   2761 A3                 3295 	inc	dptr
   2762 EF                 3296 	mov	a,r7
   2763 12 DF B7           3297 	lcall	__gptrput
                           3298 ;	../../FreeRTOS/Source/queue.c:531: if( pxQueue->pcReadFrom >= pxQueue->pcTail )
                           3299 ;	genPlus
   2766 A8 10              3300 	mov	r0,_bp
   2768 08                 3301 	inc	r0
                           3302 ;     genPlusIncr
   2769 74 03              3303 	mov	a,#0x03
   276B 26                 3304 	add	a,@r0
   276C FA                 3305 	mov	r2,a
                           3306 ;	Peephole 181	changed mov to clr
   276D E4                 3307 	clr	a
   276E 08                 3308 	inc	r0
   276F 36                 3309 	addc	a,@r0
   2770 FB                 3310 	mov	r3,a
   2771 08                 3311 	inc	r0
   2772 86 04              3312 	mov	ar4,@r0
                           3313 ;	genPointerGet
                           3314 ;	genGenPointerGet
   2774 8A 82              3315 	mov	dpl,r2
   2776 8B 83              3316 	mov	dph,r3
   2778 8C F0              3317 	mov	b,r4
   277A 12 E4 9F           3318 	lcall	__gptrget
   277D FA                 3319 	mov	r2,a
   277E A3                 3320 	inc	dptr
   277F 12 E4 9F           3321 	lcall	__gptrget
   2782 FB                 3322 	mov	r3,a
   2783 A3                 3323 	inc	dptr
   2784 12 E4 9F           3324 	lcall	__gptrget
   2787 FC                 3325 	mov	r4,a
                           3326 ;	genCmpLt
                           3327 ;	genCmp
   2788 C3                 3328 	clr	c
   2789 ED                 3329 	mov	a,r5
   278A 9A                 3330 	subb	a,r2
   278B EE                 3331 	mov	a,r6
   278C 9B                 3332 	subb	a,r3
   278D EF                 3333 	mov	a,r7
   278E 64 80              3334 	xrl	a,#0x80
   2790 8C F0              3335 	mov	b,r4
   2792 63 F0 80           3336 	xrl	b,#0x80
   2795 95 F0              3337 	subb	a,b
                           3338 ;	genIpop
                           3339 ;	genIfx
                           3340 ;	genIfxJump
                           3341 ;	Peephole 108.b	removed ljmp by inverse jump logic
                           3342 ;	Peephole 129.d	optimized condition
   2797 D0 07              3343 	pop	ar7
   2799 D0 06              3344 	pop	ar6
   279B D0 05              3345 	pop	ar5
   279D 40 34              3346 	jc	00102$
                           3347 ;	Peephole 300	removed redundant label 00124$
                           3348 ;	../../FreeRTOS/Source/queue.c:533: pxQueue->pcReadFrom = pxQueue->pcHead;
                           3349 ;	genPointerGet
                           3350 ;	genGenPointerGet
   279F A8 10              3351 	mov	r0,_bp
   27A1 08                 3352 	inc	r0
   27A2 86 82              3353 	mov	dpl,@r0
   27A4 08                 3354 	inc	r0
   27A5 86 83              3355 	mov	dph,@r0
   27A7 08                 3356 	inc	r0
   27A8 86 F0              3357 	mov	b,@r0
   27AA 12 E4 9F           3358 	lcall	__gptrget
   27AD FA                 3359 	mov	r2,a
   27AE A3                 3360 	inc	dptr
   27AF 12 E4 9F           3361 	lcall	__gptrget
   27B2 FB                 3362 	mov	r3,a
   27B3 A3                 3363 	inc	dptr
   27B4 12 E4 9F           3364 	lcall	__gptrget
   27B7 FC                 3365 	mov	r4,a
                           3366 ;	genPointerSet
                           3367 ;	genGenPointerSet
   27B8 E5 10              3368 	mov	a,_bp
   27BA 24 05              3369 	add	a,#0x05
   27BC F8                 3370 	mov	r0,a
   27BD 86 82              3371 	mov	dpl,@r0
   27BF 08                 3372 	inc	r0
   27C0 86 83              3373 	mov	dph,@r0
   27C2 08                 3374 	inc	r0
   27C3 86 F0              3375 	mov	b,@r0
   27C5 EA                 3376 	mov	a,r2
   27C6 12 DF B7           3377 	lcall	__gptrput
   27C9 A3                 3378 	inc	dptr
   27CA EB                 3379 	mov	a,r3
   27CB 12 DF B7           3380 	lcall	__gptrput
   27CE A3                 3381 	inc	dptr
   27CF EC                 3382 	mov	a,r4
   27D0 12 DF B7           3383 	lcall	__gptrput
   27D3                    3384 00102$:
                           3385 ;	../../FreeRTOS/Source/queue.c:535: --( pxQueue->uxMessagesWaiting );
                           3386 ;	genMinus
   27D3 E5 10              3387 	mov	a,_bp
   27D5 24 04              3388 	add	a,#0x04
   27D7 F8                 3389 	mov	r0,a
                           3390 ;	genMinusDec
   27D8 E6                 3391 	mov	a,@r0
   27D9 14                 3392 	dec	a
                           3393 ;	genPointerSet
                           3394 ;	genGenPointerSet
   27DA FA                 3395 	mov	r2,a
   27DB 8D 82              3396 	mov	dpl,r5
   27DD 8E 83              3397 	mov	dph,r6
   27DF 8F F0              3398 	mov	b,r7
                           3399 ;	Peephole 191	removed redundant mov
   27E1 12 DF B7           3400 	lcall	__gptrput
                           3401 ;	../../FreeRTOS/Source/queue.c:536: memcpy( ( void * ) pvBuffer, ( void * ) pxQueue->pcReadFrom, ( unsigned ) pxQueue->uxItemSize );
                           3402 ;	genCast
   27E4 E5 10              3403 	mov	a,_bp
   27E6 24 08              3404 	add	a,#0x08
   27E8 F8                 3405 	mov	r0,a
   27E9 86 02              3406 	mov	ar2,@r0
   27EB 7B 00              3407 	mov	r3,#0x00
                           3408 ;	genPointerGet
                           3409 ;	genGenPointerGet
   27ED E5 10              3410 	mov	a,_bp
   27EF 24 05              3411 	add	a,#0x05
   27F1 F8                 3412 	mov	r0,a
   27F2 86 82              3413 	mov	dpl,@r0
   27F4 08                 3414 	inc	r0
   27F5 86 83              3415 	mov	dph,@r0
   27F7 08                 3416 	inc	r0
   27F8 86 F0              3417 	mov	b,@r0
   27FA 12 E4 9F           3418 	lcall	__gptrget
   27FD FC                 3419 	mov	r4,a
   27FE A3                 3420 	inc	dptr
   27FF 12 E4 9F           3421 	lcall	__gptrget
   2802 FD                 3422 	mov	r5,a
   2803 A3                 3423 	inc	dptr
   2804 12 E4 9F           3424 	lcall	__gptrget
   2807 FE                 3425 	mov	r6,a
                           3426 ;	genIpush
   2808 C0 02              3427 	push	ar2
   280A C0 03              3428 	push	ar3
                           3429 ;	genIpush
   280C C0 04              3430 	push	ar4
   280E C0 05              3431 	push	ar5
   2810 C0 06              3432 	push	ar6
                           3433 ;	genCall
   2812 E5 10              3434 	mov	a,_bp
   2814 24 FB              3435 	add	a,#0xfffffffb
   2816 F8                 3436 	mov	r0,a
   2817 86 82              3437 	mov	dpl,@r0
   2819 08                 3438 	inc	r0
   281A 86 83              3439 	mov	dph,@r0
   281C 08                 3440 	inc	r0
   281D 86 F0              3441 	mov	b,@r0
   281F 12 E2 C7           3442 	lcall	_memcpy
   2822 E5 81              3443 	mov	a,sp
   2824 24 FB              3444 	add	a,#0xfb
   2826 F5 81              3445 	mov	sp,a
                           3446 ;	../../FreeRTOS/Source/queue.c:541: if( pxQueue->xRxLock == queueUNLOCKED )
                           3447 ;	genPlus
   2828 A8 10              3448 	mov	r0,_bp
   282A 08                 3449 	inc	r0
                           3450 ;     genPlusIncr
   282B 74 27              3451 	mov	a,#0x27
   282D 26                 3452 	add	a,@r0
   282E FA                 3453 	mov	r2,a
                           3454 ;	Peephole 181	changed mov to clr
   282F E4                 3455 	clr	a
   2830 08                 3456 	inc	r0
   2831 36                 3457 	addc	a,@r0
   2832 FB                 3458 	mov	r3,a
   2833 08                 3459 	inc	r0
   2834 86 04              3460 	mov	ar4,@r0
                           3461 ;	genPointerGet
                           3462 ;	genGenPointerGet
   2836 8A 82              3463 	mov	dpl,r2
   2838 8B 83              3464 	mov	dph,r3
   283A 8C F0              3465 	mov	b,r4
   283C 12 E4 9F           3466 	lcall	__gptrget
   283F FD                 3467 	mov	r5,a
                           3468 ;	genCmpEq
                           3469 ;	gencjneshort
                           3470 ;	Peephole 112.b	changed ljmp to sjmp
                           3471 ;	Peephole 198.b	optimized misc jump sequence
   2840 BD FF 68           3472 	cjne	r5,#0xFF,00110$
                           3473 ;	Peephole 200.b	removed redundant sjmp
                           3474 ;	Peephole 300	removed redundant label 00125$
                           3475 ;	Peephole 300	removed redundant label 00126$
                           3476 ;	../../FreeRTOS/Source/queue.c:545: if( !( *pxTaskWoken ) )
                           3477 ;	genAssign
   2843 E5 10              3478 	mov	a,_bp
   2845 24 F8              3479 	add	a,#0xfffffff8
   2847 F8                 3480 	mov	r0,a
   2848 86 02              3481 	mov	ar2,@r0
   284A 08                 3482 	inc	r0
   284B 86 03              3483 	mov	ar3,@r0
   284D 08                 3484 	inc	r0
   284E 86 04              3485 	mov	ar4,@r0
                           3486 ;	genPointerGet
                           3487 ;	genGenPointerGet
   2850 8A 82              3488 	mov	dpl,r2
   2852 8B 83              3489 	mov	dph,r3
   2854 8C F0              3490 	mov	b,r4
   2856 12 E4 9F           3491 	lcall	__gptrget
                           3492 ;	genIfxJump
                           3493 ;	Peephole 108.b	removed ljmp by inverse jump logic
   2859 70 5B              3494 	jnz	00111$
                           3495 ;	Peephole 300	removed redundant label 00127$
                           3496 ;	../../FreeRTOS/Source/queue.c:547: if( !listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToSend ) ) )
                           3497 ;	genPlus
   285B A8 10              3498 	mov	r0,_bp
   285D 08                 3499 	inc	r0
                           3500 ;     genPlusIncr
   285E 74 0C              3501 	mov	a,#0x0C
   2860 26                 3502 	add	a,@r0
   2861 FD                 3503 	mov	r5,a
                           3504 ;	Peephole 181	changed mov to clr
   2862 E4                 3505 	clr	a
   2863 08                 3506 	inc	r0
   2864 36                 3507 	addc	a,@r0
   2865 FE                 3508 	mov	r6,a
   2866 08                 3509 	inc	r0
   2867 86 07              3510 	mov	ar7,@r0
                           3511 ;	genPointerGet
                           3512 ;	genGenPointerGet
   2869 8D 82              3513 	mov	dpl,r5
   286B 8E 83              3514 	mov	dph,r6
   286D 8F F0              3515 	mov	b,r7
   286F 12 E4 9F           3516 	lcall	__gptrget
                           3517 ;	genIfxJump
                           3518 ;	Peephole 108.c	removed ljmp by inverse jump logic
   2872 60 42              3519 	jz	00111$
                           3520 ;	Peephole 300	removed redundant label 00128$
                           3521 ;	../../FreeRTOS/Source/queue.c:549: if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToSend ) ) != pdFALSE )
                           3522 ;	genPlus
   2874 A8 10              3523 	mov	r0,_bp
   2876 08                 3524 	inc	r0
                           3525 ;     genPlusIncr
   2877 74 0C              3526 	mov	a,#0x0C
   2879 26                 3527 	add	a,@r0
   287A FD                 3528 	mov	r5,a
                           3529 ;	Peephole 181	changed mov to clr
   287B E4                 3530 	clr	a
   287C 08                 3531 	inc	r0
   287D 36                 3532 	addc	a,@r0
   287E FE                 3533 	mov	r6,a
   287F 08                 3534 	inc	r0
   2880 86 07              3535 	mov	ar7,@r0
                           3536 ;	genCall
   2882 8D 82              3537 	mov	dpl,r5
   2884 8E 83              3538 	mov	dph,r6
   2886 8F F0              3539 	mov	b,r7
   2888 C0 02              3540 	push	ar2
   288A C0 03              3541 	push	ar3
   288C C0 04              3542 	push	ar4
   288E 12 14 D7           3543 	lcall	_xTaskRemoveFromEventList
   2891 AE 82              3544 	mov	r6,dpl
   2893 D0 04              3545 	pop	ar4
   2895 D0 03              3546 	pop	ar3
   2897 D0 02              3547 	pop	ar2
                           3548 ;	genCmpEq
                           3549 ;	gencjneshort
   2899 BE 00 02           3550 	cjne	r6,#0x00,00129$
                           3551 ;	Peephole 112.b	changed ljmp to sjmp
   289C 80 18              3552 	sjmp	00111$
   289E                    3553 00129$:
                           3554 ;	../../FreeRTOS/Source/queue.c:553: *pxTaskWoken = pdTRUE;
                           3555 ;	genPointerSet
                           3556 ;	genGenPointerSet
   289E 8A 82              3557 	mov	dpl,r2
   28A0 8B 83              3558 	mov	dph,r3
   28A2 8C F0              3559 	mov	b,r4
   28A4 74 01              3560 	mov	a,#0x01
   28A6 12 DF B7           3561 	lcall	__gptrput
                           3562 ;	Peephole 112.b	changed ljmp to sjmp
   28A9 80 0B              3563 	sjmp	00111$
   28AB                    3564 00110$:
                           3565 ;	../../FreeRTOS/Source/queue.c:562: ++( pxQueue->xRxLock );
                           3566 ;	genPlus
                           3567 ;     genPlusIncr
   28AB 0D                 3568 	inc	r5
                           3569 ;	genPointerSet
                           3570 ;	genGenPointerSet
   28AC 8A 82              3571 	mov	dpl,r2
   28AE 8B 83              3572 	mov	dph,r3
   28B0 8C F0              3573 	mov	b,r4
   28B2 ED                 3574 	mov	a,r5
   28B3 12 DF B7           3575 	lcall	__gptrput
   28B6                    3576 00111$:
                           3577 ;	../../FreeRTOS/Source/queue.c:565: xReturn = pdPASS;
                           3578 ;	genAssign
   28B6 7A 01              3579 	mov	r2,#0x01
                           3580 ;	Peephole 112.b	changed ljmp to sjmp
   28B8 80 02              3581 	sjmp	00114$
   28BA                    3582 00113$:
                           3583 ;	../../FreeRTOS/Source/queue.c:569: xReturn = pdFAIL;
                           3584 ;	genAssign
   28BA 7A 00              3585 	mov	r2,#0x00
   28BC                    3586 00114$:
                           3587 ;	../../FreeRTOS/Source/queue.c:572: return xReturn;
                           3588 ;	genRet
   28BC 8A 82              3589 	mov	dpl,r2
                           3590 ;	Peephole 300	removed redundant label 00115$
   28BE 85 10 81           3591 	mov	sp,_bp
   28C1 D0 10              3592 	pop	_bp
   28C3 22                 3593 	ret
                           3594 ;------------------------------------------------------------
                           3595 ;Allocation info for local variables in function 'uxQueueMessagesWaiting'
                           3596 ;------------------------------------------------------------
                           3597 ;pxQueue                   Allocated to registers r2 r3 r4 
                           3598 ;uxReturn                  Allocated to registers r2 
                           3599 ;------------------------------------------------------------
                           3600 ;	../../FreeRTOS/Source/queue.c:576: unsigned portBASE_TYPE uxQueueMessagesWaiting( xQueueHandle pxQueue )
                           3601 ;	-----------------------------------------
                           3602 ;	 function uxQueueMessagesWaiting
                           3603 ;	-----------------------------------------
   28C4                    3604 _uxQueueMessagesWaiting:
                           3605 ;	genReceive
   28C4 AA 82              3606 	mov	r2,dpl
   28C6 AB 83              3607 	mov	r3,dph
   28C8 AC F0              3608 	mov	r4,b
                           3609 ;	../../FreeRTOS/Source/queue.c:580: taskENTER_CRITICAL();
                           3610 ;	genInline
   28CA C0 E0 C0 A8        3611 	 push ACC push IE 
                           3612 ;	genAssign
   28CE C2 AF              3613 	clr	_EA
                           3614 ;	../../FreeRTOS/Source/queue.c:581: uxReturn = pxQueue->uxMessagesWaiting;
                           3615 ;	genPlus
                           3616 ;     genPlusIncr
   28D0 74 24              3617 	mov	a,#0x24
                           3618 ;	Peephole 236.a	used r2 instead of ar2
   28D2 2A                 3619 	add	a,r2
   28D3 FA                 3620 	mov	r2,a
                           3621 ;	Peephole 181	changed mov to clr
   28D4 E4                 3622 	clr	a
                           3623 ;	Peephole 236.b	used r3 instead of ar3
   28D5 3B                 3624 	addc	a,r3
   28D6 FB                 3625 	mov	r3,a
                           3626 ;	genPointerGet
                           3627 ;	genGenPointerGet
   28D7 8A 82              3628 	mov	dpl,r2
   28D9 8B 83              3629 	mov	dph,r3
   28DB 8C F0              3630 	mov	b,r4
   28DD 12 E4 9F           3631 	lcall	__gptrget
   28E0 FA                 3632 	mov	r2,a
                           3633 ;	genAssign
                           3634 ;	../../FreeRTOS/Source/queue.c:582: taskEXIT_CRITICAL();
                           3635 ;	genInline
   28E1 D0 E0              3636 	 pop ACC 
                           3637 ;	genAnd
   28E3 53 E0 80           3638 	anl	_ACC,#0x80
                           3639 ;	genOr
   28E6 E5 E0              3640 	mov	a,_ACC
   28E8 42 A8              3641 	orl	_IE,a
                           3642 ;	genInline
   28EA D0 E0              3643 	 pop ACC 
                           3644 ;	../../FreeRTOS/Source/queue.c:584: return uxReturn;
                           3645 ;	genRet
   28EC 8A 82              3646 	mov	dpl,r2
                           3647 ;	Peephole 300	removed redundant label 00101$
   28EE 22                 3648 	ret
                           3649 ;------------------------------------------------------------
                           3650 ;Allocation info for local variables in function 'vQueueDelete'
                           3651 ;------------------------------------------------------------
                           3652 ;pxQueue                   Allocated to registers r2 r3 r4 
                           3653 ;------------------------------------------------------------
                           3654 ;	../../FreeRTOS/Source/queue.c:588: void vQueueDelete( xQueueHandle pxQueue )
                           3655 ;	-----------------------------------------
                           3656 ;	 function vQueueDelete
                           3657 ;	-----------------------------------------
   28EF                    3658 _vQueueDelete:
                           3659 ;	genReceive
                           3660 ;	../../FreeRTOS/Source/queue.c:590: vPortFree( pxQueue->pcHead );
                           3661 ;	genPointerGet
                           3662 ;	genGenPointerGet
   28EF AA 82              3663 	mov	r2,dpl
   28F1 AB 83              3664 	mov	r3,dph
   28F3 AC F0              3665 	mov	r4,b
                           3666 ;	Peephole 238.d	removed 3 redundant moves
   28F5 12 E4 9F           3667 	lcall	__gptrget
   28F8 FD                 3668 	mov	r5,a
   28F9 A3                 3669 	inc	dptr
   28FA 12 E4 9F           3670 	lcall	__gptrget
   28FD FE                 3671 	mov	r6,a
   28FE A3                 3672 	inc	dptr
   28FF 12 E4 9F           3673 	lcall	__gptrget
   2902 FF                 3674 	mov	r7,a
                           3675 ;	genCall
   2903 8D 82              3676 	mov	dpl,r5
   2905 8E 83              3677 	mov	dph,r6
   2907 8F F0              3678 	mov	b,r7
   2909 C0 02              3679 	push	ar2
   290B C0 03              3680 	push	ar3
   290D C0 04              3681 	push	ar4
   290F 12 37 35           3682 	lcall	_vPortFree
   2912 D0 04              3683 	pop	ar4
   2914 D0 03              3684 	pop	ar3
   2916 D0 02              3685 	pop	ar2
                           3686 ;	../../FreeRTOS/Source/queue.c:591: vPortFree( pxQueue );
                           3687 ;	genCall
   2918 8A 82              3688 	mov	dpl,r2
   291A 8B 83              3689 	mov	dph,r3
   291C 8C F0              3690 	mov	b,r4
                           3691 ;	Peephole 253.b	replaced lcall/ret with ljmp
   291E 02 37 35           3692 	ljmp	_vPortFree
                           3693 ;
                           3694 ;------------------------------------------------------------
                           3695 ;Allocation info for local variables in function 'prvUnlockQueue'
                           3696 ;------------------------------------------------------------
                           3697 ;pxQueue                   Allocated to registers r2 r3 r4 
                           3698 ;------------------------------------------------------------
                           3699 ;	../../FreeRTOS/Source/queue.c:595: static void prvUnlockQueue( xQueueHandle pxQueue )
                           3700 ;	-----------------------------------------
                           3701 ;	 function prvUnlockQueue
                           3702 ;	-----------------------------------------
   2921                    3703 _prvUnlockQueue:
                           3704 ;	genReceive
   2921 AA 82              3705 	mov	r2,dpl
   2923 AB 83              3706 	mov	r3,dph
   2925 AC F0              3707 	mov	r4,b
                           3708 ;	../../FreeRTOS/Source/queue.c:603: taskENTER_CRITICAL();
                           3709 ;	genInline
   2927 C0 E0 C0 A8        3710 	 push ACC push IE 
                           3711 ;	genAssign
   292B C2 AF              3712 	clr	_EA
                           3713 ;	../../FreeRTOS/Source/queue.c:605: --( pxQueue->xTxLock );
                           3714 ;	genPlus
                           3715 ;     genPlusIncr
   292D 74 28              3716 	mov	a,#0x28
                           3717 ;	Peephole 236.a	used r2 instead of ar2
   292F 2A                 3718 	add	a,r2
   2930 FD                 3719 	mov	r5,a
                           3720 ;	Peephole 181	changed mov to clr
   2931 E4                 3721 	clr	a
                           3722 ;	Peephole 236.b	used r3 instead of ar3
   2932 3B                 3723 	addc	a,r3
   2933 FE                 3724 	mov	r6,a
   2934 8C 07              3725 	mov	ar7,r4
                           3726 ;	genPointerGet
                           3727 ;	genGenPointerGet
   2936 8D 82              3728 	mov	dpl,r5
   2938 8E 83              3729 	mov	dph,r6
   293A 8F F0              3730 	mov	b,r7
   293C 12 E4 9F           3731 	lcall	__gptrget
   293F F8                 3732 	mov	r0,a
                           3733 ;	genMinus
                           3734 ;	genMinusDec
   2940 18                 3735 	dec	r0
                           3736 ;	genPointerSet
                           3737 ;	genGenPointerSet
   2941 8D 82              3738 	mov	dpl,r5
   2943 8E 83              3739 	mov	dph,r6
   2945 8F F0              3740 	mov	b,r7
   2947 E8                 3741 	mov	a,r0
   2948 12 DF B7           3742 	lcall	__gptrput
                           3743 ;	../../FreeRTOS/Source/queue.c:608: if( pxQueue->xTxLock > queueUNLOCKED )
                           3744 ;	genCmpGt
                           3745 ;	genCmp
   294B C3                 3746 	clr	c
                           3747 ;	Peephole 159	avoided xrl during execution
   294C 74 7F              3748 	mov	a,#(0xFF ^ 0x80)
   294E 88 F0              3749 	mov	b,r0
   2950 63 F0 80           3750 	xrl	b,#0x80
   2953 95 F0              3751 	subb	a,b
                           3752 ;	genIfxJump
                           3753 ;	Peephole 108.a	removed ljmp by inverse jump logic
   2955 50 53              3754 	jnc	00106$
                           3755 ;	Peephole 300	removed redundant label 00121$
                           3756 ;	../../FreeRTOS/Source/queue.c:610: pxQueue->xTxLock = queueUNLOCKED;
                           3757 ;	genPointerSet
                           3758 ;	genGenPointerSet
   2957 8D 82              3759 	mov	dpl,r5
   2959 8E 83              3760 	mov	dph,r6
   295B 8F F0              3761 	mov	b,r7
   295D 74 FF              3762 	mov	a,#0xFF
   295F 12 DF B7           3763 	lcall	__gptrput
                           3764 ;	../../FreeRTOS/Source/queue.c:614: if( !listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToReceive ) ) )
                           3765 ;	genPlus
                           3766 ;     genPlusIncr
   2962 74 18              3767 	mov	a,#0x18
                           3768 ;	Peephole 236.a	used r2 instead of ar2
   2964 2A                 3769 	add	a,r2
   2965 FD                 3770 	mov	r5,a
                           3771 ;	Peephole 181	changed mov to clr
   2966 E4                 3772 	clr	a
                           3773 ;	Peephole 236.b	used r3 instead of ar3
   2967 3B                 3774 	addc	a,r3
   2968 FE                 3775 	mov	r6,a
   2969 8C 07              3776 	mov	ar7,r4
                           3777 ;	genPointerGet
                           3778 ;	genGenPointerGet
   296B 8D 82              3779 	mov	dpl,r5
   296D 8E 83              3780 	mov	dph,r6
   296F 8F F0              3781 	mov	b,r7
   2971 12 E4 9F           3782 	lcall	__gptrget
                           3783 ;	genIfxJump
                           3784 ;	Peephole 108.c	removed ljmp by inverse jump logic
   2974 60 34              3785 	jz	00106$
                           3786 ;	Peephole 300	removed redundant label 00122$
                           3787 ;	../../FreeRTOS/Source/queue.c:618: if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToReceive ) ) != pdFALSE )
                           3788 ;	genPlus
                           3789 ;     genPlusIncr
   2976 74 18              3790 	mov	a,#0x18
                           3791 ;	Peephole 236.a	used r2 instead of ar2
   2978 2A                 3792 	add	a,r2
   2979 FD                 3793 	mov	r5,a
                           3794 ;	Peephole 181	changed mov to clr
   297A E4                 3795 	clr	a
                           3796 ;	Peephole 236.b	used r3 instead of ar3
   297B 3B                 3797 	addc	a,r3
   297C FE                 3798 	mov	r6,a
   297D 8C 07              3799 	mov	ar7,r4
                           3800 ;	genCall
   297F 8D 82              3801 	mov	dpl,r5
   2981 8E 83              3802 	mov	dph,r6
   2983 8F F0              3803 	mov	b,r7
   2985 C0 02              3804 	push	ar2
   2987 C0 03              3805 	push	ar3
   2989 C0 04              3806 	push	ar4
   298B 12 14 D7           3807 	lcall	_xTaskRemoveFromEventList
   298E AD 82              3808 	mov	r5,dpl
   2990 D0 04              3809 	pop	ar4
   2992 D0 03              3810 	pop	ar3
   2994 D0 02              3811 	pop	ar2
                           3812 ;	genCmpEq
                           3813 ;	gencjneshort
   2996 BD 00 02           3814 	cjne	r5,#0x00,00123$
                           3815 ;	Peephole 112.b	changed ljmp to sjmp
   2999 80 0F              3816 	sjmp	00106$
   299B                    3817 00123$:
                           3818 ;	../../FreeRTOS/Source/queue.c:622: vTaskMissedYield();
                           3819 ;	genCall
   299B C0 02              3820 	push	ar2
   299D C0 03              3821 	push	ar3
   299F C0 04              3822 	push	ar4
   29A1 12 17 72           3823 	lcall	_vTaskMissedYield
   29A4 D0 04              3824 	pop	ar4
   29A6 D0 03              3825 	pop	ar3
   29A8 D0 02              3826 	pop	ar2
   29AA                    3827 00106$:
                           3828 ;	../../FreeRTOS/Source/queue.c:627: taskEXIT_CRITICAL();
                           3829 ;	genInline
   29AA D0 E0              3830 	 pop ACC 
                           3831 ;	genAnd
   29AC 53 E0 80           3832 	anl	_ACC,#0x80
                           3833 ;	genOr
   29AF E5 E0              3834 	mov	a,_ACC
   29B1 42 A8              3835 	orl	_IE,a
                           3836 ;	genInline
   29B3 D0 E0              3837 	 pop ACC 
                           3838 ;	../../FreeRTOS/Source/queue.c:630: taskENTER_CRITICAL();
                           3839 ;	genInline
   29B5 C0 E0 C0 A8        3840 	 push ACC push IE 
                           3841 ;	genAssign
   29B9 C2 AF              3842 	clr	_EA
                           3843 ;	../../FreeRTOS/Source/queue.c:632: --( pxQueue->xRxLock );
                           3844 ;	genPlus
                           3845 ;     genPlusIncr
   29BB 74 27              3846 	mov	a,#0x27
                           3847 ;	Peephole 236.a	used r2 instead of ar2
   29BD 2A                 3848 	add	a,r2
   29BE FD                 3849 	mov	r5,a
                           3850 ;	Peephole 181	changed mov to clr
   29BF E4                 3851 	clr	a
                           3852 ;	Peephole 236.b	used r3 instead of ar3
   29C0 3B                 3853 	addc	a,r3
   29C1 FE                 3854 	mov	r6,a
   29C2 8C 07              3855 	mov	ar7,r4
                           3856 ;	genPointerGet
                           3857 ;	genGenPointerGet
   29C4 8D 82              3858 	mov	dpl,r5
   29C6 8E 83              3859 	mov	dph,r6
   29C8 8F F0              3860 	mov	b,r7
   29CA 12 E4 9F           3861 	lcall	__gptrget
   29CD F8                 3862 	mov	r0,a
                           3863 ;	genMinus
                           3864 ;	genMinusDec
   29CE 18                 3865 	dec	r0
                           3866 ;	genPointerSet
                           3867 ;	genGenPointerSet
   29CF 8D 82              3868 	mov	dpl,r5
   29D1 8E 83              3869 	mov	dph,r6
   29D3 8F F0              3870 	mov	b,r7
   29D5 E8                 3871 	mov	a,r0
   29D6 12 DF B7           3872 	lcall	__gptrput
                           3873 ;	../../FreeRTOS/Source/queue.c:634: if( pxQueue->xRxLock > queueUNLOCKED )
                           3874 ;	genCmpGt
                           3875 ;	genCmp
   29D9 C3                 3876 	clr	c
                           3877 ;	Peephole 159	avoided xrl during execution
   29DA 74 7F              3878 	mov	a,#(0xFF ^ 0x80)
   29DC 88 F0              3879 	mov	b,r0
   29DE 63 F0 80           3880 	xrl	b,#0x80
   29E1 95 F0              3881 	subb	a,b
                           3882 ;	genIfxJump
                           3883 ;	Peephole 108.a	removed ljmp by inverse jump logic
   29E3 50 39              3884 	jnc	00112$
                           3885 ;	Peephole 300	removed redundant label 00124$
                           3886 ;	../../FreeRTOS/Source/queue.c:636: pxQueue->xRxLock = queueUNLOCKED;
                           3887 ;	genPointerSet
                           3888 ;	genGenPointerSet
   29E5 8D 82              3889 	mov	dpl,r5
   29E7 8E 83              3890 	mov	dph,r6
   29E9 8F F0              3891 	mov	b,r7
   29EB 74 FF              3892 	mov	a,#0xFF
   29ED 12 DF B7           3893 	lcall	__gptrput
                           3894 ;	../../FreeRTOS/Source/queue.c:638: if( !listLIST_IS_EMPTY( &( pxQueue->xTasksWaitingToSend ) ) )
                           3895 ;	genPlus
                           3896 ;     genPlusIncr
   29F0 74 0C              3897 	mov	a,#0x0C
                           3898 ;	Peephole 236.a	used r2 instead of ar2
   29F2 2A                 3899 	add	a,r2
   29F3 FD                 3900 	mov	r5,a
                           3901 ;	Peephole 181	changed mov to clr
   29F4 E4                 3902 	clr	a
                           3903 ;	Peephole 236.b	used r3 instead of ar3
   29F5 3B                 3904 	addc	a,r3
   29F6 FE                 3905 	mov	r6,a
   29F7 8C 07              3906 	mov	ar7,r4
                           3907 ;	genPointerGet
                           3908 ;	genGenPointerGet
   29F9 8D 82              3909 	mov	dpl,r5
   29FB 8E 83              3910 	mov	dph,r6
   29FD 8F F0              3911 	mov	b,r7
   29FF 12 E4 9F           3912 	lcall	__gptrget
                           3913 ;	genIfxJump
                           3914 ;	Peephole 108.c	removed ljmp by inverse jump logic
   2A02 60 1A              3915 	jz	00112$
                           3916 ;	Peephole 300	removed redundant label 00125$
                           3917 ;	../../FreeRTOS/Source/queue.c:640: if( xTaskRemoveFromEventList( &( pxQueue->xTasksWaitingToSend ) ) != pdFALSE )
                           3918 ;	genPlus
                           3919 ;     genPlusIncr
   2A04 74 0C              3920 	mov	a,#0x0C
                           3921 ;	Peephole 236.a	used r2 instead of ar2
   2A06 2A                 3922 	add	a,r2
   2A07 FA                 3923 	mov	r2,a
                           3924 ;	Peephole 181	changed mov to clr
   2A08 E4                 3925 	clr	a
                           3926 ;	Peephole 236.b	used r3 instead of ar3
   2A09 3B                 3927 	addc	a,r3
   2A0A FB                 3928 	mov	r3,a
                           3929 ;	genCall
   2A0B 8A 82              3930 	mov	dpl,r2
   2A0D 8B 83              3931 	mov	dph,r3
   2A0F 8C F0              3932 	mov	b,r4
   2A11 12 14 D7           3933 	lcall	_xTaskRemoveFromEventList
   2A14 AA 82              3934 	mov	r2,dpl
                           3935 ;	genCmpEq
                           3936 ;	gencjneshort
   2A16 BA 00 02           3937 	cjne	r2,#0x00,00126$
                           3938 ;	Peephole 112.b	changed ljmp to sjmp
   2A19 80 03              3939 	sjmp	00112$
   2A1B                    3940 00126$:
                           3941 ;	../../FreeRTOS/Source/queue.c:642: vTaskMissedYield();
                           3942 ;	genCall
   2A1B 12 17 72           3943 	lcall	_vTaskMissedYield
   2A1E                    3944 00112$:
                           3945 ;	../../FreeRTOS/Source/queue.c:647: taskEXIT_CRITICAL();
                           3946 ;	genInline
   2A1E D0 E0              3947 	 pop ACC 
                           3948 ;	genAnd
   2A20 53 E0 80           3949 	anl	_ACC,#0x80
                           3950 ;	genOr
   2A23 E5 E0              3951 	mov	a,_ACC
   2A25 42 A8              3952 	orl	_IE,a
                           3953 ;	genInline
   2A27 D0 E0              3954 	 pop ACC 
                           3955 ;	Peephole 300	removed redundant label 00113$
   2A29 22                 3956 	ret
                           3957 ;------------------------------------------------------------
                           3958 ;Allocation info for local variables in function 'prvIsQueueEmpty'
                           3959 ;------------------------------------------------------------
                           3960 ;pxQueue                   Allocated to registers r2 r3 r4 
                           3961 ;xReturn                   Allocated to registers r2 
                           3962 ;------------------------------------------------------------
                           3963 ;	../../FreeRTOS/Source/queue.c:651: static signed portBASE_TYPE prvIsQueueEmpty( const xQueueHandle pxQueue )
                           3964 ;	-----------------------------------------
                           3965 ;	 function prvIsQueueEmpty
                           3966 ;	-----------------------------------------
   2A2A                    3967 _prvIsQueueEmpty:
                           3968 ;	genReceive
   2A2A AA 82              3969 	mov	r2,dpl
   2A2C AB 83              3970 	mov	r3,dph
   2A2E AC F0              3971 	mov	r4,b
                           3972 ;	../../FreeRTOS/Source/queue.c:655: taskENTER_CRITICAL();
                           3973 ;	genInline
   2A30 C0 E0 C0 A8        3974 	 push ACC push IE 
                           3975 ;	genAssign
   2A34 C2 AF              3976 	clr	_EA
                           3977 ;	../../FreeRTOS/Source/queue.c:656: xReturn = ( pxQueue->uxMessagesWaiting == ( unsigned portBASE_TYPE ) 0 );
                           3978 ;	genPlus
                           3979 ;     genPlusIncr
   2A36 74 24              3980 	mov	a,#0x24
                           3981 ;	Peephole 236.a	used r2 instead of ar2
   2A38 2A                 3982 	add	a,r2
   2A39 FA                 3983 	mov	r2,a
                           3984 ;	Peephole 181	changed mov to clr
   2A3A E4                 3985 	clr	a
                           3986 ;	Peephole 236.b	used r3 instead of ar3
   2A3B 3B                 3987 	addc	a,r3
   2A3C FB                 3988 	mov	r3,a
                           3989 ;	genPointerGet
                           3990 ;	genGenPointerGet
   2A3D 8A 82              3991 	mov	dpl,r2
   2A3F 8B 83              3992 	mov	dph,r3
   2A41 8C F0              3993 	mov	b,r4
   2A43 12 E4 9F           3994 	lcall	__gptrget
   2A46 FA                 3995 	mov	r2,a
                           3996 ;	genCmpEq
                           3997 ;	gencjne
                           3998 ;	gencjneshort
                           3999 ;	Peephole 241.d	optimized compare
   2A47 E4                 4000 	clr	a
   2A48 BA 00 01           4001 	cjne	r2,#0x00,00103$
   2A4B 04                 4002 	inc	a
   2A4C                    4003 00103$:
                           4004 ;	Peephole 300	removed redundant label 00104$
   2A4C FA                 4005 	mov	r2,a
                           4006 ;	../../FreeRTOS/Source/queue.c:657: taskEXIT_CRITICAL();
                           4007 ;	genInline
   2A4D D0 E0              4008 	 pop ACC 
                           4009 ;	genAnd
   2A4F 53 E0 80           4010 	anl	_ACC,#0x80
                           4011 ;	genOr
   2A52 E5 E0              4012 	mov	a,_ACC
   2A54 42 A8              4013 	orl	_IE,a
                           4014 ;	genInline
   2A56 D0 E0              4015 	 pop ACC 
                           4016 ;	../../FreeRTOS/Source/queue.c:659: return xReturn;
                           4017 ;	genRet
   2A58 8A 82              4018 	mov	dpl,r2
                           4019 ;	Peephole 300	removed redundant label 00101$
   2A5A 22                 4020 	ret
                           4021 ;------------------------------------------------------------
                           4022 ;Allocation info for local variables in function 'prvIsQueueFull'
                           4023 ;------------------------------------------------------------
                           4024 ;pxQueue                   Allocated to registers r2 r3 r4 
                           4025 ;xReturn                   Allocated to registers r5 
                           4026 ;------------------------------------------------------------
                           4027 ;	../../FreeRTOS/Source/queue.c:663: static signed portBASE_TYPE prvIsQueueFull( const xQueueHandle pxQueue )
                           4028 ;	-----------------------------------------
                           4029 ;	 function prvIsQueueFull
                           4030 ;	-----------------------------------------
   2A5B                    4031 _prvIsQueueFull:
                           4032 ;	genReceive
   2A5B AA 82              4033 	mov	r2,dpl
   2A5D AB 83              4034 	mov	r3,dph
   2A5F AC F0              4035 	mov	r4,b
                           4036 ;	../../FreeRTOS/Source/queue.c:667: taskENTER_CRITICAL();
                           4037 ;	genInline
   2A61 C0 E0 C0 A8        4038 	 push ACC push IE 
                           4039 ;	genAssign
   2A65 C2 AF              4040 	clr	_EA
                           4041 ;	../../FreeRTOS/Source/queue.c:668: xReturn = ( pxQueue->uxMessagesWaiting == pxQueue->uxLength );
                           4042 ;	genPlus
                           4043 ;     genPlusIncr
   2A67 74 24              4044 	mov	a,#0x24
                           4045 ;	Peephole 236.a	used r2 instead of ar2
   2A69 2A                 4046 	add	a,r2
   2A6A FD                 4047 	mov	r5,a
                           4048 ;	Peephole 181	changed mov to clr
   2A6B E4                 4049 	clr	a
                           4050 ;	Peephole 236.b	used r3 instead of ar3
   2A6C 3B                 4051 	addc	a,r3
   2A6D FE                 4052 	mov	r6,a
   2A6E 8C 07              4053 	mov	ar7,r4
                           4054 ;	genPointerGet
                           4055 ;	genGenPointerGet
   2A70 8D 82              4056 	mov	dpl,r5
   2A72 8E 83              4057 	mov	dph,r6
   2A74 8F F0              4058 	mov	b,r7
   2A76 12 E4 9F           4059 	lcall	__gptrget
   2A79 FD                 4060 	mov	r5,a
                           4061 ;	genPlus
                           4062 ;     genPlusIncr
   2A7A 74 25              4063 	mov	a,#0x25
                           4064 ;	Peephole 236.a	used r2 instead of ar2
   2A7C 2A                 4065 	add	a,r2
   2A7D FA                 4066 	mov	r2,a
                           4067 ;	Peephole 181	changed mov to clr
   2A7E E4                 4068 	clr	a
                           4069 ;	Peephole 236.b	used r3 instead of ar3
   2A7F 3B                 4070 	addc	a,r3
   2A80 FB                 4071 	mov	r3,a
                           4072 ;	genPointerGet
                           4073 ;	genGenPointerGet
   2A81 8A 82              4074 	mov	dpl,r2
   2A83 8B 83              4075 	mov	dph,r3
   2A85 8C F0              4076 	mov	b,r4
   2A87 12 E4 9F           4077 	lcall	__gptrget
   2A8A FA                 4078 	mov	r2,a
                           4079 ;	genCmpEq
                           4080 ;	gencjne
                           4081 ;	gencjneshort
   2A8B ED                 4082 	mov	a,r5
   2A8C B5 02 04           4083 	cjne	a,ar2,00103$
   2A8F 74 01              4084 	mov	a,#0x01
   2A91 80 01              4085 	sjmp	00104$
   2A93                    4086 00103$:
   2A93 E4                 4087 	clr	a
   2A94                    4088 00104$:
   2A94 FD                 4089 	mov	r5,a
                           4090 ;	genAssign
                           4091 ;	../../FreeRTOS/Source/queue.c:669: taskEXIT_CRITICAL();
                           4092 ;	genInline
   2A95 D0 E0              4093 	 pop ACC 
                           4094 ;	genAnd
   2A97 53 E0 80           4095 	anl	_ACC,#0x80
                           4096 ;	genOr
   2A9A E5 E0              4097 	mov	a,_ACC
   2A9C 42 A8              4098 	orl	_IE,a
                           4099 ;	genInline
   2A9E D0 E0              4100 	 pop ACC 
                           4101 ;	../../FreeRTOS/Source/queue.c:671: return xReturn;
                           4102 ;	genRet
   2AA0 8D 82              4103 	mov	dpl,r5
                           4104 ;	Peephole 300	removed redundant label 00101$
   2AA2 22                 4105 	ret
                           4106 	.area CSEG    (CODE)
                           4107 	.area CONST   (CODE)
                           4108 	.area XINIT   (CODE)
