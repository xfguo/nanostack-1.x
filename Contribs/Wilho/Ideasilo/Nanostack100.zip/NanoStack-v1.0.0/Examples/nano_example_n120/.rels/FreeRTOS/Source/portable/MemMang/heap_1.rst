                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Nov 10 2006)
                              4 ; This file generated Fri Feb  1 13:33:37 2008
                              5 ;--------------------------------------------------------
                              6 	.module heap_1
                              7 	.optsdcc -mmcs51 --model-large
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _IRCON2_P2IF
                             13 	.globl _IRCON2_UTX0IF
                             14 	.globl _IRCON2_UTX1IF
                             15 	.globl _IRCON2_P1IF
                             16 	.globl _IRCON2_WDTIF
                             17 	.globl _CY
                             18 	.globl _AC
                             19 	.globl _F0
                             20 	.globl _RS1
                             21 	.globl _RS0
                             22 	.globl _OV
                             23 	.globl _F1
                             24 	.globl _P
                             25 	.globl _IRCON_DMAIF
                             26 	.globl _IRCON_T1IF
                             27 	.globl _IRCON_T2IF
                             28 	.globl _IRCON_T3IF
                             29 	.globl _IRCON_T4IF
                             30 	.globl _IRCON_P0IF
                             31 	.globl _IRCON_STIF
                             32 	.globl _IEN1_DMAIE
                             33 	.globl _IEN1_T1IE
                             34 	.globl _IEN1_T2IE
                             35 	.globl _IEN1_T3IE
                             36 	.globl _IEN1_T4IE
                             37 	.globl _IEN1_P0IE
                             38 	.globl _IEN0_RFERRIE
                             39 	.globl _IEN0_ADCIE
                             40 	.globl _IEN0_URX0IE
                             41 	.globl _IEN0_URX1IE
                             42 	.globl _IEN0_ENCIE
                             43 	.globl _IEN0_STIE
                             44 	.globl _IEN0_EA
                             45 	.globl _EA
                             46 	.globl _P2_4
                             47 	.globl _P2_3
                             48 	.globl _P2_2
                             49 	.globl _P2_1
                             50 	.globl _P2_0
                             51 	.globl _S0CON_ENCIF_0
                             52 	.globl _S0CON_ENCIF_1
                             53 	.globl _P1_7
                             54 	.globl _P1_6
                             55 	.globl _P1_5
                             56 	.globl _P1_4
                             57 	.globl _P1_3
                             58 	.globl _P1_2
                             59 	.globl _P1_1
                             60 	.globl _P1_0
                             61 	.globl _TCON_IT0
                             62 	.globl _TCON_RFERRIF
                             63 	.globl _TCON_IT1
                             64 	.globl _TCON_URX0IF
                             65 	.globl _TCON_ADCIF
                             66 	.globl _TCON_URX1IF
                             67 	.globl _P0_0
                             68 	.globl _P0_1
                             69 	.globl _P0_2
                             70 	.globl _P0_3
                             71 	.globl _P0_4
                             72 	.globl _P0_5
                             73 	.globl _P0_6
                             74 	.globl _P0_7
                             75 	.globl _P2DIR
                             76 	.globl _P1DIR
                             77 	.globl _P0DIR
                             78 	.globl _U1GCR
                             79 	.globl _U1UCR
                             80 	.globl _U1BAUD
                             81 	.globl _U1BUF
                             82 	.globl _U1CSR
                             83 	.globl _P2INP
                             84 	.globl _P1INP
                             85 	.globl _P2SEL
                             86 	.globl _P1SEL
                             87 	.globl _P0SEL
                             88 	.globl _ADCCFG
                             89 	.globl _PERCFG
                             90 	.globl _B
                             91 	.globl _T4CC1
                             92 	.globl _T4CCTL1
                             93 	.globl _T4CC0
                             94 	.globl _T4CCTL0
                             95 	.globl _T4CTL
                             96 	.globl _T4CNT
                             97 	.globl _RFIF
                             98 	.globl _IRCON2
                             99 	.globl _T1CCTL2
                            100 	.globl _T1CCTL1
                            101 	.globl _T1CCTL0
                            102 	.globl _T1CTL
                            103 	.globl _T1CNTH
                            104 	.globl _T1CNTL
                            105 	.globl _RFST
                            106 	.globl _ACC
                            107 	.globl _T1CC2H
                            108 	.globl _T1CC2L
                            109 	.globl _T1CC1H
                            110 	.globl _T1CC1L
                            111 	.globl _T1CC0H
                            112 	.globl _T1CC0L
                            113 	.globl _RFD
                            114 	.globl _TIMIF
                            115 	.globl _DMAREQ
                            116 	.globl _DMAARM
                            117 	.globl _DMA0CFGH
                            118 	.globl _DMA0CFGL
                            119 	.globl _DMA1CFGH
                            120 	.globl _DMA1CFGL
                            121 	.globl _DMAIRQ
                            122 	.globl _PSW
                            123 	.globl _T3CC1
                            124 	.globl _T3CCTL1
                            125 	.globl _T3CC0
                            126 	.globl _T3CCTL0
                            127 	.globl _T3CTL
                            128 	.globl _T3CNT
                            129 	.globl _WDCTL
                            130 	.globl _T2CON
                            131 	.globl _MEMCTR
                            132 	.globl _CLKCON
                            133 	.globl _U0GCR
                            134 	.globl _U0UCR
                            135 	.globl _T2CNF
                            136 	.globl _U0BAUD
                            137 	.globl _U0BUF
                            138 	.globl _IRCON
                            139 	.globl _SLEEP
                            140 	.globl _RNDH
                            141 	.globl _RNDL
                            142 	.globl _ADCH
                            143 	.globl _ADCL
                            144 	.globl _IP1
                            145 	.globl _IEN1
                            146 	.globl _RCCTL
                            147 	.globl _ADCCON3
                            148 	.globl _ADCCON2
                            149 	.globl _ADCCON1
                            150 	.globl _ENCCS
                            151 	.globl _ENCDO
                            152 	.globl _ENCDI
                            153 	.globl _FWDATA
                            154 	.globl _FCTL
                            155 	.globl _FADDRH
                            156 	.globl _FADDRL
                            157 	.globl _FWT
                            158 	.globl _IP0
                            159 	.globl _IEN0
                            160 	.globl _IE
                            161 	.globl _T2THD
                            162 	.globl _T2TLD
                            163 	.globl _T2CAPHPH
                            164 	.globl _T2CAPLPL
                            165 	.globl _T2OF2
                            166 	.globl _T2OF1
                            167 	.globl _T2OF0
                            168 	.globl _P2
                            169 	.globl _T2PEROF2
                            170 	.globl _T2PEROF1
                            171 	.globl _T2PEROF0
                            172 	.globl _S1CON
                            173 	.globl _IEN2
                            174 	.globl _HSRC
                            175 	.globl _S0CON
                            176 	.globl _ST2
                            177 	.globl _ST1
                            178 	.globl _ST0
                            179 	.globl _T2CMP
                            180 	.globl __XPAGE
                            181 	.globl _DPS
                            182 	.globl _RFIM
                            183 	.globl _P1
                            184 	.globl _P0INP
                            185 	.globl _P1IEN
                            186 	.globl _PICTL
                            187 	.globl _P2IFG
                            188 	.globl _P1IFG
                            189 	.globl _P0IFG
                            190 	.globl _TCON
                            191 	.globl _PCON
                            192 	.globl _U0CSR
                            193 	.globl _DPH1
                            194 	.globl _DPL1
                            195 	.globl _DPH0
                            196 	.globl _DPL0
                            197 	.globl _SP
                            198 	.globl _P0
                            199 	.globl _RFD_SHADOW
                            200 	.globl _RFSTATUS
                            201 	.globl _CHIPID
                            202 	.globl _CHVER
                            203 	.globl _FSMTC1
                            204 	.globl _RXFIFOCNT
                            205 	.globl _IOCFG3
                            206 	.globl _IOCFG2
                            207 	.globl _IOCFG1
                            208 	.globl _IOCFG0
                            209 	.globl _SHORTADDRL
                            210 	.globl _SHORTADDRH
                            211 	.globl _PANIDL
                            212 	.globl _PANIDH
                            213 	.globl _IEEE_ADDR7
                            214 	.globl _IEEE_ADDR6
                            215 	.globl _IEEE_ADDR5
                            216 	.globl _IEEE_ADDR4
                            217 	.globl _IEEE_ADDR3
                            218 	.globl _IEEE_ADDR2
                            219 	.globl _IEEE_ADDR1
                            220 	.globl _IEEE_ADDR0
                            221 	.globl _DACTSTL
                            222 	.globl _DACTSTH
                            223 	.globl _ADCTSTL
                            224 	.globl _ADCTSTH
                            225 	.globl _FSMSTATE
                            226 	.globl _AGCCTRLL
                            227 	.globl _AGCCTRLH
                            228 	.globl _MANORL
                            229 	.globl _MANORH
                            230 	.globl _MANANDL
                            231 	.globl _MANANDH
                            232 	.globl _FSMTCL
                            233 	.globl _FSMTCH
                            234 	.globl _RFPWR
                            235 	.globl _CSPT
                            236 	.globl _CSPCTRL
                            237 	.globl _CSPZ
                            238 	.globl _CSPY
                            239 	.globl _CSPX
                            240 	.globl _FSCTRLL
                            241 	.globl _FSCTRLH
                            242 	.globl _RXCTRL1L
                            243 	.globl _RXCTRL1H
                            244 	.globl _RXCTRL0L
                            245 	.globl _RXCTRL0H
                            246 	.globl _TXCTRLL
                            247 	.globl _TXCTRLH
                            248 	.globl _SYNCWORDL
                            249 	.globl _SYNCWORDH
                            250 	.globl _RSSIL
                            251 	.globl _RSSIH
                            252 	.globl _MDMCTRL1L
                            253 	.globl _MDMCTRL1H
                            254 	.globl _MDMCTRL0L
                            255 	.globl _MDMCTRL0H
                            256 	.globl _pvPortMalloc
                            257 	.globl _vPortFree
                            258 	.globl _vPortInitialiseBlocks
                            259 ;--------------------------------------------------------
                            260 ; special function registers
                            261 ;--------------------------------------------------------
                            262 	.area RSEG    (DATA)
                    0080    263 _P0	=	0x0080
                    0081    264 _SP	=	0x0081
                    0082    265 _DPL0	=	0x0082
                    0083    266 _DPH0	=	0x0083
                    0084    267 _DPL1	=	0x0084
                    0085    268 _DPH1	=	0x0085
                    0086    269 _U0CSR	=	0x0086
                    0087    270 _PCON	=	0x0087
                    0088    271 _TCON	=	0x0088
                    0089    272 _P0IFG	=	0x0089
                    008A    273 _P1IFG	=	0x008a
                    008B    274 _P2IFG	=	0x008b
                    008C    275 _PICTL	=	0x008c
                    008D    276 _P1IEN	=	0x008d
                    008F    277 _P0INP	=	0x008f
                    0090    278 _P1	=	0x0090
                    0091    279 _RFIM	=	0x0091
                    0092    280 _DPS	=	0x0092
                    0093    281 __XPAGE	=	0x0093
                    0094    282 _T2CMP	=	0x0094
                    0095    283 _ST0	=	0x0095
                    0096    284 _ST1	=	0x0096
                    0097    285 _ST2	=	0x0097
                    0098    286 _S0CON	=	0x0098
                    0099    287 _HSRC	=	0x0099
                    009A    288 _IEN2	=	0x009a
                    009B    289 _S1CON	=	0x009b
                    009C    290 _T2PEROF0	=	0x009c
                    009D    291 _T2PEROF1	=	0x009d
                    009E    292 _T2PEROF2	=	0x009e
                    00A0    293 _P2	=	0x00a0
                    00A1    294 _T2OF0	=	0x00a1
                    00A2    295 _T2OF1	=	0x00a2
                    00A3    296 _T2OF2	=	0x00a3
                    00A4    297 _T2CAPLPL	=	0x00a4
                    00A5    298 _T2CAPHPH	=	0x00a5
                    00A6    299 _T2TLD	=	0x00a6
                    00A7    300 _T2THD	=	0x00a7
                    00A8    301 _IE	=	0x00a8
                    00A8    302 _IEN0	=	0x00a8
                    00A9    303 _IP0	=	0x00a9
                    00AB    304 _FWT	=	0x00ab
                    00AC    305 _FADDRL	=	0x00ac
                    00AD    306 _FADDRH	=	0x00ad
                    00AE    307 _FCTL	=	0x00ae
                    00AF    308 _FWDATA	=	0x00af
                    00B1    309 _ENCDI	=	0x00b1
                    00B2    310 _ENCDO	=	0x00b2
                    00B3    311 _ENCCS	=	0x00b3
                    00B4    312 _ADCCON1	=	0x00b4
                    00B5    313 _ADCCON2	=	0x00b5
                    00B6    314 _ADCCON3	=	0x00b6
                    00B7    315 _RCCTL	=	0x00b7
                    00B8    316 _IEN1	=	0x00b8
                    00B9    317 _IP1	=	0x00b9
                    00BA    318 _ADCL	=	0x00ba
                    00BB    319 _ADCH	=	0x00bb
                    00BC    320 _RNDL	=	0x00bc
                    00BD    321 _RNDH	=	0x00bd
                    00BE    322 _SLEEP	=	0x00be
                    00C0    323 _IRCON	=	0x00c0
                    00C1    324 _U0BUF	=	0x00c1
                    00C2    325 _U0BAUD	=	0x00c2
                    00C3    326 _T2CNF	=	0x00c3
                    00C4    327 _U0UCR	=	0x00c4
                    00C5    328 _U0GCR	=	0x00c5
                    00C6    329 _CLKCON	=	0x00c6
                    00C7    330 _MEMCTR	=	0x00c7
                    00C8    331 _T2CON	=	0x00c8
                    00C9    332 _WDCTL	=	0x00c9
                    00CA    333 _T3CNT	=	0x00ca
                    00CB    334 _T3CTL	=	0x00cb
                    00CC    335 _T3CCTL0	=	0x00cc
                    00CD    336 _T3CC0	=	0x00cd
                    00CE    337 _T3CCTL1	=	0x00ce
                    00CF    338 _T3CC1	=	0x00cf
                    00D0    339 _PSW	=	0x00d0
                    00D1    340 _DMAIRQ	=	0x00d1
                    00D2    341 _DMA1CFGL	=	0x00d2
                    00D3    342 _DMA1CFGH	=	0x00d3
                    00D4    343 _DMA0CFGL	=	0x00d4
                    00D5    344 _DMA0CFGH	=	0x00d5
                    00D6    345 _DMAARM	=	0x00d6
                    00D7    346 _DMAREQ	=	0x00d7
                    00D8    347 _TIMIF	=	0x00d8
                    00D9    348 _RFD	=	0x00d9
                    00DA    349 _T1CC0L	=	0x00da
                    00DB    350 _T1CC0H	=	0x00db
                    00DC    351 _T1CC1L	=	0x00dc
                    00DD    352 _T1CC1H	=	0x00dd
                    00DE    353 _T1CC2L	=	0x00de
                    00DF    354 _T1CC2H	=	0x00df
                    00E0    355 _ACC	=	0x00e0
                    00E1    356 _RFST	=	0x00e1
                    00E2    357 _T1CNTL	=	0x00e2
                    00E3    358 _T1CNTH	=	0x00e3
                    00E4    359 _T1CTL	=	0x00e4
                    00E5    360 _T1CCTL0	=	0x00e5
                    00E6    361 _T1CCTL1	=	0x00e6
                    00E7    362 _T1CCTL2	=	0x00e7
                    00E8    363 _IRCON2	=	0x00e8
                    00E9    364 _RFIF	=	0x00e9
                    00EA    365 _T4CNT	=	0x00ea
                    00EB    366 _T4CTL	=	0x00eb
                    00EC    367 _T4CCTL0	=	0x00ec
                    00ED    368 _T4CC0	=	0x00ed
                    00EE    369 _T4CCTL1	=	0x00ee
                    00EF    370 _T4CC1	=	0x00ef
                    00F0    371 _B	=	0x00f0
                    00F1    372 _PERCFG	=	0x00f1
                    00F2    373 _ADCCFG	=	0x00f2
                    00F3    374 _P0SEL	=	0x00f3
                    00F4    375 _P1SEL	=	0x00f4
                    00F5    376 _P2SEL	=	0x00f5
                    00F6    377 _P1INP	=	0x00f6
                    00F7    378 _P2INP	=	0x00f7
                    00F8    379 _U1CSR	=	0x00f8
                    00F9    380 _U1BUF	=	0x00f9
                    00FA    381 _U1BAUD	=	0x00fa
                    00FB    382 _U1UCR	=	0x00fb
                    00FC    383 _U1GCR	=	0x00fc
                    00FD    384 _P0DIR	=	0x00fd
                    00FE    385 _P1DIR	=	0x00fe
                    00FF    386 _P2DIR	=	0x00ff
                            387 ;--------------------------------------------------------
                            388 ; special function bits
                            389 ;--------------------------------------------------------
                            390 	.area RSEG    (DATA)
                    0087    391 _P0_7	=	0x0087
                    0086    392 _P0_6	=	0x0086
                    0085    393 _P0_5	=	0x0085
                    0084    394 _P0_4	=	0x0084
                    0083    395 _P0_3	=	0x0083
                    0082    396 _P0_2	=	0x0082
                    0081    397 _P0_1	=	0x0081
                    0080    398 _P0_0	=	0x0080
                    008F    399 _TCON_URX1IF	=	0x008f
                    008D    400 _TCON_ADCIF	=	0x008d
                    008B    401 _TCON_URX0IF	=	0x008b
                    008A    402 _TCON_IT1	=	0x008a
                    0089    403 _TCON_RFERRIF	=	0x0089
                    0088    404 _TCON_IT0	=	0x0088
                    0090    405 _P1_0	=	0x0090
                    0091    406 _P1_1	=	0x0091
                    0092    407 _P1_2	=	0x0092
                    0093    408 _P1_3	=	0x0093
                    0094    409 _P1_4	=	0x0094
                    0095    410 _P1_5	=	0x0095
                    0096    411 _P1_6	=	0x0096
                    0097    412 _P1_7	=	0x0097
                    0099    413 _S0CON_ENCIF_1	=	0x0099
                    0098    414 _S0CON_ENCIF_0	=	0x0098
                    00A0    415 _P2_0	=	0x00a0
                    00A1    416 _P2_1	=	0x00a1
                    00A2    417 _P2_2	=	0x00a2
                    00A3    418 _P2_3	=	0x00a3
                    00A4    419 _P2_4	=	0x00a4
                    00AF    420 _EA	=	0x00af
                    00AF    421 _IEN0_EA	=	0x00af
                    00AD    422 _IEN0_STIE	=	0x00ad
                    00AC    423 _IEN0_ENCIE	=	0x00ac
                    00AB    424 _IEN0_URX1IE	=	0x00ab
                    00AA    425 _IEN0_URX0IE	=	0x00aa
                    00A9    426 _IEN0_ADCIE	=	0x00a9
                    00A8    427 _IEN0_RFERRIE	=	0x00a8
                    00BD    428 _IEN1_P0IE	=	0x00bd
                    00BC    429 _IEN1_T4IE	=	0x00bc
                    00BB    430 _IEN1_T3IE	=	0x00bb
                    00BA    431 _IEN1_T2IE	=	0x00ba
                    00B9    432 _IEN1_T1IE	=	0x00b9
                    00B8    433 _IEN1_DMAIE	=	0x00b8
                    00C7    434 _IRCON_STIF	=	0x00c7
                    00C5    435 _IRCON_P0IF	=	0x00c5
                    00C4    436 _IRCON_T4IF	=	0x00c4
                    00C3    437 _IRCON_T3IF	=	0x00c3
                    00C2    438 _IRCON_T2IF	=	0x00c2
                    00C1    439 _IRCON_T1IF	=	0x00c1
                    00C0    440 _IRCON_DMAIF	=	0x00c0
                    00D0    441 _P	=	0x00d0
                    00D1    442 _F1	=	0x00d1
                    00D2    443 _OV	=	0x00d2
                    00D3    444 _RS0	=	0x00d3
                    00D4    445 _RS1	=	0x00d4
                    00D5    446 _F0	=	0x00d5
                    00D6    447 _AC	=	0x00d6
                    00D7    448 _CY	=	0x00d7
                    00EC    449 _IRCON2_WDTIF	=	0x00ec
                    00EB    450 _IRCON2_P1IF	=	0x00eb
                    00EA    451 _IRCON2_UTX1IF	=	0x00ea
                    00E9    452 _IRCON2_UTX0IF	=	0x00e9
                    00E8    453 _IRCON2_P2IF	=	0x00e8
                            454 ;--------------------------------------------------------
                            455 ; overlayable register banks
                            456 ;--------------------------------------------------------
                            457 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     458 	.ds 8
                            459 ;--------------------------------------------------------
                            460 ; internal ram data
                            461 ;--------------------------------------------------------
                            462 	.area DSEG    (DATA)
                            463 ;--------------------------------------------------------
                            464 ; overlayable items in internal ram 
                            465 ;--------------------------------------------------------
                            466 	.area OSEG    (OVR,DATA)
                            467 ;--------------------------------------------------------
                            468 ; indirectly addressable internal ram data
                            469 ;--------------------------------------------------------
                            470 	.area ISEG    (DATA)
                            471 ;--------------------------------------------------------
                            472 ; bit data
                            473 ;--------------------------------------------------------
                            474 	.area BSEG    (BIT)
                            475 ;--------------------------------------------------------
                            476 ; paged external ram data
                            477 ;--------------------------------------------------------
                            478 	.area PSEG    (PAG,XDATA)
                            479 ;--------------------------------------------------------
                            480 ; external ram data
                            481 ;--------------------------------------------------------
                            482 	.area XSEG    (XDATA)
                    DF02    483 _MDMCTRL0H	=	0xdf02
                    DF03    484 _MDMCTRL0L	=	0xdf03
                    DF04    485 _MDMCTRL1H	=	0xdf04
                    DF05    486 _MDMCTRL1L	=	0xdf05
                    DF06    487 _RSSIH	=	0xdf06
                    DF07    488 _RSSIL	=	0xdf07
                    DF08    489 _SYNCWORDH	=	0xdf08
                    DF09    490 _SYNCWORDL	=	0xdf09
                    DF0A    491 _TXCTRLH	=	0xdf0a
                    DF0B    492 _TXCTRLL	=	0xdf0b
                    DF0C    493 _RXCTRL0H	=	0xdf0c
                    DF0D    494 _RXCTRL0L	=	0xdf0d
                    DF0E    495 _RXCTRL1H	=	0xdf0e
                    DF0F    496 _RXCTRL1L	=	0xdf0f
                    DF10    497 _FSCTRLH	=	0xdf10
                    DF11    498 _FSCTRLL	=	0xdf11
                    DF12    499 _CSPX	=	0xdf12
                    DF13    500 _CSPY	=	0xdf13
                    DF14    501 _CSPZ	=	0xdf14
                    DF15    502 _CSPCTRL	=	0xdf15
                    DF16    503 _CSPT	=	0xdf16
                    DF17    504 _RFPWR	=	0xdf17
                    DF20    505 _FSMTCH	=	0xdf20
                    DF21    506 _FSMTCL	=	0xdf21
                    DF22    507 _MANANDH	=	0xdf22
                    DF23    508 _MANANDL	=	0xdf23
                    DF24    509 _MANORH	=	0xdf24
                    DF25    510 _MANORL	=	0xdf25
                    DF26    511 _AGCCTRLH	=	0xdf26
                    DF27    512 _AGCCTRLL	=	0xdf27
                    DF39    513 _FSMSTATE	=	0xdf39
                    DF3A    514 _ADCTSTH	=	0xdf3a
                    DF3B    515 _ADCTSTL	=	0xdf3b
                    DF3C    516 _DACTSTH	=	0xdf3c
                    DF3D    517 _DACTSTL	=	0xdf3d
                    DF43    518 _IEEE_ADDR0	=	0xdf43
                    DF44    519 _IEEE_ADDR1	=	0xdf44
                    DF45    520 _IEEE_ADDR2	=	0xdf45
                    DF46    521 _IEEE_ADDR3	=	0xdf46
                    DF47    522 _IEEE_ADDR4	=	0xdf47
                    DF48    523 _IEEE_ADDR5	=	0xdf48
                    DF49    524 _IEEE_ADDR6	=	0xdf49
                    DF4A    525 _IEEE_ADDR7	=	0xdf4a
                    DF4B    526 _PANIDH	=	0xdf4b
                    DF4C    527 _PANIDL	=	0xdf4c
                    DF4D    528 _SHORTADDRH	=	0xdf4d
                    DF4E    529 _SHORTADDRL	=	0xdf4e
                    DF4F    530 _IOCFG0	=	0xdf4f
                    DF50    531 _IOCFG1	=	0xdf50
                    DF51    532 _IOCFG2	=	0xdf51
                    DF52    533 _IOCFG3	=	0xdf52
                    DF53    534 _RXFIFOCNT	=	0xdf53
                    DF54    535 _FSMTC1	=	0xdf54
                    DF60    536 _CHVER	=	0xdf60
                    DF61    537 _CHIPID	=	0xdf61
                    DF62    538 _RFSTATUS	=	0xdf62
                    DFD9    539 _RFD_SHADOW	=	0xdfd9
   E06D                     540 _xHeap:
   E06D                     541 	.ds 3504
                            542 ;--------------------------------------------------------
                            543 ; external initialized ram data
                            544 ;--------------------------------------------------------
                            545 	.area XISEG   (XDATA)
   F083                     546 _xNextFreeByte:
   F083                     547 	.ds 2
                            548 	.area HOME    (CODE)
                            549 	.area GSINIT0 (CODE)
                            550 	.area GSINIT1 (CODE)
                            551 	.area GSINIT2 (CODE)
                            552 	.area GSINIT3 (CODE)
                            553 	.area GSINIT4 (CODE)
                            554 	.area GSINIT5 (CODE)
                            555 	.area GSINIT  (CODE)
                            556 	.area GSFINAL (CODE)
                            557 	.area CSEG    (CODE)
                            558 ;--------------------------------------------------------
                            559 ; global & static initialisations
                            560 ;--------------------------------------------------------
                            561 	.area HOME    (CODE)
                            562 	.area GSINIT  (CODE)
                            563 	.area GSFINAL (CODE)
                            564 	.area GSINIT  (CODE)
                            565 ;--------------------------------------------------------
                            566 ; Home
                            567 ;--------------------------------------------------------
                            568 	.area HOME    (CODE)
                            569 	.area CSEG    (CODE)
                            570 ;--------------------------------------------------------
                            571 ; code
                            572 ;--------------------------------------------------------
                            573 	.area CSEG    (CODE)
                            574 ;------------------------------------------------------------
                            575 ;Allocation info for local variables in function 'pvPortMalloc'
                            576 ;------------------------------------------------------------
                            577 ;xWantedSize               Allocated to stack - offset 1
                            578 ;pvReturn                  Allocated to registers r4 r5 r6 
                            579 ;sloc0                     Allocated to stack - offset 3
                            580 ;------------------------------------------------------------
                            581 ;	../../FreeRTOS/Source/portable/MemMang/heap_1.c:86: void *pvPortMalloc( size_t xWantedSize )
                            582 ;	-----------------------------------------
                            583 ;	 function pvPortMalloc
                            584 ;	-----------------------------------------
   368C                     585 _pvPortMalloc:
                    0002    586 	ar2 = 0x02
                    0003    587 	ar3 = 0x03
                    0004    588 	ar4 = 0x04
                    0005    589 	ar5 = 0x05
                    0006    590 	ar6 = 0x06
                    0007    591 	ar7 = 0x07
                    0000    592 	ar0 = 0x00
                    0001    593 	ar1 = 0x01
   368C C0 10               594 	push	_bp
   368E 85 81 10            595 	mov	_bp,sp
                            596 ;     genReceive
   3691 C0 82               597 	push	dpl
   3693 C0 83               598 	push	dph
   3695 05 81               599 	inc	sp
   3697 05 81               600 	inc	sp
                            601 ;	../../FreeRTOS/Source/portable/MemMang/heap_1.c:88: void *pvReturn = NULL; 
                            602 ;	genAssign
   3699 7C 00               603 	mov	r4,#0x00
   369B 7D 00               604 	mov	r5,#0x00
   369D 7E 00               605 	mov	r6,#0x00
                            606 ;	../../FreeRTOS/Source/portable/MemMang/heap_1.c:99: vTaskSuspendAll();
                            607 ;	genCall
   369F C0 04               608 	push	ar4
   36A1 C0 05               609 	push	ar5
   36A3 C0 06               610 	push	ar6
   36A5 12 0E 2C            611 	lcall	_vTaskSuspendAll
   36A8 D0 06               612 	pop	ar6
   36AA D0 05               613 	pop	ar5
   36AC D0 04               614 	pop	ar4
                            615 ;	../../FreeRTOS/Source/portable/MemMang/heap_1.c:102: if( ( ( xNextFreeByte + xWantedSize ) < configTOTAL_HEAP_SIZE ) &&
                            616 ;	genAssign
   36AE 90 F0 83            617 	mov	dptr,#_xNextFreeByte
   36B1 A8 10               618 	mov	r0,_bp
   36B3 08                  619 	inc	r0
   36B4 08                  620 	inc	r0
   36B5 08                  621 	inc	r0
   36B6 E0                  622 	movx	a,@dptr
   36B7 F6                  623 	mov	@r0,a
   36B8 A3                  624 	inc	dptr
   36B9 E0                  625 	movx	a,@dptr
   36BA 08                  626 	inc	r0
   36BB F6                  627 	mov	@r0,a
                            628 ;	genPlus
   36BC A8 10               629 	mov	r0,_bp
   36BE 08                  630 	inc	r0
   36BF 08                  631 	inc	r0
   36C0 08                  632 	inc	r0
   36C1 A9 10               633 	mov	r1,_bp
   36C3 09                  634 	inc	r1
   36C4 E7                  635 	mov	a,@r1
   36C5 26                  636 	add	a,@r0
   36C6 FF                  637 	mov	r7,a
   36C7 09                  638 	inc	r1
   36C8 E7                  639 	mov	a,@r1
   36C9 08                  640 	inc	r0
   36CA 36                  641 	addc	a,@r0
   36CB FA                  642 	mov	r2,a
                            643 ;	genCmpLt
                            644 ;	genCmp
   36CC C3                  645 	clr	c
   36CD EF                  646 	mov	a,r7
   36CE 94 AC               647 	subb	a,#0xAC
   36D0 EA                  648 	mov	a,r2
   36D1 94 0D               649 	subb	a,#0x0D
                            650 ;	genIfxJump
                            651 ;	Peephole 108.a	removed ljmp by inverse jump logic
   36D3 50 45               652 	jnc	00102$
                            653 ;	Peephole 300	removed redundant label 00108$
                            654 ;	../../FreeRTOS/Source/portable/MemMang/heap_1.c:103: ( ( xNextFreeByte + xWantedSize ) > xNextFreeByte )	)/* Check for overflow. */
                            655 ;	genPlus
   36D5 A8 10               656 	mov	r0,_bp
   36D7 08                  657 	inc	r0
   36D8 08                  658 	inc	r0
   36D9 08                  659 	inc	r0
   36DA A9 10               660 	mov	r1,_bp
   36DC 09                  661 	inc	r1
   36DD E7                  662 	mov	a,@r1
   36DE 26                  663 	add	a,@r0
   36DF FA                  664 	mov	r2,a
   36E0 09                  665 	inc	r1
   36E1 E7                  666 	mov	a,@r1
   36E2 08                  667 	inc	r0
   36E3 36                  668 	addc	a,@r0
   36E4 FB                  669 	mov	r3,a
                            670 ;	genCmpGt
   36E5 A8 10               671 	mov	r0,_bp
   36E7 08                  672 	inc	r0
   36E8 08                  673 	inc	r0
   36E9 08                  674 	inc	r0
                            675 ;	genCmp
   36EA C3                  676 	clr	c
   36EB E6                  677 	mov	a,@r0
   36EC 9A                  678 	subb	a,r2
   36ED 08                  679 	inc	r0
   36EE E6                  680 	mov	a,@r0
   36EF 9B                  681 	subb	a,r3
                            682 ;	genIfxJump
                            683 ;	Peephole 108.a	removed ljmp by inverse jump logic
   36F0 50 28               684 	jnc	00102$
                            685 ;	Peephole 300	removed redundant label 00109$
                            686 ;	../../FreeRTOS/Source/portable/MemMang/heap_1.c:107: pvReturn = &( xHeap.ucHeap[ xNextFreeByte ] );
                            687 ;	genPlus
   36F2 A8 10               688 	mov	r0,_bp
   36F4 08                  689 	inc	r0
   36F5 08                  690 	inc	r0
   36F6 08                  691 	inc	r0
   36F7 E6                  692 	mov	a,@r0
   36F8 24 71               693 	add	a,#(_xHeap + 0x0004)
   36FA FA                  694 	mov	r2,a
   36FB 08                  695 	inc	r0
   36FC E6                  696 	mov	a,@r0
   36FD 34 E0               697 	addc	a,#((_xHeap + 0x0004) >> 8)
   36FF FB                  698 	mov	r3,a
                            699 ;	genCast
   3700 8A 04               700 	mov	ar4,r2
   3702 8B 05               701 	mov	ar5,r3
   3704 7E 00               702 	mov	r6,#0x0
                            703 ;	../../FreeRTOS/Source/portable/MemMang/heap_1.c:108: xNextFreeByte += xWantedSize;			
                            704 ;	genPlus
   3706 A8 10               705 	mov	r0,_bp
   3708 08                  706 	inc	r0
   3709 08                  707 	inc	r0
   370A 08                  708 	inc	r0
   370B A9 10               709 	mov	r1,_bp
   370D 09                  710 	inc	r1
   370E 90 F0 83            711 	mov	dptr,#_xNextFreeByte
   3711 E7                  712 	mov	a,@r1
   3712 26                  713 	add	a,@r0
   3713 F0                  714 	movx	@dptr,a
   3714 09                  715 	inc	r1
   3715 E7                  716 	mov	a,@r1
   3716 08                  717 	inc	r0
   3717 36                  718 	addc	a,@r0
   3718 A3                  719 	inc	dptr
   3719 F0                  720 	movx	@dptr,a
   371A                     721 00102$:
                            722 ;	../../FreeRTOS/Source/portable/MemMang/heap_1.c:111: xTaskResumeAll();
                            723 ;	genCall
   371A C0 04               724 	push	ar4
   371C C0 05               725 	push	ar5
   371E C0 06               726 	push	ar6
   3720 12 0E 45            727 	lcall	_xTaskResumeAll
   3723 D0 06               728 	pop	ar6
   3725 D0 05               729 	pop	ar5
   3727 D0 04               730 	pop	ar4
                            731 ;	../../FreeRTOS/Source/portable/MemMang/heap_1.c:113: return pvReturn;
                            732 ;	genRet
   3729 8C 82               733 	mov	dpl,r4
   372B 8D 83               734 	mov	dph,r5
   372D 8E F0               735 	mov	b,r6
                            736 ;	Peephole 300	removed redundant label 00104$
   372F 85 10 81            737 	mov	sp,_bp
   3732 D0 10               738 	pop	_bp
   3734 22                  739 	ret
                            740 ;------------------------------------------------------------
                            741 ;Allocation info for local variables in function 'vPortFree'
                            742 ;------------------------------------------------------------
                            743 ;pv                        Allocated to registers 
                            744 ;------------------------------------------------------------
                            745 ;	../../FreeRTOS/Source/portable/MemMang/heap_1.c:117: void vPortFree( void *pv )
                            746 ;	-----------------------------------------
                            747 ;	 function vPortFree
                            748 ;	-----------------------------------------
   3735                     749 _vPortFree:
                            750 ;	../../FreeRTOS/Source/portable/MemMang/heap_1.c:122: ( void ) pv;
                            751 ;	Peephole 300	removed redundant label 00101$
   3735 22                  752 	ret
                            753 ;------------------------------------------------------------
                            754 ;Allocation info for local variables in function 'vPortInitialiseBlocks'
                            755 ;------------------------------------------------------------
                            756 ;------------------------------------------------------------
                            757 ;	../../FreeRTOS/Source/portable/MemMang/heap_1.c:126: void vPortInitialiseBlocks( void )
                            758 ;	-----------------------------------------
                            759 ;	 function vPortInitialiseBlocks
                            760 ;	-----------------------------------------
   3736                     761 _vPortInitialiseBlocks:
                            762 ;	../../FreeRTOS/Source/portable/MemMang/heap_1.c:129: xNextFreeByte = ( size_t ) 0;
                            763 ;	genAssign
   3736 90 F0 83            764 	mov	dptr,#_xNextFreeByte
   3739 E4                  765 	clr	a
   373A F0                  766 	movx	@dptr,a
   373B A3                  767 	inc	dptr
   373C F0                  768 	movx	@dptr,a
                            769 ;	Peephole 300	removed redundant label 00101$
   373D 22                  770 	ret
                            771 	.area CSEG    (CODE)
                            772 	.area CONST   (CODE)
                            773 	.area XINIT   (CODE)
   E880                     774 __xinit__xNextFreeByte:
   E880 00 00               775 	.byte #0x00,#0x00
