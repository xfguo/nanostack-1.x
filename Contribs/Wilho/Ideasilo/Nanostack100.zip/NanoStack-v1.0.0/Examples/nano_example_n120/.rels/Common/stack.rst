                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Nov 10 2006)
                              4 ; This file generated Fri Feb  1 13:33:38 2008
                              5 ;--------------------------------------------------------
                              6 	.module stack
                              7 	.optsdcc -mmcs51 --model-large
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _IRCON2_P2IF
                             13 	.globl _IRCON2_UTX0IF
                             14 	.globl _IRCON2_UTX1IF
                             15 	.globl _IRCON2_P1IF
                             16 	.globl _IRCON2_WDTIF
                             17 	.globl _CY
                             18 	.globl _AC
                             19 	.globl _F0
                             20 	.globl _RS1
                             21 	.globl _RS0
                             22 	.globl _OV
                             23 	.globl _F1
                             24 	.globl _P
                             25 	.globl _IRCON_DMAIF
                             26 	.globl _IRCON_T1IF
                             27 	.globl _IRCON_T2IF
                             28 	.globl _IRCON_T3IF
                             29 	.globl _IRCON_T4IF
                             30 	.globl _IRCON_P0IF
                             31 	.globl _IRCON_STIF
                             32 	.globl _IEN1_DMAIE
                             33 	.globl _IEN1_T1IE
                             34 	.globl _IEN1_T2IE
                             35 	.globl _IEN1_T3IE
                             36 	.globl _IEN1_T4IE
                             37 	.globl _IEN1_P0IE
                             38 	.globl _IEN0_RFERRIE
                             39 	.globl _IEN0_ADCIE
                             40 	.globl _IEN0_URX0IE
                             41 	.globl _IEN0_URX1IE
                             42 	.globl _IEN0_ENCIE
                             43 	.globl _IEN0_STIE
                             44 	.globl _IEN0_EA
                             45 	.globl _EA
                             46 	.globl _P2_4
                             47 	.globl _P2_3
                             48 	.globl _P2_2
                             49 	.globl _P2_1
                             50 	.globl _P2_0
                             51 	.globl _S0CON_ENCIF_0
                             52 	.globl _S0CON_ENCIF_1
                             53 	.globl _P1_7
                             54 	.globl _P1_6
                             55 	.globl _P1_5
                             56 	.globl _P1_4
                             57 	.globl _P1_3
                             58 	.globl _P1_2
                             59 	.globl _P1_1
                             60 	.globl _P1_0
                             61 	.globl _TCON_IT0
                             62 	.globl _TCON_RFERRIF
                             63 	.globl _TCON_IT1
                             64 	.globl _TCON_URX0IF
                             65 	.globl _TCON_ADCIF
                             66 	.globl _TCON_URX1IF
                             67 	.globl _P0_0
                             68 	.globl _P0_1
                             69 	.globl _P0_2
                             70 	.globl _P0_3
                             71 	.globl _P0_4
                             72 	.globl _P0_5
                             73 	.globl _P0_6
                             74 	.globl _P0_7
                             75 	.globl _P2DIR
                             76 	.globl _P1DIR
                             77 	.globl _P0DIR
                             78 	.globl _U1GCR
                             79 	.globl _U1UCR
                             80 	.globl _U1BAUD
                             81 	.globl _U1BUF
                             82 	.globl _U1CSR
                             83 	.globl _P2INP
                             84 	.globl _P1INP
                             85 	.globl _P2SEL
                             86 	.globl _P1SEL
                             87 	.globl _P0SEL
                             88 	.globl _ADCCFG
                             89 	.globl _PERCFG
                             90 	.globl _B
                             91 	.globl _T4CC1
                             92 	.globl _T4CCTL1
                             93 	.globl _T4CC0
                             94 	.globl _T4CCTL0
                             95 	.globl _T4CTL
                             96 	.globl _T4CNT
                             97 	.globl _RFIF
                             98 	.globl _IRCON2
                             99 	.globl _T1CCTL2
                            100 	.globl _T1CCTL1
                            101 	.globl _T1CCTL0
                            102 	.globl _T1CTL
                            103 	.globl _T1CNTH
                            104 	.globl _T1CNTL
                            105 	.globl _RFST
                            106 	.globl _ACC
                            107 	.globl _T1CC2H
                            108 	.globl _T1CC2L
                            109 	.globl _T1CC1H
                            110 	.globl _T1CC1L
                            111 	.globl _T1CC0H
                            112 	.globl _T1CC0L
                            113 	.globl _RFD
                            114 	.globl _TIMIF
                            115 	.globl _DMAREQ
                            116 	.globl _DMAARM
                            117 	.globl _DMA0CFGH
                            118 	.globl _DMA0CFGL
                            119 	.globl _DMA1CFGH
                            120 	.globl _DMA1CFGL
                            121 	.globl _DMAIRQ
                            122 	.globl _PSW
                            123 	.globl _T3CC1
                            124 	.globl _T3CCTL1
                            125 	.globl _T3CC0
                            126 	.globl _T3CCTL0
                            127 	.globl _T3CTL
                            128 	.globl _T3CNT
                            129 	.globl _WDCTL
                            130 	.globl _T2CON
                            131 	.globl _MEMCTR
                            132 	.globl _CLKCON
                            133 	.globl _U0GCR
                            134 	.globl _U0UCR
                            135 	.globl _T2CNF
                            136 	.globl _U0BAUD
                            137 	.globl _U0BUF
                            138 	.globl _IRCON
                            139 	.globl _SLEEP
                            140 	.globl _RNDH
                            141 	.globl _RNDL
                            142 	.globl _ADCH
                            143 	.globl _ADCL
                            144 	.globl _IP1
                            145 	.globl _IEN1
                            146 	.globl _RCCTL
                            147 	.globl _ADCCON3
                            148 	.globl _ADCCON2
                            149 	.globl _ADCCON1
                            150 	.globl _ENCCS
                            151 	.globl _ENCDO
                            152 	.globl _ENCDI
                            153 	.globl _FWDATA
                            154 	.globl _FCTL
                            155 	.globl _FADDRH
                            156 	.globl _FADDRL
                            157 	.globl _FWT
                            158 	.globl _IP0
                            159 	.globl _IEN0
                            160 	.globl _IE
                            161 	.globl _T2THD
                            162 	.globl _T2TLD
                            163 	.globl _T2CAPHPH
                            164 	.globl _T2CAPLPL
                            165 	.globl _T2OF2
                            166 	.globl _T2OF1
                            167 	.globl _T2OF0
                            168 	.globl _P2
                            169 	.globl _T2PEROF2
                            170 	.globl _T2PEROF1
                            171 	.globl _T2PEROF0
                            172 	.globl _S1CON
                            173 	.globl _IEN2
                            174 	.globl _HSRC
                            175 	.globl _S0CON
                            176 	.globl _ST2
                            177 	.globl _ST1
                            178 	.globl _ST0
                            179 	.globl _T2CMP
                            180 	.globl __XPAGE
                            181 	.globl _DPS
                            182 	.globl _RFIM
                            183 	.globl _P1
                            184 	.globl _P0INP
                            185 	.globl _P1IEN
                            186 	.globl _PICTL
                            187 	.globl _P2IFG
                            188 	.globl _P1IFG
                            189 	.globl _P0IFG
                            190 	.globl _TCON
                            191 	.globl _PCON
                            192 	.globl _U0CSR
                            193 	.globl _DPH1
                            194 	.globl _DPL1
                            195 	.globl _DPH0
                            196 	.globl _DPL0
                            197 	.globl _SP
                            198 	.globl _P0
                            199 	.globl _stacks
                            200 	.globl _events
                            201 	.globl _n_buffers
                            202 	.globl _buffers
                            203 	.globl _RFD_SHADOW
                            204 	.globl _RFSTATUS
                            205 	.globl _CHIPID
                            206 	.globl _CHVER
                            207 	.globl _FSMTC1
                            208 	.globl _RXFIFOCNT
                            209 	.globl _IOCFG3
                            210 	.globl _IOCFG2
                            211 	.globl _IOCFG1
                            212 	.globl _IOCFG0
                            213 	.globl _SHORTADDRL
                            214 	.globl _SHORTADDRH
                            215 	.globl _PANIDL
                            216 	.globl _PANIDH
                            217 	.globl _IEEE_ADDR7
                            218 	.globl _IEEE_ADDR6
                            219 	.globl _IEEE_ADDR5
                            220 	.globl _IEEE_ADDR4
                            221 	.globl _IEEE_ADDR3
                            222 	.globl _IEEE_ADDR2
                            223 	.globl _IEEE_ADDR1
                            224 	.globl _IEEE_ADDR0
                            225 	.globl _DACTSTL
                            226 	.globl _DACTSTH
                            227 	.globl _ADCTSTL
                            228 	.globl _ADCTSTH
                            229 	.globl _FSMSTATE
                            230 	.globl _AGCCTRLL
                            231 	.globl _AGCCTRLH
                            232 	.globl _MANORL
                            233 	.globl _MANORH
                            234 	.globl _MANANDL
                            235 	.globl _MANANDH
                            236 	.globl _FSMTCL
                            237 	.globl _FSMTCH
                            238 	.globl _RFPWR
                            239 	.globl _CSPT
                            240 	.globl _CSPCTRL
                            241 	.globl _CSPZ
                            242 	.globl _CSPY
                            243 	.globl _CSPX
                            244 	.globl _FSCTRLL
                            245 	.globl _FSCTRLH
                            246 	.globl _RXCTRL1L
                            247 	.globl _RXCTRL1H
                            248 	.globl _RXCTRL0L
                            249 	.globl _RXCTRL0H
                            250 	.globl _TXCTRLL
                            251 	.globl _TXCTRLH
                            252 	.globl _SYNCWORDL
                            253 	.globl _SYNCWORDH
                            254 	.globl _RSSIL
                            255 	.globl _RSSIH
                            256 	.globl _MDMCTRL1L
                            257 	.globl _MDMCTRL1H
                            258 	.globl _MDMCTRL0L
                            259 	.globl _MDMCTRL0H
                            260 	.globl _stack_init
                            261 	.globl _stack_start
                            262 	.globl _stack_buffer_get
                            263 	.globl _stack_buffer_free
                            264 	.globl _stack_buffer_push
                            265 	.globl _stack_buffer_headroom
                            266 	.globl _stack_number_get
                            267 	.globl _stack_compare_address
                            268 	.globl _stack_insert_address_to_buffer
                            269 	.globl _stack_check_broadcast
                            270 ;--------------------------------------------------------
                            271 ; special function registers
                            272 ;--------------------------------------------------------
                            273 	.area RSEG    (DATA)
                    0080    274 _P0	=	0x0080
                    0081    275 _SP	=	0x0081
                    0082    276 _DPL0	=	0x0082
                    0083    277 _DPH0	=	0x0083
                    0084    278 _DPL1	=	0x0084
                    0085    279 _DPH1	=	0x0085
                    0086    280 _U0CSR	=	0x0086
                    0087    281 _PCON	=	0x0087
                    0088    282 _TCON	=	0x0088
                    0089    283 _P0IFG	=	0x0089
                    008A    284 _P1IFG	=	0x008a
                    008B    285 _P2IFG	=	0x008b
                    008C    286 _PICTL	=	0x008c
                    008D    287 _P1IEN	=	0x008d
                    008F    288 _P0INP	=	0x008f
                    0090    289 _P1	=	0x0090
                    0091    290 _RFIM	=	0x0091
                    0092    291 _DPS	=	0x0092
                    0093    292 __XPAGE	=	0x0093
                    0094    293 _T2CMP	=	0x0094
                    0095    294 _ST0	=	0x0095
                    0096    295 _ST1	=	0x0096
                    0097    296 _ST2	=	0x0097
                    0098    297 _S0CON	=	0x0098
                    0099    298 _HSRC	=	0x0099
                    009A    299 _IEN2	=	0x009a
                    009B    300 _S1CON	=	0x009b
                    009C    301 _T2PEROF0	=	0x009c
                    009D    302 _T2PEROF1	=	0x009d
                    009E    303 _T2PEROF2	=	0x009e
                    00A0    304 _P2	=	0x00a0
                    00A1    305 _T2OF0	=	0x00a1
                    00A2    306 _T2OF1	=	0x00a2
                    00A3    307 _T2OF2	=	0x00a3
                    00A4    308 _T2CAPLPL	=	0x00a4
                    00A5    309 _T2CAPHPH	=	0x00a5
                    00A6    310 _T2TLD	=	0x00a6
                    00A7    311 _T2THD	=	0x00a7
                    00A8    312 _IE	=	0x00a8
                    00A8    313 _IEN0	=	0x00a8
                    00A9    314 _IP0	=	0x00a9
                    00AB    315 _FWT	=	0x00ab
                    00AC    316 _FADDRL	=	0x00ac
                    00AD    317 _FADDRH	=	0x00ad
                    00AE    318 _FCTL	=	0x00ae
                    00AF    319 _FWDATA	=	0x00af
                    00B1    320 _ENCDI	=	0x00b1
                    00B2    321 _ENCDO	=	0x00b2
                    00B3    322 _ENCCS	=	0x00b3
                    00B4    323 _ADCCON1	=	0x00b4
                    00B5    324 _ADCCON2	=	0x00b5
                    00B6    325 _ADCCON3	=	0x00b6
                    00B7    326 _RCCTL	=	0x00b7
                    00B8    327 _IEN1	=	0x00b8
                    00B9    328 _IP1	=	0x00b9
                    00BA    329 _ADCL	=	0x00ba
                    00BB    330 _ADCH	=	0x00bb
                    00BC    331 _RNDL	=	0x00bc
                    00BD    332 _RNDH	=	0x00bd
                    00BE    333 _SLEEP	=	0x00be
                    00C0    334 _IRCON	=	0x00c0
                    00C1    335 _U0BUF	=	0x00c1
                    00C2    336 _U0BAUD	=	0x00c2
                    00C3    337 _T2CNF	=	0x00c3
                    00C4    338 _U0UCR	=	0x00c4
                    00C5    339 _U0GCR	=	0x00c5
                    00C6    340 _CLKCON	=	0x00c6
                    00C7    341 _MEMCTR	=	0x00c7
                    00C8    342 _T2CON	=	0x00c8
                    00C9    343 _WDCTL	=	0x00c9
                    00CA    344 _T3CNT	=	0x00ca
                    00CB    345 _T3CTL	=	0x00cb
                    00CC    346 _T3CCTL0	=	0x00cc
                    00CD    347 _T3CC0	=	0x00cd
                    00CE    348 _T3CCTL1	=	0x00ce
                    00CF    349 _T3CC1	=	0x00cf
                    00D0    350 _PSW	=	0x00d0
                    00D1    351 _DMAIRQ	=	0x00d1
                    00D2    352 _DMA1CFGL	=	0x00d2
                    00D3    353 _DMA1CFGH	=	0x00d3
                    00D4    354 _DMA0CFGL	=	0x00d4
                    00D5    355 _DMA0CFGH	=	0x00d5
                    00D6    356 _DMAARM	=	0x00d6
                    00D7    357 _DMAREQ	=	0x00d7
                    00D8    358 _TIMIF	=	0x00d8
                    00D9    359 _RFD	=	0x00d9
                    00DA    360 _T1CC0L	=	0x00da
                    00DB    361 _T1CC0H	=	0x00db
                    00DC    362 _T1CC1L	=	0x00dc
                    00DD    363 _T1CC1H	=	0x00dd
                    00DE    364 _T1CC2L	=	0x00de
                    00DF    365 _T1CC2H	=	0x00df
                    00E0    366 _ACC	=	0x00e0
                    00E1    367 _RFST	=	0x00e1
                    00E2    368 _T1CNTL	=	0x00e2
                    00E3    369 _T1CNTH	=	0x00e3
                    00E4    370 _T1CTL	=	0x00e4
                    00E5    371 _T1CCTL0	=	0x00e5
                    00E6    372 _T1CCTL1	=	0x00e6
                    00E7    373 _T1CCTL2	=	0x00e7
                    00E8    374 _IRCON2	=	0x00e8
                    00E9    375 _RFIF	=	0x00e9
                    00EA    376 _T4CNT	=	0x00ea
                    00EB    377 _T4CTL	=	0x00eb
                    00EC    378 _T4CCTL0	=	0x00ec
                    00ED    379 _T4CC0	=	0x00ed
                    00EE    380 _T4CCTL1	=	0x00ee
                    00EF    381 _T4CC1	=	0x00ef
                    00F0    382 _B	=	0x00f0
                    00F1    383 _PERCFG	=	0x00f1
                    00F2    384 _ADCCFG	=	0x00f2
                    00F3    385 _P0SEL	=	0x00f3
                    00F4    386 _P1SEL	=	0x00f4
                    00F5    387 _P2SEL	=	0x00f5
                    00F6    388 _P1INP	=	0x00f6
                    00F7    389 _P2INP	=	0x00f7
                    00F8    390 _U1CSR	=	0x00f8
                    00F9    391 _U1BUF	=	0x00f9
                    00FA    392 _U1BAUD	=	0x00fa
                    00FB    393 _U1UCR	=	0x00fb
                    00FC    394 _U1GCR	=	0x00fc
                    00FD    395 _P0DIR	=	0x00fd
                    00FE    396 _P1DIR	=	0x00fe
                    00FF    397 _P2DIR	=	0x00ff
                            398 ;--------------------------------------------------------
                            399 ; special function bits
                            400 ;--------------------------------------------------------
                            401 	.area RSEG    (DATA)
                    0087    402 _P0_7	=	0x0087
                    0086    403 _P0_6	=	0x0086
                    0085    404 _P0_5	=	0x0085
                    0084    405 _P0_4	=	0x0084
                    0083    406 _P0_3	=	0x0083
                    0082    407 _P0_2	=	0x0082
                    0081    408 _P0_1	=	0x0081
                    0080    409 _P0_0	=	0x0080
                    008F    410 _TCON_URX1IF	=	0x008f
                    008D    411 _TCON_ADCIF	=	0x008d
                    008B    412 _TCON_URX0IF	=	0x008b
                    008A    413 _TCON_IT1	=	0x008a
                    0089    414 _TCON_RFERRIF	=	0x0089
                    0088    415 _TCON_IT0	=	0x0088
                    0090    416 _P1_0	=	0x0090
                    0091    417 _P1_1	=	0x0091
                    0092    418 _P1_2	=	0x0092
                    0093    419 _P1_3	=	0x0093
                    0094    420 _P1_4	=	0x0094
                    0095    421 _P1_5	=	0x0095
                    0096    422 _P1_6	=	0x0096
                    0097    423 _P1_7	=	0x0097
                    0099    424 _S0CON_ENCIF_1	=	0x0099
                    0098    425 _S0CON_ENCIF_0	=	0x0098
                    00A0    426 _P2_0	=	0x00a0
                    00A1    427 _P2_1	=	0x00a1
                    00A2    428 _P2_2	=	0x00a2
                    00A3    429 _P2_3	=	0x00a3
                    00A4    430 _P2_4	=	0x00a4
                    00AF    431 _EA	=	0x00af
                    00AF    432 _IEN0_EA	=	0x00af
                    00AD    433 _IEN0_STIE	=	0x00ad
                    00AC    434 _IEN0_ENCIE	=	0x00ac
                    00AB    435 _IEN0_URX1IE	=	0x00ab
                    00AA    436 _IEN0_URX0IE	=	0x00aa
                    00A9    437 _IEN0_ADCIE	=	0x00a9
                    00A8    438 _IEN0_RFERRIE	=	0x00a8
                    00BD    439 _IEN1_P0IE	=	0x00bd
                    00BC    440 _IEN1_T4IE	=	0x00bc
                    00BB    441 _IEN1_T3IE	=	0x00bb
                    00BA    442 _IEN1_T2IE	=	0x00ba
                    00B9    443 _IEN1_T1IE	=	0x00b9
                    00B8    444 _IEN1_DMAIE	=	0x00b8
                    00C7    445 _IRCON_STIF	=	0x00c7
                    00C5    446 _IRCON_P0IF	=	0x00c5
                    00C4    447 _IRCON_T4IF	=	0x00c4
                    00C3    448 _IRCON_T3IF	=	0x00c3
                    00C2    449 _IRCON_T2IF	=	0x00c2
                    00C1    450 _IRCON_T1IF	=	0x00c1
                    00C0    451 _IRCON_DMAIF	=	0x00c0
                    00D0    452 _P	=	0x00d0
                    00D1    453 _F1	=	0x00d1
                    00D2    454 _OV	=	0x00d2
                    00D3    455 _RS0	=	0x00d3
                    00D4    456 _RS1	=	0x00d4
                    00D5    457 _F0	=	0x00d5
                    00D6    458 _AC	=	0x00d6
                    00D7    459 _CY	=	0x00d7
                    00EC    460 _IRCON2_WDTIF	=	0x00ec
                    00EB    461 _IRCON2_P1IF	=	0x00eb
                    00EA    462 _IRCON2_UTX1IF	=	0x00ea
                    00E9    463 _IRCON2_UTX0IF	=	0x00e9
                    00E8    464 _IRCON2_P2IF	=	0x00e8
                            465 ;--------------------------------------------------------
                            466 ; overlayable register banks
                            467 ;--------------------------------------------------------
                            468 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     469 	.ds 8
                            470 ;--------------------------------------------------------
                            471 ; internal ram data
                            472 ;--------------------------------------------------------
                            473 	.area DSEG    (DATA)
                            474 ;--------------------------------------------------------
                            475 ; overlayable items in internal ram 
                            476 ;--------------------------------------------------------
                            477 	.area OSEG    (OVR,DATA)
                            478 ;--------------------------------------------------------
                            479 ; indirectly addressable internal ram data
                            480 ;--------------------------------------------------------
                            481 	.area ISEG    (DATA)
                            482 ;--------------------------------------------------------
                            483 ; bit data
                            484 ;--------------------------------------------------------
                            485 	.area BSEG    (BIT)
                            486 ;--------------------------------------------------------
                            487 ; paged external ram data
                            488 ;--------------------------------------------------------
                            489 	.area PSEG    (PAG,XDATA)
                            490 ;--------------------------------------------------------
                            491 ; external ram data
                            492 ;--------------------------------------------------------
                            493 	.area XSEG    (XDATA)
                    DF02    494 _MDMCTRL0H	=	0xdf02
                    DF03    495 _MDMCTRL0L	=	0xdf03
                    DF04    496 _MDMCTRL1H	=	0xdf04
                    DF05    497 _MDMCTRL1L	=	0xdf05
                    DF06    498 _RSSIH	=	0xdf06
                    DF07    499 _RSSIL	=	0xdf07
                    DF08    500 _SYNCWORDH	=	0xdf08
                    DF09    501 _SYNCWORDL	=	0xdf09
                    DF0A    502 _TXCTRLH	=	0xdf0a
                    DF0B    503 _TXCTRLL	=	0xdf0b
                    DF0C    504 _RXCTRL0H	=	0xdf0c
                    DF0D    505 _RXCTRL0L	=	0xdf0d
                    DF0E    506 _RXCTRL1H	=	0xdf0e
                    DF0F    507 _RXCTRL1L	=	0xdf0f
                    DF10    508 _FSCTRLH	=	0xdf10
                    DF11    509 _FSCTRLL	=	0xdf11
                    DF12    510 _CSPX	=	0xdf12
                    DF13    511 _CSPY	=	0xdf13
                    DF14    512 _CSPZ	=	0xdf14
                    DF15    513 _CSPCTRL	=	0xdf15
                    DF16    514 _CSPT	=	0xdf16
                    DF17    515 _RFPWR	=	0xdf17
                    DF20    516 _FSMTCH	=	0xdf20
                    DF21    517 _FSMTCL	=	0xdf21
                    DF22    518 _MANANDH	=	0xdf22
                    DF23    519 _MANANDL	=	0xdf23
                    DF24    520 _MANORH	=	0xdf24
                    DF25    521 _MANORL	=	0xdf25
                    DF26    522 _AGCCTRLH	=	0xdf26
                    DF27    523 _AGCCTRLL	=	0xdf27
                    DF39    524 _FSMSTATE	=	0xdf39
                    DF3A    525 _ADCTSTH	=	0xdf3a
                    DF3B    526 _ADCTSTL	=	0xdf3b
                    DF3C    527 _DACTSTH	=	0xdf3c
                    DF3D    528 _DACTSTL	=	0xdf3d
                    DF43    529 _IEEE_ADDR0	=	0xdf43
                    DF44    530 _IEEE_ADDR1	=	0xdf44
                    DF45    531 _IEEE_ADDR2	=	0xdf45
                    DF46    532 _IEEE_ADDR3	=	0xdf46
                    DF47    533 _IEEE_ADDR4	=	0xdf47
                    DF48    534 _IEEE_ADDR5	=	0xdf48
                    DF49    535 _IEEE_ADDR6	=	0xdf49
                    DF4A    536 _IEEE_ADDR7	=	0xdf4a
                    DF4B    537 _PANIDH	=	0xdf4b
                    DF4C    538 _PANIDL	=	0xdf4c
                    DF4D    539 _SHORTADDRH	=	0xdf4d
                    DF4E    540 _SHORTADDRL	=	0xdf4e
                    DF4F    541 _IOCFG0	=	0xdf4f
                    DF50    542 _IOCFG1	=	0xdf50
                    DF51    543 _IOCFG2	=	0xdf51
                    DF52    544 _IOCFG3	=	0xdf52
                    DF53    545 _RXFIFOCNT	=	0xdf53
                    DF54    546 _FSMTC1	=	0xdf54
                    DF60    547 _CHVER	=	0xdf60
                    DF61    548 _CHIPID	=	0xdf61
                    DF62    549 _RFSTATUS	=	0xdf62
                    DFD9    550 _RFD_SHADOW	=	0xdfd9
   EFB8                     551 _buffers::
   EFB8                     552 	.ds 3
   EFBB                     553 _n_buffers::
   EFBB                     554 	.ds 1
                            555 ;--------------------------------------------------------
                            556 ; external initialized ram data
                            557 ;--------------------------------------------------------
                            558 	.area XISEG   (XDATA)
   F0DA                     559 _events::
   F0DA                     560 	.ds 3
   F0DD                     561 _stacks::
   F0DD                     562 	.ds 10
                            563 	.area HOME    (CODE)
                            564 	.area GSINIT0 (CODE)
                            565 	.area GSINIT1 (CODE)
                            566 	.area GSINIT2 (CODE)
                            567 	.area GSINIT3 (CODE)
                            568 	.area GSINIT4 (CODE)
                            569 	.area GSINIT5 (CODE)
                            570 	.area GSINIT  (CODE)
                            571 	.area GSFINAL (CODE)
                            572 	.area CSEG    (CODE)
                            573 ;--------------------------------------------------------
                            574 ; global & static initialisations
                            575 ;--------------------------------------------------------
                            576 	.area HOME    (CODE)
                            577 	.area GSINIT  (CODE)
                            578 	.area GSFINAL (CODE)
                            579 	.area GSINIT  (CODE)
                            580 ;--------------------------------------------------------
                            581 ; Home
                            582 ;--------------------------------------------------------
                            583 	.area HOME    (CODE)
                            584 	.area CSEG    (CODE)
                            585 ;--------------------------------------------------------
                            586 ; code
                            587 ;--------------------------------------------------------
                            588 	.area CSEG    (CODE)
                            589 ;------------------------------------------------------------
                            590 ;Allocation info for local variables in function 'stack_init'
                            591 ;------------------------------------------------------------
                            592 ;i                         Allocated to registers r2 
                            593 ;b                         Allocated to stack - offset 1
                            594 ;init_addr                 Allocated to stack - offset 4
                            595 ;------------------------------------------------------------
                            596 ;	../../Common/stack.c:210: portCHAR stack_init( void )
                            597 ;	-----------------------------------------
                            598 ;	 function stack_init
                            599 ;	-----------------------------------------
   553C                     600 _stack_init:
                    0002    601 	ar2 = 0x02
                    0003    602 	ar3 = 0x03
                    0004    603 	ar4 = 0x04
                    0005    604 	ar5 = 0x05
                    0006    605 	ar6 = 0x06
                    0007    606 	ar7 = 0x07
                    0000    607 	ar0 = 0x00
                    0001    608 	ar1 = 0x01
   553C C0 10               609 	push	_bp
                            610 ;	peephole 177.h	optimized mov sequence
   553E E5 81               611 	mov	a,sp
   5540 F5 10               612 	mov	_bp,a
   5542 24 10               613 	add	a,#0x10
   5544 F5 81               614 	mov	sp,a
                            615 ;	../../Common/stack.c:215: buffers = xQueueCreate( STACK_BUFFERS_MAX, sizeof( buffer_t * ) );
                            616 ;	genIpush
   5546 74 03               617 	mov	a,#0x03
   5548 C0 E0               618 	push	acc
                            619 ;	genCall
   554A 75 82 08            620 	mov	dpl,#0x08
   554D 12 1B 2D            621 	lcall	_xQueueCreate
   5550 AA 82               622 	mov	r2,dpl
   5552 AB 83               623 	mov	r3,dph
   5554 AC F0               624 	mov	r4,b
   5556 15 81               625 	dec	sp
                            626 ;	genAssign
   5558 90 EF B8            627 	mov	dptr,#_buffers
   555B EA                  628 	mov	a,r2
   555C F0                  629 	movx	@dptr,a
   555D A3                  630 	inc	dptr
   555E EB                  631 	mov	a,r3
   555F F0                  632 	movx	@dptr,a
   5560 A3                  633 	inc	dptr
   5561 EC                  634 	mov	a,r4
   5562 F0                  635 	movx	@dptr,a
                            636 ;	../../Common/stack.c:216: events = xQueueCreate( STACK_BUFFERS_MAX + 8, sizeof( event_t ) );
                            637 ;	genIpush
   5563 74 05               638 	mov	a,#0x05
   5565 C0 E0               639 	push	acc
                            640 ;	genCall
   5567 75 82 10            641 	mov	dpl,#0x10
   556A 12 1B 2D            642 	lcall	_xQueueCreate
   556D AA 82               643 	mov	r2,dpl
   556F AB 83               644 	mov	r3,dph
   5571 AC F0               645 	mov	r4,b
   5573 15 81               646 	dec	sp
                            647 ;	genAssign
   5575 90 F0 DA            648 	mov	dptr,#_events
   5578 EA                  649 	mov	a,r2
   5579 F0                  650 	movx	@dptr,a
   557A A3                  651 	inc	dptr
   557B EB                  652 	mov	a,r3
   557C F0                  653 	movx	@dptr,a
   557D A3                  654 	inc	dptr
   557E EC                  655 	mov	a,r4
   557F F0                  656 	movx	@dptr,a
                            657 ;	../../Common/stack.c:217: n_buffers = 0;
                            658 ;	genAssign
   5580 90 EF BB            659 	mov	dptr,#_n_buffers
                            660 ;	Peephole 181	changed mov to clr
   5583 E4                  661 	clr	a
   5584 F0                  662 	movx	@dptr,a
                            663 ;	../../Common/stack.c:219: xTaskCreate( stack_main, "Stack", configMAXIMUM_STACK_SIZE, NULL, STACK_PRIORITY, ( xTaskHandle * )NULL );
                            664 ;	genIpush
                            665 ;	Peephole 181	changed mov to clr
   5585 E4                  666 	clr	a
   5586 C0 E0               667 	push	acc
   5588 C0 E0               668 	push	acc
   558A C0 E0               669 	push	acc
                            670 ;	genIpush
   558C 74 02               671 	mov	a,#0x02
   558E C0 E0               672 	push	acc
                            673 ;	genIpush
                            674 ;	Peephole 181	changed mov to clr
   5590 E4                  675 	clr	a
   5591 C0 E0               676 	push	acc
   5593 C0 E0               677 	push	acc
   5595 C0 E0               678 	push	acc
                            679 ;	genIpush
   5597 74 DC               680 	mov	a,#0xDC
   5599 C0 E0               681 	push	acc
                            682 ;	Peephole 181	changed mov to clr
   559B E4                  683 	clr	a
   559C C0 E0               684 	push	acc
                            685 ;	genIpush
   559E 74 B5               686 	mov	a,#__str_0
   55A0 C0 E0               687 	push	acc
   55A2 74 E7               688 	mov	a,#(__str_0 >> 8)
   55A4 C0 E0               689 	push	acc
   55A6 74 80               690 	mov	a,#0x80
   55A8 C0 E0               691 	push	acc
                            692 ;	genCall
                            693 ;	Peephole 182.a	used 16 bit load of DPTR
   55AA 90 57 00            694 	mov	dptr,#_stack_main
   55AD 12 07 F1            695 	lcall	_xTaskCreate
   55B0 E5 81               696 	mov	a,sp
   55B2 24 F4               697 	add	a,#0xf4
   55B4 F5 81               698 	mov	sp,a
                            699 ;	../../Common/stack.c:226: i = 0;
                            700 ;	genAssign
   55B6 7A 00               701 	mov	r2,#0x00
                            702 ;	../../Common/stack.c:227: while (i < STACK_BUFFERS_MAX)
   55B8                     703 00108$:
                            704 ;	genCmpLt
                            705 ;	genCmp
   55B8 BA 08 00            706 	cjne	r2,#0x08,00118$
   55BB                     707 00118$:
                            708 ;	genIfxJump
   55BB 40 03               709 	jc	00119$
   55BD 02 56 8D            710 	ljmp	00110$
   55C0                     711 00119$:
                            712 ;	../../Common/stack.c:229: b = pvPortMalloc(sizeof(buffer_t)+BUFFER_SIZE);
                            713 ;	genCall
                            714 ;	Peephole 182.b	used 16 bit load of dptr
   55C0 90 00 AE            715 	mov	dptr,#0x00AE
   55C3 C0 02               716 	push	ar2
   55C5 12 36 8C            717 	lcall	_pvPortMalloc
   55C8 AB 82               718 	mov	r3,dpl
   55CA AC 83               719 	mov	r4,dph
   55CC AD F0               720 	mov	r5,b
   55CE D0 02               721 	pop	ar2
                            722 ;	genAssign
   55D0 A8 10               723 	mov	r0,_bp
   55D2 08                  724 	inc	r0
   55D3 A6 03               725 	mov	@r0,ar3
   55D5 08                  726 	inc	r0
   55D6 A6 04               727 	mov	@r0,ar4
   55D8 08                  728 	inc	r0
   55D9 A6 05               729 	mov	@r0,ar5
                            730 ;	../../Common/stack.c:230: if (b)
                            731 ;	genIfx
   55DB EB                  732 	mov	a,r3
   55DC 4C                  733 	orl	a,r4
   55DD 4D                  734 	orl	a,r5
                            735 ;	genIfxJump
   55DE 70 03               736 	jnz	00120$
   55E0 02 56 78            737 	ljmp	00104$
   55E3                     738 00120$:
                            739 ;	../../Common/stack.c:232: memset(b, 0, sizeof(buffer_t));
                            740 ;	genIpush
   55E3 C0 02               741 	push	ar2
                            742 ;	genAssign
   55E5 A8 10               743 	mov	r0,_bp
   55E7 08                  744 	inc	r0
   55E8 A6 03               745 	mov	@r0,ar3
   55EA 08                  746 	inc	r0
   55EB A6 04               747 	mov	@r0,ar4
   55ED 08                  748 	inc	r0
   55EE A6 05               749 	mov	@r0,ar5
                            750 ;	genIpush
   55F0 C0 02               751 	push	ar2
   55F2 C0 03               752 	push	ar3
   55F4 C0 04               753 	push	ar4
   55F6 C0 05               754 	push	ar5
   55F8 74 2E               755 	mov	a,#0x2E
   55FA C0 E0               756 	push	acc
                            757 ;	Peephole 181	changed mov to clr
   55FC E4                  758 	clr	a
   55FD C0 E0               759 	push	acc
                            760 ;	genIpush
                            761 ;	Peephole 181	changed mov to clr
   55FF E4                  762 	clr	a
   5600 C0 E0               763 	push	acc
                            764 ;	genCall
   5602 A8 10               765 	mov	r0,_bp
   5604 08                  766 	inc	r0
   5605 86 82               767 	mov	dpl,@r0
   5607 08                  768 	inc	r0
   5608 86 83               769 	mov	dph,@r0
   560A 08                  770 	inc	r0
   560B 86 F0               771 	mov	b,@r0
   560D 12 E3 65            772 	lcall	_memset
   5610 15 81               773 	dec	sp
   5612 15 81               774 	dec	sp
   5614 15 81               775 	dec	sp
   5616 D0 05               776 	pop	ar5
   5618 D0 04               777 	pop	ar4
   561A D0 03               778 	pop	ar3
   561C D0 02               779 	pop	ar2
                            780 ;	../../Common/stack.c:233: b->size = BUFFER_SIZE;
                            781 ;	genPlus
                            782 ;     genPlusIncr
   561E 74 24               783 	mov	a,#0x24
                            784 ;	Peephole 236.a	used r3 instead of ar3
   5620 2B                  785 	add	a,r3
   5621 FB                  786 	mov	r3,a
                            787 ;	Peephole 181	changed mov to clr
   5622 E4                  788 	clr	a
                            789 ;	Peephole 236.b	used r4 instead of ar4
   5623 3C                  790 	addc	a,r4
   5624 FC                  791 	mov	r4,a
                            792 ;	genPointerSet
                            793 ;	genGenPointerSet
   5625 8B 82               794 	mov	dpl,r3
   5627 8C 83               795 	mov	dph,r4
   5629 8D F0               796 	mov	b,r5
   562B 74 80               797 	mov	a,#0x80
   562D 12 DF B7            798 	lcall	__gptrput
   5630 A3                  799 	inc	dptr
                            800 ;	Peephole 181	changed mov to clr
   5631 E4                  801 	clr	a
   5632 12 DF B7            802 	lcall	__gptrput
                            803 ;	../../Common/stack.c:234: n_buffers++;
                            804 ;	genAssign
   5635 90 EF BB            805 	mov	dptr,#_n_buffers
   5638 E0                  806 	movx	a,@dptr
   5639 FB                  807 	mov	r3,a
                            808 ;	genPlus
   563A 90 EF BB            809 	mov	dptr,#_n_buffers
                            810 ;     genPlusIncr
   563D 74 01               811 	mov	a,#0x01
                            812 ;	Peephole 236.a	used r3 instead of ar3
   563F 2B                  813 	add	a,r3
   5640 F0                  814 	movx	@dptr,a
                            815 ;	../../Common/stack.c:235: if (xQueueSend( buffers, ( void * ) &b,
                            816 ;	genAddrOf
                            817 ;	Peephole 212	reduced add sequence to inc
   5641 AB 10               818 	mov	r3,_bp
   5643 0B                  819 	inc	r3
                            820 ;	genCast
   5644 7C 00               821 	mov	r4,#0x00
   5646 7D 40               822 	mov	r5,#0x40
                            823 ;	genAssign
   5648 90 EF B8            824 	mov	dptr,#_buffers
   564B E0                  825 	movx	a,@dptr
   564C FE                  826 	mov	r6,a
   564D A3                  827 	inc	dptr
   564E E0                  828 	movx	a,@dptr
   564F FF                  829 	mov	r7,a
   5650 A3                  830 	inc	dptr
   5651 E0                  831 	movx	a,@dptr
   5652 FA                  832 	mov	r2,a
                            833 ;	genIpush
                            834 ;	Peephole 181	changed mov to clr
   5653 E4                  835 	clr	a
   5654 C0 E0               836 	push	acc
   5656 C0 E0               837 	push	acc
                            838 ;	genIpush
   5658 C0 03               839 	push	ar3
   565A C0 04               840 	push	ar4
   565C C0 05               841 	push	ar5
                            842 ;	genCall
   565E 8E 82               843 	mov	dpl,r6
   5660 8F 83               844 	mov	dph,r7
   5662 8A F0               845 	mov	b,r2
   5664 12 1D 8E            846 	lcall	_xQueueSend
   5667 AA 82               847 	mov	r2,dpl
   5669 E5 81               848 	mov	a,sp
   566B 24 FB               849 	add	a,#0xfb
   566D F5 81               850 	mov	sp,a
                            851 ;	genIfx
   566F EA                  852 	mov	a,r2
                            853 ;	genIpop
   5670 D0 02               854 	pop	ar2
                            855 ;	genIfxJump
                            856 ;	Peephole 108.b	removed ljmp by inverse jump logic
                            857 ;	../../Common/stack.c:241: return pdFALSE;
                            858 ;	genRet
   5672 70 09               859 	jnz	00105$
                            860 ;	Peephole 300	removed redundant label 00121$
                            861 ;	Peephole 256.c	loading dpl with zero from a
   5674 F5 82               862 	mov	dpl,a
                            863 ;	Peephole 112.b	changed ljmp to sjmp
   5676 80 36               864 	sjmp	00111$
   5678                     865 00104$:
                            866 ;	../../Common/stack.c:249: return pdFALSE;
                            867 ;	genRet
   5678 75 82 00            868 	mov	dpl,#0x00
                            869 ;	Peephole 112.b	changed ljmp to sjmp
   567B 80 31               870 	sjmp	00111$
   567D                     871 00105$:
                            872 ;	../../Common/stack.c:251: if (i++ >= STACK_BUFFERS_MIN) i = STACK_BUFFERS_MAX;
                            873 ;	genAssign
   567D 8A 03               874 	mov	ar3,r2
                            875 ;	genPlus
                            876 ;     genPlusIncr
   567F 0A                  877 	inc	r2
                            878 ;	genCmpLt
                            879 ;	genCmp
   5680 BB 04 00            880 	cjne	r3,#0x04,00122$
   5683                     881 00122$:
                            882 ;	genIfxJump
   5683 50 03               883 	jnc	00123$
   5685 02 55 B8            884 	ljmp	00108$
   5688                     885 00123$:
                            886 ;	genAssign
   5688 7A 08               887 	mov	r2,#0x08
   568A 02 55 B8            888 	ljmp	00108$
   568D                     889 00110$:
                            890 ;	../../Common/stack.c:258: socket_init();
                            891 ;	genCall
   568D 12 44 41            892 	lcall	_socket_init
                            893 ;	../../Common/stack.c:261: init_addr.addr_type = ADDR_NONE;
                            894 ;	genAddrOf
   5690 E5 10               895 	mov	a,_bp
   5692 24 04               896 	add	a,#0x04
                            897 ;	genPointerSet
                            898 ;	genNearPointerSet
                            899 ;	Peephole 239	used a instead of acc
   5694 F8                  900 	mov	r0,a
   5695 76 00               901 	mov	@r0,#0x00
                            902 ;	../../Common/stack.c:262: rf_mac_get(&init_addr);
                            903 ;	genAddrOf
   5697 E5 10               904 	mov	a,_bp
   5699 24 04               905 	add	a,#0x04
   569B FA                  906 	mov	r2,a
                            907 ;	genCast
   569C 7B 00               908 	mov	r3,#0x00
   569E 7C 40               909 	mov	r4,#0x40
                            910 ;	genCall
   56A0 8A 82               911 	mov	dpl,r2
   56A2 8B 83               912 	mov	dph,r3
   56A4 8C F0               913 	mov	b,r4
   56A6 12 A8 51            914 	lcall	_rf_mac_get
                            915 ;	../../Common/stack.c:264: return module_init();
                            916 ;	genCall
   56A9 12 42 E0            917 	lcall	_module_init
                            918 ;	genRet
   56AC AA 82               919 	mov  r2,dpl
                            920 ;	Peephole 177.a	removed redundant mov
   56AE                     921 00111$:
   56AE 85 10 81            922 	mov	sp,_bp
   56B1 D0 10               923 	pop	_bp
   56B3 22                  924 	ret
                            925 ;------------------------------------------------------------
                            926 ;Allocation info for local variables in function 'stack_start'
                            927 ;------------------------------------------------------------
                            928 ;stack_parameters          Allocated to registers r2 r3 r4 
                            929 ;buffer                    Allocated to registers 
                            930 ;msg                       Allocated to stack - offset 7
                            931 ;------------------------------------------------------------
                            932 ;	../../Common/stack.c:276: start_status_t stack_start(stack_init_t  *stack_parameters)
                            933 ;	-----------------------------------------
                            934 ;	 function stack_start
                            935 ;	-----------------------------------------
   56B4                     936 _stack_start:
                            937 ;	genReceive
   56B4 AA 82               938 	mov	r2,dpl
   56B6 AB 83               939 	mov	r3,dph
   56B8 AC F0               940 	mov	r4,b
                            941 ;	../../Common/stack.c:282: mac_set_mac_pib_parameter(stack_parameters->mac_address, MAC_IEEE_ADDRESS);
                            942 ;	genPlus
                            943 ;     genPlusIncr
   56BA 74 06               944 	mov	a,#0x06
                            945 ;	Peephole 236.a	used r2 instead of ar2
   56BC 2A                  946 	add	a,r2
   56BD FD                  947 	mov	r5,a
                            948 ;	Peephole 181	changed mov to clr
   56BE E4                  949 	clr	a
                            950 ;	Peephole 236.b	used r3 instead of ar3
   56BF 3B                  951 	addc	a,r3
   56C0 FE                  952 	mov	r6,a
   56C1 8C 07               953 	mov	ar7,r4
                            954 ;	genIpush
   56C3 C0 02               955 	push	ar2
   56C5 C0 03               956 	push	ar3
   56C7 C0 04               957 	push	ar4
   56C9 74 01               958 	mov	a,#0x01
   56CB C0 E0               959 	push	acc
                            960 ;	genCall
   56CD 8D 82               961 	mov	dpl,r5
   56CF 8E 83               962 	mov	dph,r6
   56D1 8F F0               963 	mov	b,r7
   56D3 12 98 A2            964 	lcall	_mac_set_mac_pib_parameter
   56D6 15 81               965 	dec	sp
   56D8 D0 04               966 	pop	ar4
   56DA D0 03               967 	pop	ar3
   56DC D0 02               968 	pop	ar2
                            969 ;	../../Common/stack.c:284: switch(stack_parameters->type)
                            970 ;	genPointerGet
                            971 ;	genGenPointerGet
   56DE 8A 82               972 	mov	dpl,r2
   56E0 8B 83               973 	mov	dph,r3
   56E2 8C F0               974 	mov	b,r4
   56E4 12 E4 9F            975 	lcall	__gptrget
                            976 ;	genCmpEq
                            977 ;	gencjneshort
   56E7 FA                  978 	mov	r2,a
                            979 ;	Peephole 115.b	jump optimization
   56E8 60 02               980 	jz	00108$
                            981 ;	Peephole 300	removed redundant label 00107$
                            982 ;	Peephole 112.b	changed ljmp to sjmp
   56EA 80 10               983 	sjmp	00102$
   56EC                     984 00108$:
                            985 ;	../../Common/stack.c:289: mac_handle_address_decoder(RF_DECODER_ON);
                            986 ;	genCall
   56EC 75 82 02            987 	mov	dpl,#0x02
   56EF 12 99 48            988 	lcall	_mac_handle_address_decoder
                            989 ;	../../Common/stack.c:290: rf_802_15_4_ip_layer_address_mode_set(0);
                            990 ;	genCall
   56F2 75 82 00            991 	mov	dpl,#0x00
   56F5 12 96 A6            992 	lcall	_rf_802_15_4_ip_layer_address_mode_set
                            993 ;	../../Common/stack.c:294: return START_SUCCESS;
                            994 ;	genRet
   56F8 75 82 00            995 	mov	dpl,#0x00
                            996 ;	../../Common/stack.c:296: default:
                            997 ;	Peephole 112.b	changed ljmp to sjmp
                            998 ;	../../Common/stack.c:297: return TYPE_NOT_SUPPORTED;
                            999 ;	genRet
                           1000 ;	../../Common/stack.c:389: return START_SUCCESS;
                           1001 ;	Peephole 237.a	removed sjmp to ret
   56FB 22                 1002 	ret
   56FC                    1003 00102$:
   56FC 75 82 01           1004 	mov	dpl,#0x01
                           1005 ;	Peephole 300	removed redundant label 00104$
   56FF 22                 1006 	ret
                           1007 ;------------------------------------------------------------
                           1008 ;Allocation info for local variables in function 'stack_main'
                           1009 ;------------------------------------------------------------
                           1010 ;pvParameters              Allocated to registers 
                           1011 ;event                     Allocated to stack - offset 1
                           1012 ;xLastWakeTime             Allocated to stack - offset 6
                           1013 ;------------------------------------------------------------
                           1014 ;	../../Common/stack.c:401: void stack_main ( void *pvParameters )
                           1015 ;	-----------------------------------------
                           1016 ;	 function stack_main
                           1017 ;	-----------------------------------------
   5700                    1018 _stack_main:
   5700 C0 10              1019 	push	_bp
                           1020 ;	peephole 177.h	optimized mov sequence
   5702 E5 81              1021 	mov	a,sp
   5704 F5 10              1022 	mov	_bp,a
   5706 24 07              1023 	add	a,#0x07
   5708 F5 81              1024 	mov	sp,a
                           1025 ;	../../Common/stack.c:408: xLastWakeTime = xTaskGetTickCount();
                           1026 ;	genCall
   570A 12 10 33           1027 	lcall	_xTaskGetTickCount
   570D AA 82              1028 	mov	r2,dpl
   570F AB 83              1029 	mov	r3,dph
                           1030 ;	genAssign
   5711 E5 10              1031 	mov	a,_bp
   5713 24 06              1032 	add	a,#0x06
   5715 F8                 1033 	mov	r0,a
   5716 A6 02              1034 	mov	@r0,ar2
   5718 08                 1035 	inc	r0
   5719 A6 03              1036 	mov	@r0,ar3
                           1037 ;	../../Common/stack.c:410: vTaskDelayUntil( &xLastWakeTime, 200 / portTICK_RATE_MS );
                           1038 ;	genAddrOf
   571B E5 10              1039 	mov	a,_bp
   571D 24 06              1040 	add	a,#0x06
   571F FA                 1041 	mov	r2,a
                           1042 ;	genCast
   5720 7B 00              1043 	mov	r3,#0x00
   5722 7C 40              1044 	mov	r4,#0x40
                           1045 ;	genIpush
   5724 74 C8              1046 	mov	a,#0xC8
   5726 C0 E0              1047 	push	acc
                           1048 ;	Peephole 181	changed mov to clr
   5728 E4                 1049 	clr	a
   5729 C0 E0              1050 	push	acc
                           1051 ;	genCall
   572B 8A 82              1052 	mov	dpl,r2
   572D 8B 83              1053 	mov	dph,r3
   572F 8C F0              1054 	mov	b,r4
   5731 12 0B 80           1055 	lcall	_vTaskDelayUntil
   5734 15 81              1056 	dec	sp
   5736 15 81              1057 	dec	sp
                           1058 ;	../../Common/stack.c:412: if ( ( buffers == 0 ) || (events == 0) )
                           1059 ;	genAssign
   5738 90 EF B8           1060 	mov	dptr,#_buffers
   573B E0                 1061 	movx	a,@dptr
   573C FA                 1062 	mov	r2,a
   573D A3                 1063 	inc	dptr
   573E E0                 1064 	movx	a,@dptr
   573F FB                 1065 	mov	r3,a
   5740 A3                 1066 	inc	dptr
   5741 E0                 1067 	movx	a,@dptr
   5742 FC                 1068 	mov	r4,a
                           1069 ;	genIfx
   5743 EA                 1070 	mov	a,r2
   5744 4B                 1071 	orl	a,r3
   5745 4C                 1072 	orl	a,r4
                           1073 ;	genIfxJump
                           1074 ;	Peephole 108.c	removed ljmp by inverse jump logic
   5746 60 10              1075 	jz	00110$
                           1076 ;	Peephole 300	removed redundant label 00122$
                           1077 ;	genAssign
   5748 90 F0 DA           1078 	mov	dptr,#_events
   574B E0                 1079 	movx	a,@dptr
   574C FA                 1080 	mov	r2,a
   574D A3                 1081 	inc	dptr
   574E E0                 1082 	movx	a,@dptr
   574F FB                 1083 	mov	r3,a
   5750 A3                 1084 	inc	dptr
   5751 E0                 1085 	movx	a,@dptr
   5752 FC                 1086 	mov	r4,a
                           1087 ;	genIfx
   5753 EA                 1088 	mov	a,r2
   5754 4B                 1089 	orl	a,r3
   5755 4C                 1090 	orl	a,r4
                           1091 ;	genIfxJump
                           1092 ;	Peephole 108.b	removed ljmp by inverse jump logic
   5756 70 20              1093 	jnz	00113$
                           1094 ;	Peephole 300	removed redundant label 00123$
   5758                    1095 00110$:
                           1096 ;	../../Common/stack.c:419: vTaskDelayUntil( &xLastWakeTime, 5000 / portTICK_RATE_MS );
                           1097 ;	genAddrOf
   5758 E5 10              1098 	mov	a,_bp
   575A 24 06              1099 	add	a,#0x06
   575C FA                 1100 	mov	r2,a
                           1101 ;	genCast
   575D 7B 00              1102 	mov	r3,#0x00
   575F 7C 40              1103 	mov	r4,#0x40
                           1104 ;	genIpush
   5761 74 88              1105 	mov	a,#0x88
   5763 C0 E0              1106 	push	acc
   5765 74 13              1107 	mov	a,#0x13
   5767 C0 E0              1108 	push	acc
                           1109 ;	genCall
   5769 8A 82              1110 	mov	dpl,r2
   576B 8B 83              1111 	mov	dph,r3
   576D 8C F0              1112 	mov	b,r4
   576F 12 0B 80           1113 	lcall	_vTaskDelayUntil
   5772 15 81              1114 	dec	sp
   5774 15 81              1115 	dec	sp
                           1116 ;	Peephole 112.b	changed ljmp to sjmp
   5776 80 E0              1117 	sjmp	00110$
   5778                    1118 00113$:
                           1119 ;	../../Common/stack.c:436: if (xQueueReceive(events, &( event ), 5000 / portTICK_RATE_MS) == pdTRUE)
                           1120 ;	genAddrOf
                           1121 ;	Peephole 212	reduced add sequence to inc
   5778 AA 10              1122 	mov	r2,_bp
   577A 0A                 1123 	inc	r2
                           1124 ;	genCast
   577B 7B 00              1125 	mov	r3,#0x00
   577D 7C 40              1126 	mov	r4,#0x40
                           1127 ;	genAssign
   577F 90 F0 DA           1128 	mov	dptr,#_events
   5782 E0                 1129 	movx	a,@dptr
   5783 FD                 1130 	mov	r5,a
   5784 A3                 1131 	inc	dptr
   5785 E0                 1132 	movx	a,@dptr
   5786 FE                 1133 	mov	r6,a
   5787 A3                 1134 	inc	dptr
   5788 E0                 1135 	movx	a,@dptr
   5789 FF                 1136 	mov	r7,a
                           1137 ;	genIpush
   578A 74 88              1138 	mov	a,#0x88
   578C C0 E0              1139 	push	acc
   578E 74 13              1140 	mov	a,#0x13
   5790 C0 E0              1141 	push	acc
                           1142 ;	genIpush
   5792 C0 02              1143 	push	ar2
   5794 C0 03              1144 	push	ar3
   5796 C0 04              1145 	push	ar4
                           1146 ;	genCall
   5798 8D 82              1147 	mov	dpl,r5
   579A 8E 83              1148 	mov	dph,r6
   579C 8F F0              1149 	mov	b,r7
   579E 12 23 5A           1150 	lcall	_xQueueReceive
   57A1 AA 82              1151 	mov	r2,dpl
   57A3 E5 81              1152 	mov	a,sp
   57A5 24 FB              1153 	add	a,#0xfb
   57A7 F5 81              1154 	mov	sp,a
                           1155 ;	genCmpEq
                           1156 ;	gencjneshort
                           1157 ;	Peephole 112.b	changed ljmp to sjmp
                           1158 ;	Peephole 198.b	optimized misc jump sequence
   57A9 BA 01 CC           1159 	cjne	r2,#0x01,00113$
                           1160 ;	Peephole 200.b	removed redundant sjmp
                           1161 ;	Peephole 300	removed redundant label 00124$
                           1162 ;	Peephole 300	removed redundant label 00125$
                           1163 ;	../../Common/stack.c:438: if (event.process == 0)
                           1164 ;	genAddrOf
                           1165 ;	Peephole 212	reduced add sequence to inc
   57AC A8 10              1166 	mov	r0,_bp
   57AE 08                 1167 	inc	r0
                           1168 ;	genPointerGet
                           1169 ;	genNearPointerGet
   57AF 86 02              1170 	mov	ar2,@r0
   57B1 08                 1171 	inc	r0
   57B2 86 03              1172 	mov	ar3,@r0
   57B4 18                 1173 	dec	r0
                           1174 ;	genIfx
   57B5 EA                 1175 	mov	a,r2
   57B6 4B                 1176 	orl	a,r3
                           1177 ;	genIfxJump
                           1178 ;	Peephole 108.b	removed ljmp by inverse jump logic
   57B7 70 1C              1179 	jnz	00105$
                           1180 ;	Peephole 300	removed redundant label 00126$
                           1181 ;	../../Common/stack.c:440: stack_buffer((buffer_t *) event.param);
                           1182 ;	genAddrOf
   57B9 E5 10              1183 	mov	a,_bp
   57BB 24 01              1184 	add	a,#0x01
                           1185 ;	genPlus
                           1186 ;     genPlusIncr
   57BD 24 02              1187 	add	a,#0x02
   57BF F8                 1188 	mov	r0,a
                           1189 ;	genPointerGet
                           1190 ;	genNearPointerGet
   57C0 86 04              1191 	mov	ar4,@r0
   57C2 08                 1192 	inc	r0
   57C3 86 05              1193 	mov	ar5,@r0
   57C5 08                 1194 	inc	r0
   57C6 86 06              1195 	mov	ar6,@r0
   57C8 18                 1196 	dec	r0
   57C9 18                 1197 	dec	r0
                           1198 ;	genCall
   57CA 8C 82              1199 	mov	dpl,r4
   57CC 8D 83              1200 	mov	dph,r5
   57CE 8E F0              1201 	mov	b,r6
   57D0 12 58 0A           1202 	lcall	_stack_buffer
                           1203 ;	Peephole 112.b	changed ljmp to sjmp
   57D3 80 A3              1204 	sjmp	00113$
   57D5                    1205 00105$:
                           1206 ;	../../Common/stack.c:444: event.process(event.param);
                           1207 ;	genAssign
                           1208 ;	genAddrOf
   57D5 E5 10              1209 	mov	a,_bp
   57D7 24 01              1210 	add	a,#0x01
                           1211 ;	genPlus
                           1212 ;     genPlusIncr
   57D9 24 02              1213 	add	a,#0x02
   57DB F8                 1214 	mov	r0,a
                           1215 ;	genPointerGet
                           1216 ;	genNearPointerGet
   57DC 86 04              1217 	mov	ar4,@r0
   57DE 08                 1218 	inc	r0
   57DF 86 05              1219 	mov	ar5,@r0
   57E1 08                 1220 	inc	r0
   57E2 86 06              1221 	mov	ar6,@r0
   57E4 18                 1222 	dec	r0
   57E5 18                 1223 	dec	r0
                           1224 ;	genPcall
   57E6 C0 02              1225 	push	ar2
   57E8 C0 03              1226 	push	ar3
   57EA 74 FD              1227 	mov	a,#00127$
   57EC C0 E0              1228 	push	acc
   57EE 74 57              1229 	mov	a,#(00127$ >> 8)
   57F0 C0 E0              1230 	push	acc
   57F2 C0 02              1231 	push	ar2
   57F4 C0 03              1232 	push	ar3
   57F6 8C 82              1233 	mov	dpl,r4
   57F8 8D 83              1234 	mov	dph,r5
   57FA 8E F0              1235 	mov	b,r6
   57FC 22                 1236 	ret
   57FD                    1237 00127$:
   57FD D0 03              1238 	pop	ar3
   57FF D0 02              1239 	pop	ar2
   5801 02 57 78           1240 	ljmp	00113$
                           1241 ;	Peephole 300	removed redundant label 00115$
   5804 85 10 81           1242 	mov	sp,_bp
   5807 D0 10              1243 	pop	_bp
   5809 22                 1244 	ret
                           1245 ;------------------------------------------------------------
                           1246 ;Allocation info for local variables in function 'stack_buffer'
                           1247 ;------------------------------------------------------------
                           1248 ;b                         Allocated to stack - offset 1
                           1249 ;status                    Allocated to registers r2 
                           1250 ;i                         Allocated to stack - offset 4
                           1251 ;found                     Allocated to registers 
                           1252 ;si                        Allocated to stack - offset 5
                           1253 ;j                         Allocated to stack - offset 8
                           1254 ;next_layer                Allocated to stack - offset 9
                           1255 ;j                         Allocated to registers r5 
                           1256 ;sloc0                     Allocated to stack - offset 13
                           1257 ;sloc1                     Allocated to stack - offset 10
                           1258 ;sloc2                     Allocated to stack - offset 13
                           1259 ;------------------------------------------------------------
                           1260 ;	../../Common/stack.c:463: void stack_buffer(buffer_t *b)
                           1261 ;	-----------------------------------------
                           1262 ;	 function stack_buffer
                           1263 ;	-----------------------------------------
   580A                    1264 _stack_buffer:
   580A C0 10              1265 	push	_bp
   580C 85 81 10           1266 	mov	_bp,sp
                           1267 ;     genReceive
   580F C0 82              1268 	push	dpl
   5811 C0 83              1269 	push	dph
   5813 C0 F0              1270 	push	b
   5815 E5 81              1271 	mov	a,sp
   5817 24 0E              1272 	add	a,#0x0e
   5819 F5 81              1273 	mov	sp,a
                           1274 ;	../../Common/stack.c:468: socket_t *si = (socket_t *) b->socket;
                           1275 ;	genPointerGet
                           1276 ;	genGenPointerGet
   581B A8 10              1277 	mov	r0,_bp
   581D 08                 1278 	inc	r0
   581E 86 82              1279 	mov	dpl,@r0
   5820 08                 1280 	inc	r0
   5821 86 83              1281 	mov	dph,@r0
   5823 08                 1282 	inc	r0
   5824 86 F0              1283 	mov	b,@r0
   5826 12 E4 9F           1284 	lcall	__gptrget
   5829 FD                 1285 	mov	r5,a
   582A A3                 1286 	inc	dptr
   582B 12 E4 9F           1287 	lcall	__gptrget
   582E FE                 1288 	mov	r6,a
   582F A3                 1289 	inc	dptr
   5830 12 E4 9F           1290 	lcall	__gptrget
   5833 FF                 1291 	mov	r7,a
                           1292 ;	genAssign
   5834 E5 10              1293 	mov	a,_bp
   5836 24 05              1294 	add	a,#0x05
   5838 F8                 1295 	mov	r0,a
   5839 A6 05              1296 	mov	@r0,ar5
   583B 08                 1297 	inc	r0
   583C A6 06              1298 	mov	@r0,ar6
   583E 08                 1299 	inc	r0
   583F A6 07              1300 	mov	@r0,ar7
                           1301 ;	../../Common/stack.c:470: if (b == 0) return;
                           1302 ;	genIfx
   5841 A8 10              1303 	mov	r0,_bp
   5843 08                 1304 	inc	r0
   5844 E6                 1305 	mov	a,@r0
   5845 08                 1306 	inc	r0
   5846 46                 1307 	orl	a,@r0
   5847 08                 1308 	inc	r0
   5848 46                 1309 	orl	a,@r0
                           1310 ;	genIfxJump
                           1311 ;	Peephole 108.b	removed ljmp by inverse jump logic
   5849 70 03              1312 	jnz	00102$
                           1313 ;	Peephole 300	removed redundant label 00230$
                           1314 ;	genRet
   584B 02 5E 79           1315 	ljmp	00184$
   584E                    1316 00102$:
                           1317 ;	../../Common/stack.c:472: if ( ((si != 0) && (si->stack_id == STACKS_MAX)) || (b->options.type == BUFFER_CONTROL) )
                           1318 ;	genCmpEq
   584E E5 10              1319 	mov	a,_bp
   5850 24 05              1320 	add	a,#0x05
   5852 F8                 1321 	mov	r0,a
                           1322 ;	gencjneshort
   5853 B6 00 0A           1323 	cjne	@r0,#0x00,00231$
   5856 08                 1324 	inc	r0
   5857 B6 00 06           1325 	cjne	@r0,#0x00,00231$
   585A 08                 1326 	inc	r0
   585B B6 00 02           1327 	cjne	@r0,#0x00,00231$
                           1328 ;	Peephole 112.b	changed ljmp to sjmp
   585E 80 21              1329 	sjmp	00127$
   5860                    1330 00231$:
                           1331 ;	genIpush
                           1332 ;	genPlus
   5860 E5 10              1333 	mov	a,_bp
   5862 24 05              1334 	add	a,#0x05
   5864 F8                 1335 	mov	r0,a
                           1336 ;     genPlusIncr
   5865 74 01              1337 	mov	a,#0x01
   5867 26                 1338 	add	a,@r0
   5868 FA                 1339 	mov	r2,a
                           1340 ;	Peephole 181	changed mov to clr
   5869 E4                 1341 	clr	a
   586A 08                 1342 	inc	r0
   586B 36                 1343 	addc	a,@r0
   586C FB                 1344 	mov	r3,a
   586D 08                 1345 	inc	r0
   586E 86 04              1346 	mov	ar4,@r0
                           1347 ;	genPointerGet
                           1348 ;	genGenPointerGet
   5870 8A 82              1349 	mov	dpl,r2
   5872 8B 83              1350 	mov	dph,r3
   5874 8C F0              1351 	mov	b,r4
   5876 12 E4 9F           1352 	lcall	__gptrget
   5879 FA                 1353 	mov	r2,a
                           1354 ;	genCmpEq
                           1355 ;	gencjne
                           1356 ;	gencjneshort
                           1357 ;	Peephole 241.d	optimized compare
   587A E4                 1358 	clr	a
   587B BA 02 01           1359 	cjne	r2,#0x02,00232$
   587E 04                 1360 	inc	a
   587F                    1361 00232$:
                           1362 ;	Peephole 300	removed redundant label 00233$
                           1363 ;	genIpop
                           1364 ;	genIfx
                           1365 ;	genIfxJump
                           1366 ;	Peephole 108.b	removed ljmp by inverse jump logic
   587F 70 22              1367 	jnz	00124$
                           1368 ;	Peephole 300	removed redundant label 00234$
   5881                    1369 00127$:
                           1370 ;	genIpush
                           1371 ;	genPlus
   5881 A8 10              1372 	mov	r0,_bp
   5883 08                 1373 	inc	r0
                           1374 ;     genPlusIncr
   5884 74 26              1375 	mov	a,#0x26
   5886 26                 1376 	add	a,@r0
   5887 FD                 1377 	mov	r5,a
                           1378 ;	Peephole 181	changed mov to clr
   5888 E4                 1379 	clr	a
   5889 08                 1380 	inc	r0
   588A 36                 1381 	addc	a,@r0
   588B FE                 1382 	mov	r6,a
   588C 08                 1383 	inc	r0
   588D 86 07              1384 	mov	ar7,@r0
                           1385 ;	genPointerGet
                           1386 ;	genGenPointerGet
   588F 8D 82              1387 	mov	dpl,r5
   5891 8E 83              1388 	mov	dph,r6
   5893 8F F0              1389 	mov	b,r7
   5895 12 E4 9F           1390 	lcall	__gptrget
   5898 FD                 1391 	mov	r5,a
                           1392 ;	genCmpEq
                           1393 ;	gencjne
                           1394 ;	gencjneshort
                           1395 ;	Peephole 241.d	optimized compare
   5899 E4                 1396 	clr	a
   589A BD 01 01           1397 	cjne	r5,#0x01,00235$
   589D 04                 1398 	inc	a
   589E                    1399 00235$:
                           1400 ;	Peephole 300	removed redundant label 00236$
                           1401 ;	genIpop
                           1402 ;	genIfx
                           1403 ;	genIfxJump
   589E 70 03              1404 	jnz	00237$
   58A0 02 59 E9           1405 	ljmp	00125$
   58A3                    1406 00237$:
   58A3                    1407 00124$:
                           1408 ;	../../Common/stack.c:477: if ((b->to == MODULE_NONE) || (b->to == MODULE_APP))
                           1409 ;	genPlus
   58A3 A8 10              1410 	mov	r0,_bp
   58A5 08                 1411 	inc	r0
                           1412 ;     genPlusIncr
   58A6 74 1E              1413 	mov	a,#0x1E
   58A8 26                 1414 	add	a,@r0
   58A9 FD                 1415 	mov	r5,a
                           1416 ;	Peephole 181	changed mov to clr
   58AA E4                 1417 	clr	a
   58AB 08                 1418 	inc	r0
   58AC 36                 1419 	addc	a,@r0
   58AD FE                 1420 	mov	r6,a
   58AE 08                 1421 	inc	r0
   58AF 86 07              1422 	mov	ar7,@r0
                           1423 ;	genPointerGet
                           1424 ;	genGenPointerGet
   58B1 8D 82              1425 	mov	dpl,r5
   58B3 8E 83              1426 	mov	dph,r6
   58B5 8F F0              1427 	mov	b,r7
   58B7 12 E4 9F           1428 	lcall	__gptrget
                           1429 ;	genIfx
   58BA FA                 1430 	mov	r2,a
                           1431 ;	Peephole 105	removed redundant mov
                           1432 ;	genIfxJump
                           1433 ;	Peephole 108.c	removed ljmp by inverse jump logic
   58BB 60 08              1434 	jz	00117$
                           1435 ;	Peephole 300	removed redundant label 00238$
                           1436 ;	genCmpEq
                           1437 ;	gencjneshort
   58BD BA 0B 02           1438 	cjne	r2,#0x0B,00239$
   58C0 80 03              1439 	sjmp	00240$
   58C2                    1440 00239$:
   58C2 02 59 98           1441 	ljmp	00118$
   58C5                    1442 00240$:
   58C5                    1443 00117$:
                           1444 ;	../../Common/stack.c:479: switch(b->dir)
                           1445 ;	genIpush
   58C5 C0 05              1446 	push	ar5
   58C7 C0 06              1447 	push	ar6
   58C9 C0 07              1448 	push	ar7
                           1449 ;	genPlus
   58CB A8 10              1450 	mov	r0,_bp
   58CD 08                 1451 	inc	r0
                           1452 ;     genPlusIncr
   58CE 74 1F              1453 	mov	a,#0x1F
   58D0 26                 1454 	add	a,@r0
   58D1 FD                 1455 	mov	r5,a
                           1456 ;	Peephole 181	changed mov to clr
   58D2 E4                 1457 	clr	a
   58D3 08                 1458 	inc	r0
   58D4 36                 1459 	addc	a,@r0
   58D5 FE                 1460 	mov	r6,a
   58D6 08                 1461 	inc	r0
   58D7 86 07              1462 	mov	ar7,@r0
                           1463 ;	genPointerGet
                           1464 ;	genGenPointerGet
   58D9 8D 82              1465 	mov	dpl,r5
   58DB 8E 83              1466 	mov	dph,r6
   58DD 8F F0              1467 	mov	b,r7
   58DF 12 E4 9F           1468 	lcall	__gptrget
   58E2 FA                 1469 	mov	r2,a
                           1470 ;	genCmpEq
                           1471 ;	gencjne
                           1472 ;	gencjneshort
                           1473 ;	Peephole 241.d	optimized compare
   58E3 E4                 1474 	clr	a
   58E4 BA 00 01           1475 	cjne	r2,#0x00,00241$
   58E7 04                 1476 	inc	a
   58E8                    1477 00241$:
                           1478 ;	Peephole 300	removed redundant label 00242$
                           1479 ;	genIpop
   58E8 D0 07              1480 	pop	ar7
   58EA D0 06              1481 	pop	ar6
   58EC D0 05              1482 	pop	ar5
                           1483 ;	genIfx
                           1484 ;	genIfxJump
                           1485 ;	Peephole 108.b	removed ljmp by inverse jump logic
   58EE 70 49              1486 	jnz	00107$
                           1487 ;	Peephole 300	removed redundant label 00243$
                           1488 ;	genCmpEq
                           1489 ;	gencjneshort
   58F0 BA 01 02           1490 	cjne	r2,#0x01,00244$
   58F3 80 03              1491 	sjmp	00245$
   58F5                    1492 00244$:
   58F5 02 59 98           1493 	ljmp	00118$
   58F8                    1494 00245$:
                           1495 ;	../../Common/stack.c:485: if (si) b->to = si->protocol;
                           1496 ;	genIfx
   58F8 E5 10              1497 	mov	a,_bp
   58FA 24 05              1498 	add	a,#0x05
   58FC F8                 1499 	mov	r0,a
   58FD E6                 1500 	mov	a,@r0
   58FE 08                 1501 	inc	r0
   58FF 46                 1502 	orl	a,@r0
   5900 08                 1503 	inc	r0
   5901 46                 1504 	orl	a,@r0
                           1505 ;	genIfxJump
                           1506 ;	Peephole 108.c	removed ljmp by inverse jump logic
   5902 60 1C              1507 	jz	00105$
                           1508 ;	Peephole 300	removed redundant label 00246$
                           1509 ;	genIpush
                           1510 ;	genPointerGet
                           1511 ;	genGenPointerGet
   5904 E5 10              1512 	mov	a,_bp
   5906 24 05              1513 	add	a,#0x05
   5908 F8                 1514 	mov	r0,a
   5909 86 82              1515 	mov	dpl,@r0
   590B 08                 1516 	inc	r0
   590C 86 83              1517 	mov	dph,@r0
   590E 08                 1518 	inc	r0
   590F 86 F0              1519 	mov	b,@r0
   5911 12 E4 9F           1520 	lcall	__gptrget
                           1521 ;	genPointerSet
                           1522 ;	genGenPointerSet
   5914 FA                 1523 	mov	r2,a
   5915 8D 82              1524 	mov	dpl,r5
   5917 8E 83              1525 	mov	dph,r6
   5919 8F F0              1526 	mov	b,r7
                           1527 ;	Peephole 191	removed redundant mov
   591B 12 DF B7           1528 	lcall	__gptrput
                           1529 ;	genIpop
                           1530 ;	Peephole 112.b	changed ljmp to sjmp
   591E 80 78              1531 	sjmp	00118$
   5920                    1532 00105$:
                           1533 ;	../../Common/stack.c:488: stack_buffer_free(b);
                           1534 ;	genCall
   5920 A8 10              1535 	mov	r0,_bp
   5922 08                 1536 	inc	r0
   5923 86 82              1537 	mov	dpl,@r0
   5925 08                 1538 	inc	r0
   5926 86 83              1539 	mov	dph,@r0
   5928 08                 1540 	inc	r0
   5929 86 F0              1541 	mov	b,@r0
   592B 12 61 FA           1542 	lcall	_stack_buffer_free
                           1543 ;	../../Common/stack.c:489: b = 0;
                           1544 ;	genAssign
   592E A8 10              1545 	mov	r0,_bp
   5930 08                 1546 	inc	r0
   5931 E4                 1547 	clr	a
   5932 F6                 1548 	mov	@r0,a
   5933 08                 1549 	inc	r0
   5934 F6                 1550 	mov	@r0,a
   5935 08                 1551 	inc	r0
   5936 F6                 1552 	mov	@r0,a
                           1553 ;	../../Common/stack.c:491: break;
                           1554 ;	../../Common/stack.c:493: case BUFFER_UP:
                           1555 ;	Peephole 112.b	changed ljmp to sjmp
   5937 80 5F              1556 	sjmp	00118$
   5939                    1557 00107$:
                           1558 ;	../../Common/stack.c:494: if ((si))
                           1559 ;	genIfx
   5939 E5 10              1560 	mov	a,_bp
   593B 24 05              1561 	add	a,#0x05
   593D F8                 1562 	mov	r0,a
   593E E6                 1563 	mov	a,@r0
   593F 08                 1564 	inc	r0
   5940 46                 1565 	orl	a,@r0
   5941 08                 1566 	inc	r0
   5942 46                 1567 	orl	a,@r0
                           1568 ;	genIfxJump
                           1569 ;	Peephole 108.c	removed ljmp by inverse jump logic
   5943 60 1E              1570 	jz	00114$
                           1571 ;	Peephole 300	removed redundant label 00247$
                           1572 ;	../../Common/stack.c:496: if(socket_up(b) == pdTRUE)
                           1573 ;	genCall
   5945 A8 10              1574 	mov	r0,_bp
   5947 08                 1575 	inc	r0
   5948 86 82              1576 	mov	dpl,@r0
   594A 08                 1577 	inc	r0
   594B 86 83              1578 	mov	dph,@r0
   594D 08                 1579 	inc	r0
   594E 86 F0              1580 	mov	b,@r0
   5950 12 54 15           1581 	lcall	_socket_up
   5953 AD 82              1582 	mov	r5,dpl
                           1583 ;	genCmpEq
                           1584 ;	gencjneshort
                           1585 ;	Peephole 112.b	changed ljmp to sjmp
                           1586 ;	Peephole 198.b	optimized misc jump sequence
   5955 BD 01 40           1587 	cjne	r5,#0x01,00118$
                           1588 ;	Peephole 200.b	removed redundant sjmp
                           1589 ;	Peephole 300	removed redundant label 00248$
                           1590 ;	Peephole 300	removed redundant label 00249$
                           1591 ;	../../Common/stack.c:501: b = 0;
                           1592 ;	genAssign
   5958 A8 10              1593 	mov	r0,_bp
   595A 08                 1594 	inc	r0
   595B E4                 1595 	clr	a
   595C F6                 1596 	mov	@r0,a
   595D 08                 1597 	inc	r0
   595E F6                 1598 	mov	@r0,a
   595F 08                 1599 	inc	r0
   5960 F6                 1600 	mov	@r0,a
                           1601 ;	Peephole 112.b	changed ljmp to sjmp
   5961 80 35              1602 	sjmp	00118$
   5963                    1603 00114$:
                           1604 ;	../../Common/stack.c:506: if(socket_up(b) == pdTRUE)
                           1605 ;	genCall
   5963 A8 10              1606 	mov	r0,_bp
   5965 08                 1607 	inc	r0
   5966 86 82              1608 	mov	dpl,@r0
   5968 08                 1609 	inc	r0
   5969 86 83              1610 	mov	dph,@r0
   596B 08                 1611 	inc	r0
   596C 86 F0              1612 	mov	b,@r0
   596E 12 54 15           1613 	lcall	_socket_up
   5971 AD 82              1614 	mov	r5,dpl
                           1615 ;	genCmpEq
                           1616 ;	gencjneshort
                           1617 ;	Peephole 112.b	changed ljmp to sjmp
                           1618 ;	Peephole 198.b	optimized misc jump sequence
   5973 BD 01 0B           1619 	cjne	r5,#0x01,00111$
                           1620 ;	Peephole 200.b	removed redundant sjmp
                           1621 ;	Peephole 300	removed redundant label 00250$
                           1622 ;	Peephole 300	removed redundant label 00251$
                           1623 ;	../../Common/stack.c:511: b = 0;
                           1624 ;	genAssign
   5976 A8 10              1625 	mov	r0,_bp
   5978 08                 1626 	inc	r0
   5979 E4                 1627 	clr	a
   597A F6                 1628 	mov	@r0,a
   597B 08                 1629 	inc	r0
   597C F6                 1630 	mov	@r0,a
   597D 08                 1631 	inc	r0
   597E F6                 1632 	mov	@r0,a
                           1633 ;	Peephole 112.b	changed ljmp to sjmp
   597F 80 17              1634 	sjmp	00118$
   5981                    1635 00111$:
                           1636 ;	../../Common/stack.c:515: stack_buffer_free(b);
                           1637 ;	genCall
   5981 A8 10              1638 	mov	r0,_bp
   5983 08                 1639 	inc	r0
   5984 86 82              1640 	mov	dpl,@r0
   5986 08                 1641 	inc	r0
   5987 86 83              1642 	mov	dph,@r0
   5989 08                 1643 	inc	r0
   598A 86 F0              1644 	mov	b,@r0
   598C 12 61 FA           1645 	lcall	_stack_buffer_free
                           1646 ;	../../Common/stack.c:516: b = 0;
                           1647 ;	genAssign
   598F A8 10              1648 	mov	r0,_bp
   5991 08                 1649 	inc	r0
   5992 E4                 1650 	clr	a
   5993 F6                 1651 	mov	@r0,a
   5994 08                 1652 	inc	r0
   5995 F6                 1653 	mov	@r0,a
   5996 08                 1654 	inc	r0
   5997 F6                 1655 	mov	@r0,a
                           1656 ;	../../Common/stack.c:520: }
   5998                    1657 00118$:
                           1658 ;	../../Common/stack.c:522: if (b)
                           1659 ;	genIfx
   5998 A8 10              1660 	mov	r0,_bp
   599A 08                 1661 	inc	r0
   599B E6                 1662 	mov	a,@r0
   599C 08                 1663 	inc	r0
   599D 46                 1664 	orl	a,@r0
   599E 08                 1665 	inc	r0
   599F 46                 1666 	orl	a,@r0
                           1667 ;	genIfxJump
                           1668 ;	Peephole 108.c	removed ljmp by inverse jump logic
   59A0 60 44              1669 	jz	00123$
                           1670 ;	Peephole 300	removed redundant label 00252$
                           1671 ;	../../Common/stack.c:525: if (module_call(b->to, b) == pdFALSE)
                           1672 ;	genPlus
   59A2 A8 10              1673 	mov	r0,_bp
   59A4 08                 1674 	inc	r0
                           1675 ;     genPlusIncr
   59A5 74 1E              1676 	mov	a,#0x1E
   59A7 26                 1677 	add	a,@r0
   59A8 FD                 1678 	mov	r5,a
                           1679 ;	Peephole 181	changed mov to clr
   59A9 E4                 1680 	clr	a
   59AA 08                 1681 	inc	r0
   59AB 36                 1682 	addc	a,@r0
   59AC FE                 1683 	mov	r6,a
   59AD 08                 1684 	inc	r0
   59AE 86 07              1685 	mov	ar7,@r0
                           1686 ;	genPointerGet
                           1687 ;	genGenPointerGet
   59B0 8D 82              1688 	mov	dpl,r5
   59B2 8E 83              1689 	mov	dph,r6
   59B4 8F F0              1690 	mov	b,r7
   59B6 12 E4 9F           1691 	lcall	__gptrget
   59B9 FD                 1692 	mov	r5,a
                           1693 ;	genIpush
   59BA A8 10              1694 	mov	r0,_bp
   59BC 08                 1695 	inc	r0
   59BD E6                 1696 	mov	a,@r0
   59BE C0 E0              1697 	push	acc
   59C0 08                 1698 	inc	r0
   59C1 E6                 1699 	mov	a,@r0
   59C2 C0 E0              1700 	push	acc
   59C4 08                 1701 	inc	r0
   59C5 E6                 1702 	mov	a,@r0
   59C6 C0 E0              1703 	push	acc
                           1704 ;	genCall
   59C8 8D 82              1705 	mov	dpl,r5
   59CA 12 43 80           1706 	lcall	_module_call
   59CD AD 82              1707 	mov	r5,dpl
   59CF 15 81              1708 	dec	sp
   59D1 15 81              1709 	dec	sp
   59D3 15 81              1710 	dec	sp
                           1711 ;	genIfx
   59D5 ED                 1712 	mov	a,r5
                           1713 ;	genIfxJump
                           1714 ;	Peephole 108.b	removed ljmp by inverse jump logic
   59D6 70 0E              1715 	jnz	00123$
                           1716 ;	Peephole 300	removed redundant label 00253$
                           1717 ;	../../Common/stack.c:530: stack_buffer_free(b);               					 
                           1718 ;	genCall
   59D8 A8 10              1719 	mov	r0,_bp
   59DA 08                 1720 	inc	r0
   59DB 86 82              1721 	mov	dpl,@r0
   59DD 08                 1722 	inc	r0
   59DE 86 83              1723 	mov	dph,@r0
   59E0 08                 1724 	inc	r0
   59E1 86 F0              1725 	mov	b,@r0
   59E3 12 61 FA           1726 	lcall	_stack_buffer_free
   59E6                    1727 00123$:
                           1728 ;	../../Common/stack.c:533: return;
                           1729 ;	genRet
   59E6 02 5E 79           1730 	ljmp	00184$
   59E9                    1731 00125$:
                           1732 ;	../../Common/stack.c:536: if ((b->to != MODULE_NONE) && (b->to != MODULE_APP))
                           1733 ;	genPlus
   59E9 A8 10              1734 	mov	r0,_bp
   59EB 08                 1735 	inc	r0
                           1736 ;     genPlusIncr
   59EC 74 1E              1737 	mov	a,#0x1E
   59EE 26                 1738 	add	a,@r0
   59EF FD                 1739 	mov	r5,a
                           1740 ;	Peephole 181	changed mov to clr
   59F0 E4                 1741 	clr	a
   59F1 08                 1742 	inc	r0
   59F2 36                 1743 	addc	a,@r0
   59F3 FE                 1744 	mov	r6,a
   59F4 08                 1745 	inc	r0
   59F5 86 07              1746 	mov	ar7,@r0
                           1747 ;	genPointerGet
                           1748 ;	genGenPointerGet
   59F7 8D 82              1749 	mov	dpl,r5
   59F9 8E 83              1750 	mov	dph,r6
   59FB 8F F0              1751 	mov	b,r7
   59FD 12 E4 9F           1752 	lcall	__gptrget
                           1753 ;	genCmpEq
                           1754 ;	gencjneshort
                           1755 ;	Peephole 112.b	changed ljmp to sjmp
   5A00 FD                 1756 	mov	r5,a
                           1757 ;	Peephole 115.b	jump optimization
   5A01 60 37              1758 	jz	00181$
                           1759 ;	Peephole 300	removed redundant label 00254$
                           1760 ;	genCmpEq
                           1761 ;	gencjneshort
   5A03 BD 0B 02           1762 	cjne	r5,#0x0B,00255$
                           1763 ;	Peephole 112.b	changed ljmp to sjmp
   5A06 80 32              1764 	sjmp	00181$
   5A08                    1765 00255$:
                           1766 ;	../../Common/stack.c:541: if (module_call(b->to, b) == pdFALSE)
                           1767 ;	genIpush
   5A08 A8 10              1768 	mov	r0,_bp
   5A0A 08                 1769 	inc	r0
   5A0B E6                 1770 	mov	a,@r0
   5A0C C0 E0              1771 	push	acc
   5A0E 08                 1772 	inc	r0
   5A0F E6                 1773 	mov	a,@r0
   5A10 C0 E0              1774 	push	acc
   5A12 08                 1775 	inc	r0
   5A13 E6                 1776 	mov	a,@r0
   5A14 C0 E0              1777 	push	acc
                           1778 ;	genCall
   5A16 8D 82              1779 	mov	dpl,r5
   5A18 12 43 80           1780 	lcall	_module_call
   5A1B AD 82              1781 	mov	r5,dpl
   5A1D 15 81              1782 	dec	sp
   5A1F 15 81              1783 	dec	sp
   5A21 15 81              1784 	dec	sp
                           1785 ;	genIfx
   5A23 ED                 1786 	mov	a,r5
                           1787 ;	genIfxJump
   5A24 60 03              1788 	jz	00256$
   5A26 02 5E 79           1789 	ljmp	00184$
   5A29                    1790 00256$:
                           1791 ;	../../Common/stack.c:546: stack_buffer_free(b);               					 
                           1792 ;	genCall
   5A29 A8 10              1793 	mov	r0,_bp
   5A2B 08                 1794 	inc	r0
   5A2C 86 82              1795 	mov	dpl,@r0
   5A2E 08                 1796 	inc	r0
   5A2F 86 83              1797 	mov	dph,@r0
   5A31 08                 1798 	inc	r0
   5A32 86 F0              1799 	mov	b,@r0
   5A34 12 61 FA           1800 	lcall	_stack_buffer_free
   5A37 02 5E 79           1801 	ljmp	00184$
   5A3A                    1802 00181$:
                           1803 ;	../../Common/stack.c:549: else if (b->dir == BUFFER_DOWN)
                           1804 ;	genPlus
   5A3A A8 10              1805 	mov	r0,_bp
   5A3C 08                 1806 	inc	r0
                           1807 ;     genPlusIncr
   5A3D 74 1F              1808 	mov	a,#0x1F
   5A3F 26                 1809 	add	a,@r0
   5A40 FD                 1810 	mov	r5,a
                           1811 ;	Peephole 181	changed mov to clr
   5A41 E4                 1812 	clr	a
   5A42 08                 1813 	inc	r0
   5A43 36                 1814 	addc	a,@r0
   5A44 FE                 1815 	mov	r6,a
   5A45 08                 1816 	inc	r0
   5A46 86 07              1817 	mov	ar7,@r0
                           1818 ;	genPointerGet
                           1819 ;	genGenPointerGet
   5A48 8D 82              1820 	mov	dpl,r5
   5A4A 8E 83              1821 	mov	dph,r6
   5A4C 8F F0              1822 	mov	b,r7
   5A4E 12 E4 9F           1823 	lcall	__gptrget
   5A51 FD                 1824 	mov	r5,a
                           1825 ;	genCmpEq
                           1826 ;	gencjneshort
   5A52 BD 01 02           1827 	cjne	r5,#0x01,00257$
   5A55 80 03              1828 	sjmp	00258$
   5A57                    1829 00257$:
   5A57 02 5C FA           1830 	ljmp	00178$
   5A5A                    1831 00258$:
                           1832 ;	../../Common/stack.c:554: if (si)
                           1833 ;	genIfx
   5A5A E5 10              1834 	mov	a,_bp
   5A5C 24 05              1835 	add	a,#0x05
   5A5E F8                 1836 	mov	r0,a
   5A5F E6                 1837 	mov	a,@r0
   5A60 08                 1838 	inc	r0
   5A61 46                 1839 	orl	a,@r0
   5A62 08                 1840 	inc	r0
   5A63 46                 1841 	orl	a,@r0
                           1842 ;	genIfxJump
   5A64 70 03              1843 	jnz	00259$
   5A66 02 5B E5           1844 	ljmp	00214$
   5A69                    1845 00259$:
                           1846 ;	../../Common/stack.c:559: if ((b->from == MODULE_APP) || (b->from == MODULE_NRP))
                           1847 ;	genPlus
   5A69 A8 10              1848 	mov	r0,_bp
   5A6B 08                 1849 	inc	r0
                           1850 ;     genPlusIncr
   5A6C 74 1D              1851 	mov	a,#0x1D
   5A6E 26                 1852 	add	a,@r0
   5A6F FD                 1853 	mov	r5,a
                           1854 ;	Peephole 181	changed mov to clr
   5A70 E4                 1855 	clr	a
   5A71 08                 1856 	inc	r0
   5A72 36                 1857 	addc	a,@r0
   5A73 FE                 1858 	mov	r6,a
   5A74 08                 1859 	inc	r0
   5A75 86 07              1860 	mov	ar7,@r0
                           1861 ;	genPointerGet
                           1862 ;	genGenPointerGet
   5A77 8D 82              1863 	mov	dpl,r5
   5A79 8E 83              1864 	mov	dph,r6
   5A7B 8F F0              1865 	mov	b,r7
   5A7D 12 E4 9F           1866 	lcall	__gptrget
   5A80 FA                 1867 	mov	r2,a
                           1868 ;	genCmpEq
                           1869 ;	gencjneshort
   5A81 BA 0B 02           1870 	cjne	r2,#0x0B,00260$
                           1871 ;	Peephole 112.b	changed ljmp to sjmp
   5A84 80 03              1872 	sjmp	00136$
   5A86                    1873 00260$:
                           1874 ;	genCmpEq
                           1875 ;	gencjneshort
                           1876 ;	Peephole 112.b	changed ljmp to sjmp
                           1877 ;	Peephole 198.b	optimized misc jump sequence
   5A86 BA 05 5A           1878 	cjne	r2,#0x05,00206$
                           1879 ;	Peephole 200.b	removed redundant sjmp
                           1880 ;	Peephole 300	removed redundant label 00261$
                           1881 ;	Peephole 300	removed redundant label 00262$
   5A89                    1882 00136$:
                           1883 ;	../../Common/stack.c:561: b->from = stacks[si->stack_id].layers;
                           1884 ;	genPlus
   5A89 E5 10              1885 	mov	a,_bp
   5A8B 24 05              1886 	add	a,#0x05
   5A8D F8                 1887 	mov	r0,a
                           1888 ;     genPlusIncr
   5A8E 74 01              1889 	mov	a,#0x01
   5A90 26                 1890 	add	a,@r0
   5A91 FA                 1891 	mov	r2,a
                           1892 ;	Peephole 181	changed mov to clr
   5A92 E4                 1893 	clr	a
   5A93 08                 1894 	inc	r0
   5A94 36                 1895 	addc	a,@r0
   5A95 FB                 1896 	mov	r3,a
   5A96 08                 1897 	inc	r0
   5A97 86 04              1898 	mov	ar4,@r0
                           1899 ;	genPointerGet
                           1900 ;	genGenPointerGet
   5A99 8A 82              1901 	mov	dpl,r2
   5A9B 8B 83              1902 	mov	dph,r3
   5A9D 8C F0              1903 	mov	b,r4
   5A9F 12 E4 9F           1904 	lcall	__gptrget
                           1905 ;	genMult
                           1906 ;	genMultOneByte
   5AA2 FA                 1907 	mov	r2,a
                           1908 ;	Peephole 105	removed redundant mov
   5AA3 75 F0 05           1909 	mov	b,#0x05
   5AA6 A4                 1910 	mul	ab
                           1911 ;	genPlus
   5AA7 24 DD              1912 	add	a,#_stacks
   5AA9 F5 82              1913 	mov	dpl,a
                           1914 ;	Peephole 240	use clr instead of addc a,#0
   5AAB E4                 1915 	clr	a
   5AAC 34 F0              1916 	addc	a,#(_stacks >> 8)
   5AAE F5 83              1917 	mov	dph,a
                           1918 ;	genPointerGet
                           1919 ;	genFarPointerGet
   5AB0 E0                 1920 	movx	a,@dptr
                           1921 ;	genPointerSet
                           1922 ;	genGenPointerSet
   5AB1 FB                 1923 	mov	r3,a
   5AB2 8D 82              1924 	mov	dpl,r5
   5AB4 8E 83              1925 	mov	dph,r6
   5AB6 8F F0              1926 	mov	b,r7
                           1927 ;	Peephole 191	removed redundant mov
   5AB8 12 DF B7           1928 	lcall	__gptrput
                           1929 ;	../../Common/stack.c:562: stack_module_call(si->stack_id, (b->from) - 1, b);
                           1930 ;	genMinus
                           1931 ;	genMinusDec
   5ABB 1B                 1932 	dec	r3
                           1933 ;	genIpush
   5ABC A8 10              1934 	mov	r0,_bp
   5ABE 08                 1935 	inc	r0
   5ABF E6                 1936 	mov	a,@r0
   5AC0 C0 E0              1937 	push	acc
   5AC2 08                 1938 	inc	r0
   5AC3 E6                 1939 	mov	a,@r0
   5AC4 C0 E0              1940 	push	acc
   5AC6 08                 1941 	inc	r0
   5AC7 E6                 1942 	mov	a,@r0
   5AC8 C0 E0              1943 	push	acc
                           1944 ;	genIpush
   5ACA C0 03              1945 	push	ar3
                           1946 ;	genCall
   5ACC 8A 82              1947 	mov	dpl,r2
   5ACE 12 5E 7F           1948 	lcall	_stack_module_call
   5AD1 E5 81              1949 	mov	a,sp
   5AD3 24 FC              1950 	add	a,#0xfc
   5AD5 F5 81              1951 	mov	sp,a
                           1952 ;	../../Common/stack.c:563: b=0;
                           1953 ;	genAssign
   5AD7 A8 10              1954 	mov	r0,_bp
   5AD9 08                 1955 	inc	r0
   5ADA E4                 1956 	clr	a
   5ADB F6                 1957 	mov	@r0,a
   5ADC 08                 1958 	inc	r0
   5ADD F6                 1959 	mov	@r0,a
   5ADE 08                 1960 	inc	r0
   5ADF F6                 1961 	mov	@r0,a
   5AE0 02 5B C7           1962 	ljmp	00138$
                           1963 ;	../../Common/stack.c:568: while ( (i < stacks[si->stack_id].layers) && b)
   5AE3                    1964 00206$:
                           1965 ;	genPlus
   5AE3 E5 10              1966 	mov	a,_bp
   5AE5 24 05              1967 	add	a,#0x05
   5AE7 F8                 1968 	mov	r0,a
                           1969 ;     genPlusIncr
   5AE8 74 01              1970 	mov	a,#0x01
   5AEA 26                 1971 	add	a,@r0
   5AEB FA                 1972 	mov	r2,a
                           1973 ;	Peephole 181	changed mov to clr
   5AEC E4                 1974 	clr	a
   5AED 08                 1975 	inc	r0
   5AEE 36                 1976 	addc	a,@r0
   5AEF FB                 1977 	mov	r3,a
   5AF0 08                 1978 	inc	r0
   5AF1 86 04              1979 	mov	ar4,@r0
                           1980 ;	genAssign
   5AF3 E5 10              1981 	mov	a,_bp
   5AF5 24 04              1982 	add	a,#0x04
   5AF7 F8                 1983 	mov	r0,a
   5AF8 76 00              1984 	mov	@r0,#0x00
   5AFA                    1985 00133$:
                           1986 ;	genPointerGet
                           1987 ;	genGenPointerGet
   5AFA 8A 82              1988 	mov	dpl,r2
   5AFC 8B 83              1989 	mov	dph,r3
   5AFE 8C F0              1990 	mov	b,r4
   5B00 12 E4 9F           1991 	lcall	__gptrget
                           1992 ;	genMult
                           1993 ;	genMultOneByte
   5B03 FE                 1994 	mov	r6,a
                           1995 ;	Peephole 105	removed redundant mov
   5B04 75 F0 05           1996 	mov	b,#0x05
   5B07 A4                 1997 	mul	ab
                           1998 ;	genPlus
   5B08 FF                 1999 	mov	r7,a
                           2000 ;	Peephole 177.b	removed redundant mov
   5B09 24 DD              2001 	add	a,#_stacks
   5B0B F5 82              2002 	mov	dpl,a
                           2003 ;	Peephole 181	changed mov to clr
   5B0D E4                 2004 	clr	a
   5B0E 34 F0              2005 	addc	a,#(_stacks >> 8)
   5B10 F5 83              2006 	mov	dph,a
                           2007 ;	genIpush
   5B12 C0 02              2008 	push	ar2
   5B14 C0 03              2009 	push	ar3
   5B16 C0 04              2010 	push	ar4
                           2011 ;	genPointerGet
                           2012 ;	genFarPointerGet
   5B18 E0                 2013 	movx	a,@dptr
   5B19 FA                 2014 	mov	r2,a
                           2015 ;	genCmpLt
   5B1A E5 10              2016 	mov	a,_bp
   5B1C 24 04              2017 	add	a,#0x04
   5B1E F8                 2018 	mov	r0,a
                           2019 ;	genCmp
   5B1F C3                 2020 	clr	c
   5B20 E6                 2021 	mov	a,@r0
   5B21 9A                 2022 	subb	a,r2
                           2023 ;	genIpop
                           2024 ;	genIfx
                           2025 ;	genIfxJump
                           2026 ;	Peephole 129.d	optimized condition
   5B22 D0 04              2027 	pop	ar4
   5B24 D0 03              2028 	pop	ar3
   5B26 D0 02              2029 	pop	ar2
   5B28 40 03              2030 	jc	00263$
   5B2A 02 5B C7           2031 	ljmp	00138$
   5B2D                    2032 00263$:
                           2033 ;	genIfx
   5B2D A8 10              2034 	mov	r0,_bp
   5B2F 08                 2035 	inc	r0
   5B30 E6                 2036 	mov	a,@r0
   5B31 08                 2037 	inc	r0
   5B32 46                 2038 	orl	a,@r0
   5B33 08                 2039 	inc	r0
   5B34 46                 2040 	orl	a,@r0
                           2041 ;	genIfxJump
   5B35 70 03              2042 	jnz	00264$
   5B37 02 5B C7           2043 	ljmp	00138$
   5B3A                    2044 00264$:
                           2045 ;	../../Common/stack.c:570: if (stacks[si->stack_id].module[i] == (module_id_t) b->from)
                           2046 ;	genIpush
   5B3A C0 02              2047 	push	ar2
   5B3C C0 03              2048 	push	ar3
   5B3E C0 04              2049 	push	ar4
                           2050 ;	genPlus
                           2051 ;	Peephole 236.g	used r7 instead of ar7
   5B40 EF                 2052 	mov	a,r7
   5B41 24 DD              2053 	add	a,#_stacks
   5B43 FF                 2054 	mov	r7,a
                           2055 ;	Peephole 181	changed mov to clr
   5B44 E4                 2056 	clr	a
   5B45 34 F0              2057 	addc	a,#(_stacks >> 8)
   5B47 FA                 2058 	mov	r2,a
                           2059 ;	genPlus
                           2060 ;     genPlusIncr
   5B48 0F                 2061 	inc	r7
   5B49 BF 00 01           2062 	cjne	r7,#0x00,00265$
   5B4C 0A                 2063 	inc	r2
   5B4D                    2064 00265$:
                           2065 ;	genPlus
   5B4D E5 10              2066 	mov	a,_bp
   5B4F 24 04              2067 	add	a,#0x04
   5B51 F8                 2068 	mov	r0,a
   5B52 E6                 2069 	mov	a,@r0
                           2070 ;	Peephole 236.a	used r7 instead of ar7
   5B53 2F                 2071 	add	a,r7
   5B54 FF                 2072 	mov	r7,a
                           2073 ;	Peephole 181	changed mov to clr
   5B55 E4                 2074 	clr	a
                           2075 ;	Peephole 236.b	used r2 instead of ar2
   5B56 3A                 2076 	addc	a,r2
   5B57 FA                 2077 	mov	r2,a
                           2078 ;	genPlus
   5B58 A8 10              2079 	mov	r0,_bp
   5B5A 08                 2080 	inc	r0
                           2081 ;     genPlusIncr
   5B5B 74 1D              2082 	mov	a,#0x1D
   5B5D 26                 2083 	add	a,@r0
   5B5E FB                 2084 	mov	r3,a
                           2085 ;	Peephole 181	changed mov to clr
   5B5F E4                 2086 	clr	a
   5B60 08                 2087 	inc	r0
   5B61 36                 2088 	addc	a,@r0
   5B62 FC                 2089 	mov	r4,a
   5B63 08                 2090 	inc	r0
   5B64 86 05              2091 	mov	ar5,@r0
                           2092 ;	genPointerGet
                           2093 ;	genGenPointerGet
   5B66 8B 82              2094 	mov	dpl,r3
   5B68 8C 83              2095 	mov	dph,r4
   5B6A 8D F0              2096 	mov	b,r5
   5B6C 12 E4 9F           2097 	lcall	__gptrget
   5B6F FB                 2098 	mov	r3,a
                           2099 ;	genPointerGet
                           2100 ;	genFarPointerGet
   5B70 8F 82              2101 	mov	dpl,r7
   5B72 8A 83              2102 	mov	dph,r2
   5B74 E0                 2103 	movx	a,@dptr
                           2104 ;	genCmpEq
                           2105 ;	gencjne
                           2106 ;	gencjneshort
   5B75 FF                 2107 	mov	r7,a
                           2108 ;	Peephole 105	removed redundant mov
   5B76 B5 03 04           2109 	cjne	a,ar3,00266$
   5B79 74 01              2110 	mov	a,#0x01
   5B7B 80 01              2111 	sjmp	00267$
   5B7D                    2112 00266$:
   5B7D E4                 2113 	clr	a
   5B7E                    2114 00267$:
                           2115 ;	genIpop
   5B7E D0 04              2116 	pop	ar4
   5B80 D0 03              2117 	pop	ar3
   5B82 D0 02              2118 	pop	ar2
                           2119 ;	genIfx
                           2120 ;	genIfxJump
                           2121 ;	Peephole 108.c	removed ljmp by inverse jump logic
   5B84 60 38              2122 	jz	00131$
                           2123 ;	Peephole 300	removed redundant label 00268$
                           2124 ;	../../Common/stack.c:572: stack_module_call(si->stack_id, i-1, b);
                           2125 ;	genMinus
   5B86 E5 10              2126 	mov	a,_bp
   5B88 24 04              2127 	add	a,#0x04
   5B8A F8                 2128 	mov	r0,a
                           2129 ;	genMinusDec
   5B8B E6                 2130 	mov	a,@r0
   5B8C 14                 2131 	dec	a
   5B8D FD                 2132 	mov	r5,a
                           2133 ;	genIpush
   5B8E C0 02              2134 	push	ar2
   5B90 C0 03              2135 	push	ar3
   5B92 C0 04              2136 	push	ar4
   5B94 A8 10              2137 	mov	r0,_bp
   5B96 08                 2138 	inc	r0
   5B97 E6                 2139 	mov	a,@r0
   5B98 C0 E0              2140 	push	acc
   5B9A 08                 2141 	inc	r0
   5B9B E6                 2142 	mov	a,@r0
   5B9C C0 E0              2143 	push	acc
   5B9E 08                 2144 	inc	r0
   5B9F E6                 2145 	mov	a,@r0
   5BA0 C0 E0              2146 	push	acc
                           2147 ;	genIpush
   5BA2 C0 05              2148 	push	ar5
                           2149 ;	genCall
   5BA4 8E 82              2150 	mov	dpl,r6
   5BA6 12 5E 7F           2151 	lcall	_stack_module_call
   5BA9 E5 81              2152 	mov	a,sp
   5BAB 24 FC              2153 	add	a,#0xfc
   5BAD F5 81              2154 	mov	sp,a
   5BAF D0 04              2155 	pop	ar4
   5BB1 D0 03              2156 	pop	ar3
   5BB3 D0 02              2157 	pop	ar2
                           2158 ;	../../Common/stack.c:573: b = 0;
                           2159 ;	genAssign
   5BB5 A8 10              2160 	mov	r0,_bp
   5BB7 08                 2161 	inc	r0
   5BB8 E4                 2162 	clr	a
   5BB9 F6                 2163 	mov	@r0,a
   5BBA 08                 2164 	inc	r0
   5BBB F6                 2165 	mov	@r0,a
   5BBC 08                 2166 	inc	r0
   5BBD F6                 2167 	mov	@r0,a
   5BBE                    2168 00131$:
                           2169 ;	../../Common/stack.c:575: i++;
                           2170 ;	genPlus
   5BBE E5 10              2171 	mov	a,_bp
   5BC0 24 04              2172 	add	a,#0x04
   5BC2 F8                 2173 	mov	r0,a
                           2174 ;     genPlusIncr
   5BC3 06                 2175 	inc	@r0
   5BC4 02 5A FA           2176 	ljmp	00133$
   5BC7                    2177 00138$:
                           2178 ;	../../Common/stack.c:578: if(b)
                           2179 ;	genIfx
   5BC7 A8 10              2180 	mov	r0,_bp
   5BC9 08                 2181 	inc	r0
   5BCA E6                 2182 	mov	a,@r0
   5BCB 08                 2183 	inc	r0
   5BCC 46                 2184 	orl	a,@r0
   5BCD 08                 2185 	inc	r0
   5BCE 46                 2186 	orl	a,@r0
                           2187 ;	genIfxJump
   5BCF 70 03              2188 	jnz	00269$
   5BD1 02 5E 79           2189 	ljmp	00184$
   5BD4                    2190 00269$:
                           2191 ;	../../Common/stack.c:583: stack_buffer_free(b);
                           2192 ;	genCall
   5BD4 A8 10              2193 	mov	r0,_bp
   5BD6 08                 2194 	inc	r0
   5BD7 86 82              2195 	mov	dpl,@r0
   5BD9 08                 2196 	inc	r0
   5BDA 86 83              2197 	mov	dph,@r0
   5BDC 08                 2198 	inc	r0
   5BDD 86 F0              2199 	mov	b,@r0
   5BDF 12 61 FA           2200 	lcall	_stack_buffer_free
                           2201 ;	../../Common/stack.c:584: b=0;
   5BE2 02 5E 79           2202 	ljmp	00184$
                           2203 ;	../../Common/stack.c:593: while (b && (stacks[i].layers > 0) )
   5BE5                    2204 00214$:
                           2205 ;	genAssign
   5BE5 E5 10              2206 	mov	a,_bp
   5BE7 24 04              2207 	add	a,#0x04
   5BE9 F8                 2208 	mov	r0,a
   5BEA 76 00              2209 	mov	@r0,#0x00
   5BEC                    2210 00149$:
                           2211 ;	genIfx
   5BEC A8 10              2212 	mov	r0,_bp
   5BEE 08                 2213 	inc	r0
   5BEF E6                 2214 	mov	a,@r0
   5BF0 08                 2215 	inc	r0
   5BF1 46                 2216 	orl	a,@r0
   5BF2 08                 2217 	inc	r0
   5BF3 46                 2218 	orl	a,@r0
                           2219 ;	genIfxJump
   5BF4 70 03              2220 	jnz	00270$
   5BF6 02 5C DC           2221 	ljmp	00151$
   5BF9                    2222 00270$:
                           2223 ;	genMult
   5BF9 E5 10              2224 	mov	a,_bp
   5BFB 24 04              2225 	add	a,#0x04
   5BFD F8                 2226 	mov	r0,a
                           2227 ;	genMultOneByte
   5BFE E6                 2228 	mov	a,@r0
   5BFF 75 F0 05           2229 	mov	b,#0x05
   5C02 A4                 2230 	mul	ab
                           2231 ;	genPlus
   5C03 FB                 2232 	mov	r3,a
                           2233 ;	Peephole 177.b	removed redundant mov
   5C04 24 DD              2234 	add	a,#_stacks
   5C06 FC                 2235 	mov	r4,a
                           2236 ;	Peephole 181	changed mov to clr
   5C07 E4                 2237 	clr	a
   5C08 34 F0              2238 	addc	a,#(_stacks >> 8)
   5C0A FD                 2239 	mov	r5,a
                           2240 ;	genPointerGet
                           2241 ;	genFarPointerGet
   5C0B 8C 82              2242 	mov	dpl,r4
   5C0D 8D 83              2243 	mov	dph,r5
   5C0F E0                 2244 	movx	a,@dptr
                           2245 ;	genIfxJump
   5C10 70 03              2246 	jnz	00271$
   5C12 02 5C DC           2247 	ljmp	00151$
   5C15                    2248 00271$:
                           2249 ;	../../Common/stack.c:597: while ( (j < stacks[i].layers) && b)
                           2250 ;	genAssign
                           2251 ;	genPlus
                           2252 ;	Peephole 236.g	used r3 instead of ar3
                           2253 ;	peephole 177.h	optimized mov sequence
   5C15 EB                 2254 	mov	a,r3
                           2255 ;	Peephole 236.i	used r4 instead of ar4
   5C16 FC                 2256 	mov	r4,a
   5C17 24 DD              2257 	add	a,#_stacks
   5C19 FB                 2258 	mov	r3,a
                           2259 ;	Peephole 181	changed mov to clr
   5C1A E4                 2260 	clr	a
   5C1B 34 F0              2261 	addc	a,#(_stacks >> 8)
   5C1D FD                 2262 	mov	r5,a
                           2263 ;	genAssign
   5C1E E5 10              2264 	mov	a,_bp
   5C20 24 08              2265 	add	a,#0x08
   5C22 F8                 2266 	mov	r0,a
   5C23 76 01              2267 	mov	@r0,#0x01
   5C25                    2268 00145$:
                           2269 ;	genPointerGet
                           2270 ;	genFarPointerGet
   5C25 8B 82              2271 	mov	dpl,r3
   5C27 8D 83              2272 	mov	dph,r5
   5C29 E0                 2273 	movx	a,@dptr
   5C2A FF                 2274 	mov	r7,a
                           2275 ;	genCmpLt
   5C2B E5 10              2276 	mov	a,_bp
   5C2D 24 08              2277 	add	a,#0x08
   5C2F F8                 2278 	mov	r0,a
                           2279 ;	genCmp
   5C30 C3                 2280 	clr	c
   5C31 E6                 2281 	mov	a,@r0
   5C32 9F                 2282 	subb	a,r7
                           2283 ;	genIfxJump
   5C33 40 03              2284 	jc	00272$
   5C35 02 5C D3           2285 	ljmp	00147$
   5C38                    2286 00272$:
                           2287 ;	genIfx
   5C38 A8 10              2288 	mov	r0,_bp
   5C3A 08                 2289 	inc	r0
   5C3B E6                 2290 	mov	a,@r0
   5C3C 08                 2291 	inc	r0
   5C3D 46                 2292 	orl	a,@r0
   5C3E 08                 2293 	inc	r0
   5C3F 46                 2294 	orl	a,@r0
                           2295 ;	genIfxJump
   5C40 70 03              2296 	jnz	00273$
   5C42 02 5C D3           2297 	ljmp	00147$
   5C45                    2298 00273$:
                           2299 ;	../../Common/stack.c:599: if (stacks[i].module[j] == (module_id_t) b->from)
                           2300 ;	genIpush
   5C45 C0 03              2301 	push	ar3
   5C47 C0 05              2302 	push	ar5
                           2303 ;	genPlus
                           2304 ;	Peephole 236.g	used r4 instead of ar4
   5C49 EC                 2305 	mov	a,r4
   5C4A 24 DD              2306 	add	a,#_stacks
   5C4C FF                 2307 	mov	r7,a
                           2308 ;	Peephole 181	changed mov to clr
   5C4D E4                 2309 	clr	a
   5C4E 34 F0              2310 	addc	a,#(_stacks >> 8)
   5C50 FB                 2311 	mov	r3,a
                           2312 ;	genPlus
                           2313 ;     genPlusIncr
   5C51 0F                 2314 	inc	r7
   5C52 BF 00 01           2315 	cjne	r7,#0x00,00274$
   5C55 0B                 2316 	inc	r3
   5C56                    2317 00274$:
                           2318 ;	genPlus
   5C56 E5 10              2319 	mov	a,_bp
   5C58 24 08              2320 	add	a,#0x08
   5C5A F8                 2321 	mov	r0,a
   5C5B E6                 2322 	mov	a,@r0
                           2323 ;	Peephole 236.a	used r7 instead of ar7
   5C5C 2F                 2324 	add	a,r7
   5C5D FF                 2325 	mov	r7,a
                           2326 ;	Peephole 181	changed mov to clr
   5C5E E4                 2327 	clr	a
                           2328 ;	Peephole 236.b	used r3 instead of ar3
   5C5F 3B                 2329 	addc	a,r3
   5C60 FB                 2330 	mov	r3,a
                           2331 ;	genPlus
   5C61 A8 10              2332 	mov	r0,_bp
   5C63 08                 2333 	inc	r0
                           2334 ;     genPlusIncr
   5C64 74 1D              2335 	mov	a,#0x1D
   5C66 26                 2336 	add	a,@r0
   5C67 FD                 2337 	mov	r5,a
                           2338 ;	Peephole 181	changed mov to clr
   5C68 E4                 2339 	clr	a
   5C69 08                 2340 	inc	r0
   5C6A 36                 2341 	addc	a,@r0
   5C6B FA                 2342 	mov	r2,a
   5C6C 08                 2343 	inc	r0
   5C6D 86 06              2344 	mov	ar6,@r0
                           2345 ;	genPointerGet
                           2346 ;	genGenPointerGet
   5C6F 8D 82              2347 	mov	dpl,r5
   5C71 8A 83              2348 	mov	dph,r2
   5C73 8E F0              2349 	mov	b,r6
   5C75 12 E4 9F           2350 	lcall	__gptrget
   5C78 FD                 2351 	mov	r5,a
                           2352 ;	genPointerGet
                           2353 ;	genFarPointerGet
   5C79 8F 82              2354 	mov	dpl,r7
   5C7B 8B 83              2355 	mov	dph,r3
   5C7D E0                 2356 	movx	a,@dptr
                           2357 ;	genCmpEq
                           2358 ;	gencjne
                           2359 ;	gencjneshort
   5C7E FF                 2360 	mov	r7,a
                           2361 ;	Peephole 105	removed redundant mov
   5C7F B5 05 04           2362 	cjne	a,ar5,00275$
   5C82 74 01              2363 	mov	a,#0x01
   5C84 80 01              2364 	sjmp	00276$
   5C86                    2365 00275$:
   5C86 E4                 2366 	clr	a
   5C87                    2367 00276$:
                           2368 ;	genIpop
   5C87 D0 05              2369 	pop	ar5
   5C89 D0 03              2370 	pop	ar3
                           2371 ;	genIfx
                           2372 ;	genIfxJump
                           2373 ;	Peephole 108.c	removed ljmp by inverse jump logic
   5C8B 60 3D              2374 	jz	00143$
                           2375 ;	Peephole 300	removed redundant label 00277$
                           2376 ;	../../Common/stack.c:604: stack_module_call(i, j-1, b);
                           2377 ;	genMinus
   5C8D E5 10              2378 	mov	a,_bp
   5C8F 24 08              2379 	add	a,#0x08
   5C91 F8                 2380 	mov	r0,a
                           2381 ;	genMinusDec
   5C92 E6                 2382 	mov	a,@r0
   5C93 14                 2383 	dec	a
   5C94 FA                 2384 	mov	r2,a
                           2385 ;	genIpush
   5C95 C0 03              2386 	push	ar3
   5C97 C0 04              2387 	push	ar4
   5C99 C0 05              2388 	push	ar5
   5C9B A8 10              2389 	mov	r0,_bp
   5C9D 08                 2390 	inc	r0
   5C9E E6                 2391 	mov	a,@r0
   5C9F C0 E0              2392 	push	acc
   5CA1 08                 2393 	inc	r0
   5CA2 E6                 2394 	mov	a,@r0
   5CA3 C0 E0              2395 	push	acc
   5CA5 08                 2396 	inc	r0
   5CA6 E6                 2397 	mov	a,@r0
   5CA7 C0 E0              2398 	push	acc
                           2399 ;	genIpush
   5CA9 C0 02              2400 	push	ar2
                           2401 ;	genCall
   5CAB E5 10              2402 	mov	a,_bp
   5CAD 24 04              2403 	add	a,#0x04
   5CAF F8                 2404 	mov	r0,a
   5CB0 86 82              2405 	mov	dpl,@r0
   5CB2 12 5E 7F           2406 	lcall	_stack_module_call
   5CB5 E5 81              2407 	mov	a,sp
   5CB7 24 FC              2408 	add	a,#0xfc
   5CB9 F5 81              2409 	mov	sp,a
   5CBB D0 05              2410 	pop	ar5
   5CBD D0 04              2411 	pop	ar4
   5CBF D0 03              2412 	pop	ar3
                           2413 ;	../../Common/stack.c:605: b = 0;
                           2414 ;	genAssign
   5CC1 A8 10              2415 	mov	r0,_bp
   5CC3 08                 2416 	inc	r0
   5CC4 E4                 2417 	clr	a
   5CC5 F6                 2418 	mov	@r0,a
   5CC6 08                 2419 	inc	r0
   5CC7 F6                 2420 	mov	@r0,a
   5CC8 08                 2421 	inc	r0
   5CC9 F6                 2422 	mov	@r0,a
   5CCA                    2423 00143$:
                           2424 ;	../../Common/stack.c:607: j++;
                           2425 ;	genPlus
   5CCA E5 10              2426 	mov	a,_bp
   5CCC 24 08              2427 	add	a,#0x08
   5CCE F8                 2428 	mov	r0,a
                           2429 ;     genPlusIncr
   5CCF 06                 2430 	inc	@r0
   5CD0 02 5C 25           2431 	ljmp	00145$
   5CD3                    2432 00147$:
                           2433 ;	../../Common/stack.c:609: i++;
                           2434 ;	genPlus
   5CD3 E5 10              2435 	mov	a,_bp
   5CD5 24 04              2436 	add	a,#0x04
   5CD7 F8                 2437 	mov	r0,a
                           2438 ;     genPlusIncr
   5CD8 06                 2439 	inc	@r0
   5CD9 02 5B EC           2440 	ljmp	00149$
   5CDC                    2441 00151$:
                           2442 ;	../../Common/stack.c:612: if (b)
                           2443 ;	genIfx
   5CDC A8 10              2444 	mov	r0,_bp
   5CDE 08                 2445 	inc	r0
   5CDF E6                 2446 	mov	a,@r0
   5CE0 08                 2447 	inc	r0
   5CE1 46                 2448 	orl	a,@r0
   5CE2 08                 2449 	inc	r0
   5CE3 46                 2450 	orl	a,@r0
                           2451 ;	genIfxJump
   5CE4 70 03              2452 	jnz	00278$
   5CE6 02 5E 79           2453 	ljmp	00184$
   5CE9                    2454 00278$:
                           2455 ;	../../Common/stack.c:617: stack_buffer_free(b);
                           2456 ;	genCall
   5CE9 A8 10              2457 	mov	r0,_bp
   5CEB 08                 2458 	inc	r0
   5CEC 86 82              2459 	mov	dpl,@r0
   5CEE 08                 2460 	inc	r0
   5CEF 86 83              2461 	mov	dph,@r0
   5CF1 08                 2462 	inc	r0
   5CF2 86 F0              2463 	mov	b,@r0
   5CF4 12 61 FA           2464 	lcall	_stack_buffer_free
   5CF7 02 5E 79           2465 	ljmp	00184$
   5CFA                    2466 00178$:
                           2467 ;	../../Common/stack.c:629: status = socket_up(b);
                           2468 ;	genCall
   5CFA A8 10              2469 	mov	r0,_bp
   5CFC 08                 2470 	inc	r0
   5CFD 86 82              2471 	mov	dpl,@r0
   5CFF 08                 2472 	inc	r0
   5D00 86 83              2473 	mov	dph,@r0
   5D02 08                 2474 	inc	r0
   5D03 86 F0              2475 	mov	b,@r0
   5D05 12 54 15           2476 	lcall	_socket_up
   5D08 AA 82              2477 	mov	r2,dpl
                           2478 ;	genAssign
                           2479 ;	../../Common/stack.c:630: if (status != pdTRUE)
                           2480 ;	genCmpEq
                           2481 ;	gencjneshort
   5D0A BA 01 03           2482 	cjne	r2,#0x01,00279$
   5D0D 02 5E 56           2483 	ljmp	00172$
   5D10                    2484 00279$:
                           2485 ;	../../Common/stack.c:632: while (b && (stacks[i].layers > 0))
                           2486 ;	genAssign
   5D10 E5 10              2487 	mov	a,_bp
   5D12 24 04              2488 	add	a,#0x04
   5D14 F8                 2489 	mov	r0,a
   5D15 76 00              2490 	mov	@r0,#0x00
   5D17                    2491 00168$:
                           2492 ;	genIfx
   5D17 A8 10              2493 	mov	r0,_bp
   5D19 08                 2494 	inc	r0
   5D1A E6                 2495 	mov	a,@r0
   5D1B 08                 2496 	inc	r0
   5D1C 46                 2497 	orl	a,@r0
   5D1D 08                 2498 	inc	r0
   5D1E 46                 2499 	orl	a,@r0
                           2500 ;	genIfxJump
   5D1F 70 03              2501 	jnz	00280$
   5D21 02 5E 56           2502 	ljmp	00172$
   5D24                    2503 00280$:
                           2504 ;	genMult
   5D24 E5 10              2505 	mov	a,_bp
   5D26 24 04              2506 	add	a,#0x04
   5D28 F8                 2507 	mov	r0,a
                           2508 ;	genMultOneByte
   5D29 E6                 2509 	mov	a,@r0
   5D2A 75 F0 05           2510 	mov	b,#0x05
   5D2D A4                 2511 	mul	ab
                           2512 ;	genPlus
   5D2E FC                 2513 	mov	r4,a
                           2514 ;	Peephole 177.b	removed redundant mov
   5D2F 24 DD              2515 	add	a,#_stacks
   5D31 FD                 2516 	mov	r5,a
                           2517 ;	Peephole 181	changed mov to clr
   5D32 E4                 2518 	clr	a
   5D33 34 F0              2519 	addc	a,#(_stacks >> 8)
   5D35 FE                 2520 	mov	r6,a
                           2521 ;	genPointerGet
                           2522 ;	genFarPointerGet
   5D36 8D 82              2523 	mov	dpl,r5
   5D38 8E 83              2524 	mov	dph,r6
   5D3A E0                 2525 	movx	a,@dptr
                           2526 ;	genIfxJump
   5D3B 70 03              2527 	jnz	00281$
   5D3D 02 5E 56           2528 	ljmp	00172$
   5D40                    2529 00281$:
                           2530 ;	../../Common/stack.c:639: j=0;
                           2531 ;	genAssign
   5D40 7D 00              2532 	mov	r5,#0x00
                           2533 ;	../../Common/stack.c:640: next_layer = LAYERS_MAX + 1 ;
                           2534 ;	genAssign
   5D42 E5 10              2535 	mov	a,_bp
   5D44 24 09              2536 	add	a,#0x09
   5D46 F8                 2537 	mov	r0,a
   5D47 76 05              2538 	mov	@r0,#0x05
                           2539 ;	../../Common/stack.c:641: while (j < (stacks[i].layers-1))
                           2540 ;	genPlus
   5D49 A8 10              2541 	mov	r0,_bp
   5D4B 08                 2542 	inc	r0
   5D4C E5 10              2543 	mov	a,_bp
   5D4E 24 0A              2544 	add	a,#0x0a
   5D50 F9                 2545 	mov	r1,a
                           2546 ;     genPlusIncr
   5D51 74 1D              2547 	mov	a,#0x1D
   5D53 26                 2548 	add	a,@r0
   5D54 F7                 2549 	mov	@r1,a
                           2550 ;	Peephole 181	changed mov to clr
   5D55 E4                 2551 	clr	a
   5D56 08                 2552 	inc	r0
   5D57 36                 2553 	addc	a,@r0
   5D58 09                 2554 	inc	r1
   5D59 F7                 2555 	mov	@r1,a
   5D5A 08                 2556 	inc	r0
   5D5B 09                 2557 	inc	r1
   5D5C E6                 2558 	mov	a,@r0
   5D5D F7                 2559 	mov	@r1,a
                           2560 ;	genAssign
   5D5E 8C 07              2561 	mov	ar7,r4
                           2562 ;	genPlus
   5D60 E5 10              2563 	mov	a,_bp
   5D62 24 0D              2564 	add	a,#0x0d
   5D64 F8                 2565 	mov	r0,a
                           2566 ;	Peephole 236.g	used r4 instead of ar4
   5D65 EC                 2567 	mov	a,r4
   5D66 24 DD              2568 	add	a,#_stacks
   5D68 F6                 2569 	mov	@r0,a
                           2570 ;	Peephole 181	changed mov to clr
   5D69 E4                 2571 	clr	a
   5D6A 34 F0              2572 	addc	a,#(_stacks >> 8)
   5D6C 08                 2573 	inc	r0
   5D6D F6                 2574 	mov	@r0,a
   5D6E                    2575 00160$:
                           2576 ;	genIpush
   5D6E C0 02              2577 	push	ar2
                           2578 ;	genPointerGet
                           2579 ;	genFarPointerGet
   5D70 E5 10              2580 	mov	a,_bp
   5D72 24 0D              2581 	add	a,#0x0d
   5D74 F8                 2582 	mov	r0,a
   5D75 86 82              2583 	mov	dpl,@r0
   5D77 08                 2584 	inc	r0
   5D78 86 83              2585 	mov	dph,@r0
   5D7A E0                 2586 	movx	a,@dptr
   5D7B FC                 2587 	mov	r4,a
                           2588 ;	genCast
   5D7C 7A 00              2589 	mov	r2,#0x00
                           2590 ;	genMinus
                           2591 ;	genMinusDec
   5D7E 1C                 2592 	dec	r4
   5D7F BC FF 01           2593 	cjne	r4,#0xff,00282$
   5D82 1A                 2594 	dec	r2
   5D83                    2595 00282$:
                           2596 ;	genCast
   5D83 8D 06              2597 	mov	ar6,r5
   5D85 7B 00              2598 	mov	r3,#0x00
                           2599 ;	genCmpLt
                           2600 ;	genCmp
   5D87 C3                 2601 	clr	c
   5D88 EE                 2602 	mov	a,r6
   5D89 9C                 2603 	subb	a,r4
   5D8A EB                 2604 	mov	a,r3
   5D8B 64 80              2605 	xrl	a,#0x80
   5D8D 8A F0              2606 	mov	b,r2
   5D8F 63 F0 80           2607 	xrl	b,#0x80
   5D92 95 F0              2608 	subb	a,b
   5D94 E4                 2609 	clr	a
   5D95 33                 2610 	rlc	a
                           2611 ;	genIpop
   5D96 D0 02              2612 	pop	ar2
                           2613 ;	genIfx
                           2614 ;	genIfxJump
                           2615 ;	Peephole 108.c	removed ljmp by inverse jump logic
   5D98 60 49              2616 	jz	00162$
                           2617 ;	Peephole 300	removed redundant label 00283$
                           2618 ;	../../Common/stack.c:646: if (stacks[i].module[j] == (module_id_t) b->from)
                           2619 ;	genPlus
                           2620 ;	Peephole 236.g	used r7 instead of ar7
   5D9A EF                 2621 	mov	a,r7
   5D9B 24 DD              2622 	add	a,#_stacks
   5D9D FB                 2623 	mov	r3,a
                           2624 ;	Peephole 181	changed mov to clr
   5D9E E4                 2625 	clr	a
   5D9F 34 F0              2626 	addc	a,#(_stacks >> 8)
   5DA1 FC                 2627 	mov	r4,a
                           2628 ;	genPlus
                           2629 ;     genPlusIncr
   5DA2 0B                 2630 	inc	r3
   5DA3 BB 00 01           2631 	cjne	r3,#0x00,00284$
   5DA6 0C                 2632 	inc	r4
   5DA7                    2633 00284$:
                           2634 ;	genPlus
                           2635 ;	Peephole 236.g	used r5 instead of ar5
   5DA7 ED                 2636 	mov	a,r5
                           2637 ;	Peephole 236.a	used r3 instead of ar3
   5DA8 2B                 2638 	add	a,r3
   5DA9 FB                 2639 	mov	r3,a
                           2640 ;	Peephole 181	changed mov to clr
   5DAA E4                 2641 	clr	a
                           2642 ;	Peephole 236.b	used r4 instead of ar4
   5DAB 3C                 2643 	addc	a,r4
   5DAC FC                 2644 	mov	r4,a
                           2645 ;	genPointerGet
                           2646 ;	genGenPointerGet
   5DAD E5 10              2647 	mov	a,_bp
   5DAF 24 0A              2648 	add	a,#0x0a
   5DB1 F8                 2649 	mov	r0,a
   5DB2 86 82              2650 	mov	dpl,@r0
   5DB4 08                 2651 	inc	r0
   5DB5 86 83              2652 	mov	dph,@r0
   5DB7 08                 2653 	inc	r0
   5DB8 86 F0              2654 	mov	b,@r0
   5DBA 12 E4 9F           2655 	lcall	__gptrget
   5DBD FE                 2656 	mov	r6,a
                           2657 ;	genPointerGet
                           2658 ;	genFarPointerGet
   5DBE 8B 82              2659 	mov	dpl,r3
   5DC0 8C 83              2660 	mov	dph,r4
   5DC2 E0                 2661 	movx	a,@dptr
                           2662 ;	genCmpEq
                           2663 ;	gencjneshort
   5DC3 FB                 2664 	mov	r3,a
                           2665 ;	Peephole 105	removed redundant mov
                           2666 ;	Peephole 112.b	changed ljmp to sjmp
                           2667 ;	Peephole 198.b	optimized misc jump sequence
   5DC4 B5 06 19           2668 	cjne	a,ar6,00158$
                           2669 ;	Peephole 200.b	removed redundant sjmp
                           2670 ;	Peephole 300	removed redundant label 00285$
                           2671 ;	Peephole 300	removed redundant label 00286$
                           2672 ;	../../Common/stack.c:648: next_layer = j+1;
                           2673 ;	genPlus
   5DC7 E5 10              2674 	mov	a,_bp
   5DC9 24 09              2675 	add	a,#0x09
   5DCB F8                 2676 	mov	r0,a
                           2677 ;     genPlusIncr
   5DCC 74 01              2678 	mov	a,#0x01
                           2679 ;	Peephole 236.a	used r5 instead of ar5
   5DCE 2D                 2680 	add	a,r5
   5DCF F6                 2681 	mov	@r0,a
                           2682 ;	../../Common/stack.c:649: j = stacks[i].layers;
                           2683 ;	genPlus
                           2684 ;	Peephole 236.g	used r7 instead of ar7
   5DD0 EF                 2685 	mov	a,r7
   5DD1 24 DD              2686 	add	a,#_stacks
   5DD3 F5 82              2687 	mov	dpl,a
                           2688 ;	Peephole 181	changed mov to clr
   5DD5 E4                 2689 	clr	a
   5DD6 34 F0              2690 	addc	a,#(_stacks >> 8)
   5DD8 F5 83              2691 	mov	dph,a
                           2692 ;	genPointerGet
                           2693 ;	genFarPointerGet
   5DDA E0                 2694 	movx	a,@dptr
   5DDB FB                 2695 	mov	r3,a
                           2696 ;	genAssign
   5DDC 8B 05              2697 	mov	ar5,r3
                           2698 ;	Peephole 112.b	changed ljmp to sjmp
   5DDE 80 8E              2699 	sjmp	00160$
   5DE0                    2700 00158$:
                           2701 ;	../../Common/stack.c:651: else j++;
                           2702 ;	genPlus
                           2703 ;     genPlusIncr
   5DE0 0D                 2704 	inc	r5
                           2705 ;	Peephole 112.b	changed ljmp to sjmp
   5DE1 80 8B              2706 	sjmp	00160$
   5DE3                    2707 00162$:
                           2708 ;	../../Common/stack.c:653: if (next_layer != (LAYERS_MAX + 1))
                           2709 ;	genCmpEq
   5DE3 E5 10              2710 	mov	a,_bp
   5DE5 24 09              2711 	add	a,#0x09
   5DE7 F8                 2712 	mov	r0,a
                           2713 ;	gencjneshort
   5DE8 B6 05 02           2714 	cjne	@r0,#0x05,00287$
                           2715 ;	Peephole 112.b	changed ljmp to sjmp
   5DEB 80 60              2716 	sjmp	00166$
   5DED                    2717 00287$:
                           2718 ;	../../Common/stack.c:658: status = stack_module_check(i, next_layer, b);
                           2719 ;	genIpush
   5DED A8 10              2720 	mov	r0,_bp
   5DEF 08                 2721 	inc	r0
   5DF0 E6                 2722 	mov	a,@r0
   5DF1 C0 E0              2723 	push	acc
   5DF3 08                 2724 	inc	r0
   5DF4 E6                 2725 	mov	a,@r0
   5DF5 C0 E0              2726 	push	acc
   5DF7 08                 2727 	inc	r0
   5DF8 E6                 2728 	mov	a,@r0
   5DF9 C0 E0              2729 	push	acc
                           2730 ;	genIpush
   5DFB E5 10              2731 	mov	a,_bp
   5DFD 24 09              2732 	add	a,#0x09
   5DFF F8                 2733 	mov	r0,a
   5E00 E6                 2734 	mov	a,@r0
   5E01 C0 E0              2735 	push	acc
                           2736 ;	genCall
   5E03 E5 10              2737 	mov	a,_bp
   5E05 24 04              2738 	add	a,#0x04
   5E07 F8                 2739 	mov	r0,a
   5E08 86 82              2740 	mov	dpl,@r0
   5E0A 12 5F 31           2741 	lcall	_stack_module_check
   5E0D AB 82              2742 	mov	r3,dpl
   5E0F E5 81              2743 	mov	a,sp
   5E11 24 FC              2744 	add	a,#0xfc
   5E13 F5 81              2745 	mov	sp,a
                           2746 ;	genAssign
   5E15 8B 02              2747 	mov	ar2,r3
                           2748 ;	../../Common/stack.c:659: if (status == pdTRUE)
                           2749 ;	genCmpEq
                           2750 ;	gencjneshort
                           2751 ;	Peephole 112.b	changed ljmp to sjmp
                           2752 ;	Peephole 198.b	optimized misc jump sequence
   5E17 BA 01 33           2753 	cjne	r2,#0x01,00166$
                           2754 ;	Peephole 200.b	removed redundant sjmp
                           2755 ;	Peephole 300	removed redundant label 00288$
                           2756 ;	Peephole 300	removed redundant label 00289$
                           2757 ;	../../Common/stack.c:661: stack_module_call(i, next_layer, b);
                           2758 ;	genIpush
   5E1A C0 02              2759 	push	ar2
   5E1C A8 10              2760 	mov	r0,_bp
   5E1E 08                 2761 	inc	r0
   5E1F E6                 2762 	mov	a,@r0
   5E20 C0 E0              2763 	push	acc
   5E22 08                 2764 	inc	r0
   5E23 E6                 2765 	mov	a,@r0
   5E24 C0 E0              2766 	push	acc
   5E26 08                 2767 	inc	r0
   5E27 E6                 2768 	mov	a,@r0
   5E28 C0 E0              2769 	push	acc
                           2770 ;	genIpush
   5E2A E5 10              2771 	mov	a,_bp
   5E2C 24 09              2772 	add	a,#0x09
   5E2E F8                 2773 	mov	r0,a
   5E2F E6                 2774 	mov	a,@r0
   5E30 C0 E0              2775 	push	acc
                           2776 ;	genCall
   5E32 E5 10              2777 	mov	a,_bp
   5E34 24 04              2778 	add	a,#0x04
   5E36 F8                 2779 	mov	r0,a
   5E37 86 82              2780 	mov	dpl,@r0
   5E39 12 5E 7F           2781 	lcall	_stack_module_call
   5E3C E5 81              2782 	mov	a,sp
   5E3E 24 FC              2783 	add	a,#0xfc
   5E40 F5 81              2784 	mov	sp,a
   5E42 D0 02              2785 	pop	ar2
                           2786 ;	../../Common/stack.c:662: b = 0;
                           2787 ;	genAssign
   5E44 A8 10              2788 	mov	r0,_bp
   5E46 08                 2789 	inc	r0
   5E47 E4                 2790 	clr	a
   5E48 F6                 2791 	mov	@r0,a
   5E49 08                 2792 	inc	r0
   5E4A F6                 2793 	mov	@r0,a
   5E4B 08                 2794 	inc	r0
   5E4C F6                 2795 	mov	@r0,a
   5E4D                    2796 00166$:
                           2797 ;	../../Common/stack.c:665: i++;
                           2798 ;	genPlus
   5E4D E5 10              2799 	mov	a,_bp
   5E4F 24 04              2800 	add	a,#0x04
   5E51 F8                 2801 	mov	r0,a
                           2802 ;     genPlusIncr
   5E52 06                 2803 	inc	@r0
   5E53 02 5D 17           2804 	ljmp	00168$
   5E56                    2805 00172$:
                           2806 ;	../../Common/stack.c:669: if (status != pdTRUE)
                           2807 ;	genCmpEq
                           2808 ;	gencjneshort
   5E56 BA 01 02           2809 	cjne	r2,#0x01,00290$
                           2810 ;	Peephole 112.b	changed ljmp to sjmp
   5E59 80 1E              2811 	sjmp	00184$
   5E5B                    2812 00290$:
                           2813 ;	../../Common/stack.c:683: if (b != 0) stack_buffer_free(b);
                           2814 ;	genCmpEq
   5E5B A8 10              2815 	mov	r0,_bp
   5E5D 08                 2816 	inc	r0
                           2817 ;	gencjneshort
   5E5E B6 00 0A           2818 	cjne	@r0,#0x00,00291$
   5E61 08                 2819 	inc	r0
   5E62 B6 00 06           2820 	cjne	@r0,#0x00,00291$
   5E65 08                 2821 	inc	r0
   5E66 B6 00 02           2822 	cjne	@r0,#0x00,00291$
                           2823 ;	Peephole 112.b	changed ljmp to sjmp
   5E69 80 0E              2824 	sjmp	00184$
   5E6B                    2825 00291$:
                           2826 ;	genCall
   5E6B A8 10              2827 	mov	r0,_bp
   5E6D 08                 2828 	inc	r0
   5E6E 86 82              2829 	mov	dpl,@r0
   5E70 08                 2830 	inc	r0
   5E71 86 83              2831 	mov	dph,@r0
   5E73 08                 2832 	inc	r0
   5E74 86 F0              2833 	mov	b,@r0
   5E76 12 61 FA           2834 	lcall	_stack_buffer_free
   5E79                    2835 00184$:
   5E79 85 10 81           2836 	mov	sp,_bp
   5E7C D0 10              2837 	pop	_bp
   5E7E 22                 2838 	ret
                           2839 ;------------------------------------------------------------
                           2840 ;Allocation info for local variables in function 'stack_module_call'
                           2841 ;------------------------------------------------------------
                           2842 ;layer                     Allocated to stack - offset -3
                           2843 ;b                         Allocated to stack - offset -6
                           2844 ;stack_id                  Allocated to registers r2 
                           2845 ;i                         Allocated to registers r4 
                           2846 ;found                     Allocated to registers r3 
                           2847 ;------------------------------------------------------------
                           2848 ;	../../Common/stack.c:698: void stack_module_call(uint8_t stack_id, uint8_t layer, buffer_t *b)
                           2849 ;	-----------------------------------------
                           2850 ;	 function stack_module_call
                           2851 ;	-----------------------------------------
   5E7F                    2852 _stack_module_call:
   5E7F C0 10              2853 	push	_bp
   5E81 85 81 10           2854 	mov	_bp,sp
                           2855 ;	genReceive
   5E84 AA 82              2856 	mov	r2,dpl
                           2857 ;	../../Common/stack.c:701: uint8_t found = 0;
                           2858 ;	genAssign
   5E86 7B 00              2859 	mov	r3,#0x00
                           2860 ;	../../Common/stack.c:702: if (layer < stacks[stack_id].layers)
                           2861 ;	genMult
                           2862 ;	genMultOneByte
   5E88 EA                 2863 	mov	a,r2
   5E89 75 F0 05           2864 	mov	b,#0x05
   5E8C A4                 2865 	mul	ab
                           2866 ;	genPlus
   5E8D FA                 2867 	mov	r2,a
                           2868 ;	Peephole 177.b	removed redundant mov
   5E8E 24 DD              2869 	add	a,#_stacks
   5E90 F5 82              2870 	mov	dpl,a
                           2871 ;	Peephole 181	changed mov to clr
   5E92 E4                 2872 	clr	a
   5E93 34 F0              2873 	addc	a,#(_stacks >> 8)
   5E95 F5 83              2874 	mov	dph,a
                           2875 ;	genPointerGet
                           2876 ;	genFarPointerGet
   5E97 E0                 2877 	movx	a,@dptr
   5E98 FC                 2878 	mov	r4,a
                           2879 ;	genCmpLt
   5E99 A8 10              2880 	mov	r0,_bp
   5E9B 18                 2881 	dec	r0
   5E9C 18                 2882 	dec	r0
   5E9D 18                 2883 	dec	r0
                           2884 ;	genCmp
   5E9E C3                 2885 	clr	c
   5E9F E6                 2886 	mov	a,@r0
   5EA0 9C                 2887 	subb	a,r4
                           2888 ;	genIfxJump
   5EA1 40 03              2889 	jc	00118$
   5EA3 02 5F 2E           2890 	ljmp	00111$
   5EA6                    2891 00118$:
                           2892 ;	../../Common/stack.c:705: while(modules[i].id)
                           2893 ;	genPlus
                           2894 ;	Peephole 236.g	used r2 instead of ar2
   5EA6 EA                 2895 	mov	a,r2
   5EA7 24 DD              2896 	add	a,#_stacks
   5EA9 FA                 2897 	mov	r2,a
                           2898 ;	Peephole 181	changed mov to clr
   5EAA E4                 2899 	clr	a
   5EAB 34 F0              2900 	addc	a,#(_stacks >> 8)
   5EAD FC                 2901 	mov	r4,a
                           2902 ;	genPlus
                           2903 ;     genPlusIncr
   5EAE 0A                 2904 	inc	r2
   5EAF BA 00 01           2905 	cjne	r2,#0x00,00119$
   5EB2 0C                 2906 	inc	r4
   5EB3                    2907 00119$:
                           2908 ;	genAssign
   5EB3 A8 10              2909 	mov	r0,_bp
   5EB5 18                 2910 	dec	r0
   5EB6 18                 2911 	dec	r0
   5EB7 18                 2912 	dec	r0
                           2913 ;	genPlus
                           2914 ;	peephole 177.g	optimized mov sequence
   5EB8 E6                 2915 	mov	a,@r0
                           2916 ;	Peephole 236.i	used r5 instead of ar5
   5EB9 FD                 2917 	mov	r5,a
                           2918 ;	Peephole 236.a	used r2 instead of ar2
   5EBA 2A                 2919 	add	a,r2
   5EBB F5 82              2920 	mov	dpl,a
                           2921 ;	Peephole 181	changed mov to clr
   5EBD E4                 2922 	clr	a
                           2923 ;	Peephole 236.b	used r4 instead of ar4
   5EBE 3C                 2924 	addc	a,r4
   5EBF F5 83              2925 	mov	dph,a
                           2926 ;	genPointerGet
                           2927 ;	genFarPointerGet
   5EC1 E0                 2928 	movx	a,@dptr
   5EC2 FA                 2929 	mov	r2,a
                           2930 ;	genAssign
   5EC3 7C 00              2931 	mov	r4,#0x00
   5EC5                    2932 00104$:
                           2933 ;	genMult
                           2934 ;	genMultOneByte
   5EC5 EC                 2935 	mov	a,r4
   5EC6 75 F0 0D           2936 	mov	b,#0x0D
   5EC9 A4                 2937 	mul	ab
                           2938 ;	genPlus
   5ECA 24 A6              2939 	add	a,#_modules
   5ECC FD                 2940 	mov	r5,a
   5ECD 74 F0              2941 	mov	a,#(_modules >> 8)
   5ECF 35 F0              2942 	addc	a,b
   5ED1 FE                 2943 	mov	r6,a
                           2944 ;	genPlus
                           2945 ;     genPlusIncr
   5ED2 74 08              2946 	mov	a,#0x08
                           2947 ;	Peephole 236.a	used r5 instead of ar5
   5ED4 2D                 2948 	add	a,r5
   5ED5 F5 82              2949 	mov	dpl,a
                           2950 ;	Peephole 181	changed mov to clr
   5ED7 E4                 2951 	clr	a
                           2952 ;	Peephole 236.b	used r6 instead of ar6
   5ED8 3E                 2953 	addc	a,r6
   5ED9 F5 83              2954 	mov	dph,a
                           2955 ;	genPointerGet
                           2956 ;	genFarPointerGet
   5EDB E0                 2957 	movx	a,@dptr
                           2958 ;	genIfx
   5EDC FF                 2959 	mov	r7,a
                           2960 ;	Peephole 105	removed redundant mov
                           2961 ;	genIfxJump
                           2962 ;	Peephole 108.c	removed ljmp by inverse jump logic
   5EDD 60 3C              2963 	jz	00106$
                           2964 ;	Peephole 300	removed redundant label 00120$
                           2965 ;	../../Common/stack.c:707: if (modules[i].id == stacks[stack_id].module[layer])
                           2966 ;	genCmpEq
                           2967 ;	gencjneshort
   5EDF EF                 2968 	mov	a,r7
                           2969 ;	Peephole 112.b	changed ljmp to sjmp
                           2970 ;	Peephole 198.b	optimized misc jump sequence
   5EE0 B5 02 35           2971 	cjne	a,ar2,00102$
                           2972 ;	Peephole 200.b	removed redundant sjmp
                           2973 ;	Peephole 300	removed redundant label 00121$
                           2974 ;	Peephole 300	removed redundant label 00122$
                           2975 ;	../../Common/stack.c:709: found = 1;
                           2976 ;	genAssign
   5EE3 7B 01              2977 	mov	r3,#0x01
                           2978 ;	../../Common/stack.c:710: modules[i].handle(b);
                           2979 ;	genPlus
                           2980 ;     genPlusIncr
   5EE5 8D 82              2981 	mov	dpl,r5
   5EE7 8E 83              2982 	mov	dph,r6
   5EE9 A3                 2983 	inc	dptr
   5EEA A3                 2984 	inc	dptr
                           2985 ;	genPointerGet
                           2986 ;	genFarPointerGet
   5EEB E0                 2987 	movx	a,@dptr
   5EEC FD                 2988 	mov	r5,a
   5EED A3                 2989 	inc	dptr
   5EEE E0                 2990 	movx	a,@dptr
   5EEF FE                 2991 	mov	r6,a
                           2992 ;	genPcall
   5EF0 C0 03              2993 	push	ar3
   5EF2 C0 05              2994 	push	ar5
   5EF4 C0 06              2995 	push	ar6
   5EF6 74 10              2996 	mov	a,#00123$
   5EF8 C0 E0              2997 	push	acc
   5EFA 74 5F              2998 	mov	a,#(00123$ >> 8)
   5EFC C0 E0              2999 	push	acc
   5EFE C0 05              3000 	push	ar5
   5F00 C0 06              3001 	push	ar6
   5F02 E5 10              3002 	mov	a,_bp
   5F04 24 FA              3003 	add	a,#0xfffffffa
   5F06 F8                 3004 	mov	r0,a
   5F07 86 82              3005 	mov	dpl,@r0
   5F09 08                 3006 	inc	r0
   5F0A 86 83              3007 	mov	dph,@r0
   5F0C 08                 3008 	inc	r0
   5F0D 86 F0              3009 	mov	b,@r0
   5F0F 22                 3010 	ret
   5F10                    3011 00123$:
   5F10 D0 06              3012 	pop	ar6
   5F12 D0 05              3013 	pop	ar5
   5F14 D0 03              3014 	pop	ar3
                           3015 ;	../../Common/stack.c:711: break;
                           3016 ;	Peephole 112.b	changed ljmp to sjmp
   5F16 80 03              3017 	sjmp	00106$
   5F18                    3018 00102$:
                           3019 ;	../../Common/stack.c:713: else i++;
                           3020 ;	genPlus
                           3021 ;     genPlusIncr
   5F18 0C                 3022 	inc	r4
                           3023 ;	Peephole 112.b	changed ljmp to sjmp
   5F19 80 AA              3024 	sjmp	00104$
   5F1B                    3025 00106$:
                           3026 ;	../../Common/stack.c:715: if (!found)
                           3027 ;	genIfx
   5F1B EB                 3028 	mov	a,r3
                           3029 ;	genIfxJump
                           3030 ;	Peephole 108.b	removed ljmp by inverse jump logic
   5F1C 70 10              3031 	jnz	00111$
                           3032 ;	Peephole 300	removed redundant label 00124$
                           3033 ;	../../Common/stack.c:720: stack_buffer_free(b);
                           3034 ;	genCall
   5F1E E5 10              3035 	mov	a,_bp
   5F20 24 FA              3036 	add	a,#0xfffffffa
   5F22 F8                 3037 	mov	r0,a
   5F23 86 82              3038 	mov	dpl,@r0
   5F25 08                 3039 	inc	r0
   5F26 86 83              3040 	mov	dph,@r0
   5F28 08                 3041 	inc	r0
   5F29 86 F0              3042 	mov	b,@r0
   5F2B 12 61 FA           3043 	lcall	_stack_buffer_free
   5F2E                    3044 00111$:
   5F2E D0 10              3045 	pop	_bp
   5F30 22                 3046 	ret
                           3047 ;------------------------------------------------------------
                           3048 ;Allocation info for local variables in function 'stack_module_check'
                           3049 ;------------------------------------------------------------
                           3050 ;layer                     Allocated to stack - offset -3
                           3051 ;b                         Allocated to stack - offset -6
                           3052 ;stack_id                  Allocated to registers r2 
                           3053 ;i                         Allocated to registers r3 
                           3054 ;found                     Allocated to registers 
                           3055 ;------------------------------------------------------------
                           3056 ;	../../Common/stack.c:732: portCHAR stack_module_check(uint8_t stack_id, uint8_t layer, buffer_t *b)
                           3057 ;	-----------------------------------------
                           3058 ;	 function stack_module_check
                           3059 ;	-----------------------------------------
   5F31                    3060 _stack_module_check:
   5F31 C0 10              3061 	push	_bp
   5F33 85 81 10           3062 	mov	_bp,sp
                           3063 ;	genReceive
                           3064 ;	../../Common/stack.c:737: if (layer < stacks[stack_id].layers)
                           3065 ;	genMult
                           3066 ;	genMultOneByte
                           3067 ;	peephole 177.g	optimized mov sequence
   5F36 E5 82              3068 	mov	a,dpl
   5F38 FA                 3069 	mov	r2,a
   5F39 75 F0 05           3070 	mov	b,#0x05
   5F3C A4                 3071 	mul	ab
                           3072 ;	genPlus
   5F3D FA                 3073 	mov	r2,a
                           3074 ;	Peephole 177.b	removed redundant mov
   5F3E 24 DD              3075 	add	a,#_stacks
   5F40 F5 82              3076 	mov	dpl,a
                           3077 ;	Peephole 181	changed mov to clr
   5F42 E4                 3078 	clr	a
   5F43 34 F0              3079 	addc	a,#(_stacks >> 8)
   5F45 F5 83              3080 	mov	dph,a
                           3081 ;	genPointerGet
                           3082 ;	genFarPointerGet
   5F47 E0                 3083 	movx	a,@dptr
   5F48 FB                 3084 	mov	r3,a
                           3085 ;	genCmpLt
   5F49 A8 10              3086 	mov	r0,_bp
   5F4B 18                 3087 	dec	r0
   5F4C 18                 3088 	dec	r0
   5F4D 18                 3089 	dec	r0
                           3090 ;	genCmp
   5F4E C3                 3091 	clr	c
   5F4F E6                 3092 	mov	a,@r0
   5F50 9B                 3093 	subb	a,r3
                           3094 ;	genIfxJump
   5F51 40 03              3095 	jc	00115$
   5F53 02 5F C7           3096 	ljmp	00108$
   5F56                    3097 00115$:
                           3098 ;	../../Common/stack.c:740: while(modules[i].id)
                           3099 ;	genPlus
                           3100 ;	Peephole 236.g	used r2 instead of ar2
   5F56 EA                 3101 	mov	a,r2
   5F57 24 DD              3102 	add	a,#_stacks
   5F59 FA                 3103 	mov	r2,a
                           3104 ;	Peephole 181	changed mov to clr
   5F5A E4                 3105 	clr	a
   5F5B 34 F0              3106 	addc	a,#(_stacks >> 8)
   5F5D FB                 3107 	mov	r3,a
                           3108 ;	genPlus
                           3109 ;     genPlusIncr
   5F5E 0A                 3110 	inc	r2
   5F5F BA 00 01           3111 	cjne	r2,#0x00,00116$
   5F62 0B                 3112 	inc	r3
   5F63                    3113 00116$:
                           3114 ;	genAssign
   5F63 A8 10              3115 	mov	r0,_bp
   5F65 18                 3116 	dec	r0
   5F66 18                 3117 	dec	r0
   5F67 18                 3118 	dec	r0
                           3119 ;	genPlus
                           3120 ;	peephole 177.g	optimized mov sequence
   5F68 E6                 3121 	mov	a,@r0
                           3122 ;	Peephole 236.i	used r4 instead of ar4
   5F69 FC                 3123 	mov	r4,a
                           3124 ;	Peephole 236.a	used r2 instead of ar2
   5F6A 2A                 3125 	add	a,r2
   5F6B F5 82              3126 	mov	dpl,a
                           3127 ;	Peephole 181	changed mov to clr
   5F6D E4                 3128 	clr	a
                           3129 ;	Peephole 236.b	used r3 instead of ar3
   5F6E 3B                 3130 	addc	a,r3
   5F6F F5 83              3131 	mov	dph,a
                           3132 ;	genPointerGet
                           3133 ;	genFarPointerGet
   5F71 E0                 3134 	movx	a,@dptr
   5F72 FA                 3135 	mov	r2,a
                           3136 ;	genAssign
   5F73 7B 00              3137 	mov	r3,#0x00
   5F75                    3138 00104$:
                           3139 ;	genMult
                           3140 ;	genMultOneByte
   5F75 EB                 3141 	mov	a,r3
   5F76 75 F0 0D           3142 	mov	b,#0x0D
   5F79 A4                 3143 	mul	ab
                           3144 ;	genPlus
   5F7A 24 A6              3145 	add	a,#_modules
   5F7C FC                 3146 	mov	r4,a
   5F7D 74 F0              3147 	mov	a,#(_modules >> 8)
   5F7F 35 F0              3148 	addc	a,b
   5F81 FD                 3149 	mov	r5,a
                           3150 ;	genPlus
                           3151 ;     genPlusIncr
   5F82 74 08              3152 	mov	a,#0x08
                           3153 ;	Peephole 236.a	used r4 instead of ar4
   5F84 2C                 3154 	add	a,r4
   5F85 F5 82              3155 	mov	dpl,a
                           3156 ;	Peephole 181	changed mov to clr
   5F87 E4                 3157 	clr	a
                           3158 ;	Peephole 236.b	used r5 instead of ar5
   5F88 3D                 3159 	addc	a,r5
   5F89 F5 83              3160 	mov	dph,a
                           3161 ;	genPointerGet
                           3162 ;	genFarPointerGet
   5F8B E0                 3163 	movx	a,@dptr
                           3164 ;	genIfx
   5F8C FE                 3165 	mov	r6,a
                           3166 ;	Peephole 105	removed redundant mov
                           3167 ;	genIfxJump
                           3168 ;	Peephole 108.c	removed ljmp by inverse jump logic
   5F8D 60 38              3169 	jz	00108$
                           3170 ;	Peephole 300	removed redundant label 00117$
                           3171 ;	../../Common/stack.c:742: if (modules[i].id == stacks[stack_id].module[layer])
                           3172 ;	genCmpEq
                           3173 ;	gencjneshort
   5F8F EE                 3174 	mov	a,r6
                           3175 ;	Peephole 112.b	changed ljmp to sjmp
                           3176 ;	Peephole 198.b	optimized misc jump sequence
   5F90 B5 02 31           3177 	cjne	a,ar2,00102$
                           3178 ;	Peephole 200.b	removed redundant sjmp
                           3179 ;	Peephole 300	removed redundant label 00118$
                           3180 ;	Peephole 300	removed redundant label 00119$
                           3181 ;	../../Common/stack.c:745: return modules[i].check(b);
                           3182 ;	genPlus
                           3183 ;     genPlusIncr
   5F93 8C 82              3184 	mov	dpl,r4
   5F95 8D 83              3185 	mov	dph,r5
   5F97 A3                 3186 	inc	dptr
   5F98 A3                 3187 	inc	dptr
   5F99 A3                 3188 	inc	dptr
   5F9A A3                 3189 	inc	dptr
                           3190 ;	genPointerGet
                           3191 ;	genFarPointerGet
   5F9B E0                 3192 	movx	a,@dptr
   5F9C FC                 3193 	mov	r4,a
   5F9D A3                 3194 	inc	dptr
   5F9E E0                 3195 	movx	a,@dptr
   5F9F FD                 3196 	mov	r5,a
                           3197 ;	genPcall
   5FA0 C0 05              3198 	push	ar5
   5FA2 74 BC              3199 	mov	a,#00120$
   5FA4 C0 E0              3200 	push	acc
   5FA6 74 5F              3201 	mov	a,#(00120$ >> 8)
   5FA8 C0 E0              3202 	push	acc
   5FAA C0 04              3203 	push	ar4
   5FAC C0 05              3204 	push	ar5
   5FAE E5 10              3205 	mov	a,_bp
   5FB0 24 FA              3206 	add	a,#0xfffffffa
   5FB2 F8                 3207 	mov	r0,a
   5FB3 86 82              3208 	mov	dpl,@r0
   5FB5 08                 3209 	inc	r0
   5FB6 86 83              3210 	mov	dph,@r0
   5FB8 08                 3211 	inc	r0
   5FB9 86 F0              3212 	mov	b,@r0
   5FBB 22                 3213 	ret
   5FBC                    3214 00120$:
   5FBC AC 82              3215 	mov	r4,dpl
   5FBE D0 05              3216 	pop	ar5
                           3217 ;	genRet
   5FC0 8C 82              3218 	mov	dpl,r4
                           3219 ;	Peephole 112.b	changed ljmp to sjmp
   5FC2 80 06              3220 	sjmp	00109$
   5FC4                    3221 00102$:
                           3222 ;	../../Common/stack.c:747: else i++;
                           3223 ;	genPlus
                           3224 ;     genPlusIncr
   5FC4 0B                 3225 	inc	r3
                           3226 ;	Peephole 112.b	changed ljmp to sjmp
   5FC5 80 AE              3227 	sjmp	00104$
   5FC7                    3228 00108$:
                           3229 ;	../../Common/stack.c:750: return pdFALSE;
                           3230 ;	genRet
   5FC7 75 82 00           3231 	mov	dpl,#0x00
   5FCA                    3232 00109$:
   5FCA D0 10              3233 	pop	_bp
   5FCC 22                 3234 	ret
                           3235 ;------------------------------------------------------------
                           3236 ;Allocation info for local variables in function 'stack_buffer_get'
                           3237 ;------------------------------------------------------------
                           3238 ;blocktime                 Allocated to stack - offset 1
                           3239 ;b                         Allocated to stack - offset 3
                           3240 ;sloc0                     Allocated to stack - offset 6
                           3241 ;------------------------------------------------------------
                           3242 ;	../../Common/stack.c:760: buffer_t* stack_buffer_get ( portTickType blocktime )
                           3243 ;	-----------------------------------------
                           3244 ;	 function stack_buffer_get
                           3245 ;	-----------------------------------------
   5FCD                    3246 _stack_buffer_get:
   5FCD C0 10              3247 	push	_bp
   5FCF 85 81 10           3248 	mov	_bp,sp
                           3249 ;     genReceive
   5FD2 C0 82              3250 	push	dpl
   5FD4 C0 83              3251 	push	dph
   5FD6 E5 81              3252 	mov	a,sp
   5FD8 24 07              3253 	add	a,#0x07
   5FDA F5 81              3254 	mov	sp,a
                           3255 ;	../../Common/stack.c:764: if (xQueueReceive( buffers, &( b ), 0) == pdTRUE)
                           3256 ;	genAddrOf
   5FDC E5 10              3257 	mov	a,_bp
   5FDE 24 03              3258 	add	a,#0x03
   5FE0 FC                 3259 	mov	r4,a
                           3260 ;	genCast
   5FE1 7D 00              3261 	mov	r5,#0x00
   5FE3 7E 40              3262 	mov	r6,#0x40
                           3263 ;	genAssign
   5FE5 90 EF B8           3264 	mov	dptr,#_buffers
   5FE8 E0                 3265 	movx	a,@dptr
   5FE9 FF                 3266 	mov	r7,a
   5FEA A3                 3267 	inc	dptr
   5FEB E0                 3268 	movx	a,@dptr
   5FEC FA                 3269 	mov	r2,a
   5FED A3                 3270 	inc	dptr
   5FEE E0                 3271 	movx	a,@dptr
   5FEF FB                 3272 	mov	r3,a
                           3273 ;	genIpush
                           3274 ;	Peephole 181	changed mov to clr
   5FF0 E4                 3275 	clr	a
   5FF1 C0 E0              3276 	push	acc
   5FF3 C0 E0              3277 	push	acc
                           3278 ;	genIpush
   5FF5 C0 04              3279 	push	ar4
   5FF7 C0 05              3280 	push	ar5
   5FF9 C0 06              3281 	push	ar6
                           3282 ;	genCall
   5FFB 8F 82              3283 	mov	dpl,r7
   5FFD 8A 83              3284 	mov	dph,r2
   5FFF 8B F0              3285 	mov	b,r3
   6001 12 23 5A           3286 	lcall	_xQueueReceive
   6004 AA 82              3287 	mov	r2,dpl
   6006 E5 81              3288 	mov	a,sp
   6008 24 FB              3289 	add	a,#0xfb
   600A F5 81              3290 	mov	sp,a
                           3291 ;	genCmpEq
                           3292 ;	gencjneshort
                           3293 ;	Peephole 112.b	changed ljmp to sjmp
                           3294 ;	Peephole 198.b	optimized misc jump sequence
   600C BA 01 6B           3295 	cjne	r2,#0x01,00109$
                           3296 ;	Peephole 200.b	removed redundant sjmp
                           3297 ;	Peephole 300	removed redundant label 00117$
                           3298 ;	Peephole 300	removed redundant label 00118$
                           3299 ;	../../Common/stack.c:766: b->options.type = BUFFER_DATA;
                           3300 ;	genAssign
   600F A8 10              3301 	mov	r0,_bp
   6011 08                 3302 	inc	r0
   6012 08                 3303 	inc	r0
   6013 08                 3304 	inc	r0
   6014 86 02              3305 	mov	ar2,@r0
   6016 08                 3306 	inc	r0
   6017 86 03              3307 	mov	ar3,@r0
   6019 08                 3308 	inc	r0
   601A 86 04              3309 	mov	ar4,@r0
                           3310 ;	genPlus
                           3311 ;     genPlusIncr
   601C 74 26              3312 	mov	a,#0x26
                           3313 ;	Peephole 236.a	used r2 instead of ar2
   601E 2A                 3314 	add	a,r2
   601F FD                 3315 	mov	r5,a
                           3316 ;	Peephole 181	changed mov to clr
   6020 E4                 3317 	clr	a
                           3318 ;	Peephole 236.b	used r3 instead of ar3
   6021 3B                 3319 	addc	a,r3
   6022 FE                 3320 	mov	r6,a
   6023 8C 07              3321 	mov	ar7,r4
                           3322 ;	genPointerSet
                           3323 ;	genGenPointerSet
   6025 8D 82              3324 	mov	dpl,r5
   6027 8E 83              3325 	mov	dph,r6
   6029 8F F0              3326 	mov	b,r7
                           3327 ;	Peephole 181	changed mov to clr
   602B E4                 3328 	clr	a
   602C 12 DF B7           3329 	lcall	__gptrput
                           3330 ;	../../Common/stack.c:767: b->dir = BUFFER_DOWN;
                           3331 ;	genPlus
                           3332 ;     genPlusIncr
   602F 74 1F              3333 	mov	a,#0x1F
                           3334 ;	Peephole 236.a	used r2 instead of ar2
   6031 2A                 3335 	add	a,r2
   6032 FD                 3336 	mov	r5,a
                           3337 ;	Peephole 181	changed mov to clr
   6033 E4                 3338 	clr	a
                           3339 ;	Peephole 236.b	used r3 instead of ar3
   6034 3B                 3340 	addc	a,r3
   6035 FE                 3341 	mov	r6,a
   6036 8C 07              3342 	mov	ar7,r4
                           3343 ;	genPointerSet
                           3344 ;	genGenPointerSet
   6038 8D 82              3345 	mov	dpl,r5
   603A 8E 83              3346 	mov	dph,r6
   603C 8F F0              3347 	mov	b,r7
   603E 74 01              3348 	mov	a,#0x01
   6040 12 DF B7           3349 	lcall	__gptrput
                           3350 ;	../../Common/stack.c:768: b->socket = 0;
                           3351 ;	genPointerSet
                           3352 ;	genGenPointerSet
   6043 8A 82              3353 	mov	dpl,r2
   6045 8B 83              3354 	mov	dph,r3
   6047 8C F0              3355 	mov	b,r4
                           3356 ;	Peephole 181	changed mov to clr
   6049 E4                 3357 	clr	a
   604A 12 DF B7           3358 	lcall	__gptrput
   604D A3                 3359 	inc	dptr
                           3360 ;	Peephole 181	changed mov to clr
   604E E4                 3361 	clr	a
   604F 12 DF B7           3362 	lcall	__gptrput
   6052 A3                 3363 	inc	dptr
                           3364 ;	Peephole 181	changed mov to clr
   6053 E4                 3365 	clr	a
   6054 12 DF B7           3366 	lcall	__gptrput
                           3367 ;	../../Common/stack.c:769: b->options.lowpan_compressed=0;
                           3368 ;	genPlus
                           3369 ;     genPlusIncr
   6057 74 26              3370 	mov	a,#0x26
                           3371 ;	Peephole 236.a	used r2 instead of ar2
   6059 2A                 3372 	add	a,r2
   605A FD                 3373 	mov	r5,a
                           3374 ;	Peephole 181	changed mov to clr
   605B E4                 3375 	clr	a
                           3376 ;	Peephole 236.b	used r3 instead of ar3
   605C 3B                 3377 	addc	a,r3
   605D FE                 3378 	mov	r6,a
   605E 8C 07              3379 	mov	ar7,r4
                           3380 ;	genPlus
                           3381 ;     genPlusIncr
   6060 74 05              3382 	mov	a,#0x05
                           3383 ;	Peephole 236.a	used r5 instead of ar5
   6062 2D                 3384 	add	a,r5
   6063 FD                 3385 	mov	r5,a
                           3386 ;	Peephole 181	changed mov to clr
   6064 E4                 3387 	clr	a
                           3388 ;	Peephole 236.b	used r6 instead of ar6
   6065 3E                 3389 	addc	a,r6
   6066 FE                 3390 	mov	r6,a
                           3391 ;	genPointerSet
                           3392 ;	genGenPointerSet
   6067 8D 82              3393 	mov	dpl,r5
   6069 8E 83              3394 	mov	dph,r6
   606B 8F F0              3395 	mov	b,r7
                           3396 ;	Peephole 181	changed mov to clr
   606D E4                 3397 	clr	a
   606E 12 DF B7           3398 	lcall	__gptrput
                           3399 ;	../../Common/stack.c:770: return b;
                           3400 ;	genRet
   6071 8A 82              3401 	mov	dpl,r2
   6073 8B 83              3402 	mov	dph,r3
   6075 8C F0              3403 	mov	b,r4
   6077 02 61 F4           3404 	ljmp	00111$
   607A                    3405 00109$:
                           3406 ;	../../Common/stack.c:772: else if (n_buffers < STACK_BUFFERS_MAX)
                           3407 ;	genAssign
   607A 90 EF BB           3408 	mov	dptr,#_n_buffers
   607D E0                 3409 	movx	a,@dptr
   607E FA                 3410 	mov	r2,a
                           3411 ;	genCmpLt
                           3412 ;	genCmp
   607F BA 08 00           3413 	cjne	r2,#0x08,00119$
   6082                    3414 00119$:
                           3415 ;	genIfxJump
   6082 40 03              3416 	jc	00120$
   6084 02 61 35           3417 	ljmp	00106$
   6087                    3418 00120$:
                           3419 ;	../../Common/stack.c:774: b = pvPortMalloc(sizeof(buffer_t)+BUFFER_SIZE);
                           3420 ;	genCall
                           3421 ;	Peephole 182.b	used 16 bit load of dptr
   6087 90 00 AE           3422 	mov	dptr,#0x00AE
   608A 12 36 8C           3423 	lcall	_pvPortMalloc
   608D AA 82              3424 	mov	r2,dpl
   608F AB 83              3425 	mov	r3,dph
   6091 AC F0              3426 	mov	r4,b
                           3427 ;	../../Common/stack.c:775: if (b)
                           3428 ;	genIfx
   6093 EA                 3429 	mov	a,r2
   6094 4B                 3430 	orl	a,r3
   6095 4C                 3431 	orl	a,r4
                           3432 ;	genIfxJump
   6096 70 03              3433 	jnz	00121$
   6098 02 61 EE           3434 	ljmp	00110$
   609B                    3435 00121$:
                           3436 ;	../../Common/stack.c:777: memset(b, 0, sizeof(buffer_t));
                           3437 ;	genAssign
   609B 8A 05              3438 	mov	ar5,r2
   609D 8B 06              3439 	mov	ar6,r3
   609F 8C 07              3440 	mov	ar7,r4
                           3441 ;	genIpush
   60A1 C0 02              3442 	push	ar2
   60A3 C0 03              3443 	push	ar3
   60A5 C0 04              3444 	push	ar4
   60A7 74 2E              3445 	mov	a,#0x2E
   60A9 C0 E0              3446 	push	acc
                           3447 ;	Peephole 181	changed mov to clr
   60AB E4                 3448 	clr	a
   60AC C0 E0              3449 	push	acc
                           3450 ;	genIpush
                           3451 ;	Peephole 181	changed mov to clr
   60AE E4                 3452 	clr	a
   60AF C0 E0              3453 	push	acc
                           3454 ;	genCall
   60B1 8D 82              3455 	mov	dpl,r5
   60B3 8E 83              3456 	mov	dph,r6
   60B5 8F F0              3457 	mov	b,r7
   60B7 12 E3 65           3458 	lcall	_memset
   60BA 15 81              3459 	dec	sp
   60BC 15 81              3460 	dec	sp
   60BE 15 81              3461 	dec	sp
   60C0 D0 04              3462 	pop	ar4
   60C2 D0 03              3463 	pop	ar3
   60C4 D0 02              3464 	pop	ar2
                           3465 ;	../../Common/stack.c:778: b->options.type = BUFFER_DATA;
                           3466 ;	genPlus
                           3467 ;     genPlusIncr
   60C6 74 26              3468 	mov	a,#0x26
                           3469 ;	Peephole 236.a	used r2 instead of ar2
   60C8 2A                 3470 	add	a,r2
   60C9 FD                 3471 	mov	r5,a
                           3472 ;	Peephole 181	changed mov to clr
   60CA E4                 3473 	clr	a
                           3474 ;	Peephole 236.b	used r3 instead of ar3
   60CB 3B                 3475 	addc	a,r3
   60CC FE                 3476 	mov	r6,a
   60CD 8C 07              3477 	mov	ar7,r4
                           3478 ;	genPointerSet
                           3479 ;	genGenPointerSet
   60CF 8D 82              3480 	mov	dpl,r5
   60D1 8E 83              3481 	mov	dph,r6
   60D3 8F F0              3482 	mov	b,r7
                           3483 ;	Peephole 181	changed mov to clr
   60D5 E4                 3484 	clr	a
   60D6 12 DF B7           3485 	lcall	__gptrput
                           3486 ;	../../Common/stack.c:779: b->dir = BUFFER_DOWN;
                           3487 ;	genPlus
                           3488 ;     genPlusIncr
   60D9 74 1F              3489 	mov	a,#0x1F
                           3490 ;	Peephole 236.a	used r2 instead of ar2
   60DB 2A                 3491 	add	a,r2
   60DC FD                 3492 	mov	r5,a
                           3493 ;	Peephole 181	changed mov to clr
   60DD E4                 3494 	clr	a
                           3495 ;	Peephole 236.b	used r3 instead of ar3
   60DE 3B                 3496 	addc	a,r3
   60DF FE                 3497 	mov	r6,a
   60E0 8C 07              3498 	mov	ar7,r4
                           3499 ;	genPointerSet
                           3500 ;	genGenPointerSet
   60E2 8D 82              3501 	mov	dpl,r5
   60E4 8E 83              3502 	mov	dph,r6
   60E6 8F F0              3503 	mov	b,r7
   60E8 74 01              3504 	mov	a,#0x01
   60EA 12 DF B7           3505 	lcall	__gptrput
                           3506 ;	../../Common/stack.c:780: b->size = BUFFER_SIZE;
                           3507 ;	genPlus
                           3508 ;     genPlusIncr
   60ED 74 24              3509 	mov	a,#0x24
                           3510 ;	Peephole 236.a	used r2 instead of ar2
   60EF 2A                 3511 	add	a,r2
   60F0 FD                 3512 	mov	r5,a
                           3513 ;	Peephole 181	changed mov to clr
   60F1 E4                 3514 	clr	a
                           3515 ;	Peephole 236.b	used r3 instead of ar3
   60F2 3B                 3516 	addc	a,r3
   60F3 FE                 3517 	mov	r6,a
   60F4 8C 07              3518 	mov	ar7,r4
                           3519 ;	genPointerSet
                           3520 ;	genGenPointerSet
   60F6 8D 82              3521 	mov	dpl,r5
   60F8 8E 83              3522 	mov	dph,r6
   60FA 8F F0              3523 	mov	b,r7
   60FC 74 80              3524 	mov	a,#0x80
   60FE 12 DF B7           3525 	lcall	__gptrput
   6101 A3                 3526 	inc	dptr
                           3527 ;	Peephole 181	changed mov to clr
   6102 E4                 3528 	clr	a
   6103 12 DF B7           3529 	lcall	__gptrput
                           3530 ;	../../Common/stack.c:781: b->options.lowpan_compressed=0;
                           3531 ;	genPlus
                           3532 ;     genPlusIncr
   6106 74 26              3533 	mov	a,#0x26
                           3534 ;	Peephole 236.a	used r2 instead of ar2
   6108 2A                 3535 	add	a,r2
   6109 FD                 3536 	mov	r5,a
                           3537 ;	Peephole 181	changed mov to clr
   610A E4                 3538 	clr	a
                           3539 ;	Peephole 236.b	used r3 instead of ar3
   610B 3B                 3540 	addc	a,r3
   610C FE                 3541 	mov	r6,a
   610D 8C 07              3542 	mov	ar7,r4
                           3543 ;	genPlus
                           3544 ;     genPlusIncr
   610F 74 05              3545 	mov	a,#0x05
                           3546 ;	Peephole 236.a	used r5 instead of ar5
   6111 2D                 3547 	add	a,r5
   6112 FD                 3548 	mov	r5,a
                           3549 ;	Peephole 181	changed mov to clr
   6113 E4                 3550 	clr	a
                           3551 ;	Peephole 236.b	used r6 instead of ar6
   6114 3E                 3552 	addc	a,r6
   6115 FE                 3553 	mov	r6,a
                           3554 ;	genPointerSet
                           3555 ;	genGenPointerSet
   6116 8D 82              3556 	mov	dpl,r5
   6118 8E 83              3557 	mov	dph,r6
   611A 8F F0              3558 	mov	b,r7
                           3559 ;	Peephole 181	changed mov to clr
   611C E4                 3560 	clr	a
   611D 12 DF B7           3561 	lcall	__gptrput
                           3562 ;	../../Common/stack.c:782: n_buffers++;
                           3563 ;	genAssign
   6120 90 EF BB           3564 	mov	dptr,#_n_buffers
   6123 E0                 3565 	movx	a,@dptr
   6124 FD                 3566 	mov	r5,a
                           3567 ;	genPlus
   6125 90 EF BB           3568 	mov	dptr,#_n_buffers
                           3569 ;     genPlusIncr
   6128 74 01              3570 	mov	a,#0x01
                           3571 ;	Peephole 236.a	used r5 instead of ar5
   612A 2D                 3572 	add	a,r5
   612B F0                 3573 	movx	@dptr,a
                           3574 ;	../../Common/stack.c:783: return b;
                           3575 ;	genRet
   612C 8A 82              3576 	mov	dpl,r2
   612E 8B 83              3577 	mov	dph,r3
   6130 8C F0              3578 	mov	b,r4
   6132 02 61 F4           3579 	ljmp	00111$
   6135                    3580 00106$:
                           3581 ;	../../Common/stack.c:786: else if (xQueueReceive( buffers, &( b ), blocktime / portTICK_RATE_MS) == pdTRUE)
                           3582 ;	genCast
   6135 A8 10              3583 	mov	r0,_bp
   6137 08                 3584 	inc	r0
   6138 86 02              3585 	mov	ar2,@r0
   613A 08                 3586 	inc	r0
   613B 86 03              3587 	mov	ar3,@r0
                           3588 ;	genCast
                           3589 ;	Peephole 3.c	changed mov to clr
   613D E4                 3590 	clr	a
   613E FC                 3591 	mov	r4,a
   613F FD                 3592 	mov	r5,a
   6140 E5 10              3593 	mov	a,_bp
   6142 24 06              3594 	add	a,#0x06
   6144 F8                 3595 	mov	r0,a
   6145 A6 02              3596 	mov	@r0,ar2
   6147 08                 3597 	inc	r0
   6148 A6 03              3598 	mov	@r0,ar3
                           3599 ;	genAddrOf
   614A E5 10              3600 	mov	a,_bp
   614C 24 03              3601 	add	a,#0x03
   614E FC                 3602 	mov	r4,a
                           3603 ;	genCast
   614F 7D 00              3604 	mov	r5,#0x00
   6151 7E 40              3605 	mov	r6,#0x40
                           3606 ;	genAssign
   6153 90 EF B8           3607 	mov	dptr,#_buffers
   6156 E0                 3608 	movx	a,@dptr
   6157 FF                 3609 	mov	r7,a
   6158 A3                 3610 	inc	dptr
   6159 E0                 3611 	movx	a,@dptr
   615A FA                 3612 	mov	r2,a
   615B A3                 3613 	inc	dptr
   615C E0                 3614 	movx	a,@dptr
   615D FB                 3615 	mov	r3,a
                           3616 ;	genIpush
   615E E5 10              3617 	mov	a,_bp
   6160 24 06              3618 	add	a,#0x06
   6162 F8                 3619 	mov	r0,a
   6163 E6                 3620 	mov	a,@r0
   6164 C0 E0              3621 	push	acc
   6166 08                 3622 	inc	r0
   6167 E6                 3623 	mov	a,@r0
   6168 C0 E0              3624 	push	acc
                           3625 ;	genIpush
   616A C0 04              3626 	push	ar4
   616C C0 05              3627 	push	ar5
   616E C0 06              3628 	push	ar6
                           3629 ;	genCall
   6170 8F 82              3630 	mov	dpl,r7
   6172 8A 83              3631 	mov	dph,r2
   6174 8B F0              3632 	mov	b,r3
   6176 12 23 5A           3633 	lcall	_xQueueReceive
   6179 AA 82              3634 	mov	r2,dpl
   617B E5 81              3635 	mov	a,sp
   617D 24 FB              3636 	add	a,#0xfb
   617F F5 81              3637 	mov	sp,a
                           3638 ;	genCmpEq
                           3639 ;	gencjneshort
                           3640 ;	Peephole 112.b	changed ljmp to sjmp
                           3641 ;	Peephole 198.b	optimized misc jump sequence
   6181 BA 01 6A           3642 	cjne	r2,#0x01,00110$
                           3643 ;	Peephole 200.b	removed redundant sjmp
                           3644 ;	Peephole 300	removed redundant label 00122$
                           3645 ;	Peephole 300	removed redundant label 00123$
                           3646 ;	../../Common/stack.c:788: b->options.type = BUFFER_DATA;
                           3647 ;	genAssign
   6184 A8 10              3648 	mov	r0,_bp
   6186 08                 3649 	inc	r0
   6187 08                 3650 	inc	r0
   6188 08                 3651 	inc	r0
   6189 86 02              3652 	mov	ar2,@r0
   618B 08                 3653 	inc	r0
   618C 86 03              3654 	mov	ar3,@r0
   618E 08                 3655 	inc	r0
   618F 86 04              3656 	mov	ar4,@r0
                           3657 ;	genPlus
                           3658 ;     genPlusIncr
   6191 74 26              3659 	mov	a,#0x26
                           3660 ;	Peephole 236.a	used r2 instead of ar2
   6193 2A                 3661 	add	a,r2
   6194 FD                 3662 	mov	r5,a
                           3663 ;	Peephole 181	changed mov to clr
   6195 E4                 3664 	clr	a
                           3665 ;	Peephole 236.b	used r3 instead of ar3
   6196 3B                 3666 	addc	a,r3
   6197 FE                 3667 	mov	r6,a
   6198 8C 07              3668 	mov	ar7,r4
                           3669 ;	genPointerSet
                           3670 ;	genGenPointerSet
   619A 8D 82              3671 	mov	dpl,r5
   619C 8E 83              3672 	mov	dph,r6
   619E 8F F0              3673 	mov	b,r7
                           3674 ;	Peephole 181	changed mov to clr
   61A0 E4                 3675 	clr	a
   61A1 12 DF B7           3676 	lcall	__gptrput
                           3677 ;	../../Common/stack.c:789: b->dir = BUFFER_DOWN;
                           3678 ;	genPlus
                           3679 ;     genPlusIncr
   61A4 74 1F              3680 	mov	a,#0x1F
                           3681 ;	Peephole 236.a	used r2 instead of ar2
   61A6 2A                 3682 	add	a,r2
   61A7 FD                 3683 	mov	r5,a
                           3684 ;	Peephole 181	changed mov to clr
   61A8 E4                 3685 	clr	a
                           3686 ;	Peephole 236.b	used r3 instead of ar3
   61A9 3B                 3687 	addc	a,r3
   61AA FE                 3688 	mov	r6,a
   61AB 8C 07              3689 	mov	ar7,r4
                           3690 ;	genPointerSet
                           3691 ;	genGenPointerSet
   61AD 8D 82              3692 	mov	dpl,r5
   61AF 8E 83              3693 	mov	dph,r6
   61B1 8F F0              3694 	mov	b,r7
   61B3 74 01              3695 	mov	a,#0x01
   61B5 12 DF B7           3696 	lcall	__gptrput
                           3697 ;	../../Common/stack.c:790: b->socket = 0;
                           3698 ;	genPointerSet
                           3699 ;	genGenPointerSet
   61B8 8A 82              3700 	mov	dpl,r2
   61BA 8B 83              3701 	mov	dph,r3
   61BC 8C F0              3702 	mov	b,r4
                           3703 ;	Peephole 181	changed mov to clr
   61BE E4                 3704 	clr	a
   61BF 12 DF B7           3705 	lcall	__gptrput
   61C2 A3                 3706 	inc	dptr
                           3707 ;	Peephole 181	changed mov to clr
   61C3 E4                 3708 	clr	a
   61C4 12 DF B7           3709 	lcall	__gptrput
   61C7 A3                 3710 	inc	dptr
                           3711 ;	Peephole 181	changed mov to clr
   61C8 E4                 3712 	clr	a
   61C9 12 DF B7           3713 	lcall	__gptrput
                           3714 ;	../../Common/stack.c:791: b->options.lowpan_compressed=0;
                           3715 ;	genPlus
                           3716 ;     genPlusIncr
   61CC 74 26              3717 	mov	a,#0x26
                           3718 ;	Peephole 236.a	used r2 instead of ar2
   61CE 2A                 3719 	add	a,r2
   61CF FD                 3720 	mov	r5,a
                           3721 ;	Peephole 181	changed mov to clr
   61D0 E4                 3722 	clr	a
                           3723 ;	Peephole 236.b	used r3 instead of ar3
   61D1 3B                 3724 	addc	a,r3
   61D2 FE                 3725 	mov	r6,a
   61D3 8C 07              3726 	mov	ar7,r4
                           3727 ;	genPlus
                           3728 ;     genPlusIncr
   61D5 74 05              3729 	mov	a,#0x05
                           3730 ;	Peephole 236.a	used r5 instead of ar5
   61D7 2D                 3731 	add	a,r5
   61D8 FD                 3732 	mov	r5,a
                           3733 ;	Peephole 181	changed mov to clr
   61D9 E4                 3734 	clr	a
                           3735 ;	Peephole 236.b	used r6 instead of ar6
   61DA 3E                 3736 	addc	a,r6
   61DB FE                 3737 	mov	r6,a
                           3738 ;	genPointerSet
                           3739 ;	genGenPointerSet
   61DC 8D 82              3740 	mov	dpl,r5
   61DE 8E 83              3741 	mov	dph,r6
   61E0 8F F0              3742 	mov	b,r7
                           3743 ;	Peephole 181	changed mov to clr
   61E2 E4                 3744 	clr	a
   61E3 12 DF B7           3745 	lcall	__gptrput
                           3746 ;	../../Common/stack.c:792: return b;
                           3747 ;	genRet
   61E6 8A 82              3748 	mov	dpl,r2
   61E8 8B 83              3749 	mov	dph,r3
   61EA 8C F0              3750 	mov	b,r4
                           3751 ;	Peephole 112.b	changed ljmp to sjmp
   61EC 80 06              3752 	sjmp	00111$
   61EE                    3753 00110$:
                           3754 ;	../../Common/stack.c:794: return 0;
                           3755 ;	genRet
                           3756 ;	Peephole 182.b	used 16 bit load of dptr
   61EE 90 00 00           3757 	mov	dptr,#0x0000
   61F1 75 F0 00           3758 	mov	b,#0x00
   61F4                    3759 00111$:
   61F4 85 10 81           3760 	mov	sp,_bp
   61F7 D0 10              3761 	pop	_bp
   61F9 22                 3762 	ret
                           3763 ;------------------------------------------------------------
                           3764 ;Allocation info for local variables in function 'stack_buffer_free'
                           3765 ;------------------------------------------------------------
                           3766 ;b                         Allocated to stack - offset 1
                           3767 ;------------------------------------------------------------
                           3768 ;	../../Common/stack.c:833: void stack_buffer_free ( buffer_t *b )
                           3769 ;	-----------------------------------------
                           3770 ;	 function stack_buffer_free
                           3771 ;	-----------------------------------------
   61FA                    3772 _stack_buffer_free:
   61FA C0 10              3773 	push	_bp
   61FC 85 81 10           3774 	mov	_bp,sp
                           3775 ;     genReceive
   61FF C0 82              3776 	push	dpl
   6201 C0 83              3777 	push	dph
   6203 C0 F0              3778 	push	b
                           3779 ;	../../Common/stack.c:835: b->buf_ptr = 0;
                           3780 ;	genAssign
   6205 A8 10              3781 	mov	r0,_bp
   6207 08                 3782 	inc	r0
   6208 86 02              3783 	mov	ar2,@r0
   620A 08                 3784 	inc	r0
   620B 86 03              3785 	mov	ar3,@r0
   620D 08                 3786 	inc	r0
   620E 86 04              3787 	mov	ar4,@r0
                           3788 ;	genPlus
                           3789 ;     genPlusIncr
   6210 74 20              3790 	mov	a,#0x20
                           3791 ;	Peephole 236.a	used r2 instead of ar2
   6212 2A                 3792 	add	a,r2
   6213 FD                 3793 	mov	r5,a
                           3794 ;	Peephole 181	changed mov to clr
   6214 E4                 3795 	clr	a
                           3796 ;	Peephole 236.b	used r3 instead of ar3
   6215 3B                 3797 	addc	a,r3
   6216 FE                 3798 	mov	r6,a
   6217 8C 07              3799 	mov	ar7,r4
                           3800 ;	genPointerSet
                           3801 ;	genGenPointerSet
   6219 8D 82              3802 	mov	dpl,r5
   621B 8E 83              3803 	mov	dph,r6
   621D 8F F0              3804 	mov	b,r7
                           3805 ;	Peephole 181	changed mov to clr
   621F E4                 3806 	clr	a
   6220 12 DF B7           3807 	lcall	__gptrput
   6223 A3                 3808 	inc	dptr
                           3809 ;	Peephole 181	changed mov to clr
   6224 E4                 3810 	clr	a
   6225 12 DF B7           3811 	lcall	__gptrput
                           3812 ;	../../Common/stack.c:836: b->buf_end = 0;
                           3813 ;	genPlus
                           3814 ;     genPlusIncr
   6228 74 22              3815 	mov	a,#0x22
                           3816 ;	Peephole 236.a	used r2 instead of ar2
   622A 2A                 3817 	add	a,r2
   622B FD                 3818 	mov	r5,a
                           3819 ;	Peephole 181	changed mov to clr
   622C E4                 3820 	clr	a
                           3821 ;	Peephole 236.b	used r3 instead of ar3
   622D 3B                 3822 	addc	a,r3
   622E FE                 3823 	mov	r6,a
   622F 8C 07              3824 	mov	ar7,r4
                           3825 ;	genPointerSet
                           3826 ;	genGenPointerSet
   6231 8D 82              3827 	mov	dpl,r5
   6233 8E 83              3828 	mov	dph,r6
   6235 8F F0              3829 	mov	b,r7
                           3830 ;	Peephole 181	changed mov to clr
   6237 E4                 3831 	clr	a
   6238 12 DF B7           3832 	lcall	__gptrput
   623B A3                 3833 	inc	dptr
                           3834 ;	Peephole 181	changed mov to clr
   623C E4                 3835 	clr	a
   623D 12 DF B7           3836 	lcall	__gptrput
                           3837 ;	../../Common/stack.c:837: b->socket = 0;
                           3838 ;	genPointerSet
                           3839 ;	genGenPointerSet
   6240 8A 82              3840 	mov	dpl,r2
   6242 8B 83              3841 	mov	dph,r3
   6244 8C F0              3842 	mov	b,r4
                           3843 ;	Peephole 181	changed mov to clr
   6246 E4                 3844 	clr	a
   6247 12 DF B7           3845 	lcall	__gptrput
   624A A3                 3846 	inc	dptr
                           3847 ;	Peephole 181	changed mov to clr
   624B E4                 3848 	clr	a
   624C 12 DF B7           3849 	lcall	__gptrput
   624F A3                 3850 	inc	dptr
                           3851 ;	Peephole 181	changed mov to clr
   6250 E4                 3852 	clr	a
   6251 12 DF B7           3853 	lcall	__gptrput
                           3854 ;	../../Common/stack.c:838: b->from = 0;
                           3855 ;	genPlus
                           3856 ;     genPlusIncr
   6254 74 1D              3857 	mov	a,#0x1D
                           3858 ;	Peephole 236.a	used r2 instead of ar2
   6256 2A                 3859 	add	a,r2
   6257 FD                 3860 	mov	r5,a
                           3861 ;	Peephole 181	changed mov to clr
   6258 E4                 3862 	clr	a
                           3863 ;	Peephole 236.b	used r3 instead of ar3
   6259 3B                 3864 	addc	a,r3
   625A FE                 3865 	mov	r6,a
   625B 8C 07              3866 	mov	ar7,r4
                           3867 ;	genPointerSet
                           3868 ;	genGenPointerSet
   625D 8D 82              3869 	mov	dpl,r5
   625F 8E 83              3870 	mov	dph,r6
   6261 8F F0              3871 	mov	b,r7
                           3872 ;	Peephole 181	changed mov to clr
   6263 E4                 3873 	clr	a
   6264 12 DF B7           3874 	lcall	__gptrput
                           3875 ;	../../Common/stack.c:839: b->to = 0;
                           3876 ;	genPlus
                           3877 ;     genPlusIncr
   6267 74 1E              3878 	mov	a,#0x1E
                           3879 ;	Peephole 236.a	used r2 instead of ar2
   6269 2A                 3880 	add	a,r2
   626A FD                 3881 	mov	r5,a
                           3882 ;	Peephole 181	changed mov to clr
   626B E4                 3883 	clr	a
                           3884 ;	Peephole 236.b	used r3 instead of ar3
   626C 3B                 3885 	addc	a,r3
   626D FE                 3886 	mov	r6,a
   626E 8C 07              3887 	mov	ar7,r4
                           3888 ;	genPointerSet
                           3889 ;	genGenPointerSet
   6270 8D 82              3890 	mov	dpl,r5
   6272 8E 83              3891 	mov	dph,r6
   6274 8F F0              3892 	mov	b,r7
                           3893 ;	Peephole 181	changed mov to clr
   6276 E4                 3894 	clr	a
   6277 12 DF B7           3895 	lcall	__gptrput
                           3896 ;	../../Common/stack.c:840: b->options.lowpan_compressed=0;
                           3897 ;	genPlus
                           3898 ;     genPlusIncr
   627A 74 26              3899 	mov	a,#0x26
                           3900 ;	Peephole 236.a	used r2 instead of ar2
   627C 2A                 3901 	add	a,r2
   627D FA                 3902 	mov	r2,a
                           3903 ;	Peephole 181	changed mov to clr
   627E E4                 3904 	clr	a
                           3905 ;	Peephole 236.b	used r3 instead of ar3
   627F 3B                 3906 	addc	a,r3
   6280 FB                 3907 	mov	r3,a
                           3908 ;	genPlus
                           3909 ;     genPlusIncr
   6281 74 05              3910 	mov	a,#0x05
                           3911 ;	Peephole 236.a	used r2 instead of ar2
   6283 2A                 3912 	add	a,r2
   6284 FA                 3913 	mov	r2,a
                           3914 ;	Peephole 181	changed mov to clr
   6285 E4                 3915 	clr	a
                           3916 ;	Peephole 236.b	used r3 instead of ar3
   6286 3B                 3917 	addc	a,r3
   6287 FB                 3918 	mov	r3,a
                           3919 ;	genPointerSet
                           3920 ;	genGenPointerSet
   6288 8A 82              3921 	mov	dpl,r2
   628A 8B 83              3922 	mov	dph,r3
   628C 8C F0              3923 	mov	b,r4
                           3924 ;	Peephole 181	changed mov to clr
   628E E4                 3925 	clr	a
   628F 12 DF B7           3926 	lcall	__gptrput
                           3927 ;	../../Common/stack.c:852: xQueueSend( buffers, ( void * ) &b, ( portTickType ) 0 );
                           3928 ;	genAddrOf
                           3929 ;	Peephole 212	reduced add sequence to inc
   6292 AA 10              3930 	mov	r2,_bp
   6294 0A                 3931 	inc	r2
                           3932 ;	genCast
   6295 7B 00              3933 	mov	r3,#0x00
   6297 7C 40              3934 	mov	r4,#0x40
                           3935 ;	genAssign
   6299 90 EF B8           3936 	mov	dptr,#_buffers
   629C E0                 3937 	movx	a,@dptr
   629D FD                 3938 	mov	r5,a
   629E A3                 3939 	inc	dptr
   629F E0                 3940 	movx	a,@dptr
   62A0 FE                 3941 	mov	r6,a
   62A1 A3                 3942 	inc	dptr
   62A2 E0                 3943 	movx	a,@dptr
   62A3 FF                 3944 	mov	r7,a
                           3945 ;	genIpush
                           3946 ;	Peephole 181	changed mov to clr
   62A4 E4                 3947 	clr	a
   62A5 C0 E0              3948 	push	acc
   62A7 C0 E0              3949 	push	acc
                           3950 ;	genIpush
   62A9 C0 02              3951 	push	ar2
   62AB C0 03              3952 	push	ar3
   62AD C0 04              3953 	push	ar4
                           3954 ;	genCall
   62AF 8D 82              3955 	mov	dpl,r5
   62B1 8E 83              3956 	mov	dph,r6
   62B3 8F F0              3957 	mov	b,r7
   62B5 12 1D 8E           3958 	lcall	_xQueueSend
   62B8 E5 81              3959 	mov	a,sp
   62BA 24 FB              3960 	add	a,#0xfb
   62BC F5 81              3961 	mov	sp,a
                           3962 ;	Peephole 300	removed redundant label 00101$
   62BE 85 10 81           3963 	mov	sp,_bp
   62C1 D0 10              3964 	pop	_bp
   62C3 22                 3965 	ret
                           3966 ;------------------------------------------------------------
                           3967 ;Allocation info for local variables in function 'stack_buffer_push'
                           3968 ;------------------------------------------------------------
                           3969 ;b                         Allocated to registers r2 r3 r4 
                           3970 ;event                     Allocated to stack - offset 1
                           3971 ;------------------------------------------------------------
                           3972 ;	../../Common/stack.c:864: portCHAR stack_buffer_push( buffer_t * b)
                           3973 ;	-----------------------------------------
                           3974 ;	 function stack_buffer_push
                           3975 ;	-----------------------------------------
   62C4                    3976 _stack_buffer_push:
   62C4 C0 10              3977 	push	_bp
                           3978 ;	peephole 177.h	optimized mov sequence
   62C6 E5 81              3979 	mov	a,sp
   62C8 F5 10              3980 	mov	_bp,a
   62CA 24 05              3981 	add	a,#0x05
   62CC F5 81              3982 	mov	sp,a
                           3983 ;	genReceive
   62CE AA 82              3984 	mov	r2,dpl
   62D0 AB 83              3985 	mov	r3,dph
   62D2 AC F0              3986 	mov	r4,b
                           3987 ;	../../Common/stack.c:867: event.process = 0;
                           3988 ;	genAddrOf
   62D4 E5 10              3989 	mov	a,_bp
   62D6 24 01              3990 	add	a,#0x01
                           3991 ;	genPointerSet
                           3992 ;	genNearPointerSet
                           3993 ;	Peephole 239	used a instead of acc
   62D8 F8                 3994 	mov	r0,a
   62D9 76 00              3995 	mov	@r0,#0x00
   62DB 08                 3996 	inc	r0
   62DC 76 00              3997 	mov	@r0,#0x00
                           3998 ;	../../Common/stack.c:868: event.param = (void *) b;
                           3999 ;	genAddrOf
                           4000 ;	Peephole 212	reduced add sequence to inc
   62DE AD 10              4001 	mov	r5,_bp
   62E0 0D                 4002 	inc	r5
                           4003 ;	genPlus
                           4004 ;     genPlusIncr
   62E1 74 02              4005 	mov	a,#0x02
                           4006 ;	Peephole 236.a	used r5 instead of ar5
   62E3 2D                 4007 	add	a,r5
                           4008 ;	genPointerSet
                           4009 ;	genNearPointerSet
                           4010 ;	Peephole 239	used a instead of acc
   62E4 F8                 4011 	mov	r0,a
   62E5 A6 02              4012 	mov	@r0,ar2
   62E7 08                 4013 	inc	r0
   62E8 A6 03              4014 	mov	@r0,ar3
   62EA 08                 4015 	inc	r0
   62EB A6 04              4016 	mov	@r0,ar4
                           4017 ;	../../Common/stack.c:870: return xQueueSend( events, ( void * ) &event, ( portTickType ) 0 );
                           4018 ;	genAssign
                           4019 ;	genCast
   62ED 7A 00              4020 	mov	r2,#0x00
   62EF 7B 40              4021 	mov	r3,#0x40
                           4022 ;	genAssign
   62F1 90 F0 DA           4023 	mov	dptr,#_events
   62F4 E0                 4024 	movx	a,@dptr
   62F5 FC                 4025 	mov	r4,a
   62F6 A3                 4026 	inc	dptr
   62F7 E0                 4027 	movx	a,@dptr
   62F8 FE                 4028 	mov	r6,a
   62F9 A3                 4029 	inc	dptr
   62FA E0                 4030 	movx	a,@dptr
   62FB FF                 4031 	mov	r7,a
                           4032 ;	genIpush
                           4033 ;	Peephole 181	changed mov to clr
   62FC E4                 4034 	clr	a
   62FD C0 E0              4035 	push	acc
   62FF C0 E0              4036 	push	acc
                           4037 ;	genIpush
   6301 C0 05              4038 	push	ar5
   6303 C0 02              4039 	push	ar2
   6305 C0 03              4040 	push	ar3
                           4041 ;	genCall
   6307 8C 82              4042 	mov	dpl,r4
   6309 8E 83              4043 	mov	dph,r6
   630B 8F F0              4044 	mov	b,r7
   630D 12 1D 8E           4045 	lcall	_xQueueSend
   6310 AA 82              4046 	mov	r2,dpl
   6312 E5 81              4047 	mov	a,sp
   6314 24 FB              4048 	add	a,#0xfb
   6316 F5 81              4049 	mov	sp,a
                           4050 ;	genRet
   6318 8A 82              4051 	mov	dpl,r2
                           4052 ;	Peephole 300	removed redundant label 00101$
   631A 85 10 81           4053 	mov	sp,_bp
   631D D0 10              4054 	pop	_bp
   631F 22                 4055 	ret
                           4056 ;------------------------------------------------------------
                           4057 ;Allocation info for local variables in function 'stack_buffer_headroom'
                           4058 ;------------------------------------------------------------
                           4059 ;size                      Allocated to stack - offset -4
                           4060 ;b                         Allocated to stack - offset 1
                           4061 ;sloc0                     Allocated to stack - offset 4
                           4062 ;sloc1                     Allocated to stack - offset 6
                           4063 ;sloc2                     Allocated to stack - offset 9
                           4064 ;sloc3                     Allocated to stack - offset 11
                           4065 ;sloc4                     Allocated to stack - offset 14
                           4066 ;------------------------------------------------------------
                           4067 ;	../../Common/stack.c:882: portCHAR stack_buffer_headroom( buffer_t * b, uint16_t size)
                           4068 ;	-----------------------------------------
                           4069 ;	 function stack_buffer_headroom
                           4070 ;	-----------------------------------------
   6320                    4071 _stack_buffer_headroom:
   6320 C0 10              4072 	push	_bp
   6322 85 81 10           4073 	mov	_bp,sp
                           4074 ;     genReceive
   6325 C0 82              4075 	push	dpl
   6327 C0 83              4076 	push	dph
   6329 C0 F0              4077 	push	b
   632B E5 81              4078 	mov	a,sp
   632D 24 10              4079 	add	a,#0x10
   632F F5 81              4080 	mov	sp,a
                           4081 ;	../../Common/stack.c:884: if (b->buf_ptr < size)
                           4082 ;	genPlus
   6331 A8 10              4083 	mov	r0,_bp
   6333 08                 4084 	inc	r0
                           4085 ;     genPlusIncr
   6334 74 20              4086 	mov	a,#0x20
   6336 26                 4087 	add	a,@r0
   6337 FD                 4088 	mov	r5,a
                           4089 ;	Peephole 181	changed mov to clr
   6338 E4                 4090 	clr	a
   6339 08                 4091 	inc	r0
   633A 36                 4092 	addc	a,@r0
   633B FE                 4093 	mov	r6,a
   633C 08                 4094 	inc	r0
   633D 86 07              4095 	mov	ar7,@r0
                           4096 ;	genPointerGet
                           4097 ;	genGenPointerGet
   633F 8D 82              4098 	mov	dpl,r5
   6341 8E 83              4099 	mov	dph,r6
   6343 8F F0              4100 	mov	b,r7
   6345 E5 10              4101 	mov	a,_bp
   6347 24 04              4102 	add	a,#0x04
   6349 F8                 4103 	mov	r0,a
   634A 12 E4 9F           4104 	lcall	__gptrget
   634D F6                 4105 	mov	@r0,a
   634E A3                 4106 	inc	dptr
   634F 12 E4 9F           4107 	lcall	__gptrget
   6352 08                 4108 	inc	r0
   6353 F6                 4109 	mov	@r0,a
                           4110 ;	genCmpLt
   6354 E5 10              4111 	mov	a,_bp
   6356 24 04              4112 	add	a,#0x04
   6358 F8                 4113 	mov	r0,a
   6359 E5 10              4114 	mov	a,_bp
   635B 24 FC              4115 	add	a,#0xfffffffc
   635D F9                 4116 	mov	r1,a
                           4117 ;	genCmp
   635E C3                 4118 	clr	c
   635F E6                 4119 	mov	a,@r0
   6360 97                 4120 	subb	a,@r1
   6361 08                 4121 	inc	r0
   6362 E6                 4122 	mov	a,@r0
   6363 09                 4123 	inc	r1
   6364 97                 4124 	subb	a,@r1
                           4125 ;	genIfxJump
   6365 40 03              4126 	jc	00109$
   6367 02 64 EF           4127 	ljmp	00104$
   636A                    4128 00109$:
                           4129 ;	../../Common/stack.c:886: if ((b->buf_end + size) >  b->size)
                           4130 ;	genIpush
   636A C0 05              4131 	push	ar5
   636C C0 06              4132 	push	ar6
   636E C0 07              4133 	push	ar7
                           4134 ;	genPlus
   6370 A8 10              4135 	mov	r0,_bp
   6372 08                 4136 	inc	r0
   6373 E5 10              4137 	mov	a,_bp
   6375 24 06              4138 	add	a,#0x06
   6377 F9                 4139 	mov	r1,a
                           4140 ;     genPlusIncr
   6378 74 22              4141 	mov	a,#0x22
   637A 26                 4142 	add	a,@r0
   637B F7                 4143 	mov	@r1,a
                           4144 ;	Peephole 181	changed mov to clr
   637C E4                 4145 	clr	a
   637D 08                 4146 	inc	r0
   637E 36                 4147 	addc	a,@r0
   637F 09                 4148 	inc	r1
   6380 F7                 4149 	mov	@r1,a
   6381 08                 4150 	inc	r0
   6382 09                 4151 	inc	r1
   6383 E6                 4152 	mov	a,@r0
   6384 F7                 4153 	mov	@r1,a
                           4154 ;	genPointerGet
                           4155 ;	genGenPointerGet
   6385 E5 10              4156 	mov	a,_bp
   6387 24 06              4157 	add	a,#0x06
   6389 F8                 4158 	mov	r0,a
   638A 86 82              4159 	mov	dpl,@r0
   638C 08                 4160 	inc	r0
   638D 86 83              4161 	mov	dph,@r0
   638F 08                 4162 	inc	r0
   6390 86 F0              4163 	mov	b,@r0
   6392 E5 10              4164 	mov	a,_bp
   6394 24 09              4165 	add	a,#0x09
   6396 F9                 4166 	mov	r1,a
   6397 12 E4 9F           4167 	lcall	__gptrget
   639A F7                 4168 	mov	@r1,a
   639B A3                 4169 	inc	dptr
   639C 12 E4 9F           4170 	lcall	__gptrget
   639F 09                 4171 	inc	r1
   63A0 F7                 4172 	mov	@r1,a
                           4173 ;	genPlus
   63A1 E5 10              4174 	mov	a,_bp
   63A3 24 09              4175 	add	a,#0x09
   63A5 F8                 4176 	mov	r0,a
   63A6 E5 10              4177 	mov	a,_bp
   63A8 24 FC              4178 	add	a,#0xfffffffc
   63AA F9                 4179 	mov	r1,a
   63AB E7                 4180 	mov	a,@r1
   63AC 26                 4181 	add	a,@r0
   63AD FD                 4182 	mov	r5,a
   63AE 09                 4183 	inc	r1
   63AF E7                 4184 	mov	a,@r1
   63B0 08                 4185 	inc	r0
   63B1 36                 4186 	addc	a,@r0
   63B2 FE                 4187 	mov	r6,a
                           4188 ;	genPlus
   63B3 A8 10              4189 	mov	r0,_bp
   63B5 08                 4190 	inc	r0
                           4191 ;     genPlusIncr
   63B6 74 24              4192 	mov	a,#0x24
   63B8 26                 4193 	add	a,@r0
   63B9 FF                 4194 	mov	r7,a
                           4195 ;	Peephole 181	changed mov to clr
   63BA E4                 4196 	clr	a
   63BB 08                 4197 	inc	r0
   63BC 36                 4198 	addc	a,@r0
   63BD FA                 4199 	mov	r2,a
   63BE 08                 4200 	inc	r0
   63BF 86 03              4201 	mov	ar3,@r0
                           4202 ;	genPointerGet
                           4203 ;	genGenPointerGet
   63C1 8F 82              4204 	mov	dpl,r7
   63C3 8A 83              4205 	mov	dph,r2
   63C5 8B F0              4206 	mov	b,r3
   63C7 12 E4 9F           4207 	lcall	__gptrget
   63CA FF                 4208 	mov	r7,a
   63CB A3                 4209 	inc	dptr
   63CC 12 E4 9F           4210 	lcall	__gptrget
   63CF FA                 4211 	mov	r2,a
                           4212 ;	genCmpGt
                           4213 ;	genCmp
   63D0 C3                 4214 	clr	c
   63D1 EF                 4215 	mov	a,r7
   63D2 9D                 4216 	subb	a,r5
   63D3 EA                 4217 	mov	a,r2
   63D4 9E                 4218 	subb	a,r6
   63D5 E4                 4219 	clr	a
   63D6 33                 4220 	rlc	a
                           4221 ;	genIpop
   63D7 D0 07              4222 	pop	ar7
   63D9 D0 06              4223 	pop	ar6
   63DB D0 05              4224 	pop	ar5
                           4225 ;	genIfx
                           4226 ;	genIfxJump
                           4227 ;	Peephole 108.c	removed ljmp by inverse jump logic
   63DD 60 06              4228 	jz	00102$
                           4229 ;	Peephole 300	removed redundant label 00110$
                           4230 ;	../../Common/stack.c:888: return pdFALSE;
                           4231 ;	genRet
   63DF 75 82 00           4232 	mov	dpl,#0x00
   63E2 02 64 F2           4233 	ljmp	00105$
   63E5                    4234 00102$:
                           4235 ;	../../Common/stack.c:892: buffer_data_length(b));
                           4236 ;	genMinus
   63E5 E5 10              4237 	mov	a,_bp
   63E7 24 09              4238 	add	a,#0x09
   63E9 F8                 4239 	mov	r0,a
   63EA E5 10              4240 	mov	a,_bp
   63EC 24 04              4241 	add	a,#0x04
   63EE F9                 4242 	mov	r1,a
   63EF E6                 4243 	mov	a,@r0
   63F0 C3                 4244 	clr	c
   63F1 97                 4245 	subb	a,@r1
   63F2 F6                 4246 	mov	@r0,a
   63F3 08                 4247 	inc	r0
   63F4 E6                 4248 	mov	a,@r0
   63F5 09                 4249 	inc	r1
   63F6 97                 4250 	subb	a,@r1
   63F7 F6                 4251 	mov	@r0,a
                           4252 ;	../../Common/stack.c:891: &(b->buf[b->buf_ptr]), 
                           4253 ;	genPlus
   63F8 A8 10              4254 	mov	r0,_bp
   63FA 08                 4255 	inc	r0
   63FB E5 10              4256 	mov	a,_bp
   63FD 24 0B              4257 	add	a,#0x0b
   63FF F9                 4258 	mov	r1,a
                           4259 ;     genPlusIncr
   6400 74 2C              4260 	mov	a,#0x2C
   6402 26                 4261 	add	a,@r0
   6403 F7                 4262 	mov	@r1,a
                           4263 ;	Peephole 181	changed mov to clr
   6404 E4                 4264 	clr	a
   6405 08                 4265 	inc	r0
   6406 36                 4266 	addc	a,@r0
   6407 09                 4267 	inc	r1
   6408 F7                 4268 	mov	@r1,a
   6409 08                 4269 	inc	r0
   640A 09                 4270 	inc	r1
   640B E6                 4271 	mov	a,@r0
   640C F7                 4272 	mov	@r1,a
                           4273 ;	genPlus
   640D E5 10              4274 	mov	a,_bp
   640F 24 0B              4275 	add	a,#0x0b
   6411 F8                 4276 	mov	r0,a
   6412 E5 10              4277 	mov	a,_bp
   6414 24 04              4278 	add	a,#0x04
   6416 F9                 4279 	mov	r1,a
   6417 E7                 4280 	mov	a,@r1
   6418 26                 4281 	add	a,@r0
   6419 C0 E0              4282 	push	acc
   641B 09                 4283 	inc	r1
   641C E7                 4284 	mov	a,@r1
   641D 08                 4285 	inc	r0
   641E 36                 4286 	addc	a,@r0
   641F C0 E0              4287 	push	acc
   6421 08                 4288 	inc	r0
   6422 E6                 4289 	mov	a,@r0
   6423 C0 E0              4290 	push	acc
   6425 E5 10              4291 	mov	a,_bp
   6427 24 10              4292 	add	a,#0x10
   6429 F8                 4293 	mov	r0,a
   642A D0 E0              4294 	pop	acc
   642C F6                 4295 	mov	@r0,a
   642D 18                 4296 	dec	r0
   642E D0 E0              4297 	pop	acc
   6430 F6                 4298 	mov	@r0,a
   6431 18                 4299 	dec	r0
   6432 D0 E0              4300 	pop	acc
   6434 F6                 4301 	mov	@r0,a
                           4302 ;	../../Common/stack.c:890: memmove(&(b->buf[(b->buf_ptr)+size]), 
                           4303 ;	genCast
   6435 E5 10              4304 	mov	a,_bp
   6437 24 04              4305 	add	a,#0x04
   6439 F8                 4306 	mov	r0,a
   643A 86 02              4307 	mov	ar2,@r0
                           4308 ;	genCast
   643C E5 10              4309 	mov	a,_bp
   643E 24 FC              4310 	add	a,#0xfffffffc
   6440 F8                 4311 	mov	r0,a
                           4312 ;	genPlus
                           4313 ;	peephole 177.g	optimized mov sequence
   6441 E6                 4314 	mov	a,@r0
                           4315 ;	Peephole 236.i	used r3 instead of ar3
   6442 FB                 4316 	mov	r3,a
                           4317 ;	Peephole 236.a	used r2 instead of ar2
   6443 2A                 4318 	add	a,r2
                           4319 ;	genPlus
   6444 C0 E0              4320 	push	acc
   6446 E5 10              4321 	mov	a,_bp
   6448 24 0B              4322 	add	a,#0x0b
   644A F8                 4323 	mov	r0,a
   644B D0 E0              4324 	pop	acc
   644D 26                 4325 	add	a,@r0
   644E FA                 4326 	mov	r2,a
   644F 08                 4327 	inc	r0
                           4328 ;	Peephole 240	use clr instead of addc a,#0
   6450 E4                 4329 	clr	a
   6451 36                 4330 	addc	a,@r0
   6452 FB                 4331 	mov	r3,a
   6453 08                 4332 	inc	r0
   6454 86 04              4333 	mov	ar4,@r0
                           4334 ;	genIpush
   6456 C0 05              4335 	push	ar5
   6458 C0 06              4336 	push	ar6
   645A C0 07              4337 	push	ar7
   645C E5 10              4338 	mov	a,_bp
   645E 24 09              4339 	add	a,#0x09
   6460 F8                 4340 	mov	r0,a
   6461 E6                 4341 	mov	a,@r0
   6462 C0 E0              4342 	push	acc
   6464 08                 4343 	inc	r0
   6465 E6                 4344 	mov	a,@r0
   6466 C0 E0              4345 	push	acc
                           4346 ;	genIpush
   6468 E5 10              4347 	mov	a,_bp
   646A 24 0E              4348 	add	a,#0x0e
   646C F8                 4349 	mov	r0,a
   646D E6                 4350 	mov	a,@r0
   646E C0 E0              4351 	push	acc
   6470 08                 4352 	inc	r0
   6471 E6                 4353 	mov	a,@r0
   6472 C0 E0              4354 	push	acc
   6474 08                 4355 	inc	r0
   6475 E6                 4356 	mov	a,@r0
   6476 C0 E0              4357 	push	acc
                           4358 ;	genCall
   6478 8A 82              4359 	mov	dpl,r2
   647A 8B 83              4360 	mov	dph,r3
   647C 8C F0              4361 	mov	b,r4
   647E 12 DF D0           4362 	lcall	_memmove
   6481 E5 81              4363 	mov	a,sp
   6483 24 FB              4364 	add	a,#0xfb
   6485 F5 81              4365 	mov	sp,a
   6487 D0 07              4366 	pop	ar7
   6489 D0 06              4367 	pop	ar6
   648B D0 05              4368 	pop	ar5
                           4369 ;	../../Common/stack.c:893: b->buf_end += size;
                           4370 ;	genPointerGet
                           4371 ;	genGenPointerGet
   648D E5 10              4372 	mov	a,_bp
   648F 24 06              4373 	add	a,#0x06
   6491 F8                 4374 	mov	r0,a
   6492 86 82              4375 	mov	dpl,@r0
   6494 08                 4376 	inc	r0
   6495 86 83              4377 	mov	dph,@r0
   6497 08                 4378 	inc	r0
   6498 86 F0              4379 	mov	b,@r0
   649A 12 E4 9F           4380 	lcall	__gptrget
   649D FA                 4381 	mov	r2,a
   649E A3                 4382 	inc	dptr
   649F 12 E4 9F           4383 	lcall	__gptrget
   64A2 FB                 4384 	mov	r3,a
                           4385 ;	genPlus
   64A3 E5 10              4386 	mov	a,_bp
   64A5 24 FC              4387 	add	a,#0xfffffffc
   64A7 F8                 4388 	mov	r0,a
   64A8 E6                 4389 	mov	a,@r0
                           4390 ;	Peephole 236.a	used r2 instead of ar2
   64A9 2A                 4391 	add	a,r2
   64AA FA                 4392 	mov	r2,a
   64AB 08                 4393 	inc	r0
   64AC E6                 4394 	mov	a,@r0
                           4395 ;	Peephole 236.b	used r3 instead of ar3
   64AD 3B                 4396 	addc	a,r3
   64AE FB                 4397 	mov	r3,a
                           4398 ;	genPointerSet
                           4399 ;	genGenPointerSet
   64AF E5 10              4400 	mov	a,_bp
   64B1 24 06              4401 	add	a,#0x06
   64B3 F8                 4402 	mov	r0,a
   64B4 86 82              4403 	mov	dpl,@r0
   64B6 08                 4404 	inc	r0
   64B7 86 83              4405 	mov	dph,@r0
   64B9 08                 4406 	inc	r0
   64BA 86 F0              4407 	mov	b,@r0
   64BC EA                 4408 	mov	a,r2
   64BD 12 DF B7           4409 	lcall	__gptrput
   64C0 A3                 4410 	inc	dptr
   64C1 EB                 4411 	mov	a,r3
   64C2 12 DF B7           4412 	lcall	__gptrput
                           4413 ;	../../Common/stack.c:894: b->buf_ptr += size;
                           4414 ;	genPointerGet
                           4415 ;	genGenPointerGet
   64C5 8D 82              4416 	mov	dpl,r5
   64C7 8E 83              4417 	mov	dph,r6
   64C9 8F F0              4418 	mov	b,r7
   64CB 12 E4 9F           4419 	lcall	__gptrget
   64CE FA                 4420 	mov	r2,a
   64CF A3                 4421 	inc	dptr
   64D0 12 E4 9F           4422 	lcall	__gptrget
   64D3 FB                 4423 	mov	r3,a
                           4424 ;	genPlus
   64D4 E5 10              4425 	mov	a,_bp
   64D6 24 FC              4426 	add	a,#0xfffffffc
   64D8 F8                 4427 	mov	r0,a
   64D9 E6                 4428 	mov	a,@r0
                           4429 ;	Peephole 236.a	used r2 instead of ar2
   64DA 2A                 4430 	add	a,r2
   64DB FA                 4431 	mov	r2,a
   64DC 08                 4432 	inc	r0
   64DD E6                 4433 	mov	a,@r0
                           4434 ;	Peephole 236.b	used r3 instead of ar3
   64DE 3B                 4435 	addc	a,r3
   64DF FB                 4436 	mov	r3,a
                           4437 ;	genPointerSet
                           4438 ;	genGenPointerSet
   64E0 8D 82              4439 	mov	dpl,r5
   64E2 8E 83              4440 	mov	dph,r6
   64E4 8F F0              4441 	mov	b,r7
   64E6 EA                 4442 	mov	a,r2
   64E7 12 DF B7           4443 	lcall	__gptrput
   64EA A3                 4444 	inc	dptr
   64EB EB                 4445 	mov	a,r3
   64EC 12 DF B7           4446 	lcall	__gptrput
   64EF                    4447 00104$:
                           4448 ;	../../Common/stack.c:896: return pdTRUE;
                           4449 ;	genRet
   64EF 75 82 01           4450 	mov	dpl,#0x01
   64F2                    4451 00105$:
   64F2 85 10 81           4452 	mov	sp,_bp
   64F5 D0 10              4453 	pop	_bp
   64F7 22                 4454 	ret
                           4455 ;------------------------------------------------------------
                           4456 ;Allocation info for local variables in function 'stack_number_get'
                           4457 ;------------------------------------------------------------
                           4458 ;------------------------------------------------------------
                           4459 ;	../../Common/stack.c:904: uint8_t stack_number_get()
                           4460 ;	-----------------------------------------
                           4461 ;	 function stack_number_get
                           4462 ;	-----------------------------------------
   64F8                    4463 _stack_number_get:
                           4464 ;	../../Common/stack.c:906: return STACKS_MAX;
                           4465 ;	genRet
   64F8 75 82 02           4466 	mov	dpl,#0x02
                           4467 ;	Peephole 300	removed redundant label 00101$
   64FB 22                 4468 	ret
                           4469 ;------------------------------------------------------------
                           4470 ;Allocation info for local variables in function 'stack_compare_address'
                           4471 ;------------------------------------------------------------
                           4472 ;a2                        Allocated to stack - offset -5
                           4473 ;a1                        Allocated to stack - offset 1
                           4474 ;size                      Allocated to stack - offset 4
                           4475 ;pan                       Allocated to stack - offset 6
                           4476 ;match                     Allocated to stack - offset 10
                           4477 ;i                         Allocated to stack - offset 11
                           4478 ;tmp_type                  Allocated to registers r7 
                           4479 ;dptr                      Allocated to stack - offset 12
                           4480 ;tmp_addr                  Allocated to stack - offset 15
                           4481 ;cmp_size                  Allocated to registers r2 
                           4482 ;sloc0                     Allocated to stack - offset 18
                           4483 ;sloc1                     Allocated to stack - offset 21
                           4484 ;------------------------------------------------------------
                           4485 ;	../../Common/stack.c:920: portCHAR stack_compare_address(sockaddr_t *a1, sockaddr_t *a2)
                           4486 ;	-----------------------------------------
                           4487 ;	 function stack_compare_address
                           4488 ;	-----------------------------------------
   64FC                    4489 _stack_compare_address:
   64FC C0 10              4490 	push	_bp
   64FE 85 81 10           4491 	mov	_bp,sp
                           4492 ;     genReceive
   6501 C0 82              4493 	push	dpl
   6503 C0 83              4494 	push	dph
   6505 C0 F0              4495 	push	b
   6507 E5 81              4496 	mov	a,sp
   6509 24 17              4497 	add	a,#0x17
   650B F5 81              4498 	mov	sp,a
                           4499 ;	../../Common/stack.c:922: uint8_t size[2] = {0,0};
                           4500 ;	genAddrOf
   650D E5 10              4501 	mov	a,_bp
   650F 24 04              4502 	add	a,#0x04
   6511 F8                 4503 	mov	r0,a
                           4504 ;	genPointerSet
                           4505 ;	genNearPointerSet
   6512 76 00              4506 	mov	@r0,#0x00
                           4507 ;	genPlus
                           4508 ;     genPlusIncr
   6514 74 01              4509 	mov	a,#0x01
                           4510 ;	Peephole 236.a	used r0 instead of ar0
   6516 28                 4511 	add	a,r0
   6517 F9                 4512 	mov	r1,a
                           4513 ;	genPointerSet
                           4514 ;	genNearPointerSet
   6518 77 00              4515 	mov	@r1,#0x00
                           4516 ;	../../Common/stack.c:923: uint16_t pan[2] = {0xFFFF,0xFFFF};
                           4517 ;	genAddrOf
   651A E5 10              4518 	mov	a,_bp
   651C 24 06              4519 	add	a,#0x06
   651E FD                 4520 	mov	r5,a
                           4521 ;	genPointerSet
                           4522 ;	genNearPointerSet
   651F C0 00              4523 	push	ar0
   6521 A8 05              4524 	mov	r0,ar5
   6523 76 FF              4525 	mov	@r0,#0xFF
   6525 08                 4526 	inc	r0
   6526 76 FF              4527 	mov	@r0,#0xFF
   6528 D0 00              4528 	pop	ar0
                           4529 ;	genPlus
                           4530 ;     genPlusIncr
   652A 74 02              4531 	mov	a,#0x02
                           4532 ;	Peephole 236.a	used r5 instead of ar5
   652C 2D                 4533 	add	a,r5
   652D FE                 4534 	mov	r6,a
                           4535 ;	genPointerSet
                           4536 ;	genNearPointerSet
   652E C0 00              4537 	push	ar0
   6530 A8 06              4538 	mov	r0,ar6
   6532 76 FF              4539 	mov	@r0,#0xFF
   6534 08                 4540 	inc	r0
   6535 76 FF              4541 	mov	@r0,#0xFF
   6537 D0 00              4542 	pop	ar0
                           4543 ;	../../Common/stack.c:924: uint8_t match = 0;
                           4544 ;	genAssign
   6539 C0 00              4545 	push	ar0
   653B E5 10              4546 	mov	a,_bp
   653D 24 0A              4547 	add	a,#0x0a
   653F F8                 4548 	mov	r0,a
   6540 76 00              4549 	mov	@r0,#0x00
   6542 D0 00              4550 	pop	ar0
                           4551 ;	../../Common/stack.c:930: for (i=0; i<2; i++)
                           4552 ;	genAssign
   6544 C0 00              4553 	push	ar0
   6546 E5 10              4554 	mov	a,_bp
   6548 24 FB              4555 	add	a,#0xfffffffb
   654A F8                 4556 	mov	r0,a
   654B C0 01              4557 	push	ar1
   654D E5 10              4558 	mov	a,_bp
   654F 24 0F              4559 	add	a,#0x0f
   6551 F9                 4560 	mov	r1,a
   6552 E6                 4561 	mov	a,@r0
   6553 F7                 4562 	mov	@r1,a
   6554 08                 4563 	inc	r0
   6555 09                 4564 	inc	r1
   6556 E6                 4565 	mov	a,@r0
   6557 F7                 4566 	mov	@r1,a
   6558 08                 4567 	inc	r0
   6559 09                 4568 	inc	r1
   655A E6                 4569 	mov	a,@r0
   655B F7                 4570 	mov	@r1,a
   655C D0 01              4571 	pop	ar1
   655E D0 00              4572 	pop	ar0
                           4573 ;	genAssign
   6560 C0 00              4574 	push	ar0
   6562 E5 10              4575 	mov	a,_bp
   6564 24 0B              4576 	add	a,#0x0b
   6566 F8                 4577 	mov	r0,a
   6567 76 00              4578 	mov	@r0,#0x00
   6569 D0 00              4579 	pop	ar0
   656B                    4580 00134$:
                           4581 ;	genCmpLt
   656B C0 00              4582 	push	ar0
   656D E5 10              4583 	mov	a,_bp
   656F 24 0B              4584 	add	a,#0x0b
   6571 F8                 4585 	mov	r0,a
                           4586 ;	genCmp
   6572 B6 02 00           4587 	cjne	@r0,#0x02,00155$
   6575                    4588 00155$:
   6575 D0 00              4589 	pop	ar0
                           4590 ;	genIfxJump
   6577 40 03              4591 	jc	00156$
   6579 02 67 52           4592 	ljmp	00137$
   657C                    4593 00156$:
                           4594 ;	../../Common/stack.c:932: uint8_t *dptr = 0;
                           4595 ;	genAssign
   657C C0 00              4596 	push	ar0
   657E E5 10              4597 	mov	a,_bp
   6580 24 0C              4598 	add	a,#0x0c
   6582 F8                 4599 	mov	r0,a
   6583 E4                 4600 	clr	a
   6584 F6                 4601 	mov	@r0,a
   6585 08                 4602 	inc	r0
   6586 F6                 4603 	mov	@r0,a
   6587 08                 4604 	inc	r0
   6588 F6                 4605 	mov	@r0,a
   6589 D0 00              4606 	pop	ar0
                           4607 ;	../../Common/stack.c:935: if (i==0)
                           4608 ;	genIfx
   658B C0 00              4609 	push	ar0
   658D E5 10              4610 	mov	a,_bp
   658F 24 0B              4611 	add	a,#0x0b
   6591 F8                 4612 	mov	r0,a
   6592 E6                 4613 	mov	a,@r0
   6593 D0 00              4614 	pop	ar0
                           4615 ;	genIfxJump
                           4616 ;	Peephole 108.b	removed ljmp by inverse jump logic
   6595 70 24              4617 	jnz	00102$
                           4618 ;	Peephole 300	removed redundant label 00157$
                           4619 ;	../../Common/stack.c:936: { tmp_type = a1->addr_type;
                           4620 ;	genPointerGet
                           4621 ;	genGenPointerGet
   6597 C0 00              4622 	push	ar0
   6599 A8 10              4623 	mov	r0,_bp
   659B 08                 4624 	inc	r0
   659C 86 82              4625 	mov	dpl,@r0
   659E 08                 4626 	inc	r0
   659F 86 83              4627 	mov	dph,@r0
   65A1 08                 4628 	inc	r0
   65A2 86 F0              4629 	mov	b,@r0
   65A4 12 E4 9F           4630 	lcall	__gptrget
   65A7 FF                 4631 	mov	r7,a
   65A8 D0 00              4632 	pop	ar0
                           4633 ;	genAssign
                           4634 ;	../../Common/stack.c:937: tmp_addr = a1;
                           4635 ;	genAssign
   65AA C0 00              4636 	push	ar0
   65AC A8 10              4637 	mov	r0,_bp
   65AE 08                 4638 	inc	r0
   65AF 86 02              4639 	mov	ar2,@r0
   65B1 08                 4640 	inc	r0
   65B2 86 03              4641 	mov	ar3,@r0
   65B4 08                 4642 	inc	r0
   65B5 86 04              4643 	mov	ar4,@r0
   65B7 D0 00              4644 	pop	ar0
                           4645 ;	Peephole 112.b	changed ljmp to sjmp
   65B9 80 2C              4646 	sjmp	00103$
   65BB                    4647 00102$:
                           4648 ;	../../Common/stack.c:940: { tmp_type = a2->addr_type;
                           4649 ;	genIpush
   65BB C0 06              4650 	push	ar6
                           4651 ;	genPointerGet
                           4652 ;	genGenPointerGet
   65BD C0 00              4653 	push	ar0
   65BF E5 10              4654 	mov	a,_bp
   65C1 24 0F              4655 	add	a,#0x0f
   65C3 F8                 4656 	mov	r0,a
   65C4 86 82              4657 	mov	dpl,@r0
   65C6 08                 4658 	inc	r0
   65C7 86 83              4659 	mov	dph,@r0
   65C9 08                 4660 	inc	r0
   65CA 86 F0              4661 	mov	b,@r0
   65CC 12 E4 9F           4662 	lcall	__gptrget
   65CF FE                 4663 	mov	r6,a
   65D0 D0 00              4664 	pop	ar0
                           4665 ;	genAssign
   65D2 8E 07              4666 	mov	ar7,r6
                           4667 ;	../../Common/stack.c:941: tmp_addr = a2;
                           4668 ;	genAssign
   65D4 C0 00              4669 	push	ar0
   65D6 E5 10              4670 	mov	a,_bp
   65D8 24 0F              4671 	add	a,#0x0f
   65DA F8                 4672 	mov	r0,a
   65DB 86 02              4673 	mov	ar2,@r0
   65DD 08                 4674 	inc	r0
   65DE 86 03              4675 	mov	ar3,@r0
   65E0 08                 4676 	inc	r0
   65E1 86 04              4677 	mov	ar4,@r0
   65E3 D0 00              4678 	pop	ar0
                           4679 ;	../../Common/stack.c:1011: return pdTRUE;
                           4680 ;	genIpop
   65E5 D0 06              4681 	pop	ar6
                           4682 ;	../../Common/stack.c:941: tmp_addr = a2;
   65E7                    4683 00103$:
                           4684 ;	../../Common/stack.c:944: switch(tmp_type)
                           4685 ;	genCmpGt
                           4686 ;	genCmp
                           4687 ;	genIfxJump
                           4688 ;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
   65E7 EF                 4689 	mov	a,r7
   65E8 24 F7              4690 	add	a,#0xff - 0x08
   65EA 50 03              4691 	jnc	00158$
   65EC 02 66 C6           4692 	ljmp	00112$
   65EF                    4693 00158$:
                           4694 ;	genJumpTab
   65EF EF                 4695 	mov	a,r7
                           4696 ;	Peephole 254	optimized left shift
   65F0 2F                 4697 	add	a,r7
   65F1 2F                 4698 	add	a,r7
   65F2 90 65 F6           4699 	mov	dptr,#00159$
   65F5 73                 4700 	jmp	@a+dptr
   65F6                    4701 00159$:
   65F6 02 66 B2           4702 	ljmp	00111$
   65F9 02 66 72           4703 	ljmp	00107$
   65FC 02 66 36           4704 	ljmp	00105$
   65FF 02 66 11           4705 	ljmp	00104$
   6602 02 66 4D           4706 	ljmp	00106$
   6605 02 66 88           4707 	ljmp	00108$
   6608 02 66 9E           4708 	ljmp	00109$
   660B 02 66 C6           4709 	ljmp	00112$
   660E 02 66 B2           4710 	ljmp	00110$
                           4711 ;	../../Common/stack.c:946: case ADDR_802_15_4_PAN_SHORT:
   6611                    4712 00104$:
                           4713 ;	../../Common/stack.c:947: dptr = tmp_addr->address;
                           4714 ;	genPlus
   6611 C0 00              4715 	push	ar0
   6613 E5 10              4716 	mov	a,_bp
   6615 24 0C              4717 	add	a,#0x0c
   6617 F8                 4718 	mov	r0,a
                           4719 ;     genPlusIncr
   6618 74 01              4720 	mov	a,#0x01
                           4721 ;	Peephole 236.a	used r2 instead of ar2
   661A 2A                 4722 	add	a,r2
   661B F6                 4723 	mov	@r0,a
                           4724 ;	Peephole 181	changed mov to clr
   661C E4                 4725 	clr	a
                           4726 ;	Peephole 236.b	used r3 instead of ar3
   661D 3B                 4727 	addc	a,r3
   661E 08                 4728 	inc	r0
   661F F6                 4729 	mov	@r0,a
   6620 08                 4730 	inc	r0
   6621 A6 04              4731 	mov	@r0,ar4
   6623 D0 00              4732 	pop	ar0
                           4733 ;	../../Common/stack.c:948: dptr += 2;
                           4734 ;	genPlus
   6625 C0 00              4735 	push	ar0
   6627 E5 10              4736 	mov	a,_bp
   6629 24 0C              4737 	add	a,#0x0c
   662B F8                 4738 	mov	r0,a
                           4739 ;     genPlusIncr
   662C 74 02              4740 	mov	a,#0x02
   662E 26                 4741 	add	a,@r0
   662F F6                 4742 	mov	@r0,a
                           4743 ;	Peephole 181	changed mov to clr
   6630 E4                 4744 	clr	a
   6631 08                 4745 	inc	r0
   6632 36                 4746 	addc	a,@r0
   6633 F6                 4747 	mov	@r0,a
   6634 D0 00              4748 	pop	ar0
                           4749 ;	../../Common/stack.c:949: case ADDR_802_15_4_SHORT:
   6636                    4750 00105$:
                           4751 ;	../../Common/stack.c:950: size[i] = 2;
                           4752 ;	genPlus
   6636 C0 01              4753 	push	ar1
   6638 E5 10              4754 	mov	a,_bp
   663A 24 0B              4755 	add	a,#0x0b
   663C F9                 4756 	mov	r1,a
   663D E7                 4757 	mov	a,@r1
                           4758 ;	Peephole 236.a	used r0 instead of ar0
   663E 28                 4759 	add	a,r0
   663F FF                 4760 	mov	r7,a
   6640 D0 01              4761 	pop	ar1
                           4762 ;	genPointerSet
                           4763 ;	genNearPointerSet
   6642 C0 00              4764 	push	ar0
   6644 A8 07              4765 	mov	r0,ar7
   6646 76 02              4766 	mov	@r0,#0x02
   6648 D0 00              4767 	pop	ar0
                           4768 ;	../../Common/stack.c:951: break;
   664A 02 66 C6           4769 	ljmp	00112$
                           4770 ;	../../Common/stack.c:953: case ADDR_802_15_4_PAN_LONG:
   664D                    4771 00106$:
                           4772 ;	../../Common/stack.c:954: dptr = tmp_addr->address;
                           4773 ;	genPlus
   664D C0 00              4774 	push	ar0
   664F E5 10              4775 	mov	a,_bp
   6651 24 0C              4776 	add	a,#0x0c
   6653 F8                 4777 	mov	r0,a
                           4778 ;     genPlusIncr
   6654 74 01              4779 	mov	a,#0x01
                           4780 ;	Peephole 236.a	used r2 instead of ar2
   6656 2A                 4781 	add	a,r2
   6657 F6                 4782 	mov	@r0,a
                           4783 ;	Peephole 181	changed mov to clr
   6658 E4                 4784 	clr	a
                           4785 ;	Peephole 236.b	used r3 instead of ar3
   6659 3B                 4786 	addc	a,r3
   665A 08                 4787 	inc	r0
   665B F6                 4788 	mov	@r0,a
   665C 08                 4789 	inc	r0
   665D A6 04              4790 	mov	@r0,ar4
   665F D0 00              4791 	pop	ar0
                           4792 ;	../../Common/stack.c:955: dptr += 8;
                           4793 ;	genPlus
   6661 C0 00              4794 	push	ar0
   6663 E5 10              4795 	mov	a,_bp
   6665 24 0C              4796 	add	a,#0x0c
   6667 F8                 4797 	mov	r0,a
                           4798 ;     genPlusIncr
   6668 74 08              4799 	mov	a,#0x08
   666A 26                 4800 	add	a,@r0
   666B F6                 4801 	mov	@r0,a
                           4802 ;	Peephole 181	changed mov to clr
   666C E4                 4803 	clr	a
   666D 08                 4804 	inc	r0
   666E 36                 4805 	addc	a,@r0
   666F F6                 4806 	mov	@r0,a
   6670 D0 00              4807 	pop	ar0
                           4808 ;	../../Common/stack.c:956: case ADDR_802_15_4_LONG:
   6672                    4809 00107$:
                           4810 ;	../../Common/stack.c:957: size[i] = 8;
                           4811 ;	genPlus
   6672 C0 01              4812 	push	ar1
   6674 E5 10              4813 	mov	a,_bp
   6676 24 0B              4814 	add	a,#0x0b
   6678 F9                 4815 	mov	r1,a
   6679 E7                 4816 	mov	a,@r1
                           4817 ;	Peephole 236.a	used r0 instead of ar0
   667A 28                 4818 	add	a,r0
   667B FF                 4819 	mov	r7,a
   667C D0 01              4820 	pop	ar1
                           4821 ;	genPointerSet
                           4822 ;	genNearPointerSet
   667E C0 00              4823 	push	ar0
   6680 A8 07              4824 	mov	r0,ar7
   6682 76 08              4825 	mov	@r0,#0x08
   6684 D0 00              4826 	pop	ar0
                           4827 ;	../../Common/stack.c:958: break;
                           4828 ;	../../Common/stack.c:960: case ADDR_SHORT:
                           4829 ;	Peephole 112.b	changed ljmp to sjmp
   6686 80 3E              4830 	sjmp	00112$
   6688                    4831 00108$:
                           4832 ;	../../Common/stack.c:961: size[i] = 1;
                           4833 ;	genPlus
   6688 C0 01              4834 	push	ar1
   668A E5 10              4835 	mov	a,_bp
   668C 24 0B              4836 	add	a,#0x0b
   668E F9                 4837 	mov	r1,a
   668F E7                 4838 	mov	a,@r1
                           4839 ;	Peephole 236.a	used r0 instead of ar0
   6690 28                 4840 	add	a,r0
   6691 FF                 4841 	mov	r7,a
   6692 D0 01              4842 	pop	ar1
                           4843 ;	genPointerSet
                           4844 ;	genNearPointerSet
   6694 C0 00              4845 	push	ar0
   6696 A8 07              4846 	mov	r0,ar7
   6698 76 01              4847 	mov	@r0,#0x01
   669A D0 00              4848 	pop	ar0
                           4849 ;	../../Common/stack.c:962: break;
                           4850 ;	../../Common/stack.c:964: case ADDR_PAN:
                           4851 ;	Peephole 112.b	changed ljmp to sjmp
   669C 80 28              4852 	sjmp	00112$
   669E                    4853 00109$:
                           4854 ;	../../Common/stack.c:965: dptr = tmp_addr->address;
                           4855 ;	genPlus
   669E C0 00              4856 	push	ar0
   66A0 E5 10              4857 	mov	a,_bp
   66A2 24 0C              4858 	add	a,#0x0c
   66A4 F8                 4859 	mov	r0,a
                           4860 ;     genPlusIncr
   66A5 74 01              4861 	mov	a,#0x01
                           4862 ;	Peephole 236.a	used r2 instead of ar2
   66A7 2A                 4863 	add	a,r2
   66A8 F6                 4864 	mov	@r0,a
                           4865 ;	Peephole 181	changed mov to clr
   66A9 E4                 4866 	clr	a
                           4867 ;	Peephole 236.b	used r3 instead of ar3
   66AA 3B                 4868 	addc	a,r3
   66AB 08                 4869 	inc	r0
   66AC F6                 4870 	mov	@r0,a
   66AD 08                 4871 	inc	r0
   66AE A6 04              4872 	mov	@r0,ar4
   66B0 D0 00              4873 	pop	ar0
                           4874 ;	../../Common/stack.c:966: case ADDR_BROADCAST:
   66B2                    4875 00110$:
                           4876 ;	../../Common/stack.c:967: case ADDR_NONE:
   66B2                    4877 00111$:
                           4878 ;	../../Common/stack.c:968: size[i] = 0;
                           4879 ;	genPlus
   66B2 C0 01              4880 	push	ar1
   66B4 E5 10              4881 	mov	a,_bp
   66B6 24 0B              4882 	add	a,#0x0b
   66B8 F9                 4883 	mov	r1,a
   66B9 E7                 4884 	mov	a,@r1
                           4885 ;	Peephole 236.a	used r0 instead of ar0
   66BA 28                 4886 	add	a,r0
   66BB FF                 4887 	mov	r7,a
   66BC D0 01              4888 	pop	ar1
                           4889 ;	genPointerSet
                           4890 ;	genNearPointerSet
   66BE C0 00              4891 	push	ar0
   66C0 A8 07              4892 	mov	r0,ar7
   66C2 76 00              4893 	mov	@r0,#0x00
   66C4 D0 00              4894 	pop	ar0
                           4895 ;	../../Common/stack.c:970: }
   66C6                    4896 00112$:
                           4897 ;	../../Common/stack.c:971: if (dptr)
                           4898 ;	genIfx
   66C6 C0 00              4899 	push	ar0
   66C8 E5 10              4900 	mov	a,_bp
   66CA 24 0C              4901 	add	a,#0x0c
   66CC F8                 4902 	mov	r0,a
   66CD E6                 4903 	mov	a,@r0
   66CE 08                 4904 	inc	r0
   66CF 46                 4905 	orl	a,@r0
   66D0 08                 4906 	inc	r0
   66D1 46                 4907 	orl	a,@r0
   66D2 D0 00              4908 	pop	ar0
                           4909 ;	genIfxJump
                           4910 ;	Peephole 108.c	removed ljmp by inverse jump logic
   66D4 60 6F              4911 	jz	00136$
                           4912 ;	Peephole 300	removed redundant label 00160$
                           4913 ;	../../Common/stack.c:973: pan[i] = *dptr++;
                           4914 ;	genIpush
   66D6 C0 06              4915 	push	ar6
                           4916 ;	genLeftShift
                           4917 ;	genLeftShiftLiteral
   66D8 C0 00              4918 	push	ar0
   66DA E5 10              4919 	mov	a,_bp
   66DC 24 0B              4920 	add	a,#0x0b
   66DE F8                 4921 	mov	r0,a
                           4922 ;	genlshOne
   66DF E6                 4923 	mov	a,@r0
   66E0 25 E0              4924 	add	a,acc
   66E2 FF                 4925 	mov	r7,a
   66E3 D0 00              4926 	pop	ar0
                           4927 ;	genPlus
                           4928 ;	Peephole 236.g	used r7 instead of ar7
   66E5 EF                 4929 	mov	a,r7
                           4930 ;	Peephole 236.a	used r5 instead of ar5
   66E6 2D                 4931 	add	a,r5
   66E7 FF                 4932 	mov	r7,a
                           4933 ;	genPointerGet
                           4934 ;	genGenPointerGet
   66E8 C0 00              4935 	push	ar0
   66EA E5 10              4936 	mov	a,_bp
   66EC 24 0C              4937 	add	a,#0x0c
   66EE F8                 4938 	mov	r0,a
   66EF 86 82              4939 	mov	dpl,@r0
   66F1 08                 4940 	inc	r0
   66F2 86 83              4941 	mov	dph,@r0
   66F4 08                 4942 	inc	r0
   66F5 86 F0              4943 	mov	b,@r0
   66F7 12 E4 9F           4944 	lcall	__gptrget
   66FA FE                 4945 	mov	r6,a
   66FB A3                 4946 	inc	dptr
   66FC 18                 4947 	dec	r0
   66FD 18                 4948 	dec	r0
   66FE A6 82              4949 	mov	@r0,dpl
   6700 08                 4950 	inc	r0
   6701 A6 83              4951 	mov	@r0,dph
   6703 D0 00              4952 	pop	ar0
                           4953 ;	genCast
   6705 7A 00              4954 	mov	r2,#0x00
                           4955 ;	genPointerSet
                           4956 ;	genNearPointerSet
   6707 C0 00              4957 	push	ar0
   6709 A8 07              4958 	mov	r0,ar7
   670B A6 06              4959 	mov	@r0,ar6
   670D 08                 4960 	inc	r0
   670E A6 02              4961 	mov	@r0,ar2
   6710 D0 00              4962 	pop	ar0
                           4963 ;	../../Common/stack.c:974: pan[i] <<= 8;
                           4964 ;	genLeftShift
                           4965 ;	genLeftShiftLiteral
                           4966 ;	genlshTwo
   6712 8E 02              4967 	mov	ar2,r6
   6714 7E 00              4968 	mov	r6,#0x00
                           4969 ;	genPointerSet
                           4970 ;	genNearPointerSet
   6716 C0 00              4971 	push	ar0
   6718 A8 07              4972 	mov	r0,ar7
   671A A6 06              4973 	mov	@r0,ar6
   671C 08                 4974 	inc	r0
   671D A6 02              4975 	mov	@r0,ar2
   671F D0 00              4976 	pop	ar0
                           4977 ;	../../Common/stack.c:975: pan[i] = *dptr++;
                           4978 ;	genPointerGet
                           4979 ;	genGenPointerGet
   6721 C0 00              4980 	push	ar0
   6723 E5 10              4981 	mov	a,_bp
   6725 24 0C              4982 	add	a,#0x0c
   6727 F8                 4983 	mov	r0,a
   6728 86 82              4984 	mov	dpl,@r0
   672A 08                 4985 	inc	r0
   672B 86 83              4986 	mov	dph,@r0
   672D 08                 4987 	inc	r0
   672E 86 F0              4988 	mov	b,@r0
   6730 12 E4 9F           4989 	lcall	__gptrget
   6733 FA                 4990 	mov	r2,a
   6734 D0 00              4991 	pop	ar0
                           4992 ;	genCast
   6736 7B 00              4993 	mov	r3,#0x00
                           4994 ;	genPointerSet
                           4995 ;	genNearPointerSet
   6738 C0 00              4996 	push	ar0
   673A A8 07              4997 	mov	r0,ar7
   673C A6 02              4998 	mov	@r0,ar2
   673E 08                 4999 	inc	r0
   673F A6 03              5000 	mov	@r0,ar3
   6741 D0 00              5001 	pop	ar0
                           5002 ;	../../Common/stack.c:1011: return pdTRUE;
                           5003 ;	genIpop
   6743 D0 06              5004 	pop	ar6
                           5005 ;	../../Common/stack.c:975: pan[i] = *dptr++;
   6745                    5006 00136$:
                           5007 ;	../../Common/stack.c:930: for (i=0; i<2; i++)
                           5008 ;	genPlus
   6745 C0 00              5009 	push	ar0
   6747 E5 10              5010 	mov	a,_bp
   6749 24 0B              5011 	add	a,#0x0b
   674B F8                 5012 	mov	r0,a
                           5013 ;     genPlusIncr
   674C 06                 5014 	inc	@r0
   674D D0 00              5015 	pop	ar0
   674F 02 65 6B           5016 	ljmp	00134$
   6752                    5017 00137$:
                           5018 ;	../../Common/stack.c:979: if (stack_check_broadcast(a1->address, a1->addr_type) == pdTRUE)
                           5019 ;	genPointerGet
                           5020 ;	genGenPointerGet
   6752 C0 00              5021 	push	ar0
   6754 A8 10              5022 	mov	r0,_bp
   6756 08                 5023 	inc	r0
   6757 86 82              5024 	mov	dpl,@r0
   6759 08                 5025 	inc	r0
   675A 86 83              5026 	mov	dph,@r0
   675C 08                 5027 	inc	r0
   675D 86 F0              5028 	mov	b,@r0
   675F 12 E4 9F           5029 	lcall	__gptrget
   6762 FA                 5030 	mov	r2,a
   6763 D0 00              5031 	pop	ar0
                           5032 ;	genPlus
   6765 C0 00              5033 	push	ar0
   6767 A8 10              5034 	mov	r0,_bp
   6769 08                 5035 	inc	r0
                           5036 ;     genPlusIncr
   676A 74 01              5037 	mov	a,#0x01
   676C 26                 5038 	add	a,@r0
   676D FB                 5039 	mov	r3,a
                           5040 ;	Peephole 181	changed mov to clr
   676E E4                 5041 	clr	a
   676F 08                 5042 	inc	r0
   6770 36                 5043 	addc	a,@r0
   6771 FC                 5044 	mov	r4,a
   6772 08                 5045 	inc	r0
   6773 86 07              5046 	mov	ar7,@r0
   6775 D0 00              5047 	pop	ar0
                           5048 ;	genIpush
   6777 C0 05              5049 	push	ar5
   6779 C0 06              5050 	push	ar6
   677B C0 00              5051 	push	ar0
   677D C0 01              5052 	push	ar1
   677F C0 02              5053 	push	ar2
                           5054 ;	genCall
   6781 8B 82              5055 	mov	dpl,r3
   6783 8C 83              5056 	mov	dph,r4
   6785 8F F0              5057 	mov	b,r7
   6787 12 6B 44           5058 	lcall	_stack_check_broadcast
   678A AA 82              5059 	mov	r2,dpl
   678C 15 81              5060 	dec	sp
   678E D0 01              5061 	pop	ar1
   6790 D0 00              5062 	pop	ar0
   6792 D0 06              5063 	pop	ar6
   6794 D0 05              5064 	pop	ar5
                           5065 ;	genCmpEq
                           5066 ;	gencjneshort
                           5067 ;	Peephole 112.b	changed ljmp to sjmp
                           5068 ;	Peephole 198.b	optimized misc jump sequence
   6796 BA 01 0B           5069 	cjne	r2,#0x01,00116$
                           5070 ;	Peephole 200.b	removed redundant sjmp
                           5071 ;	Peephole 300	removed redundant label 00161$
                           5072 ;	Peephole 300	removed redundant label 00162$
                           5073 ;	../../Common/stack.c:981: match = 1;
                           5074 ;	genAssign
   6799 C0 00              5075 	push	ar0
   679B E5 10              5076 	mov	a,_bp
   679D 24 0A              5077 	add	a,#0x0a
   679F F8                 5078 	mov	r0,a
   67A0 76 01              5079 	mov	@r0,#0x01
   67A2 D0 00              5080 	pop	ar0
   67A4                    5081 00116$:
                           5082 ;	../../Common/stack.c:983: if (stack_check_broadcast(a2->address, a2->addr_type) == pdTRUE)
                           5083 ;	genPointerGet
                           5084 ;	genGenPointerGet
   67A4 C0 00              5085 	push	ar0
   67A6 E5 10              5086 	mov	a,_bp
   67A8 24 0F              5087 	add	a,#0x0f
   67AA F8                 5088 	mov	r0,a
   67AB 86 82              5089 	mov	dpl,@r0
   67AD 08                 5090 	inc	r0
   67AE 86 83              5091 	mov	dph,@r0
   67B0 08                 5092 	inc	r0
   67B1 86 F0              5093 	mov	b,@r0
   67B3 12 E4 9F           5094 	lcall	__gptrget
   67B6 FA                 5095 	mov	r2,a
   67B7 D0 00              5096 	pop	ar0
                           5097 ;	genPlus
   67B9 C0 00              5098 	push	ar0
   67BB E5 10              5099 	mov	a,_bp
   67BD 24 0F              5100 	add	a,#0x0f
   67BF F8                 5101 	mov	r0,a
                           5102 ;     genPlusIncr
   67C0 74 01              5103 	mov	a,#0x01
   67C2 26                 5104 	add	a,@r0
   67C3 FB                 5105 	mov	r3,a
                           5106 ;	Peephole 181	changed mov to clr
   67C4 E4                 5107 	clr	a
   67C5 08                 5108 	inc	r0
   67C6 36                 5109 	addc	a,@r0
   67C7 FC                 5110 	mov	r4,a
   67C8 08                 5111 	inc	r0
   67C9 86 07              5112 	mov	ar7,@r0
   67CB D0 00              5113 	pop	ar0
                           5114 ;	genIpush
   67CD C0 05              5115 	push	ar5
   67CF C0 06              5116 	push	ar6
   67D1 C0 00              5117 	push	ar0
   67D3 C0 01              5118 	push	ar1
   67D5 C0 02              5119 	push	ar2
                           5120 ;	genCall
   67D7 8B 82              5121 	mov	dpl,r3
   67D9 8C 83              5122 	mov	dph,r4
   67DB 8F F0              5123 	mov	b,r7
   67DD 12 6B 44           5124 	lcall	_stack_check_broadcast
   67E0 AA 82              5125 	mov	r2,dpl
   67E2 15 81              5126 	dec	sp
   67E4 D0 01              5127 	pop	ar1
   67E6 D0 00              5128 	pop	ar0
   67E8 D0 06              5129 	pop	ar6
   67EA D0 05              5130 	pop	ar5
                           5131 ;	genCmpEq
                           5132 ;	gencjneshort
                           5133 ;	Peephole 112.b	changed ljmp to sjmp
                           5134 ;	Peephole 198.b	optimized misc jump sequence
   67EC BA 01 0B           5135 	cjne	r2,#0x01,00118$
                           5136 ;	Peephole 200.b	removed redundant sjmp
                           5137 ;	Peephole 300	removed redundant label 00163$
                           5138 ;	Peephole 300	removed redundant label 00164$
                           5139 ;	../../Common/stack.c:985: match = 1;
                           5140 ;	genAssign
   67EF C0 00              5141 	push	ar0
   67F1 E5 10              5142 	mov	a,_bp
   67F3 24 0A              5143 	add	a,#0x0a
   67F5 F8                 5144 	mov	r0,a
   67F6 76 01              5145 	mov	@r0,#0x01
   67F8 D0 00              5146 	pop	ar0
   67FA                    5147 00118$:
                           5148 ;	../../Common/stack.c:988: if (!match)
                           5149 ;	genIfx
   67FA C0 00              5150 	push	ar0
   67FC E5 10              5151 	mov	a,_bp
   67FE 24 0A              5152 	add	a,#0x0a
   6800 F8                 5153 	mov	r0,a
   6801 E6                 5154 	mov	a,@r0
   6802 D0 00              5155 	pop	ar0
                           5156 ;	genIfxJump
   6804 60 03              5157 	jz	00165$
   6806 02 68 8F           5158 	ljmp	00125$
   6809                    5159 00165$:
                           5160 ;	../../Common/stack.c:991: if (size[0] > size[1]) cmp_size = size[1];
                           5161 ;	genPointerGet
                           5162 ;	genNearPointerGet
   6809 86 02              5163 	mov	ar2,@r0
                           5164 ;	genPointerGet
                           5165 ;	genNearPointerGet
   680B 87 03              5166 	mov	ar3,@r1
                           5167 ;	genCmpGt
                           5168 ;	genCmp
   680D C3                 5169 	clr	c
   680E EB                 5170 	mov	a,r3
   680F 9A                 5171 	subb	a,r2
                           5172 ;	genIfxJump
                           5173 ;	Peephole 108.a	removed ljmp by inverse jump logic
   6810 50 04              5174 	jnc	00120$
                           5175 ;	Peephole 300	removed redundant label 00166$
                           5176 ;	genPointerGet
                           5177 ;	genNearPointerGet
   6812 87 02              5178 	mov	ar2,@r1
                           5179 ;	genAssign
                           5180 ;	Peephole 112.b	changed ljmp to sjmp
   6814 80 04              5181 	sjmp	00121$
   6816                    5182 00120$:
                           5183 ;	../../Common/stack.c:992: else 	cmp_size = size[0];
                           5184 ;	genPointerGet
                           5185 ;	genNearPointerGet
   6816 86 03              5186 	mov	ar3,@r0
                           5187 ;	genAssign
   6818 8B 02              5188 	mov	ar2,r3
   681A                    5189 00121$:
                           5190 ;	../../Common/stack.c:993: if (memcmp(a2->address, a1->address, cmp_size) == 0)
                           5191 ;	genIpush
   681A C0 06              5192 	push	ar6
                           5193 ;	genCast
   681C E5 10              5194 	mov	a,_bp
   681E 24 12              5195 	add	a,#0x12
   6820 F8                 5196 	mov	r0,a
   6821 A6 02              5197 	mov	@r0,ar2
   6823 08                 5198 	inc	r0
   6824 76 00              5199 	mov	@r0,#0x00
                           5200 ;	genPlus
   6826 A8 10              5201 	mov	r0,_bp
   6828 08                 5202 	inc	r0
   6829 E5 10              5203 	mov	a,_bp
   682B 24 15              5204 	add	a,#0x15
   682D F9                 5205 	mov	r1,a
                           5206 ;     genPlusIncr
   682E 74 01              5207 	mov	a,#0x01
   6830 26                 5208 	add	a,@r0
   6831 F7                 5209 	mov	@r1,a
                           5210 ;	Peephole 181	changed mov to clr
   6832 E4                 5211 	clr	a
   6833 08                 5212 	inc	r0
   6834 36                 5213 	addc	a,@r0
   6835 09                 5214 	inc	r1
   6836 F7                 5215 	mov	@r1,a
   6837 08                 5216 	inc	r0
   6838 09                 5217 	inc	r1
   6839 E6                 5218 	mov	a,@r0
   683A F7                 5219 	mov	@r1,a
                           5220 ;	genPlus
   683B E5 10              5221 	mov	a,_bp
   683D 24 0F              5222 	add	a,#0x0f
   683F F8                 5223 	mov	r0,a
                           5224 ;     genPlusIncr
   6840 74 01              5225 	mov	a,#0x01
   6842 26                 5226 	add	a,@r0
   6843 FA                 5227 	mov	r2,a
                           5228 ;	Peephole 181	changed mov to clr
   6844 E4                 5229 	clr	a
   6845 08                 5230 	inc	r0
   6846 36                 5231 	addc	a,@r0
   6847 FB                 5232 	mov	r3,a
   6848 08                 5233 	inc	r0
   6849 86 04              5234 	mov	ar4,@r0
                           5235 ;	genIpush
   684B C0 05              5236 	push	ar5
   684D C0 06              5237 	push	ar6
   684F E5 10              5238 	mov	a,_bp
   6851 24 12              5239 	add	a,#0x12
   6853 F8                 5240 	mov	r0,a
   6854 E6                 5241 	mov	a,@r0
   6855 C0 E0              5242 	push	acc
   6857 08                 5243 	inc	r0
   6858 E6                 5244 	mov	a,@r0
   6859 C0 E0              5245 	push	acc
                           5246 ;	genIpush
   685B E5 10              5247 	mov	a,_bp
   685D 24 15              5248 	add	a,#0x15
   685F F8                 5249 	mov	r0,a
   6860 E6                 5250 	mov	a,@r0
   6861 C0 E0              5251 	push	acc
   6863 08                 5252 	inc	r0
   6864 E6                 5253 	mov	a,@r0
   6865 C0 E0              5254 	push	acc
   6867 08                 5255 	inc	r0
   6868 E6                 5256 	mov	a,@r0
   6869 C0 E0              5257 	push	acc
                           5258 ;	genCall
   686B 8A 82              5259 	mov	dpl,r2
   686D 8B 83              5260 	mov	dph,r3
   686F 8C F0              5261 	mov	b,r4
   6871 12 E2 0A           5262 	lcall	_memcmp
   6874 AA 82              5263 	mov	r2,dpl
   6876 AB 83              5264 	mov	r3,dph
   6878 E5 81              5265 	mov	a,sp
   687A 24 FB              5266 	add	a,#0xfb
   687C F5 81              5267 	mov	sp,a
   687E D0 06              5268 	pop	ar6
   6880 D0 05              5269 	pop	ar5
                           5270 ;	genIpop
   6882 D0 06              5271 	pop	ar6
                           5272 ;	genIfx
   6884 EA                 5273 	mov	a,r2
   6885 4B                 5274 	orl	a,r3
                           5275 ;	genIfxJump
                           5276 ;	Peephole 108.b	removed ljmp by inverse jump logic
   6886 70 07              5277 	jnz	00125$
                           5278 ;	Peephole 300	removed redundant label 00167$
                           5279 ;	../../Common/stack.c:995: match = 1;
                           5280 ;	genAssign
   6888 E5 10              5281 	mov	a,_bp
   688A 24 0A              5282 	add	a,#0x0a
   688C F8                 5283 	mov	r0,a
   688D 76 01              5284 	mov	@r0,#0x01
   688F                    5285 00125$:
                           5286 ;	../../Common/stack.c:999: if (match)
                           5287 ;	genIfx
   688F E5 10              5288 	mov	a,_bp
   6891 24 0A              5289 	add	a,#0x0a
   6893 F8                 5290 	mov	r0,a
   6894 E6                 5291 	mov	a,@r0
                           5292 ;	genIfxJump
                           5293 ;	Peephole 108.c	removed ljmp by inverse jump logic
   6895 60 3B              5294 	jz	00132$
                           5295 ;	Peephole 300	removed redundant label 00168$
                           5296 ;	../../Common/stack.c:1001: if ((pan[0] != 0xFFFF) && (pan[1] != 0xFFFF))
                           5297 ;	genPointerGet
                           5298 ;	genNearPointerGet
   6897 A8 05              5299 	mov	r0,ar5
   6899 86 02              5300 	mov	ar2,@r0
   689B 08                 5301 	inc	r0
   689C 86 03              5302 	mov	ar3,@r0
                           5303 ;	genCmpEq
                           5304 ;	gencjneshort
   689E BA FF 05           5305 	cjne	r2,#0xFF,00169$
   68A1 BB FF 02           5306 	cjne	r3,#0xFF,00169$
                           5307 ;	Peephole 112.b	changed ljmp to sjmp
   68A4 80 31              5308 	sjmp	00133$
   68A6                    5309 00169$:
                           5310 ;	genPointerGet
                           5311 ;	genNearPointerGet
   68A6 A8 06              5312 	mov	r0,ar6
   68A8 86 02              5313 	mov	ar2,@r0
   68AA 08                 5314 	inc	r0
   68AB 86 03              5315 	mov	ar3,@r0
                           5316 ;	genCmpEq
                           5317 ;	gencjneshort
   68AD BA FF 05           5318 	cjne	r2,#0xFF,00170$
   68B0 BB FF 02           5319 	cjne	r3,#0xFF,00170$
                           5320 ;	Peephole 112.b	changed ljmp to sjmp
   68B3 80 22              5321 	sjmp	00133$
   68B5                    5322 00170$:
                           5323 ;	../../Common/stack.c:1003: if (pan[0] != pan[1]) return pdFALSE;
                           5324 ;	genPointerGet
                           5325 ;	genNearPointerGet
   68B5 A8 05              5326 	mov	r0,ar5
   68B7 86 02              5327 	mov	ar2,@r0
   68B9 08                 5328 	inc	r0
   68BA 86 03              5329 	mov	ar3,@r0
                           5330 ;	genPointerGet
                           5331 ;	genNearPointerGet
   68BC A8 06              5332 	mov	r0,ar6
   68BE 86 04              5333 	mov	ar4,@r0
   68C0 08                 5334 	inc	r0
   68C1 86 05              5335 	mov	ar5,@r0
                           5336 ;	genCmpEq
                           5337 ;	gencjneshort
   68C3 EA                 5338 	mov	a,r2
   68C4 B5 04 06           5339 	cjne	a,ar4,00171$
   68C7 EB                 5340 	mov	a,r3
   68C8 B5 05 02           5341 	cjne	a,ar5,00171$
                           5342 ;	Peephole 112.b	changed ljmp to sjmp
   68CB 80 0A              5343 	sjmp	00133$
   68CD                    5344 00171$:
                           5345 ;	genRet
   68CD 75 82 00           5346 	mov	dpl,#0x00
                           5347 ;	Peephole 112.b	changed ljmp to sjmp
   68D0 80 08              5348 	sjmp	00138$
   68D2                    5349 00132$:
                           5350 ;	../../Common/stack.c:1008: return pdFALSE;
                           5351 ;	genRet
   68D2 75 82 00           5352 	mov	dpl,#0x00
                           5353 ;	Peephole 112.b	changed ljmp to sjmp
   68D5 80 03              5354 	sjmp	00138$
   68D7                    5355 00133$:
                           5356 ;	../../Common/stack.c:1011: return pdTRUE;
                           5357 ;	genRet
   68D7 75 82 01           5358 	mov	dpl,#0x01
   68DA                    5359 00138$:
   68DA 85 10 81           5360 	mov	sp,_bp
   68DD D0 10              5361 	pop	_bp
   68DF 22                 5362 	ret
                           5363 ;------------------------------------------------------------
                           5364 ;Allocation info for local variables in function 'stack_insert_address_to_buffer'
                           5365 ;------------------------------------------------------------
                           5366 ;ind                       Allocated to stack - offset -3
                           5367 ;type                      Allocated to stack - offset -4
                           5368 ;address                   Allocated to stack - offset -7
                           5369 ;buf                       Allocated to registers r2 r3 r4 
                           5370 ;i                         Allocated to registers r6 
                           5371 ;sloc0                     Allocated to stack - offset 1
                           5372 ;sloc1                     Allocated to stack - offset 4
                           5373 ;sloc2                     Allocated to stack - offset 7
                           5374 ;------------------------------------------------------------
                           5375 ;	../../Common/stack.c:1023: uint8_t stack_insert_address_to_buffer(buffer_t *buf, uint8_t ind, addrtype_t type, address_t address)
                           5376 ;	-----------------------------------------
                           5377 ;	 function stack_insert_address_to_buffer
                           5378 ;	-----------------------------------------
   68E0                    5379 _stack_insert_address_to_buffer:
   68E0 C0 10              5380 	push	_bp
                           5381 ;	peephole 177.h	optimized mov sequence
   68E2 E5 81              5382 	mov	a,sp
   68E4 F5 10              5383 	mov	_bp,a
   68E6 24 09              5384 	add	a,#0x09
   68E8 F5 81              5385 	mov	sp,a
                           5386 ;	genReceive
   68EA AA 82              5387 	mov	r2,dpl
   68EC AB 83              5388 	mov	r3,dph
   68EE AC F0              5389 	mov	r4,b
                           5390 ;	../../Common/stack.c:1026: if(type == ADDR_802_15_4_PAN_LONG || type == ADDR_802_15_4_LONG )
                           5391 ;	genCmpEq
   68F0 E5 10              5392 	mov	a,_bp
   68F2 24 FC              5393 	add	a,#0xfffffffc
   68F4 F8                 5394 	mov	r0,a
                           5395 ;	gencjne
                           5396 ;	gencjneshort
                           5397 ;	Peephole 241.h	optimized compare
   68F5 E4                 5398 	clr	a
   68F6 B6 04 01           5399 	cjne	@r0,#0x04,00132$
   68F9 04                 5400 	inc	a
   68FA                    5401 00132$:
                           5402 ;	Peephole 300	removed redundant label 00133$
                           5403 ;	genIfx
   68FA FD                 5404 	mov	r5,a
                           5405 ;	Peephole 105	removed redundant mov
                           5406 ;	genIfxJump
                           5407 ;	Peephole 108.b	removed ljmp by inverse jump logic
   68FB 70 0D              5408 	jnz	00108$
                           5409 ;	Peephole 300	removed redundant label 00134$
                           5410 ;	genCmpEq
   68FD E5 10              5411 	mov	a,_bp
   68FF 24 FC              5412 	add	a,#0xfffffffc
   6901 F8                 5413 	mov	r0,a
                           5414 ;	gencjneshort
   6902 B6 01 02           5415 	cjne	@r0,#0x01,00135$
   6905 80 03              5416 	sjmp	00136$
   6907                    5417 00135$:
   6907 02 6A 0B           5418 	ljmp	00109$
   690A                    5419 00136$:
   690A                    5420 00108$:
                           5421 ;	../../Common/stack.c:1028: if(type == ADDR_802_15_4_PAN_LONG)
                           5422 ;	genIfx
   690A ED                 5423 	mov	a,r5
                           5424 ;	genIfxJump
   690B 70 03              5425 	jnz	00137$
   690D 02 69 A4           5426 	ljmp	00125$
   6910                    5427 00137$:
                           5428 ;	../../Common/stack.c:1030: buf->buf[ind++] = address[8];
                           5429 ;	genPlus
                           5430 ;     genPlusIncr
   6910 74 2C              5431 	mov	a,#0x2C
                           5432 ;	Peephole 236.a	used r2 instead of ar2
   6912 2A                 5433 	add	a,r2
   6913 FD                 5434 	mov	r5,a
                           5435 ;	Peephole 181	changed mov to clr
   6914 E4                 5436 	clr	a
                           5437 ;	Peephole 236.b	used r3 instead of ar3
   6915 3B                 5438 	addc	a,r3
   6916 FE                 5439 	mov	r6,a
   6917 8C 07              5440 	mov	ar7,r4
                           5441 ;	genIpush
   6919 C0 02              5442 	push	ar2
   691B C0 03              5443 	push	ar3
   691D C0 04              5444 	push	ar4
                           5445 ;	genAssign
   691F A8 10              5446 	mov	r0,_bp
   6921 18                 5447 	dec	r0
   6922 18                 5448 	dec	r0
   6923 18                 5449 	dec	r0
   6924 86 02              5450 	mov	ar2,@r0
                           5451 ;	genPlus
   6926 A8 10              5452 	mov	r0,_bp
   6928 18                 5453 	dec	r0
   6929 18                 5454 	dec	r0
   692A 18                 5455 	dec	r0
                           5456 ;     genPlusIncr
   692B 74 01              5457 	mov	a,#0x01
                           5458 ;	Peephole 236.a	used r2 instead of ar2
   692D 2A                 5459 	add	a,r2
   692E F6                 5460 	mov	@r0,a
                           5461 ;	genPlus
   692F A8 10              5462 	mov	r0,_bp
   6931 08                 5463 	inc	r0
                           5464 ;	Peephole 236.g	used r2 instead of ar2
   6932 EA                 5465 	mov	a,r2
                           5466 ;	Peephole 236.a	used r5 instead of ar5
   6933 2D                 5467 	add	a,r5
   6934 F6                 5468 	mov	@r0,a
                           5469 ;	Peephole 181	changed mov to clr
   6935 E4                 5470 	clr	a
                           5471 ;	Peephole 236.b	used r6 instead of ar6
   6936 3E                 5472 	addc	a,r6
   6937 08                 5473 	inc	r0
   6938 F6                 5474 	mov	@r0,a
   6939 08                 5475 	inc	r0
   693A A6 07              5476 	mov	@r0,ar7
                           5477 ;	genPlus
   693C E5 10              5478 	mov	a,_bp
   693E 24 F9              5479 	add	a,#0xfffffff9
   6940 F8                 5480 	mov	r0,a
                           5481 ;     genPlusIncr
   6941 74 08              5482 	mov	a,#0x08
   6943 26                 5483 	add	a,@r0
   6944 FA                 5484 	mov	r2,a
                           5485 ;	Peephole 181	changed mov to clr
   6945 E4                 5486 	clr	a
   6946 08                 5487 	inc	r0
   6947 36                 5488 	addc	a,@r0
   6948 FB                 5489 	mov	r3,a
   6949 08                 5490 	inc	r0
   694A 86 04              5491 	mov	ar4,@r0
                           5492 ;	genPointerGet
                           5493 ;	genGenPointerGet
   694C 8A 82              5494 	mov	dpl,r2
   694E 8B 83              5495 	mov	dph,r3
   6950 8C F0              5496 	mov	b,r4
   6952 12 E4 9F           5497 	lcall	__gptrget
   6955 FA                 5498 	mov	r2,a
                           5499 ;	genPointerSet
                           5500 ;	genGenPointerSet
   6956 A8 10              5501 	mov	r0,_bp
   6958 08                 5502 	inc	r0
   6959 86 82              5503 	mov	dpl,@r0
   695B 08                 5504 	inc	r0
   695C 86 83              5505 	mov	dph,@r0
   695E 08                 5506 	inc	r0
   695F 86 F0              5507 	mov	b,@r0
   6961 EA                 5508 	mov	a,r2
   6962 12 DF B7           5509 	lcall	__gptrput
                           5510 ;	../../Common/stack.c:1031: buf->buf[ind++] = address[9];
                           5511 ;	genAssign
   6965 A8 10              5512 	mov	r0,_bp
   6967 18                 5513 	dec	r0
   6968 18                 5514 	dec	r0
   6969 18                 5515 	dec	r0
   696A 86 02              5516 	mov	ar2,@r0
                           5517 ;	genPlus
   696C A8 10              5518 	mov	r0,_bp
   696E 18                 5519 	dec	r0
   696F 18                 5520 	dec	r0
   6970 18                 5521 	dec	r0
                           5522 ;     genPlusIncr
   6971 74 01              5523 	mov	a,#0x01
                           5524 ;	Peephole 236.a	used r2 instead of ar2
   6973 2A                 5525 	add	a,r2
   6974 F6                 5526 	mov	@r0,a
                           5527 ;	genPlus
                           5528 ;	Peephole 236.g	used r2 instead of ar2
   6975 EA                 5529 	mov	a,r2
                           5530 ;	Peephole 236.a	used r5 instead of ar5
   6976 2D                 5531 	add	a,r5
   6977 FD                 5532 	mov	r5,a
                           5533 ;	Peephole 181	changed mov to clr
   6978 E4                 5534 	clr	a
                           5535 ;	Peephole 236.b	used r6 instead of ar6
   6979 3E                 5536 	addc	a,r6
   697A FE                 5537 	mov	r6,a
                           5538 ;	genPlus
   697B E5 10              5539 	mov	a,_bp
   697D 24 F9              5540 	add	a,#0xfffffff9
   697F F8                 5541 	mov	r0,a
                           5542 ;     genPlusIncr
   6980 74 09              5543 	mov	a,#0x09
   6982 26                 5544 	add	a,@r0
   6983 FA                 5545 	mov	r2,a
                           5546 ;	Peephole 181	changed mov to clr
   6984 E4                 5547 	clr	a
   6985 08                 5548 	inc	r0
   6986 36                 5549 	addc	a,@r0
   6987 FB                 5550 	mov	r3,a
   6988 08                 5551 	inc	r0
   6989 86 04              5552 	mov	ar4,@r0
                           5553 ;	genPointerGet
                           5554 ;	genGenPointerGet
   698B 8A 82              5555 	mov	dpl,r2
   698D 8B 83              5556 	mov	dph,r3
   698F 8C F0              5557 	mov	b,r4
   6991 12 E4 9F           5558 	lcall	__gptrget
                           5559 ;	genPointerSet
                           5560 ;	genGenPointerSet
   6994 FA                 5561 	mov	r2,a
   6995 8D 82              5562 	mov	dpl,r5
   6997 8E 83              5563 	mov	dph,r6
   6999 8F F0              5564 	mov	b,r7
                           5565 ;	Peephole 191	removed redundant mov
   699B 12 DF B7           5566 	lcall	__gptrput
                           5567 ;	../../Common/stack.c:1054: return ind;
                           5568 ;	genIpop
   699E D0 04              5569 	pop	ar4
   69A0 D0 03              5570 	pop	ar3
   69A2 D0 02              5571 	pop	ar2
                           5572 ;	../../Common/stack.c:1033: for (i = 0; i < 8; i++)
   69A4                    5573 00125$:
                           5574 ;	genPlus
   69A4 E5 10              5575 	mov	a,_bp
   69A6 24 04              5576 	add	a,#0x04
   69A8 F8                 5577 	mov	r0,a
                           5578 ;     genPlusIncr
   69A9 74 2C              5579 	mov	a,#0x2C
                           5580 ;	Peephole 236.a	used r2 instead of ar2
   69AB 2A                 5581 	add	a,r2
   69AC F6                 5582 	mov	@r0,a
                           5583 ;	Peephole 181	changed mov to clr
   69AD E4                 5584 	clr	a
                           5585 ;	Peephole 236.b	used r3 instead of ar3
   69AE 3B                 5586 	addc	a,r3
   69AF 08                 5587 	inc	r0
   69B0 F6                 5588 	mov	@r0,a
   69B1 08                 5589 	inc	r0
   69B2 A6 04              5590 	mov	@r0,ar4
                           5591 ;	genAssign
   69B4 A8 10              5592 	mov	r0,_bp
   69B6 18                 5593 	dec	r0
   69B7 18                 5594 	dec	r0
   69B8 18                 5595 	dec	r0
   69B9 86 02              5596 	mov	ar2,@r0
                           5597 ;	genAssign
   69BB 7B 00              5598 	mov	r3,#0x00
   69BD                    5599 00112$:
                           5600 ;	genCmpLt
                           5601 ;	genCmp
   69BD BB 08 00           5602 	cjne	r3,#0x08,00138$
   69C0                    5603 00138$:
                           5604 ;	genIfxJump
   69C0 40 03              5605 	jc	00139$
   69C2 02 6B 27           5606 	ljmp	00130$
   69C5                    5607 00139$:
                           5608 ;	../../Common/stack.c:1035: buf->buf[ind++] = address[i];
                           5609 ;	genAssign
   69C5 8A 06              5610 	mov	ar6,r2
                           5611 ;	genPlus
                           5612 ;     genPlusIncr
   69C7 0A                 5613 	inc	r2
                           5614 ;	genPlus
   69C8 E5 10              5615 	mov	a,_bp
   69CA 24 04              5616 	add	a,#0x04
   69CC F8                 5617 	mov	r0,a
   69CD E5 10              5618 	mov	a,_bp
   69CF 24 07              5619 	add	a,#0x07
   69D1 F9                 5620 	mov	r1,a
                           5621 ;	Peephole 236.g	used r6 instead of ar6
   69D2 EE                 5622 	mov	a,r6
   69D3 26                 5623 	add	a,@r0
   69D4 F7                 5624 	mov	@r1,a
                           5625 ;	Peephole 181	changed mov to clr
   69D5 E4                 5626 	clr	a
   69D6 08                 5627 	inc	r0
   69D7 36                 5628 	addc	a,@r0
   69D8 09                 5629 	inc	r1
   69D9 F7                 5630 	mov	@r1,a
   69DA 08                 5631 	inc	r0
   69DB 09                 5632 	inc	r1
   69DC E6                 5633 	mov	a,@r0
   69DD F7                 5634 	mov	@r1,a
                           5635 ;	genPlus
   69DE E5 10              5636 	mov	a,_bp
   69E0 24 F9              5637 	add	a,#0xfffffff9
   69E2 F8                 5638 	mov	r0,a
                           5639 ;	Peephole 236.g	used r3 instead of ar3
   69E3 EB                 5640 	mov	a,r3
   69E4 26                 5641 	add	a,@r0
   69E5 FD                 5642 	mov	r5,a
                           5643 ;	Peephole 181	changed mov to clr
   69E6 E4                 5644 	clr	a
   69E7 08                 5645 	inc	r0
   69E8 36                 5646 	addc	a,@r0
   69E9 FE                 5647 	mov	r6,a
   69EA 08                 5648 	inc	r0
   69EB 86 07              5649 	mov	ar7,@r0
                           5650 ;	genPointerGet
                           5651 ;	genGenPointerGet
   69ED 8D 82              5652 	mov	dpl,r5
   69EF 8E 83              5653 	mov	dph,r6
   69F1 8F F0              5654 	mov	b,r7
   69F3 12 E4 9F           5655 	lcall	__gptrget
   69F6 FD                 5656 	mov	r5,a
                           5657 ;	genPointerSet
                           5658 ;	genGenPointerSet
   69F7 E5 10              5659 	mov	a,_bp
   69F9 24 07              5660 	add	a,#0x07
   69FB F8                 5661 	mov	r0,a
   69FC 86 82              5662 	mov	dpl,@r0
   69FE 08                 5663 	inc	r0
   69FF 86 83              5664 	mov	dph,@r0
   6A01 08                 5665 	inc	r0
   6A02 86 F0              5666 	mov	b,@r0
   6A04 ED                 5667 	mov	a,r5
   6A05 12 DF B7           5668 	lcall	__gptrput
                           5669 ;	../../Common/stack.c:1033: for (i = 0; i < 8; i++)
                           5670 ;	genPlus
                           5671 ;     genPlusIncr
   6A08 0B                 5672 	inc	r3
                           5673 ;	Peephole 112.b	changed ljmp to sjmp
   6A09 80 B2              5674 	sjmp	00112$
   6A0B                    5675 00109$:
                           5676 ;	../../Common/stack.c:1038: else if(type == ADDR_802_15_4_PAN_SHORT  || type == ADDR_802_15_4_SHORT)
                           5677 ;	genCmpEq
   6A0B E5 10              5678 	mov	a,_bp
   6A0D 24 FC              5679 	add	a,#0xfffffffc
   6A0F F8                 5680 	mov	r0,a
                           5681 ;	gencjne
                           5682 ;	gencjneshort
                           5683 ;	Peephole 241.h	optimized compare
   6A10 E4                 5684 	clr	a
   6A11 B6 03 01           5685 	cjne	@r0,#0x03,00140$
   6A14 04                 5686 	inc	a
   6A15                    5687 00140$:
                           5688 ;	Peephole 300	removed redundant label 00141$
                           5689 ;	genIfx
   6A15 FD                 5690 	mov	r5,a
                           5691 ;	Peephole 105	removed redundant mov
                           5692 ;	genIfxJump
                           5693 ;	Peephole 108.b	removed ljmp by inverse jump logic
   6A16 70 0D              5694 	jnz	00105$
                           5695 ;	Peephole 300	removed redundant label 00142$
                           5696 ;	genCmpEq
   6A18 E5 10              5697 	mov	a,_bp
   6A1A 24 FC              5698 	add	a,#0xfffffffc
   6A1C F8                 5699 	mov	r0,a
                           5700 ;	gencjneshort
   6A1D B6 02 02           5701 	cjne	@r0,#0x02,00143$
   6A20 80 03              5702 	sjmp	00144$
   6A22                    5703 00143$:
   6A22 02 6B 37           5704 	ljmp	00110$
   6A25                    5705 00144$:
   6A25                    5706 00105$:
                           5707 ;	../../Common/stack.c:1040: if(type == ADDR_802_15_4_PAN_SHORT)
                           5708 ;	genIfx
   6A25 ED                 5709 	mov	a,r5
                           5710 ;	genIfxJump
   6A26 70 03              5711 	jnz	00145$
   6A28 02 6A C3           5712 	ljmp	00129$
   6A2B                    5713 00145$:
                           5714 ;	../../Common/stack.c:1042: buf->buf[ind++] = address[2];
                           5715 ;	genPlus
                           5716 ;     genPlusIncr
   6A2B 74 2C              5717 	mov	a,#0x2C
                           5718 ;	Peephole 236.a	used r2 instead of ar2
   6A2D 2A                 5719 	add	a,r2
   6A2E FD                 5720 	mov	r5,a
                           5721 ;	Peephole 181	changed mov to clr
   6A2F E4                 5722 	clr	a
                           5723 ;	Peephole 236.b	used r3 instead of ar3
   6A30 3B                 5724 	addc	a,r3
   6A31 FE                 5725 	mov	r6,a
   6A32 8C 07              5726 	mov	ar7,r4
                           5727 ;	genIpush
   6A34 C0 02              5728 	push	ar2
   6A36 C0 03              5729 	push	ar3
   6A38 C0 04              5730 	push	ar4
                           5731 ;	genAssign
   6A3A A8 10              5732 	mov	r0,_bp
   6A3C 18                 5733 	dec	r0
   6A3D 18                 5734 	dec	r0
   6A3E 18                 5735 	dec	r0
   6A3F 86 02              5736 	mov	ar2,@r0
                           5737 ;	genPlus
   6A41 A8 10              5738 	mov	r0,_bp
   6A43 18                 5739 	dec	r0
   6A44 18                 5740 	dec	r0
   6A45 18                 5741 	dec	r0
                           5742 ;     genPlusIncr
   6A46 74 01              5743 	mov	a,#0x01
                           5744 ;	Peephole 236.a	used r2 instead of ar2
   6A48 2A                 5745 	add	a,r2
   6A49 F6                 5746 	mov	@r0,a
                           5747 ;	genPlus
   6A4A E5 10              5748 	mov	a,_bp
   6A4C 24 07              5749 	add	a,#0x07
   6A4E F8                 5750 	mov	r0,a
                           5751 ;	Peephole 236.g	used r2 instead of ar2
   6A4F EA                 5752 	mov	a,r2
                           5753 ;	Peephole 236.a	used r5 instead of ar5
   6A50 2D                 5754 	add	a,r5
   6A51 F6                 5755 	mov	@r0,a
                           5756 ;	Peephole 181	changed mov to clr
   6A52 E4                 5757 	clr	a
                           5758 ;	Peephole 236.b	used r6 instead of ar6
   6A53 3E                 5759 	addc	a,r6
   6A54 08                 5760 	inc	r0
   6A55 F6                 5761 	mov	@r0,a
   6A56 08                 5762 	inc	r0
   6A57 A6 07              5763 	mov	@r0,ar7
                           5764 ;	genPlus
   6A59 E5 10              5765 	mov	a,_bp
   6A5B 24 F9              5766 	add	a,#0xfffffff9
   6A5D F8                 5767 	mov	r0,a
                           5768 ;     genPlusIncr
   6A5E 74 02              5769 	mov	a,#0x02
   6A60 26                 5770 	add	a,@r0
   6A61 FA                 5771 	mov	r2,a
                           5772 ;	Peephole 181	changed mov to clr
   6A62 E4                 5773 	clr	a
   6A63 08                 5774 	inc	r0
   6A64 36                 5775 	addc	a,@r0
   6A65 FB                 5776 	mov	r3,a
   6A66 08                 5777 	inc	r0
   6A67 86 04              5778 	mov	ar4,@r0
                           5779 ;	genPointerGet
                           5780 ;	genGenPointerGet
   6A69 8A 82              5781 	mov	dpl,r2
   6A6B 8B 83              5782 	mov	dph,r3
   6A6D 8C F0              5783 	mov	b,r4
   6A6F 12 E4 9F           5784 	lcall	__gptrget
   6A72 FA                 5785 	mov	r2,a
                           5786 ;	genPointerSet
                           5787 ;	genGenPointerSet
   6A73 E5 10              5788 	mov	a,_bp
   6A75 24 07              5789 	add	a,#0x07
   6A77 F8                 5790 	mov	r0,a
   6A78 86 82              5791 	mov	dpl,@r0
   6A7A 08                 5792 	inc	r0
   6A7B 86 83              5793 	mov	dph,@r0
   6A7D 08                 5794 	inc	r0
   6A7E 86 F0              5795 	mov	b,@r0
   6A80 EA                 5796 	mov	a,r2
   6A81 12 DF B7           5797 	lcall	__gptrput
                           5798 ;	../../Common/stack.c:1043: buf->buf[ind++] = address[3];
                           5799 ;	genAssign
   6A84 A8 10              5800 	mov	r0,_bp
   6A86 18                 5801 	dec	r0
   6A87 18                 5802 	dec	r0
   6A88 18                 5803 	dec	r0
   6A89 86 02              5804 	mov	ar2,@r0
                           5805 ;	genPlus
   6A8B A8 10              5806 	mov	r0,_bp
   6A8D 18                 5807 	dec	r0
   6A8E 18                 5808 	dec	r0
   6A8F 18                 5809 	dec	r0
                           5810 ;     genPlusIncr
   6A90 74 01              5811 	mov	a,#0x01
                           5812 ;	Peephole 236.a	used r2 instead of ar2
   6A92 2A                 5813 	add	a,r2
   6A93 F6                 5814 	mov	@r0,a
                           5815 ;	genPlus
                           5816 ;	Peephole 236.g	used r2 instead of ar2
   6A94 EA                 5817 	mov	a,r2
                           5818 ;	Peephole 236.a	used r5 instead of ar5
   6A95 2D                 5819 	add	a,r5
   6A96 FD                 5820 	mov	r5,a
                           5821 ;	Peephole 181	changed mov to clr
   6A97 E4                 5822 	clr	a
                           5823 ;	Peephole 236.b	used r6 instead of ar6
   6A98 3E                 5824 	addc	a,r6
   6A99 FE                 5825 	mov	r6,a
                           5826 ;	genPlus
   6A9A E5 10              5827 	mov	a,_bp
   6A9C 24 F9              5828 	add	a,#0xfffffff9
   6A9E F8                 5829 	mov	r0,a
                           5830 ;     genPlusIncr
   6A9F 74 03              5831 	mov	a,#0x03
   6AA1 26                 5832 	add	a,@r0
   6AA2 FA                 5833 	mov	r2,a
                           5834 ;	Peephole 181	changed mov to clr
   6AA3 E4                 5835 	clr	a
   6AA4 08                 5836 	inc	r0
   6AA5 36                 5837 	addc	a,@r0
   6AA6 FB                 5838 	mov	r3,a
   6AA7 08                 5839 	inc	r0
   6AA8 86 04              5840 	mov	ar4,@r0
                           5841 ;	genPointerGet
                           5842 ;	genGenPointerGet
   6AAA 8A 82              5843 	mov	dpl,r2
   6AAC 8B 83              5844 	mov	dph,r3
   6AAE 8C F0              5845 	mov	b,r4
   6AB0 12 E4 9F           5846 	lcall	__gptrget
                           5847 ;	genPointerSet
                           5848 ;	genGenPointerSet
   6AB3 FA                 5849 	mov	r2,a
   6AB4 8D 82              5850 	mov	dpl,r5
   6AB6 8E 83              5851 	mov	dph,r6
   6AB8 8F F0              5852 	mov	b,r7
                           5853 ;	Peephole 191	removed redundant mov
   6ABA 12 DF B7           5854 	lcall	__gptrput
                           5855 ;	../../Common/stack.c:1054: return ind;
                           5856 ;	genIpop
   6ABD D0 04              5857 	pop	ar4
   6ABF D0 03              5858 	pop	ar3
   6AC1 D0 02              5859 	pop	ar2
                           5860 ;	../../Common/stack.c:1045: for (i = 0; i < 2; i++)
   6AC3                    5861 00129$:
                           5862 ;	genPlus
   6AC3 E5 10              5863 	mov	a,_bp
   6AC5 24 07              5864 	add	a,#0x07
   6AC7 F8                 5865 	mov	r0,a
                           5866 ;     genPlusIncr
   6AC8 74 2C              5867 	mov	a,#0x2C
                           5868 ;	Peephole 236.a	used r2 instead of ar2
   6ACA 2A                 5869 	add	a,r2
   6ACB F6                 5870 	mov	@r0,a
                           5871 ;	Peephole 181	changed mov to clr
   6ACC E4                 5872 	clr	a
                           5873 ;	Peephole 236.b	used r3 instead of ar3
   6ACD 3B                 5874 	addc	a,r3
   6ACE 08                 5875 	inc	r0
   6ACF F6                 5876 	mov	@r0,a
   6AD0 08                 5877 	inc	r0
   6AD1 A6 04              5878 	mov	@r0,ar4
                           5879 ;	genAssign
   6AD3 A8 10              5880 	mov	r0,_bp
   6AD5 18                 5881 	dec	r0
   6AD6 18                 5882 	dec	r0
   6AD7 18                 5883 	dec	r0
   6AD8 86 05              5884 	mov	ar5,@r0
                           5885 ;	genAssign
   6ADA 7E 00              5886 	mov	r6,#0x00
   6ADC                    5887 00116$:
                           5888 ;	genCmpLt
                           5889 ;	genCmp
   6ADC BE 02 00           5890 	cjne	r6,#0x02,00146$
   6ADF                    5891 00146$:
                           5892 ;	genIfxJump
                           5893 ;	Peephole 108.a	removed ljmp by inverse jump logic
   6ADF 50 4F              5894 	jnc	00131$
                           5895 ;	Peephole 300	removed redundant label 00147$
                           5896 ;	../../Common/stack.c:1047: buf->buf[ind++] = address[i];
                           5897 ;	genAssign
   6AE1 8D 07              5898 	mov	ar7,r5
                           5899 ;	genPlus
                           5900 ;     genPlusIncr
   6AE3 0D                 5901 	inc	r5
                           5902 ;	genPlus
   6AE4 E5 10              5903 	mov	a,_bp
   6AE6 24 07              5904 	add	a,#0x07
   6AE8 F8                 5905 	mov	r0,a
   6AE9 E5 10              5906 	mov	a,_bp
   6AEB 24 04              5907 	add	a,#0x04
   6AED F9                 5908 	mov	r1,a
                           5909 ;	Peephole 236.g	used r7 instead of ar7
   6AEE EF                 5910 	mov	a,r7
   6AEF 26                 5911 	add	a,@r0
   6AF0 F7                 5912 	mov	@r1,a
                           5913 ;	Peephole 181	changed mov to clr
   6AF1 E4                 5914 	clr	a
   6AF2 08                 5915 	inc	r0
   6AF3 36                 5916 	addc	a,@r0
   6AF4 09                 5917 	inc	r1
   6AF5 F7                 5918 	mov	@r1,a
   6AF6 08                 5919 	inc	r0
   6AF7 09                 5920 	inc	r1
   6AF8 E6                 5921 	mov	a,@r0
   6AF9 F7                 5922 	mov	@r1,a
                           5923 ;	genPlus
   6AFA E5 10              5924 	mov	a,_bp
   6AFC 24 F9              5925 	add	a,#0xfffffff9
   6AFE F8                 5926 	mov	r0,a
                           5927 ;	Peephole 236.g	used r6 instead of ar6
   6AFF EE                 5928 	mov	a,r6
   6B00 26                 5929 	add	a,@r0
   6B01 FB                 5930 	mov	r3,a
                           5931 ;	Peephole 181	changed mov to clr
   6B02 E4                 5932 	clr	a
   6B03 08                 5933 	inc	r0
   6B04 36                 5934 	addc	a,@r0
   6B05 FC                 5935 	mov	r4,a
   6B06 08                 5936 	inc	r0
   6B07 86 02              5937 	mov	ar2,@r0
                           5938 ;	genPointerGet
                           5939 ;	genGenPointerGet
   6B09 8B 82              5940 	mov	dpl,r3
   6B0B 8C 83              5941 	mov	dph,r4
   6B0D 8A F0              5942 	mov	b,r2
   6B0F 12 E4 9F           5943 	lcall	__gptrget
   6B12 FB                 5944 	mov	r3,a
                           5945 ;	genPointerSet
                           5946 ;	genGenPointerSet
   6B13 E5 10              5947 	mov	a,_bp
   6B15 24 04              5948 	add	a,#0x04
   6B17 F8                 5949 	mov	r0,a
   6B18 86 82              5950 	mov	dpl,@r0
   6B1A 08                 5951 	inc	r0
   6B1B 86 83              5952 	mov	dph,@r0
   6B1D 08                 5953 	inc	r0
   6B1E 86 F0              5954 	mov	b,@r0
   6B20 EB                 5955 	mov	a,r3
   6B21 12 DF B7           5956 	lcall	__gptrput
                           5957 ;	../../Common/stack.c:1045: for (i = 0; i < 2; i++)
                           5958 ;	genPlus
                           5959 ;     genPlusIncr
   6B24 0E                 5960 	inc	r6
                           5961 ;	Peephole 112.b	changed ljmp to sjmp
   6B25 80 B5              5962 	sjmp	00116$
   6B27                    5963 00130$:
                           5964 ;	genAssign
   6B27 A8 10              5965 	mov	r0,_bp
   6B29 18                 5966 	dec	r0
   6B2A 18                 5967 	dec	r0
   6B2B 18                 5968 	dec	r0
   6B2C A6 02              5969 	mov	@r0,ar2
                           5970 ;	../../Common/stack.c:1054: return ind;
                           5971 ;	../../Common/stack.c:1045: for (i = 0; i < 2; i++)
                           5972 ;	Peephole 112.b	changed ljmp to sjmp
   6B2E 80 07              5973 	sjmp	00110$
   6B30                    5974 00131$:
                           5975 ;	genAssign
   6B30 A8 10              5976 	mov	r0,_bp
   6B32 18                 5977 	dec	r0
   6B33 18                 5978 	dec	r0
   6B34 18                 5979 	dec	r0
   6B35 A6 05              5980 	mov	@r0,ar5
   6B37                    5981 00110$:
                           5982 ;	../../Common/stack.c:1054: return ind;
                           5983 ;	genRet
   6B37 A8 10              5984 	mov	r0,_bp
   6B39 18                 5985 	dec	r0
   6B3A 18                 5986 	dec	r0
   6B3B 18                 5987 	dec	r0
   6B3C 86 82              5988 	mov	dpl,@r0
                           5989 ;	Peephole 300	removed redundant label 00120$
   6B3E 85 10 81           5990 	mov	sp,_bp
   6B41 D0 10              5991 	pop	_bp
   6B43 22                 5992 	ret
                           5993 ;------------------------------------------------------------
                           5994 ;Allocation info for local variables in function 'stack_check_broadcast'
                           5995 ;------------------------------------------------------------
                           5996 ;type                      Allocated to stack - offset -3
                           5997 ;address                   Allocated to stack - offset 1
                           5998 ;i                         Allocated to registers r6 
                           5999 ;len                       Allocated to registers r5 
                           6000 ;------------------------------------------------------------
                           6001 ;	../../Common/stack.c:1065: portCHAR stack_check_broadcast(address_t address, addrtype_t type)
                           6002 ;	-----------------------------------------
                           6003 ;	 function stack_check_broadcast
                           6004 ;	-----------------------------------------
   6B44                    6005 _stack_check_broadcast:
   6B44 C0 10              6006 	push	_bp
   6B46 85 81 10           6007 	mov	_bp,sp
                           6008 ;     genReceive
   6B49 C0 82              6009 	push	dpl
   6B4B C0 83              6010 	push	dph
   6B4D C0 F0              6011 	push	b
                           6012 ;	../../Common/stack.c:1067: uint8_t i, len=4;
                           6013 ;	genAssign
   6B4F 7D 04              6014 	mov	r5,#0x04
                           6015 ;	../../Common/stack.c:1068: if(type==ADDR_802_15_4_PAN_LONG || type==ADDR_802_15_4_LONG)
                           6016 ;	genCmpEq
   6B51 A8 10              6017 	mov	r0,_bp
   6B53 18                 6018 	dec	r0
   6B54 18                 6019 	dec	r0
   6B55 18                 6020 	dec	r0
                           6021 ;	gencjneshort
   6B56 B6 04 02           6022 	cjne	@r0,#0x04,00119$
                           6023 ;	Peephole 112.b	changed ljmp to sjmp
   6B59 80 08              6024 	sjmp	00101$
   6B5B                    6025 00119$:
                           6026 ;	genCmpEq
   6B5B A8 10              6027 	mov	r0,_bp
   6B5D 18                 6028 	dec	r0
   6B5E 18                 6029 	dec	r0
   6B5F 18                 6030 	dec	r0
                           6031 ;	gencjneshort
                           6032 ;	Peephole 112.b	changed ljmp to sjmp
                           6033 ;	Peephole 198.b	optimized misc jump sequence
   6B60 B6 01 02           6034 	cjne	@r0,#0x01,00102$
                           6035 ;	Peephole 200.b	removed redundant sjmp
                           6036 ;	Peephole 300	removed redundant label 00120$
                           6037 ;	Peephole 300	removed redundant label 00121$
   6B63                    6038 00101$:
                           6039 ;	../../Common/stack.c:1069: len=8;
                           6040 ;	genAssign
   6B63 7D 08              6041 	mov	r5,#0x08
   6B65                    6042 00102$:
                           6043 ;	../../Common/stack.c:1070: if(type==ADDR_SHORT)
                           6044 ;	genCmpEq
   6B65 A8 10              6045 	mov	r0,_bp
   6B67 18                 6046 	dec	r0
   6B68 18                 6047 	dec	r0
   6B69 18                 6048 	dec	r0
                           6049 ;	gencjneshort
                           6050 ;	Peephole 112.b	changed ljmp to sjmp
                           6051 ;	Peephole 198.b	optimized misc jump sequence
   6B6A B6 05 02           6052 	cjne	@r0,#0x05,00118$
                           6053 ;	Peephole 200.b	removed redundant sjmp
                           6054 ;	Peephole 300	removed redundant label 00122$
                           6055 ;	Peephole 300	removed redundant label 00123$
                           6056 ;	../../Common/stack.c:1071: len=2;
                           6057 ;	genAssign
   6B6D 7D 02              6058 	mov	r5,#0x02
                           6059 ;	../../Common/stack.c:1072: for(i=0; i<len; i++)
   6B6F                    6060 00118$:
                           6061 ;	genAssign
   6B6F 7E 00              6062 	mov	r6,#0x00
   6B71                    6063 00108$:
                           6064 ;	genCmpLt
                           6065 ;	genCmp
   6B71 C3                 6066 	clr	c
   6B72 EE                 6067 	mov	a,r6
   6B73 9D                 6068 	subb	a,r5
                           6069 ;	genIfxJump
                           6070 ;	Peephole 108.a	removed ljmp by inverse jump logic
   6B74 50 29              6071 	jnc	00111$
                           6072 ;	Peephole 300	removed redundant label 00124$
                           6073 ;	../../Common/stack.c:1074: if(address[i] != 0xff)
                           6074 ;	genIpush
   6B76 C0 05              6075 	push	ar5
                           6076 ;	genPlus
   6B78 A8 10              6077 	mov	r0,_bp
   6B7A 08                 6078 	inc	r0
                           6079 ;	Peephole 236.g	used r6 instead of ar6
   6B7B EE                 6080 	mov	a,r6
   6B7C 26                 6081 	add	a,@r0
   6B7D FF                 6082 	mov	r7,a
                           6083 ;	Peephole 181	changed mov to clr
   6B7E E4                 6084 	clr	a
   6B7F 08                 6085 	inc	r0
   6B80 36                 6086 	addc	a,@r0
   6B81 FD                 6087 	mov	r5,a
   6B82 08                 6088 	inc	r0
   6B83 86 02              6089 	mov	ar2,@r0
                           6090 ;	genPointerGet
                           6091 ;	genGenPointerGet
   6B85 8F 82              6092 	mov	dpl,r7
   6B87 8D 83              6093 	mov	dph,r5
   6B89 8A F0              6094 	mov	b,r2
   6B8B 12 E4 9F           6095 	lcall	__gptrget
   6B8E FF                 6096 	mov	r7,a
                           6097 ;	genCmpEq
                           6098 ;	gencjne
                           6099 ;	gencjneshort
                           6100 ;	Peephole 241.d	optimized compare
   6B8F E4                 6101 	clr	a
   6B90 BF FF 01           6102 	cjne	r7,#0xFF,00125$
   6B93 04                 6103 	inc	a
   6B94                    6104 00125$:
                           6105 ;	Peephole 300	removed redundant label 00126$
                           6106 ;	genIpop
   6B94 D0 05              6107 	pop	ar5
                           6108 ;	genIfx
                           6109 ;	genIfxJump
                           6110 ;	Peephole 108.b	removed ljmp by inverse jump logic
                           6111 ;	../../Common/stack.c:1076: return pdFALSE;
                           6112 ;	genRet
   6B96 70 04              6113 	jnz	00110$
                           6114 ;	Peephole 300	removed redundant label 00127$
                           6115 ;	Peephole 256.c	loading dpl with zero from a
   6B98 F5 82              6116 	mov	dpl,a
                           6117 ;	Peephole 112.b	changed ljmp to sjmp
   6B9A 80 06              6118 	sjmp	00112$
   6B9C                    6119 00110$:
                           6120 ;	../../Common/stack.c:1072: for(i=0; i<len; i++)
                           6121 ;	genPlus
                           6122 ;     genPlusIncr
   6B9C 0E                 6123 	inc	r6
                           6124 ;	Peephole 112.b	changed ljmp to sjmp
   6B9D 80 D2              6125 	sjmp	00108$
   6B9F                    6126 00111$:
                           6127 ;	../../Common/stack.c:1079: return pdTRUE;
                           6128 ;	genRet
   6B9F 75 82 01           6129 	mov	dpl,#0x01
   6BA2                    6130 00112$:
   6BA2 85 10 81           6131 	mov	sp,_bp
   6BA5 D0 10              6132 	pop	_bp
   6BA7 22                 6133 	ret
                           6134 	.area CSEG    (CODE)
                           6135 	.area CONST   (CODE)
   E7B5                    6136 __str_0:
   E7B5 53 74 61 63 6B     6137 	.ascii "Stack"
   E7BA 00                 6138 	.db 0x00
                           6139 	.area XINIT   (CODE)
   E8D7                    6140 __xinit__events:
                           6141 ; generic printIvalPtr
   E8D7 00 00 00           6142 	.byte #0x00,#0x00,#0x00
   E8DA                    6143 __xinit__stacks:
   E8DA 03                 6144 	.db #0x03
   E8DB 08                 6145 	.db #0x08
   E8DC 01                 6146 	.db #0x01
   E8DD 02                 6147 	.db #0x02
   E8DE 00                 6148 	.db 0x00
   E8DF 00                 6149 	.db #0x00
   E8E0 00                 6150 	.db #0x00
   E8E1 00                 6151 	.db 0x00
   E8E2 00                 6152 	.db 0x00
   E8E3 00                 6153 	.db 0x00
