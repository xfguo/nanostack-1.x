                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Nov 10 2006)
                              4 ; This file generated Fri Feb  1 13:33:38 2008
                              5 ;--------------------------------------------------------
                              6 	.module socket
                              7 	.optsdcc -mmcs51 --model-large
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _IRCON2_P2IF
                             13 	.globl _IRCON2_UTX0IF
                             14 	.globl _IRCON2_UTX1IF
                             15 	.globl _IRCON2_P1IF
                             16 	.globl _IRCON2_WDTIF
                             17 	.globl _CY
                             18 	.globl _AC
                             19 	.globl _F0
                             20 	.globl _RS1
                             21 	.globl _RS0
                             22 	.globl _OV
                             23 	.globl _F1
                             24 	.globl _P
                             25 	.globl _IRCON_DMAIF
                             26 	.globl _IRCON_T1IF
                             27 	.globl _IRCON_T2IF
                             28 	.globl _IRCON_T3IF
                             29 	.globl _IRCON_T4IF
                             30 	.globl _IRCON_P0IF
                             31 	.globl _IRCON_STIF
                             32 	.globl _IEN1_DMAIE
                             33 	.globl _IEN1_T1IE
                             34 	.globl _IEN1_T2IE
                             35 	.globl _IEN1_T3IE
                             36 	.globl _IEN1_T4IE
                             37 	.globl _IEN1_P0IE
                             38 	.globl _IEN0_RFERRIE
                             39 	.globl _IEN0_ADCIE
                             40 	.globl _IEN0_URX0IE
                             41 	.globl _IEN0_URX1IE
                             42 	.globl _IEN0_ENCIE
                             43 	.globl _IEN0_STIE
                             44 	.globl _IEN0_EA
                             45 	.globl _EA
                             46 	.globl _P2_4
                             47 	.globl _P2_3
                             48 	.globl _P2_2
                             49 	.globl _P2_1
                             50 	.globl _P2_0
                             51 	.globl _S0CON_ENCIF_0
                             52 	.globl _S0CON_ENCIF_1
                             53 	.globl _P1_7
                             54 	.globl _P1_6
                             55 	.globl _P1_5
                             56 	.globl _P1_4
                             57 	.globl _P1_3
                             58 	.globl _P1_2
                             59 	.globl _P1_1
                             60 	.globl _P1_0
                             61 	.globl _TCON_IT0
                             62 	.globl _TCON_RFERRIF
                             63 	.globl _TCON_IT1
                             64 	.globl _TCON_URX0IF
                             65 	.globl _TCON_ADCIF
                             66 	.globl _TCON_URX1IF
                             67 	.globl _P0_0
                             68 	.globl _P0_1
                             69 	.globl _P0_2
                             70 	.globl _P0_3
                             71 	.globl _P0_4
                             72 	.globl _P0_5
                             73 	.globl _P0_6
                             74 	.globl _P0_7
                             75 	.globl _P2DIR
                             76 	.globl _P1DIR
                             77 	.globl _P0DIR
                             78 	.globl _U1GCR
                             79 	.globl _U1UCR
                             80 	.globl _U1BAUD
                             81 	.globl _U1BUF
                             82 	.globl _U1CSR
                             83 	.globl _P2INP
                             84 	.globl _P1INP
                             85 	.globl _P2SEL
                             86 	.globl _P1SEL
                             87 	.globl _P0SEL
                             88 	.globl _ADCCFG
                             89 	.globl _PERCFG
                             90 	.globl _B
                             91 	.globl _T4CC1
                             92 	.globl _T4CCTL1
                             93 	.globl _T4CC0
                             94 	.globl _T4CCTL0
                             95 	.globl _T4CTL
                             96 	.globl _T4CNT
                             97 	.globl _RFIF
                             98 	.globl _IRCON2
                             99 	.globl _T1CCTL2
                            100 	.globl _T1CCTL1
                            101 	.globl _T1CCTL0
                            102 	.globl _T1CTL
                            103 	.globl _T1CNTH
                            104 	.globl _T1CNTL
                            105 	.globl _RFST
                            106 	.globl _ACC
                            107 	.globl _T1CC2H
                            108 	.globl _T1CC2L
                            109 	.globl _T1CC1H
                            110 	.globl _T1CC1L
                            111 	.globl _T1CC0H
                            112 	.globl _T1CC0L
                            113 	.globl _RFD
                            114 	.globl _TIMIF
                            115 	.globl _DMAREQ
                            116 	.globl _DMAARM
                            117 	.globl _DMA0CFGH
                            118 	.globl _DMA0CFGL
                            119 	.globl _DMA1CFGH
                            120 	.globl _DMA1CFGL
                            121 	.globl _DMAIRQ
                            122 	.globl _PSW
                            123 	.globl _T3CC1
                            124 	.globl _T3CCTL1
                            125 	.globl _T3CC0
                            126 	.globl _T3CCTL0
                            127 	.globl _T3CTL
                            128 	.globl _T3CNT
                            129 	.globl _WDCTL
                            130 	.globl _T2CON
                            131 	.globl _MEMCTR
                            132 	.globl _CLKCON
                            133 	.globl _U0GCR
                            134 	.globl _U0UCR
                            135 	.globl _T2CNF
                            136 	.globl _U0BAUD
                            137 	.globl _U0BUF
                            138 	.globl _IRCON
                            139 	.globl _SLEEP
                            140 	.globl _RNDH
                            141 	.globl _RNDL
                            142 	.globl _ADCH
                            143 	.globl _ADCL
                            144 	.globl _IP1
                            145 	.globl _IEN1
                            146 	.globl _RCCTL
                            147 	.globl _ADCCON3
                            148 	.globl _ADCCON2
                            149 	.globl _ADCCON1
                            150 	.globl _ENCCS
                            151 	.globl _ENCDO
                            152 	.globl _ENCDI
                            153 	.globl _FWDATA
                            154 	.globl _FCTL
                            155 	.globl _FADDRH
                            156 	.globl _FADDRL
                            157 	.globl _FWT
                            158 	.globl _IP0
                            159 	.globl _IEN0
                            160 	.globl _IE
                            161 	.globl _T2THD
                            162 	.globl _T2TLD
                            163 	.globl _T2CAPHPH
                            164 	.globl _T2CAPLPL
                            165 	.globl _T2OF2
                            166 	.globl _T2OF1
                            167 	.globl _T2OF0
                            168 	.globl _P2
                            169 	.globl _T2PEROF2
                            170 	.globl _T2PEROF1
                            171 	.globl _T2PEROF0
                            172 	.globl _S1CON
                            173 	.globl _IEN2
                            174 	.globl _HSRC
                            175 	.globl _S0CON
                            176 	.globl _ST2
                            177 	.globl _ST1
                            178 	.globl _ST0
                            179 	.globl _T2CMP
                            180 	.globl __XPAGE
                            181 	.globl _DPS
                            182 	.globl _RFIM
                            183 	.globl _P1
                            184 	.globl _P0INP
                            185 	.globl _P1IEN
                            186 	.globl _PICTL
                            187 	.globl _P2IFG
                            188 	.globl _P1IFG
                            189 	.globl _P0IFG
                            190 	.globl _TCON
                            191 	.globl _PCON
                            192 	.globl _U0CSR
                            193 	.globl _DPH1
                            194 	.globl _DPL1
                            195 	.globl _DPH0
                            196 	.globl _DPL0
                            197 	.globl _SP
                            198 	.globl _P0
                            199 	.globl _sockets
                            200 	.globl _RFD_SHADOW
                            201 	.globl _RFSTATUS
                            202 	.globl _CHIPID
                            203 	.globl _CHVER
                            204 	.globl _FSMTC1
                            205 	.globl _RXFIFOCNT
                            206 	.globl _IOCFG3
                            207 	.globl _IOCFG2
                            208 	.globl _IOCFG1
                            209 	.globl _IOCFG0
                            210 	.globl _SHORTADDRL
                            211 	.globl _SHORTADDRH
                            212 	.globl _PANIDL
                            213 	.globl _PANIDH
                            214 	.globl _IEEE_ADDR7
                            215 	.globl _IEEE_ADDR6
                            216 	.globl _IEEE_ADDR5
                            217 	.globl _IEEE_ADDR4
                            218 	.globl _IEEE_ADDR3
                            219 	.globl _IEEE_ADDR2
                            220 	.globl _IEEE_ADDR1
                            221 	.globl _IEEE_ADDR0
                            222 	.globl _DACTSTL
                            223 	.globl _DACTSTH
                            224 	.globl _ADCTSTL
                            225 	.globl _ADCTSTH
                            226 	.globl _FSMSTATE
                            227 	.globl _AGCCTRLL
                            228 	.globl _AGCCTRLH
                            229 	.globl _MANORL
                            230 	.globl _MANORH
                            231 	.globl _MANANDL
                            232 	.globl _MANANDH
                            233 	.globl _FSMTCL
                            234 	.globl _FSMTCH
                            235 	.globl _RFPWR
                            236 	.globl _CSPT
                            237 	.globl _CSPCTRL
                            238 	.globl _CSPZ
                            239 	.globl _CSPY
                            240 	.globl _CSPX
                            241 	.globl _FSCTRLL
                            242 	.globl _FSCTRLH
                            243 	.globl _RXCTRL1L
                            244 	.globl _RXCTRL1H
                            245 	.globl _RXCTRL0L
                            246 	.globl _RXCTRL0H
                            247 	.globl _TXCTRLL
                            248 	.globl _TXCTRLH
                            249 	.globl _SYNCWORDL
                            250 	.globl _SYNCWORDH
                            251 	.globl _RSSIL
                            252 	.globl _RSSIH
                            253 	.globl _MDMCTRL1L
                            254 	.globl _MDMCTRL1H
                            255 	.globl _MDMCTRL0L
                            256 	.globl _MDMCTRL0H
                            257 	.globl _socket_init
                            258 	.globl _socket
                            259 	.globl _socket_close
                            260 	.globl _socket_bind
                            261 	.globl _socket_id_find
                            262 	.globl _socket_find
                            263 	.globl _socket_buffer_get
                            264 	.globl _socket_buffer_free
                            265 	.globl _socket_sendto
                            266 	.globl _socket_write
                            267 	.globl _socket_connect
                            268 	.globl _socket_accept
                            269 	.globl _socket_port_random
                            270 	.globl _socket_read
                            271 	.globl _socket_up
                            272 ;--------------------------------------------------------
                            273 ; special function registers
                            274 ;--------------------------------------------------------
                            275 	.area RSEG    (DATA)
                    0080    276 _P0	=	0x0080
                    0081    277 _SP	=	0x0081
                    0082    278 _DPL0	=	0x0082
                    0083    279 _DPH0	=	0x0083
                    0084    280 _DPL1	=	0x0084
                    0085    281 _DPH1	=	0x0085
                    0086    282 _U0CSR	=	0x0086
                    0087    283 _PCON	=	0x0087
                    0088    284 _TCON	=	0x0088
                    0089    285 _P0IFG	=	0x0089
                    008A    286 _P1IFG	=	0x008a
                    008B    287 _P2IFG	=	0x008b
                    008C    288 _PICTL	=	0x008c
                    008D    289 _P1IEN	=	0x008d
                    008F    290 _P0INP	=	0x008f
                    0090    291 _P1	=	0x0090
                    0091    292 _RFIM	=	0x0091
                    0092    293 _DPS	=	0x0092
                    0093    294 __XPAGE	=	0x0093
                    0094    295 _T2CMP	=	0x0094
                    0095    296 _ST0	=	0x0095
                    0096    297 _ST1	=	0x0096
                    0097    298 _ST2	=	0x0097
                    0098    299 _S0CON	=	0x0098
                    0099    300 _HSRC	=	0x0099
                    009A    301 _IEN2	=	0x009a
                    009B    302 _S1CON	=	0x009b
                    009C    303 _T2PEROF0	=	0x009c
                    009D    304 _T2PEROF1	=	0x009d
                    009E    305 _T2PEROF2	=	0x009e
                    00A0    306 _P2	=	0x00a0
                    00A1    307 _T2OF0	=	0x00a1
                    00A2    308 _T2OF1	=	0x00a2
                    00A3    309 _T2OF2	=	0x00a3
                    00A4    310 _T2CAPLPL	=	0x00a4
                    00A5    311 _T2CAPHPH	=	0x00a5
                    00A6    312 _T2TLD	=	0x00a6
                    00A7    313 _T2THD	=	0x00a7
                    00A8    314 _IE	=	0x00a8
                    00A8    315 _IEN0	=	0x00a8
                    00A9    316 _IP0	=	0x00a9
                    00AB    317 _FWT	=	0x00ab
                    00AC    318 _FADDRL	=	0x00ac
                    00AD    319 _FADDRH	=	0x00ad
                    00AE    320 _FCTL	=	0x00ae
                    00AF    321 _FWDATA	=	0x00af
                    00B1    322 _ENCDI	=	0x00b1
                    00B2    323 _ENCDO	=	0x00b2
                    00B3    324 _ENCCS	=	0x00b3
                    00B4    325 _ADCCON1	=	0x00b4
                    00B5    326 _ADCCON2	=	0x00b5
                    00B6    327 _ADCCON3	=	0x00b6
                    00B7    328 _RCCTL	=	0x00b7
                    00B8    329 _IEN1	=	0x00b8
                    00B9    330 _IP1	=	0x00b9
                    00BA    331 _ADCL	=	0x00ba
                    00BB    332 _ADCH	=	0x00bb
                    00BC    333 _RNDL	=	0x00bc
                    00BD    334 _RNDH	=	0x00bd
                    00BE    335 _SLEEP	=	0x00be
                    00C0    336 _IRCON	=	0x00c0
                    00C1    337 _U0BUF	=	0x00c1
                    00C2    338 _U0BAUD	=	0x00c2
                    00C3    339 _T2CNF	=	0x00c3
                    00C4    340 _U0UCR	=	0x00c4
                    00C5    341 _U0GCR	=	0x00c5
                    00C6    342 _CLKCON	=	0x00c6
                    00C7    343 _MEMCTR	=	0x00c7
                    00C8    344 _T2CON	=	0x00c8
                    00C9    345 _WDCTL	=	0x00c9
                    00CA    346 _T3CNT	=	0x00ca
                    00CB    347 _T3CTL	=	0x00cb
                    00CC    348 _T3CCTL0	=	0x00cc
                    00CD    349 _T3CC0	=	0x00cd
                    00CE    350 _T3CCTL1	=	0x00ce
                    00CF    351 _T3CC1	=	0x00cf
                    00D0    352 _PSW	=	0x00d0
                    00D1    353 _DMAIRQ	=	0x00d1
                    00D2    354 _DMA1CFGL	=	0x00d2
                    00D3    355 _DMA1CFGH	=	0x00d3
                    00D4    356 _DMA0CFGL	=	0x00d4
                    00D5    357 _DMA0CFGH	=	0x00d5
                    00D6    358 _DMAARM	=	0x00d6
                    00D7    359 _DMAREQ	=	0x00d7
                    00D8    360 _TIMIF	=	0x00d8
                    00D9    361 _RFD	=	0x00d9
                    00DA    362 _T1CC0L	=	0x00da
                    00DB    363 _T1CC0H	=	0x00db
                    00DC    364 _T1CC1L	=	0x00dc
                    00DD    365 _T1CC1H	=	0x00dd
                    00DE    366 _T1CC2L	=	0x00de
                    00DF    367 _T1CC2H	=	0x00df
                    00E0    368 _ACC	=	0x00e0
                    00E1    369 _RFST	=	0x00e1
                    00E2    370 _T1CNTL	=	0x00e2
                    00E3    371 _T1CNTH	=	0x00e3
                    00E4    372 _T1CTL	=	0x00e4
                    00E5    373 _T1CCTL0	=	0x00e5
                    00E6    374 _T1CCTL1	=	0x00e6
                    00E7    375 _T1CCTL2	=	0x00e7
                    00E8    376 _IRCON2	=	0x00e8
                    00E9    377 _RFIF	=	0x00e9
                    00EA    378 _T4CNT	=	0x00ea
                    00EB    379 _T4CTL	=	0x00eb
                    00EC    380 _T4CCTL0	=	0x00ec
                    00ED    381 _T4CC0	=	0x00ed
                    00EE    382 _T4CCTL1	=	0x00ee
                    00EF    383 _T4CC1	=	0x00ef
                    00F0    384 _B	=	0x00f0
                    00F1    385 _PERCFG	=	0x00f1
                    00F2    386 _ADCCFG	=	0x00f2
                    00F3    387 _P0SEL	=	0x00f3
                    00F4    388 _P1SEL	=	0x00f4
                    00F5    389 _P2SEL	=	0x00f5
                    00F6    390 _P1INP	=	0x00f6
                    00F7    391 _P2INP	=	0x00f7
                    00F8    392 _U1CSR	=	0x00f8
                    00F9    393 _U1BUF	=	0x00f9
                    00FA    394 _U1BAUD	=	0x00fa
                    00FB    395 _U1UCR	=	0x00fb
                    00FC    396 _U1GCR	=	0x00fc
                    00FD    397 _P0DIR	=	0x00fd
                    00FE    398 _P1DIR	=	0x00fe
                    00FF    399 _P2DIR	=	0x00ff
                            400 ;--------------------------------------------------------
                            401 ; special function bits
                            402 ;--------------------------------------------------------
                            403 	.area RSEG    (DATA)
                    0087    404 _P0_7	=	0x0087
                    0086    405 _P0_6	=	0x0086
                    0085    406 _P0_5	=	0x0085
                    0084    407 _P0_4	=	0x0084
                    0083    408 _P0_3	=	0x0083
                    0082    409 _P0_2	=	0x0082
                    0081    410 _P0_1	=	0x0081
                    0080    411 _P0_0	=	0x0080
                    008F    412 _TCON_URX1IF	=	0x008f
                    008D    413 _TCON_ADCIF	=	0x008d
                    008B    414 _TCON_URX0IF	=	0x008b
                    008A    415 _TCON_IT1	=	0x008a
                    0089    416 _TCON_RFERRIF	=	0x0089
                    0088    417 _TCON_IT0	=	0x0088
                    0090    418 _P1_0	=	0x0090
                    0091    419 _P1_1	=	0x0091
                    0092    420 _P1_2	=	0x0092
                    0093    421 _P1_3	=	0x0093
                    0094    422 _P1_4	=	0x0094
                    0095    423 _P1_5	=	0x0095
                    0096    424 _P1_6	=	0x0096
                    0097    425 _P1_7	=	0x0097
                    0099    426 _S0CON_ENCIF_1	=	0x0099
                    0098    427 _S0CON_ENCIF_0	=	0x0098
                    00A0    428 _P2_0	=	0x00a0
                    00A1    429 _P2_1	=	0x00a1
                    00A2    430 _P2_2	=	0x00a2
                    00A3    431 _P2_3	=	0x00a3
                    00A4    432 _P2_4	=	0x00a4
                    00AF    433 _EA	=	0x00af
                    00AF    434 _IEN0_EA	=	0x00af
                    00AD    435 _IEN0_STIE	=	0x00ad
                    00AC    436 _IEN0_ENCIE	=	0x00ac
                    00AB    437 _IEN0_URX1IE	=	0x00ab
                    00AA    438 _IEN0_URX0IE	=	0x00aa
                    00A9    439 _IEN0_ADCIE	=	0x00a9
                    00A8    440 _IEN0_RFERRIE	=	0x00a8
                    00BD    441 _IEN1_P0IE	=	0x00bd
                    00BC    442 _IEN1_T4IE	=	0x00bc
                    00BB    443 _IEN1_T3IE	=	0x00bb
                    00BA    444 _IEN1_T2IE	=	0x00ba
                    00B9    445 _IEN1_T1IE	=	0x00b9
                    00B8    446 _IEN1_DMAIE	=	0x00b8
                    00C7    447 _IRCON_STIF	=	0x00c7
                    00C5    448 _IRCON_P0IF	=	0x00c5
                    00C4    449 _IRCON_T4IF	=	0x00c4
                    00C3    450 _IRCON_T3IF	=	0x00c3
                    00C2    451 _IRCON_T2IF	=	0x00c2
                    00C1    452 _IRCON_T1IF	=	0x00c1
                    00C0    453 _IRCON_DMAIF	=	0x00c0
                    00D0    454 _P	=	0x00d0
                    00D1    455 _F1	=	0x00d1
                    00D2    456 _OV	=	0x00d2
                    00D3    457 _RS0	=	0x00d3
                    00D4    458 _RS1	=	0x00d4
                    00D5    459 _F0	=	0x00d5
                    00D6    460 _AC	=	0x00d6
                    00D7    461 _CY	=	0x00d7
                    00EC    462 _IRCON2_WDTIF	=	0x00ec
                    00EB    463 _IRCON2_P1IF	=	0x00eb
                    00EA    464 _IRCON2_UTX1IF	=	0x00ea
                    00E9    465 _IRCON2_UTX0IF	=	0x00e9
                    00E8    466 _IRCON2_P2IF	=	0x00e8
                            467 ;--------------------------------------------------------
                            468 ; overlayable register banks
                            469 ;--------------------------------------------------------
                            470 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     471 	.ds 8
                            472 ;--------------------------------------------------------
                            473 ; internal ram data
                            474 ;--------------------------------------------------------
                            475 	.area DSEG    (DATA)
                            476 ;--------------------------------------------------------
                            477 ; overlayable items in internal ram 
                            478 ;--------------------------------------------------------
                            479 	.area OSEG    (OVR,DATA)
                            480 ;--------------------------------------------------------
                            481 ; indirectly addressable internal ram data
                            482 ;--------------------------------------------------------
                            483 	.area ISEG    (DATA)
                            484 ;--------------------------------------------------------
                            485 ; bit data
                            486 ;--------------------------------------------------------
                            487 	.area BSEG    (BIT)
                            488 ;--------------------------------------------------------
                            489 ; paged external ram data
                            490 ;--------------------------------------------------------
                            491 	.area PSEG    (PAG,XDATA)
                            492 ;--------------------------------------------------------
                            493 ; external ram data
                            494 ;--------------------------------------------------------
                            495 	.area XSEG    (XDATA)
                    DF02    496 _MDMCTRL0H	=	0xdf02
                    DF03    497 _MDMCTRL0L	=	0xdf03
                    DF04    498 _MDMCTRL1H	=	0xdf04
                    DF05    499 _MDMCTRL1L	=	0xdf05
                    DF06    500 _RSSIH	=	0xdf06
                    DF07    501 _RSSIL	=	0xdf07
                    DF08    502 _SYNCWORDH	=	0xdf08
                    DF09    503 _SYNCWORDL	=	0xdf09
                    DF0A    504 _TXCTRLH	=	0xdf0a
                    DF0B    505 _TXCTRLL	=	0xdf0b
                    DF0C    506 _RXCTRL0H	=	0xdf0c
                    DF0D    507 _RXCTRL0L	=	0xdf0d
                    DF0E    508 _RXCTRL1H	=	0xdf0e
                    DF0F    509 _RXCTRL1L	=	0xdf0f
                    DF10    510 _FSCTRLH	=	0xdf10
                    DF11    511 _FSCTRLL	=	0xdf11
                    DF12    512 _CSPX	=	0xdf12
                    DF13    513 _CSPY	=	0xdf13
                    DF14    514 _CSPZ	=	0xdf14
                    DF15    515 _CSPCTRL	=	0xdf15
                    DF16    516 _CSPT	=	0xdf16
                    DF17    517 _RFPWR	=	0xdf17
                    DF20    518 _FSMTCH	=	0xdf20
                    DF21    519 _FSMTCL	=	0xdf21
                    DF22    520 _MANANDH	=	0xdf22
                    DF23    521 _MANANDL	=	0xdf23
                    DF24    522 _MANORH	=	0xdf24
                    DF25    523 _MANORL	=	0xdf25
                    DF26    524 _AGCCTRLH	=	0xdf26
                    DF27    525 _AGCCTRLL	=	0xdf27
                    DF39    526 _FSMSTATE	=	0xdf39
                    DF3A    527 _ADCTSTH	=	0xdf3a
                    DF3B    528 _ADCTSTL	=	0xdf3b
                    DF3C    529 _DACTSTH	=	0xdf3c
                    DF3D    530 _DACTSTL	=	0xdf3d
                    DF43    531 _IEEE_ADDR0	=	0xdf43
                    DF44    532 _IEEE_ADDR1	=	0xdf44
                    DF45    533 _IEEE_ADDR2	=	0xdf45
                    DF46    534 _IEEE_ADDR3	=	0xdf46
                    DF47    535 _IEEE_ADDR4	=	0xdf47
                    DF48    536 _IEEE_ADDR5	=	0xdf48
                    DF49    537 _IEEE_ADDR6	=	0xdf49
                    DF4A    538 _IEEE_ADDR7	=	0xdf4a
                    DF4B    539 _PANIDH	=	0xdf4b
                    DF4C    540 _PANIDL	=	0xdf4c
                    DF4D    541 _SHORTADDRH	=	0xdf4d
                    DF4E    542 _SHORTADDRL	=	0xdf4e
                    DF4F    543 _IOCFG0	=	0xdf4f
                    DF50    544 _IOCFG1	=	0xdf50
                    DF51    545 _IOCFG2	=	0xdf51
                    DF52    546 _IOCFG3	=	0xdf52
                    DF53    547 _RXFIFOCNT	=	0xdf53
                    DF54    548 _FSMTC1	=	0xdf54
                    DF60    549 _CHVER	=	0xdf60
                    DF61    550 _CHIPID	=	0xdf61
                    DF62    551 _RFSTATUS	=	0xdf62
                    DFD9    552 _RFD_SHADOW	=	0xdfd9
   EF58                     553 _sockets::
   EF58                     554 	.ds 96
                            555 ;--------------------------------------------------------
                            556 ; external initialized ram data
                            557 ;--------------------------------------------------------
                            558 	.area XISEG   (XDATA)
                            559 	.area HOME    (CODE)
                            560 	.area GSINIT0 (CODE)
                            561 	.area GSINIT1 (CODE)
                            562 	.area GSINIT2 (CODE)
                            563 	.area GSINIT3 (CODE)
                            564 	.area GSINIT4 (CODE)
                            565 	.area GSINIT5 (CODE)
                            566 	.area GSINIT  (CODE)
                            567 	.area GSFINAL (CODE)
                            568 	.area CSEG    (CODE)
                            569 ;--------------------------------------------------------
                            570 ; global & static initialisations
                            571 ;--------------------------------------------------------
                            572 	.area HOME    (CODE)
                            573 	.area GSINIT  (CODE)
                            574 	.area GSFINAL (CODE)
                            575 	.area GSINIT  (CODE)
                            576 ;--------------------------------------------------------
                            577 ; Home
                            578 ;--------------------------------------------------------
                            579 	.area HOME    (CODE)
                            580 	.area CSEG    (CODE)
                            581 ;--------------------------------------------------------
                            582 ; code
                            583 ;--------------------------------------------------------
                            584 	.area CSEG    (CODE)
                            585 ;------------------------------------------------------------
                            586 ;Allocation info for local variables in function 'socket_init'
                            587 ;------------------------------------------------------------
                            588 ;i                         Allocated to registers r2 
                            589 ;------------------------------------------------------------
                            590 ;	../../Common/socket.c:74: void socket_init (void) 
                            591 ;	-----------------------------------------
                            592 ;	 function socket_init
                            593 ;	-----------------------------------------
   4441                     594 _socket_init:
                    0002    595 	ar2 = 0x02
                    0003    596 	ar3 = 0x03
                    0004    597 	ar4 = 0x04
                    0005    598 	ar5 = 0x05
                    0006    599 	ar6 = 0x06
                    0007    600 	ar7 = 0x07
                    0000    601 	ar0 = 0x00
                    0001    602 	ar1 = 0x01
                            603 ;	../../Common/socket.c:82: for (i = 0; i < SOCKETS_MAX; i++)
                            604 ;	genAssign
   4441 7A 04               605 	mov	r2,#0x04
   4443                     606 00103$:
                            607 ;	../../Common/socket.c:84: sockets[i].protocol = 0;   
                            608 ;	genMinus
                            609 ;	genMinusDec
   4443 EA                  610 	mov	a,r2
   4444 14                  611 	dec	a
                            612 ;	genMult
                            613 ;	genMultOneByte
   4445 FB                  614 	mov	r3,a
                            615 ;	Peephole 105	removed redundant mov
   4446 75 F0 18            616 	mov	b,#0x18
   4449 A4                  617 	mul	ab
                            618 ;	genPlus
   444A FC                  619 	mov	r4,a
                            620 ;	Peephole 177.b	removed redundant mov
   444B 24 58               621 	add	a,#_sockets
   444D F5 82               622 	mov	dpl,a
                            623 ;	Peephole 181	changed mov to clr
   444F E4                  624 	clr	a
   4450 34 EF               625 	addc	a,#(_sockets >> 8)
   4452 F5 83               626 	mov	dph,a
                            627 ;	genPointerSet
                            628 ;     genFarPointerSet
                            629 ;	Peephole 181	changed mov to clr
   4454 E4                  630 	clr	a
   4455 F0                  631 	movx	@dptr,a
                            632 ;	../../Common/socket.c:85: sockets[i].callback = 0;   
                            633 ;	genPlus
                            634 ;	Peephole 236.g	used r4 instead of ar4
   4456 EC                  635 	mov	a,r4
   4457 24 58               636 	add	a,#_sockets
   4459 FC                  637 	mov	r4,a
                            638 ;	Peephole 181	changed mov to clr
   445A E4                  639 	clr	a
   445B 34 EF               640 	addc	a,#(_sockets >> 8)
   445D FD                  641 	mov	r5,a
                            642 ;	genPlus
                            643 ;     genPlusIncr
   445E 74 16               644 	mov	a,#0x16
                            645 ;	Peephole 236.a	used r4 instead of ar4
   4460 2C                  646 	add	a,r4
   4461 F5 82               647 	mov	dpl,a
                            648 ;	Peephole 181	changed mov to clr
   4463 E4                  649 	clr	a
                            650 ;	Peephole 236.b	used r5 instead of ar5
   4464 3D                  651 	addc	a,r5
   4465 F5 83               652 	mov	dph,a
                            653 ;	genPointerSet
                            654 ;     genFarPointerSet
                            655 ;	Peephole 181	changed mov to clr
   4467 E4                  656 	clr	a
   4468 F0                  657 	movx	@dptr,a
   4469 A3                  658 	inc	dptr
                            659 ;	Peephole 101	removed redundant mov
   446A F0                  660 	movx	@dptr,a
                            661 ;	../../Common/socket.c:86: sockets[i].listen = 0;   
                            662 ;	genPlus
                            663 ;     genPlusIncr
   446B 8C 82               664 	mov	dpl,r4
   446D 8D 83               665 	mov	dph,r5
   446F A3                  666 	inc	dptr
   4470 A3                  667 	inc	dptr
                            668 ;	genPointerSet
                            669 ;     genFarPointerSet
                            670 ;	Peephole 181	changed mov to clr
   4471 E4                  671 	clr	a
   4472 F0                  672 	movx	@dptr,a
   4473 A3                  673 	inc	dptr
                            674 ;	Peephole 101	removed redundant mov
   4474 F0                  675 	movx	@dptr,a
                            676 ;	../../Common/socket.c:87: sockets[i].queue = 0;
                            677 ;	genPlus
                            678 ;     genPlusIncr
   4475 74 13               679 	mov	a,#0x13
                            680 ;	Peephole 236.a	used r4 instead of ar4
   4477 2C                  681 	add	a,r4
   4478 F5 82               682 	mov	dpl,a
                            683 ;	Peephole 181	changed mov to clr
   447A E4                  684 	clr	a
                            685 ;	Peephole 236.b	used r5 instead of ar5
   447B 3D                  686 	addc	a,r5
   447C F5 83               687 	mov	dph,a
                            688 ;	genPointerSet
                            689 ;     genFarPointerSet
                            690 ;	Peephole 181	changed mov to clr
                            691 ;	Peephole 101	removed redundant mov
                            692 ;	Peephole 181	changed mov to clr
   447E E4                  693 	clr	a
   447F F0                  694 	movx	@dptr,a
   4480 A3                  695 	inc	dptr
   4481 F0                  696 	movx	@dptr,a
   4482 A3                  697 	inc	dptr
                            698 ;	Peephole 226.b	removed unnecessary clr
   4483 F0                  699 	movx	@dptr,a
                            700 ;	../../Common/socket.c:88: sockets[i].sa.addr_type = ADDR_NONE;   
                            701 ;	genPlus
                            702 ;     genPlusIncr
   4484 74 06               703 	mov	a,#0x06
                            704 ;	Peephole 236.a	used r4 instead of ar4
   4486 2C                  705 	add	a,r4
   4487 F5 82               706 	mov	dpl,a
                            707 ;	Peephole 181	changed mov to clr
   4489 E4                  708 	clr	a
                            709 ;	Peephole 236.b	used r5 instead of ar5
   448A 3D                  710 	addc	a,r5
   448B F5 83               711 	mov	dph,a
                            712 ;	genPointerSet
                            713 ;     genFarPointerSet
                            714 ;	Peephole 181	changed mov to clr
   448D E4                  715 	clr	a
   448E F0                  716 	movx	@dptr,a
                            717 ;	genAssign
                            718 ;	genAssign
   448F 8B 02               719 	mov	ar2,r3
                            720 ;	../../Common/socket.c:82: for (i = 0; i < SOCKETS_MAX; i++)
                            721 ;	genIfx
   4491 EA                  722 	mov	a,r2
                            723 ;	genIfxJump
                            724 ;	Peephole 108.b	removed ljmp by inverse jump logic
   4492 70 AF               725 	jnz	00103$
                            726 ;	Peephole 300	removed redundant label 00108$
                            727 ;	Peephole 300	removed redundant label 00104$
   4494 22                  728 	ret
                            729 ;------------------------------------------------------------
                            730 ;Allocation info for local variables in function 'socket'
                            731 ;------------------------------------------------------------
                            732 ;sock_handler              Allocated to stack - offset -4
                            733 ;protocol                  Allocated to registers r5 
                            734 ;i                         Allocated to registers r2 
                            735 ;j                         Allocated to registers r2 
                            736 ;temp                      Allocated to stack - offset 1
                            737 ;retvalue                  Allocated to stack - offset 2
                            738 ;stack                     Allocated to stack - offset 5
                            739 ;module                    Allocated to registers r2 r3 r4 
                            740 ;sloc0                     Allocated to stack - offset 12
                            741 ;sloc1                     Allocated to stack - offset 6
                            742 ;sloc2                     Allocated to stack - offset 8
                            743 ;------------------------------------------------------------
                            744 ;	../../Common/socket.c:101: socket_t *socket(module_id_t protocol,
                            745 ;	-----------------------------------------
                            746 ;	 function socket
                            747 ;	-----------------------------------------
   4495                     748 _socket:
   4495 C0 10               749 	push	_bp
                            750 ;	peephole 177.h	optimized mov sequence
   4497 E5 81               751 	mov	a,sp
   4499 F5 10               752 	mov	_bp,a
   449B 24 0A               753 	add	a,#0x0a
   449D F5 81               754 	mov	sp,a
                            755 ;	genReceive
   449F AD 82               756 	mov	r5,dpl
                            757 ;	../../Common/socket.c:104: uint8_t i,j, temp=0;
                            758 ;	genAssign
   44A1 A8 10               759 	mov	r0,_bp
   44A3 08                  760 	inc	r0
   44A4 76 00               761 	mov	@r0,#0x00
                            762 ;	../../Common/socket.c:105: socket_t *retvalue = 0;
                            763 ;	genAssign
   44A6 A8 10               764 	mov	r0,_bp
   44A8 08                  765 	inc	r0
   44A9 08                  766 	inc	r0
   44AA E4                  767 	clr	a
   44AB F6                  768 	mov	@r0,a
   44AC 08                  769 	inc	r0
   44AD F6                  770 	mov	@r0,a
   44AE 08                  771 	inc	r0
   44AF F6                  772 	mov	@r0,a
                            773 ;	../../Common/socket.c:106: int8_t stack = -1;
                            774 ;	genAssign
   44B0 7F FF               775 	mov	r7,#0xFF
                            776 ;	../../Common/socket.c:109: while ((stacks[i].layers > 0) && (stack < 0) )
                            777 ;	genAssign
   44B2 E5 10               778 	mov	a,_bp
   44B4 24 05               779 	add	a,#0x05
   44B6 F8                  780 	mov	r0,a
   44B7 76 00               781 	mov	@r0,#0x00
   44B9                     782 00104$:
                            783 ;	genMult
   44B9 E5 10               784 	mov	a,_bp
   44BB 24 05               785 	add	a,#0x05
   44BD F8                  786 	mov	r0,a
                            787 ;	genMultOneByte
   44BE E6                  788 	mov	a,@r0
   44BF 75 F0 05            789 	mov	b,#0x05
   44C2 A4                  790 	mul	ab
   44C3 FB                  791 	mov	r3,a
   44C4 AC F0               792 	mov	r4,b
                            793 ;	genPlus
   44C6 E5 10               794 	mov	a,_bp
   44C8 24 06               795 	add	a,#0x06
   44CA F8                  796 	mov	r0,a
                            797 ;	Peephole 236.g	used r3 instead of ar3
   44CB EB                  798 	mov	a,r3
   44CC 24 DD               799 	add	a,#_stacks
   44CE F6                  800 	mov	@r0,a
                            801 ;	Peephole 236.g	used r4 instead of ar4
   44CF EC                  802 	mov	a,r4
   44D0 34 F0               803 	addc	a,#(_stacks >> 8)
   44D2 08                  804 	inc	r0
   44D3 F6                  805 	mov	@r0,a
                            806 ;	genPointerGet
                            807 ;	genFarPointerGet
   44D4 E5 10               808 	mov	a,_bp
   44D6 24 06               809 	add	a,#0x06
   44D8 F8                  810 	mov	r0,a
   44D9 86 82               811 	mov	dpl,@r0
   44DB 08                  812 	inc	r0
   44DC 86 83               813 	mov	dph,@r0
   44DE E0                  814 	movx	a,@dptr
                            815 ;	genIfxJump
                            816 ;	Peephole 112.b	changed ljmp to sjmp
                            817 ;	Peephole 160.c	removed sjmp by inverse jump logic
   44DF 60 6F               818 	jz	00106$
                            819 ;	Peephole 300	removed redundant label 00145$
                            820 ;	genCmpLt
                            821 ;	genCmp
   44E1 EF                  822 	mov	a,r7
                            823 ;	genIfxJump
                            824 ;	Peephole 108.d	removed ljmp by inverse jump logic
   44E2 30 E7 6B            825 	jnb	acc.7,00106$
                            826 ;	Peephole 300	removed redundant label 00146$
                            827 ;	../../Common/socket.c:112: for (j=0; j<stacks[i].layers; j++)
                            828 ;	genAssign
   44E5 7A 00               829 	mov	r2,#0x00
                            830 ;	genAssign
   44E7 8B 06               831 	mov	ar6,r3
                            832 ;	genAssign
   44E9 E5 10               833 	mov	a,_bp
   44EB 24 06               834 	add	a,#0x06
   44ED F8                  835 	mov	r0,a
   44EE                     836 00122$:
                            837 ;	genIpush
   44EE C0 07               838 	push	ar7
                            839 ;	genPointerGet
                            840 ;	genFarPointerGet
   44F0 E5 10               841 	mov	a,_bp
   44F2 24 06               842 	add	a,#0x06
   44F4 F8                  843 	mov	r0,a
   44F5 86 82               844 	mov	dpl,@r0
   44F7 08                  845 	inc	r0
   44F8 86 83               846 	mov	dph,@r0
   44FA E0                  847 	movx	a,@dptr
   44FB FF                  848 	mov	r7,a
                            849 ;	genCmpLt
                            850 ;	genCmp
   44FC C3                  851 	clr	c
   44FD EA                  852 	mov	a,r2
   44FE 9F                  853 	subb	a,r7
   44FF E4                  854 	clr	a
   4500 33                  855 	rlc	a
                            856 ;	genIpop
   4501 D0 07               857 	pop	ar7
                            858 ;	genIfx
                            859 ;	genIfxJump
                            860 ;	Peephole 108.c	removed ljmp by inverse jump logic
   4503 60 42               861 	jz	00125$
                            862 ;	Peephole 300	removed redundant label 00147$
                            863 ;	../../Common/socket.c:115: if (stacks[i].module[j] == protocol)
                            864 ;	genIpush
   4505 C0 07               865 	push	ar7
                            866 ;	genPlus
                            867 ;	Peephole 236.g	used r6 instead of ar6
   4507 EE                  868 	mov	a,r6
   4508 24 DD               869 	add	a,#_stacks
   450A FF                  870 	mov	r7,a
                            871 ;	Peephole 236.g	used r4 instead of ar4
   450B EC                  872 	mov	a,r4
   450C 34 F0               873 	addc	a,#(_stacks >> 8)
   450E FB                  874 	mov	r3,a
                            875 ;	genPlus
                            876 ;     genPlusIncr
   450F 0F                  877 	inc	r7
   4510 BF 00 01            878 	cjne	r7,#0x00,00148$
   4513 0B                  879 	inc	r3
   4514                     880 00148$:
                            881 ;	genPlus
                            882 ;	Peephole 236.g	used r2 instead of ar2
   4514 EA                  883 	mov	a,r2
                            884 ;	Peephole 236.a	used r7 instead of ar7
   4515 2F                  885 	add	a,r7
   4516 F5 82               886 	mov	dpl,a
                            887 ;	Peephole 181	changed mov to clr
   4518 E4                  888 	clr	a
                            889 ;	Peephole 236.b	used r3 instead of ar3
   4519 3B                  890 	addc	a,r3
   451A F5 83               891 	mov	dph,a
                            892 ;	genPointerGet
                            893 ;	genFarPointerGet
   451C E0                  894 	movx	a,@dptr
                            895 ;	genCmpEq
                            896 ;	gencjne
                            897 ;	gencjneshort
   451D FB                  898 	mov	r3,a
                            899 ;	Peephole 105	removed redundant mov
   451E B5 05 04            900 	cjne	a,ar5,00149$
   4521 74 01               901 	mov	a,#0x01
   4523 80 01               902 	sjmp	00150$
   4525                     903 00149$:
   4525 E4                  904 	clr	a
   4526                     905 00150$:
                            906 ;	genIpop
   4526 D0 07               907 	pop	ar7
                            908 ;	genIfx
                            909 ;	genIfxJump
                            910 ;	Peephole 108.c	removed ljmp by inverse jump logic
   4528 60 1A               911 	jz	00124$
                            912 ;	Peephole 300	removed redundant label 00151$
                            913 ;	../../Common/socket.c:117: stack = i;
                            914 ;	genAssign
   452A E5 10               915 	mov	a,_bp
   452C 24 05               916 	add	a,#0x05
   452E F8                  917 	mov	r0,a
   452F 86 07               918 	mov	ar7,@r0
                            919 ;	../../Common/socket.c:118: temp=j;
                            920 ;	genAssign
   4531 A8 10               921 	mov	r0,_bp
   4533 08                  922 	inc	r0
   4534 A6 02               923 	mov	@r0,ar2
                            924 ;	../../Common/socket.c:119: j = stacks[i].layers;
                            925 ;	genPlus
                            926 ;	Peephole 236.g	used r6 instead of ar6
   4536 EE                  927 	mov	a,r6
   4537 24 DD               928 	add	a,#_stacks
   4539 F5 82               929 	mov	dpl,a
                            930 ;	Peephole 236.g	used r4 instead of ar4
   453B EC                  931 	mov	a,r4
   453C 34 F0               932 	addc	a,#(_stacks >> 8)
   453E F5 83               933 	mov	dph,a
                            934 ;	genPointerGet
                            935 ;	genFarPointerGet
   4540 E0                  936 	movx	a,@dptr
   4541 FB                  937 	mov	r3,a
                            938 ;	genAssign
   4542 8B 02               939 	mov	ar2,r3
   4544                     940 00124$:
                            941 ;	../../Common/socket.c:112: for (j=0; j<stacks[i].layers; j++)
                            942 ;	genPlus
                            943 ;     genPlusIncr
   4544 0A                  944 	inc	r2
                            945 ;	Peephole 112.b	changed ljmp to sjmp
   4545 80 A7               946 	sjmp	00122$
   4547                     947 00125$:
                            948 ;	../../Common/socket.c:127: i++;
                            949 ;	genPlus
   4547 E5 10               950 	mov	a,_bp
   4549 24 05               951 	add	a,#0x05
   454B F8                  952 	mov	r0,a
                            953 ;     genPlusIncr
   454C 06                  954 	inc	@r0
   454D 02 44 B9            955 	ljmp	00104$
   4550                     956 00106$:
                            957 ;	../../Common/socket.c:130: for (i = 0; i < SOCKETS_MAX; i++)
                            958 ;	genAssign
   4550 7A 00               959 	mov	r2,#0x00
   4552                     960 00109$:
                            961 ;	genCmpLt
                            962 ;	genCmp
   4552 BA 04 00            963 	cjne	r2,#0x04,00152$
   4555                     964 00152$:
                            965 ;	genIfxJump
                            966 ;	Peephole 108.a	removed ljmp by inverse jump logic
   4555 50 1A               967 	jnc	00112$
                            968 ;	Peephole 300	removed redundant label 00153$
                            969 ;	../../Common/socket.c:132: if (sockets[i].protocol == 0) break;
                            970 ;	genIpush
   4557 C0 07               971 	push	ar7
                            972 ;	genMult
                            973 ;	genMultOneByte
   4559 EA                  974 	mov	a,r2
   455A 75 F0 18            975 	mov	b,#0x18
   455D A4                  976 	mul	ab
                            977 ;	genPlus
   455E 24 58               978 	add	a,#_sockets
   4560 FB                  979 	mov	r3,a
                            980 ;	Peephole 240	use clr instead of addc a,#0
   4561 E4                  981 	clr	a
   4562 34 EF               982 	addc	a,#(_sockets >> 8)
   4564 FF                  983 	mov	r7,a
                            984 ;	genPointerGet
                            985 ;	genFarPointerGet
   4565 8B 82               986 	mov	dpl,r3
   4567 8F 83               987 	mov	dph,r7
   4569 E0                  988 	movx	a,@dptr
                            989 ;	genIpop
   456A D0 07               990 	pop	ar7
                            991 ;	genIfx
                            992 ;	genIfxJump
                            993 ;	Peephole 108.c	removed ljmp by inverse jump logic
   456C 60 03               994 	jz	00112$
                            995 ;	Peephole 300	removed redundant label 00154$
                            996 ;	../../Common/socket.c:130: for (i = 0; i < SOCKETS_MAX; i++)
                            997 ;	genPlus
                            998 ;     genPlusIncr
   456E 0A                  999 	inc	r2
                           1000 ;	Peephole 112.b	changed ljmp to sjmp
   456F 80 E1              1001 	sjmp	00109$
   4571                    1002 00112$:
                           1003 ;	../../Common/socket.c:135: if ((stack >= 0) && (i < SOCKETS_MAX))
                           1004 ;	genCmpLt
                           1005 ;	genCmp
   4571 EF                 1006 	mov	a,r7
                           1007 ;	genIfxJump
   4572 30 E7 03           1008 	jnb	acc.7,00155$
   4575 02 47 46           1009 	ljmp	00120$
   4578                    1010 00155$:
                           1011 ;	genCmpLt
                           1012 ;	genCmp
   4578 BA 04 00           1013 	cjne	r2,#0x04,00156$
   457B                    1014 00156$:
                           1015 ;	genIfxJump
   457B 40 03              1016 	jc	00157$
   457D 02 47 46           1017 	ljmp	00120$
   4580                    1018 00157$:
                           1019 ;	../../Common/socket.c:137: retvalue = &(sockets[i]);
                           1020 ;	genMult
                           1021 ;	genMultOneByte
   4580 EA                 1022 	mov	a,r2
   4581 75 F0 18           1023 	mov	b,#0x18
   4584 A4                 1024 	mul	ab
                           1025 ;	genPlus
   4585 24 58              1026 	add	a,#_sockets
   4587 FA                 1027 	mov	r2,a
                           1028 ;	Peephole 240	use clr instead of addc a,#0
   4588 E4                 1029 	clr	a
   4589 34 EF              1030 	addc	a,#(_sockets >> 8)
   458B FB                 1031 	mov	r3,a
                           1032 ;	genCast
   458C A8 10              1033 	mov	r0,_bp
   458E 08                 1034 	inc	r0
   458F 08                 1035 	inc	r0
   4590 A6 02              1036 	mov	@r0,ar2
   4592 08                 1037 	inc	r0
   4593 A6 03              1038 	mov	@r0,ar3
   4595 08                 1039 	inc	r0
   4596 76 00              1040 	mov	@r0,#0x0
                           1041 ;	../../Common/socket.c:138: retvalue->sa.addr_type = ADDR_NONE;
                           1042 ;	genPlus
   4598 A8 10              1043 	mov	r0,_bp
   459A 08                 1044 	inc	r0
   459B 08                 1045 	inc	r0
                           1046 ;     genPlusIncr
   459C 74 06              1047 	mov	a,#0x06
   459E 26                 1048 	add	a,@r0
   459F FA                 1049 	mov	r2,a
                           1050 ;	Peephole 181	changed mov to clr
   45A0 E4                 1051 	clr	a
   45A1 08                 1052 	inc	r0
   45A2 36                 1053 	addc	a,@r0
   45A3 FB                 1054 	mov	r3,a
   45A4 08                 1055 	inc	r0
   45A5 86 04              1056 	mov	ar4,@r0
                           1057 ;	genPointerSet
                           1058 ;	genGenPointerSet
   45A7 8A 82              1059 	mov	dpl,r2
   45A9 8B 83              1060 	mov	dph,r3
   45AB 8C F0              1061 	mov	b,r4
                           1062 ;	Peephole 181	changed mov to clr
   45AD E4                 1063 	clr	a
   45AE 12 DF B7           1064 	lcall	__gptrput
                           1065 ;	../../Common/socket.c:139: retvalue->stack_id = stack;
                           1066 ;	genPlus
   45B1 A8 10              1067 	mov	r0,_bp
   45B3 08                 1068 	inc	r0
   45B4 08                 1069 	inc	r0
                           1070 ;     genPlusIncr
   45B5 74 01              1071 	mov	a,#0x01
   45B7 26                 1072 	add	a,@r0
   45B8 FA                 1073 	mov	r2,a
                           1074 ;	Peephole 181	changed mov to clr
   45B9 E4                 1075 	clr	a
   45BA 08                 1076 	inc	r0
   45BB 36                 1077 	addc	a,@r0
   45BC FB                 1078 	mov	r3,a
   45BD 08                 1079 	inc	r0
   45BE 86 04              1080 	mov	ar4,@r0
                           1081 ;	genPointerSet
                           1082 ;	genGenPointerSet
   45C0 8A 82              1083 	mov	dpl,r2
   45C2 8B 83              1084 	mov	dph,r3
   45C4 8C F0              1085 	mov	b,r4
   45C6 EF                 1086 	mov	a,r7
   45C7 12 DF B7           1087 	lcall	__gptrput
                           1088 ;	../../Common/socket.c:140: retvalue->sa.port = 0;		
                           1089 ;	genPlus
   45CA A8 10              1090 	mov	r0,_bp
   45CC 08                 1091 	inc	r0
   45CD 08                 1092 	inc	r0
                           1093 ;     genPlusIncr
   45CE 74 06              1094 	mov	a,#0x06
   45D0 26                 1095 	add	a,@r0
   45D1 FA                 1096 	mov	r2,a
                           1097 ;	Peephole 181	changed mov to clr
   45D2 E4                 1098 	clr	a
   45D3 08                 1099 	inc	r0
   45D4 36                 1100 	addc	a,@r0
   45D5 FB                 1101 	mov	r3,a
   45D6 08                 1102 	inc	r0
   45D7 86 04              1103 	mov	ar4,@r0
                           1104 ;	genPlus
                           1105 ;     genPlusIncr
   45D9 74 0B              1106 	mov	a,#0x0B
                           1107 ;	Peephole 236.a	used r2 instead of ar2
   45DB 2A                 1108 	add	a,r2
   45DC FA                 1109 	mov	r2,a
                           1110 ;	Peephole 181	changed mov to clr
   45DD E4                 1111 	clr	a
                           1112 ;	Peephole 236.b	used r3 instead of ar3
   45DE 3B                 1113 	addc	a,r3
   45DF FB                 1114 	mov	r3,a
                           1115 ;	genPointerSet
                           1116 ;	genGenPointerSet
   45E0 8A 82              1117 	mov	dpl,r2
   45E2 8B 83              1118 	mov	dph,r3
   45E4 8C F0              1119 	mov	b,r4
                           1120 ;	Peephole 181	changed mov to clr
   45E6 E4                 1121 	clr	a
   45E7 12 DF B7           1122 	lcall	__gptrput
   45EA A3                 1123 	inc	dptr
                           1124 ;	Peephole 181	changed mov to clr
   45EB E4                 1125 	clr	a
   45EC 12 DF B7           1126 	lcall	__gptrput
                           1127 ;	../../Common/socket.c:141: retvalue->port = 0;
                           1128 ;	genPlus
   45EF A8 10              1129 	mov	r0,_bp
   45F1 08                 1130 	inc	r0
   45F2 08                 1131 	inc	r0
                           1132 ;     genPlusIncr
   45F3 74 04              1133 	mov	a,#0x04
   45F5 26                 1134 	add	a,@r0
   45F6 FA                 1135 	mov	r2,a
                           1136 ;	Peephole 181	changed mov to clr
   45F7 E4                 1137 	clr	a
   45F8 08                 1138 	inc	r0
   45F9 36                 1139 	addc	a,@r0
   45FA FB                 1140 	mov	r3,a
   45FB 08                 1141 	inc	r0
   45FC 86 04              1142 	mov	ar4,@r0
                           1143 ;	genPointerSet
                           1144 ;	genGenPointerSet
   45FE 8A 82              1145 	mov	dpl,r2
   4600 8B 83              1146 	mov	dph,r3
   4602 8C F0              1147 	mov	b,r4
                           1148 ;	Peephole 181	changed mov to clr
   4604 E4                 1149 	clr	a
   4605 12 DF B7           1150 	lcall	__gptrput
   4608 A3                 1151 	inc	dptr
                           1152 ;	Peephole 181	changed mov to clr
   4609 E4                 1153 	clr	a
   460A 12 DF B7           1154 	lcall	__gptrput
                           1155 ;	../../Common/socket.c:142: retvalue->listen = 0;
                           1156 ;	genPlus
   460D A8 10              1157 	mov	r0,_bp
   460F 08                 1158 	inc	r0
   4610 08                 1159 	inc	r0
                           1160 ;     genPlusIncr
   4611 74 02              1161 	mov	a,#0x02
   4613 26                 1162 	add	a,@r0
   4614 FA                 1163 	mov	r2,a
                           1164 ;	Peephole 181	changed mov to clr
   4615 E4                 1165 	clr	a
   4616 08                 1166 	inc	r0
   4617 36                 1167 	addc	a,@r0
   4618 FB                 1168 	mov	r3,a
   4619 08                 1169 	inc	r0
   461A 86 04              1170 	mov	ar4,@r0
                           1171 ;	genPointerSet
                           1172 ;	genGenPointerSet
   461C 8A 82              1173 	mov	dpl,r2
   461E 8B 83              1174 	mov	dph,r3
   4620 8C F0              1175 	mov	b,r4
                           1176 ;	Peephole 181	changed mov to clr
   4622 E4                 1177 	clr	a
   4623 12 DF B7           1178 	lcall	__gptrput
   4626 A3                 1179 	inc	dptr
                           1180 ;	Peephole 181	changed mov to clr
   4627 E4                 1181 	clr	a
   4628 12 DF B7           1182 	lcall	__gptrput
                           1183 ;	../../Common/socket.c:143: retvalue->protocol = protocol;
                           1184 ;	genPointerSet
                           1185 ;	genGenPointerSet
   462B A8 10              1186 	mov	r0,_bp
   462D 08                 1187 	inc	r0
   462E 08                 1188 	inc	r0
   462F 86 82              1189 	mov	dpl,@r0
   4631 08                 1190 	inc	r0
   4632 86 83              1191 	mov	dph,@r0
   4634 08                 1192 	inc	r0
   4635 86 F0              1193 	mov	b,@r0
   4637 ED                 1194 	mov	a,r5
   4638 12 DF B7           1195 	lcall	__gptrput
                           1196 ;	../../Common/socket.c:144: retvalue->callback = sock_handler;
                           1197 ;	genPlus
   463B A8 10              1198 	mov	r0,_bp
   463D 08                 1199 	inc	r0
   463E 08                 1200 	inc	r0
                           1201 ;     genPlusIncr
   463F 74 16              1202 	mov	a,#0x16
   4641 26                 1203 	add	a,@r0
   4642 FA                 1204 	mov	r2,a
                           1205 ;	Peephole 181	changed mov to clr
   4643 E4                 1206 	clr	a
   4644 08                 1207 	inc	r0
   4645 36                 1208 	addc	a,@r0
   4646 FB                 1209 	mov	r3,a
   4647 08                 1210 	inc	r0
   4648 86 04              1211 	mov	ar4,@r0
                           1212 ;	genPointerSet
                           1213 ;	genGenPointerSet
   464A 8A 82              1214 	mov	dpl,r2
   464C 8B 83              1215 	mov	dph,r3
   464E 8C F0              1216 	mov	b,r4
   4650 E5 10              1217 	mov	a,_bp
   4652 24 FC              1218 	add	a,#0xfffffffc
   4654 F8                 1219 	mov	r0,a
   4655 E6                 1220 	mov	a,@r0
   4656 12 DF B7           1221 	lcall	__gptrput
   4659 A3                 1222 	inc	dptr
   465A 08                 1223 	inc	r0
   465B E6                 1224 	mov	a,@r0
   465C 12 DF B7           1225 	lcall	__gptrput
                           1226 ;	../../Common/socket.c:145: if ( (retvalue->queue == 0) && (sock_handler == 0) )
                           1227 ;	genPlus
   465F A8 10              1228 	mov	r0,_bp
   4661 08                 1229 	inc	r0
   4662 08                 1230 	inc	r0
   4663 E5 10              1231 	mov	a,_bp
   4665 24 08              1232 	add	a,#0x08
   4667 F9                 1233 	mov	r1,a
                           1234 ;     genPlusIncr
   4668 74 13              1235 	mov	a,#0x13
   466A 26                 1236 	add	a,@r0
   466B F7                 1237 	mov	@r1,a
                           1238 ;	Peephole 181	changed mov to clr
   466C E4                 1239 	clr	a
   466D 08                 1240 	inc	r0
   466E 36                 1241 	addc	a,@r0
   466F 09                 1242 	inc	r1
   4670 F7                 1243 	mov	@r1,a
   4671 08                 1244 	inc	r0
   4672 09                 1245 	inc	r1
   4673 E6                 1246 	mov	a,@r0
   4674 F7                 1247 	mov	@r1,a
                           1248 ;	genPointerGet
                           1249 ;	genGenPointerGet
   4675 E5 10              1250 	mov	a,_bp
   4677 24 08              1251 	add	a,#0x08
   4679 F8                 1252 	mov	r0,a
   467A 86 82              1253 	mov	dpl,@r0
   467C 08                 1254 	inc	r0
   467D 86 83              1255 	mov	dph,@r0
   467F 08                 1256 	inc	r0
   4680 86 F0              1257 	mov	b,@r0
   4682 12 E4 9F           1258 	lcall	__gptrget
   4685 FD                 1259 	mov	r5,a
   4686 A3                 1260 	inc	dptr
   4687 12 E4 9F           1261 	lcall	__gptrget
   468A FE                 1262 	mov	r6,a
   468B A3                 1263 	inc	dptr
   468C 12 E4 9F           1264 	lcall	__gptrget
   468F FA                 1265 	mov	r2,a
                           1266 ;	genIfx
   4690 ED                 1267 	mov	a,r5
   4691 4E                 1268 	orl	a,r6
   4692 4A                 1269 	orl	a,r2
                           1270 ;	genIfxJump
                           1271 ;	Peephole 108.b	removed ljmp by inverse jump logic
   4693 70 40              1272 	jnz	00114$
                           1273 ;	Peephole 300	removed redundant label 00158$
                           1274 ;	genIfx
   4695 E5 10              1275 	mov	a,_bp
   4697 24 FC              1276 	add	a,#0xfffffffc
   4699 F8                 1277 	mov	r0,a
   469A E6                 1278 	mov	a,@r0
   469B 08                 1279 	inc	r0
   469C 46                 1280 	orl	a,@r0
                           1281 ;	genIfxJump
                           1282 ;	Peephole 108.b	removed ljmp by inverse jump logic
   469D 70 36              1283 	jnz	00114$
                           1284 ;	Peephole 300	removed redundant label 00159$
                           1285 ;	../../Common/socket.c:147: retvalue->queue = xQueueCreate( 5, sizeof( buffer_t * ) );
                           1286 ;	genAssign
   469F E5 10              1287 	mov	a,_bp
   46A1 24 08              1288 	add	a,#0x08
   46A3 F8                 1289 	mov	r0,a
                           1290 ;	genIpush
   46A4 C0 07              1291 	push	ar7
   46A6 74 03              1292 	mov	a,#0x03
   46A8 C0 E0              1293 	push	acc
                           1294 ;	genCall
   46AA 75 82 05           1295 	mov	dpl,#0x05
   46AD 12 1B 2D           1296 	lcall	_xQueueCreate
   46B0 AD 82              1297 	mov	r5,dpl
   46B2 AE 83              1298 	mov	r6,dph
   46B4 AA F0              1299 	mov	r2,b
   46B6 15 81              1300 	dec	sp
   46B8 D0 07              1301 	pop	ar7
                           1302 ;	genPointerSet
                           1303 ;	genGenPointerSet
   46BA E5 10              1304 	mov	a,_bp
   46BC 24 08              1305 	add	a,#0x08
   46BE F8                 1306 	mov	r0,a
   46BF 86 82              1307 	mov	dpl,@r0
   46C1 08                 1308 	inc	r0
   46C2 86 83              1309 	mov	dph,@r0
   46C4 08                 1310 	inc	r0
   46C5 86 F0              1311 	mov	b,@r0
   46C7 ED                 1312 	mov	a,r5
   46C8 12 DF B7           1313 	lcall	__gptrput
   46CB A3                 1314 	inc	dptr
   46CC EE                 1315 	mov	a,r6
   46CD 12 DF B7           1316 	lcall	__gptrput
   46D0 A3                 1317 	inc	dptr
   46D1 EA                 1318 	mov	a,r2
   46D2 12 DF B7           1319 	lcall	__gptrput
   46D5                    1320 00114$:
                           1321 ;	../../Common/socket.c:152: module = module_get(stacks[stack].module[temp]);
                           1322 ;	genMult
                           1323 ;	genMultOneByte
   46D5 C2 D5              1324 	clr	F0
   46D7 75 F0 05           1325 	mov	b,#0x05
   46DA EF                 1326 	mov	a,r7
   46DB 30 E7 04           1327 	jnb	acc.7,00160$
   46DE B2 D5              1328 	cpl	F0
   46E0 F4                 1329 	cpl	a
   46E1 04                 1330 	inc	a
   46E2                    1331 00160$:
   46E2 A4                 1332 	mul	ab
   46E3 30 D5 0A           1333 	jnb	F0,00161$
   46E6 F4                 1334 	cpl	a
   46E7 24 01              1335 	add	a,#1
   46E9 C5 F0              1336 	xch	a,b
   46EB F4                 1337 	cpl	a
   46EC 34 00              1338 	addc	a,#0
   46EE C5 F0              1339 	xch	a,b
   46F0                    1340 00161$:
                           1341 ;	genPlus
   46F0 24 DD              1342 	add	a,#_stacks
   46F2 FA                 1343 	mov	r2,a
   46F3 74 F0              1344 	mov	a,#(_stacks >> 8)
   46F5 35 F0              1345 	addc	a,b
   46F7 FB                 1346 	mov	r3,a
                           1347 ;	genPlus
                           1348 ;     genPlusIncr
   46F8 0A                 1349 	inc	r2
   46F9 BA 00 01           1350 	cjne	r2,#0x00,00162$
   46FC 0B                 1351 	inc	r3
   46FD                    1352 00162$:
                           1353 ;	genPlus
   46FD A8 10              1354 	mov	r0,_bp
   46FF 08                 1355 	inc	r0
   4700 E6                 1356 	mov	a,@r0
                           1357 ;	Peephole 236.a	used r2 instead of ar2
   4701 2A                 1358 	add	a,r2
   4702 F5 82              1359 	mov	dpl,a
                           1360 ;	Peephole 181	changed mov to clr
   4704 E4                 1361 	clr	a
                           1362 ;	Peephole 236.b	used r3 instead of ar3
   4705 3B                 1363 	addc	a,r3
   4706 F5 83              1364 	mov	dph,a
                           1365 ;	genPointerGet
                           1366 ;	genFarPointerGet
   4708 E0                 1367 	movx	a,@dptr
                           1368 ;	genCall
   4709 FA                 1369 	mov	r2,a
                           1370 ;	Peephole 244.c	loading dpl from a instead of r2
   470A F5 82              1371 	mov	dpl,a
   470C 12 43 31           1372 	lcall	_module_get
   470F AA 82              1373 	mov	r2,dpl
   4711 AB 83              1374 	mov	r3,dph
   4713 AC F0              1375 	mov	r4,b
                           1376 ;	genAssign
                           1377 ;	../../Common/socket.c:171: if (module && (module->addr_type != ADDR_NONE))
                           1378 ;	genIfx
   4715 EA                 1379 	mov	a,r2
   4716 4B                 1380 	orl	a,r3
   4717 4C                 1381 	orl	a,r4
                           1382 ;	genIfxJump
                           1383 ;	Peephole 108.c	removed ljmp by inverse jump logic
   4718 60 2C              1384 	jz	00120$
                           1385 ;	Peephole 300	removed redundant label 00163$
                           1386 ;	genPlus
                           1387 ;     genPlusIncr
   471A 74 0A              1388 	mov	a,#0x0A
                           1389 ;	Peephole 236.a	used r2 instead of ar2
   471C 2A                 1390 	add	a,r2
   471D FA                 1391 	mov	r2,a
                           1392 ;	Peephole 181	changed mov to clr
   471E E4                 1393 	clr	a
                           1394 ;	Peephole 236.b	used r3 instead of ar3
   471F 3B                 1395 	addc	a,r3
   4720 FB                 1396 	mov	r3,a
                           1397 ;	genPointerGet
                           1398 ;	genGenPointerGet
   4721 8A 82              1399 	mov	dpl,r2
   4723 8B 83              1400 	mov	dph,r3
   4725 8C F0              1401 	mov	b,r4
   4727 12 E4 9F           1402 	lcall	__gptrget
                           1403 ;	genCmpEq
                           1404 ;	gencjneshort
                           1405 ;	Peephole 112.b	changed ljmp to sjmp
   472A FA                 1406 	mov	r2,a
                           1407 ;	Peephole 115.b	jump optimization
   472B 60 19              1408 	jz	00120$
                           1409 ;	Peephole 300	removed redundant label 00164$
                           1410 ;	../../Common/socket.c:173: retvalue->sa.addr_type = module->addr_type;
                           1411 ;	genPlus
   472D A8 10              1412 	mov	r0,_bp
   472F 08                 1413 	inc	r0
   4730 08                 1414 	inc	r0
                           1415 ;     genPlusIncr
   4731 74 06              1416 	mov	a,#0x06
   4733 26                 1417 	add	a,@r0
   4734 FB                 1418 	mov	r3,a
                           1419 ;	Peephole 181	changed mov to clr
   4735 E4                 1420 	clr	a
   4736 08                 1421 	inc	r0
   4737 36                 1422 	addc	a,@r0
   4738 FC                 1423 	mov	r4,a
   4739 08                 1424 	inc	r0
   473A 86 05              1425 	mov	ar5,@r0
                           1426 ;	genPointerSet
                           1427 ;	genGenPointerSet
   473C 8B 82              1428 	mov	dpl,r3
   473E 8C 83              1429 	mov	dph,r4
   4740 8D F0              1430 	mov	b,r5
   4742 EA                 1431 	mov	a,r2
   4743 12 DF B7           1432 	lcall	__gptrput
                           1433 ;	../../Common/socket.c:174: i = stacks[stack].layers;
   4746                    1434 00120$:
                           1435 ;	../../Common/socket.c:178: return retvalue;
                           1436 ;	genRet
   4746 A8 10              1437 	mov	r0,_bp
   4748 08                 1438 	inc	r0
   4749 08                 1439 	inc	r0
   474A 86 82              1440 	mov	dpl,@r0
   474C 08                 1441 	inc	r0
   474D 86 83              1442 	mov	dph,@r0
   474F 08                 1443 	inc	r0
   4750 86 F0              1444 	mov	b,@r0
                           1445 ;	Peephole 300	removed redundant label 00126$
   4752 85 10 81           1446 	mov	sp,_bp
   4755 D0 10              1447 	pop	_bp
   4757 22                 1448 	ret
                           1449 ;------------------------------------------------------------
                           1450 ;Allocation info for local variables in function 'socket_close'
                           1451 ;------------------------------------------------------------
                           1452 ;si                        Allocated to registers r2 r3 r4 
                           1453 ;i                         Allocated to registers r5 
                           1454 ;------------------------------------------------------------
                           1455 ;	../../Common/socket.c:191: portCHAR socket_close (socket_t * si)
                           1456 ;	-----------------------------------------
                           1457 ;	 function socket_close
                           1458 ;	-----------------------------------------
   4758                    1459 _socket_close:
                           1460 ;	genReceive
                           1461 ;	../../Common/socket.c:195: i = socket_id_find(si);
                           1462 ;	genCall
   4758 AA 82              1463 	mov	r2,dpl
   475A AB 83              1464 	mov	r3,dph
   475C AC F0              1465 	mov	r4,b
                           1466 ;	Peephole 238.d	removed 3 redundant moves
   475E C0 02              1467 	push	ar2
   4760 C0 03              1468 	push	ar3
   4762 C0 04              1469 	push	ar4
   4764 12 49 11           1470 	lcall	_socket_id_find
   4767 AD 82              1471 	mov	r5,dpl
   4769 D0 04              1472 	pop	ar4
   476B D0 03              1473 	pop	ar3
   476D D0 02              1474 	pop	ar2
                           1475 ;	genAssign
                           1476 ;	../../Common/socket.c:196: if (i >= 0)
                           1477 ;	genCmpLt
                           1478 ;	genCmp
   476F ED                 1479 	mov	a,r5
                           1480 ;	genIfxJump
                           1481 ;	Peephole 108.e	removed ljmp by inverse jump logic
   4770 20 E7 0E           1482 	jb	acc.7,00102$
                           1483 ;	Peephole 300	removed redundant label 00106$
                           1484 ;	../../Common/socket.c:198: si->protocol = 0;
                           1485 ;	genPointerSet
                           1486 ;	genGenPointerSet
   4773 8A 82              1487 	mov	dpl,r2
   4775 8B 83              1488 	mov	dph,r3
   4777 8C F0              1489 	mov	b,r4
                           1490 ;	Peephole 181	changed mov to clr
   4779 E4                 1491 	clr	a
   477A 12 DF B7           1492 	lcall	__gptrput
                           1493 ;	../../Common/socket.c:199: return pdTRUE;
                           1494 ;	genRet
   477D 75 82 01           1495 	mov	dpl,#0x01
                           1496 ;	Peephole 112.b	changed ljmp to sjmp
                           1497 ;	../../Common/socket.c:201: return pdFAIL;
                           1498 ;	genRet
                           1499 ;	Peephole 237.a	removed sjmp to ret
   4780 22                 1500 	ret
   4781                    1501 00102$:
   4781 75 82 00           1502 	mov	dpl,#0x00
                           1503 ;	Peephole 300	removed redundant label 00103$
   4784 22                 1504 	ret
                           1505 ;------------------------------------------------------------
                           1506 ;Allocation info for local variables in function 'socket_bind'
                           1507 ;------------------------------------------------------------
                           1508 ;sa                        Allocated to stack - offset -5
                           1509 ;si                        Allocated to stack - offset 1
                           1510 ;stack_numbers             Allocated to registers r2 
                           1511 ;sloc0                     Allocated to stack - offset 4
                           1512 ;sloc1                     Allocated to stack - offset 8
                           1513 ;sloc2                     Allocated to stack - offset 7
                           1514 ;sloc3                     Allocated to stack - offset 13
                           1515 ;------------------------------------------------------------
                           1516 ;	../../Common/socket.c:215: portCHAR socket_bind (socket_t * si,               /* Socket to bind to */
                           1517 ;	-----------------------------------------
                           1518 ;	 function socket_bind
                           1519 ;	-----------------------------------------
   4785                    1520 _socket_bind:
   4785 C0 10              1521 	push	_bp
   4787 85 81 10           1522 	mov	_bp,sp
                           1523 ;     genReceive
   478A C0 82              1524 	push	dpl
   478C C0 83              1525 	push	dph
   478E C0 F0              1526 	push	b
   4790 E5 81              1527 	mov	a,sp
   4792 24 09              1528 	add	a,#0x09
   4794 F5 81              1529 	mov	sp,a
                           1530 ;	../../Common/socket.c:218: if (((sa->port == 0) || (sa->port == NPING_PORT)) || ((sa->port > 0xF0BF)))     /* 254 reserved for PING */
                           1531 ;	genAssign
   4796 E5 10              1532 	mov	a,_bp
   4798 24 FB              1533 	add	a,#0xfffffffb
   479A F8                 1534 	mov	r0,a
   479B 86 05              1535 	mov	ar5,@r0
   479D 08                 1536 	inc	r0
   479E 86 06              1537 	mov	ar6,@r0
   47A0 08                 1538 	inc	r0
   47A1 86 07              1539 	mov	ar7,@r0
                           1540 ;	genPlus
   47A3 E5 10              1541 	mov	a,_bp
   47A5 24 04              1542 	add	a,#0x04
   47A7 F8                 1543 	mov	r0,a
                           1544 ;     genPlusIncr
   47A8 74 0B              1545 	mov	a,#0x0B
                           1546 ;	Peephole 236.a	used r5 instead of ar5
   47AA 2D                 1547 	add	a,r5
   47AB F6                 1548 	mov	@r0,a
                           1549 ;	Peephole 181	changed mov to clr
   47AC E4                 1550 	clr	a
                           1551 ;	Peephole 236.b	used r6 instead of ar6
   47AD 3E                 1552 	addc	a,r6
   47AE 08                 1553 	inc	r0
   47AF F6                 1554 	mov	@r0,a
   47B0 08                 1555 	inc	r0
   47B1 A6 07              1556 	mov	@r0,ar7
                           1557 ;	genPointerGet
                           1558 ;	genGenPointerGet
   47B3 E5 10              1559 	mov	a,_bp
   47B5 24 04              1560 	add	a,#0x04
   47B7 F8                 1561 	mov	r0,a
   47B8 86 82              1562 	mov	dpl,@r0
   47BA 08                 1563 	inc	r0
   47BB 86 83              1564 	mov	dph,@r0
   47BD 08                 1565 	inc	r0
   47BE 86 F0              1566 	mov	b,@r0
   47C0 12 E4 9F           1567 	lcall	__gptrget
   47C3 FA                 1568 	mov	r2,a
   47C4 A3                 1569 	inc	dptr
   47C5 12 E4 9F           1570 	lcall	__gptrget
                           1571 ;	genIfx
   47C8 FB                 1572 	mov	r3,a
                           1573 ;	Peephole 135	removed redundant mov
   47C9 4A                 1574 	orl	a,r2
                           1575 ;	genIfxJump
                           1576 ;	Peephole 108.c	removed ljmp by inverse jump logic
   47CA 60 11              1577 	jz	00101$
                           1578 ;	Peephole 300	removed redundant label 00122$
                           1579 ;	genCmpEq
                           1580 ;	gencjneshort
   47CC BA FE 05           1581 	cjne	r2,#0xFE,00123$
   47CF BB 00 02           1582 	cjne	r3,#0x00,00123$
                           1583 ;	Peephole 112.b	changed ljmp to sjmp
   47D2 80 09              1584 	sjmp	00101$
   47D4                    1585 00123$:
                           1586 ;	genCmpGt
                           1587 ;	genCmp
   47D4 C3                 1588 	clr	c
   47D5 74 BF              1589 	mov	a,#0xBF
   47D7 9A                 1590 	subb	a,r2
   47D8 74 F0              1591 	mov	a,#0xF0
   47DA 9B                 1592 	subb	a,r3
                           1593 ;	genIfxJump
                           1594 ;	Peephole 108.a	removed ljmp by inverse jump logic
   47DB 50 06              1595 	jnc	00102$
                           1596 ;	Peephole 300	removed redundant label 00124$
   47DD                    1597 00101$:
                           1598 ;	../../Common/socket.c:223: return pdFAIL;
                           1599 ;	genRet
   47DD 75 82 00           1600 	mov	dpl,#0x00
   47E0 02 49 0B           1601 	ljmp	00115$
   47E3                    1602 00102$:
                           1603 ;	../../Common/socket.c:226: if ((si == NULL) || (si->listen != 0))
                           1604 ;	genCmpEq
   47E3 A8 10              1605 	mov	r0,_bp
   47E5 08                 1606 	inc	r0
                           1607 ;	gencjneshort
   47E6 B6 00 0A           1608 	cjne	@r0,#0x00,00125$
   47E9 08                 1609 	inc	r0
   47EA B6 00 06           1610 	cjne	@r0,#0x00,00125$
   47ED 08                 1611 	inc	r0
   47EE B6 00 02           1612 	cjne	@r0,#0x00,00125$
                           1613 ;	Peephole 112.b	changed ljmp to sjmp
   47F1 80 41              1614 	sjmp	00105$
   47F3                    1615 00125$:
                           1616 ;	genIpush
   47F3 C0 05              1617 	push	ar5
   47F5 C0 06              1618 	push	ar6
   47F7 C0 07              1619 	push	ar7
                           1620 ;	genPlus
   47F9 A8 10              1621 	mov	r0,_bp
   47FB 08                 1622 	inc	r0
   47FC E5 10              1623 	mov	a,_bp
   47FE 24 07              1624 	add	a,#0x07
   4800 F9                 1625 	mov	r1,a
                           1626 ;     genPlusIncr
   4801 74 02              1627 	mov	a,#0x02
   4803 26                 1628 	add	a,@r0
   4804 F7                 1629 	mov	@r1,a
                           1630 ;	Peephole 181	changed mov to clr
   4805 E4                 1631 	clr	a
   4806 08                 1632 	inc	r0
   4807 36                 1633 	addc	a,@r0
   4808 09                 1634 	inc	r1
   4809 F7                 1635 	mov	@r1,a
   480A 08                 1636 	inc	r0
   480B 09                 1637 	inc	r1
   480C E6                 1638 	mov	a,@r0
   480D F7                 1639 	mov	@r1,a
                           1640 ;	genPointerGet
                           1641 ;	genGenPointerGet
   480E E5 10              1642 	mov	a,_bp
   4810 24 07              1643 	add	a,#0x07
   4812 F8                 1644 	mov	r0,a
   4813 86 82              1645 	mov	dpl,@r0
   4815 08                 1646 	inc	r0
   4816 86 83              1647 	mov	dph,@r0
   4818 08                 1648 	inc	r0
   4819 86 F0              1649 	mov	b,@r0
   481B 12 E4 9F           1650 	lcall	__gptrget
   481E FD                 1651 	mov	r5,a
   481F A3                 1652 	inc	dptr
   4820 12 E4 9F           1653 	lcall	__gptrget
   4823 FE                 1654 	mov	r6,a
                           1655 ;	genCmpEq
                           1656 ;	gencjne
                           1657 ;	gencjneshort
                           1658 ;	Peephole 241.c	optimized compare
   4824 E4                 1659 	clr	a
   4825 BD 00 04           1660 	cjne	r5,#0x00,00126$
   4828 BE 00 01           1661 	cjne	r6,#0x00,00126$
   482B 04                 1662 	inc	a
   482C                    1663 00126$:
                           1664 ;	Peephole 300	removed redundant label 00127$
                           1665 ;	genIpop
   482C D0 07              1666 	pop	ar7
   482E D0 06              1667 	pop	ar6
   4830 D0 05              1668 	pop	ar5
                           1669 ;	genIfx
                           1670 ;	genIfxJump
                           1671 ;	Peephole 108.b	removed ljmp by inverse jump logic
   4832 70 06              1672 	jnz	00106$
                           1673 ;	Peephole 300	removed redundant label 00128$
   4834                    1674 00105$:
                           1675 ;	../../Common/socket.c:231: return pdFAIL;
                           1676 ;	genRet
   4834 75 82 00           1677 	mov	dpl,#0x00
   4837 02 49 0B           1678 	ljmp	00115$
   483A                    1679 00106$:
                           1680 ;	../../Common/socket.c:234: if (sa->addr_type != ADDR_NONE)
                           1681 ;	genPointerGet
                           1682 ;	genGenPointerGet
   483A 8D 82              1683 	mov	dpl,r5
   483C 8E 83              1684 	mov	dph,r6
   483E 8F F0              1685 	mov	b,r7
   4840 12 E4 9F           1686 	lcall	__gptrget
                           1687 ;	genCmpEq
                           1688 ;	gencjneshort
                           1689 ;	Peephole 112.b	changed ljmp to sjmp
   4843 FA                 1690 	mov	r2,a
                           1691 ;	Peephole 115.b	jump optimization
   4844 60 5C              1692 	jz	00113$
                           1693 ;	Peephole 300	removed redundant label 00129$
                           1694 ;	../../Common/socket.c:236: if ((si->sa.addr_type == ADDR_NONE) || (sa->addr_type == si->sa.addr_type))
                           1695 ;	genIpush
   4846 C0 05              1696 	push	ar5
   4848 C0 06              1697 	push	ar6
   484A C0 07              1698 	push	ar7
                           1699 ;	genPlus
   484C A8 10              1700 	mov	r0,_bp
   484E 08                 1701 	inc	r0
                           1702 ;     genPlusIncr
   484F 74 06              1703 	mov	a,#0x06
   4851 26                 1704 	add	a,@r0
   4852 FD                 1705 	mov	r5,a
                           1706 ;	Peephole 181	changed mov to clr
   4853 E4                 1707 	clr	a
   4854 08                 1708 	inc	r0
   4855 36                 1709 	addc	a,@r0
   4856 FE                 1710 	mov	r6,a
   4857 08                 1711 	inc	r0
   4858 86 07              1712 	mov	ar7,@r0
                           1713 ;	genPointerGet
                           1714 ;	genGenPointerGet
   485A 8D 82              1715 	mov	dpl,r5
   485C 8E 83              1716 	mov	dph,r6
   485E 8F F0              1717 	mov	b,r7
   4860 12 E4 9F           1718 	lcall	__gptrget
   4863 FB                 1719 	mov	r3,a
                           1720 ;	genIpop
   4864 D0 07              1721 	pop	ar7
   4866 D0 06              1722 	pop	ar6
   4868 D0 05              1723 	pop	ar5
                           1724 ;	genIfx
   486A EB                 1725 	mov	a,r3
                           1726 ;	genIfxJump
                           1727 ;	Peephole 108.c	removed ljmp by inverse jump logic
   486B 60 04              1728 	jz	00108$
                           1729 ;	Peephole 300	removed redundant label 00130$
                           1730 ;	genCmpEq
                           1731 ;	gencjneshort
   486D EA                 1732 	mov	a,r2
                           1733 ;	Peephole 112.b	changed ljmp to sjmp
                           1734 ;	Peephole 198.b	optimized misc jump sequence
   486E B5 03 2C           1735 	cjne	a,ar3,00109$
                           1736 ;	Peephole 200.b	removed redundant sjmp
                           1737 ;	Peephole 300	removed redundant label 00131$
                           1738 ;	Peephole 300	removed redundant label 00132$
   4871                    1739 00108$:
                           1740 ;	../../Common/socket.c:238: memcpy(&(si->sa), sa, sizeof(sa));
                           1741 ;	genPlus
   4871 A8 10              1742 	mov	r0,_bp
   4873 08                 1743 	inc	r0
                           1744 ;     genPlusIncr
   4874 74 06              1745 	mov	a,#0x06
   4876 26                 1746 	add	a,@r0
   4877 FA                 1747 	mov	r2,a
                           1748 ;	Peephole 181	changed mov to clr
   4878 E4                 1749 	clr	a
   4879 08                 1750 	inc	r0
   487A 36                 1751 	addc	a,@r0
   487B FB                 1752 	mov	r3,a
   487C 08                 1753 	inc	r0
   487D 86 04              1754 	mov	ar4,@r0
                           1755 ;	genIpush
   487F 74 03              1756 	mov	a,#0x03
   4881 C0 E0              1757 	push	acc
                           1758 ;	Peephole 181	changed mov to clr
   4883 E4                 1759 	clr	a
   4884 C0 E0              1760 	push	acc
                           1761 ;	genIpush
   4886 C0 05              1762 	push	ar5
   4888 C0 06              1763 	push	ar6
   488A C0 07              1764 	push	ar7
                           1765 ;	genCall
   488C 8A 82              1766 	mov	dpl,r2
   488E 8B 83              1767 	mov	dph,r3
   4890 8C F0              1768 	mov	b,r4
   4892 12 E2 C7           1769 	lcall	_memcpy
   4895 E5 81              1770 	mov	a,sp
   4897 24 FB              1771 	add	a,#0xfb
   4899 F5 81              1772 	mov	sp,a
                           1773 ;	Peephole 112.b	changed ljmp to sjmp
   489B 80 22              1774 	sjmp	00114$
   489D                    1775 00109$:
                           1776 ;	../../Common/socket.c:249: return pdFAIL;
                           1777 ;	genRet
   489D 75 82 00           1778 	mov	dpl,#0x00
                           1779 ;	Peephole 112.b	changed ljmp to sjmp
   48A0 80 69              1780 	sjmp	00115$
   48A2                    1781 00113$:
                           1782 ;	../../Common/socket.c:254: uint8_t stack_numbers = stack_number_get();
                           1783 ;	genCall
   48A2 12 64 F8           1784 	lcall	_stack_number_get
   48A5 AA 82              1785 	mov	r2,dpl
                           1786 ;	genAssign
                           1787 ;	../../Common/socket.c:255: si->stack_id = stack_numbers;
                           1788 ;	genPlus
   48A7 A8 10              1789 	mov	r0,_bp
   48A9 08                 1790 	inc	r0
                           1791 ;     genPlusIncr
   48AA 74 01              1792 	mov	a,#0x01
   48AC 26                 1793 	add	a,@r0
   48AD FB                 1794 	mov	r3,a
                           1795 ;	Peephole 181	changed mov to clr
   48AE E4                 1796 	clr	a
   48AF 08                 1797 	inc	r0
   48B0 36                 1798 	addc	a,@r0
   48B1 FC                 1799 	mov	r4,a
   48B2 08                 1800 	inc	r0
   48B3 86 05              1801 	mov	ar5,@r0
                           1802 ;	genPointerSet
                           1803 ;	genGenPointerSet
   48B5 8B 82              1804 	mov	dpl,r3
   48B7 8C 83              1805 	mov	dph,r4
   48B9 8D F0              1806 	mov	b,r5
   48BB EA                 1807 	mov	a,r2
   48BC 12 DF B7           1808 	lcall	__gptrput
   48BF                    1809 00114$:
                           1810 ;	../../Common/socket.c:261: si->listen = sa->port;
                           1811 ;	genPointerGet
                           1812 ;	genGenPointerGet
   48BF E5 10              1813 	mov	a,_bp
   48C1 24 04              1814 	add	a,#0x04
   48C3 F8                 1815 	mov	r0,a
   48C4 86 82              1816 	mov	dpl,@r0
   48C6 08                 1817 	inc	r0
   48C7 86 83              1818 	mov	dph,@r0
   48C9 08                 1819 	inc	r0
   48CA 86 F0              1820 	mov	b,@r0
   48CC 12 E4 9F           1821 	lcall	__gptrget
   48CF FA                 1822 	mov	r2,a
   48D0 A3                 1823 	inc	dptr
   48D1 12 E4 9F           1824 	lcall	__gptrget
   48D4 FB                 1825 	mov	r3,a
                           1826 ;	genPointerSet
                           1827 ;	genGenPointerSet
   48D5 E5 10              1828 	mov	a,_bp
   48D7 24 07              1829 	add	a,#0x07
   48D9 F8                 1830 	mov	r0,a
   48DA 86 82              1831 	mov	dpl,@r0
   48DC 08                 1832 	inc	r0
   48DD 86 83              1833 	mov	dph,@r0
   48DF 08                 1834 	inc	r0
   48E0 86 F0              1835 	mov	b,@r0
   48E2 EA                 1836 	mov	a,r2
   48E3 12 DF B7           1837 	lcall	__gptrput
   48E6 A3                 1838 	inc	dptr
   48E7 EB                 1839 	mov	a,r3
   48E8 12 DF B7           1840 	lcall	__gptrput
                           1841 ;	../../Common/socket.c:262: si->port = sa->port;
                           1842 ;	genPlus
   48EB A8 10              1843 	mov	r0,_bp
   48ED 08                 1844 	inc	r0
                           1845 ;     genPlusIncr
   48EE 74 04              1846 	mov	a,#0x04
   48F0 26                 1847 	add	a,@r0
   48F1 FC                 1848 	mov	r4,a
                           1849 ;	Peephole 181	changed mov to clr
   48F2 E4                 1850 	clr	a
   48F3 08                 1851 	inc	r0
   48F4 36                 1852 	addc	a,@r0
   48F5 FD                 1853 	mov	r5,a
   48F6 08                 1854 	inc	r0
   48F7 86 06              1855 	mov	ar6,@r0
                           1856 ;	genPointerSet
                           1857 ;	genGenPointerSet
   48F9 8C 82              1858 	mov	dpl,r4
   48FB 8D 83              1859 	mov	dph,r5
   48FD 8E F0              1860 	mov	b,r6
   48FF EA                 1861 	mov	a,r2
   4900 12 DF B7           1862 	lcall	__gptrput
   4903 A3                 1863 	inc	dptr
   4904 EB                 1864 	mov	a,r3
   4905 12 DF B7           1865 	lcall	__gptrput
                           1866 ;	../../Common/socket.c:269: return pdTRUE;
                           1867 ;	genRet
   4908 75 82 01           1868 	mov	dpl,#0x01
   490B                    1869 00115$:
   490B 85 10 81           1870 	mov	sp,_bp
   490E D0 10              1871 	pop	_bp
   4910 22                 1872 	ret
                           1873 ;------------------------------------------------------------
                           1874 ;Allocation info for local variables in function 'socket_id_find'
                           1875 ;------------------------------------------------------------
                           1876 ;si                        Allocated to registers r2 r3 r4 
                           1877 ;i                         Allocated to registers r5 
                           1878 ;------------------------------------------------------------
                           1879 ;	../../Common/socket.c:281: int8_t socket_id_find(socket_t * si)
                           1880 ;	-----------------------------------------
                           1881 ;	 function socket_id_find
                           1882 ;	-----------------------------------------
   4911                    1883 _socket_id_find:
                           1884 ;	genReceive
   4911 AA 82              1885 	mov	r2,dpl
   4913 AB 83              1886 	mov	r3,dph
   4915 AC F0              1887 	mov	r4,b
                           1888 ;	../../Common/socket.c:285: for (i = 0; i < SOCKETS_MAX; i++)
                           1889 ;	genAssign
   4917 7D 00              1890 	mov	r5,#0x00
   4919                    1891 00103$:
                           1892 ;	genCmpLt
                           1893 ;	genCmp
   4919 BD 04 00           1894 	cjne	r5,#0x04,00116$
   491C                    1895 00116$:
                           1896 ;	genIfxJump
                           1897 ;	Peephole 108.a	removed ljmp by inverse jump logic
   491C 50 1F              1898 	jnc	00106$
                           1899 ;	Peephole 300	removed redundant label 00117$
                           1900 ;	../../Common/socket.c:287: if ( si == &(sockets[i]) ) break;
                           1901 ;	genMult
                           1902 ;	genMultOneByte
   491E ED                 1903 	mov	a,r5
   491F 75 F0 18           1904 	mov	b,#0x18
   4922 A4                 1905 	mul	ab
                           1906 ;	genPlus
   4923 24 58              1907 	add	a,#_sockets
   4925 FE                 1908 	mov	r6,a
                           1909 ;	Peephole 240	use clr instead of addc a,#0
   4926 E4                 1910 	clr	a
   4927 34 EF              1911 	addc	a,#(_sockets >> 8)
   4929 FF                 1912 	mov	r7,a
                           1913 ;	genCast
   492A 78 00              1914 	mov	r0,#0x0
                           1915 ;	genCmpEq
                           1916 ;	gencjneshort
   492C EA                 1917 	mov	a,r2
   492D B5 06 0A           1918 	cjne	a,ar6,00118$
   4930 EB                 1919 	mov	a,r3
   4931 B5 07 06           1920 	cjne	a,ar7,00118$
   4934 EC                 1921 	mov	a,r4
   4935 B5 00 02           1922 	cjne	a,ar0,00118$
                           1923 ;	Peephole 112.b	changed ljmp to sjmp
   4938 80 03              1924 	sjmp	00106$
   493A                    1925 00118$:
                           1926 ;	../../Common/socket.c:285: for (i = 0; i < SOCKETS_MAX; i++)
                           1927 ;	genPlus
                           1928 ;     genPlusIncr
   493A 0D                 1929 	inc	r5
                           1930 ;	Peephole 112.b	changed ljmp to sjmp
   493B 80 DC              1931 	sjmp	00103$
   493D                    1932 00106$:
                           1933 ;	../../Common/socket.c:289: if (i < SOCKETS_MAX)
                           1934 ;	genCmpLt
                           1935 ;	genCmp
   493D BD 04 00           1936 	cjne	r5,#0x04,00119$
   4940                    1937 00119$:
                           1938 ;	genIfxJump
                           1939 ;	Peephole 108.a	removed ljmp by inverse jump logic
   4940 50 03              1940 	jnc	00108$
                           1941 ;	Peephole 300	removed redundant label 00120$
                           1942 ;	../../Common/socket.c:291: return i;
                           1943 ;	genRet
   4942 8D 82              1944 	mov	dpl,r5
                           1945 ;	Peephole 112.b	changed ljmp to sjmp
                           1946 ;	../../Common/socket.c:293: return -1;
                           1947 ;	genRet
                           1948 ;	Peephole 237.a	removed sjmp to ret
   4944 22                 1949 	ret
   4945                    1950 00108$:
   4945 75 82 FF           1951 	mov	dpl,#0xFF
                           1952 ;	Peephole 300	removed redundant label 00109$
   4948 22                 1953 	ret
                           1954 ;------------------------------------------------------------
                           1955 ;Allocation info for local variables in function 'socket_find'
                           1956 ;------------------------------------------------------------
                           1957 ;sa                        Allocated to stack - offset -5
                           1958 ;port                      Allocated to stack - offset 1
                           1959 ;i                         Allocated to stack - offset 3
                           1960 ;sp                        Allocated to stack - offset 4
                           1961 ;addr_size                 Allocated to stack - offset 7
                           1962 ;sloc0                     Allocated to stack - offset 8
                           1963 ;sloc1                     Allocated to stack - offset 11
                           1964 ;sloc2                     Allocated to stack - offset 13
                           1965 ;sloc3                     Allocated to stack - offset 15
                           1966 ;------------------------------------------------------------
                           1967 ;	../../Common/socket.c:305: socket_t *socket_find (uint16_t port, sockaddr_t *sa)             /* Port to check */
                           1968 ;	-----------------------------------------
                           1969 ;	 function socket_find
                           1970 ;	-----------------------------------------
   4949                    1971 _socket_find:
   4949 C0 10              1972 	push	_bp
   494B 85 81 10           1973 	mov	_bp,sp
                           1974 ;     genReceive
   494E C0 82              1975 	push	dpl
   4950 C0 83              1976 	push	dph
   4952 E5 81              1977 	mov	a,sp
   4954 24 11              1978 	add	a,#0x11
   4956 F5 81              1979 	mov	sp,a
                           1980 ;	../../Common/socket.c:308: socket_t *sp = 0;
                           1981 ;	genAssign
   4958 E5 10              1982 	mov	a,_bp
   495A 24 04              1983 	add	a,#0x04
   495C F8                 1984 	mov	r0,a
   495D E4                 1985 	clr	a
   495E F6                 1986 	mov	@r0,a
   495F 08                 1987 	inc	r0
   4960 F6                 1988 	mov	@r0,a
   4961 08                 1989 	inc	r0
   4962 F6                 1990 	mov	@r0,a
                           1991 ;	../../Common/socket.c:311: if ((sa->port == 0) || (port == 0)) return 0;
                           1992 ;	genAssign
   4963 E5 10              1993 	mov	a,_bp
   4965 24 FB              1994 	add	a,#0xfffffffb
   4967 F8                 1995 	mov	r0,a
   4968 86 07              1996 	mov	ar7,@r0
   496A 08                 1997 	inc	r0
   496B 86 04              1998 	mov	ar4,@r0
   496D 08                 1999 	inc	r0
   496E 86 05              2000 	mov	ar5,@r0
                           2001 ;	genPlus
   4970 E5 10              2002 	mov	a,_bp
   4972 24 08              2003 	add	a,#0x08
   4974 F8                 2004 	mov	r0,a
                           2005 ;     genPlusIncr
   4975 74 0B              2006 	mov	a,#0x0B
                           2007 ;	Peephole 236.a	used r7 instead of ar7
   4977 2F                 2008 	add	a,r7
   4978 F6                 2009 	mov	@r0,a
                           2010 ;	Peephole 181	changed mov to clr
   4979 E4                 2011 	clr	a
                           2012 ;	Peephole 236.b	used r4 instead of ar4
   497A 3C                 2013 	addc	a,r4
   497B 08                 2014 	inc	r0
   497C F6                 2015 	mov	@r0,a
   497D 08                 2016 	inc	r0
   497E A6 05              2017 	mov	@r0,ar5
                           2018 ;	genPointerGet
                           2019 ;	genGenPointerGet
   4980 E5 10              2020 	mov	a,_bp
   4982 24 08              2021 	add	a,#0x08
   4984 F8                 2022 	mov	r0,a
   4985 86 82              2023 	mov	dpl,@r0
   4987 08                 2024 	inc	r0
   4988 86 83              2025 	mov	dph,@r0
   498A 08                 2026 	inc	r0
   498B 86 F0              2027 	mov	b,@r0
   498D 12 E4 9F           2028 	lcall	__gptrget
   4990 FE                 2029 	mov	r6,a
   4991 A3                 2030 	inc	dptr
   4992 12 E4 9F           2031 	lcall	__gptrget
                           2032 ;	genIfx
   4995 FA                 2033 	mov	r2,a
                           2034 ;	Peephole 135	removed redundant mov
   4996 4E                 2035 	orl	a,r6
                           2036 ;	genIfxJump
                           2037 ;	Peephole 108.c	removed ljmp by inverse jump logic
   4997 60 08              2038 	jz	00101$
                           2039 ;	Peephole 300	removed redundant label 00143$
                           2040 ;	genIfx
   4999 A8 10              2041 	mov	r0,_bp
   499B 08                 2042 	inc	r0
   499C E6                 2043 	mov	a,@r0
   499D 08                 2044 	inc	r0
   499E 46                 2045 	orl	a,@r0
                           2046 ;	genIfxJump
                           2047 ;	Peephole 108.b	removed ljmp by inverse jump logic
   499F 70 09              2048 	jnz	00102$
                           2049 ;	Peephole 300	removed redundant label 00144$
   49A1                    2050 00101$:
                           2051 ;	genRet
                           2052 ;	Peephole 182.b	used 16 bit load of dptr
   49A1 90 00 00           2053 	mov	dptr,#0x0000
   49A4 75 F0 00           2054 	mov	b,#0x00
   49A7 02 4B A9           2055 	ljmp	00130$
   49AA                    2056 00102$:
                           2057 ;	../../Common/socket.c:313: switch (sa->addr_type)
                           2058 ;	genPointerGet
                           2059 ;	genGenPointerGet
   49AA 8F 82              2060 	mov	dpl,r7
   49AC 8C 83              2061 	mov	dph,r4
   49AE 8D F0              2062 	mov	b,r5
   49B0 12 E4 9F           2063 	lcall	__gptrget
                           2064 ;	genCmpGt
                           2065 ;	genCmp
                           2066 ;	genIfxJump
                           2067 ;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
   49B3 FA                 2068 	mov  r2,a
                           2069 ;	Peephole 177.a	removed redundant mov
   49B4 24 FB              2070 	add	a,#0xff - 0x04
                           2071 ;	Peephole 112.b	changed ljmp to sjmp
                           2072 ;	Peephole 160.a	removed sjmp by inverse jump logic
   49B6 40 37              2073 	jc	00109$
                           2074 ;	Peephole 300	removed redundant label 00145$
                           2075 ;	genJumpTab
   49B8 EA                 2076 	mov	a,r2
                           2077 ;	Peephole 254	optimized left shift
   49B9 2A                 2078 	add	a,r2
   49BA 2A                 2079 	add	a,r2
   49BB 90 49 BF           2080 	mov	dptr,#00146$
   49BE 73                 2081 	jmp	@a+dptr
   49BF                    2082 00146$:
   49BF 02 49 EF           2083 	ljmp	00108$
   49C2 02 49 D4           2084 	ljmp	00105$
   49C5 02 49 E6           2085 	ljmp	00107$
   49C8 02 49 DD           2086 	ljmp	00106$
                           2087 ;	../../Common/socket.c:315: case ADDR_802_15_4_PAN_LONG:
                           2088 ;	Peephole 107	removed redundant ljmp
                           2089 ;	Peephole 300	removed redundant label 00104$
                           2090 ;	../../Common/socket.c:316: addr_size = 8;
                           2091 ;	genAssign
   49CB E5 10              2092 	mov	a,_bp
   49CD 24 07              2093 	add	a,#0x07
   49CF F8                 2094 	mov	r0,a
   49D0 76 08              2095 	mov	@r0,#0x08
                           2096 ;	../../Common/socket.c:317: break;
                           2097 ;	../../Common/socket.c:318: case ADDR_802_15_4_LONG:
                           2098 ;	Peephole 112.b	changed ljmp to sjmp
   49D2 80 22              2099 	sjmp	00110$
   49D4                    2100 00105$:
                           2101 ;	../../Common/socket.c:319: addr_size = 8;
                           2102 ;	genAssign
   49D4 E5 10              2103 	mov	a,_bp
   49D6 24 07              2104 	add	a,#0x07
   49D8 F8                 2105 	mov	r0,a
   49D9 76 08              2106 	mov	@r0,#0x08
                           2107 ;	../../Common/socket.c:320: break;
                           2108 ;	../../Common/socket.c:321: case ADDR_802_15_4_PAN_SHORT:
                           2109 ;	Peephole 112.b	changed ljmp to sjmp
   49DB 80 19              2110 	sjmp	00110$
   49DD                    2111 00106$:
                           2112 ;	../../Common/socket.c:322: addr_size = 4;
                           2113 ;	genAssign
   49DD E5 10              2114 	mov	a,_bp
   49DF 24 07              2115 	add	a,#0x07
   49E1 F8                 2116 	mov	r0,a
   49E2 76 04              2117 	mov	@r0,#0x04
                           2118 ;	../../Common/socket.c:323: break;
                           2119 ;	../../Common/socket.c:324: case ADDR_802_15_4_SHORT:
                           2120 ;	Peephole 112.b	changed ljmp to sjmp
   49E4 80 10              2121 	sjmp	00110$
   49E6                    2122 00107$:
                           2123 ;	../../Common/socket.c:325: addr_size = 2;
                           2124 ;	genAssign
   49E6 E5 10              2125 	mov	a,_bp
   49E8 24 07              2126 	add	a,#0x07
   49EA F8                 2127 	mov	r0,a
   49EB 76 02              2128 	mov	@r0,#0x02
                           2129 ;	../../Common/socket.c:326: break;
                           2130 ;	../../Common/socket.c:327: case ADDR_NONE:
                           2131 ;	Peephole 112.b	changed ljmp to sjmp
   49ED 80 07              2132 	sjmp	00110$
   49EF                    2133 00108$:
                           2134 ;	../../Common/socket.c:328: default:
   49EF                    2135 00109$:
                           2136 ;	../../Common/socket.c:329: addr_size = 0;
                           2137 ;	genAssign
   49EF E5 10              2138 	mov	a,_bp
   49F1 24 07              2139 	add	a,#0x07
   49F3 F8                 2140 	mov	r0,a
   49F4 76 00              2141 	mov	@r0,#0x00
                           2142 ;	../../Common/socket.c:330: }	
   49F6                    2143 00110$:
                           2144 ;	../../Common/socket.c:333: for (i = 0; i < SOCKETS_MAX; i++)
                           2145 ;	genAssign
   49F6 7B 00              2146 	mov	r3,#0x00
                           2147 ;	genAssign
   49F8 A8 10              2148 	mov	r0,_bp
   49FA 08                 2149 	inc	r0
   49FB 08                 2150 	inc	r0
   49FC 08                 2151 	inc	r0
   49FD 76 00              2152 	mov	@r0,#0x00
   49FF                    2153 00118$:
                           2154 ;	genCmpLt
   49FF A8 10              2155 	mov	r0,_bp
   4A01 08                 2156 	inc	r0
   4A02 08                 2157 	inc	r0
   4A03 08                 2158 	inc	r0
                           2159 ;	genCmp
   4A04 B6 04 00           2160 	cjne	@r0,#0x04,00147$
   4A07                    2161 00147$:
                           2162 ;	genIfxJump
   4A07 40 03              2163 	jc	00148$
   4A09 02 4B 51           2164 	ljmp	00121$
   4A0C                    2165 00148$:
                           2166 ;	../../Common/socket.c:335: if ((sockets[i].port == port))
                           2167 ;	genIpush
   4A0C C0 03              2168 	push	ar3
                           2169 ;	genMult
   4A0E A8 10              2170 	mov	r0,_bp
   4A10 08                 2171 	inc	r0
   4A11 08                 2172 	inc	r0
   4A12 08                 2173 	inc	r0
                           2174 ;	genMultOneByte
   4A13 E6                 2175 	mov	a,@r0
   4A14 75 F0 18           2176 	mov	b,#0x18
   4A17 A4                 2177 	mul	ab
                           2178 ;	genPlus
   4A18 C0 E0              2179 	push	acc
   4A1A E5 10              2180 	mov	a,_bp
   4A1C 24 0B              2181 	add	a,#0x0b
   4A1E F8                 2182 	mov	r0,a
   4A1F D0 E0              2183 	pop	acc
   4A21 24 58              2184 	add	a,#_sockets
   4A23 F6                 2185 	mov	@r0,a
                           2186 ;	Peephole 240	use clr instead of addc a,#0
   4A24 E4                 2187 	clr	a
   4A25 34 EF              2188 	addc	a,#(_sockets >> 8)
   4A27 08                 2189 	inc	r0
   4A28 F6                 2190 	mov	@r0,a
                           2191 ;	genPlus
   4A29 E5 10              2192 	mov	a,_bp
   4A2B 24 0B              2193 	add	a,#0x0b
   4A2D F8                 2194 	mov	r0,a
                           2195 ;     genPlusIncr
   4A2E 86 82              2196 	mov	dpl,@r0
   4A30 08                 2197 	inc	r0
   4A31 86 83              2198 	mov	dph,@r0
   4A33 A3                 2199 	inc	dptr
   4A34 A3                 2200 	inc	dptr
   4A35 A3                 2201 	inc	dptr
   4A36 A3                 2202 	inc	dptr
                           2203 ;	genPointerGet
                           2204 ;	genFarPointerGet
   4A37 E0                 2205 	movx	a,@dptr
   4A38 FB                 2206 	mov	r3,a
   4A39 A3                 2207 	inc	dptr
   4A3A E0                 2208 	movx	a,@dptr
   4A3B FA                 2209 	mov	r2,a
                           2210 ;	genCmpEq
   4A3C A8 10              2211 	mov	r0,_bp
   4A3E 08                 2212 	inc	r0
                           2213 ;	gencjne
                           2214 ;	gencjneshort
   4A3F E6                 2215 	mov	a,@r0
   4A40 B5 03 09           2216 	cjne	a,ar3,00149$
   4A43 08                 2217 	inc	r0
   4A44 E6                 2218 	mov	a,@r0
   4A45 B5 02 04           2219 	cjne	a,ar2,00149$
   4A48 74 01              2220 	mov	a,#0x01
   4A4A 80 01              2221 	sjmp	00150$
   4A4C                    2222 00149$:
   4A4C E4                 2223 	clr	a
   4A4D                    2224 00150$:
                           2225 ;	genIpop
   4A4D D0 03              2226 	pop	ar3
                           2227 ;	genIfx
                           2228 ;	genIfxJump
   4A4F 70 03              2229 	jnz	00151$
   4A51 02 4B 41           2230 	ljmp	00120$
   4A54                    2231 00151$:
                           2232 ;	../../Common/socket.c:337: if(sockets[i].sa.port == sa->port)
                           2233 ;	genIpush
   4A54 C0 03              2234 	push	ar3
                           2235 ;	genPlus
   4A56 E5 10              2236 	mov	a,_bp
   4A58 24 0B              2237 	add	a,#0x0b
   4A5A F8                 2238 	mov	r0,a
                           2239 ;     genPlusIncr
   4A5B 74 06              2240 	mov	a,#0x06
   4A5D 26                 2241 	add	a,@r0
   4A5E F6                 2242 	mov	@r0,a
                           2243 ;	Peephole 181	changed mov to clr
   4A5F E4                 2244 	clr	a
   4A60 08                 2245 	inc	r0
   4A61 36                 2246 	addc	a,@r0
   4A62 F6                 2247 	mov	@r0,a
                           2248 ;	genPlus
   4A63 E5 10              2249 	mov	a,_bp
   4A65 24 0B              2250 	add	a,#0x0b
   4A67 F8                 2251 	mov	r0,a
                           2252 ;     genPlusIncr
   4A68 74 0B              2253 	mov	a,#0x0B
   4A6A 26                 2254 	add	a,@r0
   4A6B F5 82              2255 	mov	dpl,a
                           2256 ;	Peephole 181	changed mov to clr
   4A6D E4                 2257 	clr	a
   4A6E 08                 2258 	inc	r0
   4A6F 36                 2259 	addc	a,@r0
   4A70 F5 83              2260 	mov	dph,a
                           2261 ;	genPointerGet
                           2262 ;	genFarPointerGet
   4A72 E5 10              2263 	mov	a,_bp
   4A74 24 0D              2264 	add	a,#0x0d
   4A76 F8                 2265 	mov	r0,a
   4A77 E0                 2266 	movx	a,@dptr
   4A78 F6                 2267 	mov	@r0,a
   4A79 A3                 2268 	inc	dptr
   4A7A E0                 2269 	movx	a,@dptr
   4A7B 08                 2270 	inc	r0
   4A7C F6                 2271 	mov	@r0,a
                           2272 ;	genPointerGet
                           2273 ;	genGenPointerGet
   4A7D E5 10              2274 	mov	a,_bp
   4A7F 24 08              2275 	add	a,#0x08
   4A81 F8                 2276 	mov	r0,a
   4A82 86 82              2277 	mov	dpl,@r0
   4A84 08                 2278 	inc	r0
   4A85 86 83              2279 	mov	dph,@r0
   4A87 08                 2280 	inc	r0
   4A88 86 F0              2281 	mov	b,@r0
   4A8A 12 E4 9F           2282 	lcall	__gptrget
   4A8D FE                 2283 	mov	r6,a
   4A8E A3                 2284 	inc	dptr
   4A8F 12 E4 9F           2285 	lcall	__gptrget
   4A92 FA                 2286 	mov	r2,a
                           2287 ;	genCmpEq
   4A93 E5 10              2288 	mov	a,_bp
   4A95 24 0D              2289 	add	a,#0x0d
   4A97 F8                 2290 	mov	r0,a
                           2291 ;	gencjne
                           2292 ;	gencjneshort
   4A98 E6                 2293 	mov	a,@r0
   4A99 B5 06 09           2294 	cjne	a,ar6,00152$
   4A9C 08                 2295 	inc	r0
   4A9D E6                 2296 	mov	a,@r0
   4A9E B5 02 04           2297 	cjne	a,ar2,00152$
   4AA1 74 01              2298 	mov	a,#0x01
   4AA3 80 01              2299 	sjmp	00153$
   4AA5                    2300 00152$:
   4AA5 E4                 2301 	clr	a
   4AA6                    2302 00153$:
                           2303 ;	genIpop
   4AA6 D0 03              2304 	pop	ar3
                           2305 ;	genIfx
                           2306 ;	genIfxJump
   4AA8 70 03              2307 	jnz	00154$
   4AAA 02 4B 41           2308 	ljmp	00120$
   4AAD                    2309 00154$:
                           2310 ;	../../Common/socket.c:342: if ( (addr_size == 0) || (memcmp(sockets[i].sa.address, sa->address, addr_size) == 0) )
                           2311 ;	genIfx
   4AAD E5 10              2312 	mov	a,_bp
   4AAF 24 07              2313 	add	a,#0x07
   4AB1 F8                 2314 	mov	r0,a
   4AB2 E6                 2315 	mov	a,@r0
                           2316 ;	genIfxJump
                           2317 ;	Peephole 108.c	removed ljmp by inverse jump logic
   4AB3 60 71              2318 	jz	00111$
                           2319 ;	Peephole 300	removed redundant label 00155$
                           2320 ;	genIpush
   4AB5 C0 03              2321 	push	ar3
                           2322 ;	genCast
   4AB7 E5 10              2323 	mov	a,_bp
   4AB9 24 07              2324 	add	a,#0x07
   4ABB F8                 2325 	mov	r0,a
   4ABC E5 10              2326 	mov	a,_bp
   4ABE 24 0D              2327 	add	a,#0x0d
   4AC0 F9                 2328 	mov	r1,a
   4AC1 E6                 2329 	mov	a,@r0
   4AC2 F7                 2330 	mov	@r1,a
   4AC3 09                 2331 	inc	r1
   4AC4 77 00              2332 	mov	@r1,#0x00
                           2333 ;	genPlus
   4AC6 E5 10              2334 	mov	a,_bp
   4AC8 24 0F              2335 	add	a,#0x0f
   4ACA F8                 2336 	mov	r0,a
                           2337 ;     genPlusIncr
   4ACB 74 01              2338 	mov	a,#0x01
                           2339 ;	Peephole 236.a	used r7 instead of ar7
   4ACD 2F                 2340 	add	a,r7
   4ACE F6                 2341 	mov	@r0,a
                           2342 ;	Peephole 181	changed mov to clr
   4ACF E4                 2343 	clr	a
                           2344 ;	Peephole 236.b	used r4 instead of ar4
   4AD0 3C                 2345 	addc	a,r4
   4AD1 08                 2346 	inc	r0
   4AD2 F6                 2347 	mov	@r0,a
   4AD3 08                 2348 	inc	r0
   4AD4 A6 05              2349 	mov	@r0,ar5
                           2350 ;	genPlus
   4AD6 E5 10              2351 	mov	a,_bp
   4AD8 24 0B              2352 	add	a,#0x0b
   4ADA F8                 2353 	mov	r0,a
                           2354 ;     genPlusIncr
   4ADB 74 01              2355 	mov	a,#0x01
   4ADD 26                 2356 	add	a,@r0
   4ADE FA                 2357 	mov	r2,a
                           2358 ;	Peephole 181	changed mov to clr
   4ADF E4                 2359 	clr	a
   4AE0 08                 2360 	inc	r0
   4AE1 36                 2361 	addc	a,@r0
   4AE2 FB                 2362 	mov	r3,a
                           2363 ;	genCast
   4AE3 7E 00              2364 	mov	r6,#0x0
                           2365 ;	genIpush
   4AE5 C0 04              2366 	push	ar4
   4AE7 C0 05              2367 	push	ar5
   4AE9 C0 07              2368 	push	ar7
   4AEB E5 10              2369 	mov	a,_bp
   4AED 24 0D              2370 	add	a,#0x0d
   4AEF F8                 2371 	mov	r0,a
   4AF0 E6                 2372 	mov	a,@r0
   4AF1 C0 E0              2373 	push	acc
   4AF3 08                 2374 	inc	r0
   4AF4 E6                 2375 	mov	a,@r0
   4AF5 C0 E0              2376 	push	acc
                           2377 ;	genIpush
   4AF7 E5 10              2378 	mov	a,_bp
   4AF9 24 0F              2379 	add	a,#0x0f
   4AFB F8                 2380 	mov	r0,a
   4AFC E6                 2381 	mov	a,@r0
   4AFD C0 E0              2382 	push	acc
   4AFF 08                 2383 	inc	r0
   4B00 E6                 2384 	mov	a,@r0
   4B01 C0 E0              2385 	push	acc
   4B03 08                 2386 	inc	r0
   4B04 E6                 2387 	mov	a,@r0
   4B05 C0 E0              2388 	push	acc
                           2389 ;	genCall
   4B07 8A 82              2390 	mov	dpl,r2
   4B09 8B 83              2391 	mov	dph,r3
   4B0B 8E F0              2392 	mov	b,r6
   4B0D 12 E2 0A           2393 	lcall	_memcmp
   4B10 AA 82              2394 	mov	r2,dpl
   4B12 AB 83              2395 	mov	r3,dph
   4B14 E5 81              2396 	mov	a,sp
   4B16 24 FB              2397 	add	a,#0xfb
   4B18 F5 81              2398 	mov	sp,a
   4B1A D0 07              2399 	pop	ar7
   4B1C D0 05              2400 	pop	ar5
   4B1E D0 04              2401 	pop	ar4
                           2402 ;	genIfx
   4B20 EA                 2403 	mov	a,r2
   4B21 4B                 2404 	orl	a,r3
                           2405 ;	genIpop
   4B22 D0 03              2406 	pop	ar3
                           2407 ;	genIfxJump
                           2408 ;	Peephole 108.b	removed ljmp by inverse jump logic
   4B24 70 1B              2409 	jnz	00120$
                           2410 ;	Peephole 300	removed redundant label 00156$
   4B26                    2411 00111$:
                           2412 ;	../../Common/socket.c:343: { sp = ((socket_t *) &sockets[i]);
                           2413 ;	genMult
                           2414 ;	genMultOneByte
   4B26 EB                 2415 	mov	a,r3
   4B27 75 F0 18           2416 	mov	b,#0x18
   4B2A A4                 2417 	mul	ab
                           2418 ;	genPlus
   4B2B 24 58              2419 	add	a,#_sockets
   4B2D FA                 2420 	mov	r2,a
                           2421 ;	Peephole 240	use clr instead of addc a,#0
   4B2E E4                 2422 	clr	a
   4B2F 34 EF              2423 	addc	a,#(_sockets >> 8)
   4B31 FE                 2424 	mov	r6,a
                           2425 ;	genCast
   4B32 E5 10              2426 	mov	a,_bp
   4B34 24 04              2427 	add	a,#0x04
   4B36 F8                 2428 	mov	r0,a
   4B37 A6 02              2429 	mov	@r0,ar2
   4B39 08                 2430 	inc	r0
   4B3A A6 06              2431 	mov	@r0,ar6
   4B3C 08                 2432 	inc	r0
   4B3D 76 00              2433 	mov	@r0,#0x0
                           2434 ;	../../Common/socket.c:347: break;
                           2435 ;	Peephole 112.b	changed ljmp to sjmp
   4B3F 80 10              2436 	sjmp	00121$
   4B41                    2437 00120$:
                           2438 ;	../../Common/socket.c:333: for (i = 0; i < SOCKETS_MAX; i++)
                           2439 ;	genPlus
   4B41 A8 10              2440 	mov	r0,_bp
   4B43 08                 2441 	inc	r0
   4B44 08                 2442 	inc	r0
   4B45 08                 2443 	inc	r0
                           2444 ;     genPlusIncr
   4B46 06                 2445 	inc	@r0
                           2446 ;	genAssign
   4B47 A8 10              2447 	mov	r0,_bp
   4B49 08                 2448 	inc	r0
   4B4A 08                 2449 	inc	r0
   4B4B 08                 2450 	inc	r0
   4B4C 86 03              2451 	mov	ar3,@r0
   4B4E 02 49 FF           2452 	ljmp	00118$
   4B51                    2453 00121$:
                           2454 ;	../../Common/socket.c:354: if (sp == 0)
                           2455 ;	genIfx
   4B51 E5 10              2456 	mov	a,_bp
   4B53 24 04              2457 	add	a,#0x04
   4B55 F8                 2458 	mov	r0,a
   4B56 E6                 2459 	mov	a,@r0
   4B57 08                 2460 	inc	r0
   4B58 46                 2461 	orl	a,@r0
   4B59 08                 2462 	inc	r0
   4B5A 46                 2463 	orl	a,@r0
                           2464 ;	genIfxJump
                           2465 ;	Peephole 108.b	removed ljmp by inverse jump logic
                           2466 ;	../../Common/socket.c:356: for (i = 0; i < SOCKETS_MAX; i++)
                           2467 ;	genAssign
   4B5B 70 3F              2468 	jnz	00129$
                           2469 ;	Peephole 300	removed redundant label 00157$
                           2470 ;	Peephole 256.c	loading r2 with zero from a
   4B5D FA                 2471 	mov	r2,a
   4B5E                    2472 00124$:
                           2473 ;	genCmpLt
                           2474 ;	genCmp
   4B5E BA 04 00           2475 	cjne	r2,#0x04,00158$
   4B61                    2476 00158$:
                           2477 ;	genIfxJump
                           2478 ;	Peephole 108.a	removed ljmp by inverse jump logic
   4B61 50 39              2479 	jnc	00129$
                           2480 ;	Peephole 300	removed redundant label 00159$
                           2481 ;	../../Common/socket.c:358: if ((sockets[i].listen == port) )
                           2482 ;	genMult
                           2483 ;	genMultOneByte
   4B63 EA                 2484 	mov	a,r2
   4B64 75 F0 18           2485 	mov	b,#0x18
   4B67 A4                 2486 	mul	ab
                           2487 ;	genPlus
   4B68 24 58              2488 	add	a,#_sockets
   4B6A FB                 2489 	mov	r3,a
                           2490 ;	Peephole 240	use clr instead of addc a,#0
   4B6B E4                 2491 	clr	a
   4B6C 34 EF              2492 	addc	a,#(_sockets >> 8)
   4B6E FC                 2493 	mov	r4,a
                           2494 ;	genPlus
                           2495 ;     genPlusIncr
   4B6F 8B 82              2496 	mov	dpl,r3
   4B71 8C 83              2497 	mov	dph,r4
   4B73 A3                 2498 	inc	dptr
   4B74 A3                 2499 	inc	dptr
                           2500 ;	genPointerGet
                           2501 ;	genFarPointerGet
   4B75 E0                 2502 	movx	a,@dptr
   4B76 FD                 2503 	mov	r5,a
   4B77 A3                 2504 	inc	dptr
   4B78 E0                 2505 	movx	a,@dptr
   4B79 FE                 2506 	mov	r6,a
                           2507 ;	genCmpEq
   4B7A A8 10              2508 	mov	r0,_bp
   4B7C 08                 2509 	inc	r0
                           2510 ;	gencjneshort
   4B7D E6                 2511 	mov	a,@r0
   4B7E B5 05 07           2512 	cjne	a,ar5,00160$
   4B81 08                 2513 	inc	r0
   4B82 E6                 2514 	mov	a,@r0
   4B83 B5 06 02           2515 	cjne	a,ar6,00160$
   4B86 80 02              2516 	sjmp	00161$
   4B88                    2517 00160$:
                           2518 ;	Peephole 112.b	changed ljmp to sjmp
   4B88 80 0F              2519 	sjmp	00126$
   4B8A                    2520 00161$:
                           2521 ;	../../Common/socket.c:359: { sp = ((socket_t *) &sockets[i]);
                           2522 ;	genAssign
                           2523 ;	genCast
   4B8A E5 10              2524 	mov	a,_bp
   4B8C 24 04              2525 	add	a,#0x04
   4B8E F8                 2526 	mov	r0,a
   4B8F A6 03              2527 	mov	@r0,ar3
   4B91 08                 2528 	inc	r0
   4B92 A6 04              2529 	mov	@r0,ar4
   4B94 08                 2530 	inc	r0
   4B95 76 00              2531 	mov	@r0,#0x0
                           2532 ;	../../Common/socket.c:360: break;
                           2533 ;	Peephole 112.b	changed ljmp to sjmp
   4B97 80 03              2534 	sjmp	00129$
   4B99                    2535 00126$:
                           2536 ;	../../Common/socket.c:356: for (i = 0; i < SOCKETS_MAX; i++)
                           2537 ;	genPlus
                           2538 ;     genPlusIncr
   4B99 0A                 2539 	inc	r2
                           2540 ;	Peephole 112.b	changed ljmp to sjmp
   4B9A 80 C2              2541 	sjmp	00124$
   4B9C                    2542 00129$:
                           2543 ;	../../Common/socket.c:371: return sp;
                           2544 ;	genRet
   4B9C E5 10              2545 	mov	a,_bp
   4B9E 24 04              2546 	add	a,#0x04
   4BA0 F8                 2547 	mov	r0,a
   4BA1 86 82              2548 	mov	dpl,@r0
   4BA3 08                 2549 	inc	r0
   4BA4 86 83              2550 	mov	dph,@r0
   4BA6 08                 2551 	inc	r0
   4BA7 86 F0              2552 	mov	b,@r0
   4BA9                    2553 00130$:
   4BA9 85 10 81           2554 	mov	sp,_bp
   4BAC D0 10              2555 	pop	_bp
   4BAE 22                 2556 	ret
                           2557 ;------------------------------------------------------------
                           2558 ;Allocation info for local variables in function 'socket_buffer_get'
                           2559 ;------------------------------------------------------------
                           2560 ;si                        Allocated to stack - offset 1
                           2561 ;buffer                    Allocated to stack - offset 4
                           2562 ;i                         Allocated to registers r2 
                           2563 ;ptr                       Allocated to stack - offset 7
                           2564 ;------------------------------------------------------------
                           2565 ;	../../Common/socket.c:381: buffer_t *socket_buffer_get(socket_t * si) 
                           2566 ;	-----------------------------------------
                           2567 ;	 function socket_buffer_get
                           2568 ;	-----------------------------------------
   4BAF                    2569 _socket_buffer_get:
   4BAF C0 10              2570 	push	_bp
   4BB1 85 81 10           2571 	mov	_bp,sp
                           2572 ;     genReceive
   4BB4 C0 82              2573 	push	dpl
   4BB6 C0 83              2574 	push	dph
   4BB8 C0 F0              2575 	push	b
   4BBA E5 81              2576 	mov	a,sp
   4BBC 24 08              2577 	add	a,#0x08
   4BBE F5 81              2578 	mov	sp,a
                           2579 ;	../../Common/socket.c:387: if (/*(si->stack_id >= 0) && */(buffer=stack_buffer_get(20)) )
                           2580 ;	genCall
                           2581 ;	Peephole 182.b	used 16 bit load of dptr
   4BC0 90 00 14           2582 	mov	dptr,#0x0014
   4BC3 12 5F CD           2583 	lcall	_stack_buffer_get
   4BC6 AD 82              2584 	mov	r5,dpl
   4BC8 AE 83              2585 	mov	r6,dph
   4BCA AF F0              2586 	mov	r7,b
                           2587 ;	genAssign
   4BCC E5 10              2588 	mov	a,_bp
   4BCE 24 04              2589 	add	a,#0x04
   4BD0 F8                 2590 	mov	r0,a
   4BD1 A6 05              2591 	mov	@r0,ar5
   4BD3 08                 2592 	inc	r0
   4BD4 A6 06              2593 	mov	@r0,ar6
   4BD6 08                 2594 	inc	r0
   4BD7 A6 07              2595 	mov	@r0,ar7
                           2596 ;	genIfx
   4BD9 ED                 2597 	mov	a,r5
   4BDA 4E                 2598 	orl	a,r6
   4BDB 4F                 2599 	orl	a,r7
                           2600 ;	genIfxJump
   4BDC 70 03              2601 	jnz	00113$
   4BDE 02 4D FF           2602 	ljmp	00102$
   4BE1                    2603 00113$:
                           2604 ;	../../Common/socket.c:389: buffer->socket = (void *) si;
                           2605 ;	genPointerSet
                           2606 ;	genGenPointerSet
   4BE1 E5 10              2607 	mov	a,_bp
   4BE3 24 04              2608 	add	a,#0x04
   4BE5 F8                 2609 	mov	r0,a
   4BE6 86 82              2610 	mov	dpl,@r0
   4BE8 08                 2611 	inc	r0
   4BE9 86 83              2612 	mov	dph,@r0
   4BEB 08                 2613 	inc	r0
   4BEC 86 F0              2614 	mov	b,@r0
   4BEE A9 10              2615 	mov	r1,_bp
   4BF0 09                 2616 	inc	r1
   4BF1 E7                 2617 	mov	a,@r1
   4BF2 12 DF B7           2618 	lcall	__gptrput
   4BF5 A3                 2619 	inc	dptr
   4BF6 09                 2620 	inc	r1
   4BF7 E7                 2621 	mov	a,@r1
   4BF8 12 DF B7           2622 	lcall	__gptrput
   4BFB A3                 2623 	inc	dptr
   4BFC 09                 2624 	inc	r1
   4BFD E7                 2625 	mov	a,@r1
   4BFE 12 DF B7           2626 	lcall	__gptrput
                           2627 ;	../../Common/socket.c:390: ptr = 0;
                           2628 ;	genAssign
   4C01 E5 10              2629 	mov	a,_bp
   4C03 24 07              2630 	add	a,#0x07
   4C05 F8                 2631 	mov	r0,a
   4C06 E4                 2632 	clr	a
   4C07 F6                 2633 	mov	@r0,a
   4C08 08                 2634 	inc	r0
   4C09 F6                 2635 	mov	@r0,a
                           2636 ;	../../Common/socket.c:391: for (i=0; i< stacks[si->stack_id].layers; i++)
                           2637 ;	genPlus
   4C0A A8 10              2638 	mov	r0,_bp
   4C0C 08                 2639 	inc	r0
                           2640 ;     genPlusIncr
   4C0D 74 01              2641 	mov	a,#0x01
   4C0F 26                 2642 	add	a,@r0
   4C10 FF                 2643 	mov	r7,a
                           2644 ;	Peephole 181	changed mov to clr
   4C11 E4                 2645 	clr	a
   4C12 08                 2646 	inc	r0
   4C13 36                 2647 	addc	a,@r0
   4C14 FD                 2648 	mov	r5,a
   4C15 08                 2649 	inc	r0
   4C16 86 06              2650 	mov	ar6,@r0
                           2651 ;	genAssign
   4C18 7A 00              2652 	mov	r2,#0x00
   4C1A                    2653 00103$:
                           2654 ;	genPointerGet
                           2655 ;	genGenPointerGet
   4C1A 8F 82              2656 	mov	dpl,r7
   4C1C 8D 83              2657 	mov	dph,r5
   4C1E 8E F0              2658 	mov	b,r6
   4C20 12 E4 9F           2659 	lcall	__gptrget
                           2660 ;	genMult
                           2661 ;	genMultOneByte
   4C23 FB                 2662 	mov	r3,a
                           2663 ;	Peephole 105	removed redundant mov
   4C24 75 F0 05           2664 	mov	b,#0x05
   4C27 A4                 2665 	mul	ab
   4C28 FB                 2666 	mov	r3,a
   4C29 AC F0              2667 	mov	r4,b
                           2668 ;	genPlus
                           2669 ;	Peephole 236.g	used r3 instead of ar3
   4C2B EB                 2670 	mov	a,r3
   4C2C 24 DD              2671 	add	a,#_stacks
   4C2E F5 82              2672 	mov	dpl,a
                           2673 ;	Peephole 236.g	used r4 instead of ar4
   4C30 EC                 2674 	mov	a,r4
   4C31 34 F0              2675 	addc	a,#(_stacks >> 8)
   4C33 F5 83              2676 	mov	dph,a
                           2677 ;	genIpush
   4C35 C0 07              2678 	push	ar7
   4C37 C0 05              2679 	push	ar5
   4C39 C0 06              2680 	push	ar6
                           2681 ;	genPointerGet
                           2682 ;	genFarPointerGet
   4C3B E0                 2683 	movx	a,@dptr
   4C3C FD                 2684 	mov	r5,a
                           2685 ;	genCmpLt
                           2686 ;	genCmp
   4C3D C3                 2687 	clr	c
   4C3E EA                 2688 	mov	a,r2
   4C3F 9D                 2689 	subb	a,r5
   4C40 E4                 2690 	clr	a
   4C41 33                 2691 	rlc	a
                           2692 ;	genIpop
   4C42 D0 06              2693 	pop	ar6
   4C44 D0 05              2694 	pop	ar5
   4C46 D0 07              2695 	pop	ar7
                           2696 ;	genIfx
                           2697 ;	genIfxJump
                           2698 ;	Peephole 108.c	removed ljmp by inverse jump logic
   4C48 60 5D              2699 	jz	00106$
                           2700 ;	Peephole 300	removed redundant label 00114$
                           2701 ;	../../Common/socket.c:393: ptr += module_get(stacks[si->stack_id].module[i])->hdr_size;
                           2702 ;	genIpush
   4C4A C0 07              2703 	push	ar7
   4C4C C0 05              2704 	push	ar5
   4C4E C0 06              2705 	push	ar6
                           2706 ;	genPlus
                           2707 ;	Peephole 236.g	used r3 instead of ar3
   4C50 EB                 2708 	mov	a,r3
   4C51 24 DD              2709 	add	a,#_stacks
   4C53 FB                 2710 	mov	r3,a
                           2711 ;	Peephole 236.g	used r4 instead of ar4
   4C54 EC                 2712 	mov	a,r4
   4C55 34 F0              2713 	addc	a,#(_stacks >> 8)
   4C57 FC                 2714 	mov	r4,a
                           2715 ;	genPlus
                           2716 ;     genPlusIncr
   4C58 0B                 2717 	inc	r3
   4C59 BB 00 01           2718 	cjne	r3,#0x00,00115$
   4C5C 0C                 2719 	inc	r4
   4C5D                    2720 00115$:
                           2721 ;	genPlus
                           2722 ;	Peephole 236.g	used r2 instead of ar2
   4C5D EA                 2723 	mov	a,r2
                           2724 ;	Peephole 236.a	used r3 instead of ar3
   4C5E 2B                 2725 	add	a,r3
   4C5F F5 82              2726 	mov	dpl,a
                           2727 ;	Peephole 181	changed mov to clr
   4C61 E4                 2728 	clr	a
                           2729 ;	Peephole 236.b	used r4 instead of ar4
   4C62 3C                 2730 	addc	a,r4
   4C63 F5 83              2731 	mov	dph,a
                           2732 ;	genPointerGet
                           2733 ;	genFarPointerGet
   4C65 E0                 2734 	movx	a,@dptr
                           2735 ;	genCall
   4C66 FB                 2736 	mov	r3,a
                           2737 ;	Peephole 244.c	loading dpl from a instead of r3
   4C67 F5 82              2738 	mov	dpl,a
   4C69 C0 02              2739 	push	ar2
   4C6B C0 06              2740 	push	ar6
   4C6D C0 07              2741 	push	ar7
   4C6F 12 43 31           2742 	lcall	_module_get
   4C72 AB 82              2743 	mov	r3,dpl
   4C74 AC 83              2744 	mov	r4,dph
   4C76 AD F0              2745 	mov	r5,b
   4C78 D0 07              2746 	pop	ar7
   4C7A D0 06              2747 	pop	ar6
   4C7C D0 02              2748 	pop	ar2
                           2749 ;	genPlus
                           2750 ;     genPlusIncr
   4C7E 74 09              2751 	mov	a,#0x09
                           2752 ;	Peephole 236.a	used r3 instead of ar3
   4C80 2B                 2753 	add	a,r3
   4C81 FB                 2754 	mov	r3,a
                           2755 ;	Peephole 181	changed mov to clr
   4C82 E4                 2756 	clr	a
                           2757 ;	Peephole 236.b	used r4 instead of ar4
   4C83 3C                 2758 	addc	a,r4
   4C84 FC                 2759 	mov	r4,a
                           2760 ;	genPointerGet
                           2761 ;	genGenPointerGet
   4C85 8B 82              2762 	mov	dpl,r3
   4C87 8C 83              2763 	mov	dph,r4
   4C89 8D F0              2764 	mov	b,r5
   4C8B 12 E4 9F           2765 	lcall	__gptrget
   4C8E FB                 2766 	mov	r3,a
                           2767 ;	genCast
   4C8F 7C 00              2768 	mov	r4,#0x00
                           2769 ;	genPlus
   4C91 E5 10              2770 	mov	a,_bp
   4C93 24 07              2771 	add	a,#0x07
   4C95 F8                 2772 	mov	r0,a
                           2773 ;	Peephole 236.g	used r3 instead of ar3
   4C96 EB                 2774 	mov	a,r3
   4C97 26                 2775 	add	a,@r0
   4C98 F6                 2776 	mov	@r0,a
                           2777 ;	Peephole 236.g	used r4 instead of ar4
   4C99 EC                 2778 	mov	a,r4
   4C9A 08                 2779 	inc	r0
   4C9B 36                 2780 	addc	a,@r0
   4C9C F6                 2781 	mov	@r0,a
                           2782 ;	../../Common/socket.c:391: for (i=0; i< stacks[si->stack_id].layers; i++)
                           2783 ;	genPlus
                           2784 ;     genPlusIncr
   4C9D 0A                 2785 	inc	r2
                           2786 ;	genIpop
   4C9E D0 06              2787 	pop	ar6
   4CA0 D0 05              2788 	pop	ar5
   4CA2 D0 07              2789 	pop	ar7
   4CA4 02 4C 1A           2790 	ljmp	00103$
   4CA7                    2791 00106$:
                           2792 ;	../../Common/socket.c:395: buffer->buf_ptr = ptr;
                           2793 ;	genPlus
   4CA7 E5 10              2794 	mov	a,_bp
   4CA9 24 04              2795 	add	a,#0x04
   4CAB F8                 2796 	mov	r0,a
                           2797 ;     genPlusIncr
   4CAC 74 20              2798 	mov	a,#0x20
   4CAE 26                 2799 	add	a,@r0
   4CAF FA                 2800 	mov	r2,a
                           2801 ;	Peephole 181	changed mov to clr
   4CB0 E4                 2802 	clr	a
   4CB1 08                 2803 	inc	r0
   4CB2 36                 2804 	addc	a,@r0
   4CB3 FB                 2805 	mov	r3,a
   4CB4 08                 2806 	inc	r0
   4CB5 86 04              2807 	mov	ar4,@r0
                           2808 ;	genPointerSet
                           2809 ;	genGenPointerSet
   4CB7 8A 82              2810 	mov	dpl,r2
   4CB9 8B 83              2811 	mov	dph,r3
   4CBB 8C F0              2812 	mov	b,r4
   4CBD E5 10              2813 	mov	a,_bp
   4CBF 24 07              2814 	add	a,#0x07
   4CC1 F8                 2815 	mov	r0,a
   4CC2 E6                 2816 	mov	a,@r0
   4CC3 12 DF B7           2817 	lcall	__gptrput
   4CC6 A3                 2818 	inc	dptr
   4CC7 08                 2819 	inc	r0
   4CC8 E6                 2820 	mov	a,@r0
   4CC9 12 DF B7           2821 	lcall	__gptrput
                           2822 ;	../../Common/socket.c:396: buffer->buf_end = ptr;
                           2823 ;	genPlus
   4CCC E5 10              2824 	mov	a,_bp
   4CCE 24 04              2825 	add	a,#0x04
   4CD0 F8                 2826 	mov	r0,a
                           2827 ;     genPlusIncr
   4CD1 74 22              2828 	mov	a,#0x22
   4CD3 26                 2829 	add	a,@r0
   4CD4 FA                 2830 	mov	r2,a
                           2831 ;	Peephole 181	changed mov to clr
   4CD5 E4                 2832 	clr	a
   4CD6 08                 2833 	inc	r0
   4CD7 36                 2834 	addc	a,@r0
   4CD8 FB                 2835 	mov	r3,a
   4CD9 08                 2836 	inc	r0
   4CDA 86 04              2837 	mov	ar4,@r0
                           2838 ;	genPointerSet
                           2839 ;	genGenPointerSet
   4CDC 8A 82              2840 	mov	dpl,r2
   4CDE 8B 83              2841 	mov	dph,r3
   4CE0 8C F0              2842 	mov	b,r4
   4CE2 E5 10              2843 	mov	a,_bp
   4CE4 24 07              2844 	add	a,#0x07
   4CE6 F8                 2845 	mov	r0,a
   4CE7 E6                 2846 	mov	a,@r0
   4CE8 12 DF B7           2847 	lcall	__gptrput
   4CEB A3                 2848 	inc	dptr
   4CEC 08                 2849 	inc	r0
   4CED E6                 2850 	mov	a,@r0
   4CEE 12 DF B7           2851 	lcall	__gptrput
                           2852 ;	../../Common/socket.c:397: buffer->from = MODULE_APP;
                           2853 ;	genPlus
   4CF1 E5 10              2854 	mov	a,_bp
   4CF3 24 04              2855 	add	a,#0x04
   4CF5 F8                 2856 	mov	r0,a
                           2857 ;     genPlusIncr
   4CF6 74 1D              2858 	mov	a,#0x1D
   4CF8 26                 2859 	add	a,@r0
   4CF9 FA                 2860 	mov	r2,a
                           2861 ;	Peephole 181	changed mov to clr
   4CFA E4                 2862 	clr	a
   4CFB 08                 2863 	inc	r0
   4CFC 36                 2864 	addc	a,@r0
   4CFD FB                 2865 	mov	r3,a
   4CFE 08                 2866 	inc	r0
   4CFF 86 04              2867 	mov	ar4,@r0
                           2868 ;	genPointerSet
                           2869 ;	genGenPointerSet
   4D01 8A 82              2870 	mov	dpl,r2
   4D03 8B 83              2871 	mov	dph,r3
   4D05 8C F0              2872 	mov	b,r4
   4D07 74 0B              2873 	mov	a,#0x0B
   4D09 12 DF B7           2874 	lcall	__gptrput
                           2875 ;	../../Common/socket.c:398: buffer->to = MODULE_NONE;
                           2876 ;	genPlus
   4D0C E5 10              2877 	mov	a,_bp
   4D0E 24 04              2878 	add	a,#0x04
   4D10 F8                 2879 	mov	r0,a
                           2880 ;     genPlusIncr
   4D11 74 1E              2881 	mov	a,#0x1E
   4D13 26                 2882 	add	a,@r0
   4D14 FA                 2883 	mov	r2,a
                           2884 ;	Peephole 181	changed mov to clr
   4D15 E4                 2885 	clr	a
   4D16 08                 2886 	inc	r0
   4D17 36                 2887 	addc	a,@r0
   4D18 FB                 2888 	mov	r3,a
   4D19 08                 2889 	inc	r0
   4D1A 86 04              2890 	mov	ar4,@r0
                           2891 ;	genPointerSet
                           2892 ;	genGenPointerSet
   4D1C 8A 82              2893 	mov	dpl,r2
   4D1E 8B 83              2894 	mov	dph,r3
   4D20 8C F0              2895 	mov	b,r4
                           2896 ;	Peephole 181	changed mov to clr
   4D22 E4                 2897 	clr	a
   4D23 12 DF B7           2898 	lcall	__gptrput
                           2899 ;	../../Common/socket.c:399: buffer->dir = BUFFER_DOWN;
                           2900 ;	genPlus
   4D26 E5 10              2901 	mov	a,_bp
   4D28 24 04              2902 	add	a,#0x04
   4D2A F8                 2903 	mov	r0,a
                           2904 ;     genPlusIncr
   4D2B 74 1F              2905 	mov	a,#0x1F
   4D2D 26                 2906 	add	a,@r0
   4D2E FA                 2907 	mov	r2,a
                           2908 ;	Peephole 181	changed mov to clr
   4D2F E4                 2909 	clr	a
   4D30 08                 2910 	inc	r0
   4D31 36                 2911 	addc	a,@r0
   4D32 FB                 2912 	mov	r3,a
   4D33 08                 2913 	inc	r0
   4D34 86 04              2914 	mov	ar4,@r0
                           2915 ;	genPointerSet
                           2916 ;	genGenPointerSet
   4D36 8A 82              2917 	mov	dpl,r2
   4D38 8B 83              2918 	mov	dph,r3
   4D3A 8C F0              2919 	mov	b,r4
   4D3C 74 01              2920 	mov	a,#0x01
   4D3E 12 DF B7           2921 	lcall	__gptrput
                           2922 ;	../../Common/socket.c:400: buffer->options.rf_dbm = 0;
                           2923 ;	genPlus
   4D41 E5 10              2924 	mov	a,_bp
   4D43 24 04              2925 	add	a,#0x04
   4D45 F8                 2926 	mov	r0,a
                           2927 ;     genPlusIncr
   4D46 74 26              2928 	mov	a,#0x26
   4D48 26                 2929 	add	a,@r0
   4D49 FA                 2930 	mov	r2,a
                           2931 ;	Peephole 181	changed mov to clr
   4D4A E4                 2932 	clr	a
   4D4B 08                 2933 	inc	r0
   4D4C 36                 2934 	addc	a,@r0
   4D4D FB                 2935 	mov	r3,a
   4D4E 08                 2936 	inc	r0
   4D4F 86 04              2937 	mov	ar4,@r0
                           2938 ;	genPlus
                           2939 ;     genPlusIncr
   4D51 74 01              2940 	mov	a,#0x01
                           2941 ;	Peephole 236.a	used r2 instead of ar2
   4D53 2A                 2942 	add	a,r2
   4D54 FD                 2943 	mov	r5,a
                           2944 ;	Peephole 181	changed mov to clr
   4D55 E4                 2945 	clr	a
                           2946 ;	Peephole 236.b	used r3 instead of ar3
   4D56 3B                 2947 	addc	a,r3
   4D57 FE                 2948 	mov	r6,a
   4D58 8C 07              2949 	mov	ar7,r4
                           2950 ;	genPointerSet
                           2951 ;	genGenPointerSet
   4D5A 8D 82              2952 	mov	dpl,r5
   4D5C 8E 83              2953 	mov	dph,r6
   4D5E 8F F0              2954 	mov	b,r7
                           2955 ;	Peephole 181	changed mov to clr
   4D60 E4                 2956 	clr	a
   4D61 12 DF B7           2957 	lcall	__gptrput
                           2958 ;	../../Common/socket.c:401: buffer->options.rf_lqi = 0;
                           2959 ;	genPlus
                           2960 ;     genPlusIncr
   4D64 74 02              2961 	mov	a,#0x02
                           2962 ;	Peephole 236.a	used r2 instead of ar2
   4D66 2A                 2963 	add	a,r2
   4D67 FD                 2964 	mov	r5,a
                           2965 ;	Peephole 181	changed mov to clr
   4D68 E4                 2966 	clr	a
                           2967 ;	Peephole 236.b	used r3 instead of ar3
   4D69 3B                 2968 	addc	a,r3
   4D6A FE                 2969 	mov	r6,a
   4D6B 8C 07              2970 	mov	ar7,r4
                           2971 ;	genPointerSet
                           2972 ;	genGenPointerSet
   4D6D 8D 82              2973 	mov	dpl,r5
   4D6F 8E 83              2974 	mov	dph,r6
   4D71 8F F0              2975 	mov	b,r7
                           2976 ;	Peephole 181	changed mov to clr
   4D73 E4                 2977 	clr	a
   4D74 12 DF B7           2978 	lcall	__gptrput
                           2979 ;	../../Common/socket.c:402: buffer->options.lowpan_compressed=0;
                           2980 ;	genPlus
                           2981 ;     genPlusIncr
   4D77 74 05              2982 	mov	a,#0x05
                           2983 ;	Peephole 236.a	used r2 instead of ar2
   4D79 2A                 2984 	add	a,r2
   4D7A FD                 2985 	mov	r5,a
                           2986 ;	Peephole 181	changed mov to clr
   4D7B E4                 2987 	clr	a
                           2988 ;	Peephole 236.b	used r3 instead of ar3
   4D7C 3B                 2989 	addc	a,r3
   4D7D FE                 2990 	mov	r6,a
   4D7E 8C 07              2991 	mov	ar7,r4
                           2992 ;	genPointerSet
                           2993 ;	genGenPointerSet
   4D80 8D 82              2994 	mov	dpl,r5
   4D82 8E 83              2995 	mov	dph,r6
   4D84 8F F0              2996 	mov	b,r7
                           2997 ;	Peephole 181	changed mov to clr
   4D86 E4                 2998 	clr	a
   4D87 12 DF B7           2999 	lcall	__gptrput
                           3000 ;	../../Common/socket.c:403: buffer->options.type = BUFFER_DATA;
                           3001 ;	genPointerSet
                           3002 ;	genGenPointerSet
   4D8A 8A 82              3003 	mov	dpl,r2
   4D8C 8B 83              3004 	mov	dph,r3
   4D8E 8C F0              3005 	mov	b,r4
                           3006 ;	Peephole 181	changed mov to clr
   4D90 E4                 3007 	clr	a
   4D91 12 DF B7           3008 	lcall	__gptrput
                           3009 ;	../../Common/socket.c:404: memcpy(&(buffer->dst_sa), &(si->sa), sizeof(sockaddr_t));
                           3010 ;	genPlus
   4D94 A8 10              3011 	mov	r0,_bp
   4D96 08                 3012 	inc	r0
                           3013 ;     genPlusIncr
   4D97 74 06              3014 	mov	a,#0x06
   4D99 26                 3015 	add	a,@r0
   4D9A FA                 3016 	mov	r2,a
                           3017 ;	Peephole 181	changed mov to clr
   4D9B E4                 3018 	clr	a
   4D9C 08                 3019 	inc	r0
   4D9D 36                 3020 	addc	a,@r0
   4D9E FB                 3021 	mov	r3,a
   4D9F 08                 3022 	inc	r0
   4DA0 86 04              3023 	mov	ar4,@r0
                           3024 ;	genPlus
   4DA2 E5 10              3025 	mov	a,_bp
   4DA4 24 04              3026 	add	a,#0x04
   4DA6 F8                 3027 	mov	r0,a
                           3028 ;     genPlusIncr
   4DA7 74 03              3029 	mov	a,#0x03
   4DA9 26                 3030 	add	a,@r0
   4DAA FD                 3031 	mov	r5,a
                           3032 ;	Peephole 181	changed mov to clr
   4DAB E4                 3033 	clr	a
   4DAC 08                 3034 	inc	r0
   4DAD 36                 3035 	addc	a,@r0
   4DAE FE                 3036 	mov	r6,a
   4DAF 08                 3037 	inc	r0
   4DB0 86 07              3038 	mov	ar7,@r0
                           3039 ;	genIpush
   4DB2 74 0D              3040 	mov	a,#0x0D
   4DB4 C0 E0              3041 	push	acc
                           3042 ;	Peephole 181	changed mov to clr
   4DB6 E4                 3043 	clr	a
   4DB7 C0 E0              3044 	push	acc
                           3045 ;	genIpush
   4DB9 C0 02              3046 	push	ar2
   4DBB C0 03              3047 	push	ar3
   4DBD C0 04              3048 	push	ar4
                           3049 ;	genCall
   4DBF 8D 82              3050 	mov	dpl,r5
   4DC1 8E 83              3051 	mov	dph,r6
   4DC3 8F F0              3052 	mov	b,r7
   4DC5 12 E2 C7           3053 	lcall	_memcpy
   4DC8 E5 81              3054 	mov	a,sp
   4DCA 24 FB              3055 	add	a,#0xfb
   4DCC F5 81              3056 	mov	sp,a
                           3057 ;	../../Common/socket.c:405: memcpy(&(buffer->src_sa), &(mac_long), sizeof(sockaddr_t));		
                           3058 ;	genPlus
   4DCE E5 10              3059 	mov	a,_bp
   4DD0 24 04              3060 	add	a,#0x04
   4DD2 F8                 3061 	mov	r0,a
                           3062 ;     genPlusIncr
   4DD3 74 10              3063 	mov	a,#0x10
   4DD5 26                 3064 	add	a,@r0
   4DD6 FA                 3065 	mov	r2,a
                           3066 ;	Peephole 181	changed mov to clr
   4DD7 E4                 3067 	clr	a
   4DD8 08                 3068 	inc	r0
   4DD9 36                 3069 	addc	a,@r0
   4DDA FB                 3070 	mov	r3,a
   4DDB 08                 3071 	inc	r0
   4DDC 86 04              3072 	mov	ar4,@r0
                           3073 ;	genIpush
   4DDE 74 0D              3074 	mov	a,#0x0D
   4DE0 C0 E0              3075 	push	acc
                           3076 ;	Peephole 181	changed mov to clr
   4DE2 E4                 3077 	clr	a
   4DE3 C0 E0              3078 	push	acc
                           3079 ;	genIpush
   4DE5 74 92              3080 	mov	a,#_mac_long
   4DE7 C0 E0              3081 	push	acc
   4DE9 74 F0              3082 	mov	a,#(_mac_long >> 8)
   4DEB C0 E0              3083 	push	acc
                           3084 ;	Peephole 181	changed mov to clr
   4DED E4                 3085 	clr	a
   4DEE C0 E0              3086 	push	acc
                           3087 ;	genCall
   4DF0 8A 82              3088 	mov	dpl,r2
   4DF2 8B 83              3089 	mov	dph,r3
   4DF4 8C F0              3090 	mov	b,r4
   4DF6 12 E2 C7           3091 	lcall	_memcpy
   4DF9 E5 81              3092 	mov	a,sp
   4DFB 24 FB              3093 	add	a,#0xfb
   4DFD F5 81              3094 	mov	sp,a
   4DFF                    3095 00102$:
                           3096 ;	../../Common/socket.c:407: return buffer;
                           3097 ;	genRet
   4DFF E5 10              3098 	mov	a,_bp
   4E01 24 04              3099 	add	a,#0x04
   4E03 F8                 3100 	mov	r0,a
   4E04 86 82              3101 	mov	dpl,@r0
   4E06 08                 3102 	inc	r0
   4E07 86 83              3103 	mov	dph,@r0
   4E09 08                 3104 	inc	r0
   4E0A 86 F0              3105 	mov	b,@r0
                           3106 ;	Peephole 300	removed redundant label 00107$
   4E0C 85 10 81           3107 	mov	sp,_bp
   4E0F D0 10              3108 	pop	_bp
   4E11 22                 3109 	ret
                           3110 ;------------------------------------------------------------
                           3111 ;Allocation info for local variables in function 'socket_buffer_free'
                           3112 ;------------------------------------------------------------
                           3113 ;buffer                    Allocated to registers r2 r3 r4 
                           3114 ;------------------------------------------------------------
                           3115 ;	../../Common/socket.c:418: portCHAR socket_buffer_free(buffer_t *buffer) 
                           3116 ;	-----------------------------------------
                           3117 ;	 function socket_buffer_free
                           3118 ;	-----------------------------------------
   4E12                    3119 _socket_buffer_free:
                           3120 ;	genReceive
   4E12 AA 82              3121 	mov	r2,dpl
   4E14 AB 83              3122 	mov	r3,dph
   4E16 AC F0              3123 	mov	r4,b
                           3124 ;	../../Common/socket.c:421: if (buffer)
                           3125 ;	genIfx
   4E18 EA                 3126 	mov	a,r2
   4E19 4B                 3127 	orl	a,r3
   4E1A 4C                 3128 	orl	a,r4
                           3129 ;	genIfxJump
                           3130 ;	Peephole 108.c	removed ljmp by inverse jump logic
   4E1B 60 09              3131 	jz	00102$
                           3132 ;	Peephole 300	removed redundant label 00106$
                           3133 ;	../../Common/socket.c:423: stack_buffer_free(buffer);
                           3134 ;	genCall
   4E1D 8A 82              3135 	mov	dpl,r2
   4E1F 8B 83              3136 	mov	dph,r3
   4E21 8C F0              3137 	mov	b,r4
   4E23 12 61 FA           3138 	lcall	_stack_buffer_free
   4E26                    3139 00102$:
                           3140 ;	../../Common/socket.c:425: return pdTRUE;
                           3141 ;	genRet
   4E26 75 82 01           3142 	mov	dpl,#0x01
                           3143 ;	Peephole 300	removed redundant label 00103$
   4E29 22                 3144 	ret
                           3145 ;------------------------------------------------------------
                           3146 ;Allocation info for local variables in function 'socket_sendto'
                           3147 ;------------------------------------------------------------
                           3148 ;dst                       Allocated to stack - offset -5
                           3149 ;buf                       Allocated to stack - offset -8
                           3150 ;si                        Allocated to stack - offset 1
                           3151 ;retvalue                  Allocated to registers r2 
                           3152 ;src_port                  Allocated to registers r3 r4 
                           3153 ;sloc0                     Allocated to stack - offset 4
                           3154 ;------------------------------------------------------------
                           3155 ;	../../Common/socket.c:439: portCHAR socket_sendto (socket_t *si, sockaddr_t *dst, buffer_t *buf)
                           3156 ;	-----------------------------------------
                           3157 ;	 function socket_sendto
                           3158 ;	-----------------------------------------
   4E2A                    3159 _socket_sendto:
   4E2A C0 10              3160 	push	_bp
   4E2C 85 81 10           3161 	mov	_bp,sp
                           3162 ;     genReceive
   4E2F C0 82              3163 	push	dpl
   4E31 C0 83              3164 	push	dph
   4E33 C0 F0              3165 	push	b
   4E35 05 81              3166 	inc	sp
   4E37 05 81              3167 	inc	sp
   4E39 05 81              3168 	inc	sp
                           3169 ;	../../Common/socket.c:444: if ( socket_id_find(si) < 0)
                           3170 ;	genCall
   4E3B A8 10              3171 	mov	r0,_bp
   4E3D 08                 3172 	inc	r0
   4E3E 86 82              3173 	mov	dpl,@r0
   4E40 08                 3174 	inc	r0
   4E41 86 83              3175 	mov	dph,@r0
   4E43 08                 3176 	inc	r0
   4E44 86 F0              3177 	mov	b,@r0
   4E46 12 49 11           3178 	lcall	_socket_id_find
                           3179 ;	genCmpLt
                           3180 ;	genCmp
                           3181 ;	peephole 177.g	optimized mov sequence
   4E49 E5 82              3182 	mov	a,dpl
   4E4B FD                 3183 	mov	r5,a
                           3184 ;	genIfxJump
                           3185 ;	Peephole 108.d	removed ljmp by inverse jump logic
   4E4C 30 E7 06           3186 	jnb	acc.7,00102$
                           3187 ;	Peephole 300	removed redundant label 00127$
                           3188 ;	../../Common/socket.c:449: return pdFAIL;
                           3189 ;	genRet
   4E4F 75 82 00           3190 	mov	dpl,#0x00
   4E52 02 50 F1           3191 	ljmp	00118$
   4E55                    3192 00102$:
                           3193 ;	../../Common/socket.c:451: if (si->stack_id == stack_number_get())
                           3194 ;	genPlus
   4E55 A8 10              3195 	mov	r0,_bp
   4E57 08                 3196 	inc	r0
                           3197 ;     genPlusIncr
   4E58 74 01              3198 	mov	a,#0x01
   4E5A 26                 3199 	add	a,@r0
   4E5B FD                 3200 	mov	r5,a
                           3201 ;	Peephole 181	changed mov to clr
   4E5C E4                 3202 	clr	a
   4E5D 08                 3203 	inc	r0
   4E5E 36                 3204 	addc	a,@r0
   4E5F FE                 3205 	mov	r6,a
   4E60 08                 3206 	inc	r0
   4E61 86 07              3207 	mov	ar7,@r0
                           3208 ;	genPointerGet
                           3209 ;	genGenPointerGet
   4E63 8D 82              3210 	mov	dpl,r5
   4E65 8E 83              3211 	mov	dph,r6
   4E67 8F F0              3212 	mov	b,r7
   4E69 12 E4 9F           3213 	lcall	__gptrget
   4E6C FD                 3214 	mov	r5,a
                           3215 ;	genCall
   4E6D C0 05              3216 	push	ar5
   4E6F 12 64 F8           3217 	lcall	_stack_number_get
   4E72 AE 82              3218 	mov	r6,dpl
   4E74 D0 05              3219 	pop	ar5
                           3220 ;	genCmpEq
                           3221 ;	gencjneshort
   4E76 ED                 3222 	mov	a,r5
   4E77 B5 06 02           3223 	cjne	a,ar6,00128$
   4E7A 80 03              3224 	sjmp	00129$
   4E7C                    3225 00128$:
   4E7C 02 4F 06           3226 	ljmp	00104$
   4E7F                    3227 00129$:
                           3228 ;	../../Common/socket.c:456: buf->options.type = BUFFER_CONTROL;
                           3229 ;	genAssign
   4E7F E5 10              3230 	mov	a,_bp
   4E81 24 F8              3231 	add	a,#0xfffffff8
   4E83 F8                 3232 	mov	r0,a
   4E84 86 05              3233 	mov	ar5,@r0
   4E86 08                 3234 	inc	r0
   4E87 86 06              3235 	mov	ar6,@r0
   4E89 08                 3236 	inc	r0
   4E8A 86 07              3237 	mov	ar7,@r0
                           3238 ;	genPlus
                           3239 ;     genPlusIncr
   4E8C 74 26              3240 	mov	a,#0x26
                           3241 ;	Peephole 236.a	used r5 instead of ar5
   4E8E 2D                 3242 	add	a,r5
   4E8F FA                 3243 	mov	r2,a
                           3244 ;	Peephole 181	changed mov to clr
   4E90 E4                 3245 	clr	a
                           3246 ;	Peephole 236.b	used r6 instead of ar6
   4E91 3E                 3247 	addc	a,r6
   4E92 FB                 3248 	mov	r3,a
   4E93 8F 04              3249 	mov	ar4,r7
                           3250 ;	genPointerSet
                           3251 ;	genGenPointerSet
   4E95 8A 82              3252 	mov	dpl,r2
   4E97 8B 83              3253 	mov	dph,r3
   4E99 8C F0              3254 	mov	b,r4
   4E9B 74 01              3255 	mov	a,#0x01
   4E9D 12 DF B7           3256 	lcall	__gptrput
                           3257 ;	../../Common/socket.c:457: buf->to = si->protocol;
                           3258 ;	genPlus
   4EA0 E5 10              3259 	mov	a,_bp
   4EA2 24 04              3260 	add	a,#0x04
   4EA4 F8                 3261 	mov	r0,a
                           3262 ;     genPlusIncr
   4EA5 74 1E              3263 	mov	a,#0x1E
                           3264 ;	Peephole 236.a	used r5 instead of ar5
   4EA7 2D                 3265 	add	a,r5
   4EA8 F6                 3266 	mov	@r0,a
                           3267 ;	Peephole 181	changed mov to clr
   4EA9 E4                 3268 	clr	a
                           3269 ;	Peephole 236.b	used r6 instead of ar6
   4EAA 3E                 3270 	addc	a,r6
   4EAB 08                 3271 	inc	r0
   4EAC F6                 3272 	mov	@r0,a
   4EAD 08                 3273 	inc	r0
   4EAE A6 07              3274 	mov	@r0,ar7
                           3275 ;	genPointerGet
                           3276 ;	genGenPointerGet
   4EB0 A8 10              3277 	mov	r0,_bp
   4EB2 08                 3278 	inc	r0
   4EB3 86 82              3279 	mov	dpl,@r0
   4EB5 08                 3280 	inc	r0
   4EB6 86 83              3281 	mov	dph,@r0
   4EB8 08                 3282 	inc	r0
   4EB9 86 F0              3283 	mov	b,@r0
   4EBB 12 E4 9F           3284 	lcall	__gptrget
   4EBE FA                 3285 	mov	r2,a
                           3286 ;	genPointerSet
                           3287 ;	genGenPointerSet
   4EBF E5 10              3288 	mov	a,_bp
   4EC1 24 04              3289 	add	a,#0x04
   4EC3 F8                 3290 	mov	r0,a
   4EC4 86 82              3291 	mov	dpl,@r0
   4EC6 08                 3292 	inc	r0
   4EC7 86 83              3293 	mov	dph,@r0
   4EC9 08                 3294 	inc	r0
   4ECA 86 F0              3295 	mov	b,@r0
   4ECC EA                 3296 	mov	a,r2
   4ECD 12 DF B7           3297 	lcall	__gptrput
                           3298 ;	../../Common/socket.c:458: buf->dir = BUFFER_DOWN;
                           3299 ;	genPlus
                           3300 ;     genPlusIncr
   4ED0 74 1F              3301 	mov	a,#0x1F
                           3302 ;	Peephole 236.a	used r5 instead of ar5
   4ED2 2D                 3303 	add	a,r5
   4ED3 FA                 3304 	mov	r2,a
                           3305 ;	Peephole 181	changed mov to clr
   4ED4 E4                 3306 	clr	a
                           3307 ;	Peephole 236.b	used r6 instead of ar6
   4ED5 3E                 3308 	addc	a,r6
   4ED6 FB                 3309 	mov	r3,a
   4ED7 8F 04              3310 	mov	ar4,r7
                           3311 ;	genPointerSet
                           3312 ;	genGenPointerSet
   4ED9 8A 82              3313 	mov	dpl,r2
   4EDB 8B 83              3314 	mov	dph,r3
   4EDD 8C F0              3315 	mov	b,r4
   4EDF 74 01              3316 	mov	a,#0x01
   4EE1 12 DF B7           3317 	lcall	__gptrput
                           3318 ;	../../Common/socket.c:459: buf->from = MODULE_APP;
                           3319 ;	genPlus
                           3320 ;     genPlusIncr
   4EE4 74 1D              3321 	mov	a,#0x1D
                           3322 ;	Peephole 236.a	used r5 instead of ar5
   4EE6 2D                 3323 	add	a,r5
   4EE7 FA                 3324 	mov	r2,a
                           3325 ;	Peephole 181	changed mov to clr
   4EE8 E4                 3326 	clr	a
                           3327 ;	Peephole 236.b	used r6 instead of ar6
   4EE9 3E                 3328 	addc	a,r6
   4EEA FB                 3329 	mov	r3,a
   4EEB 8F 04              3330 	mov	ar4,r7
                           3331 ;	genPointerSet
                           3332 ;	genGenPointerSet
   4EED 8A 82              3333 	mov	dpl,r2
   4EEF 8B 83              3334 	mov	dph,r3
   4EF1 8C F0              3335 	mov	b,r4
   4EF3 74 0B              3336 	mov	a,#0x0B
   4EF5 12 DF B7           3337 	lcall	__gptrput
                           3338 ;	../../Common/socket.c:460: retvalue = stack_buffer_push(buf);
                           3339 ;	genCall
   4EF8 8D 82              3340 	mov	dpl,r5
   4EFA 8E 83              3341 	mov	dph,r6
   4EFC 8F F0              3342 	mov	b,r7
   4EFE 12 62 C4           3343 	lcall	_stack_buffer_push
                           3344 ;	genAssign
                           3345 ;	../../Common/socket.c:461: return retvalue;
                           3346 ;	genRet
   4F01 AA 82              3347 	mov  r2,dpl
                           3348 ;	Peephole 177.a	removed redundant mov
   4F03 02 50 F1           3349 	ljmp	00118$
   4F06                    3350 00104$:
                           3351 ;	../../Common/socket.c:465: if (si->listen != 0)
                           3352 ;	genPlus
   4F06 A8 10              3353 	mov	r0,_bp
   4F08 08                 3354 	inc	r0
                           3355 ;     genPlusIncr
   4F09 74 02              3356 	mov	a,#0x02
   4F0B 26                 3357 	add	a,@r0
   4F0C FB                 3358 	mov	r3,a
                           3359 ;	Peephole 181	changed mov to clr
   4F0D E4                 3360 	clr	a
   4F0E 08                 3361 	inc	r0
   4F0F 36                 3362 	addc	a,@r0
   4F10 FC                 3363 	mov	r4,a
   4F11 08                 3364 	inc	r0
   4F12 86 05              3365 	mov	ar5,@r0
                           3366 ;	genPointerGet
                           3367 ;	genGenPointerGet
   4F14 8B 82              3368 	mov	dpl,r3
   4F16 8C 83              3369 	mov	dph,r4
   4F18 8D F0              3370 	mov	b,r5
   4F1A 12 E4 9F           3371 	lcall	__gptrget
   4F1D FB                 3372 	mov	r3,a
   4F1E A3                 3373 	inc	dptr
   4F1F 12 E4 9F           3374 	lcall	__gptrget
   4F22 FC                 3375 	mov	r4,a
                           3376 ;	genCmpEq
                           3377 ;	gencjneshort
                           3378 ;	Peephole 112.b	changed ljmp to sjmp
                           3379 ;	../../Common/socket.c:467: src_port = si->listen;
                           3380 ;	genAssign
                           3381 ;	genAssign
                           3382 ;	Peephole 112.b	changed ljmp to sjmp
                           3383 ;	Peephole 198.a	optimized misc jump sequence
   4F23 BB 00 57           3384 	cjne	r3,#0x00,00109$
   4F26 BC 00 54           3385 	cjne	r4,#0x00,00109$
                           3386 ;	Peephole 200.b	removed redundant sjmp
                           3387 ;	Peephole 300	removed redundant label 00130$
                           3388 ;	Peephole 300	removed redundant label 00108$
                           3389 ;	../../Common/socket.c:471: src_port = si->port;
                           3390 ;	genPlus
   4F29 A8 10              3391 	mov	r0,_bp
   4F2B 08                 3392 	inc	r0
                           3393 ;     genPlusIncr
   4F2C 74 04              3394 	mov	a,#0x04
   4F2E 26                 3395 	add	a,@r0
   4F2F FD                 3396 	mov	r5,a
                           3397 ;	Peephole 181	changed mov to clr
   4F30 E4                 3398 	clr	a
   4F31 08                 3399 	inc	r0
   4F32 36                 3400 	addc	a,@r0
   4F33 FE                 3401 	mov	r6,a
   4F34 08                 3402 	inc	r0
   4F35 86 07              3403 	mov	ar7,@r0
                           3404 ;	genPointerGet
                           3405 ;	genGenPointerGet
   4F37 8D 82              3406 	mov	dpl,r5
   4F39 8E 83              3407 	mov	dph,r6
   4F3B 8F F0              3408 	mov	b,r7
   4F3D 12 E4 9F           3409 	lcall	__gptrget
   4F40 FD                 3410 	mov	r5,a
   4F41 A3                 3411 	inc	dptr
   4F42 12 E4 9F           3412 	lcall	__gptrget
   4F45 FE                 3413 	mov	r6,a
                           3414 ;	genAssign
   4F46 8D 03              3415 	mov	ar3,r5
   4F48 8E 04              3416 	mov	ar4,r6
                           3417 ;	../../Common/socket.c:472: if (src_port == 0)
                           3418 ;	genIfx
   4F4A EB                 3419 	mov	a,r3
   4F4B 4C                 3420 	orl	a,r4
                           3421 ;	genIfxJump
                           3422 ;	Peephole 108.b	removed ljmp by inverse jump logic
   4F4C 70 2F              3423 	jnz	00109$
                           3424 ;	Peephole 300	removed redundant label 00131$
                           3425 ;	../../Common/socket.c:474: socket_port_random(si);
                           3426 ;	genCall
   4F4E A8 10              3427 	mov	r0,_bp
   4F50 08                 3428 	inc	r0
   4F51 86 82              3429 	mov	dpl,@r0
   4F53 08                 3430 	inc	r0
   4F54 86 83              3431 	mov	dph,@r0
   4F56 08                 3432 	inc	r0
   4F57 86 F0              3433 	mov	b,@r0
   4F59 12 52 A8           3434 	lcall	_socket_port_random
                           3435 ;	../../Common/socket.c:480: src_port = si->port;
                           3436 ;	genPlus
   4F5C A8 10              3437 	mov	r0,_bp
   4F5E 08                 3438 	inc	r0
                           3439 ;     genPlusIncr
   4F5F 74 04              3440 	mov	a,#0x04
   4F61 26                 3441 	add	a,@r0
   4F62 FD                 3442 	mov	r5,a
                           3443 ;	Peephole 181	changed mov to clr
   4F63 E4                 3444 	clr	a
   4F64 08                 3445 	inc	r0
   4F65 36                 3446 	addc	a,@r0
   4F66 FE                 3447 	mov	r6,a
   4F67 08                 3448 	inc	r0
   4F68 86 07              3449 	mov	ar7,@r0
                           3450 ;	genPointerGet
                           3451 ;	genGenPointerGet
   4F6A 8D 82              3452 	mov	dpl,r5
   4F6C 8E 83              3453 	mov	dph,r6
   4F6E 8F F0              3454 	mov	b,r7
   4F70 12 E4 9F           3455 	lcall	__gptrget
   4F73 FD                 3456 	mov	r5,a
   4F74 A3                 3457 	inc	dptr
   4F75 12 E4 9F           3458 	lcall	__gptrget
   4F78 FE                 3459 	mov	r6,a
                           3460 ;	genAssign
   4F79 8D 03              3461 	mov	ar3,r5
   4F7B 8E 04              3462 	mov	ar4,r6
   4F7D                    3463 00109$:
                           3464 ;	../../Common/socket.c:484: buf->socket = (void *) si;
                           3465 ;	genIpush
   4F7D C0 03              3466 	push	ar3
   4F7F C0 04              3467 	push	ar4
                           3468 ;	genAssign
   4F81 E5 10              3469 	mov	a,_bp
   4F83 24 F8              3470 	add	a,#0xfffffff8
   4F85 F8                 3471 	mov	r0,a
   4F86 E5 10              3472 	mov	a,_bp
   4F88 24 04              3473 	add	a,#0x04
   4F8A F9                 3474 	mov	r1,a
   4F8B E6                 3475 	mov	a,@r0
   4F8C F7                 3476 	mov	@r1,a
   4F8D 08                 3477 	inc	r0
   4F8E 09                 3478 	inc	r1
   4F8F E6                 3479 	mov	a,@r0
   4F90 F7                 3480 	mov	@r1,a
   4F91 08                 3481 	inc	r0
   4F92 09                 3482 	inc	r1
   4F93 E6                 3483 	mov	a,@r0
   4F94 F7                 3484 	mov	@r1,a
                           3485 ;	genPointerSet
                           3486 ;	genGenPointerSet
   4F95 E5 10              3487 	mov	a,_bp
   4F97 24 04              3488 	add	a,#0x04
   4F99 F8                 3489 	mov	r0,a
   4F9A 86 82              3490 	mov	dpl,@r0
   4F9C 08                 3491 	inc	r0
   4F9D 86 83              3492 	mov	dph,@r0
   4F9F 08                 3493 	inc	r0
   4FA0 86 F0              3494 	mov	b,@r0
   4FA2 A9 10              3495 	mov	r1,_bp
   4FA4 09                 3496 	inc	r1
   4FA5 E7                 3497 	mov	a,@r1
   4FA6 12 DF B7           3498 	lcall	__gptrput
   4FA9 A3                 3499 	inc	dptr
   4FAA 09                 3500 	inc	r1
   4FAB E7                 3501 	mov	a,@r1
   4FAC 12 DF B7           3502 	lcall	__gptrput
   4FAF A3                 3503 	inc	dptr
   4FB0 09                 3504 	inc	r1
   4FB1 E7                 3505 	mov	a,@r1
   4FB2 12 DF B7           3506 	lcall	__gptrput
                           3507 ;	../../Common/socket.c:485: if (buf->src_sa.addr_type == ADDR_NONE)
                           3508 ;	genPlus
   4FB5 E5 10              3509 	mov	a,_bp
   4FB7 24 04              3510 	add	a,#0x04
   4FB9 F8                 3511 	mov	r0,a
                           3512 ;     genPlusIncr
   4FBA 74 10              3513 	mov	a,#0x10
   4FBC 26                 3514 	add	a,@r0
   4FBD FB                 3515 	mov	r3,a
                           3516 ;	Peephole 181	changed mov to clr
   4FBE E4                 3517 	clr	a
   4FBF 08                 3518 	inc	r0
   4FC0 36                 3519 	addc	a,@r0
   4FC1 FC                 3520 	mov	r4,a
   4FC2 08                 3521 	inc	r0
   4FC3 86 05              3522 	mov	ar5,@r0
                           3523 ;	genPointerGet
                           3524 ;	genGenPointerGet
   4FC5 8B 82              3525 	mov	dpl,r3
   4FC7 8C 83              3526 	mov	dph,r4
   4FC9 8D F0              3527 	mov	b,r5
   4FCB 12 E4 9F           3528 	lcall	__gptrget
                           3529 ;	genIpop
   4FCE D0 04              3530 	pop	ar4
   4FD0 D0 03              3531 	pop	ar3
                           3532 ;	genIfx
                           3533 ;	genIfxJump
                           3534 ;	Peephole 108.b	removed ljmp by inverse jump logic
   4FD2 70 3E              3535 	jnz	00111$
                           3536 ;	Peephole 300	removed redundant label 00132$
                           3537 ;	../../Common/socket.c:487: memcpy(&(buf->src_sa.address), &(mac_long.address), 8);
                           3538 ;	genPlus
   4FD4 E5 10              3539 	mov	a,_bp
   4FD6 24 04              3540 	add	a,#0x04
   4FD8 F8                 3541 	mov	r0,a
                           3542 ;     genPlusIncr
   4FD9 74 10              3543 	mov	a,#0x10
   4FDB 26                 3544 	add	a,@r0
   4FDC FD                 3545 	mov	r5,a
                           3546 ;	Peephole 181	changed mov to clr
   4FDD E4                 3547 	clr	a
   4FDE 08                 3548 	inc	r0
   4FDF 36                 3549 	addc	a,@r0
   4FE0 FE                 3550 	mov	r6,a
   4FE1 08                 3551 	inc	r0
   4FE2 86 07              3552 	mov	ar7,@r0
                           3553 ;	genPlus
                           3554 ;     genPlusIncr
   4FE4 0D                 3555 	inc	r5
   4FE5 BD 00 01           3556 	cjne	r5,#0x00,00133$
   4FE8 0E                 3557 	inc	r6
   4FE9                    3558 00133$:
                           3559 ;	genIpush
   4FE9 C0 03              3560 	push	ar3
   4FEB C0 04              3561 	push	ar4
   4FED 74 08              3562 	mov	a,#0x08
   4FEF C0 E0              3563 	push	acc
                           3564 ;	Peephole 181	changed mov to clr
   4FF1 E4                 3565 	clr	a
   4FF2 C0 E0              3566 	push	acc
                           3567 ;	genIpush
   4FF4 74 93              3568 	mov	a,#(_mac_long + 0x0001)
   4FF6 C0 E0              3569 	push	acc
   4FF8 74 F0              3570 	mov	a,#((_mac_long + 0x0001) >> 8)
   4FFA C0 E0              3571 	push	acc
                           3572 ;	Peephole 181	changed mov to clr
   4FFC E4                 3573 	clr	a
   4FFD C0 E0              3574 	push	acc
                           3575 ;	genCall
   4FFF 8D 82              3576 	mov	dpl,r5
   5001 8E 83              3577 	mov	dph,r6
   5003 8F F0              3578 	mov	b,r7
   5005 12 E2 C7           3579 	lcall	_memcpy
   5008 E5 81              3580 	mov	a,sp
   500A 24 FB              3581 	add	a,#0xfb
   500C F5 81              3582 	mov	sp,a
   500E D0 04              3583 	pop	ar4
   5010 D0 03              3584 	pop	ar3
   5012                    3585 00111$:
                           3586 ;	../../Common/socket.c:489: buf->src_sa.port = src_port;
                           3587 ;	genPlus
   5012 E5 10              3588 	mov	a,_bp
   5014 24 04              3589 	add	a,#0x04
   5016 F8                 3590 	mov	r0,a
                           3591 ;     genPlusIncr
   5017 74 10              3592 	mov	a,#0x10
   5019 26                 3593 	add	a,@r0
   501A FD                 3594 	mov	r5,a
                           3595 ;	Peephole 181	changed mov to clr
   501B E4                 3596 	clr	a
   501C 08                 3597 	inc	r0
   501D 36                 3598 	addc	a,@r0
   501E FE                 3599 	mov	r6,a
   501F 08                 3600 	inc	r0
   5020 86 07              3601 	mov	ar7,@r0
                           3602 ;	genPlus
                           3603 ;     genPlusIncr
   5022 74 0B              3604 	mov	a,#0x0B
                           3605 ;	Peephole 236.a	used r5 instead of ar5
   5024 2D                 3606 	add	a,r5
   5025 FD                 3607 	mov	r5,a
                           3608 ;	Peephole 181	changed mov to clr
   5026 E4                 3609 	clr	a
                           3610 ;	Peephole 236.b	used r6 instead of ar6
   5027 3E                 3611 	addc	a,r6
   5028 FE                 3612 	mov	r6,a
                           3613 ;	genPointerSet
                           3614 ;	genGenPointerSet
   5029 8D 82              3615 	mov	dpl,r5
   502B 8E 83              3616 	mov	dph,r6
   502D 8F F0              3617 	mov	b,r7
   502F EB                 3618 	mov	a,r3
   5030 12 DF B7           3619 	lcall	__gptrput
   5033 A3                 3620 	inc	dptr
   5034 EC                 3621 	mov	a,r4
   5035 12 DF B7           3622 	lcall	__gptrput
                           3623 ;	../../Common/socket.c:490: buf->from = MODULE_APP;
                           3624 ;	genPlus
   5038 E5 10              3625 	mov	a,_bp
   503A 24 04              3626 	add	a,#0x04
   503C F8                 3627 	mov	r0,a
                           3628 ;     genPlusIncr
   503D 74 1D              3629 	mov	a,#0x1D
   503F 26                 3630 	add	a,@r0
   5040 FB                 3631 	mov	r3,a
                           3632 ;	Peephole 181	changed mov to clr
   5041 E4                 3633 	clr	a
   5042 08                 3634 	inc	r0
   5043 36                 3635 	addc	a,@r0
   5044 FC                 3636 	mov	r4,a
   5045 08                 3637 	inc	r0
   5046 86 05              3638 	mov	ar5,@r0
                           3639 ;	genPointerSet
                           3640 ;	genGenPointerSet
   5048 8B 82              3641 	mov	dpl,r3
   504A 8C 83              3642 	mov	dph,r4
   504C 8D F0              3643 	mov	b,r5
   504E 74 0B              3644 	mov	a,#0x0B
   5050 12 DF B7           3645 	lcall	__gptrput
                           3646 ;	../../Common/socket.c:491: buf->dir = BUFFER_DOWN;
                           3647 ;	genPlus
   5053 E5 10              3648 	mov	a,_bp
   5055 24 04              3649 	add	a,#0x04
   5057 F8                 3650 	mov	r0,a
                           3651 ;     genPlusIncr
   5058 74 1F              3652 	mov	a,#0x1F
   505A 26                 3653 	add	a,@r0
   505B FB                 3654 	mov	r3,a
                           3655 ;	Peephole 181	changed mov to clr
   505C E4                 3656 	clr	a
   505D 08                 3657 	inc	r0
   505E 36                 3658 	addc	a,@r0
   505F FC                 3659 	mov	r4,a
   5060 08                 3660 	inc	r0
   5061 86 05              3661 	mov	ar5,@r0
                           3662 ;	genPointerSet
                           3663 ;	genGenPointerSet
   5063 8B 82              3664 	mov	dpl,r3
   5065 8C 83              3665 	mov	dph,r4
   5067 8D F0              3666 	mov	b,r5
   5069 74 01              3667 	mov	a,#0x01
   506B 12 DF B7           3668 	lcall	__gptrput
                           3669 ;	../../Common/socket.c:492: buf->to = MODULE_NONE;
                           3670 ;	genPlus
   506E E5 10              3671 	mov	a,_bp
   5070 24 04              3672 	add	a,#0x04
   5072 F8                 3673 	mov	r0,a
                           3674 ;     genPlusIncr
   5073 74 1E              3675 	mov	a,#0x1E
   5075 26                 3676 	add	a,@r0
   5076 FB                 3677 	mov	r3,a
                           3678 ;	Peephole 181	changed mov to clr
   5077 E4                 3679 	clr	a
   5078 08                 3680 	inc	r0
   5079 36                 3681 	addc	a,@r0
   507A FC                 3682 	mov	r4,a
   507B 08                 3683 	inc	r0
   507C 86 05              3684 	mov	ar5,@r0
                           3685 ;	genPointerSet
                           3686 ;	genGenPointerSet
   507E 8B 82              3687 	mov	dpl,r3
   5080 8C 83              3688 	mov	dph,r4
   5082 8D F0              3689 	mov	b,r5
                           3690 ;	Peephole 181	changed mov to clr
   5084 E4                 3691 	clr	a
   5085 12 DF B7           3692 	lcall	__gptrput
                           3693 ;	../../Common/socket.c:494: if (dst)
                           3694 ;	genIfx
   5088 E5 10              3695 	mov	a,_bp
   508A 24 FB              3696 	add	a,#0xfffffffb
   508C F8                 3697 	mov	r0,a
   508D E6                 3698 	mov	a,@r0
   508E 08                 3699 	inc	r0
   508F 46                 3700 	orl	a,@r0
   5090 08                 3701 	inc	r0
   5091 46                 3702 	orl	a,@r0
                           3703 ;	genIfxJump
                           3704 ;	Peephole 108.c	removed ljmp by inverse jump logic
   5092 60 3E              3705 	jz	00113$
                           3706 ;	Peephole 300	removed redundant label 00134$
                           3707 ;	../../Common/socket.c:496: retvalue = pdTRUE;
                           3708 ;	genAssign
   5094 7A 01              3709 	mov	r2,#0x01
                           3710 ;	../../Common/socket.c:497: memcpy(&(buf->dst_sa), dst, sizeof(sockaddr_t));
                           3711 ;	genPlus
   5096 E5 10              3712 	mov	a,_bp
   5098 24 04              3713 	add	a,#0x04
   509A F8                 3714 	mov	r0,a
                           3715 ;     genPlusIncr
   509B 74 03              3716 	mov	a,#0x03
   509D 26                 3717 	add	a,@r0
   509E FB                 3718 	mov	r3,a
                           3719 ;	Peephole 181	changed mov to clr
   509F E4                 3720 	clr	a
   50A0 08                 3721 	inc	r0
   50A1 36                 3722 	addc	a,@r0
   50A2 FC                 3723 	mov	r4,a
   50A3 08                 3724 	inc	r0
   50A4 86 05              3725 	mov	ar5,@r0
                           3726 ;	genIpush
   50A6 C0 02              3727 	push	ar2
   50A8 74 0D              3728 	mov	a,#0x0D
   50AA C0 E0              3729 	push	acc
                           3730 ;	Peephole 181	changed mov to clr
   50AC E4                 3731 	clr	a
   50AD C0 E0              3732 	push	acc
                           3733 ;	genIpush
   50AF E5 10              3734 	mov	a,_bp
   50B1 24 FB              3735 	add	a,#0xfffffffb
   50B3 F8                 3736 	mov	r0,a
   50B4 E6                 3737 	mov	a,@r0
   50B5 C0 E0              3738 	push	acc
   50B7 08                 3739 	inc	r0
   50B8 E6                 3740 	mov	a,@r0
   50B9 C0 E0              3741 	push	acc
   50BB 08                 3742 	inc	r0
   50BC E6                 3743 	mov	a,@r0
   50BD C0 E0              3744 	push	acc
                           3745 ;	genCall
   50BF 8B 82              3746 	mov	dpl,r3
   50C1 8C 83              3747 	mov	dph,r4
   50C3 8D F0              3748 	mov	b,r5
   50C5 12 E2 C7           3749 	lcall	_memcpy
   50C8 E5 81              3750 	mov	a,sp
   50CA 24 FB              3751 	add	a,#0xfb
   50CC F5 81              3752 	mov	sp,a
   50CE D0 02              3753 	pop	ar2
                           3754 ;	Peephole 112.b	changed ljmp to sjmp
   50D0 80 02              3755 	sjmp	00114$
   50D2                    3756 00113$:
                           3757 ;	../../Common/socket.c:504: retvalue = pdFAIL;	/*No destination*/
                           3758 ;	genAssign
   50D2 7A 00              3759 	mov	r2,#0x00
   50D4                    3760 00114$:
                           3761 ;	../../Common/socket.c:506: if (retvalue == pdTRUE)
                           3762 ;	genCmpEq
                           3763 ;	gencjneshort
                           3764 ;	Peephole 112.b	changed ljmp to sjmp
                           3765 ;	Peephole 198.b	optimized misc jump sequence
   50D4 BA 01 16           3766 	cjne	r2,#0x01,00116$
                           3767 ;	Peephole 200.b	removed redundant sjmp
                           3768 ;	Peephole 300	removed redundant label 00135$
                           3769 ;	Peephole 300	removed redundant label 00136$
                           3770 ;	../../Common/socket.c:508: retvalue = stack_buffer_push(buf);
                           3771 ;	genCall
   50D7 E5 10              3772 	mov	a,_bp
   50D9 24 04              3773 	add	a,#0x04
   50DB F8                 3774 	mov	r0,a
   50DC 86 82              3775 	mov	dpl,@r0
   50DE 08                 3776 	inc	r0
   50DF 86 83              3777 	mov	dph,@r0
   50E1 08                 3778 	inc	r0
   50E2 86 F0              3779 	mov	b,@r0
   50E4 12 62 C4           3780 	lcall	_stack_buffer_push
   50E7 AB 82              3781 	mov	r3,dpl
                           3782 ;	genAssign
   50E9 8B 02              3783 	mov	ar2,r3
                           3784 ;	Peephole 112.b	changed ljmp to sjmp
   50EB 80 02              3785 	sjmp	00117$
   50ED                    3786 00116$:
                           3787 ;	../../Common/socket.c:512: retvalue = pdFALSE;
                           3788 ;	genAssign
   50ED 7A 00              3789 	mov	r2,#0x00
   50EF                    3790 00117$:
                           3791 ;	../../Common/socket.c:514: return retvalue;
                           3792 ;	genRet
   50EF 8A 82              3793 	mov	dpl,r2
   50F1                    3794 00118$:
   50F1 85 10 81           3795 	mov	sp,_bp
   50F4 D0 10              3796 	pop	_bp
   50F6 22                 3797 	ret
                           3798 ;------------------------------------------------------------
                           3799 ;Allocation info for local variables in function 'socket_write'
                           3800 ;------------------------------------------------------------
                           3801 ;buf                       Allocated to stack - offset -5
                           3802 ;si                        Allocated to registers r2 r3 r4 
                           3803 ;------------------------------------------------------------
                           3804 ;	../../Common/socket.c:527: portCHAR socket_write (socket_t *si, buffer_t *buf)
                           3805 ;	-----------------------------------------
                           3806 ;	 function socket_write
                           3807 ;	-----------------------------------------
   50F7                    3808 _socket_write:
   50F7 C0 10              3809 	push	_bp
   50F9 85 81 10           3810 	mov	_bp,sp
                           3811 ;	genReceive
   50FC AA 82              3812 	mov	r2,dpl
   50FE AB 83              3813 	mov	r3,dph
   5100 AC F0              3814 	mov	r4,b
                           3815 ;	../../Common/socket.c:529: return socket_sendto(si, &(si->sa), buf);
                           3816 ;	genPlus
                           3817 ;     genPlusIncr
   5102 74 06              3818 	mov	a,#0x06
                           3819 ;	Peephole 236.a	used r2 instead of ar2
   5104 2A                 3820 	add	a,r2
   5105 FD                 3821 	mov	r5,a
                           3822 ;	Peephole 181	changed mov to clr
   5106 E4                 3823 	clr	a
                           3824 ;	Peephole 236.b	used r3 instead of ar3
   5107 3B                 3825 	addc	a,r3
   5108 FE                 3826 	mov	r6,a
   5109 8C 07              3827 	mov	ar7,r4
                           3828 ;	genIpush
   510B E5 10              3829 	mov	a,_bp
   510D 24 FB              3830 	add	a,#0xfffffffb
   510F F8                 3831 	mov	r0,a
   5110 E6                 3832 	mov	a,@r0
   5111 C0 E0              3833 	push	acc
   5113 08                 3834 	inc	r0
   5114 E6                 3835 	mov	a,@r0
   5115 C0 E0              3836 	push	acc
   5117 08                 3837 	inc	r0
   5118 E6                 3838 	mov	a,@r0
   5119 C0 E0              3839 	push	acc
                           3840 ;	genIpush
   511B C0 05              3841 	push	ar5
   511D C0 06              3842 	push	ar6
   511F C0 07              3843 	push	ar7
                           3844 ;	genCall
   5121 8A 82              3845 	mov	dpl,r2
   5123 8B 83              3846 	mov	dph,r3
   5125 8C F0              3847 	mov	b,r4
   5127 12 4E 2A           3848 	lcall	_socket_sendto
   512A AA 82              3849 	mov	r2,dpl
   512C E5 81              3850 	mov	a,sp
   512E 24 FA              3851 	add	a,#0xfa
   5130 F5 81              3852 	mov	sp,a
                           3853 ;	genRet
   5132 8A 82              3854 	mov	dpl,r2
                           3855 ;	Peephole 300	removed redundant label 00101$
   5134 D0 10              3856 	pop	_bp
   5136 22                 3857 	ret
                           3858 ;------------------------------------------------------------
                           3859 ;Allocation info for local variables in function 'socket_connect'
                           3860 ;------------------------------------------------------------
                           3861 ;dst                       Allocated to stack - offset -5
                           3862 ;si                        Allocated to registers r2 r3 r4 
                           3863 ;------------------------------------------------------------
                           3864 ;	../../Common/socket.c:544: portCHAR socket_connect(socket_t *si, sockaddr_t *dst)
                           3865 ;	-----------------------------------------
                           3866 ;	 function socket_connect
                           3867 ;	-----------------------------------------
   5137                    3868 _socket_connect:
   5137 C0 10              3869 	push	_bp
   5139 85 81 10           3870 	mov	_bp,sp
                           3871 ;	genReceive
   513C AA 82              3872 	mov	r2,dpl
   513E AB 83              3873 	mov	r3,dph
   5140 AC F0              3874 	mov	r4,b
                           3875 ;	../../Common/socket.c:546: memcpy(&(si->sa), dst, sizeof(sockaddr_t));
                           3876 ;	genPlus
                           3877 ;     genPlusIncr
   5142 74 06              3878 	mov	a,#0x06
                           3879 ;	Peephole 236.a	used r2 instead of ar2
   5144 2A                 3880 	add	a,r2
   5145 FD                 3881 	mov	r5,a
                           3882 ;	Peephole 181	changed mov to clr
   5146 E4                 3883 	clr	a
                           3884 ;	Peephole 236.b	used r3 instead of ar3
   5147 3B                 3885 	addc	a,r3
   5148 FE                 3886 	mov	r6,a
   5149 8C 07              3887 	mov	ar7,r4
                           3888 ;	genIpush
   514B C0 02              3889 	push	ar2
   514D C0 03              3890 	push	ar3
   514F C0 04              3891 	push	ar4
   5151 74 0D              3892 	mov	a,#0x0D
   5153 C0 E0              3893 	push	acc
                           3894 ;	Peephole 181	changed mov to clr
   5155 E4                 3895 	clr	a
   5156 C0 E0              3896 	push	acc
                           3897 ;	genIpush
   5158 E5 10              3898 	mov	a,_bp
   515A 24 FB              3899 	add	a,#0xfffffffb
   515C F8                 3900 	mov	r0,a
   515D E6                 3901 	mov	a,@r0
   515E C0 E0              3902 	push	acc
   5160 08                 3903 	inc	r0
   5161 E6                 3904 	mov	a,@r0
   5162 C0 E0              3905 	push	acc
   5164 08                 3906 	inc	r0
   5165 E6                 3907 	mov	a,@r0
   5166 C0 E0              3908 	push	acc
                           3909 ;	genCall
   5168 8D 82              3910 	mov	dpl,r5
   516A 8E 83              3911 	mov	dph,r6
   516C 8F F0              3912 	mov	b,r7
   516E 12 E2 C7           3913 	lcall	_memcpy
   5171 E5 81              3914 	mov	a,sp
   5173 24 FB              3915 	add	a,#0xfb
   5175 F5 81              3916 	mov	sp,a
   5177 D0 04              3917 	pop	ar4
   5179 D0 03              3918 	pop	ar3
   517B D0 02              3919 	pop	ar2
                           3920 ;	../../Common/socket.c:547: si->listen = 0;
                           3921 ;	genPlus
                           3922 ;     genPlusIncr
   517D 74 02              3923 	mov	a,#0x02
                           3924 ;	Peephole 236.a	used r2 instead of ar2
   517F 2A                 3925 	add	a,r2
   5180 FD                 3926 	mov	r5,a
                           3927 ;	Peephole 181	changed mov to clr
   5181 E4                 3928 	clr	a
                           3929 ;	Peephole 236.b	used r3 instead of ar3
   5182 3B                 3930 	addc	a,r3
   5183 FE                 3931 	mov	r6,a
   5184 8C 07              3932 	mov	ar7,r4
                           3933 ;	genPointerSet
                           3934 ;	genGenPointerSet
   5186 8D 82              3935 	mov	dpl,r5
   5188 8E 83              3936 	mov	dph,r6
   518A 8F F0              3937 	mov	b,r7
                           3938 ;	Peephole 181	changed mov to clr
   518C E4                 3939 	clr	a
   518D 12 DF B7           3940 	lcall	__gptrput
   5190 A3                 3941 	inc	dptr
                           3942 ;	Peephole 181	changed mov to clr
   5191 E4                 3943 	clr	a
   5192 12 DF B7           3944 	lcall	__gptrput
                           3945 ;	../../Common/socket.c:548: if (si->port == 0)
                           3946 ;	genPlus
                           3947 ;     genPlusIncr
   5195 74 04              3948 	mov	a,#0x04
                           3949 ;	Peephole 236.a	used r2 instead of ar2
   5197 2A                 3950 	add	a,r2
   5198 FD                 3951 	mov	r5,a
                           3952 ;	Peephole 181	changed mov to clr
   5199 E4                 3953 	clr	a
                           3954 ;	Peephole 236.b	used r3 instead of ar3
   519A 3B                 3955 	addc	a,r3
   519B FE                 3956 	mov	r6,a
   519C 8C 07              3957 	mov	ar7,r4
                           3958 ;	genPointerGet
                           3959 ;	genGenPointerGet
   519E 8D 82              3960 	mov	dpl,r5
   51A0 8E 83              3961 	mov	dph,r6
   51A2 8F F0              3962 	mov	b,r7
   51A4 12 E4 9F           3963 	lcall	__gptrget
   51A7 FD                 3964 	mov	r5,a
   51A8 A3                 3965 	inc	dptr
   51A9 12 E4 9F           3966 	lcall	__gptrget
                           3967 ;	genIfx
   51AC FE                 3968 	mov	r6,a
                           3969 ;	Peephole 135	removed redundant mov
   51AD 4D                 3970 	orl	a,r5
                           3971 ;	genIfxJump
                           3972 ;	Peephole 108.b	removed ljmp by inverse jump logic
   51AE 70 09              3973 	jnz	00102$
                           3974 ;	Peephole 300	removed redundant label 00106$
                           3975 ;	../../Common/socket.c:550: socket_port_random(si);
                           3976 ;	genCall
   51B0 8A 82              3977 	mov	dpl,r2
   51B2 8B 83              3978 	mov	dph,r3
   51B4 8C F0              3979 	mov	b,r4
   51B6 12 52 A8           3980 	lcall	_socket_port_random
   51B9                    3981 00102$:
                           3982 ;	../../Common/socket.c:558: return pdTRUE;
                           3983 ;	genRet
   51B9 75 82 01           3984 	mov	dpl,#0x01
                           3985 ;	Peephole 300	removed redundant label 00103$
   51BC D0 10              3986 	pop	_bp
   51BE 22                 3987 	ret
                           3988 ;------------------------------------------------------------
                           3989 ;Allocation info for local variables in function 'socket_accept'
                           3990 ;------------------------------------------------------------
                           3991 ;dst                       Allocated to stack - offset -5
                           3992 ;sock_handler              Allocated to stack - offset -7
                           3993 ;si                        Allocated to registers r2 r3 r4 
                           3994 ;new_si                    Allocated to stack - offset 1
                           3995 ;------------------------------------------------------------
                           3996 ;	../../Common/socket.c:572: socket_t *socket_accept(socket_t *si, sockaddr_t *dst,
                           3997 ;	-----------------------------------------
                           3998 ;	 function socket_accept
                           3999 ;	-----------------------------------------
   51BF                    4000 _socket_accept:
   51BF C0 10              4001 	push	_bp
   51C1 85 81 10           4002 	mov	_bp,sp
   51C4 05 81              4003 	inc	sp
   51C6 05 81              4004 	inc	sp
   51C8 05 81              4005 	inc	sp
                           4006 ;	genReceive
                           4007 ;	../../Common/socket.c:577: new_si = socket(si->protocol, sock_handler);
                           4008 ;	genPointerGet
                           4009 ;	genGenPointerGet
   51CA AA 82              4010 	mov	r2,dpl
   51CC AB 83              4011 	mov	r3,dph
   51CE AC F0              4012 	mov	r4,b
                           4013 ;	Peephole 238.d	removed 3 redundant moves
   51D0 12 E4 9F           4014 	lcall	__gptrget
   51D3 FD                 4015 	mov	r5,a
                           4016 ;	genIpush
   51D4 C0 02              4017 	push	ar2
   51D6 C0 03              4018 	push	ar3
   51D8 C0 04              4019 	push	ar4
   51DA E5 10              4020 	mov	a,_bp
   51DC 24 F9              4021 	add	a,#0xfffffff9
   51DE F8                 4022 	mov	r0,a
   51DF E6                 4023 	mov	a,@r0
   51E0 C0 E0              4024 	push	acc
   51E2 08                 4025 	inc	r0
   51E3 E6                 4026 	mov	a,@r0
   51E4 C0 E0              4027 	push	acc
                           4028 ;	genCall
   51E6 8D 82              4029 	mov	dpl,r5
   51E8 12 44 95           4030 	lcall	_socket
   51EB AD 82              4031 	mov	r5,dpl
   51ED AE 83              4032 	mov	r6,dph
   51EF AF F0              4033 	mov	r7,b
   51F1 15 81              4034 	dec	sp
   51F3 15 81              4035 	dec	sp
   51F5 D0 04              4036 	pop	ar4
   51F7 D0 03              4037 	pop	ar3
   51F9 D0 02              4038 	pop	ar2
                           4039 ;	genAssign
   51FB A8 10              4040 	mov	r0,_bp
   51FD 08                 4041 	inc	r0
   51FE A6 05              4042 	mov	@r0,ar5
   5200 08                 4043 	inc	r0
   5201 A6 06              4044 	mov	@r0,ar6
   5203 08                 4045 	inc	r0
   5204 A6 07              4046 	mov	@r0,ar7
                           4047 ;	../../Common/socket.c:578: if (new_si)
                           4048 ;	genIfx
   5206 A8 10              4049 	mov	r0,_bp
   5208 08                 4050 	inc	r0
   5209 E6                 4051 	mov	a,@r0
   520A 08                 4052 	inc	r0
   520B 46                 4053 	orl	a,@r0
   520C 08                 4054 	inc	r0
   520D 46                 4055 	orl	a,@r0
                           4056 ;	genIfxJump
   520E 70 03              4057 	jnz	00106$
   5210 02 52 97           4058 	ljmp	00102$
   5213                    4059 00106$:
                           4060 ;	../../Common/socket.c:580: new_si->port = si->port;
                           4061 ;	genPlus
   5213 A8 10              4062 	mov	r0,_bp
   5215 08                 4063 	inc	r0
                           4064 ;     genPlusIncr
   5216 74 04              4065 	mov	a,#0x04
   5218 26                 4066 	add	a,@r0
   5219 FD                 4067 	mov	r5,a
                           4068 ;	Peephole 181	changed mov to clr
   521A E4                 4069 	clr	a
   521B 08                 4070 	inc	r0
   521C 36                 4071 	addc	a,@r0
   521D FE                 4072 	mov	r6,a
   521E 08                 4073 	inc	r0
   521F 86 07              4074 	mov	ar7,@r0
                           4075 ;	genPlus
                           4076 ;     genPlusIncr
   5221 74 04              4077 	mov	a,#0x04
                           4078 ;	Peephole 236.a	used r2 instead of ar2
   5223 2A                 4079 	add	a,r2
   5224 FA                 4080 	mov	r2,a
                           4081 ;	Peephole 181	changed mov to clr
   5225 E4                 4082 	clr	a
                           4083 ;	Peephole 236.b	used r3 instead of ar3
   5226 3B                 4084 	addc	a,r3
   5227 FB                 4085 	mov	r3,a
                           4086 ;	genPointerGet
                           4087 ;	genGenPointerGet
   5228 8A 82              4088 	mov	dpl,r2
   522A 8B 83              4089 	mov	dph,r3
   522C 8C F0              4090 	mov	b,r4
   522E 12 E4 9F           4091 	lcall	__gptrget
   5231 FA                 4092 	mov	r2,a
   5232 A3                 4093 	inc	dptr
   5233 12 E4 9F           4094 	lcall	__gptrget
   5236 FB                 4095 	mov	r3,a
                           4096 ;	genPointerSet
                           4097 ;	genGenPointerSet
   5237 8D 82              4098 	mov	dpl,r5
   5239 8E 83              4099 	mov	dph,r6
   523B 8F F0              4100 	mov	b,r7
   523D EA                 4101 	mov	a,r2
   523E 12 DF B7           4102 	lcall	__gptrput
   5241 A3                 4103 	inc	dptr
   5242 EB                 4104 	mov	a,r3
   5243 12 DF B7           4105 	lcall	__gptrput
                           4106 ;	../../Common/socket.c:581: memcpy(&(new_si->sa), dst, sizeof(sockaddr_t));
                           4107 ;	genPlus
   5246 A8 10              4108 	mov	r0,_bp
   5248 08                 4109 	inc	r0
                           4110 ;     genPlusIncr
   5249 74 06              4111 	mov	a,#0x06
   524B 26                 4112 	add	a,@r0
   524C FA                 4113 	mov	r2,a
                           4114 ;	Peephole 181	changed mov to clr
   524D E4                 4115 	clr	a
   524E 08                 4116 	inc	r0
   524F 36                 4117 	addc	a,@r0
   5250 FB                 4118 	mov	r3,a
   5251 08                 4119 	inc	r0
   5252 86 04              4120 	mov	ar4,@r0
                           4121 ;	genIpush
   5254 74 0D              4122 	mov	a,#0x0D
   5256 C0 E0              4123 	push	acc
                           4124 ;	Peephole 181	changed mov to clr
   5258 E4                 4125 	clr	a
   5259 C0 E0              4126 	push	acc
                           4127 ;	genIpush
   525B E5 10              4128 	mov	a,_bp
   525D 24 FB              4129 	add	a,#0xfffffffb
   525F F8                 4130 	mov	r0,a
   5260 E6                 4131 	mov	a,@r0
   5261 C0 E0              4132 	push	acc
   5263 08                 4133 	inc	r0
   5264 E6                 4134 	mov	a,@r0
   5265 C0 E0              4135 	push	acc
   5267 08                 4136 	inc	r0
   5268 E6                 4137 	mov	a,@r0
   5269 C0 E0              4138 	push	acc
                           4139 ;	genCall
   526B 8A 82              4140 	mov	dpl,r2
   526D 8B 83              4141 	mov	dph,r3
   526F 8C F0              4142 	mov	b,r4
   5271 12 E2 C7           4143 	lcall	_memcpy
   5274 E5 81              4144 	mov	a,sp
   5276 24 FB              4145 	add	a,#0xfb
   5278 F5 81              4146 	mov	sp,a
                           4147 ;	../../Common/socket.c:582: new_si->listen = 0;
                           4148 ;	genPlus
   527A A8 10              4149 	mov	r0,_bp
   527C 08                 4150 	inc	r0
                           4151 ;     genPlusIncr
   527D 74 02              4152 	mov	a,#0x02
   527F 26                 4153 	add	a,@r0
   5280 FA                 4154 	mov	r2,a
                           4155 ;	Peephole 181	changed mov to clr
   5281 E4                 4156 	clr	a
   5282 08                 4157 	inc	r0
   5283 36                 4158 	addc	a,@r0
   5284 FB                 4159 	mov	r3,a
   5285 08                 4160 	inc	r0
   5286 86 04              4161 	mov	ar4,@r0
                           4162 ;	genPointerSet
                           4163 ;	genGenPointerSet
   5288 8A 82              4164 	mov	dpl,r2
   528A 8B 83              4165 	mov	dph,r3
   528C 8C F0              4166 	mov	b,r4
                           4167 ;	Peephole 181	changed mov to clr
   528E E4                 4168 	clr	a
   528F 12 DF B7           4169 	lcall	__gptrput
   5292 A3                 4170 	inc	dptr
                           4171 ;	Peephole 181	changed mov to clr
   5293 E4                 4172 	clr	a
   5294 12 DF B7           4173 	lcall	__gptrput
   5297                    4174 00102$:
                           4175 ;	../../Common/socket.c:584: return new_si;	
                           4176 ;	genRet
   5297 A8 10              4177 	mov	r0,_bp
   5299 08                 4178 	inc	r0
   529A 86 82              4179 	mov	dpl,@r0
   529C 08                 4180 	inc	r0
   529D 86 83              4181 	mov	dph,@r0
   529F 08                 4182 	inc	r0
   52A0 86 F0              4183 	mov	b,@r0
                           4184 ;	Peephole 300	removed redundant label 00103$
   52A2 85 10 81           4185 	mov	sp,_bp
   52A5 D0 10              4186 	pop	_bp
   52A7 22                 4187 	ret
                           4188 ;------------------------------------------------------------
                           4189 ;Allocation info for local variables in function 'socket_port_random'
                           4190 ;------------------------------------------------------------
                           4191 ;si                        Allocated to stack - offset 1
                           4192 ;new_port                  Allocated to stack - offset 4
                           4193 ;i                         Allocated to registers r2 
                           4194 ;found                     Allocated to registers r7 
                           4195 ;sloc0                     Allocated to stack - offset 6
                           4196 ;------------------------------------------------------------
                           4197 ;	../../Common/socket.c:593: void socket_port_random(socket_t *si)
                           4198 ;	-----------------------------------------
                           4199 ;	 function socket_port_random
                           4200 ;	-----------------------------------------
   52A8                    4201 _socket_port_random:
   52A8 C0 10              4202 	push	_bp
   52AA 85 81 10           4203 	mov	_bp,sp
                           4204 ;     genReceive
   52AD C0 82              4205 	push	dpl
   52AF C0 83              4206 	push	dph
   52B1 C0 F0              4207 	push	b
   52B3 E5 81              4208 	mov	a,sp
   52B5 24 07              4209 	add	a,#0x07
   52B7 F5 81              4210 	mov	sp,a
                           4211 ;	../../Common/socket.c:595: uint16_t new_port = 253;
                           4212 ;	genAssign
   52B9 E5 10              4213 	mov	a,_bp
   52BB 24 04              4214 	add	a,#0x04
   52BD F8                 4215 	mov	r0,a
   52BE 76 FD              4216 	mov	@r0,#0xFD
   52C0 E4                 4217 	clr	a
   52C1 08                 4218 	inc	r0
   52C2 F6                 4219 	mov	@r0,a
                           4220 ;	../../Common/socket.c:597: uint8_t found = 0;
                           4221 ;	genAssign
   52C3 7F 00              4222 	mov	r7,#0x00
                           4223 ;	../../Common/socket.c:598: while (!found)
   52C5                    4224 00104$:
                           4225 ;	genIfx
   52C5 EF                 4226 	mov	a,r7
                           4227 ;	genIfxJump
   52C6 60 03              4228 	jz	00118$
   52C8 02 53 48           4229 	ljmp	00106$
   52CB                    4230 00118$:
                           4231 ;	../../Common/socket.c:600: found = 1;
                           4232 ;	genAssign
   52CB 7F 01              4233 	mov	r7,#0x01
                           4234 ;	../../Common/socket.c:601: for (i=0; i<SOCKETS_MAX; i++)
                           4235 ;	genAssign
   52CD 7A 00              4236 	mov	r2,#0x00
                           4237 ;	genAssign
   52CF E5 10              4238 	mov	a,_bp
   52D1 24 04              4239 	add	a,#0x04
   52D3 F8                 4240 	mov	r0,a
   52D4 86 03              4241 	mov	ar3,@r0
   52D6 08                 4242 	inc	r0
   52D7 86 04              4243 	mov	ar4,@r0
   52D9                    4244 00107$:
                           4245 ;	genCmpLt
                           4246 ;	genCmp
   52D9 BA 04 00           4247 	cjne	r2,#0x04,00119$
   52DC                    4248 00119$:
                           4249 ;	genIfxJump
                           4250 ;	Peephole 108.a	removed ljmp by inverse jump logic
   52DC 50 E7              4251 	jnc	00104$
                           4252 ;	Peephole 300	removed redundant label 00120$
                           4253 ;	../../Common/socket.c:603: if ( ((sockets[i].port) == new_port) || ((sockets[i].listen) == new_port) )
                           4254 ;	genIpush
   52DE C0 07              4255 	push	ar7
                           4256 ;	genMult
                           4257 ;	genMultOneByte
   52E0 EA                 4258 	mov	a,r2
   52E1 75 F0 18           4259 	mov	b,#0x18
   52E4 A4                 4260 	mul	ab
                           4261 ;	genPlus
   52E5 A8 10              4262 	mov	r0,_bp
   52E7 08                 4263 	inc	r0
   52E8 08                 4264 	inc	r0
   52E9 08                 4265 	inc	r0
   52EA 08                 4266 	inc	r0
   52EB 08                 4267 	inc	r0
   52EC 08                 4268 	inc	r0
   52ED 24 58              4269 	add	a,#_sockets
   52EF F6                 4270 	mov	@r0,a
                           4271 ;	Peephole 240	use clr instead of addc a,#0
   52F0 E4                 4272 	clr	a
   52F1 34 EF              4273 	addc	a,#(_sockets >> 8)
   52F3 08                 4274 	inc	r0
   52F4 F6                 4275 	mov	@r0,a
                           4276 ;	genPlus
   52F5 E5 10              4277 	mov	a,_bp
   52F7 24 06              4278 	add	a,#0x06
   52F9 F8                 4279 	mov	r0,a
                           4280 ;     genPlusIncr
   52FA 86 82              4281 	mov	dpl,@r0
   52FC 08                 4282 	inc	r0
   52FD 86 83              4283 	mov	dph,@r0
   52FF A3                 4284 	inc	dptr
   5300 A3                 4285 	inc	dptr
   5301 A3                 4286 	inc	dptr
   5302 A3                 4287 	inc	dptr
                           4288 ;	genPointerGet
                           4289 ;	genFarPointerGet
   5303 E0                 4290 	movx	a,@dptr
   5304 FF                 4291 	mov	r7,a
   5305 A3                 4292 	inc	dptr
   5306 E0                 4293 	movx	a,@dptr
   5307 FD                 4294 	mov	r5,a
                           4295 ;	genCmpEq
                           4296 ;	gencjne
                           4297 ;	gencjneshort
   5308 EF                 4298 	mov	a,r7
   5309 B5 03 08           4299 	cjne	a,ar3,00121$
   530C ED                 4300 	mov	a,r5
   530D B5 04 04           4301 	cjne	a,ar4,00121$
   5310 74 01              4302 	mov	a,#0x01
   5312 80 01              4303 	sjmp	00122$
   5314                    4304 00121$:
   5314 E4                 4305 	clr	a
   5315                    4306 00122$:
                           4307 ;	genIpop
   5315 D0 07              4308 	pop	ar7
                           4309 ;	genIfx
                           4310 ;	genIfxJump
                           4311 ;	Peephole 108.b	removed ljmp by inverse jump logic
   5317 70 19              4312 	jnz	00101$
                           4313 ;	Peephole 300	removed redundant label 00123$
                           4314 ;	genPlus
   5319 E5 10              4315 	mov	a,_bp
   531B 24 06              4316 	add	a,#0x06
   531D F8                 4317 	mov	r0,a
                           4318 ;     genPlusIncr
   531E 86 82              4319 	mov	dpl,@r0
   5320 08                 4320 	inc	r0
   5321 86 83              4321 	mov	dph,@r0
   5323 A3                 4322 	inc	dptr
   5324 A3                 4323 	inc	dptr
                           4324 ;	genPointerGet
                           4325 ;	genFarPointerGet
   5325 E0                 4326 	movx	a,@dptr
   5326 FD                 4327 	mov	r5,a
   5327 A3                 4328 	inc	dptr
   5328 E0                 4329 	movx	a,@dptr
   5329 FE                 4330 	mov	r6,a
                           4331 ;	genCmpEq
                           4332 ;	gencjneshort
   532A ED                 4333 	mov	a,r5
                           4334 ;	Peephole 112.b	changed ljmp to sjmp
                           4335 ;	Peephole 197.b	optimized misc jump sequence
   532B B5 03 17           4336 	cjne	a,ar3,00109$
   532E EE                 4337 	mov	a,r6
   532F B5 04 13           4338 	cjne	a,ar4,00109$
                           4339 ;	Peephole 200.b	removed redundant sjmp
                           4340 ;	Peephole 300	removed redundant label 00124$
                           4341 ;	Peephole 300	removed redundant label 00125$
   5332                    4342 00101$:
                           4343 ;	../../Common/socket.c:605: new_port--;
                           4344 ;	genMinus
                           4345 ;	genMinusDec
   5332 1B                 4346 	dec	r3
   5333 BB FF 01           4347 	cjne	r3,#0xff,00126$
   5336 1C                 4348 	dec	r4
   5337                    4349 00126$:
                           4350 ;	genAssign
   5337 E5 10              4351 	mov	a,_bp
   5339 24 04              4352 	add	a,#0x04
   533B F8                 4353 	mov	r0,a
   533C A6 03              4354 	mov	@r0,ar3
   533E 08                 4355 	inc	r0
   533F A6 04              4356 	mov	@r0,ar4
                           4357 ;	../../Common/socket.c:606: found = 0;
                           4358 ;	genAssign
   5341 7F 00              4359 	mov	r7,#0x00
                           4360 ;	../../Common/socket.c:607: i = SOCKETS_MAX;
                           4361 ;	genAssign
   5343 7A 04              4362 	mov	r2,#0x04
   5345                    4363 00109$:
                           4364 ;	../../Common/socket.c:601: for (i=0; i<SOCKETS_MAX; i++)
                           4365 ;	genPlus
                           4366 ;     genPlusIncr
   5345 0A                 4367 	inc	r2
                           4368 ;	Peephole 112.b	changed ljmp to sjmp
   5346 80 91              4369 	sjmp	00107$
   5348                    4370 00106$:
                           4371 ;	../../Common/socket.c:612: si->port = new_port;
                           4372 ;	genPlus
   5348 A8 10              4373 	mov	r0,_bp
   534A 08                 4374 	inc	r0
                           4375 ;     genPlusIncr
   534B 74 04              4376 	mov	a,#0x04
   534D 26                 4377 	add	a,@r0
   534E FA                 4378 	mov	r2,a
                           4379 ;	Peephole 181	changed mov to clr
   534F E4                 4380 	clr	a
   5350 08                 4381 	inc	r0
   5351 36                 4382 	addc	a,@r0
   5352 FB                 4383 	mov	r3,a
   5353 08                 4384 	inc	r0
   5354 86 04              4385 	mov	ar4,@r0
                           4386 ;	genPointerSet
                           4387 ;	genGenPointerSet
   5356 8A 82              4388 	mov	dpl,r2
   5358 8B 83              4389 	mov	dph,r3
   535A 8C F0              4390 	mov	b,r4
   535C E5 10              4391 	mov	a,_bp
   535E 24 04              4392 	add	a,#0x04
   5360 F8                 4393 	mov	r0,a
   5361 E6                 4394 	mov	a,@r0
   5362 12 DF B7           4395 	lcall	__gptrput
   5365 A3                 4396 	inc	dptr
   5366 08                 4397 	inc	r0
   5367 E6                 4398 	mov	a,@r0
   5368 12 DF B7           4399 	lcall	__gptrput
                           4400 ;	Peephole 300	removed redundant label 00111$
   536B 85 10 81           4401 	mov	sp,_bp
   536E D0 10              4402 	pop	_bp
   5370 22                 4403 	ret
                           4404 ;------------------------------------------------------------
                           4405 ;Allocation info for local variables in function 'socket_read'
                           4406 ;------------------------------------------------------------
                           4407 ;time                      Allocated to stack - offset -4
                           4408 ;si                        Allocated to registers r2 r3 r4 
                           4409 ;i                         Allocated to registers r5 
                           4410 ;b                         Allocated to stack - offset 1
                           4411 ;sloc0                     Allocated to stack - offset 4
                           4412 ;------------------------------------------------------------
                           4413 ;	../../Common/socket.c:625: buffer_t *socket_read(socket_t * si, uint16_t time)
                           4414 ;	-----------------------------------------
                           4415 ;	 function socket_read
                           4416 ;	-----------------------------------------
   5371                    4417 _socket_read:
   5371 C0 10              4418 	push	_bp
                           4419 ;	peephole 177.h	optimized mov sequence
   5373 E5 81              4420 	mov	a,sp
   5375 F5 10              4421 	mov	_bp,a
   5377 24 06              4422 	add	a,#0x06
   5379 F5 81              4423 	mov	sp,a
                           4424 ;	genReceive
                           4425 ;	../../Common/socket.c:630: i = socket_id_find(si);
                           4426 ;	genCall
   537B AA 82              4427 	mov	r2,dpl
   537D AB 83              4428 	mov	r3,dph
   537F AC F0              4429 	mov	r4,b
                           4430 ;	Peephole 238.d	removed 3 redundant moves
   5381 C0 02              4431 	push	ar2
   5383 C0 03              4432 	push	ar3
   5385 C0 04              4433 	push	ar4
   5387 12 49 11           4434 	lcall	_socket_id_find
   538A AD 82              4435 	mov	r5,dpl
   538C D0 04              4436 	pop	ar4
   538E D0 03              4437 	pop	ar3
   5390 D0 02              4438 	pop	ar2
                           4439 ;	genAssign
                           4440 ;	../../Common/socket.c:631: if (i >= 0)
                           4441 ;	genCmpLt
                           4442 ;	genCmp
   5392 ED                 4443 	mov	a,r5
                           4444 ;	genIfxJump
                           4445 ;	Peephole 108.e	removed ljmp by inverse jump logic
   5393 20 E7 73           4446 	jb	acc.7,00105$
                           4447 ;	Peephole 300	removed redundant label 00111$
                           4448 ;	../../Common/socket.c:633: if ( (si->queue) && 
                           4449 ;	genPlus
                           4450 ;     genPlusIncr
   5396 74 13              4451 	mov	a,#0x13
                           4452 ;	Peephole 236.a	used r2 instead of ar2
   5398 2A                 4453 	add	a,r2
   5399 FA                 4454 	mov	r2,a
                           4455 ;	Peephole 181	changed mov to clr
   539A E4                 4456 	clr	a
                           4457 ;	Peephole 236.b	used r3 instead of ar3
   539B 3B                 4458 	addc	a,r3
   539C FB                 4459 	mov	r3,a
                           4460 ;	genPointerGet
                           4461 ;	genGenPointerGet
   539D 8A 82              4462 	mov	dpl,r2
   539F 8B 83              4463 	mov	dph,r3
   53A1 8C F0              4464 	mov	b,r4
   53A3 E5 10              4465 	mov	a,_bp
   53A5 24 04              4466 	add	a,#0x04
   53A7 F8                 4467 	mov	r0,a
   53A8 12 E4 9F           4468 	lcall	__gptrget
   53AB F6                 4469 	mov	@r0,a
   53AC A3                 4470 	inc	dptr
   53AD 12 E4 9F           4471 	lcall	__gptrget
   53B0 08                 4472 	inc	r0
   53B1 F6                 4473 	mov	@r0,a
   53B2 A3                 4474 	inc	dptr
   53B3 12 E4 9F           4475 	lcall	__gptrget
   53B6 08                 4476 	inc	r0
   53B7 F6                 4477 	mov	@r0,a
                           4478 ;	genIfx
   53B8 E5 10              4479 	mov	a,_bp
   53BA 24 04              4480 	add	a,#0x04
   53BC F8                 4481 	mov	r0,a
   53BD E6                 4482 	mov	a,@r0
   53BE 08                 4483 	inc	r0
   53BF 46                 4484 	orl	a,@r0
   53C0 08                 4485 	inc	r0
   53C1 46                 4486 	orl	a,@r0
                           4487 ;	genIfxJump
                           4488 ;	Peephole 108.c	removed ljmp by inverse jump logic
   53C2 60 45              4489 	jz	00105$
                           4490 ;	Peephole 300	removed redundant label 00112$
                           4491 ;	../../Common/socket.c:634: (xQueueReceive(si->queue, &(b), time / portTICK_RATE_MS) == pdTRUE) )
                           4492 ;	genCast
   53C4 E5 10              4493 	mov	a,_bp
   53C6 24 FC              4494 	add	a,#0xfffffffc
   53C8 F8                 4495 	mov	r0,a
   53C9 86 05              4496 	mov	ar5,@r0
   53CB 08                 4497 	inc	r0
   53CC 86 06              4498 	mov	ar6,@r0
                           4499 ;	genCast
                           4500 ;	genAddrOf
                           4501 ;	Peephole 3.c	changed mov to clr
   53CE E4                 4502 	clr	a
   53CF FF                 4503 	mov	r7,a
                           4504 ;	Peephole 212	reduced add sequence to inc
                           4505 ;	Peephole 177.c	removed redundant move
   53D0 AA 10              4506 	mov	r2,_bp
   53D2 0A                 4507 	inc	r2
                           4508 ;	genCast
   53D3 7B 00              4509 	mov	r3,#0x00
   53D5 7C 40              4510 	mov	r4,#0x40
                           4511 ;	genIpush
   53D7 C0 05              4512 	push	ar5
   53D9 C0 06              4513 	push	ar6
                           4514 ;	genIpush
   53DB C0 02              4515 	push	ar2
   53DD C0 03              4516 	push	ar3
   53DF C0 04              4517 	push	ar4
                           4518 ;	genCall
   53E1 E5 10              4519 	mov	a,_bp
   53E3 24 04              4520 	add	a,#0x04
   53E5 F8                 4521 	mov	r0,a
   53E6 86 82              4522 	mov	dpl,@r0
   53E8 08                 4523 	inc	r0
   53E9 86 83              4524 	mov	dph,@r0
   53EB 08                 4525 	inc	r0
   53EC 86 F0              4526 	mov	b,@r0
   53EE 12 23 5A           4527 	lcall	_xQueueReceive
   53F1 AA 82              4528 	mov	r2,dpl
   53F3 E5 81              4529 	mov	a,sp
   53F5 24 FB              4530 	add	a,#0xfb
   53F7 F5 81              4531 	mov	sp,a
                           4532 ;	genCmpEq
                           4533 ;	gencjneshort
                           4534 ;	Peephole 112.b	changed ljmp to sjmp
                           4535 ;	Peephole 198.b	optimized misc jump sequence
   53F9 BA 01 0D           4536 	cjne	r2,#0x01,00105$
                           4537 ;	Peephole 200.b	removed redundant sjmp
                           4538 ;	Peephole 300	removed redundant label 00113$
                           4539 ;	Peephole 300	removed redundant label 00114$
                           4540 ;	../../Common/socket.c:636: return b;
                           4541 ;	genRet
   53FC A8 10              4542 	mov	r0,_bp
   53FE 08                 4543 	inc	r0
   53FF 86 82              4544 	mov	dpl,@r0
   5401 08                 4545 	inc	r0
   5402 86 83              4546 	mov	dph,@r0
   5404 08                 4547 	inc	r0
   5405 86 F0              4548 	mov	b,@r0
                           4549 ;	Peephole 112.b	changed ljmp to sjmp
   5407 80 06              4550 	sjmp	00106$
   5409                    4551 00105$:
                           4552 ;	../../Common/socket.c:639: return 0;
                           4553 ;	genRet
                           4554 ;	Peephole 182.b	used 16 bit load of dptr
   5409 90 00 00           4555 	mov	dptr,#0x0000
   540C 75 F0 00           4556 	mov	b,#0x00
   540F                    4557 00106$:
   540F 85 10 81           4558 	mov	sp,_bp
   5412 D0 10              4559 	pop	_bp
   5414 22                 4560 	ret
                           4561 ;------------------------------------------------------------
                           4562 ;Allocation info for local variables in function 'socket_up'
                           4563 ;------------------------------------------------------------
                           4564 ;b                         Allocated to stack - offset 1
                           4565 ;psocket                   Allocated to registers r2 r3 r4 
                           4566 ;sloc0                     Allocated to stack - offset 7
                           4567 ;sloc1                     Allocated to stack - offset 10
                           4568 ;------------------------------------------------------------
                           4569 ;	../../Common/socket.c:651: portCHAR socket_up(buffer_t *b)
                           4570 ;	-----------------------------------------
                           4571 ;	 function socket_up
                           4572 ;	-----------------------------------------
   5415                    4573 _socket_up:
   5415 C0 10              4574 	push	_bp
   5417 85 81 10           4575 	mov	_bp,sp
                           4576 ;     genReceive
   541A C0 82              4577 	push	dpl
   541C C0 83              4578 	push	dph
   541E C0 F0              4579 	push	b
                           4580 ;	../../Common/socket.c:655: if (b->socket == 0)
                           4581 ;	genAssign
   5420 A8 10              4582 	mov	r0,_bp
   5422 08                 4583 	inc	r0
   5423 86 02              4584 	mov	ar2,@r0
   5425 08                 4585 	inc	r0
   5426 86 03              4586 	mov	ar3,@r0
   5428 08                 4587 	inc	r0
   5429 86 04              4588 	mov	ar4,@r0
                           4589 ;	genPointerGet
                           4590 ;	genGenPointerGet
   542B 8A 82              4591 	mov	dpl,r2
   542D 8B 83              4592 	mov	dph,r3
   542F 8C F0              4593 	mov	b,r4
   5431 12 E4 9F           4594 	lcall	__gptrget
   5434 FD                 4595 	mov	r5,a
   5435 A3                 4596 	inc	dptr
   5436 12 E4 9F           4597 	lcall	__gptrget
   5439 FE                 4598 	mov	r6,a
   543A A3                 4599 	inc	dptr
   543B 12 E4 9F           4600 	lcall	__gptrget
   543E FF                 4601 	mov	r7,a
                           4602 ;	genIfx
   543F ED                 4603 	mov	a,r5
   5440 4E                 4604 	orl	a,r6
   5441 4F                 4605 	orl	a,r7
                           4606 ;	genIfxJump
                           4607 ;	Peephole 108.b	removed ljmp by inverse jump logic
   5442 70 41              4608 	jnz	00102$
                           4609 ;	Peephole 300	removed redundant label 00119$
                           4610 ;	../../Common/socket.c:656: psocket = socket_find(b->dst_sa.port, &(b->src_sa));
                           4611 ;	genPlus
                           4612 ;     genPlusIncr
   5444 74 10              4613 	mov	a,#0x10
                           4614 ;	Peephole 236.a	used r2 instead of ar2
   5446 2A                 4615 	add	a,r2
   5447 FD                 4616 	mov	r5,a
                           4617 ;	Peephole 181	changed mov to clr
   5448 E4                 4618 	clr	a
                           4619 ;	Peephole 236.b	used r3 instead of ar3
   5449 3B                 4620 	addc	a,r3
   544A FE                 4621 	mov	r6,a
   544B 8C 07              4622 	mov	ar7,r4
                           4623 ;	genPlus
                           4624 ;     genPlusIncr
   544D 74 03              4625 	mov	a,#0x03
                           4626 ;	Peephole 236.a	used r2 instead of ar2
   544F 2A                 4627 	add	a,r2
   5450 FA                 4628 	mov	r2,a
                           4629 ;	Peephole 181	changed mov to clr
   5451 E4                 4630 	clr	a
                           4631 ;	Peephole 236.b	used r3 instead of ar3
   5452 3B                 4632 	addc	a,r3
   5453 FB                 4633 	mov	r3,a
                           4634 ;	genPlus
                           4635 ;     genPlusIncr
   5454 74 0B              4636 	mov	a,#0x0B
                           4637 ;	Peephole 236.a	used r2 instead of ar2
   5456 2A                 4638 	add	a,r2
   5457 FA                 4639 	mov	r2,a
                           4640 ;	Peephole 181	changed mov to clr
   5458 E4                 4641 	clr	a
                           4642 ;	Peephole 236.b	used r3 instead of ar3
   5459 3B                 4643 	addc	a,r3
   545A FB                 4644 	mov	r3,a
                           4645 ;	genPointerGet
                           4646 ;	genGenPointerGet
   545B 8A 82              4647 	mov	dpl,r2
   545D 8B 83              4648 	mov	dph,r3
   545F 8C F0              4649 	mov	b,r4
   5461 12 E4 9F           4650 	lcall	__gptrget
   5464 FA                 4651 	mov	r2,a
   5465 A3                 4652 	inc	dptr
   5466 12 E4 9F           4653 	lcall	__gptrget
   5469 FB                 4654 	mov	r3,a
                           4655 ;	genIpush
   546A C0 05              4656 	push	ar5
   546C C0 06              4657 	push	ar6
   546E C0 07              4658 	push	ar7
                           4659 ;	genCall
   5470 8A 82              4660 	mov	dpl,r2
   5472 8B 83              4661 	mov	dph,r3
   5474 12 49 49           4662 	lcall	_socket_find
   5477 AA 82              4663 	mov	r2,dpl
   5479 AB 83              4664 	mov	r3,dph
   547B AC F0              4665 	mov	r4,b
   547D 15 81              4666 	dec	sp
   547F 15 81              4667 	dec	sp
   5481 15 81              4668 	dec	sp
                           4669 ;	genAssign
                           4670 ;	Peephole 112.b	changed ljmp to sjmp
   5483 80 06              4671 	sjmp	00103$
   5485                    4672 00102$:
                           4673 ;	../../Common/socket.c:658: psocket = (socket_t *) b->socket;
                           4674 ;	genAssign
                           4675 ;	genAssign
   5485 8D 02              4676 	mov	ar2,r5
   5487 8E 03              4677 	mov	ar3,r6
   5489 8F 04              4678 	mov	ar4,r7
   548B                    4679 00103$:
                           4680 ;	../../Common/socket.c:660: if (psocket != 0)
                           4681 ;	genCmpEq
                           4682 ;	gencjneshort
   548B BA 00 09           4683 	cjne	r2,#0x00,00120$
   548E BB 00 06           4684 	cjne	r3,#0x00,00120$
   5491 BC 00 03           4685 	cjne	r4,#0x00,00120$
   5494 02 55 33           4686 	ljmp	00111$
   5497                    4687 00120$:
                           4688 ;	../../Common/socket.c:662: if  ((psocket->callback) != 0)
                           4689 ;	genPlus
                           4690 ;     genPlusIncr
   5497 74 16              4691 	mov	a,#0x16
                           4692 ;	Peephole 236.a	used r2 instead of ar2
   5499 2A                 4693 	add	a,r2
   549A FD                 4694 	mov	r5,a
                           4695 ;	Peephole 181	changed mov to clr
   549B E4                 4696 	clr	a
                           4697 ;	Peephole 236.b	used r3 instead of ar3
   549C 3B                 4698 	addc	a,r3
   549D FE                 4699 	mov	r6,a
   549E 8C 07              4700 	mov	ar7,r4
                           4701 ;	genPointerGet
                           4702 ;	genGenPointerGet
   54A0 8D 82              4703 	mov	dpl,r5
   54A2 8E 83              4704 	mov	dph,r6
   54A4 8F F0              4705 	mov	b,r7
   54A6 12 E4 9F           4706 	lcall	__gptrget
   54A9 FD                 4707 	mov	r5,a
   54AA A3                 4708 	inc	dptr
   54AB 12 E4 9F           4709 	lcall	__gptrget
   54AE FE                 4710 	mov	r6,a
                           4711 ;	genCmpEq
                           4712 ;	gencjneshort
   54AF BD 00 05           4713 	cjne	r5,#0x00,00121$
   54B2 BE 00 02           4714 	cjne	r6,#0x00,00121$
                           4715 ;	Peephole 112.b	changed ljmp to sjmp
   54B5 80 2B              4716 	sjmp	00108$
   54B7                    4717 00121$:
                           4718 ;	../../Common/socket.c:667: psocket->callback((void *)b);
                           4719 ;	genAssign
   54B7 A8 10              4720 	mov	r0,_bp
   54B9 08                 4721 	inc	r0
   54BA 86 02              4722 	mov	ar2,@r0
   54BC 08                 4723 	inc	r0
   54BD 86 03              4724 	mov	ar3,@r0
   54BF 08                 4725 	inc	r0
   54C0 86 04              4726 	mov	ar4,@r0
                           4727 ;	genPcall
   54C2 C0 05              4728 	push	ar5
   54C4 C0 06              4729 	push	ar6
   54C6 74 D9              4730 	mov	a,#00122$
   54C8 C0 E0              4731 	push	acc
   54CA 74 54              4732 	mov	a,#(00122$ >> 8)
   54CC C0 E0              4733 	push	acc
   54CE C0 05              4734 	push	ar5
   54D0 C0 06              4735 	push	ar6
   54D2 8A 82              4736 	mov	dpl,r2
   54D4 8B 83              4737 	mov	dph,r3
   54D6 8C F0              4738 	mov	b,r4
   54D8 22                 4739 	ret
   54D9                    4740 00122$:
   54D9 D0 06              4741 	pop	ar6
   54DB D0 05              4742 	pop	ar5
                           4743 ;	../../Common/socket.c:668: return pdTRUE;
                           4744 ;	genRet
   54DD 75 82 01           4745 	mov	dpl,#0x01
                           4746 ;	Peephole 112.b	changed ljmp to sjmp
   54E0 80 54              4747 	sjmp	00112$
   54E2                    4748 00108$:
                           4749 ;	../../Common/socket.c:670: else if ( (psocket->queue != 0) && (xQueueSend( psocket->queue, ( void * ) &b, ( portTickType ) 0 )==pdTRUE) )
                           4750 ;	genPlus
                           4751 ;     genPlusIncr
   54E2 74 13              4752 	mov	a,#0x13
                           4753 ;	Peephole 236.a	used r2 instead of ar2
   54E4 2A                 4754 	add	a,r2
   54E5 FA                 4755 	mov	r2,a
                           4756 ;	Peephole 181	changed mov to clr
   54E6 E4                 4757 	clr	a
                           4758 ;	Peephole 236.b	used r3 instead of ar3
   54E7 3B                 4759 	addc	a,r3
   54E8 FB                 4760 	mov	r3,a
                           4761 ;	genPointerGet
                           4762 ;	genGenPointerGet
   54E9 8A 82              4763 	mov	dpl,r2
   54EB 8B 83              4764 	mov	dph,r3
   54ED 8C F0              4765 	mov	b,r4
   54EF 12 E4 9F           4766 	lcall	__gptrget
   54F2 FA                 4767 	mov	r2,a
   54F3 A3                 4768 	inc	dptr
   54F4 12 E4 9F           4769 	lcall	__gptrget
   54F7 FB                 4770 	mov	r3,a
   54F8 A3                 4771 	inc	dptr
   54F9 12 E4 9F           4772 	lcall	__gptrget
   54FC FC                 4773 	mov	r4,a
                           4774 ;	genCmpEq
                           4775 ;	gencjneshort
   54FD BA 00 08           4776 	cjne	r2,#0x00,00123$
   5500 BB 00 05           4777 	cjne	r3,#0x00,00123$
   5503 BC 00 02           4778 	cjne	r4,#0x00,00123$
                           4779 ;	Peephole 112.b	changed ljmp to sjmp
   5506 80 2B              4780 	sjmp	00111$
   5508                    4781 00123$:
                           4782 ;	genAddrOf
                           4783 ;	Peephole 212	reduced add sequence to inc
   5508 AD 10              4784 	mov	r5,_bp
   550A 0D                 4785 	inc	r5
                           4786 ;	genCast
   550B 7E 00              4787 	mov	r6,#0x00
   550D 7F 40              4788 	mov	r7,#0x40
                           4789 ;	genIpush
                           4790 ;	Peephole 181	changed mov to clr
   550F E4                 4791 	clr	a
   5510 C0 E0              4792 	push	acc
   5512 C0 E0              4793 	push	acc
                           4794 ;	genIpush
   5514 C0 05              4795 	push	ar5
   5516 C0 06              4796 	push	ar6
   5518 C0 07              4797 	push	ar7
                           4798 ;	genCall
   551A 8A 82              4799 	mov	dpl,r2
   551C 8B 83              4800 	mov	dph,r3
   551E 8C F0              4801 	mov	b,r4
   5520 12 1D 8E           4802 	lcall	_xQueueSend
   5523 AA 82              4803 	mov	r2,dpl
   5525 E5 81              4804 	mov	a,sp
   5527 24 FB              4805 	add	a,#0xfb
   5529 F5 81              4806 	mov	sp,a
                           4807 ;	genCmpEq
                           4808 ;	gencjneshort
                           4809 ;	Peephole 112.b	changed ljmp to sjmp
                           4810 ;	Peephole 198.b	optimized misc jump sequence
   552B BA 01 05           4811 	cjne	r2,#0x01,00111$
                           4812 ;	Peephole 200.b	removed redundant sjmp
                           4813 ;	Peephole 300	removed redundant label 00124$
                           4814 ;	Peephole 300	removed redundant label 00125$
                           4815 ;	../../Common/socket.c:675: return pdTRUE;
                           4816 ;	genRet
   552E 75 82 01           4817 	mov	dpl,#0x01
                           4818 ;	Peephole 112.b	changed ljmp to sjmp
   5531 80 03              4819 	sjmp	00112$
   5533                    4820 00111$:
                           4821 ;	../../Common/socket.c:678: return pdFALSE;
                           4822 ;	genRet
   5533 75 82 00           4823 	mov	dpl,#0x00
   5536                    4824 00112$:
   5536 85 10 81           4825 	mov	sp,_bp
   5539 D0 10              4826 	pop	_bp
   553B 22                 4827 	ret
                           4828 	.area CSEG    (CODE)
                           4829 	.area CONST   (CODE)
                           4830 	.area XINIT   (CODE)
