                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Nov 10 2006)
                              4 ; This file generated Fri Feb  1 13:33:37 2008
                              5 ;--------------------------------------------------------
                              6 	.module port
                              7 	.optsdcc -mmcs51 --model-large
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _IRCON2_P2IF
                             13 	.globl _IRCON2_UTX0IF
                             14 	.globl _IRCON2_UTX1IF
                             15 	.globl _IRCON2_P1IF
                             16 	.globl _IRCON2_WDTIF
                             17 	.globl _CY
                             18 	.globl _AC
                             19 	.globl _F0
                             20 	.globl _RS1
                             21 	.globl _RS0
                             22 	.globl _OV
                             23 	.globl _F1
                             24 	.globl _P
                             25 	.globl _IRCON_DMAIF
                             26 	.globl _IRCON_T1IF
                             27 	.globl _IRCON_T2IF
                             28 	.globl _IRCON_T3IF
                             29 	.globl _IRCON_T4IF
                             30 	.globl _IRCON_P0IF
                             31 	.globl _IRCON_STIF
                             32 	.globl _IEN1_DMAIE
                             33 	.globl _IEN1_T1IE
                             34 	.globl _IEN1_T2IE
                             35 	.globl _IEN1_T3IE
                             36 	.globl _IEN1_T4IE
                             37 	.globl _IEN1_P0IE
                             38 	.globl _IEN0_RFERRIE
                             39 	.globl _IEN0_ADCIE
                             40 	.globl _IEN0_URX0IE
                             41 	.globl _IEN0_URX1IE
                             42 	.globl _IEN0_ENCIE
                             43 	.globl _IEN0_STIE
                             44 	.globl _IEN0_EA
                             45 	.globl _EA
                             46 	.globl _P2_4
                             47 	.globl _P2_3
                             48 	.globl _P2_2
                             49 	.globl _P2_1
                             50 	.globl _P2_0
                             51 	.globl _S0CON_ENCIF_0
                             52 	.globl _S0CON_ENCIF_1
                             53 	.globl _P1_7
                             54 	.globl _P1_6
                             55 	.globl _P1_5
                             56 	.globl _P1_4
                             57 	.globl _P1_3
                             58 	.globl _P1_2
                             59 	.globl _P1_1
                             60 	.globl _P1_0
                             61 	.globl _TCON_IT0
                             62 	.globl _TCON_RFERRIF
                             63 	.globl _TCON_IT1
                             64 	.globl _TCON_URX0IF
                             65 	.globl _TCON_ADCIF
                             66 	.globl _TCON_URX1IF
                             67 	.globl _P0_0
                             68 	.globl _P0_1
                             69 	.globl _P0_2
                             70 	.globl _P0_3
                             71 	.globl _P0_4
                             72 	.globl _P0_5
                             73 	.globl _P0_6
                             74 	.globl _P0_7
                             75 	.globl _P2DIR
                             76 	.globl _P1DIR
                             77 	.globl _P0DIR
                             78 	.globl _U1GCR
                             79 	.globl _U1UCR
                             80 	.globl _U1BAUD
                             81 	.globl _U1BUF
                             82 	.globl _U1CSR
                             83 	.globl _P2INP
                             84 	.globl _P1INP
                             85 	.globl _P2SEL
                             86 	.globl _P1SEL
                             87 	.globl _P0SEL
                             88 	.globl _ADCCFG
                             89 	.globl _PERCFG
                             90 	.globl _B
                             91 	.globl _T4CC1
                             92 	.globl _T4CCTL1
                             93 	.globl _T4CC0
                             94 	.globl _T4CCTL0
                             95 	.globl _T4CTL
                             96 	.globl _T4CNT
                             97 	.globl _RFIF
                             98 	.globl _IRCON2
                             99 	.globl _T1CCTL2
                            100 	.globl _T1CCTL1
                            101 	.globl _T1CCTL0
                            102 	.globl _T1CTL
                            103 	.globl _T1CNTH
                            104 	.globl _T1CNTL
                            105 	.globl _RFST
                            106 	.globl _ACC
                            107 	.globl _T1CC2H
                            108 	.globl _T1CC2L
                            109 	.globl _T1CC1H
                            110 	.globl _T1CC1L
                            111 	.globl _T1CC0H
                            112 	.globl _T1CC0L
                            113 	.globl _RFD
                            114 	.globl _TIMIF
                            115 	.globl _DMAREQ
                            116 	.globl _DMAARM
                            117 	.globl _DMA0CFGH
                            118 	.globl _DMA0CFGL
                            119 	.globl _DMA1CFGH
                            120 	.globl _DMA1CFGL
                            121 	.globl _DMAIRQ
                            122 	.globl _PSW
                            123 	.globl _T3CC1
                            124 	.globl _T3CCTL1
                            125 	.globl _T3CC0
                            126 	.globl _T3CCTL0
                            127 	.globl _T3CTL
                            128 	.globl _T3CNT
                            129 	.globl _WDCTL
                            130 	.globl _T2CON
                            131 	.globl _MEMCTR
                            132 	.globl _CLKCON
                            133 	.globl _U0GCR
                            134 	.globl _U0UCR
                            135 	.globl _T2CNF
                            136 	.globl _U0BAUD
                            137 	.globl _U0BUF
                            138 	.globl _IRCON
                            139 	.globl _SLEEP
                            140 	.globl _RNDH
                            141 	.globl _RNDL
                            142 	.globl _ADCH
                            143 	.globl _ADCL
                            144 	.globl _IP1
                            145 	.globl _IEN1
                            146 	.globl _RCCTL
                            147 	.globl _ADCCON3
                            148 	.globl _ADCCON2
                            149 	.globl _ADCCON1
                            150 	.globl _ENCCS
                            151 	.globl _ENCDO
                            152 	.globl _ENCDI
                            153 	.globl _FWDATA
                            154 	.globl _FCTL
                            155 	.globl _FADDRH
                            156 	.globl _FADDRL
                            157 	.globl _FWT
                            158 	.globl _IP0
                            159 	.globl _IEN0
                            160 	.globl _IE
                            161 	.globl _T2THD
                            162 	.globl _T2TLD
                            163 	.globl _T2CAPHPH
                            164 	.globl _T2CAPLPL
                            165 	.globl _T2OF2
                            166 	.globl _T2OF1
                            167 	.globl _T2OF0
                            168 	.globl _P2
                            169 	.globl _T2PEROF2
                            170 	.globl _T2PEROF1
                            171 	.globl _T2PEROF0
                            172 	.globl _S1CON
                            173 	.globl _IEN2
                            174 	.globl _HSRC
                            175 	.globl _S0CON
                            176 	.globl _ST2
                            177 	.globl _ST1
                            178 	.globl _ST0
                            179 	.globl _T2CMP
                            180 	.globl __XPAGE
                            181 	.globl _DPS
                            182 	.globl _RFIM
                            183 	.globl _P1
                            184 	.globl _P0INP
                            185 	.globl _P1IEN
                            186 	.globl _PICTL
                            187 	.globl _P2IFG
                            188 	.globl _P1IFG
                            189 	.globl _P0IFG
                            190 	.globl _TCON
                            191 	.globl _PCON
                            192 	.globl _U0CSR
                            193 	.globl _DPH1
                            194 	.globl _DPL1
                            195 	.globl _DPH0
                            196 	.globl _DPL0
                            197 	.globl _SP
                            198 	.globl _P0
                            199 	.globl _volatile_ram2
                            200 	.globl _volatile_ram1
                            201 	.globl _RFD_SHADOW
                            202 	.globl _RFSTATUS
                            203 	.globl _CHIPID
                            204 	.globl _CHVER
                            205 	.globl _FSMTC1
                            206 	.globl _RXFIFOCNT
                            207 	.globl _IOCFG3
                            208 	.globl _IOCFG2
                            209 	.globl _IOCFG1
                            210 	.globl _IOCFG0
                            211 	.globl _SHORTADDRL
                            212 	.globl _SHORTADDRH
                            213 	.globl _PANIDL
                            214 	.globl _PANIDH
                            215 	.globl _IEEE_ADDR7
                            216 	.globl _IEEE_ADDR6
                            217 	.globl _IEEE_ADDR5
                            218 	.globl _IEEE_ADDR4
                            219 	.globl _IEEE_ADDR3
                            220 	.globl _IEEE_ADDR2
                            221 	.globl _IEEE_ADDR1
                            222 	.globl _IEEE_ADDR0
                            223 	.globl _DACTSTL
                            224 	.globl _DACTSTH
                            225 	.globl _ADCTSTL
                            226 	.globl _ADCTSTH
                            227 	.globl _FSMSTATE
                            228 	.globl _AGCCTRLL
                            229 	.globl _AGCCTRLH
                            230 	.globl _MANORL
                            231 	.globl _MANORH
                            232 	.globl _MANANDL
                            233 	.globl _MANANDH
                            234 	.globl _FSMTCL
                            235 	.globl _FSMTCH
                            236 	.globl _RFPWR
                            237 	.globl _CSPT
                            238 	.globl _CSPCTRL
                            239 	.globl _CSPZ
                            240 	.globl _CSPY
                            241 	.globl _CSPX
                            242 	.globl _FSCTRLL
                            243 	.globl _FSCTRLH
                            244 	.globl _RXCTRL1L
                            245 	.globl _RXCTRL1H
                            246 	.globl _RXCTRL0L
                            247 	.globl _RXCTRL0H
                            248 	.globl _TXCTRLL
                            249 	.globl _TXCTRLH
                            250 	.globl _SYNCWORDL
                            251 	.globl _SYNCWORDH
                            252 	.globl _RSSIL
                            253 	.globl _RSSIH
                            254 	.globl _MDMCTRL1L
                            255 	.globl _MDMCTRL1H
                            256 	.globl _MDMCTRL0L
                            257 	.globl _MDMCTRL0H
                            258 	.globl _pxRAMStack
                            259 	.globl _pxXRAMStack
                            260 	.globl _ucStackBytes
                            261 	.globl _pxPortInitialiseStack
                            262 	.globl _xPortStartScheduler
                            263 	.globl _vPortEndScheduler
                            264 	.globl _vPortYield
                            265 	.globl _vST_ISR
                            266 ;--------------------------------------------------------
                            267 ; special function registers
                            268 ;--------------------------------------------------------
                            269 	.area RSEG    (DATA)
                    0080    270 _P0	=	0x0080
                    0081    271 _SP	=	0x0081
                    0082    272 _DPL0	=	0x0082
                    0083    273 _DPH0	=	0x0083
                    0084    274 _DPL1	=	0x0084
                    0085    275 _DPH1	=	0x0085
                    0086    276 _U0CSR	=	0x0086
                    0087    277 _PCON	=	0x0087
                    0088    278 _TCON	=	0x0088
                    0089    279 _P0IFG	=	0x0089
                    008A    280 _P1IFG	=	0x008a
                    008B    281 _P2IFG	=	0x008b
                    008C    282 _PICTL	=	0x008c
                    008D    283 _P1IEN	=	0x008d
                    008F    284 _P0INP	=	0x008f
                    0090    285 _P1	=	0x0090
                    0091    286 _RFIM	=	0x0091
                    0092    287 _DPS	=	0x0092
                    0093    288 __XPAGE	=	0x0093
                    0094    289 _T2CMP	=	0x0094
                    0095    290 _ST0	=	0x0095
                    0096    291 _ST1	=	0x0096
                    0097    292 _ST2	=	0x0097
                    0098    293 _S0CON	=	0x0098
                    0099    294 _HSRC	=	0x0099
                    009A    295 _IEN2	=	0x009a
                    009B    296 _S1CON	=	0x009b
                    009C    297 _T2PEROF0	=	0x009c
                    009D    298 _T2PEROF1	=	0x009d
                    009E    299 _T2PEROF2	=	0x009e
                    00A0    300 _P2	=	0x00a0
                    00A1    301 _T2OF0	=	0x00a1
                    00A2    302 _T2OF1	=	0x00a2
                    00A3    303 _T2OF2	=	0x00a3
                    00A4    304 _T2CAPLPL	=	0x00a4
                    00A5    305 _T2CAPHPH	=	0x00a5
                    00A6    306 _T2TLD	=	0x00a6
                    00A7    307 _T2THD	=	0x00a7
                    00A8    308 _IE	=	0x00a8
                    00A8    309 _IEN0	=	0x00a8
                    00A9    310 _IP0	=	0x00a9
                    00AB    311 _FWT	=	0x00ab
                    00AC    312 _FADDRL	=	0x00ac
                    00AD    313 _FADDRH	=	0x00ad
                    00AE    314 _FCTL	=	0x00ae
                    00AF    315 _FWDATA	=	0x00af
                    00B1    316 _ENCDI	=	0x00b1
                    00B2    317 _ENCDO	=	0x00b2
                    00B3    318 _ENCCS	=	0x00b3
                    00B4    319 _ADCCON1	=	0x00b4
                    00B5    320 _ADCCON2	=	0x00b5
                    00B6    321 _ADCCON3	=	0x00b6
                    00B7    322 _RCCTL	=	0x00b7
                    00B8    323 _IEN1	=	0x00b8
                    00B9    324 _IP1	=	0x00b9
                    00BA    325 _ADCL	=	0x00ba
                    00BB    326 _ADCH	=	0x00bb
                    00BC    327 _RNDL	=	0x00bc
                    00BD    328 _RNDH	=	0x00bd
                    00BE    329 _SLEEP	=	0x00be
                    00C0    330 _IRCON	=	0x00c0
                    00C1    331 _U0BUF	=	0x00c1
                    00C2    332 _U0BAUD	=	0x00c2
                    00C3    333 _T2CNF	=	0x00c3
                    00C4    334 _U0UCR	=	0x00c4
                    00C5    335 _U0GCR	=	0x00c5
                    00C6    336 _CLKCON	=	0x00c6
                    00C7    337 _MEMCTR	=	0x00c7
                    00C8    338 _T2CON	=	0x00c8
                    00C9    339 _WDCTL	=	0x00c9
                    00CA    340 _T3CNT	=	0x00ca
                    00CB    341 _T3CTL	=	0x00cb
                    00CC    342 _T3CCTL0	=	0x00cc
                    00CD    343 _T3CC0	=	0x00cd
                    00CE    344 _T3CCTL1	=	0x00ce
                    00CF    345 _T3CC1	=	0x00cf
                    00D0    346 _PSW	=	0x00d0
                    00D1    347 _DMAIRQ	=	0x00d1
                    00D2    348 _DMA1CFGL	=	0x00d2
                    00D3    349 _DMA1CFGH	=	0x00d3
                    00D4    350 _DMA0CFGL	=	0x00d4
                    00D5    351 _DMA0CFGH	=	0x00d5
                    00D6    352 _DMAARM	=	0x00d6
                    00D7    353 _DMAREQ	=	0x00d7
                    00D8    354 _TIMIF	=	0x00d8
                    00D9    355 _RFD	=	0x00d9
                    00DA    356 _T1CC0L	=	0x00da
                    00DB    357 _T1CC0H	=	0x00db
                    00DC    358 _T1CC1L	=	0x00dc
                    00DD    359 _T1CC1H	=	0x00dd
                    00DE    360 _T1CC2L	=	0x00de
                    00DF    361 _T1CC2H	=	0x00df
                    00E0    362 _ACC	=	0x00e0
                    00E1    363 _RFST	=	0x00e1
                    00E2    364 _T1CNTL	=	0x00e2
                    00E3    365 _T1CNTH	=	0x00e3
                    00E4    366 _T1CTL	=	0x00e4
                    00E5    367 _T1CCTL0	=	0x00e5
                    00E6    368 _T1CCTL1	=	0x00e6
                    00E7    369 _T1CCTL2	=	0x00e7
                    00E8    370 _IRCON2	=	0x00e8
                    00E9    371 _RFIF	=	0x00e9
                    00EA    372 _T4CNT	=	0x00ea
                    00EB    373 _T4CTL	=	0x00eb
                    00EC    374 _T4CCTL0	=	0x00ec
                    00ED    375 _T4CC0	=	0x00ed
                    00EE    376 _T4CCTL1	=	0x00ee
                    00EF    377 _T4CC1	=	0x00ef
                    00F0    378 _B	=	0x00f0
                    00F1    379 _PERCFG	=	0x00f1
                    00F2    380 _ADCCFG	=	0x00f2
                    00F3    381 _P0SEL	=	0x00f3
                    00F4    382 _P1SEL	=	0x00f4
                    00F5    383 _P2SEL	=	0x00f5
                    00F6    384 _P1INP	=	0x00f6
                    00F7    385 _P2INP	=	0x00f7
                    00F8    386 _U1CSR	=	0x00f8
                    00F9    387 _U1BUF	=	0x00f9
                    00FA    388 _U1BAUD	=	0x00fa
                    00FB    389 _U1UCR	=	0x00fb
                    00FC    390 _U1GCR	=	0x00fc
                    00FD    391 _P0DIR	=	0x00fd
                    00FE    392 _P1DIR	=	0x00fe
                    00FF    393 _P2DIR	=	0x00ff
                            394 ;--------------------------------------------------------
                            395 ; special function bits
                            396 ;--------------------------------------------------------
                            397 	.area RSEG    (DATA)
                    0087    398 _P0_7	=	0x0087
                    0086    399 _P0_6	=	0x0086
                    0085    400 _P0_5	=	0x0085
                    0084    401 _P0_4	=	0x0084
                    0083    402 _P0_3	=	0x0083
                    0082    403 _P0_2	=	0x0082
                    0081    404 _P0_1	=	0x0081
                    0080    405 _P0_0	=	0x0080
                    008F    406 _TCON_URX1IF	=	0x008f
                    008D    407 _TCON_ADCIF	=	0x008d
                    008B    408 _TCON_URX0IF	=	0x008b
                    008A    409 _TCON_IT1	=	0x008a
                    0089    410 _TCON_RFERRIF	=	0x0089
                    0088    411 _TCON_IT0	=	0x0088
                    0090    412 _P1_0	=	0x0090
                    0091    413 _P1_1	=	0x0091
                    0092    414 _P1_2	=	0x0092
                    0093    415 _P1_3	=	0x0093
                    0094    416 _P1_4	=	0x0094
                    0095    417 _P1_5	=	0x0095
                    0096    418 _P1_6	=	0x0096
                    0097    419 _P1_7	=	0x0097
                    0099    420 _S0CON_ENCIF_1	=	0x0099
                    0098    421 _S0CON_ENCIF_0	=	0x0098
                    00A0    422 _P2_0	=	0x00a0
                    00A1    423 _P2_1	=	0x00a1
                    00A2    424 _P2_2	=	0x00a2
                    00A3    425 _P2_3	=	0x00a3
                    00A4    426 _P2_4	=	0x00a4
                    00AF    427 _EA	=	0x00af
                    00AF    428 _IEN0_EA	=	0x00af
                    00AD    429 _IEN0_STIE	=	0x00ad
                    00AC    430 _IEN0_ENCIE	=	0x00ac
                    00AB    431 _IEN0_URX1IE	=	0x00ab
                    00AA    432 _IEN0_URX0IE	=	0x00aa
                    00A9    433 _IEN0_ADCIE	=	0x00a9
                    00A8    434 _IEN0_RFERRIE	=	0x00a8
                    00BD    435 _IEN1_P0IE	=	0x00bd
                    00BC    436 _IEN1_T4IE	=	0x00bc
                    00BB    437 _IEN1_T3IE	=	0x00bb
                    00BA    438 _IEN1_T2IE	=	0x00ba
                    00B9    439 _IEN1_T1IE	=	0x00b9
                    00B8    440 _IEN1_DMAIE	=	0x00b8
                    00C7    441 _IRCON_STIF	=	0x00c7
                    00C5    442 _IRCON_P0IF	=	0x00c5
                    00C4    443 _IRCON_T4IF	=	0x00c4
                    00C3    444 _IRCON_T3IF	=	0x00c3
                    00C2    445 _IRCON_T2IF	=	0x00c2
                    00C1    446 _IRCON_T1IF	=	0x00c1
                    00C0    447 _IRCON_DMAIF	=	0x00c0
                    00D0    448 _P	=	0x00d0
                    00D1    449 _F1	=	0x00d1
                    00D2    450 _OV	=	0x00d2
                    00D3    451 _RS0	=	0x00d3
                    00D4    452 _RS1	=	0x00d4
                    00D5    453 _F0	=	0x00d5
                    00D6    454 _AC	=	0x00d6
                    00D7    455 _CY	=	0x00d7
                    00EC    456 _IRCON2_WDTIF	=	0x00ec
                    00EB    457 _IRCON2_P1IF	=	0x00eb
                    00EA    458 _IRCON2_UTX1IF	=	0x00ea
                    00E9    459 _IRCON2_UTX0IF	=	0x00e9
                    00E8    460 _IRCON2_P2IF	=	0x00e8
                            461 ;--------------------------------------------------------
                            462 ; overlayable register banks
                            463 ;--------------------------------------------------------
                            464 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     465 	.ds 8
                            466 ;--------------------------------------------------------
                            467 ; internal ram data
                            468 ;--------------------------------------------------------
                            469 	.area DSEG    (DATA)
   0008                     470 _ucStackBytes::
   0008                     471 	.ds 1
   0009                     472 _ulTimerValue:
   0009                     473 	.ds 4
   000D                     474 _pxXRAMStack::
   000D                     475 	.ds 2
   000F                     476 _pxRAMStack::
   000F                     477 	.ds 1
                            478 ;--------------------------------------------------------
                            479 ; overlayable items in internal ram 
                            480 ;--------------------------------------------------------
                            481 	.area OSEG    (OVR,DATA)
                            482 ;--------------------------------------------------------
                            483 ; indirectly addressable internal ram data
                            484 ;--------------------------------------------------------
                            485 	.area ISEG    (DATA)
                            486 ;--------------------------------------------------------
                            487 ; bit data
                            488 ;--------------------------------------------------------
                            489 	.area BSEG    (BIT)
                            490 ;--------------------------------------------------------
                            491 ; paged external ram data
                            492 ;--------------------------------------------------------
                            493 	.area PSEG    (PAG,XDATA)
                            494 ;--------------------------------------------------------
                            495 ; external ram data
                            496 ;--------------------------------------------------------
                            497 	.area XSEG    (XDATA)
                    DF02    498 _MDMCTRL0H	=	0xdf02
                    DF03    499 _MDMCTRL0L	=	0xdf03
                    DF04    500 _MDMCTRL1H	=	0xdf04
                    DF05    501 _MDMCTRL1L	=	0xdf05
                    DF06    502 _RSSIH	=	0xdf06
                    DF07    503 _RSSIL	=	0xdf07
                    DF08    504 _SYNCWORDH	=	0xdf08
                    DF09    505 _SYNCWORDL	=	0xdf09
                    DF0A    506 _TXCTRLH	=	0xdf0a
                    DF0B    507 _TXCTRLL	=	0xdf0b
                    DF0C    508 _RXCTRL0H	=	0xdf0c
                    DF0D    509 _RXCTRL0L	=	0xdf0d
                    DF0E    510 _RXCTRL1H	=	0xdf0e
                    DF0F    511 _RXCTRL1L	=	0xdf0f
                    DF10    512 _FSCTRLH	=	0xdf10
                    DF11    513 _FSCTRLL	=	0xdf11
                    DF12    514 _CSPX	=	0xdf12
                    DF13    515 _CSPY	=	0xdf13
                    DF14    516 _CSPZ	=	0xdf14
                    DF15    517 _CSPCTRL	=	0xdf15
                    DF16    518 _CSPT	=	0xdf16
                    DF17    519 _RFPWR	=	0xdf17
                    DF20    520 _FSMTCH	=	0xdf20
                    DF21    521 _FSMTCL	=	0xdf21
                    DF22    522 _MANANDH	=	0xdf22
                    DF23    523 _MANANDL	=	0xdf23
                    DF24    524 _MANORH	=	0xdf24
                    DF25    525 _MANORL	=	0xdf25
                    DF26    526 _AGCCTRLH	=	0xdf26
                    DF27    527 _AGCCTRLL	=	0xdf27
                    DF39    528 _FSMSTATE	=	0xdf39
                    DF3A    529 _ADCTSTH	=	0xdf3a
                    DF3B    530 _ADCTSTL	=	0xdf3b
                    DF3C    531 _DACTSTH	=	0xdf3c
                    DF3D    532 _DACTSTL	=	0xdf3d
                    DF43    533 _IEEE_ADDR0	=	0xdf43
                    DF44    534 _IEEE_ADDR1	=	0xdf44
                    DF45    535 _IEEE_ADDR2	=	0xdf45
                    DF46    536 _IEEE_ADDR3	=	0xdf46
                    DF47    537 _IEEE_ADDR4	=	0xdf47
                    DF48    538 _IEEE_ADDR5	=	0xdf48
                    DF49    539 _IEEE_ADDR6	=	0xdf49
                    DF4A    540 _IEEE_ADDR7	=	0xdf4a
                    DF4B    541 _PANIDH	=	0xdf4b
                    DF4C    542 _PANIDL	=	0xdf4c
                    DF4D    543 _SHORTADDRH	=	0xdf4d
                    DF4E    544 _SHORTADDRL	=	0xdf4e
                    DF4F    545 _IOCFG0	=	0xdf4f
                    DF50    546 _IOCFG1	=	0xdf50
                    DF51    547 _IOCFG2	=	0xdf51
                    DF52    548 _IOCFG3	=	0xdf52
                    DF53    549 _RXFIFOCNT	=	0xdf53
                    DF54    550 _FSMTC1	=	0xdf54
                    DF60    551 _CHVER	=	0xdf60
                    DF61    552 _CHIPID	=	0xdf61
                    DF62    553 _RFSTATUS	=	0xdf62
                    DFD9    554 _RFD_SHADOW	=	0xdfd9
                    E000    555 _volatile_ram1	=	0xe000
                    FD58    556 _volatile_ram2	=	0xfd58
                            557 ;--------------------------------------------------------
                            558 ; external initialized ram data
                            559 ;--------------------------------------------------------
                            560 	.area XISEG   (XDATA)
                            561 	.area HOME    (CODE)
                            562 	.area GSINIT0 (CODE)
                            563 	.area GSINIT1 (CODE)
                            564 	.area GSINIT2 (CODE)
                            565 	.area GSINIT3 (CODE)
                            566 	.area GSINIT4 (CODE)
                            567 	.area GSINIT5 (CODE)
                            568 	.area GSINIT  (CODE)
                            569 	.area GSFINAL (CODE)
                            570 	.area CSEG    (CODE)
                            571 ;--------------------------------------------------------
                            572 ; global & static initialisations
                            573 ;--------------------------------------------------------
                            574 	.area HOME    (CODE)
                            575 	.area GSINIT  (CODE)
                            576 	.area GSFINAL (CODE)
                            577 	.area GSINIT  (CODE)
                            578 ;--------------------------------------------------------
                            579 ; Home
                            580 ;--------------------------------------------------------
                            581 	.area HOME    (CODE)
                            582 	.area CSEG    (CODE)
                            583 ;--------------------------------------------------------
                            584 ; code
                            585 ;--------------------------------------------------------
                            586 	.area CSEG    (CODE)
                            587 ;------------------------------------------------------------
                            588 ;Allocation info for local variables in function 'pxPortInitialiseStack'
                            589 ;------------------------------------------------------------
                            590 ;pxCode                    Allocated to stack - offset -4
                            591 ;pvParameters              Allocated to stack - offset -7
                            592 ;pxTopOfStack              Allocated to stack - offset 1
                            593 ;ulAddress                 Allocated to registers r5 r6 r7 r2 
                            594 ;pxStartOfStack            Allocated to stack - offset 4
                            595 ;------------------------------------------------------------
                            596 ;	../../Platform/nano/port.c:133: portSTACK_TYPE *pxPortInitialiseStack( portSTACK_TYPE *pxTopOfStack, pdTASK_CODE pxCode, void *pvParameters )
                            597 ;	-----------------------------------------
                            598 ;	 function pxPortInitialiseStack
                            599 ;	-----------------------------------------
   3149                     600 _pxPortInitialiseStack:
                    0002    601 	ar2 = 0x02
                    0003    602 	ar3 = 0x03
                    0004    603 	ar4 = 0x04
                    0005    604 	ar5 = 0x05
                    0006    605 	ar6 = 0x06
                    0007    606 	ar7 = 0x07
                    0000    607 	ar0 = 0x00
                    0001    608 	ar1 = 0x01
   3149 C0 10               609 	push	_bp
   314B 85 81 10            610 	mov	_bp,sp
                            611 ;     genReceive
   314E C0 82               612 	push	dpl
   3150 C0 83               613 	push	dph
   3152 C0 F0               614 	push	b
   3154 05 81               615 	inc	sp
   3156 05 81               616 	inc	sp
   3158 05 81               617 	inc	sp
                            618 ;	../../Platform/nano/port.c:139: pxStartOfStack = pxTopOfStack;
                            619 ;	genAssign
   315A A8 10               620 	mov	r0,_bp
   315C 08                  621 	inc	r0
   315D E5 10               622 	mov	a,_bp
   315F 24 04               623 	add	a,#0x04
   3161 F9                  624 	mov	r1,a
   3162 E6                  625 	mov	a,@r0
   3163 F7                  626 	mov	@r1,a
   3164 08                  627 	inc	r0
   3165 09                  628 	inc	r1
   3166 E6                  629 	mov	a,@r0
   3167 F7                  630 	mov	@r1,a
   3168 08                  631 	inc	r0
   3169 09                  632 	inc	r1
   316A E6                  633 	mov	a,@r0
   316B F7                  634 	mov	@r1,a
                            635 ;	../../Platform/nano/port.c:140: pxTopOfStack++;
                            636 ;	genPlus
   316C A8 10               637 	mov	r0,_bp
   316E 08                  638 	inc	r0
                            639 ;     genPlusIncr
   316F 74 01               640 	mov	a,#0x01
   3171 26                  641 	add	a,@r0
   3172 F6                  642 	mov	@r0,a
                            643 ;	Peephole 181	changed mov to clr
   3173 E4                  644 	clr	a
   3174 08                  645 	inc	r0
   3175 36                  646 	addc	a,@r0
   3176 F6                  647 	mov	@r0,a
                            648 ;	../../Platform/nano/port.c:156: ulAddress = ( unsigned portLONG ) pxCode;
                            649 ;	genCast
   3177 E5 10               650 	mov	a,_bp
   3179 24 FC               651 	add	a,#0xfffffffc
   317B F8                  652 	mov	r0,a
   317C 86 05               653 	mov	ar5,@r0
   317E 08                  654 	inc	r0
   317F 86 06               655 	mov	ar6,@r0
   3181 7F 00               656 	mov	r7,#0x00
   3183 7A 00               657 	mov	r2,#0x00
                            658 ;	../../Platform/nano/port.c:157: *pxTopOfStack = ( portSTACK_TYPE ) ulAddress;
                            659 ;	genCast
   3185 8D 03               660 	mov	ar3,r5
                            661 ;	genPointerSet
                            662 ;	genGenPointerSet
   3187 A8 10               663 	mov	r0,_bp
   3189 08                  664 	inc	r0
   318A 86 82               665 	mov	dpl,@r0
   318C 08                  666 	inc	r0
   318D 86 83               667 	mov	dph,@r0
   318F 08                  668 	inc	r0
   3190 86 F0               669 	mov	b,@r0
   3192 EB                  670 	mov	a,r3
   3193 12 DF B7            671 	lcall	__gptrput
   3196 A3                  672 	inc	dptr
   3197 18                  673 	dec	r0
   3198 18                  674 	dec	r0
   3199 A6 82               675 	mov	@r0,dpl
   319B 08                  676 	inc	r0
   319C A6 83               677 	mov	@r0,dph
                            678 ;	../../Platform/nano/port.c:158: ulAddress >>= 8;
                            679 ;	genRightShift
                            680 ;	genRightShiftLiteral
                            681 ;	genrshFour
   319E 8E 05               682 	mov	ar5,r6
   31A0 8F 06               683 	mov	ar6,r7
   31A2 8A 07               684 	mov	ar7,r2
   31A4 7A 00               685 	mov	r2,#0x00
                            686 ;	../../Platform/nano/port.c:159: pxTopOfStack++;
                            687 ;	../../Platform/nano/port.c:160: *pxTopOfStack = ( portSTACK_TYPE ) ( ulAddress );
                            688 ;	genCast
   31A6 8D 03               689 	mov	ar3,r5
                            690 ;	genPointerSet
                            691 ;	genGenPointerSet
   31A8 A8 10               692 	mov	r0,_bp
   31AA 08                  693 	inc	r0
   31AB 86 82               694 	mov	dpl,@r0
   31AD 08                  695 	inc	r0
   31AE 86 83               696 	mov	dph,@r0
   31B0 08                  697 	inc	r0
   31B1 86 F0               698 	mov	b,@r0
   31B3 EB                  699 	mov	a,r3
   31B4 12 DF B7            700 	lcall	__gptrput
   31B7 A3                  701 	inc	dptr
   31B8 18                  702 	dec	r0
   31B9 18                  703 	dec	r0
   31BA A6 82               704 	mov	@r0,dpl
   31BC 08                  705 	inc	r0
   31BD A6 83               706 	mov	@r0,dph
                            707 ;	../../Platform/nano/port.c:161: pxTopOfStack++;
                            708 ;	../../Platform/nano/port.c:164: *pxTopOfStack = 0xaa;	/* acc */
                            709 ;	genPointerSet
                            710 ;	genGenPointerSet
   31BF A8 10               711 	mov	r0,_bp
   31C1 08                  712 	inc	r0
   31C2 86 82               713 	mov	dpl,@r0
   31C4 08                  714 	inc	r0
   31C5 86 83               715 	mov	dph,@r0
   31C7 08                  716 	inc	r0
   31C8 86 F0               717 	mov	b,@r0
   31CA 74 AA               718 	mov	a,#0xAA
   31CC 12 DF B7            719 	lcall	__gptrput
   31CF A3                  720 	inc	dptr
   31D0 18                  721 	dec	r0
   31D1 18                  722 	dec	r0
   31D2 A6 82               723 	mov	@r0,dpl
   31D4 08                  724 	inc	r0
   31D5 A6 83               725 	mov	@r0,dph
                            726 ;	../../Platform/nano/port.c:165: pxTopOfStack++;	
                            727 ;	../../Platform/nano/port.c:168: *pxTopOfStack = portGLOBAL_INTERRUPT_BIT;
                            728 ;	genPointerSet
                            729 ;	genGenPointerSet
   31D7 A8 10               730 	mov	r0,_bp
   31D9 08                  731 	inc	r0
   31DA 86 82               732 	mov	dpl,@r0
   31DC 08                  733 	inc	r0
   31DD 86 83               734 	mov	dph,@r0
   31DF 08                  735 	inc	r0
   31E0 86 F0               736 	mov	b,@r0
   31E2 74 80               737 	mov	a,#0x80
   31E4 12 DF B7            738 	lcall	__gptrput
   31E7 A3                  739 	inc	dptr
   31E8 18                  740 	dec	r0
   31E9 18                  741 	dec	r0
   31EA A6 82               742 	mov	@r0,dpl
   31EC 08                  743 	inc	r0
   31ED A6 83               744 	mov	@r0,dph
                            745 ;	../../Platform/nano/port.c:169: pxTopOfStack++;
                            746 ;	../../Platform/nano/port.c:173: ulAddress = ( unsigned portLONG ) pvParameters;
                            747 ;	genCast
   31EF E5 10               748 	mov	a,_bp
   31F1 24 F9               749 	add	a,#0xfffffff9
   31F3 F8                  750 	mov	r0,a
   31F4 86 05               751 	mov	ar5,@r0
   31F6 08                  752 	inc	r0
   31F7 86 06               753 	mov	ar6,@r0
   31F9 08                  754 	inc	r0
   31FA 86 07               755 	mov	ar7,@r0
   31FC 7A 00               756 	mov	r2,#0x00
                            757 ;	../../Platform/nano/port.c:174: *pxTopOfStack = ( portSTACK_TYPE ) ulAddress;	/* DPL */
                            758 ;	genCast
   31FE 8D 03               759 	mov	ar3,r5
                            760 ;	genPointerSet
                            761 ;	genGenPointerSet
   3200 A8 10               762 	mov	r0,_bp
   3202 08                  763 	inc	r0
   3203 86 82               764 	mov	dpl,@r0
   3205 08                  765 	inc	r0
   3206 86 83               766 	mov	dph,@r0
   3208 08                  767 	inc	r0
   3209 86 F0               768 	mov	b,@r0
   320B EB                  769 	mov	a,r3
   320C 12 DF B7            770 	lcall	__gptrput
   320F A3                  771 	inc	dptr
   3210 18                  772 	dec	r0
   3211 18                  773 	dec	r0
   3212 A6 82               774 	mov	@r0,dpl
   3214 08                  775 	inc	r0
   3215 A6 83               776 	mov	@r0,dph
                            777 ;	../../Platform/nano/port.c:175: ulAddress >>= 8;
                            778 ;	genRightShift
                            779 ;	genRightShiftLiteral
                            780 ;	genrshFour
   3217 8E 05               781 	mov	ar5,r6
   3219 8F 06               782 	mov	ar6,r7
   321B 8A 07               783 	mov	ar7,r2
   321D 7A 00               784 	mov	r2,#0x00
                            785 ;	../../Platform/nano/port.c:176: *pxTopOfStack++;
                            786 ;	../../Platform/nano/port.c:177: *pxTopOfStack = ( portSTACK_TYPE ) ulAddress;	/* DPH */
                            787 ;	genCast
   321F 8D 03               788 	mov	ar3,r5
                            789 ;	genPointerSet
                            790 ;	genGenPointerSet
   3221 A8 10               791 	mov	r0,_bp
   3223 08                  792 	inc	r0
   3224 86 82               793 	mov	dpl,@r0
   3226 08                  794 	inc	r0
   3227 86 83               795 	mov	dph,@r0
   3229 08                  796 	inc	r0
   322A 86 F0               797 	mov	b,@r0
   322C EB                  798 	mov	a,r3
   322D 12 DF B7            799 	lcall	__gptrput
   3230 A3                  800 	inc	dptr
   3231 18                  801 	dec	r0
   3232 18                  802 	dec	r0
   3233 A6 82               803 	mov	@r0,dpl
   3235 08                  804 	inc	r0
   3236 A6 83               805 	mov	@r0,dph
                            806 ;	../../Platform/nano/port.c:178: ulAddress >>= 8;
                            807 ;	genRightShift
                            808 ;	genRightShiftLiteral
                            809 ;	genrshFour
   3238 8E 05               810 	mov	ar5,r6
   323A 8F 06               811 	mov	ar6,r7
   323C 8A 07               812 	mov	ar7,r2
   323E 7A 00               813 	mov	r2,#0x00
                            814 ;	../../Platform/nano/port.c:179: pxTopOfStack++;
                            815 ;	../../Platform/nano/port.c:180: *pxTopOfStack = ( portSTACK_TYPE ) ulAddress;	/* b */
                            816 ;	genCast
                            817 ;	genPointerSet
                            818 ;	genGenPointerSet
   3240 A8 10               819 	mov	r0,_bp
   3242 08                  820 	inc	r0
   3243 86 82               821 	mov	dpl,@r0
   3245 08                  822 	inc	r0
   3246 86 83               823 	mov	dph,@r0
   3248 08                  824 	inc	r0
   3249 86 F0               825 	mov	b,@r0
   324B ED                  826 	mov	a,r5
   324C 12 DF B7            827 	lcall	__gptrput
   324F A3                  828 	inc	dptr
   3250 18                  829 	dec	r0
   3251 18                  830 	dec	r0
   3252 A6 82               831 	mov	@r0,dpl
   3254 08                  832 	inc	r0
   3255 A6 83               833 	mov	@r0,dph
                            834 ;	../../Platform/nano/port.c:181: pxTopOfStack++;
                            835 ;	../../Platform/nano/port.c:184: *pxTopOfStack = 0x02;	/* R2 */
                            836 ;	genPointerSet
                            837 ;	genGenPointerSet
   3257 A8 10               838 	mov	r0,_bp
   3259 08                  839 	inc	r0
   325A 86 82               840 	mov	dpl,@r0
   325C 08                  841 	inc	r0
   325D 86 83               842 	mov	dph,@r0
   325F 08                  843 	inc	r0
   3260 86 F0               844 	mov	b,@r0
   3262 74 02               845 	mov	a,#0x02
   3264 12 DF B7            846 	lcall	__gptrput
   3267 A3                  847 	inc	dptr
   3268 18                  848 	dec	r0
   3269 18                  849 	dec	r0
   326A A6 82               850 	mov	@r0,dpl
   326C 08                  851 	inc	r0
   326D A6 83               852 	mov	@r0,dph
                            853 ;	../../Platform/nano/port.c:185: pxTopOfStack++;
                            854 ;	../../Platform/nano/port.c:186: *pxTopOfStack = 0x03;	/* R3 */
                            855 ;	genPointerSet
                            856 ;	genGenPointerSet
   326F A8 10               857 	mov	r0,_bp
   3271 08                  858 	inc	r0
   3272 86 82               859 	mov	dpl,@r0
   3274 08                  860 	inc	r0
   3275 86 83               861 	mov	dph,@r0
   3277 08                  862 	inc	r0
   3278 86 F0               863 	mov	b,@r0
   327A 74 03               864 	mov	a,#0x03
   327C 12 DF B7            865 	lcall	__gptrput
   327F A3                  866 	inc	dptr
   3280 18                  867 	dec	r0
   3281 18                  868 	dec	r0
   3282 A6 82               869 	mov	@r0,dpl
   3284 08                  870 	inc	r0
   3285 A6 83               871 	mov	@r0,dph
                            872 ;	../../Platform/nano/port.c:187: pxTopOfStack++;
                            873 ;	../../Platform/nano/port.c:188: *pxTopOfStack = 0x04;	/* R4 */
                            874 ;	genPointerSet
                            875 ;	genGenPointerSet
   3287 A8 10               876 	mov	r0,_bp
   3289 08                  877 	inc	r0
   328A 86 82               878 	mov	dpl,@r0
   328C 08                  879 	inc	r0
   328D 86 83               880 	mov	dph,@r0
   328F 08                  881 	inc	r0
   3290 86 F0               882 	mov	b,@r0
   3292 74 04               883 	mov	a,#0x04
   3294 12 DF B7            884 	lcall	__gptrput
   3297 A3                  885 	inc	dptr
   3298 18                  886 	dec	r0
   3299 18                  887 	dec	r0
   329A A6 82               888 	mov	@r0,dpl
   329C 08                  889 	inc	r0
   329D A6 83               890 	mov	@r0,dph
                            891 ;	../../Platform/nano/port.c:189: pxTopOfStack++;
                            892 ;	../../Platform/nano/port.c:190: *pxTopOfStack = 0x05;	/* R5 */
                            893 ;	genPointerSet
                            894 ;	genGenPointerSet
   329F A8 10               895 	mov	r0,_bp
   32A1 08                  896 	inc	r0
   32A2 86 82               897 	mov	dpl,@r0
   32A4 08                  898 	inc	r0
   32A5 86 83               899 	mov	dph,@r0
   32A7 08                  900 	inc	r0
   32A8 86 F0               901 	mov	b,@r0
   32AA 74 05               902 	mov	a,#0x05
   32AC 12 DF B7            903 	lcall	__gptrput
   32AF A3                  904 	inc	dptr
   32B0 18                  905 	dec	r0
   32B1 18                  906 	dec	r0
   32B2 A6 82               907 	mov	@r0,dpl
   32B4 08                  908 	inc	r0
   32B5 A6 83               909 	mov	@r0,dph
                            910 ;	../../Platform/nano/port.c:191: pxTopOfStack++;
                            911 ;	../../Platform/nano/port.c:192: *pxTopOfStack = 0x06;	/* R6 */
                            912 ;	genPointerSet
                            913 ;	genGenPointerSet
   32B7 A8 10               914 	mov	r0,_bp
   32B9 08                  915 	inc	r0
   32BA 86 82               916 	mov	dpl,@r0
   32BC 08                  917 	inc	r0
   32BD 86 83               918 	mov	dph,@r0
   32BF 08                  919 	inc	r0
   32C0 86 F0               920 	mov	b,@r0
   32C2 74 06               921 	mov	a,#0x06
   32C4 12 DF B7            922 	lcall	__gptrput
   32C7 A3                  923 	inc	dptr
   32C8 18                  924 	dec	r0
   32C9 18                  925 	dec	r0
   32CA A6 82               926 	mov	@r0,dpl
   32CC 08                  927 	inc	r0
   32CD A6 83               928 	mov	@r0,dph
                            929 ;	../../Platform/nano/port.c:193: pxTopOfStack++;
                            930 ;	../../Platform/nano/port.c:194: *pxTopOfStack = 0x07;	/* R7 */
                            931 ;	genPointerSet
                            932 ;	genGenPointerSet
   32CF A8 10               933 	mov	r0,_bp
   32D1 08                  934 	inc	r0
   32D2 86 82               935 	mov	dpl,@r0
   32D4 08                  936 	inc	r0
   32D5 86 83               937 	mov	dph,@r0
   32D7 08                  938 	inc	r0
   32D8 86 F0               939 	mov	b,@r0
   32DA 74 07               940 	mov	a,#0x07
   32DC 12 DF B7            941 	lcall	__gptrput
   32DF A3                  942 	inc	dptr
   32E0 18                  943 	dec	r0
   32E1 18                  944 	dec	r0
   32E2 A6 82               945 	mov	@r0,dpl
   32E4 08                  946 	inc	r0
   32E5 A6 83               947 	mov	@r0,dph
                            948 ;	../../Platform/nano/port.c:195: pxTopOfStack++;
                            949 ;	../../Platform/nano/port.c:196: *pxTopOfStack = 0x00;	/* R0 */
                            950 ;	genPointerSet
                            951 ;	genGenPointerSet
   32E7 A8 10               952 	mov	r0,_bp
   32E9 08                  953 	inc	r0
   32EA 86 82               954 	mov	dpl,@r0
   32EC 08                  955 	inc	r0
   32ED 86 83               956 	mov	dph,@r0
   32EF 08                  957 	inc	r0
   32F0 86 F0               958 	mov	b,@r0
                            959 ;	Peephole 181	changed mov to clr
   32F2 E4                  960 	clr	a
   32F3 12 DF B7            961 	lcall	__gptrput
   32F6 A3                  962 	inc	dptr
   32F7 18                  963 	dec	r0
   32F8 18                  964 	dec	r0
   32F9 A6 82               965 	mov	@r0,dpl
   32FB 08                  966 	inc	r0
   32FC A6 83               967 	mov	@r0,dph
                            968 ;	../../Platform/nano/port.c:197: pxTopOfStack++;
                            969 ;	../../Platform/nano/port.c:198: *pxTopOfStack = 0x01;	/* R1 */
                            970 ;	genPointerSet
                            971 ;	genGenPointerSet
   32FE A8 10               972 	mov	r0,_bp
   3300 08                  973 	inc	r0
   3301 86 82               974 	mov	dpl,@r0
   3303 08                  975 	inc	r0
   3304 86 83               976 	mov	dph,@r0
   3306 08                  977 	inc	r0
   3307 86 F0               978 	mov	b,@r0
   3309 74 01               979 	mov	a,#0x01
   330B 12 DF B7            980 	lcall	__gptrput
   330E A3                  981 	inc	dptr
   330F 18                  982 	dec	r0
   3310 18                  983 	dec	r0
   3311 A6 82               984 	mov	@r0,dpl
   3313 08                  985 	inc	r0
   3314 A6 83               986 	mov	@r0,dph
                            987 ;	../../Platform/nano/port.c:199: pxTopOfStack++;
                            988 ;	../../Platform/nano/port.c:200: *pxTopOfStack = 0x00;	/* PSW */
                            989 ;	genPointerSet
                            990 ;	genGenPointerSet
   3316 A8 10               991 	mov	r0,_bp
   3318 08                  992 	inc	r0
   3319 86 82               993 	mov	dpl,@r0
   331B 08                  994 	inc	r0
   331C 86 83               995 	mov	dph,@r0
   331E 08                  996 	inc	r0
   331F 86 F0               997 	mov	b,@r0
                            998 ;	Peephole 181	changed mov to clr
   3321 E4                  999 	clr	a
   3322 12 DF B7           1000 	lcall	__gptrput
   3325 A3                 1001 	inc	dptr
   3326 18                 1002 	dec	r0
   3327 18                 1003 	dec	r0
   3328 A6 82              1004 	mov	@r0,dpl
   332A 08                 1005 	inc	r0
   332B A6 83              1006 	mov	@r0,dph
                           1007 ;	../../Platform/nano/port.c:201: pxTopOfStack++;
                           1008 ;	../../Platform/nano/port.c:202: *pxTopOfStack = 0xbb;	/* BP */
                           1009 ;	genPointerSet
                           1010 ;	genGenPointerSet
   332D A8 10              1011 	mov	r0,_bp
   332F 08                 1012 	inc	r0
   3330 86 82              1013 	mov	dpl,@r0
   3332 08                 1014 	inc	r0
   3333 86 83              1015 	mov	dph,@r0
   3335 08                 1016 	inc	r0
   3336 86 F0              1017 	mov	b,@r0
   3338 74 BB              1018 	mov	a,#0xBB
   333A 12 DF B7           1019 	lcall	__gptrput
                           1020 ;	../../Platform/nano/port.c:208: *pxStartOfStack = ( portSTACK_TYPE ) ( pxTopOfStack - pxStartOfStack );
                           1021 ;	genMinus
   333D A8 10              1022 	mov	r0,_bp
   333F 08                 1023 	inc	r0
   3340 E5 10              1024 	mov	a,_bp
   3342 24 04              1025 	add	a,#0x04
   3344 F9                 1026 	mov	r1,a
   3345 E6                 1027 	mov	a,@r0
   3346 C3                 1028 	clr	c
   3347 97                 1029 	subb	a,@r1
   3348 FA                 1030 	mov	r2,a
   3349 08                 1031 	inc	r0
   334A E6                 1032 	mov	a,@r0
   334B 09                 1033 	inc	r1
   334C 97                 1034 	subb	a,@r1
   334D FB                 1035 	mov	r3,a
                           1036 ;	genCast
                           1037 ;	genPointerSet
                           1038 ;	genGenPointerSet
   334E E5 10              1039 	mov	a,_bp
   3350 24 04              1040 	add	a,#0x04
   3352 F8                 1041 	mov	r0,a
   3353 86 82              1042 	mov	dpl,@r0
   3355 08                 1043 	inc	r0
   3356 86 83              1044 	mov	dph,@r0
   3358 08                 1045 	inc	r0
   3359 86 F0              1046 	mov	b,@r0
   335B EA                 1047 	mov	a,r2
   335C 12 DF B7           1048 	lcall	__gptrput
                           1049 ;	../../Platform/nano/port.c:212: return pxStartOfStack;
                           1050 ;	genRet
   335F E5 10              1051 	mov	a,_bp
   3361 24 04              1052 	add	a,#0x04
   3363 F8                 1053 	mov	r0,a
   3364 86 82              1054 	mov	dpl,@r0
   3366 08                 1055 	inc	r0
   3367 86 83              1056 	mov	dph,@r0
   3369 08                 1057 	inc	r0
   336A 86 F0              1058 	mov	b,@r0
                           1059 ;	Peephole 300	removed redundant label 00101$
   336C 85 10 81           1060 	mov	sp,_bp
   336F D0 10              1061 	pop	_bp
   3371 22                 1062 	ret
                           1063 ;------------------------------------------------------------
                           1064 ;Allocation info for local variables in function 'xPortStartScheduler'
                           1065 ;------------------------------------------------------------
                           1066 ;------------------------------------------------------------
                           1067 ;	../../Platform/nano/port.c:219: portBASE_TYPE xPortStartScheduler( void )
                           1068 ;	-----------------------------------------
                           1069 ;	 function xPortStartScheduler
                           1070 ;	-----------------------------------------
   3372                    1071 _xPortStartScheduler:
                           1072 ;	../../Platform/nano/port.c:225: prvSetupTimerInterrupt();	
                           1073 ;	genCall
   3372 12 36 1A           1074 	lcall	_prvSetupTimerInterrupt
                           1075 ;	../../Platform/nano/port.c:233: portCOPY_XRAM_TO_STACK();
                           1076 ;	genAssign
   3375 90 F0 75           1077 	mov	dptr,#_pxCurrentTCB
   3378 E0                 1078 	movx	a,@dptr
   3379 FA                 1079 	mov	r2,a
   337A A3                 1080 	inc	dptr
   337B E0                 1081 	movx	a,@dptr
   337C FB                 1082 	mov	r3,a
   337D A3                 1083 	inc	dptr
   337E E0                 1084 	movx	a,@dptr
   337F FC                 1085 	mov	r4,a
                           1086 ;	genPointerGet
                           1087 ;	genGenPointerGet
   3380 8A 82              1088 	mov	dpl,r2
   3382 8B 83              1089 	mov	dph,r3
   3384 8C F0              1090 	mov	b,r4
   3386 12 E4 9F           1091 	lcall	__gptrget
   3389 F5 0D              1092 	mov	_pxXRAMStack,a
   338B A3                 1093 	inc	dptr
   338C 12 E4 9F           1094 	lcall	__gptrget
   338F F5 0E              1095 	mov	(_pxXRAMStack + 1),a
                           1096 ;	genAssign
   3391 75 0F 21           1097 	mov	_pxRAMStack,#0x21
                           1098 ;	genAssign
   3394 85 0D 82           1099 	mov	dpl,_pxXRAMStack
   3397 85 0E 83           1100 	mov	dph,(_pxXRAMStack + 1)
                           1101 ;	genPointerGet
                           1102 ;	genFarPointerGet
   339A E0                 1103 	movx	a,@dptr
   339B F5 08              1104 	mov	_ucStackBytes,a
   339D                    1105 00101$:
                           1106 ;	genPlus
                           1107 ;     genPlusIncr
   339D 05 0D              1108 	inc	_pxXRAMStack
   339F E4                 1109 	clr	a
   33A0 B5 0D 02           1110 	cjne	a,_pxXRAMStack,00108$
   33A3 05 0E              1111 	inc	(_pxXRAMStack + 1)
   33A5                    1112 00108$:
                           1113 ;	genPlus
                           1114 ;     genPlusIncr
   33A5 05 0F              1115 	inc	_pxRAMStack
                           1116 ;	genAssign
   33A7 A8 0F              1117 	mov	r0,_pxRAMStack
                           1118 ;	genAssign
   33A9 85 0D 82           1119 	mov	dpl,_pxXRAMStack
   33AC 85 0E 83           1120 	mov	dph,(_pxXRAMStack + 1)
                           1121 ;	genPointerGet
                           1122 ;	genFarPointerGet
   33AF E0                 1123 	movx	a,@dptr
                           1124 ;	genPointerSet
                           1125 ;	genNearPointerSet
   33B0 FA                 1126 	mov	r2,a
                           1127 ;	Peephole 192	used a instead of ar2 as source
   33B1 F6                 1128 	mov	@r0,a
                           1129 ;	genMinus
                           1130 ;	genMinusDec
   33B2 15 08              1131 	dec	_ucStackBytes
                           1132 ;	genIfx
   33B4 E5 08              1133 	mov	a,_ucStackBytes
                           1134 ;	genIfxJump
                           1135 ;	Peephole 108.b	removed ljmp by inverse jump logic
   33B6 70 E5              1136 	jnz	00101$
                           1137 ;	Peephole 300	removed redundant label 00109$
                           1138 ;	genCast
   33B8 85 0F 81           1139 	mov	_SP,_pxRAMStack
                           1140 ;	../../Platform/nano/port.c:234: portRESTORE_CONTEXT();
                           1141 ;	genInline
   0272                    1142  pop _bp pop PSW pop ar1 pop ar0 pop ar7 pop ar6 pop ar5 pop ar4 pop ar3 pop ar2 pop b pop DPH pop DPL pop ACC JB ACC.7,0098$ CLR IE.7 LJMP 0099$ 0098$:
   0296                    1143 SETB IE.7 0099$:
   33BB D0 10              1144 	pop ACC 
                           1145 ;	../../Platform/nano/port.c:237: return pdTRUE;
                           1146 ;	genRet
   33BD D0 D0 D0           1147 	mov	dpl,#0x01
                           1148 ;	Peephole 300	removed redundant label 00104$
   33C0 01                 1149 	ret
                           1150 ;------------------------------------------------------------
                           1151 ;Allocation info for local variables in function 'vPortEndScheduler'
                           1152 ;------------------------------------------------------------
                           1153 ;------------------------------------------------------------
                           1154 ;	../../Platform/nano/port.c:241: void vPortEndScheduler( void )
                           1155 ;	-----------------------------------------
                           1156 ;	 function vPortEndScheduler
                           1157 ;	-----------------------------------------
   029E                    1158 _vPortEndScheduler:
                           1159 ;	../../Platform/nano/port.c:244: }
                           1160 ;	Peephole 300	removed redundant label 00101$
   33C1 D0                 1161 	ret
                           1162 ;------------------------------------------------------------
                           1163 ;Allocation info for local variables in function 'vPortYield'
                           1164 ;------------------------------------------------------------
                           1165 ;------------------------------------------------------------
                           1166 ;	../../Platform/nano/port.c:251: void vPortYield( void ) _naked
                           1167 ;	-----------------------------------------
                           1168 ;	 function vPortYield
                           1169 ;	-----------------------------------------
   029F                    1170 _vPortYield:
                           1171 ;	naked function: no prologue.
                           1172 ;	../../Platform/nano/port.c:259: portSAVE_CONTEXT();
                           1173 ;	genInline
   33C2 00 D0 07 D0 06 D0  1174 	 push ACC push IE clr _EA push DPL push DPH push b push ar2 push ar3 push ar4 push ar5 push ar6 push ar7 push ar0 push ar1 push PSW 
        05 D0 04 D0 03 D0
        02 D0 F0 D0 83 D0
        82 D0 E0 20 E7 05
        C2 AF 02 33 E1 D0
                           1175 ;	genAssign
   33DF 75 D0 00           1176 	mov	_PSW,#0x00
                           1177 ;	genInline
   33DF D2 AF              1178 	 push _bp 
                           1179 ;	../../Platform/nano/port.c:260: portCOPY_STACK_TO_XRAM();
                           1180 ;	genAssign
   33E1 90s00r00           1181 	mov	dptr,#_pxCurrentTCB
   33E1 D0                 1182 	movx	a,@dptr
   33E2 E0                 1183 	mov	r2,a
   33E3 75                 1184 	inc	dptr
   33E4 82                 1185 	movx	a,@dptr
   33E5 01                 1186 	mov	r3,a
   33E6 22                 1187 	inc	dptr
   33E7 E0                 1188 	movx	a,@dptr
   33E7 22                 1189 	mov	r4,a
                           1190 ;	genPointerGet
                           1191 ;	genGenPointerGet
   33E8 8A 82              1192 	mov	dpl,r2
   33E8 C0 E0              1193 	mov	dph,r3
   33EA C0 A8              1194 	mov	b,r4
   33EC C2 AF C0           1195 	lcall	__gptrget
   33EF 82 C0              1196 	mov	_pxXRAMStack,a
   33F1 83                 1197 	inc	dptr
   33F2 C0 F0 C0           1198 	lcall	__gptrget
   33F5 02 C0              1199 	mov	(_pxXRAMStack + 1),a
                           1200 ;	genAssign
   33F7 03 C0 04           1201 	mov	_pxRAMStack,#0x22
                           1202 ;	genMinus
   33FA C0 05              1203 	mov	a,_SP
   33FC C0 06              1204 	add	a,#0xdf
                           1205 ;	genAssign
                           1206 ;	genPointerSet
                           1207 ;     genFarPointerSet
   33FE C0 07              1208 	mov	_ucStackBytes,a
   3400 C0 00 C0           1209 	mov	dpl,_pxXRAMStack
   3403 01 C0 D0           1210 	mov	dph,(_pxXRAMStack + 1)
                           1211 ;	Peephole 136	removed redundant move
   3406 75                 1212 	movx	@dptr,a
   02EE                    1213 00101$:
                           1214 ;	genIfx
   3407 D0 00              1215 	mov	a,_ucStackBytes
                           1216 ;	genIfxJump
                           1217 ;	Peephole 108.c	removed ljmp by inverse jump logic
   3409 C0 10              1218 	jz	00103$
                           1219 ;	Peephole 300	removed redundant label 00113$
                           1220 ;	genPlus
                           1221 ;     genPlusIncr
   340B 90 F0              1222 	inc	_pxXRAMStack
   340D 75                 1223 	clr	a
   340E E0 FA A3           1224 	cjne	a,_pxXRAMStack,00114$
   3411 E0 FB              1225 	inc	(_pxXRAMStack + 1)
   02FA                    1226 00114$:
                           1227 ;	genAssign
   3413 A3 E0 FC           1228 	mov	dpl,_pxXRAMStack
   3416 8A 82 8B           1229 	mov	dph,(_pxXRAMStack + 1)
                           1230 ;	genAssign
   3419 83 8C              1231 	mov	r0,_pxRAMStack
                           1232 ;	genPointerGet
                           1233 ;	genNearPointerGet
   341B F0 12              1234 	mov	ar2,@r0
                           1235 ;	genPointerSet
                           1236 ;     genFarPointerSet
   341D E4                 1237 	mov	a,r2
   341E 9F                 1238 	movx	@dptr,a
                           1239 ;	genPlus
                           1240 ;     genPlusIncr
   341F F5 0D              1241 	inc	_pxRAMStack
                           1242 ;	genMinus
                           1243 ;	genMinusDec
   3421 A3 12              1244 	dec	_ucStackBytes
                           1245 ;	Peephole 112.b	changed ljmp to sjmp
   3423 E4 9F              1246 	sjmp	00101$
   030C                    1247 00103$:
                           1248 ;	../../Platform/nano/port.c:263: vTaskSwitchContext();
                           1249 ;	genCall
   3425 F5 0E 75           1250 	lcall	_vTaskSwitchContext
                           1251 ;	../../Platform/nano/port.c:267: portCOPY_XRAM_TO_STACK();
                           1252 ;	genAssign
   3428 0F 22 E5           1253 	mov	dptr,#_pxCurrentTCB
   342B 81                 1254 	movx	a,@dptr
   342C 24                 1255 	mov	r2,a
   342D DF                 1256 	inc	dptr
   342E F5                 1257 	movx	a,@dptr
   342F 08                 1258 	mov	r3,a
   3430 85                 1259 	inc	dptr
   3431 0D                 1260 	movx	a,@dptr
   3432 82                 1261 	mov	r4,a
                           1262 ;	genPointerGet
                           1263 ;	genGenPointerGet
   3433 85 0E              1264 	mov	dpl,r2
   3435 83 F0              1265 	mov	dph,r3
   3437 8C F0              1266 	mov	b,r4
   3437 E5 08 60           1267 	lcall	__gptrget
   343A 1A 05              1268 	mov	_pxXRAMStack,a
   343C 0D                 1269 	inc	dptr
   343D E4 B5 0D           1270 	lcall	__gptrget
   3440 02 05              1271 	mov	(_pxXRAMStack + 1),a
                           1272 ;	genAssign
   3442 0E*07 21           1273 	mov	_pxRAMStack,#0x21
                           1274 ;	genAssign
   3443 85*05 82           1275 	mov	dpl,_pxXRAMStack
   3443 85 0D 82           1276 	mov	dph,(_pxXRAMStack + 1)
                           1277 ;	genPointerGet
                           1278 ;	genFarPointerGet
   3446 85                 1279 	movx	a,@dptr
   3447 0E 83              1280 	mov	_ucStackBytes,a
   0337                    1281 00104$:
                           1282 ;	genPlus
                           1283 ;     genPlusIncr
   3449 A8 0F              1284 	inc	_pxXRAMStack
   344B 86                 1285 	clr	a
   344C 02 EA F0           1286 	cjne	a,_pxXRAMStack,00115$
   344F 05 0F              1287 	inc	(_pxXRAMStack + 1)
   033F                    1288 00115$:
                           1289 ;	genPlus
                           1290 ;     genPlusIncr
   3451 15 08              1291 	inc	_pxRAMStack
                           1292 ;	genAssign
   3453 80 E2              1293 	mov	r0,_pxRAMStack
                           1294 ;	genAssign
   3455 85*05 82           1295 	mov	dpl,_pxXRAMStack
   3455 12 12 75           1296 	mov	dph,(_pxXRAMStack + 1)
                           1297 ;	genPointerGet
                           1298 ;	genFarPointerGet
   3458 90                 1299 	movx	a,@dptr
                           1300 ;	genPointerSet
                           1301 ;	genNearPointerSet
   3459 F0                 1302 	mov	r2,a
                           1303 ;	Peephole 192	used a instead of ar2 as source
   345A 75                 1304 	mov	@r0,a
                           1305 ;	genMinus
                           1306 ;	genMinusDec
   345B E0 FA              1307 	dec	_ucStackBytes
                           1308 ;	genIfx
   345D A3 E0              1309 	mov	a,_ucStackBytes
                           1310 ;	genIfxJump
                           1311 ;	Peephole 108.b	removed ljmp by inverse jump logic
   345F FB A3              1312 	jnz	00104$
                           1313 ;	Peephole 300	removed redundant label 00116$
                           1314 ;	genCast
   3461 E0 FC 8A           1315 	mov	_SP,_pxRAMStack
                           1316 ;	../../Platform/nano/port.c:268: portRESTORE_CONTEXT();
                           1317 ;	genInline
   0355                    1318  pop _bp pop PSW pop ar1 pop ar0 pop ar7 pop ar6 pop ar5 pop ar4 pop ar3 pop ar2 pop b pop DPH pop DPL pop ACC JB ACC.7,0098$ CLR IE.7 LJMP 0099$ 0098$:
   0379                    1319 SETB IE.7 0099$:
   3464 82 8B              1320 	pop ACC 
                           1321 ;	Peephole 300	removed redundant label 00107$
                           1322 ;	naked function: no epilogue.
                           1323 ;------------------------------------------------------------
                           1324 ;Allocation info for local variables in function 'vST_ISR'
                           1325 ;------------------------------------------------------------
                           1326 ;------------------------------------------------------------
                           1327 ;	../../Platform/nano/port.c:277: void vST_ISR( void ) interrupt (ST_VECTOR) _naked
                           1328 ;	-----------------------------------------
                           1329 ;	 function vST_ISR
                           1330 ;	-----------------------------------------
   037D                    1331 _vST_ISR:
                           1332 ;	naked function: no prologue.
                           1333 ;	../../Platform/nano/port.c:279: EA = 0;
                           1334 ;	genAssign
   3466 83 8C              1335 	clr	_EA
                           1336 ;	../../Platform/nano/port.c:284: portSAVE_CONTEXT();
                           1337 ;	genInline
   3468 F0 12 E4 9F F5 0D  1338 	 push ACC push IE clr _EA push DPL push DPH push b push ar2 push ar3 push ar4 push ar5 push ar6 push ar7 push ar0 push ar1 push PSW 
        A3 12 E4 9F F5 0E
        75 0F 21 85 0D 82
        85 0E 83 E0 F5 08
        C0 00 C0 01 C0 D0
                           1339 ;	genAssign
   3480 75 D0 00           1340 	mov	_PSW,#0x00
                           1341 ;	genInline
   3480 05 0D              1342 	 push _bp 
                           1343 ;	../../Platform/nano/port.c:285: portCOPY_STACK_TO_XRAM();
                           1344 ;	genAssign
   3482 E4 B5 0D           1345 	mov	dptr,#_pxCurrentTCB
   3485 02                 1346 	movx	a,@dptr
   3486 05                 1347 	mov	r2,a
   3487 0E                 1348 	inc	dptr
   3488 E0                 1349 	movx	a,@dptr
   3488 05                 1350 	mov	r3,a
   3489 0F                 1351 	inc	dptr
   348A A8                 1352 	movx	a,@dptr
   348B 0F                 1353 	mov	r4,a
                           1354 ;	genPointerGet
                           1355 ;	genGenPointerGet
   348C 85 0D              1356 	mov	dpl,r2
   348E 82 85              1357 	mov	dph,r3
   3490 0E 83              1358 	mov	b,r4
   3492 E0 FA F6           1359 	lcall	__gptrget
   3495 15 08              1360 	mov	_pxXRAMStack,a
   3497 E5                 1361 	inc	dptr
   3498 08 70 E5           1362 	lcall	__gptrget
   349B 85 0F              1363 	mov	(_pxXRAMStack + 1),a
                           1364 ;	genAssign
   349D 81 D0 10           1365 	mov	_pxRAMStack,#0x22
                           1366 ;	genMinus
   34A0 D0 D0              1367 	mov	a,_SP
   34A2 D0 01              1368 	add	a,#0xdf
                           1369 ;	genAssign
                           1370 ;	genPointerSet
                           1371 ;     genFarPointerSet
   34A4 D0 00              1372 	mov	_ucStackBytes,a
   34A6 D0 07 D0           1373 	mov	dpl,_pxXRAMStack
   34A9 06 D0 05           1374 	mov	dph,(_pxXRAMStack + 1)
                           1375 ;	Peephole 136	removed redundant move
   34AC D0                 1376 	movx	@dptr,a
   03CE                    1377 00101$:
                           1378 ;	genIfx
   34AD 04 D0              1379 	mov	a,_ucStackBytes
                           1380 ;	genIfxJump
                           1381 ;	Peephole 108.c	removed ljmp by inverse jump logic
   34AF 03 D0              1382 	jz	00103$
                           1383 ;	Peephole 300	removed redundant label 00113$
                           1384 ;	genPlus
                           1385 ;     genPlusIncr
   34B1 02 D0              1386 	inc	_pxXRAMStack
   34B3 F0                 1387 	clr	a
   34B4 D0 83 D0           1388 	cjne	a,_pxXRAMStack,00114$
   34B7 82 D0              1389 	inc	(_pxXRAMStack + 1)
   03DA                    1390 00114$:
                           1391 ;	genAssign
   34B9 E0 20 E7           1392 	mov	dpl,_pxXRAMStack
   34BC 05 C2 AF           1393 	mov	dph,(_pxXRAMStack + 1)
                           1394 ;	genAssign
   34BF 02 34              1395 	mov	r0,_pxRAMStack
                           1396 ;	genPointerGet
                           1397 ;	genNearPointerGet
   34C1 C4 02              1398 	mov	ar2,@r0
                           1399 ;	genPointerSet
                           1400 ;     genFarPointerSet
   34C2 EA                 1401 	mov	a,r2
   34C2 D2                 1402 	movx	@dptr,a
                           1403 ;	genPlus
                           1404 ;     genPlusIncr
   34C3 AF*07              1405 	inc	_pxRAMStack
                           1406 ;	genMinus
                           1407 ;	genMinusDec
   34C4 15*00              1408 	dec	_ucStackBytes
                           1409 ;	Peephole 112.b	changed ljmp to sjmp
   34C4 D0 E0              1410 	sjmp	00101$
   34C6                    1411 00103$:
                           1412 ;	../../Platform/nano/port.c:287: ulTimerValue = ST0;
                           1413 ;	genCast
   34C6 C2 AF C0           1414 	mov	_ulTimerValue,_ST0
   34C9 E0 C0 A8           1415 	mov	(_ulTimerValue + 1),#0x00
   34CC C2 AF C0           1416 	mov	(_ulTimerValue + 2),#0x00
   34CF 82 C0 83           1417 	mov	(_ulTimerValue + 3),#0x00
                           1418 ;	../../Platform/nano/port.c:288: ulTimerValue += ((unsigned long int)ST1) << 8;
                           1419 ;	genCast
   34D2 C0 F0              1420 	mov	r2,_ST1
   34D4 C0 02              1421 	mov	r3,#0x00
   34D6 C0 03              1422 	mov	r4,#0x00
                           1423 ;	genLeftShift
                           1424 ;	genLeftShiftLiteral
                           1425 ;	genlshFour
                           1426 ;	peephole 177.e	removed redundant move
   34D8 C0 04              1427 	mov	ar5,r4
   34DA C0 05              1428 	mov	ar4,r3
   34DC C0 06              1429 	mov	ar3,r2
                           1430 ;	genPlus
                           1431 ;	Peephole 236.g	used r2 instead of ar2
                           1432 ;	peephole 177.g	optimized mov sequence
                           1433 ;	Peephole 181	changed mov to clr
   34DE C0                 1434 	clr	a
   34DF 07                 1435 	mov	r2,a
   34E0 C0 00              1436 	add	a,_ulTimerValue
   34E2 C0 01              1437 	mov	_ulTimerValue,a
                           1438 ;	Peephole 236.g	used r3 instead of ar3
   34E4 C0                 1439 	mov	a,r3
   34E5 D0 75              1440 	addc	a,(_ulTimerValue + 1)
   34E7 D0 00              1441 	mov	(_ulTimerValue + 1),a
                           1442 ;	Peephole 236.g	used r4 instead of ar4
   34E9 C0                 1443 	mov	a,r4
   34EA 10 90              1444 	addc	a,(_ulTimerValue + 2)
   34EC F0 75              1445 	mov	(_ulTimerValue + 2),a
                           1446 ;	Peephole 236.g	used r5 instead of ar5
   34EE E0                 1447 	mov	a,r5
   34EF FA A3              1448 	addc	a,(_ulTimerValue + 3)
   34F1 E0 FB              1449 	mov	(_ulTimerValue + 3),a
                           1450 ;	../../Platform/nano/port.c:289: ulTimerValue += ((unsigned long int)ST2) << 16;
                           1451 ;	genCast
   34F3 A3 E0              1452 	mov	r2,_ST2
   34F5 FC 8A              1453 	mov	r3,#0x00
   34F7 82 8B              1454 	mov	r4,#0x00
                           1455 ;	genLeftShift
                           1456 ;	genLeftShiftLiteral
                           1457 ;	genlshFour
                           1458 ;	peephole 177.e	removed redundant move
   34F9 83 8C              1459 	mov	ar5,r3
   34FB F0 12              1460 	mov	ar4,r2
                           1461 ;	genPlus
                           1462 ;	Peephole 3.c	changed mov to clr
   34FD E4                 1463 	clr	a
   34FE 9F                 1464 	mov	r3,a
   34FF F5                 1465 	mov	r2,a
                           1466 ;	Peephole 177.b	removed redundant mov
   3500 0D A3              1467 	add	a,_ulTimerValue
   3502 12 E4              1468 	mov	_ulTimerValue,a
                           1469 ;	Peephole 236.g	used r3 instead of ar3
   3504 9F                 1470 	mov	a,r3
   3505 F5 0E              1471 	addc	a,(_ulTimerValue + 1)
   3507 75 0F              1472 	mov	(_ulTimerValue + 1),a
                           1473 ;	Peephole 236.g	used r4 instead of ar4
   3509 22                 1474 	mov	a,r4
   350A E5 81              1475 	addc	a,(_ulTimerValue + 2)
   350C 24 DF              1476 	mov	(_ulTimerValue + 2),a
                           1477 ;	Peephole 236.g	used r5 instead of ar5
   350E F5                 1478 	mov	a,r5
   350F 08 85              1479 	addc	a,(_ulTimerValue + 3)
   3511 0D 82              1480 	mov	(_ulTimerValue + 3),a
                           1481 ;	../../Platform/nano/port.c:290: ulTimerValue += TICK_VAL;
                           1482 ;	genPlus
                           1483 ;     genPlusIncr
   3513 85 0E              1484 	mov	a,#0x20
   3515 83 F0              1485 	add	a,_ulTimerValue
   3517 F5*01              1486 	mov	_ulTimerValue,a
                           1487 ;	Peephole 181	changed mov to clr
   3517 E5                 1488 	clr	a
   3518 08 60              1489 	addc	a,(_ulTimerValue + 1)
   351A 1A 05              1490 	mov	(_ulTimerValue + 1),a
                           1491 ;	Peephole 181	changed mov to clr
   351C 0D                 1492 	clr	a
   351D E4 B5              1493 	addc	a,(_ulTimerValue + 2)
   351F 0D 02              1494 	mov	(_ulTimerValue + 2),a
                           1495 ;	Peephole 181	changed mov to clr
   3521 05                 1496 	clr	a
   3522 0E*04              1497 	addc	a,(_ulTimerValue + 3)
   3523 F5*04              1498 	mov	(_ulTimerValue + 3),a
                           1499 ;	../../Platform/nano/port.c:291: ST2 = (unsigned char) (ulTimerValue >> 16);
                           1500 ;	genGetByte
   3523 85 0D 82           1501 	mov	_ST2,(_ulTimerValue + 2)
                           1502 ;	../../Platform/nano/port.c:292: ST1 = (unsigned char) (ulTimerValue >> 8);
                           1503 ;	genGetByte
   3526 85 0E 83           1504 	mov	_ST1,(_ulTimerValue + 1)
                           1505 ;	../../Platform/nano/port.c:293: ST0 = (unsigned char) ulTimerValue;
                           1506 ;	genCast
   3529 A8 0F 86           1507 	mov	_ST0,_ulTimerValue
                           1508 ;	../../Platform/nano/port.c:295: vTaskIncrementTick();
                           1509 ;	genCall
   352C 02 EA F0           1510 	lcall	_vTaskIncrementTick
                           1511 ;	../../Platform/nano/port.c:296: vTaskSwitchContext();
                           1512 ;	genCall
   352F 05 0F 15           1513 	lcall	_vTaskSwitchContext
                           1514 ;	../../Platform/nano/port.c:299: IRCON &= ~STIF;
                           1515 ;	genAnd
   3532 08 80 E2           1516 	anl	_IRCON,#0x7F
                           1517 ;	../../Platform/nano/port.c:301: portCOPY_XRAM_TO_STACK();
                           1518 ;	genAssign
   3535 90s00r00           1519 	mov	dptr,#_pxCurrentTCB
   3535 85                 1520 	movx	a,@dptr
   3536 95                 1521 	mov	r2,a
   3537 09                 1522 	inc	dptr
   3538 75                 1523 	movx	a,@dptr
   3539 0A                 1524 	mov	r3,a
   353A 00                 1525 	inc	dptr
   353B 75                 1526 	movx	a,@dptr
   353C 0B                 1527 	mov	r4,a
                           1528 ;	genPointerGet
                           1529 ;	genGenPointerGet
   353D 00 75              1530 	mov	dpl,r2
   353F 0C 00              1531 	mov	dph,r3
   3541 AA 96              1532 	mov	b,r4
   3543 7B 00 7C           1533 	lcall	__gptrget
   3546 00 8C              1534 	mov	_pxXRAMStack,a
   3548 05                 1535 	inc	dptr
   3549 8B 04 8A           1536 	lcall	__gptrget
   354C 03 E4              1537 	mov	(_pxXRAMStack + 1),a
                           1538 ;	genAssign
   354E FA 25 09           1539 	mov	_pxRAMStack,#0x21
                           1540 ;	genAssign
   3551 F5 09 EB           1541 	mov	dpl,_pxXRAMStack
   3554 35 0A F5           1542 	mov	dph,(_pxXRAMStack + 1)
                           1543 ;	genPointerGet
                           1544 ;	genFarPointerGet
   3557 0A                 1545 	movx	a,@dptr
   3558 EC 35              1546 	mov	_ucStackBytes,a
   0488                    1547 00104$:
                           1548 ;	genPlus
                           1549 ;     genPlusIncr
   355A 0B F5              1550 	inc	_pxXRAMStack
   355C 0B                 1551 	clr	a
   355D ED 35 0C           1552 	cjne	a,_pxXRAMStack,00115$
   3560 F5 0C              1553 	inc	(_pxXRAMStack + 1)
   0490                    1554 00115$:
                           1555 ;	genPlus
                           1556 ;     genPlusIncr
   3562 AA 97              1557 	inc	_pxRAMStack
                           1558 ;	genAssign
   3564 7B 00              1559 	mov	r0,_pxRAMStack
                           1560 ;	genAssign
   3566 7C 00 8B           1561 	mov	dpl,_pxXRAMStack
   3569 05 8A 04           1562 	mov	dph,(_pxXRAMStack + 1)
                           1563 ;	genPointerGet
                           1564 ;	genFarPointerGet
   356C E4                 1565 	movx	a,@dptr
                           1566 ;	genPointerSet
                           1567 ;	genNearPointerSet
   356D FB                 1568 	mov	r2,a
                           1569 ;	Peephole 192	used a instead of ar2 as source
   356E FA                 1570 	mov	@r0,a
                           1571 ;	genMinus
                           1572 ;	genMinusDec
   356F 25 09              1573 	dec	_ucStackBytes
                           1574 ;	genIfx
   3571 F5 09              1575 	mov	a,_ucStackBytes
                           1576 ;	genIfxJump
                           1577 ;	Peephole 108.b	removed ljmp by inverse jump logic
   3573 EB 35              1578 	jnz	00104$
                           1579 ;	Peephole 300	removed redundant label 00116$
                           1580 ;	genCast
   3575 0A F5 0A           1581 	mov	_SP,_pxRAMStack
                           1582 ;	../../Platform/nano/port.c:302: portRESTORE_CONTEXT();
                           1583 ;	genInline
   04A6                    1584  pop _bp pop PSW pop ar1 pop ar0 pop ar7 pop ar6 pop ar5 pop ar4 pop ar3 pop ar2 pop b pop DPH pop DPL pop ACC JB ACC.7,0098$ CLR IE.7 LJMP 0099$ 0098$:
   04CA                    1585 SETB IE.7 0099$:
   3578 EC 35              1586 	pop ACC 
                           1587 ;	../../Platform/nano/port.c:303: EA = 1;
                           1588 ;	genAssign
   357A 0B F5              1589 	setb	_EA
                           1590 ;	../../Platform/nano/port.c:304: {		\
                           1591 ;	genInline
   357C 0B                 1592 	 reti 
                           1593 ;	Peephole 300	removed redundant label 00107$
                           1594 ;	naked function: no epilogue.
                           1595 ;------------------------------------------------------------
                           1596 ;Allocation info for local variables in function 'prvSetupTimerInterrupt'
                           1597 ;------------------------------------------------------------
                           1598 ;------------------------------------------------------------
                           1599 ;	../../Platform/nano/port.c:334: static void prvSetupTimerInterrupt( void )
                           1600 ;	-----------------------------------------
                           1601 ;	 function prvSetupTimerInterrupt
                           1602 ;	-----------------------------------------
   04D1                    1603 _prvSetupTimerInterrupt:
                           1604 ;	../../Platform/nano/port.c:336: CLKCON = OSC32K |  TICKSPD2|TICKSPD1|TICKSPD0;
                           1605 ;	genAssign
   357D ED 35 0C           1606 	mov	_CLKCON,#0xB8
                           1607 ;	../../Platform/nano/port.c:339: ulTimerValue = ST0;
                           1608 ;	genCast
   3580 F5 0C 74           1609 	mov	_ulTimerValue,_ST0
   3583 20 25 09           1610 	mov	(_ulTimerValue + 1),#0x00
   3586 F5 09 E4           1611 	mov	(_ulTimerValue + 2),#0x00
   3589 35 0A F5           1612 	mov	(_ulTimerValue + 3),#0x00
                           1613 ;	../../Platform/nano/port.c:340: ulTimerValue += ((unsigned long int)ST1) << 8;
                           1614 ;	genCast
   358C 0A E4              1615 	mov	r2,_ST1
   358E 35 0B              1616 	mov	r3,#0x00
   3590 F5 0B              1617 	mov	r4,#0x00
                           1618 ;	genLeftShift
                           1619 ;	genLeftShiftLiteral
                           1620 ;	genlshFour
                           1621 ;	peephole 177.e	removed redundant move
   3592 E4 35              1622 	mov	ar5,r4
   3594 0C F5              1623 	mov	ar4,r3
   3596 0C 85              1624 	mov	ar3,r2
                           1625 ;	genPlus
                           1626 ;	Peephole 236.g	used r2 instead of ar2
                           1627 ;	peephole 177.g	optimized mov sequence
                           1628 ;	Peephole 181	changed mov to clr
   3598 0B                 1629 	clr	a
   3599 97                 1630 	mov	r2,a
   359A 85 0A              1631 	add	a,_ulTimerValue
   359C 96 85              1632 	mov	_ulTimerValue,a
                           1633 ;	Peephole 236.g	used r3 instead of ar3
   359E 09                 1634 	mov	a,r3
   359F 95 12              1635 	addc	a,(_ulTimerValue + 1)
   35A1 10 6A              1636 	mov	(_ulTimerValue + 1),a
                           1637 ;	Peephole 236.g	used r4 instead of ar4
   35A3 12                 1638 	mov	a,r4
   35A4 12 75              1639 	addc	a,(_ulTimerValue + 2)
   35A6 53 C0              1640 	mov	(_ulTimerValue + 2),a
                           1641 ;	Peephole 236.g	used r5 instead of ar5
   35A8 7F                 1642 	mov	a,r5
   35A9 90 F0              1643 	addc	a,(_ulTimerValue + 3)
   35AB 75 E0              1644 	mov	(_ulTimerValue + 3),a
                           1645 ;	../../Platform/nano/port.c:341: ulTimerValue += ((unsigned long int)ST2) << 16;
                           1646 ;	genCast
   35AD FA A3              1647 	mov	r2,_ST2
   35AF E0 FB              1648 	mov	r3,#0x00
   35B1 A3 E0              1649 	mov	r4,#0x00
                           1650 ;	genLeftShift
                           1651 ;	genLeftShiftLiteral
                           1652 ;	genlshFour
                           1653 ;	peephole 177.e	removed redundant move
   35B3 FC 8A              1654 	mov	ar5,r3
   35B5 82 8B              1655 	mov	ar4,r2
                           1656 ;	genPlus
                           1657 ;	Peephole 3.c	changed mov to clr
   35B7 83                 1658 	clr	a
   35B8 8C                 1659 	mov	r3,a
   35B9 F0                 1660 	mov	r2,a
                           1661 ;	Peephole 177.b	removed redundant mov
   35BA 12 E4              1662 	add	a,_ulTimerValue
   35BC 9F F5              1663 	mov	_ulTimerValue,a
                           1664 ;	Peephole 236.g	used r3 instead of ar3
   35BE 0D                 1665 	mov	a,r3
   35BF A3 12              1666 	addc	a,(_ulTimerValue + 1)
   35C1 E4 9F              1667 	mov	(_ulTimerValue + 1),a
                           1668 ;	Peephole 236.g	used r4 instead of ar4
   35C3 F5                 1669 	mov	a,r4
   35C4 0E 75              1670 	addc	a,(_ulTimerValue + 2)
   35C6 0F 21              1671 	mov	(_ulTimerValue + 2),a
                           1672 ;	Peephole 236.g	used r5 instead of ar5
   35C8 85                 1673 	mov	a,r5
   35C9 0D 82              1674 	addc	a,(_ulTimerValue + 3)
   35CB 85 0E              1675 	mov	(_ulTimerValue + 3),a
                           1676 ;	../../Platform/nano/port.c:342: ulTimerValue += TICK_VAL;
                           1677 ;	genPlus
                           1678 ;     genPlusIncr
   35CD 83 E0              1679 	mov	a,#0x20
   35CF F5 08              1680 	add	a,_ulTimerValue
   35D1 F5*01              1681 	mov	_ulTimerValue,a
                           1682 ;	Peephole 181	changed mov to clr
   35D1 05                 1683 	clr	a
   35D2 0D E4              1684 	addc	a,(_ulTimerValue + 1)
   35D4 B5 0D              1685 	mov	(_ulTimerValue + 1),a
                           1686 ;	Peephole 181	changed mov to clr
   35D6 02                 1687 	clr	a
   35D7 05 0E              1688 	addc	a,(_ulTimerValue + 2)
   35D9 F5*03              1689 	mov	(_ulTimerValue + 2),a
                           1690 ;	Peephole 181	changed mov to clr
   35D9 05                 1691 	clr	a
   35DA 0F A8              1692 	addc	a,(_ulTimerValue + 3)
   35DC 0F 85              1693 	mov	(_ulTimerValue + 3),a
                           1694 ;	../../Platform/nano/port.c:343: ST2 = (unsigned char) (ulTimerValue >> 16);
                           1695 ;	genGetByte
   35DE 0D 82 85           1696 	mov	_ST2,(_ulTimerValue + 2)
                           1697 ;	../../Platform/nano/port.c:344: ST1 = (unsigned char) (ulTimerValue >> 8);
                           1698 ;	genGetByte
   35E1 0E 83 E0           1699 	mov	_ST1,(_ulTimerValue + 1)
                           1700 ;	../../Platform/nano/port.c:345: ST0 = (unsigned char) ulTimerValue;
                           1701 ;	genCast
   35E4 FA F6 15           1702 	mov	_ST0,_ulTimerValue
                           1703 ;	../../Platform/nano/port.c:346: IEN0 |= STIE;
                           1704 ;	genOr
   35E7 08 E5 08           1705 	orl	_IEN0,#0x20
                           1706 ;	Peephole 300	removed redundant label 00101$
   35EA 70                 1707 	ret
                           1708 	.area CSEG    (CODE)
                           1709 	.area CONST   (CODE)
                           1710 	.area XINIT   (CODE)
