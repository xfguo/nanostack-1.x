                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Nov 10 2006)
                              4 ; This file generated Fri Feb  1 13:33:39 2008
                              5 ;--------------------------------------------------------
                              6 	.module routing
                              7 	.optsdcc -mmcs51 --model-large
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _IRCON2_P2IF
                             13 	.globl _IRCON2_UTX0IF
                             14 	.globl _IRCON2_UTX1IF
                             15 	.globl _IRCON2_P1IF
                             16 	.globl _IRCON2_WDTIF
                             17 	.globl _CY
                             18 	.globl _AC
                             19 	.globl _F0
                             20 	.globl _RS1
                             21 	.globl _RS0
                             22 	.globl _OV
                             23 	.globl _F1
                             24 	.globl _P
                             25 	.globl _IRCON_DMAIF
                             26 	.globl _IRCON_T1IF
                             27 	.globl _IRCON_T2IF
                             28 	.globl _IRCON_T3IF
                             29 	.globl _IRCON_T4IF
                             30 	.globl _IRCON_P0IF
                             31 	.globl _IRCON_STIF
                             32 	.globl _IEN1_DMAIE
                             33 	.globl _IEN1_T1IE
                             34 	.globl _IEN1_T2IE
                             35 	.globl _IEN1_T3IE
                             36 	.globl _IEN1_T4IE
                             37 	.globl _IEN1_P0IE
                             38 	.globl _IEN0_RFERRIE
                             39 	.globl _IEN0_ADCIE
                             40 	.globl _IEN0_URX0IE
                             41 	.globl _IEN0_URX1IE
                             42 	.globl _IEN0_ENCIE
                             43 	.globl _IEN0_STIE
                             44 	.globl _IEN0_EA
                             45 	.globl _EA
                             46 	.globl _P2_4
                             47 	.globl _P2_3
                             48 	.globl _P2_2
                             49 	.globl _P2_1
                             50 	.globl _P2_0
                             51 	.globl _S0CON_ENCIF_0
                             52 	.globl _S0CON_ENCIF_1
                             53 	.globl _P1_7
                             54 	.globl _P1_6
                             55 	.globl _P1_5
                             56 	.globl _P1_4
                             57 	.globl _P1_3
                             58 	.globl _P1_2
                             59 	.globl _P1_1
                             60 	.globl _P1_0
                             61 	.globl _TCON_IT0
                             62 	.globl _TCON_RFERRIF
                             63 	.globl _TCON_IT1
                             64 	.globl _TCON_URX0IF
                             65 	.globl _TCON_ADCIF
                             66 	.globl _TCON_URX1IF
                             67 	.globl _P0_0
                             68 	.globl _P0_1
                             69 	.globl _P0_2
                             70 	.globl _P0_3
                             71 	.globl _P0_4
                             72 	.globl _P0_5
                             73 	.globl _P0_6
                             74 	.globl _P0_7
                             75 	.globl _P2DIR
                             76 	.globl _P1DIR
                             77 	.globl _P0DIR
                             78 	.globl _U1GCR
                             79 	.globl _U1UCR
                             80 	.globl _U1BAUD
                             81 	.globl _U1BUF
                             82 	.globl _U1CSR
                             83 	.globl _P2INP
                             84 	.globl _P1INP
                             85 	.globl _P2SEL
                             86 	.globl _P1SEL
                             87 	.globl _P0SEL
                             88 	.globl _ADCCFG
                             89 	.globl _PERCFG
                             90 	.globl _B
                             91 	.globl _T4CC1
                             92 	.globl _T4CCTL1
                             93 	.globl _T4CC0
                             94 	.globl _T4CCTL0
                             95 	.globl _T4CTL
                             96 	.globl _T4CNT
                             97 	.globl _RFIF
                             98 	.globl _IRCON2
                             99 	.globl _T1CCTL2
                            100 	.globl _T1CCTL1
                            101 	.globl _T1CCTL0
                            102 	.globl _T1CTL
                            103 	.globl _T1CNTH
                            104 	.globl _T1CNTL
                            105 	.globl _RFST
                            106 	.globl _ACC
                            107 	.globl _T1CC2H
                            108 	.globl _T1CC2L
                            109 	.globl _T1CC1H
                            110 	.globl _T1CC1L
                            111 	.globl _T1CC0H
                            112 	.globl _T1CC0L
                            113 	.globl _RFD
                            114 	.globl _TIMIF
                            115 	.globl _DMAREQ
                            116 	.globl _DMAARM
                            117 	.globl _DMA0CFGH
                            118 	.globl _DMA0CFGL
                            119 	.globl _DMA1CFGH
                            120 	.globl _DMA1CFGL
                            121 	.globl _DMAIRQ
                            122 	.globl _PSW
                            123 	.globl _T3CC1
                            124 	.globl _T3CCTL1
                            125 	.globl _T3CC0
                            126 	.globl _T3CCTL0
                            127 	.globl _T3CTL
                            128 	.globl _T3CNT
                            129 	.globl _WDCTL
                            130 	.globl _T2CON
                            131 	.globl _MEMCTR
                            132 	.globl _CLKCON
                            133 	.globl _U0GCR
                            134 	.globl _U0UCR
                            135 	.globl _T2CNF
                            136 	.globl _U0BAUD
                            137 	.globl _U0BUF
                            138 	.globl _IRCON
                            139 	.globl _SLEEP
                            140 	.globl _RNDH
                            141 	.globl _RNDL
                            142 	.globl _ADCH
                            143 	.globl _ADCL
                            144 	.globl _IP1
                            145 	.globl _IEN1
                            146 	.globl _RCCTL
                            147 	.globl _ADCCON3
                            148 	.globl _ADCCON2
                            149 	.globl _ADCCON1
                            150 	.globl _ENCCS
                            151 	.globl _ENCDO
                            152 	.globl _ENCDI
                            153 	.globl _FWDATA
                            154 	.globl _FCTL
                            155 	.globl _FADDRH
                            156 	.globl _FADDRL
                            157 	.globl _FWT
                            158 	.globl _IP0
                            159 	.globl _IEN0
                            160 	.globl _IE
                            161 	.globl _T2THD
                            162 	.globl _T2TLD
                            163 	.globl _T2CAPHPH
                            164 	.globl _T2CAPLPL
                            165 	.globl _T2OF2
                            166 	.globl _T2OF1
                            167 	.globl _T2OF0
                            168 	.globl _P2
                            169 	.globl _T2PEROF2
                            170 	.globl _T2PEROF1
                            171 	.globl _T2PEROF0
                            172 	.globl _S1CON
                            173 	.globl _IEN2
                            174 	.globl _HSRC
                            175 	.globl _S0CON
                            176 	.globl _ST2
                            177 	.globl _ST1
                            178 	.globl _ST0
                            179 	.globl _T2CMP
                            180 	.globl __XPAGE
                            181 	.globl _DPS
                            182 	.globl _RFIM
                            183 	.globl _P1
                            184 	.globl _P0INP
                            185 	.globl _P1IEN
                            186 	.globl _PICTL
                            187 	.globl _P2IFG
                            188 	.globl _P1IFG
                            189 	.globl _P0IFG
                            190 	.globl _TCON
                            191 	.globl _PCON
                            192 	.globl _U0CSR
                            193 	.globl _DPH1
                            194 	.globl _DPL1
                            195 	.globl _DPH0
                            196 	.globl _DPL0
                            197 	.globl _SP
                            198 	.globl _P0
                            199 	.globl _n_neigh_buffer
                            200 	.globl _table_lock
                            201 	.globl _neighbor_info
                            202 	.globl _neighbor_table
                            203 	.globl _RFD_SHADOW
                            204 	.globl _RFSTATUS
                            205 	.globl _CHIPID
                            206 	.globl _CHVER
                            207 	.globl _FSMTC1
                            208 	.globl _RXFIFOCNT
                            209 	.globl _IOCFG3
                            210 	.globl _IOCFG2
                            211 	.globl _IOCFG1
                            212 	.globl _IOCFG0
                            213 	.globl _SHORTADDRL
                            214 	.globl _SHORTADDRH
                            215 	.globl _PANIDL
                            216 	.globl _PANIDH
                            217 	.globl _IEEE_ADDR7
                            218 	.globl _IEEE_ADDR6
                            219 	.globl _IEEE_ADDR5
                            220 	.globl _IEEE_ADDR4
                            221 	.globl _IEEE_ADDR3
                            222 	.globl _IEEE_ADDR2
                            223 	.globl _IEEE_ADDR1
                            224 	.globl _IEEE_ADDR0
                            225 	.globl _DACTSTL
                            226 	.globl _DACTSTH
                            227 	.globl _ADCTSTL
                            228 	.globl _ADCTSTH
                            229 	.globl _FSMSTATE
                            230 	.globl _AGCCTRLL
                            231 	.globl _AGCCTRLH
                            232 	.globl _MANORL
                            233 	.globl _MANORH
                            234 	.globl _MANANDL
                            235 	.globl _MANANDH
                            236 	.globl _FSMTCL
                            237 	.globl _FSMTCH
                            238 	.globl _RFPWR
                            239 	.globl _CSPT
                            240 	.globl _CSPCTRL
                            241 	.globl _CSPZ
                            242 	.globl _CSPY
                            243 	.globl _CSPX
                            244 	.globl _FSCTRLL
                            245 	.globl _FSCTRLH
                            246 	.globl _RXCTRL1L
                            247 	.globl _RXCTRL1H
                            248 	.globl _RXCTRL0L
                            249 	.globl _RXCTRL0H
                            250 	.globl _TXCTRLL
                            251 	.globl _TXCTRLH
                            252 	.globl _SYNCWORDL
                            253 	.globl _SYNCWORDH
                            254 	.globl _RSSIL
                            255 	.globl _RSSIH
                            256 	.globl _MDMCTRL1L
                            257 	.globl _MDMCTRL1H
                            258 	.globl _MDMCTRL0L
                            259 	.globl _MDMCTRL0H
                            260 	.globl _routing_init
                            261 	.globl _get_neighbour_info
                            262 	.globl _free_table_semaphore
                            263 	.globl _neigh_buffer_get
                            264 	.globl _neigh_buffer_free
                            265 	.globl _update_neighbour_table
                            266 	.globl _update_tables_ttl
                            267 	.globl _check_neighbour_table
                            268 	.globl _check_tables_status
                            269 	.globl _print_table_information
                            270 ;--------------------------------------------------------
                            271 ; special function registers
                            272 ;--------------------------------------------------------
                            273 	.area RSEG    (DATA)
                    0080    274 _P0	=	0x0080
                    0081    275 _SP	=	0x0081
                    0082    276 _DPL0	=	0x0082
                    0083    277 _DPH0	=	0x0083
                    0084    278 _DPL1	=	0x0084
                    0085    279 _DPH1	=	0x0085
                    0086    280 _U0CSR	=	0x0086
                    0087    281 _PCON	=	0x0087
                    0088    282 _TCON	=	0x0088
                    0089    283 _P0IFG	=	0x0089
                    008A    284 _P1IFG	=	0x008a
                    008B    285 _P2IFG	=	0x008b
                    008C    286 _PICTL	=	0x008c
                    008D    287 _P1IEN	=	0x008d
                    008F    288 _P0INP	=	0x008f
                    0090    289 _P1	=	0x0090
                    0091    290 _RFIM	=	0x0091
                    0092    291 _DPS	=	0x0092
                    0093    292 __XPAGE	=	0x0093
                    0094    293 _T2CMP	=	0x0094
                    0095    294 _ST0	=	0x0095
                    0096    295 _ST1	=	0x0096
                    0097    296 _ST2	=	0x0097
                    0098    297 _S0CON	=	0x0098
                    0099    298 _HSRC	=	0x0099
                    009A    299 _IEN2	=	0x009a
                    009B    300 _S1CON	=	0x009b
                    009C    301 _T2PEROF0	=	0x009c
                    009D    302 _T2PEROF1	=	0x009d
                    009E    303 _T2PEROF2	=	0x009e
                    00A0    304 _P2	=	0x00a0
                    00A1    305 _T2OF0	=	0x00a1
                    00A2    306 _T2OF1	=	0x00a2
                    00A3    307 _T2OF2	=	0x00a3
                    00A4    308 _T2CAPLPL	=	0x00a4
                    00A5    309 _T2CAPHPH	=	0x00a5
                    00A6    310 _T2TLD	=	0x00a6
                    00A7    311 _T2THD	=	0x00a7
                    00A8    312 _IE	=	0x00a8
                    00A8    313 _IEN0	=	0x00a8
                    00A9    314 _IP0	=	0x00a9
                    00AB    315 _FWT	=	0x00ab
                    00AC    316 _FADDRL	=	0x00ac
                    00AD    317 _FADDRH	=	0x00ad
                    00AE    318 _FCTL	=	0x00ae
                    00AF    319 _FWDATA	=	0x00af
                    00B1    320 _ENCDI	=	0x00b1
                    00B2    321 _ENCDO	=	0x00b2
                    00B3    322 _ENCCS	=	0x00b3
                    00B4    323 _ADCCON1	=	0x00b4
                    00B5    324 _ADCCON2	=	0x00b5
                    00B6    325 _ADCCON3	=	0x00b6
                    00B7    326 _RCCTL	=	0x00b7
                    00B8    327 _IEN1	=	0x00b8
                    00B9    328 _IP1	=	0x00b9
                    00BA    329 _ADCL	=	0x00ba
                    00BB    330 _ADCH	=	0x00bb
                    00BC    331 _RNDL	=	0x00bc
                    00BD    332 _RNDH	=	0x00bd
                    00BE    333 _SLEEP	=	0x00be
                    00C0    334 _IRCON	=	0x00c0
                    00C1    335 _U0BUF	=	0x00c1
                    00C2    336 _U0BAUD	=	0x00c2
                    00C3    337 _T2CNF	=	0x00c3
                    00C4    338 _U0UCR	=	0x00c4
                    00C5    339 _U0GCR	=	0x00c5
                    00C6    340 _CLKCON	=	0x00c6
                    00C7    341 _MEMCTR	=	0x00c7
                    00C8    342 _T2CON	=	0x00c8
                    00C9    343 _WDCTL	=	0x00c9
                    00CA    344 _T3CNT	=	0x00ca
                    00CB    345 _T3CTL	=	0x00cb
                    00CC    346 _T3CCTL0	=	0x00cc
                    00CD    347 _T3CC0	=	0x00cd
                    00CE    348 _T3CCTL1	=	0x00ce
                    00CF    349 _T3CC1	=	0x00cf
                    00D0    350 _PSW	=	0x00d0
                    00D1    351 _DMAIRQ	=	0x00d1
                    00D2    352 _DMA1CFGL	=	0x00d2
                    00D3    353 _DMA1CFGH	=	0x00d3
                    00D4    354 _DMA0CFGL	=	0x00d4
                    00D5    355 _DMA0CFGH	=	0x00d5
                    00D6    356 _DMAARM	=	0x00d6
                    00D7    357 _DMAREQ	=	0x00d7
                    00D8    358 _TIMIF	=	0x00d8
                    00D9    359 _RFD	=	0x00d9
                    00DA    360 _T1CC0L	=	0x00da
                    00DB    361 _T1CC0H	=	0x00db
                    00DC    362 _T1CC1L	=	0x00dc
                    00DD    363 _T1CC1H	=	0x00dd
                    00DE    364 _T1CC2L	=	0x00de
                    00DF    365 _T1CC2H	=	0x00df
                    00E0    366 _ACC	=	0x00e0
                    00E1    367 _RFST	=	0x00e1
                    00E2    368 _T1CNTL	=	0x00e2
                    00E3    369 _T1CNTH	=	0x00e3
                    00E4    370 _T1CTL	=	0x00e4
                    00E5    371 _T1CCTL0	=	0x00e5
                    00E6    372 _T1CCTL1	=	0x00e6
                    00E7    373 _T1CCTL2	=	0x00e7
                    00E8    374 _IRCON2	=	0x00e8
                    00E9    375 _RFIF	=	0x00e9
                    00EA    376 _T4CNT	=	0x00ea
                    00EB    377 _T4CTL	=	0x00eb
                    00EC    378 _T4CCTL0	=	0x00ec
                    00ED    379 _T4CC0	=	0x00ed
                    00EE    380 _T4CCTL1	=	0x00ee
                    00EF    381 _T4CC1	=	0x00ef
                    00F0    382 _B	=	0x00f0
                    00F1    383 _PERCFG	=	0x00f1
                    00F2    384 _ADCCFG	=	0x00f2
                    00F3    385 _P0SEL	=	0x00f3
                    00F4    386 _P1SEL	=	0x00f4
                    00F5    387 _P2SEL	=	0x00f5
                    00F6    388 _P1INP	=	0x00f6
                    00F7    389 _P2INP	=	0x00f7
                    00F8    390 _U1CSR	=	0x00f8
                    00F9    391 _U1BUF	=	0x00f9
                    00FA    392 _U1BAUD	=	0x00fa
                    00FB    393 _U1UCR	=	0x00fb
                    00FC    394 _U1GCR	=	0x00fc
                    00FD    395 _P0DIR	=	0x00fd
                    00FE    396 _P1DIR	=	0x00fe
                    00FF    397 _P2DIR	=	0x00ff
                            398 ;--------------------------------------------------------
                            399 ; special function bits
                            400 ;--------------------------------------------------------
                            401 	.area RSEG    (DATA)
                    0087    402 _P0_7	=	0x0087
                    0086    403 _P0_6	=	0x0086
                    0085    404 _P0_5	=	0x0085
                    0084    405 _P0_4	=	0x0084
                    0083    406 _P0_3	=	0x0083
                    0082    407 _P0_2	=	0x0082
                    0081    408 _P0_1	=	0x0081
                    0080    409 _P0_0	=	0x0080
                    008F    410 _TCON_URX1IF	=	0x008f
                    008D    411 _TCON_ADCIF	=	0x008d
                    008B    412 _TCON_URX0IF	=	0x008b
                    008A    413 _TCON_IT1	=	0x008a
                    0089    414 _TCON_RFERRIF	=	0x0089
                    0088    415 _TCON_IT0	=	0x0088
                    0090    416 _P1_0	=	0x0090
                    0091    417 _P1_1	=	0x0091
                    0092    418 _P1_2	=	0x0092
                    0093    419 _P1_3	=	0x0093
                    0094    420 _P1_4	=	0x0094
                    0095    421 _P1_5	=	0x0095
                    0096    422 _P1_6	=	0x0096
                    0097    423 _P1_7	=	0x0097
                    0099    424 _S0CON_ENCIF_1	=	0x0099
                    0098    425 _S0CON_ENCIF_0	=	0x0098
                    00A0    426 _P2_0	=	0x00a0
                    00A1    427 _P2_1	=	0x00a1
                    00A2    428 _P2_2	=	0x00a2
                    00A3    429 _P2_3	=	0x00a3
                    00A4    430 _P2_4	=	0x00a4
                    00AF    431 _EA	=	0x00af
                    00AF    432 _IEN0_EA	=	0x00af
                    00AD    433 _IEN0_STIE	=	0x00ad
                    00AC    434 _IEN0_ENCIE	=	0x00ac
                    00AB    435 _IEN0_URX1IE	=	0x00ab
                    00AA    436 _IEN0_URX0IE	=	0x00aa
                    00A9    437 _IEN0_ADCIE	=	0x00a9
                    00A8    438 _IEN0_RFERRIE	=	0x00a8
                    00BD    439 _IEN1_P0IE	=	0x00bd
                    00BC    440 _IEN1_T4IE	=	0x00bc
                    00BB    441 _IEN1_T3IE	=	0x00bb
                    00BA    442 _IEN1_T2IE	=	0x00ba
                    00B9    443 _IEN1_T1IE	=	0x00b9
                    00B8    444 _IEN1_DMAIE	=	0x00b8
                    00C7    445 _IRCON_STIF	=	0x00c7
                    00C5    446 _IRCON_P0IF	=	0x00c5
                    00C4    447 _IRCON_T4IF	=	0x00c4
                    00C3    448 _IRCON_T3IF	=	0x00c3
                    00C2    449 _IRCON_T2IF	=	0x00c2
                    00C1    450 _IRCON_T1IF	=	0x00c1
                    00C0    451 _IRCON_DMAIF	=	0x00c0
                    00D0    452 _P	=	0x00d0
                    00D1    453 _F1	=	0x00d1
                    00D2    454 _OV	=	0x00d2
                    00D3    455 _RS0	=	0x00d3
                    00D4    456 _RS1	=	0x00d4
                    00D5    457 _F0	=	0x00d5
                    00D6    458 _AC	=	0x00d6
                    00D7    459 _CY	=	0x00d7
                    00EC    460 _IRCON2_WDTIF	=	0x00ec
                    00EB    461 _IRCON2_P1IF	=	0x00eb
                    00EA    462 _IRCON2_UTX1IF	=	0x00ea
                    00E9    463 _IRCON2_UTX0IF	=	0x00e9
                    00E8    464 _IRCON2_P2IF	=	0x00e8
                            465 ;--------------------------------------------------------
                            466 ; overlayable register banks
                            467 ;--------------------------------------------------------
                            468 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     469 	.ds 8
                            470 ;--------------------------------------------------------
                            471 ; internal ram data
                            472 ;--------------------------------------------------------
                            473 	.area DSEG    (DATA)
                            474 ;--------------------------------------------------------
                            475 ; overlayable items in internal ram 
                            476 ;--------------------------------------------------------
                            477 	.area OSEG    (OVR,DATA)
                            478 ;--------------------------------------------------------
                            479 ; indirectly addressable internal ram data
                            480 ;--------------------------------------------------------
                            481 	.area ISEG    (DATA)
                            482 ;--------------------------------------------------------
                            483 ; bit data
                            484 ;--------------------------------------------------------
                            485 	.area BSEG    (BIT)
                            486 ;--------------------------------------------------------
                            487 ; paged external ram data
                            488 ;--------------------------------------------------------
                            489 	.area PSEG    (PAG,XDATA)
                            490 ;--------------------------------------------------------
                            491 ; external ram data
                            492 ;--------------------------------------------------------
                            493 	.area XSEG    (XDATA)
                    DF02    494 _MDMCTRL0H	=	0xdf02
                    DF03    495 _MDMCTRL0L	=	0xdf03
                    DF04    496 _MDMCTRL1H	=	0xdf04
                    DF05    497 _MDMCTRL1L	=	0xdf05
                    DF06    498 _RSSIH	=	0xdf06
                    DF07    499 _RSSIL	=	0xdf07
                    DF08    500 _SYNCWORDH	=	0xdf08
                    DF09    501 _SYNCWORDL	=	0xdf09
                    DF0A    502 _TXCTRLH	=	0xdf0a
                    DF0B    503 _TXCTRLL	=	0xdf0b
                    DF0C    504 _RXCTRL0H	=	0xdf0c
                    DF0D    505 _RXCTRL0L	=	0xdf0d
                    DF0E    506 _RXCTRL1H	=	0xdf0e
                    DF0F    507 _RXCTRL1L	=	0xdf0f
                    DF10    508 _FSCTRLH	=	0xdf10
                    DF11    509 _FSCTRLL	=	0xdf11
                    DF12    510 _CSPX	=	0xdf12
                    DF13    511 _CSPY	=	0xdf13
                    DF14    512 _CSPZ	=	0xdf14
                    DF15    513 _CSPCTRL	=	0xdf15
                    DF16    514 _CSPT	=	0xdf16
                    DF17    515 _RFPWR	=	0xdf17
                    DF20    516 _FSMTCH	=	0xdf20
                    DF21    517 _FSMTCL	=	0xdf21
                    DF22    518 _MANANDH	=	0xdf22
                    DF23    519 _MANANDL	=	0xdf23
                    DF24    520 _MANORH	=	0xdf24
                    DF25    521 _MANORL	=	0xdf25
                    DF26    522 _AGCCTRLH	=	0xdf26
                    DF27    523 _AGCCTRLL	=	0xdf27
                    DF39    524 _FSMSTATE	=	0xdf39
                    DF3A    525 _ADCTSTH	=	0xdf3a
                    DF3B    526 _ADCTSTL	=	0xdf3b
                    DF3C    527 _DACTSTH	=	0xdf3c
                    DF3D    528 _DACTSTL	=	0xdf3d
                    DF43    529 _IEEE_ADDR0	=	0xdf43
                    DF44    530 _IEEE_ADDR1	=	0xdf44
                    DF45    531 _IEEE_ADDR2	=	0xdf45
                    DF46    532 _IEEE_ADDR3	=	0xdf46
                    DF47    533 _IEEE_ADDR4	=	0xdf47
                    DF48    534 _IEEE_ADDR5	=	0xdf48
                    DF49    535 _IEEE_ADDR6	=	0xdf49
                    DF4A    536 _IEEE_ADDR7	=	0xdf4a
                    DF4B    537 _PANIDH	=	0xdf4b
                    DF4C    538 _PANIDL	=	0xdf4c
                    DF4D    539 _SHORTADDRH	=	0xdf4d
                    DF4E    540 _SHORTADDRL	=	0xdf4e
                    DF4F    541 _IOCFG0	=	0xdf4f
                    DF50    542 _IOCFG1	=	0xdf50
                    DF51    543 _IOCFG2	=	0xdf51
                    DF52    544 _IOCFG3	=	0xdf52
                    DF53    545 _RXFIFOCNT	=	0xdf53
                    DF54    546 _FSMTC1	=	0xdf54
                    DF60    547 _CHVER	=	0xdf60
                    DF61    548 _CHIPID	=	0xdf61
                    DF62    549 _RFSTATUS	=	0xdf62
                    DFD9    550 _RFD_SHADOW	=	0xdfd9
   EFBC                     551 _neighbor_table::
   EFBC                     552 	.ds 62
   EFFA                     553 _neighbor_info::
   EFFA                     554 	.ds 3
                            555 ;--------------------------------------------------------
                            556 ; external initialized ram data
                            557 ;--------------------------------------------------------
                            558 	.area XISEG   (XDATA)
   F0E7                     559 _table_lock::
   F0E7                     560 	.ds 3
   F0EA                     561 _n_neigh_buffer::
   F0EA                     562 	.ds 1
                            563 	.area HOME    (CODE)
                            564 	.area GSINIT0 (CODE)
                            565 	.area GSINIT1 (CODE)
                            566 	.area GSINIT2 (CODE)
                            567 	.area GSINIT3 (CODE)
                            568 	.area GSINIT4 (CODE)
                            569 	.area GSINIT5 (CODE)
                            570 	.area GSINIT  (CODE)
                            571 	.area GSFINAL (CODE)
                            572 	.area CSEG    (CODE)
                            573 ;--------------------------------------------------------
                            574 ; global & static initialisations
                            575 ;--------------------------------------------------------
                            576 	.area HOME    (CODE)
                            577 	.area GSINIT  (CODE)
                            578 	.area GSFINAL (CODE)
                            579 	.area GSINIT  (CODE)
                            580 ;--------------------------------------------------------
                            581 ; Home
                            582 ;--------------------------------------------------------
                            583 	.area HOME    (CODE)
                            584 	.area CSEG    (CODE)
                            585 ;--------------------------------------------------------
                            586 ; code
                            587 ;--------------------------------------------------------
                            588 	.area CSEG    (CODE)
                            589 ;------------------------------------------------------------
                            590 ;Allocation info for local variables in function 'routing_init'
                            591 ;------------------------------------------------------------
                            592 ;b                         Allocated to stack - offset 1
                            593 ;i                         Allocated to registers r2 
                            594 ;------------------------------------------------------------
                            595 ;	../../Common/routing.c:71: void routing_init(void)
                            596 ;	-----------------------------------------
                            597 ;	 function routing_init
                            598 ;	-----------------------------------------
   6BA8                     599 _routing_init:
                    0002    600 	ar2 = 0x02
                    0003    601 	ar3 = 0x03
                    0004    602 	ar4 = 0x04
                    0005    603 	ar5 = 0x05
                    0006    604 	ar6 = 0x06
                    0007    605 	ar7 = 0x07
                    0000    606 	ar0 = 0x00
                    0001    607 	ar1 = 0x01
   6BA8 C0 10               608 	push	_bp
   6BAA 85 81 10            609 	mov	_bp,sp
   6BAD 05 81               610 	inc	sp
   6BAF 05 81               611 	inc	sp
   6BB1 05 81               612 	inc	sp
                            613 ;	../../Common/routing.c:74: vSemaphoreCreateBinary( table_lock );
                            614 ;	genIpush
                            615 ;	Peephole 181	changed mov to clr
   6BB3 E4                  616 	clr	a
   6BB4 C0 E0               617 	push	acc
                            618 ;	genCall
   6BB6 75 82 01            619 	mov	dpl,#0x01
   6BB9 12 1B 2D            620 	lcall	_xQueueCreate
   6BBC AA 82               621 	mov	r2,dpl
   6BBE AB 83               622 	mov	r3,dph
   6BC0 AC F0               623 	mov	r4,b
   6BC2 15 81               624 	dec	sp
                            625 ;	genAssign
   6BC4 90 F0 E7            626 	mov	dptr,#_table_lock
   6BC7 EA                  627 	mov	a,r2
   6BC8 F0                  628 	movx	@dptr,a
   6BC9 A3                  629 	inc	dptr
   6BCA EB                  630 	mov	a,r3
   6BCB F0                  631 	movx	@dptr,a
   6BCC A3                  632 	inc	dptr
   6BCD EC                  633 	mov	a,r4
   6BCE F0                  634 	movx	@dptr,a
                            635 ;	genCmpEq
                            636 ;	gencjneshort
   6BCF BA 00 08            637 	cjne	r2,#0x00,00130$
   6BD2 BB 00 05            638 	cjne	r3,#0x00,00130$
   6BD5 BC 00 02            639 	cjne	r4,#0x00,00130$
                            640 ;	Peephole 112.b	changed ljmp to sjmp
   6BD8 80 1B               641 	sjmp	00102$
   6BDA                     642 00130$:
                            643 ;	genIpush
                            644 ;	Peephole 181	changed mov to clr
   6BDA E4                  645 	clr	a
   6BDB C0 E0               646 	push	acc
   6BDD C0 E0               647 	push	acc
                            648 ;	genIpush
                            649 ;	Peephole 181	changed mov to clr
   6BDF E4                  650 	clr	a
   6BE0 C0 E0               651 	push	acc
   6BE2 C0 E0               652 	push	acc
   6BE4 C0 E0               653 	push	acc
                            654 ;	genCall
   6BE6 8A 82               655 	mov	dpl,r2
   6BE8 8B 83               656 	mov	dph,r3
   6BEA 8C F0               657 	mov	b,r4
   6BEC 12 1D 8E            658 	lcall	_xQueueSend
   6BEF E5 81               659 	mov	a,sp
   6BF1 24 FB               660 	add	a,#0xfb
   6BF3 F5 81               661 	mov	sp,a
   6BF5                     662 00102$:
                            663 ;	../../Common/routing.c:75: if(table_lock != NULL)
                            664 ;	genAssign
   6BF5 90 F0 E7            665 	mov	dptr,#_table_lock
   6BF8 E0                  666 	movx	a,@dptr
   6BF9 FA                  667 	mov	r2,a
   6BFA A3                  668 	inc	dptr
   6BFB E0                  669 	movx	a,@dptr
   6BFC FB                  670 	mov	r3,a
   6BFD A3                  671 	inc	dptr
   6BFE E0                  672 	movx	a,@dptr
   6BFF FC                  673 	mov	r4,a
                            674 ;	genCmpEq
                            675 ;	gencjneshort
   6C00 BA 00 09            676 	cjne	r2,#0x00,00131$
   6C03 BB 00 06            677 	cjne	r3,#0x00,00131$
   6C06 BC 00 03            678 	cjne	r4,#0x00,00131$
   6C09 02 6C E7            679 	ljmp	00119$
   6C0C                     680 00131$:
                            681 ;	../../Common/routing.c:83: neighbor_table.count=0;
                            682 ;	genPointerSet
                            683 ;     genFarPointerSet
   6C0C 90 EF BC            684 	mov	dptr,#_neighbor_table
                            685 ;	Peephole 181	changed mov to clr
                            686 ;	../../Common/routing.c:84: neighbor_table.child_count=0;
                            687 ;	genPointerSet
                            688 ;     genFarPointerSet
                            689 ;	Peephole 181	changed mov to clr
                            690 ;	Peephole 219.a	removed redundant clear
   6C0F E4                  691 	clr	a
   6C10 F0                  692 	movx	@dptr,a
   6C11 90 EF BD            693 	mov	dptr,#(_neighbor_table + 0x0001)
   6C14 F0                  694 	movx	@dptr,a
                            695 ;	../../Common/routing.c:85: neighbor_info = xQueueCreate( MAX_NEIGHBOR_COUNT, sizeof( neighbor_info_t * ) );
                            696 ;	genIpush
   6C15 74 03               697 	mov	a,#0x03
   6C17 C0 E0               698 	push	acc
                            699 ;	genCall
   6C19 75 82 14            700 	mov	dpl,#0x14
   6C1C 12 1B 2D            701 	lcall	_xQueueCreate
   6C1F AA 82               702 	mov	r2,dpl
   6C21 AB 83               703 	mov	r3,dph
   6C23 AC F0               704 	mov	r4,b
   6C25 15 81               705 	dec	sp
                            706 ;	genAssign
   6C27 90 EF FA            707 	mov	dptr,#_neighbor_info
   6C2A EA                  708 	mov	a,r2
   6C2B F0                  709 	movx	@dptr,a
   6C2C A3                  710 	inc	dptr
   6C2D EB                  711 	mov	a,r3
   6C2E F0                  712 	movx	@dptr,a
   6C2F A3                  713 	inc	dptr
   6C30 EC                  714 	mov	a,r4
   6C31 F0                  715 	movx	@dptr,a
                            716 ;	../../Common/routing.c:89: i = 0;
                            717 ;	genAssign
   6C32 7A 00               718 	mov	r2,#0x00
                            719 ;	../../Common/routing.c:90: while (i < MAX_NEIGHBOR_COUNT)
   6C34                     720 00110$:
                            721 ;	genCmpLt
                            722 ;	genCmp
   6C34 BA 14 00            723 	cjne	r2,#0x14,00132$
   6C37                     724 00132$:
                            725 ;	genIfxJump
   6C37 40 03               726 	jc	00133$
   6C39 02 6C CD            727 	ljmp	00128$
   6C3C                     728 00133$:
                            729 ;	../../Common/routing.c:92: b = pvPortMalloc(sizeof(neighbor_info_t));
                            730 ;	genCall
                            731 ;	Peephole 182.b	used 16 bit load of dptr
   6C3C 90 00 0F            732 	mov	dptr,#0x000F
   6C3F C0 02               733 	push	ar2
   6C41 12 36 8C            734 	lcall	_pvPortMalloc
   6C44 AB 82               735 	mov	r3,dpl
   6C46 AC 83               736 	mov	r4,dph
   6C48 AD F0               737 	mov	r5,b
   6C4A D0 02               738 	pop	ar2
                            739 ;	genAssign
   6C4C A8 10               740 	mov	r0,_bp
   6C4E 08                  741 	inc	r0
   6C4F A6 03               742 	mov	@r0,ar3
   6C51 08                  743 	inc	r0
   6C52 A6 04               744 	mov	@r0,ar4
   6C54 08                  745 	inc	r0
   6C55 A6 05               746 	mov	@r0,ar5
                            747 ;	../../Common/routing.c:93: if (b)
                            748 ;	genIfx
   6C57 EB                  749 	mov	a,r3
   6C58 4C                  750 	orl	a,r4
   6C59 4D                  751 	orl	a,r5
                            752 ;	genIfxJump
                            753 ;	Peephole 108.c	removed ljmp by inverse jump logic
   6C5A 60 5F               754 	jz	00106$
                            755 ;	Peephole 300	removed redundant label 00134$
                            756 ;	../../Common/routing.c:95: memset(b, 0, sizeof(neighbor_info_t));
                            757 ;	genIpush
   6C5C C0 02               758 	push	ar2
                            759 ;	genAssign
                            760 ;	genIpush
   6C5E C0 02               761 	push	ar2
   6C60 74 0F               762 	mov	a,#0x0F
   6C62 C0 E0               763 	push	acc
                            764 ;	Peephole 181	changed mov to clr
   6C64 E4                  765 	clr	a
   6C65 C0 E0               766 	push	acc
                            767 ;	genIpush
                            768 ;	Peephole 181	changed mov to clr
   6C67 E4                  769 	clr	a
   6C68 C0 E0               770 	push	acc
                            771 ;	genCall
   6C6A 8B 82               772 	mov	dpl,r3
   6C6C 8C 83               773 	mov	dph,r4
   6C6E 8D F0               774 	mov	b,r5
   6C70 12 E3 65            775 	lcall	_memset
   6C73 15 81               776 	dec	sp
   6C75 15 81               777 	dec	sp
   6C77 15 81               778 	dec	sp
   6C79 D0 02               779 	pop	ar2
                            780 ;	../../Common/routing.c:96: n_neigh_buffer++;
                            781 ;	genAssign
   6C7B 90 F0 EA            782 	mov	dptr,#_n_neigh_buffer
   6C7E E0                  783 	movx	a,@dptr
   6C7F FB                  784 	mov	r3,a
                            785 ;	genPlus
   6C80 90 F0 EA            786 	mov	dptr,#_n_neigh_buffer
                            787 ;     genPlusIncr
   6C83 74 01               788 	mov	a,#0x01
                            789 ;	Peephole 236.a	used r3 instead of ar3
   6C85 2B                  790 	add	a,r3
   6C86 F0                  791 	movx	@dptr,a
                            792 ;	../../Common/routing.c:97: if (xQueueSend( neighbor_info, ( void * ) &b,(portTickType) 0 ) == pdFALSE)
                            793 ;	genAddrOf
                            794 ;	Peephole 212	reduced add sequence to inc
   6C87 AB 10               795 	mov	r3,_bp
   6C89 0B                  796 	inc	r3
                            797 ;	genCast
   6C8A 7C 00               798 	mov	r4,#0x00
   6C8C 7D 40               799 	mov	r5,#0x40
                            800 ;	genAssign
   6C8E 90 EF FA            801 	mov	dptr,#_neighbor_info
   6C91 E0                  802 	movx	a,@dptr
   6C92 FE                  803 	mov	r6,a
   6C93 A3                  804 	inc	dptr
   6C94 E0                  805 	movx	a,@dptr
   6C95 FF                  806 	mov	r7,a
   6C96 A3                  807 	inc	dptr
   6C97 E0                  808 	movx	a,@dptr
   6C98 FA                  809 	mov	r2,a
                            810 ;	genIpush
   6C99 C0 02               811 	push	ar2
                            812 ;	Peephole 181	changed mov to clr
   6C9B E4                  813 	clr	a
   6C9C C0 E0               814 	push	acc
   6C9E C0 E0               815 	push	acc
                            816 ;	genIpush
   6CA0 C0 03               817 	push	ar3
   6CA2 C0 04               818 	push	ar4
   6CA4 C0 05               819 	push	ar5
                            820 ;	genCall
   6CA6 8E 82               821 	mov	dpl,r6
   6CA8 8F 83               822 	mov	dph,r7
   6CAA 8A F0               823 	mov	b,r2
   6CAC 12 1D 8E            824 	lcall	_xQueueSend
   6CAF E5 81               825 	mov	a,sp
   6CB1 24 FB               826 	add	a,#0xfb
   6CB3 F5 81               827 	mov	sp,a
   6CB5 D0 02               828 	pop	ar2
                            829 ;	genIpop
   6CB7 D0 02               830 	pop	ar2
                            831 ;	Peephole 112.b	changed ljmp to sjmp
   6CB9 80 02               832 	sjmp	00107$
   6CBB                     833 00106$:
                            834 ;	../../Common/routing.c:109: i = MAX_NEIGHBOR_COUNT;  
                            835 ;	genAssign
   6CBB 7A 14               836 	mov	r2,#0x14
   6CBD                     837 00107$:
                            838 ;	../../Common/routing.c:111: if (i++ >= MIN_NEIGHBOR_INFO_COUNT) i = MAX_NEIGHBOR_COUNT;
                            839 ;	genAssign
   6CBD 8A 03               840 	mov	ar3,r2
                            841 ;	genPlus
                            842 ;     genPlusIncr
   6CBF 0A                  843 	inc	r2
                            844 ;	genCmpLt
                            845 ;	genCmp
   6CC0 BB 0F 00            846 	cjne	r3,#0x0F,00135$
   6CC3                     847 00135$:
                            848 ;	genIfxJump
   6CC3 50 03               849 	jnc	00136$
   6CC5 02 6C 34            850 	ljmp	00110$
   6CC8                     851 00136$:
                            852 ;	genAssign
   6CC8 7A 14               853 	mov	r2,#0x14
   6CCA 02 6C 34            854 	ljmp	00110$
                            855 ;	../../Common/routing.c:114: for(i=0; i < MAX_ROUTE_INFO_COUNT ; i++)
   6CCD                     856 00128$:
                            857 ;	genAssign
   6CCD 7A 00               858 	mov	r2,#0x00
   6CCF                     859 00115$:
                            860 ;	genCmpLt
                            861 ;	genCmp
   6CCF BA 0F 00            862 	cjne	r2,#0x0F,00137$
   6CD2                     863 00137$:
                            864 ;	genIfxJump
                            865 ;	Peephole 108.a	removed ljmp by inverse jump logic
   6CD2 50 13               866 	jnc	00119$
                            867 ;	Peephole 300	removed redundant label 00138$
                            868 ;	../../Common/routing.c:116: neighbor_table.neighbor_info[i]=0;
                            869 ;	genMult
                            870 ;	genMultOneByte
   6CD4 EA                  871 	mov	a,r2
   6CD5 75 F0 03            872 	mov	b,#0x03
   6CD8 A4                  873 	mul	ab
                            874 ;	genPlus
   6CD9 24 BE               875 	add	a,#(_neighbor_table + 0x0002)
   6CDB F5 82               876 	mov	dpl,a
                            877 ;	Peephole 240	use clr instead of addc a,#0
   6CDD E4                  878 	clr	a
   6CDE 34 EF               879 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   6CE0 F5 83               880 	mov	dph,a
                            881 ;	genPointerSet
                            882 ;     genFarPointerSet
                            883 ;	Peephole 181	changed mov to clr
   6CE2 E4                  884 	clr	a
   6CE3 F0                  885 	movx	@dptr,a
                            886 ;	../../Common/routing.c:114: for(i=0; i < MAX_ROUTE_INFO_COUNT ; i++)
                            887 ;	genPlus
                            888 ;     genPlusIncr
   6CE4 0A                  889 	inc	r2
                            890 ;	Peephole 112.b	changed ljmp to sjmp
   6CE5 80 E8               891 	sjmp	00115$
   6CE7                     892 00119$:
   6CE7 85 10 81            893 	mov	sp,_bp
   6CEA D0 10               894 	pop	_bp
   6CEC 22                  895 	ret
                            896 ;------------------------------------------------------------
                            897 ;Allocation info for local variables in function 'get_neighbour_info'
                            898 ;------------------------------------------------------------
                            899 ;------------------------------------------------------------
                            900 ;	../../Common/routing.c:159: neighbor_table_t* get_neighbour_info(void)
                            901 ;	-----------------------------------------
                            902 ;	 function get_neighbour_info
                            903 ;	-----------------------------------------
   6CED                     904 _get_neighbour_info:
                            905 ;	../../Common/routing.c:161: if( xSemaphoreTake( table_lock, ( portTickType ) 10 ) == pdTRUE )
                            906 ;	genAssign
   6CED 90 F0 E7            907 	mov	dptr,#_table_lock
   6CF0 E0                  908 	movx	a,@dptr
   6CF1 FA                  909 	mov	r2,a
   6CF2 A3                  910 	inc	dptr
   6CF3 E0                  911 	movx	a,@dptr
   6CF4 FB                  912 	mov	r3,a
   6CF5 A3                  913 	inc	dptr
   6CF6 E0                  914 	movx	a,@dptr
   6CF7 FC                  915 	mov	r4,a
                            916 ;	genIpush
   6CF8 74 0A               917 	mov	a,#0x0A
   6CFA C0 E0               918 	push	acc
                            919 ;	Peephole 181	changed mov to clr
   6CFC E4                  920 	clr	a
   6CFD C0 E0               921 	push	acc
                            922 ;	genIpush
                            923 ;	Peephole 181	changed mov to clr
   6CFF E4                  924 	clr	a
   6D00 C0 E0               925 	push	acc
   6D02 C0 E0               926 	push	acc
   6D04 C0 E0               927 	push	acc
                            928 ;	genCall
   6D06 8A 82               929 	mov	dpl,r2
   6D08 8B 83               930 	mov	dph,r3
   6D0A 8C F0               931 	mov	b,r4
   6D0C 12 23 5A            932 	lcall	_xQueueReceive
   6D0F AA 82               933 	mov	r2,dpl
   6D11 E5 81               934 	mov	a,sp
   6D13 24 FB               935 	add	a,#0xfb
   6D15 F5 81               936 	mov	sp,a
                            937 ;	genCmpEq
                            938 ;	gencjneshort
                            939 ;	Peephole 112.b	changed ljmp to sjmp
                            940 ;	Peephole 198.b	optimized misc jump sequence
   6D17 BA 01 07            941 	cjne	r2,#0x01,00102$
                            942 ;	Peephole 200.b	removed redundant sjmp
                            943 ;	Peephole 300	removed redundant label 00106$
                            944 ;	Peephole 300	removed redundant label 00107$
                            945 ;	../../Common/routing.c:163: return &(neighbor_table);
                            946 ;	genRet
                            947 ;	Peephole 182.a	used 16 bit load of DPTR
   6D1A 90 EF BC            948 	mov	dptr,#_neighbor_table
   6D1D 75 F0 00            949 	mov	b,#0x00
                            950 ;	Peephole 112.b	changed ljmp to sjmp
                            951 ;	Peephole 251.b	replaced sjmp to ret with ret
   6D20 22                  952 	ret
   6D21                     953 00102$:
                            954 ;	../../Common/routing.c:165: return 0;
                            955 ;	genRet
                            956 ;	Peephole 182.b	used 16 bit load of dptr
   6D21 90 00 00            957 	mov	dptr,#0x0000
   6D24 75 F0 00            958 	mov	b,#0x00
                            959 ;	Peephole 300	removed redundant label 00103$
   6D27 22                  960 	ret
                            961 ;------------------------------------------------------------
                            962 ;Allocation info for local variables in function 'free_table_semaphore'
                            963 ;------------------------------------------------------------
                            964 ;------------------------------------------------------------
                            965 ;	../../Common/routing.c:168: void free_table_semaphore(void)
                            966 ;	-----------------------------------------
                            967 ;	 function free_table_semaphore
                            968 ;	-----------------------------------------
   6D28                     969 _free_table_semaphore:
                            970 ;	../../Common/routing.c:170: xSemaphoreGive( table_lock ); /*free lock*/
                            971 ;	genAssign
   6D28 90 F0 E7            972 	mov	dptr,#_table_lock
   6D2B E0                  973 	movx	a,@dptr
   6D2C FA                  974 	mov	r2,a
   6D2D A3                  975 	inc	dptr
   6D2E E0                  976 	movx	a,@dptr
   6D2F FB                  977 	mov	r3,a
   6D30 A3                  978 	inc	dptr
   6D31 E0                  979 	movx	a,@dptr
   6D32 FC                  980 	mov	r4,a
                            981 ;	genIpush
                            982 ;	Peephole 181	changed mov to clr
   6D33 E4                  983 	clr	a
   6D34 C0 E0               984 	push	acc
   6D36 C0 E0               985 	push	acc
                            986 ;	genIpush
                            987 ;	Peephole 181	changed mov to clr
   6D38 E4                  988 	clr	a
   6D39 C0 E0               989 	push	acc
   6D3B C0 E0               990 	push	acc
   6D3D C0 E0               991 	push	acc
                            992 ;	genCall
   6D3F 8A 82               993 	mov	dpl,r2
   6D41 8B 83               994 	mov	dph,r3
   6D43 8C F0               995 	mov	b,r4
   6D45 12 1D 8E            996 	lcall	_xQueueSend
   6D48 E5 81               997 	mov	a,sp
   6D4A 24 FB               998 	add	a,#0xfb
   6D4C F5 81               999 	mov	sp,a
                           1000 ;	Peephole 300	removed redundant label 00101$
   6D4E 22                 1001 	ret
                           1002 ;------------------------------------------------------------
                           1003 ;Allocation info for local variables in function 'neigh_buffer_get'
                           1004 ;------------------------------------------------------------
                           1005 ;blocktime                 Allocated to stack - offset 1
                           1006 ;b                         Allocated to stack - offset 3
                           1007 ;sloc0                     Allocated to stack - offset 6
                           1008 ;------------------------------------------------------------
                           1009 ;	../../Common/routing.c:180: neighbor_info_t* neigh_buffer_get( portTickType blocktime )
                           1010 ;	-----------------------------------------
                           1011 ;	 function neigh_buffer_get
                           1012 ;	-----------------------------------------
   6D4F                    1013 _neigh_buffer_get:
   6D4F C0 10              1014 	push	_bp
   6D51 85 81 10           1015 	mov	_bp,sp
                           1016 ;     genReceive
   6D54 C0 82              1017 	push	dpl
   6D56 C0 83              1018 	push	dph
   6D58 E5 81              1019 	mov	a,sp
   6D5A 24 07              1020 	add	a,#0x07
   6D5C F5 81              1021 	mov	sp,a
                           1022 ;	../../Common/routing.c:184: if (xQueueReceive( neighbor_info, &( b ), 0) == pdTRUE)
                           1023 ;	genAddrOf
   6D5E E5 10              1024 	mov	a,_bp
   6D60 24 03              1025 	add	a,#0x03
   6D62 FC                 1026 	mov	r4,a
                           1027 ;	genCast
   6D63 7D 00              1028 	mov	r5,#0x00
   6D65 7E 40              1029 	mov	r6,#0x40
                           1030 ;	genAssign
   6D67 90 EF FA           1031 	mov	dptr,#_neighbor_info
   6D6A E0                 1032 	movx	a,@dptr
   6D6B FF                 1033 	mov	r7,a
   6D6C A3                 1034 	inc	dptr
   6D6D E0                 1035 	movx	a,@dptr
   6D6E FA                 1036 	mov	r2,a
   6D6F A3                 1037 	inc	dptr
   6D70 E0                 1038 	movx	a,@dptr
   6D71 FB                 1039 	mov	r3,a
                           1040 ;	genIpush
                           1041 ;	Peephole 181	changed mov to clr
   6D72 E4                 1042 	clr	a
   6D73 C0 E0              1043 	push	acc
   6D75 C0 E0              1044 	push	acc
                           1045 ;	genIpush
   6D77 C0 04              1046 	push	ar4
   6D79 C0 05              1047 	push	ar5
   6D7B C0 06              1048 	push	ar6
                           1049 ;	genCall
   6D7D 8F 82              1050 	mov	dpl,r7
   6D7F 8A 83              1051 	mov	dph,r2
   6D81 8B F0              1052 	mov	b,r3
   6D83 12 23 5A           1053 	lcall	_xQueueReceive
   6D86 AA 82              1054 	mov	r2,dpl
   6D88 E5 81              1055 	mov	a,sp
   6D8A 24 FB              1056 	add	a,#0xfb
   6D8C F5 81              1057 	mov	sp,a
                           1058 ;	genCmpEq
                           1059 ;	gencjneshort
                           1060 ;	Peephole 112.b	changed ljmp to sjmp
                           1061 ;	Peephole 198.b	optimized misc jump sequence
   6D8E BA 01 10           1062 	cjne	r2,#0x01,00109$
                           1063 ;	Peephole 200.b	removed redundant sjmp
                           1064 ;	Peephole 300	removed redundant label 00117$
                           1065 ;	Peephole 300	removed redundant label 00118$
                           1066 ;	../../Common/routing.c:186: return b;
                           1067 ;	genRet
   6D91 A8 10              1068 	mov	r0,_bp
   6D93 08                 1069 	inc	r0
   6D94 08                 1070 	inc	r0
   6D95 08                 1071 	inc	r0
   6D96 86 82              1072 	mov	dpl,@r0
   6D98 08                 1073 	inc	r0
   6D99 86 83              1074 	mov	dph,@r0
   6D9B 08                 1075 	inc	r0
   6D9C 86 F0              1076 	mov	b,@r0
   6D9E 02 6E 62           1077 	ljmp	00111$
   6DA1                    1078 00109$:
                           1079 ;	../../Common/routing.c:188: else if (n_neigh_buffer < MAX_NEIGHBOR_COUNT)
                           1080 ;	genAssign
   6DA1 90 F0 EA           1081 	mov	dptr,#_n_neigh_buffer
   6DA4 E0                 1082 	movx	a,@dptr
   6DA5 FA                 1083 	mov	r2,a
                           1084 ;	genCmpLt
                           1085 ;	genCmp
   6DA6 BA 14 00           1086 	cjne	r2,#0x14,00119$
   6DA9                    1087 00119$:
                           1088 ;	genIfxJump
                           1089 ;	Peephole 108.a	removed ljmp by inverse jump logic
   6DA9 50 53              1090 	jnc	00106$
                           1091 ;	Peephole 300	removed redundant label 00120$
                           1092 ;	../../Common/routing.c:190: b = pvPortMalloc(sizeof(neighbor_info_t));
                           1093 ;	genCall
                           1094 ;	Peephole 182.b	used 16 bit load of dptr
   6DAB 90 00 0F           1095 	mov	dptr,#0x000F
   6DAE 12 36 8C           1096 	lcall	_pvPortMalloc
   6DB1 AA 82              1097 	mov	r2,dpl
   6DB3 AB 83              1098 	mov	r3,dph
   6DB5 AC F0              1099 	mov	r4,b
                           1100 ;	../../Common/routing.c:191: if (b)
                           1101 ;	genIfx
   6DB7 EA                 1102 	mov	a,r2
   6DB8 4B                 1103 	orl	a,r3
   6DB9 4C                 1104 	orl	a,r4
                           1105 ;	genIfxJump
   6DBA 70 03              1106 	jnz	00121$
   6DBC 02 6E 5C           1107 	ljmp	00110$
   6DBF                    1108 00121$:
                           1109 ;	../../Common/routing.c:193: memset(b, 0, sizeof(neighbor_info_t));
                           1110 ;	genAssign
   6DBF 8A 05              1111 	mov	ar5,r2
   6DC1 8B 06              1112 	mov	ar6,r3
   6DC3 8C 07              1113 	mov	ar7,r4
                           1114 ;	genIpush
   6DC5 C0 02              1115 	push	ar2
   6DC7 C0 03              1116 	push	ar3
   6DC9 C0 04              1117 	push	ar4
   6DCB 74 0F              1118 	mov	a,#0x0F
   6DCD C0 E0              1119 	push	acc
                           1120 ;	Peephole 181	changed mov to clr
   6DCF E4                 1121 	clr	a
   6DD0 C0 E0              1122 	push	acc
                           1123 ;	genIpush
                           1124 ;	Peephole 181	changed mov to clr
   6DD2 E4                 1125 	clr	a
   6DD3 C0 E0              1126 	push	acc
                           1127 ;	genCall
   6DD5 8D 82              1128 	mov	dpl,r5
   6DD7 8E 83              1129 	mov	dph,r6
   6DD9 8F F0              1130 	mov	b,r7
   6DDB 12 E3 65           1131 	lcall	_memset
   6DDE 15 81              1132 	dec	sp
   6DE0 15 81              1133 	dec	sp
   6DE2 15 81              1134 	dec	sp
   6DE4 D0 04              1135 	pop	ar4
   6DE6 D0 03              1136 	pop	ar3
   6DE8 D0 02              1137 	pop	ar2
                           1138 ;	../../Common/routing.c:194: n_neigh_buffer++;
                           1139 ;	genAssign
   6DEA 90 F0 EA           1140 	mov	dptr,#_n_neigh_buffer
   6DED E0                 1141 	movx	a,@dptr
   6DEE FD                 1142 	mov	r5,a
                           1143 ;	genPlus
   6DEF 90 F0 EA           1144 	mov	dptr,#_n_neigh_buffer
                           1145 ;     genPlusIncr
   6DF2 74 01              1146 	mov	a,#0x01
                           1147 ;	Peephole 236.a	used r5 instead of ar5
   6DF4 2D                 1148 	add	a,r5
   6DF5 F0                 1149 	movx	@dptr,a
                           1150 ;	../../Common/routing.c:195: return b;
                           1151 ;	genRet
   6DF6 8A 82              1152 	mov	dpl,r2
   6DF8 8B 83              1153 	mov	dph,r3
   6DFA 8C F0              1154 	mov	b,r4
                           1155 ;	Peephole 112.b	changed ljmp to sjmp
   6DFC 80 64              1156 	sjmp	00111$
   6DFE                    1157 00106$:
                           1158 ;	../../Common/routing.c:198: else if (xQueueReceive( neighbor_info, &( b ), blocktime / portTICK_RATE_MS) == pdTRUE)
                           1159 ;	genCast
   6DFE A8 10              1160 	mov	r0,_bp
   6E00 08                 1161 	inc	r0
   6E01 86 02              1162 	mov	ar2,@r0
   6E03 08                 1163 	inc	r0
   6E04 86 03              1164 	mov	ar3,@r0
                           1165 ;	genCast
                           1166 ;	Peephole 3.c	changed mov to clr
   6E06 E4                 1167 	clr	a
   6E07 FC                 1168 	mov	r4,a
   6E08 FD                 1169 	mov	r5,a
   6E09 E5 10              1170 	mov	a,_bp
   6E0B 24 06              1171 	add	a,#0x06
   6E0D F8                 1172 	mov	r0,a
   6E0E A6 02              1173 	mov	@r0,ar2
   6E10 08                 1174 	inc	r0
   6E11 A6 03              1175 	mov	@r0,ar3
                           1176 ;	genAddrOf
   6E13 E5 10              1177 	mov	a,_bp
   6E15 24 03              1178 	add	a,#0x03
   6E17 FC                 1179 	mov	r4,a
                           1180 ;	genCast
   6E18 7D 00              1181 	mov	r5,#0x00
   6E1A 7E 40              1182 	mov	r6,#0x40
                           1183 ;	genAssign
   6E1C 90 EF FA           1184 	mov	dptr,#_neighbor_info
   6E1F E0                 1185 	movx	a,@dptr
   6E20 FF                 1186 	mov	r7,a
   6E21 A3                 1187 	inc	dptr
   6E22 E0                 1188 	movx	a,@dptr
   6E23 FA                 1189 	mov	r2,a
   6E24 A3                 1190 	inc	dptr
   6E25 E0                 1191 	movx	a,@dptr
   6E26 FB                 1192 	mov	r3,a
                           1193 ;	genIpush
   6E27 E5 10              1194 	mov	a,_bp
   6E29 24 06              1195 	add	a,#0x06
   6E2B F8                 1196 	mov	r0,a
   6E2C E6                 1197 	mov	a,@r0
   6E2D C0 E0              1198 	push	acc
   6E2F 08                 1199 	inc	r0
   6E30 E6                 1200 	mov	a,@r0
   6E31 C0 E0              1201 	push	acc
                           1202 ;	genIpush
   6E33 C0 04              1203 	push	ar4
   6E35 C0 05              1204 	push	ar5
   6E37 C0 06              1205 	push	ar6
                           1206 ;	genCall
   6E39 8F 82              1207 	mov	dpl,r7
   6E3B 8A 83              1208 	mov	dph,r2
   6E3D 8B F0              1209 	mov	b,r3
   6E3F 12 23 5A           1210 	lcall	_xQueueReceive
   6E42 AA 82              1211 	mov	r2,dpl
   6E44 E5 81              1212 	mov	a,sp
   6E46 24 FB              1213 	add	a,#0xfb
   6E48 F5 81              1214 	mov	sp,a
                           1215 ;	genCmpEq
                           1216 ;	gencjneshort
                           1217 ;	Peephole 112.b	changed ljmp to sjmp
                           1218 ;	Peephole 198.b	optimized misc jump sequence
   6E4A BA 01 0F           1219 	cjne	r2,#0x01,00110$
                           1220 ;	Peephole 200.b	removed redundant sjmp
                           1221 ;	Peephole 300	removed redundant label 00122$
                           1222 ;	Peephole 300	removed redundant label 00123$
                           1223 ;	../../Common/routing.c:200: return b;
                           1224 ;	genRet
   6E4D A8 10              1225 	mov	r0,_bp
   6E4F 08                 1226 	inc	r0
   6E50 08                 1227 	inc	r0
   6E51 08                 1228 	inc	r0
   6E52 86 82              1229 	mov	dpl,@r0
   6E54 08                 1230 	inc	r0
   6E55 86 83              1231 	mov	dph,@r0
   6E57 08                 1232 	inc	r0
   6E58 86 F0              1233 	mov	b,@r0
                           1234 ;	Peephole 112.b	changed ljmp to sjmp
   6E5A 80 06              1235 	sjmp	00111$
   6E5C                    1236 00110$:
                           1237 ;	../../Common/routing.c:202: return 0;
                           1238 ;	genRet
                           1239 ;	Peephole 182.b	used 16 bit load of dptr
   6E5C 90 00 00           1240 	mov	dptr,#0x0000
   6E5F 75 F0 00           1241 	mov	b,#0x00
   6E62                    1242 00111$:
   6E62 85 10 81           1243 	mov	sp,_bp
   6E65 D0 10              1244 	pop	_bp
   6E67 22                 1245 	ret
                           1246 ;------------------------------------------------------------
                           1247 ;Allocation info for local variables in function 'neigh_buffer_free'
                           1248 ;------------------------------------------------------------
                           1249 ;b                         Allocated to stack - offset 1
                           1250 ;------------------------------------------------------------
                           1251 ;	../../Common/routing.c:210: void neigh_buffer_free( neighbor_info_t *b )
                           1252 ;	-----------------------------------------
                           1253 ;	 function neigh_buffer_free
                           1254 ;	-----------------------------------------
   6E68                    1255 _neigh_buffer_free:
   6E68 C0 10              1256 	push	_bp
   6E6A 85 81 10           1257 	mov	_bp,sp
                           1258 ;     genReceive
   6E6D C0 82              1259 	push	dpl
   6E6F C0 83              1260 	push	dph
   6E71 C0 F0              1261 	push	b
                           1262 ;	../../Common/routing.c:212: b->last_lqi  =	0;
                           1263 ;	genAssign
   6E73 A8 10              1264 	mov	r0,_bp
   6E75 08                 1265 	inc	r0
   6E76 86 02              1266 	mov	ar2,@r0
   6E78 08                 1267 	inc	r0
   6E79 86 03              1268 	mov	ar3,@r0
   6E7B 08                 1269 	inc	r0
   6E7C 86 04              1270 	mov	ar4,@r0
                           1271 ;	genPlus
                           1272 ;     genPlusIncr
   6E7E 74 0B              1273 	mov	a,#0x0B
                           1274 ;	Peephole 236.a	used r2 instead of ar2
   6E80 2A                 1275 	add	a,r2
   6E81 FD                 1276 	mov	r5,a
                           1277 ;	Peephole 181	changed mov to clr
   6E82 E4                 1278 	clr	a
                           1279 ;	Peephole 236.b	used r3 instead of ar3
   6E83 3B                 1280 	addc	a,r3
   6E84 FE                 1281 	mov	r6,a
   6E85 8C 07              1282 	mov	ar7,r4
                           1283 ;	genPointerSet
                           1284 ;	genGenPointerSet
   6E87 8D 82              1285 	mov	dpl,r5
   6E89 8E 83              1286 	mov	dph,r6
   6E8B 8F F0              1287 	mov	b,r7
                           1288 ;	Peephole 181	changed mov to clr
   6E8D E4                 1289 	clr	a
   6E8E 12 DF B7           1290 	lcall	__gptrput
                           1291 ;	../../Common/routing.c:213: b->last_sqn  =    0;
                           1292 ;	genPlus
                           1293 ;     genPlusIncr
   6E91 74 0C              1294 	mov	a,#0x0C
                           1295 ;	Peephole 236.a	used r2 instead of ar2
   6E93 2A                 1296 	add	a,r2
   6E94 FD                 1297 	mov	r5,a
                           1298 ;	Peephole 181	changed mov to clr
   6E95 E4                 1299 	clr	a
                           1300 ;	Peephole 236.b	used r3 instead of ar3
   6E96 3B                 1301 	addc	a,r3
   6E97 FE                 1302 	mov	r6,a
   6E98 8C 07              1303 	mov	ar7,r4
                           1304 ;	genPointerSet
                           1305 ;	genGenPointerSet
   6E9A 8D 82              1306 	mov	dpl,r5
   6E9C 8E 83              1307 	mov	dph,r6
   6E9E 8F F0              1308 	mov	b,r7
                           1309 ;	Peephole 181	changed mov to clr
   6EA0 E4                 1310 	clr	a
   6EA1 12 DF B7           1311 	lcall	__gptrput
                           1312 ;	../../Common/routing.c:214: b->child_dev =	0;
                           1313 ;	genPlus
                           1314 ;     genPlusIncr
   6EA4 74 0E              1315 	mov	a,#0x0E
                           1316 ;	Peephole 236.a	used r2 instead of ar2
   6EA6 2A                 1317 	add	a,r2
   6EA7 FD                 1318 	mov	r5,a
                           1319 ;	Peephole 181	changed mov to clr
   6EA8 E4                 1320 	clr	a
                           1321 ;	Peephole 236.b	used r3 instead of ar3
   6EA9 3B                 1322 	addc	a,r3
   6EAA FE                 1323 	mov	r6,a
   6EAB 8C 07              1324 	mov	ar7,r4
                           1325 ;	genPointerSet
                           1326 ;	genGenPointerSet
   6EAD 8D 82              1327 	mov	dpl,r5
   6EAF 8E 83              1328 	mov	dph,r6
   6EB1 8F F0              1329 	mov	b,r7
                           1330 ;	Peephole 181	changed mov to clr
   6EB3 E4                 1331 	clr	a
   6EB4 12 DF B7           1332 	lcall	__gptrput
                           1333 ;	../../Common/routing.c:215: b->type	   =	0;
                           1334 ;	genPlus
                           1335 ;     genPlusIncr
   6EB7 74 0A              1336 	mov	a,#0x0A
                           1337 ;	Peephole 236.a	used r2 instead of ar2
   6EB9 2A                 1338 	add	a,r2
   6EBA FA                 1339 	mov	r2,a
                           1340 ;	Peephole 181	changed mov to clr
   6EBB E4                 1341 	clr	a
                           1342 ;	Peephole 236.b	used r3 instead of ar3
   6EBC 3B                 1343 	addc	a,r3
   6EBD FB                 1344 	mov	r3,a
                           1345 ;	genPointerSet
                           1346 ;	genGenPointerSet
   6EBE 8A 82              1347 	mov	dpl,r2
   6EC0 8B 83              1348 	mov	dph,r3
   6EC2 8C F0              1349 	mov	b,r4
                           1350 ;	Peephole 181	changed mov to clr
   6EC4 E4                 1351 	clr	a
   6EC5 12 DF B7           1352 	lcall	__gptrput
                           1353 ;	../../Common/routing.c:216: xQueueSend( neighbor_info, ( void * ) &b, ( portTickType ) 0 );
                           1354 ;	genAddrOf
                           1355 ;	Peephole 212	reduced add sequence to inc
   6EC8 AA 10              1356 	mov	r2,_bp
   6ECA 0A                 1357 	inc	r2
                           1358 ;	genCast
   6ECB 7B 00              1359 	mov	r3,#0x00
   6ECD 7C 40              1360 	mov	r4,#0x40
                           1361 ;	genAssign
   6ECF 90 EF FA           1362 	mov	dptr,#_neighbor_info
   6ED2 E0                 1363 	movx	a,@dptr
   6ED3 FD                 1364 	mov	r5,a
   6ED4 A3                 1365 	inc	dptr
   6ED5 E0                 1366 	movx	a,@dptr
   6ED6 FE                 1367 	mov	r6,a
   6ED7 A3                 1368 	inc	dptr
   6ED8 E0                 1369 	movx	a,@dptr
   6ED9 FF                 1370 	mov	r7,a
                           1371 ;	genIpush
                           1372 ;	Peephole 181	changed mov to clr
   6EDA E4                 1373 	clr	a
   6EDB C0 E0              1374 	push	acc
   6EDD C0 E0              1375 	push	acc
                           1376 ;	genIpush
   6EDF C0 02              1377 	push	ar2
   6EE1 C0 03              1378 	push	ar3
   6EE3 C0 04              1379 	push	ar4
                           1380 ;	genCall
   6EE5 8D 82              1381 	mov	dpl,r5
   6EE7 8E 83              1382 	mov	dph,r6
   6EE9 8F F0              1383 	mov	b,r7
   6EEB 12 1D 8E           1384 	lcall	_xQueueSend
   6EEE E5 81              1385 	mov	a,sp
   6EF0 24 FB              1386 	add	a,#0xfb
   6EF2 F5 81              1387 	mov	sp,a
                           1388 ;	Peephole 300	removed redundant label 00101$
   6EF4 85 10 81           1389 	mov	sp,_bp
   6EF7 D0 10              1390 	pop	_bp
   6EF9 22                 1391 	ret
                           1392 ;------------------------------------------------------------
                           1393 ;Allocation info for local variables in function 'update_neighbour_table'
                           1394 ;------------------------------------------------------------
                           1395 ;address                   Allocated to stack - offset -5
                           1396 ;last_lqi                  Allocated to stack - offset -6
                           1397 ;last_sqn                  Allocated to stack - offset -7
                           1398 ;type                      Allocated to stack - offset 1
                           1399 ;i                         Allocated to stack - offset 2
                           1400 ;j                         Allocated to stack - offset 3
                           1401 ;tmp_8                     Allocated to stack - offset 4
                           1402 ;sqn_check                 Allocated to stack - offset 5
                           1403 ;length                    Allocated to stack - offset 6
                           1404 ;delivery_mode             Allocated to stack - offset 7
                           1405 ;sloc0                     Allocated to stack - offset 8
                           1406 ;sloc1                     Allocated to stack - offset 8
                           1407 ;sloc2                     Allocated to stack - offset 9
                           1408 ;sloc3                     Allocated to stack - offset 11
                           1409 ;------------------------------------------------------------
                           1410 ;	../../Common/routing.c:232: uint8_t update_neighbour_table(addrtype_t type, address_t address, uint8_t last_lqi, uint8_t last_sqn)
                           1411 ;	-----------------------------------------
                           1412 ;	 function update_neighbour_table
                           1413 ;	-----------------------------------------
   6EFA                    1414 _update_neighbour_table:
   6EFA C0 10              1415 	push	_bp
   6EFC 85 81 10           1416 	mov	_bp,sp
                           1417 ;     genReceive
   6EFF C0 82              1418 	push	dpl
   6F01 E5 81              1419 	mov	a,sp
   6F03 24 0C              1420 	add	a,#0x0c
   6F05 F5 81              1421 	mov	sp,a
                           1422 ;	../../Common/routing.c:234: uint8_t i,j,tmp_8=0, sqn_check=0, length=0;
                           1423 ;	genAssign
   6F07 E5 10              1424 	mov	a,_bp
   6F09 24 05              1425 	add	a,#0x05
   6F0B F8                 1426 	mov	r0,a
   6F0C 76 00              1427 	mov	@r0,#0x00
                           1428 ;	genAssign
   6F0E E5 10              1429 	mov	a,_bp
   6F10 24 06              1430 	add	a,#0x06
   6F12 F8                 1431 	mov	r0,a
   6F13 76 00              1432 	mov	@r0,#0x00
                           1433 ;	../../Common/routing.c:238: if( xSemaphoreTake( table_lock, ( portTickType ) 10 ) == pdTRUE )
                           1434 ;	genAssign
   6F15 90 F0 E7           1435 	mov	dptr,#_table_lock
   6F18 E0                 1436 	movx	a,@dptr
   6F19 FD                 1437 	mov	r5,a
   6F1A A3                 1438 	inc	dptr
   6F1B E0                 1439 	movx	a,@dptr
   6F1C FE                 1440 	mov	r6,a
   6F1D A3                 1441 	inc	dptr
   6F1E E0                 1442 	movx	a,@dptr
   6F1F FF                 1443 	mov	r7,a
                           1444 ;	genIpush
   6F20 74 0A              1445 	mov	a,#0x0A
   6F22 C0 E0              1446 	push	acc
                           1447 ;	Peephole 181	changed mov to clr
   6F24 E4                 1448 	clr	a
   6F25 C0 E0              1449 	push	acc
                           1450 ;	genIpush
                           1451 ;	Peephole 181	changed mov to clr
   6F27 E4                 1452 	clr	a
   6F28 C0 E0              1453 	push	acc
   6F2A C0 E0              1454 	push	acc
   6F2C C0 E0              1455 	push	acc
                           1456 ;	genCall
   6F2E 8D 82              1457 	mov	dpl,r5
   6F30 8E 83              1458 	mov	dph,r6
   6F32 8F F0              1459 	mov	b,r7
   6F34 12 23 5A           1460 	lcall	_xQueueReceive
   6F37 AD 82              1461 	mov	r5,dpl
   6F39 E5 81              1462 	mov	a,sp
   6F3B 24 FB              1463 	add	a,#0xfb
   6F3D F5 81              1464 	mov	sp,a
                           1465 ;	genCmpEq
                           1466 ;	gencjneshort
   6F3F BD 01 02           1467 	cjne	r5,#0x01,00163$
   6F42 80 03              1468 	sjmp	00164$
   6F44                    1469 00163$:
   6F44 02 73 62           1470 	ljmp	00126$
   6F47                    1471 00164$:
                           1472 ;	../../Common/routing.c:240: if(type==ADDR_802_15_4_PAN_LONG)
                           1473 ;	genCmpEq
   6F47 A8 10              1474 	mov	r0,_bp
   6F49 08                 1475 	inc	r0
                           1476 ;	gencjne
                           1477 ;	gencjneshort
                           1478 ;	Peephole 241.h	optimized compare
   6F4A E4                 1479 	clr	a
   6F4B B6 04 01           1480 	cjne	@r0,#0x04,00165$
   6F4E 04                 1481 	inc	a
   6F4F                    1482 00165$:
                           1483 ;	Peephole 300	removed redundant label 00166$
                           1484 ;	genIfx
   6F4F FD                 1485 	mov	r5,a
                           1486 ;	Peephole 105	removed redundant mov
                           1487 ;	genIfxJump
                           1488 ;	Peephole 108.c	removed ljmp by inverse jump logic
   6F50 60 07              1489 	jz	00102$
                           1490 ;	Peephole 300	removed redundant label 00167$
                           1491 ;	../../Common/routing.c:245: length=8;					
                           1492 ;	genAssign
   6F52 E5 10              1493 	mov	a,_bp
   6F54 24 06              1494 	add	a,#0x06
   6F56 F8                 1495 	mov	r0,a
   6F57 76 08              1496 	mov	@r0,#0x08
   6F59                    1497 00102$:
                           1498 ;	../../Common/routing.c:248: if(type == ADDR_802_15_4_PAN_SHORT)
                           1499 ;	genCmpEq
   6F59 A8 10              1500 	mov	r0,_bp
   6F5B 08                 1501 	inc	r0
   6F5C E5 10              1502 	mov	a,_bp
   6F5E 24 08              1503 	add	a,#0x08
   6F60 F9                 1504 	mov	r1,a
                           1505 ;	gencjne
                           1506 ;	gencjneshort
                           1507 ;	Peephole 241.h	optimized compare
   6F61 E4                 1508 	clr	a
   6F62 B6 03 01           1509 	cjne	@r0,#0x03,00168$
   6F65 04                 1510 	inc	a
   6F66                    1511 00168$:
                           1512 ;	Peephole 300	removed redundant label 00169$
   6F66 F7                 1513 	mov	@r1,a
                           1514 ;	genIfx
   6F67 E5 10              1515 	mov	a,_bp
   6F69 24 08              1516 	add	a,#0x08
   6F6B F8                 1517 	mov	r0,a
   6F6C E6                 1518 	mov	a,@r0
                           1519 ;	genIfxJump
                           1520 ;	Peephole 108.c	removed ljmp by inverse jump logic
   6F6D 60 07              1521 	jz	00104$
                           1522 ;	Peephole 300	removed redundant label 00170$
                           1523 ;	../../Common/routing.c:250: length=4;
                           1524 ;	genAssign
   6F6F E5 10              1525 	mov	a,_bp
   6F71 24 06              1526 	add	a,#0x06
   6F73 F8                 1527 	mov	r0,a
   6F74 76 04              1528 	mov	@r0,#0x04
   6F76                    1529 00104$:
                           1530 ;	../../Common/routing.c:252: delivery_mode = NOT_NEIGHBOR;
                           1531 ;	genAssign
   6F76 E5 10              1532 	mov	a,_bp
   6F78 24 07              1533 	add	a,#0x07
   6F7A F8                 1534 	mov	r0,a
   6F7B 76 02              1535 	mov	@r0,#0x02
                           1536 ;	../../Common/routing.c:253: if(neighbor_table.count > 0)
                           1537 ;	genPointerGet
                           1538 ;	genFarPointerGet
   6F7D 90 EF BC           1539 	mov	dptr,#_neighbor_table
   6F80 E0                 1540 	movx	a,@dptr
                           1541 ;	genIfxJump
   6F81 70 03              1542 	jnz	00171$
   6F83 02 71 C2           1543 	ljmp	00117$
   6F86                    1544 00171$:
                           1545 ;	../../Common/routing.c:255: for(i=0; i < neighbor_table.count ; i++)
                           1546 ;	genAssign
   6F86 A8 10              1547 	mov	r0,_bp
   6F88 08                 1548 	inc	r0
   6F89 08                 1549 	inc	r0
   6F8A 76 00              1550 	mov	@r0,#0x00
   6F8C                    1551 00131$:
                           1552 ;	genIpush
   6F8C C0 05              1553 	push	ar5
                           1554 ;	genPointerGet
                           1555 ;	genFarPointerGet
   6F8E 90 EF BC           1556 	mov	dptr,#_neighbor_table
   6F91 E0                 1557 	movx	a,@dptr
   6F92 FD                 1558 	mov	r5,a
                           1559 ;	genCmpLt
   6F93 A8 10              1560 	mov	r0,_bp
   6F95 08                 1561 	inc	r0
   6F96 08                 1562 	inc	r0
                           1563 ;	genCmp
   6F97 C3                 1564 	clr	c
   6F98 E6                 1565 	mov	a,@r0
   6F99 9D                 1566 	subb	a,r5
                           1567 ;	genIpop
                           1568 ;	genIfx
                           1569 ;	genIfxJump
                           1570 ;	Peephole 129.b	optimized condition
   6F9A D0 05              1571 	pop	ar5
   6F9C 40 03              1572 	jc	00172$
   6F9E 02 71 C2           1573 	ljmp	00117$
   6FA1                    1574 00172$:
                           1575 ;	../../Common/routing.c:257: if(neighbor_table.neighbor_info[i] && (type == neighbor_table.neighbor_info[i]->type))
                           1576 ;	genMult
   6FA1 A8 10              1577 	mov	r0,_bp
   6FA3 08                 1578 	inc	r0
   6FA4 08                 1579 	inc	r0
                           1580 ;	genMultOneByte
   6FA5 E6                 1581 	mov	a,@r0
   6FA6 75 F0 03           1582 	mov	b,#0x03
   6FA9 A4                 1583 	mul	ab
                           1584 ;	genPlus
   6FAA FC                 1585 	mov	r4,a
                           1586 ;	Peephole 177.b	removed redundant mov
   6FAB 24 BE              1587 	add	a,#(_neighbor_table + 0x0002)
   6FAD F5 82              1588 	mov	dpl,a
                           1589 ;	Peephole 181	changed mov to clr
   6FAF E4                 1590 	clr	a
   6FB0 34 EF              1591 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   6FB2 F5 83              1592 	mov	dph,a
                           1593 ;	genPointerGet
                           1594 ;	genFarPointerGet
   6FB4 E0                 1595 	movx	a,@dptr
   6FB5 FF                 1596 	mov	r7,a
   6FB6 A3                 1597 	inc	dptr
   6FB7 E0                 1598 	movx	a,@dptr
   6FB8 FA                 1599 	mov	r2,a
   6FB9 A3                 1600 	inc	dptr
   6FBA E0                 1601 	movx	a,@dptr
   6FBB FB                 1602 	mov	r3,a
                           1603 ;	genIfx
   6FBC EF                 1604 	mov	a,r7
   6FBD 4A                 1605 	orl	a,r2
   6FBE 4B                 1606 	orl	a,r3
                           1607 ;	genIfxJump
   6FBF 70 03              1608 	jnz	00173$
   6FC1 02 71 BA           1609 	ljmp	00133$
   6FC4                    1610 00173$:
                           1611 ;	genPlus
                           1612 ;	Peephole 236.g	used r4 instead of ar4
   6FC4 EC                 1613 	mov	a,r4
   6FC5 24 BE              1614 	add	a,#(_neighbor_table + 0x0002)
   6FC7 F5 82              1615 	mov	dpl,a
                           1616 ;	Peephole 181	changed mov to clr
   6FC9 E4                 1617 	clr	a
   6FCA 34 EF              1618 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   6FCC F5 83              1619 	mov	dph,a
                           1620 ;	genPointerGet
                           1621 ;	genFarPointerGet
   6FCE E0                 1622 	movx	a,@dptr
   6FCF FA                 1623 	mov	r2,a
   6FD0 A3                 1624 	inc	dptr
   6FD1 E0                 1625 	movx	a,@dptr
   6FD2 FB                 1626 	mov	r3,a
   6FD3 A3                 1627 	inc	dptr
   6FD4 E0                 1628 	movx	a,@dptr
   6FD5 FF                 1629 	mov	r7,a
                           1630 ;	genPlus
                           1631 ;     genPlusIncr
   6FD6 74 0A              1632 	mov	a,#0x0A
                           1633 ;	Peephole 236.a	used r2 instead of ar2
   6FD8 2A                 1634 	add	a,r2
   6FD9 FA                 1635 	mov	r2,a
                           1636 ;	Peephole 181	changed mov to clr
   6FDA E4                 1637 	clr	a
                           1638 ;	Peephole 236.b	used r3 instead of ar3
   6FDB 3B                 1639 	addc	a,r3
   6FDC FB                 1640 	mov	r3,a
                           1641 ;	genPointerGet
                           1642 ;	genGenPointerGet
   6FDD 8A 82              1643 	mov	dpl,r2
   6FDF 8B 83              1644 	mov	dph,r3
   6FE1 8F F0              1645 	mov	b,r7
   6FE3 12 E4 9F           1646 	lcall	__gptrget
   6FE6 FA                 1647 	mov	r2,a
                           1648 ;	genCmpEq
   6FE7 A8 10              1649 	mov	r0,_bp
   6FE9 08                 1650 	inc	r0
                           1651 ;	gencjneshort
   6FEA E6                 1652 	mov	a,@r0
   6FEB B5 02 02           1653 	cjne	a,ar2,00174$
   6FEE 80 03              1654 	sjmp	00175$
   6FF0                    1655 00174$:
   6FF0 02 71 BA           1656 	ljmp	00133$
   6FF3                    1657 00175$:
                           1658 ;	../../Common/routing.c:259: if(memcmp(neighbor_table.neighbor_info[i]->address, address,length) == 0)
                           1659 ;	genIpush
   6FF3 C0 05              1660 	push	ar5
                           1661 ;	genCast
   6FF5 E5 10              1662 	mov	a,_bp
   6FF7 24 06              1663 	add	a,#0x06
   6FF9 F8                 1664 	mov	r0,a
   6FFA 86 02              1665 	mov	ar2,@r0
   6FFC 7B 00              1666 	mov	r3,#0x00
                           1667 ;	genPlus
                           1668 ;	Peephole 236.g	used r4 instead of ar4
   6FFE EC                 1669 	mov	a,r4
   6FFF 24 BE              1670 	add	a,#(_neighbor_table + 0x0002)
   7001 F5 82              1671 	mov	dpl,a
                           1672 ;	Peephole 181	changed mov to clr
   7003 E4                 1673 	clr	a
   7004 34 EF              1674 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7006 F5 83              1675 	mov	dph,a
                           1676 ;	genPointerGet
                           1677 ;	genFarPointerGet
   7008 E0                 1678 	movx	a,@dptr
   7009 FF                 1679 	mov	r7,a
   700A A3                 1680 	inc	dptr
   700B E0                 1681 	movx	a,@dptr
   700C FD                 1682 	mov	r5,a
   700D A3                 1683 	inc	dptr
   700E E0                 1684 	movx	a,@dptr
   700F FC                 1685 	mov	r4,a
                           1686 ;	genIpush
   7010 C0 05              1687 	push	ar5
   7012 C0 02              1688 	push	ar2
   7014 C0 03              1689 	push	ar3
                           1690 ;	genIpush
   7016 E5 10              1691 	mov	a,_bp
   7018 24 FB              1692 	add	a,#0xfffffffb
   701A F8                 1693 	mov	r0,a
   701B E6                 1694 	mov	a,@r0
   701C C0 E0              1695 	push	acc
   701E 08                 1696 	inc	r0
   701F E6                 1697 	mov	a,@r0
   7020 C0 E0              1698 	push	acc
   7022 08                 1699 	inc	r0
   7023 E6                 1700 	mov	a,@r0
   7024 C0 E0              1701 	push	acc
                           1702 ;	genCall
   7026 8F 82              1703 	mov	dpl,r7
   7028 8D 83              1704 	mov	dph,r5
   702A 8C F0              1705 	mov	b,r4
   702C 12 E2 0A           1706 	lcall	_memcmp
   702F AA 82              1707 	mov	r2,dpl
   7031 AB 83              1708 	mov	r3,dph
   7033 E5 81              1709 	mov	a,sp
   7035 24 FB              1710 	add	a,#0xfb
   7037 F5 81              1711 	mov	sp,a
   7039 D0 05              1712 	pop	ar5
                           1713 ;	genIpop
   703B D0 05              1714 	pop	ar5
                           1715 ;	genIfx
   703D EA                 1716 	mov	a,r2
   703E 4B                 1717 	orl	a,r3
                           1718 ;	genIfxJump
                           1719 ;	Peephole 108.b	removed ljmp by inverse jump logic
   703F 70 07              1720 	jnz	00106$
                           1721 ;	Peephole 300	removed redundant label 00176$
                           1722 ;	../../Common/routing.c:261: delivery_mode = NEIGHBOR;
                           1723 ;	genAssign
   7041 E5 10              1724 	mov	a,_bp
   7043 24 07              1725 	add	a,#0x07
   7045 F8                 1726 	mov	r0,a
   7046 76 01              1727 	mov	@r0,#0x01
   7048                    1728 00106$:
                           1729 ;	../../Common/routing.c:264: if( delivery_mode == NEIGHBOR )
                           1730 ;	genCmpEq
   7048 E5 10              1731 	mov	a,_bp
   704A 24 07              1732 	add	a,#0x07
   704C F8                 1733 	mov	r0,a
                           1734 ;	gencjneshort
   704D B6 01 02           1735 	cjne	@r0,#0x01,00177$
   7050 80 03              1736 	sjmp	00178$
   7052                    1737 00177$:
   7052 02 71 BA           1738 	ljmp	00133$
   7055                    1739 00178$:
                           1740 ;	../../Common/routing.c:267: if(type != ADDR_802_15_4_PAN_SHORT)
                           1741 ;	genIfx
   7055 E5 10              1742 	mov	a,_bp
   7057 24 08              1743 	add	a,#0x08
   7059 F8                 1744 	mov	r0,a
   705A E6                 1745 	mov	a,@r0
                           1746 ;	genIfxJump
   705B 60 03              1747 	jz	00179$
   705D 02 71 01           1748 	ljmp	00108$
   7060                    1749 00179$:
                           1750 ;	../../Common/routing.c:269: for(j=0; j<2; j++)
                           1751 ;	genMult
   7060 A8 10              1752 	mov	r0,_bp
   7062 08                 1753 	inc	r0
   7063 08                 1754 	inc	r0
                           1755 ;	genMultOneByte
   7064 E6                 1756 	mov	a,@r0
   7065 75 F0 03           1757 	mov	b,#0x03
   7068 A4                 1758 	mul	ab
                           1759 ;	genPlus
   7069 C0 E0              1760 	push	acc
   706B E5 10              1761 	mov	a,_bp
   706D 24 09              1762 	add	a,#0x09
   706F F8                 1763 	mov	r0,a
   7070 D0 E0              1764 	pop	acc
   7072 24 BE              1765 	add	a,#(_neighbor_table + 0x0002)
   7074 F6                 1766 	mov	@r0,a
                           1767 ;	Peephole 240	use clr instead of addc a,#0
   7075 E4                 1768 	clr	a
   7076 34 EF              1769 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7078 08                 1770 	inc	r0
   7079 F6                 1771 	mov	@r0,a
                           1772 ;	genAssign
   707A A8 10              1773 	mov	r0,_bp
   707C 08                 1774 	inc	r0
   707D 08                 1775 	inc	r0
   707E 08                 1776 	inc	r0
   707F 76 00              1777 	mov	@r0,#0x00
   7081                    1778 00127$:
                           1779 ;	genCmpLt
   7081 A8 10              1780 	mov	r0,_bp
   7083 08                 1781 	inc	r0
   7084 08                 1782 	inc	r0
   7085 08                 1783 	inc	r0
                           1784 ;	genCmp
   7086 B6 02 00           1785 	cjne	@r0,#0x02,00180$
   7089                    1786 00180$:
                           1787 ;	genIfxJump
                           1788 ;	Peephole 108.a	removed ljmp by inverse jump logic
   7089 50 76              1789 	jnc	00108$
                           1790 ;	Peephole 300	removed redundant label 00181$
                           1791 ;	../../Common/routing.c:271: neighbor_table.neighbor_info[i]->address[length+j] = address[length+j];
                           1792 ;	genIpush
   708B C0 05              1793 	push	ar5
                           1794 ;	genPointerGet
                           1795 ;	genFarPointerGet
   708D E5 10              1796 	mov	a,_bp
   708F 24 09              1797 	add	a,#0x09
   7091 F8                 1798 	mov	r0,a
   7092 86 82              1799 	mov	dpl,@r0
   7094 08                 1800 	inc	r0
   7095 86 83              1801 	mov	dph,@r0
   7097 E0                 1802 	movx	a,@dptr
   7098 FF                 1803 	mov	r7,a
   7099 A3                 1804 	inc	dptr
   709A E0                 1805 	movx	a,@dptr
   709B FD                 1806 	mov	r5,a
   709C A3                 1807 	inc	dptr
   709D E0                 1808 	movx	a,@dptr
   709E FC                 1809 	mov	r4,a
                           1810 ;	genPlus
   709F E5 10              1811 	mov	a,_bp
   70A1 24 06              1812 	add	a,#0x06
   70A3 F8                 1813 	mov	r0,a
   70A4 A9 10              1814 	mov	r1,_bp
   70A6 09                 1815 	inc	r1
   70A7 09                 1816 	inc	r1
   70A8 09                 1817 	inc	r1
   70A9 E7                 1818 	mov	a,@r1
   70AA 26                 1819 	add	a,@r0
                           1820 ;	genPlus
                           1821 ;	Peephole 236.a	used r7 instead of ar7
   70AB 2F                 1822 	add	a,r7
   70AC FF                 1823 	mov	r7,a
                           1824 ;	Peephole 236.g	used r5 instead of ar5
                           1825 ;	Peephole 240	use clr instead of addc a,#0
   70AD E4                 1826 	clr	a
   70AE 3D                 1827 	addc	a,r5
   70AF FD                 1828 	mov	r5,a
                           1829 ;	genCast
   70B0 E5 10              1830 	mov	a,_bp
   70B2 24 06              1831 	add	a,#0x06
   70B4 F8                 1832 	mov	r0,a
   70B5 E5 10              1833 	mov	a,_bp
   70B7 24 0B              1834 	add	a,#0x0b
   70B9 F9                 1835 	mov	r1,a
   70BA E6                 1836 	mov	a,@r0
   70BB F7                 1837 	mov	@r1,a
   70BC 09                 1838 	inc	r1
   70BD 77 00              1839 	mov	@r1,#0x00
                           1840 ;	genCast
   70BF A8 10              1841 	mov	r0,_bp
   70C1 08                 1842 	inc	r0
   70C2 08                 1843 	inc	r0
   70C3 08                 1844 	inc	r0
   70C4 86 03              1845 	mov	ar3,@r0
   70C6 7A 00              1846 	mov	r2,#0x00
                           1847 ;	genPlus
   70C8 E5 10              1848 	mov	a,_bp
   70CA 24 0B              1849 	add	a,#0x0b
   70CC F8                 1850 	mov	r0,a
                           1851 ;	Peephole 236.g	used r3 instead of ar3
   70CD EB                 1852 	mov	a,r3
   70CE 26                 1853 	add	a,@r0
   70CF FB                 1854 	mov	r3,a
                           1855 ;	Peephole 236.g	used r2 instead of ar2
   70D0 EA                 1856 	mov	a,r2
   70D1 08                 1857 	inc	r0
   70D2 36                 1858 	addc	a,@r0
   70D3 FA                 1859 	mov	r2,a
                           1860 ;	genPlus
   70D4 E5 10              1861 	mov	a,_bp
   70D6 24 FB              1862 	add	a,#0xfffffffb
   70D8 F8                 1863 	mov	r0,a
                           1864 ;	Peephole 236.g	used r3 instead of ar3
   70D9 EB                 1865 	mov	a,r3
   70DA 26                 1866 	add	a,@r0
   70DB FB                 1867 	mov	r3,a
                           1868 ;	Peephole 236.g	used r2 instead of ar2
   70DC EA                 1869 	mov	a,r2
   70DD 08                 1870 	inc	r0
   70DE 36                 1871 	addc	a,@r0
   70DF FA                 1872 	mov	r2,a
   70E0 08                 1873 	inc	r0
   70E1 86 06              1874 	mov	ar6,@r0
                           1875 ;	genPointerGet
                           1876 ;	genGenPointerGet
   70E3 8B 82              1877 	mov	dpl,r3
   70E5 8A 83              1878 	mov	dph,r2
   70E7 8E F0              1879 	mov	b,r6
   70E9 12 E4 9F           1880 	lcall	__gptrget
                           1881 ;	genPointerSet
                           1882 ;	genGenPointerSet
   70EC FB                 1883 	mov	r3,a
   70ED 8F 82              1884 	mov	dpl,r7
   70EF 8D 83              1885 	mov	dph,r5
   70F1 8C F0              1886 	mov	b,r4
                           1887 ;	Peephole 191	removed redundant mov
   70F3 12 DF B7           1888 	lcall	__gptrput
                           1889 ;	../../Common/routing.c:269: for(j=0; j<2; j++)
                           1890 ;	genPlus
   70F6 A8 10              1891 	mov	r0,_bp
   70F8 08                 1892 	inc	r0
   70F9 08                 1893 	inc	r0
   70FA 08                 1894 	inc	r0
                           1895 ;     genPlusIncr
   70FB 06                 1896 	inc	@r0
                           1897 ;	genIpop
   70FC D0 05              1898 	pop	ar5
   70FE 02 70 81           1899 	ljmp	00127$
   7101                    1900 00108$:
                           1901 ;	../../Common/routing.c:276: if(neighbor_table.neighbor_info[i]->last_sqn != last_sqn)
                           1902 ;	genMult
   7101 A8 10              1903 	mov	r0,_bp
   7103 08                 1904 	inc	r0
   7104 08                 1905 	inc	r0
                           1906 ;	genMultOneByte
   7105 E6                 1907 	mov	a,@r0
   7106 75 F0 03           1908 	mov	b,#0x03
   7109 A4                 1909 	mul	ab
                           1910 ;	genPlus
   710A FA                 1911 	mov	r2,a
                           1912 ;	Peephole 177.b	removed redundant mov
   710B 24 BE              1913 	add	a,#(_neighbor_table + 0x0002)
   710D F5 82              1914 	mov	dpl,a
                           1915 ;	Peephole 181	changed mov to clr
   710F E4                 1916 	clr	a
   7110 34 EF              1917 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7112 F5 83              1918 	mov	dph,a
                           1919 ;	genPointerGet
                           1920 ;	genFarPointerGet
   7114 E0                 1921 	movx	a,@dptr
   7115 FB                 1922 	mov	r3,a
   7116 A3                 1923 	inc	dptr
   7117 E0                 1924 	movx	a,@dptr
   7118 FC                 1925 	mov	r4,a
   7119 A3                 1926 	inc	dptr
   711A E0                 1927 	movx	a,@dptr
   711B FE                 1928 	mov	r6,a
                           1929 ;	genPlus
                           1930 ;     genPlusIncr
   711C 74 0C              1931 	mov	a,#0x0C
                           1932 ;	Peephole 236.a	used r3 instead of ar3
   711E 2B                 1933 	add	a,r3
   711F FB                 1934 	mov	r3,a
                           1935 ;	Peephole 181	changed mov to clr
   7120 E4                 1936 	clr	a
                           1937 ;	Peephole 236.b	used r4 instead of ar4
   7121 3C                 1938 	addc	a,r4
   7122 FC                 1939 	mov	r4,a
                           1940 ;	genPointerGet
                           1941 ;	genGenPointerGet
   7123 8B 82              1942 	mov	dpl,r3
   7125 8C 83              1943 	mov	dph,r4
   7127 8E F0              1944 	mov	b,r6
   7129 12 E4 9F           1945 	lcall	__gptrget
   712C FB                 1946 	mov	r3,a
                           1947 ;	genCmpEq
   712D E5 10              1948 	mov	a,_bp
   712F 24 F9              1949 	add	a,#0xfffffff9
   7131 F8                 1950 	mov	r0,a
                           1951 ;	gencjneshort
   7132 E6                 1952 	mov	a,@r0
   7133 B5 03 02           1953 	cjne	a,ar3,00182$
                           1954 ;	Peephole 112.b	changed ljmp to sjmp
   7136 80 2F              1955 	sjmp	00110$
   7138                    1956 00182$:
                           1957 ;	../../Common/routing.c:278: neighbor_table.neighbor_info[i]->last_sqn = last_sqn;
                           1958 ;	genPlus
                           1959 ;	Peephole 236.g	used r2 instead of ar2
   7138 EA                 1960 	mov	a,r2
   7139 24 BE              1961 	add	a,#(_neighbor_table + 0x0002)
   713B F5 82              1962 	mov	dpl,a
                           1963 ;	Peephole 181	changed mov to clr
   713D E4                 1964 	clr	a
   713E 34 EF              1965 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7140 F5 83              1966 	mov	dph,a
                           1967 ;	genPointerGet
                           1968 ;	genFarPointerGet
   7142 E0                 1969 	movx	a,@dptr
   7143 FA                 1970 	mov	r2,a
   7144 A3                 1971 	inc	dptr
   7145 E0                 1972 	movx	a,@dptr
   7146 FB                 1973 	mov	r3,a
   7147 A3                 1974 	inc	dptr
   7148 E0                 1975 	movx	a,@dptr
   7149 FC                 1976 	mov	r4,a
                           1977 ;	genPlus
                           1978 ;     genPlusIncr
   714A 74 0C              1979 	mov	a,#0x0C
                           1980 ;	Peephole 236.a	used r2 instead of ar2
   714C 2A                 1981 	add	a,r2
   714D FA                 1982 	mov	r2,a
                           1983 ;	Peephole 181	changed mov to clr
   714E E4                 1984 	clr	a
                           1985 ;	Peephole 236.b	used r3 instead of ar3
   714F 3B                 1986 	addc	a,r3
   7150 FB                 1987 	mov	r3,a
                           1988 ;	genPointerSet
                           1989 ;	genGenPointerSet
   7151 8A 82              1990 	mov	dpl,r2
   7153 8B 83              1991 	mov	dph,r3
   7155 8C F0              1992 	mov	b,r4
   7157 E5 10              1993 	mov	a,_bp
   7159 24 F9              1994 	add	a,#0xfffffff9
   715B F8                 1995 	mov	r0,a
   715C E6                 1996 	mov	a,@r0
   715D 12 DF B7           1997 	lcall	__gptrput
                           1998 ;	../../Common/routing.c:279: sqn_check=1;
                           1999 ;	genAssign
   7160 E5 10              2000 	mov	a,_bp
   7162 24 05              2001 	add	a,#0x05
   7164 F8                 2002 	mov	r0,a
   7165 76 01              2003 	mov	@r0,#0x01
   7167                    2004 00110$:
                           2005 ;	../../Common/routing.c:281: neighbor_table.neighbor_info[i]->last_lqi = last_lqi;
                           2006 ;	genIpush
   7167 C0 05              2007 	push	ar5
                           2008 ;	genMult
   7169 A8 10              2009 	mov	r0,_bp
   716B 08                 2010 	inc	r0
   716C 08                 2011 	inc	r0
                           2012 ;	genMultOneByte
   716D E6                 2013 	mov	a,@r0
   716E 75 F0 03           2014 	mov	b,#0x03
   7171 A4                 2015 	mul	ab
                           2016 ;	genPlus
   7172 24 BE              2017 	add	a,#(_neighbor_table + 0x0002)
   7174 F5 82              2018 	mov	dpl,a
                           2019 ;	Peephole 240	use clr instead of addc a,#0
   7176 E4                 2020 	clr	a
   7177 34 EF              2021 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7179 F5 83              2022 	mov	dph,a
                           2023 ;	genPointerGet
                           2024 ;	genFarPointerGet
   717B E0                 2025 	movx	a,@dptr
   717C FA                 2026 	mov	r2,a
   717D A3                 2027 	inc	dptr
   717E E0                 2028 	movx	a,@dptr
   717F FB                 2029 	mov	r3,a
   7180 A3                 2030 	inc	dptr
   7181 E0                 2031 	movx	a,@dptr
   7182 FC                 2032 	mov	r4,a
                           2033 ;	genPlus
                           2034 ;     genPlusIncr
   7183 74 0B              2035 	mov	a,#0x0B
                           2036 ;	Peephole 236.a	used r2 instead of ar2
   7185 2A                 2037 	add	a,r2
   7186 FE                 2038 	mov	r6,a
                           2039 ;	Peephole 181	changed mov to clr
   7187 E4                 2040 	clr	a
                           2041 ;	Peephole 236.b	used r3 instead of ar3
   7188 3B                 2042 	addc	a,r3
   7189 FF                 2043 	mov	r7,a
   718A 8C 05              2044 	mov	ar5,r4
                           2045 ;	genPointerSet
                           2046 ;	genGenPointerSet
   718C 8E 82              2047 	mov	dpl,r6
   718E 8F 83              2048 	mov	dph,r7
   7190 8D F0              2049 	mov	b,r5
   7192 E5 10              2050 	mov	a,_bp
   7194 24 FA              2051 	add	a,#0xfffffffa
   7196 F8                 2052 	mov	r0,a
   7197 E6                 2053 	mov	a,@r0
   7198 12 DF B7           2054 	lcall	__gptrput
                           2055 ;	../../Common/routing.c:288: neighbor_table.neighbor_info[i]->ttl=TTL;
                           2056 ;	genPlus
                           2057 ;     genPlusIncr
   719B 74 0D              2058 	mov	a,#0x0D
                           2059 ;	Peephole 236.a	used r2 instead of ar2
   719D 2A                 2060 	add	a,r2
   719E FA                 2061 	mov	r2,a
                           2062 ;	Peephole 181	changed mov to clr
   719F E4                 2063 	clr	a
                           2064 ;	Peephole 236.b	used r3 instead of ar3
   71A0 3B                 2065 	addc	a,r3
   71A1 FB                 2066 	mov	r3,a
                           2067 ;	genPointerSet
                           2068 ;	genGenPointerSet
   71A2 8A 82              2069 	mov	dpl,r2
   71A4 8B 83              2070 	mov	dph,r3
   71A6 8C F0              2071 	mov	b,r4
   71A8 74 0F              2072 	mov	a,#0x0F
   71AA 12 DF B7           2073 	lcall	__gptrput
                           2074 ;	../../Common/routing.c:290: i=(neighbor_table.count);
                           2075 ;	genPointerGet
                           2076 ;	genFarPointerGet
   71AD 90 EF BC           2077 	mov	dptr,#_neighbor_table
   71B0 E0                 2078 	movx	a,@dptr
   71B1 FA                 2079 	mov	r2,a
                           2080 ;	genAssign
   71B2 A8 10              2081 	mov	r0,_bp
   71B4 08                 2082 	inc	r0
   71B5 08                 2083 	inc	r0
   71B6 A6 02              2084 	mov	@r0,ar2
                           2085 ;	../../Common/routing.c:364: return sqn_check;
                           2086 ;	genIpop
   71B8 D0 05              2087 	pop	ar5
                           2088 ;	../../Common/routing.c:290: i=(neighbor_table.count);
   71BA                    2089 00133$:
                           2090 ;	../../Common/routing.c:255: for(i=0; i < neighbor_table.count ; i++)
                           2091 ;	genPlus
   71BA A8 10              2092 	mov	r0,_bp
   71BC 08                 2093 	inc	r0
   71BD 08                 2094 	inc	r0
                           2095 ;     genPlusIncr
   71BE 06                 2096 	inc	@r0
   71BF 02 6F 8C           2097 	ljmp	00131$
   71C2                    2098 00117$:
                           2099 ;	../../Common/routing.c:296: if((delivery_mode == NOT_NEIGHBOR) && neighbor_table.count < MAX_NEIGHBOR_COUNT)
                           2100 ;	genCmpEq
   71C2 E5 10              2101 	mov	a,_bp
   71C4 24 07              2102 	add	a,#0x07
   71C6 F8                 2103 	mov	r0,a
                           2104 ;	gencjneshort
   71C7 B6 02 02           2105 	cjne	@r0,#0x02,00183$
   71CA 80 03              2106 	sjmp	00184$
   71CC                    2107 00183$:
   71CC 02 73 5F           2108 	ljmp	00123$
   71CF                    2109 00184$:
                           2110 ;	genPointerGet
                           2111 ;	genFarPointerGet
   71CF 90 EF BC           2112 	mov	dptr,#_neighbor_table
   71D2 E0                 2113 	movx	a,@dptr
   71D3 FA                 2114 	mov	r2,a
                           2115 ;	genCmpLt
                           2116 ;	genCmp
   71D4 BA 14 00           2117 	cjne	r2,#0x14,00185$
   71D7                    2118 00185$:
                           2119 ;	genIfxJump
   71D7 40 03              2120 	jc	00186$
   71D9 02 73 5F           2121 	ljmp	00123$
   71DC                    2122 00186$:
                           2123 ;	../../Common/routing.c:298: tmp_8=neighbor_table.count;
                           2124 ;	genIpush
   71DC C0 05              2125 	push	ar5
                           2126 ;	genAssign
                           2127 ;	genAssign
   71DE E5 10              2128 	mov	a,_bp
   71E0 24 04              2129 	add	a,#0x04
   71E2 F8                 2130 	mov	r0,a
   71E3 A6 02              2131 	mov	@r0,ar2
                           2132 ;	../../Common/routing.c:299: neighbor_table.neighbor_info[tmp_8] = neigh_buffer_get(2);
                           2133 ;	genMult
   71E5 E5 10              2134 	mov	a,_bp
   71E7 24 04              2135 	add	a,#0x04
   71E9 F8                 2136 	mov	r0,a
                           2137 ;	genMultOneByte
   71EA E6                 2138 	mov	a,@r0
   71EB 75 F0 03           2139 	mov	b,#0x03
   71EE A4                 2140 	mul	ab
                           2141 ;	genPlus
   71EF 24 BE              2142 	add	a,#(_neighbor_table + 0x0002)
   71F1 FB                 2143 	mov	r3,a
                           2144 ;	Peephole 240	use clr instead of addc a,#0
   71F2 E4                 2145 	clr	a
   71F3 34 EF              2146 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   71F5 FC                 2147 	mov	r4,a
                           2148 ;	genCall
                           2149 ;	Peephole 182.b	used 16 bit load of dptr
   71F6 90 00 02           2150 	mov	dptr,#0x0002
   71F9 C0 03              2151 	push	ar3
   71FB C0 04              2152 	push	ar4
   71FD 12 6D 4F           2153 	lcall	_neigh_buffer_get
   7200 AE 82              2154 	mov	r6,dpl
   7202 AF 83              2155 	mov	r7,dph
   7204 AD F0              2156 	mov	r5,b
   7206 D0 04              2157 	pop	ar4
   7208 D0 03              2158 	pop	ar3
                           2159 ;	genPointerSet
                           2160 ;     genFarPointerSet
   720A 8B 82              2161 	mov	dpl,r3
   720C 8C 83              2162 	mov	dph,r4
   720E EE                 2163 	mov	a,r6
   720F F0                 2164 	movx	@dptr,a
   7210 A3                 2165 	inc	dptr
   7211 EF                 2166 	mov	a,r7
   7212 F0                 2167 	movx	@dptr,a
   7213 A3                 2168 	inc	dptr
   7214 ED                 2169 	mov	a,r5
   7215 F0                 2170 	movx	@dptr,a
                           2171 ;	../../Common/routing.c:300: if(neighbor_table.neighbor_info[tmp_8])
                           2172 ;	genMult
   7216 E5 10              2173 	mov	a,_bp
   7218 24 04              2174 	add	a,#0x04
   721A F8                 2175 	mov	r0,a
   721B E5 10              2176 	mov	a,_bp
   721D 24 0B              2177 	add	a,#0x0b
   721F F9                 2178 	mov	r1,a
                           2179 ;	genMultOneByte
   7220 E6                 2180 	mov	a,@r0
   7221 75 F0 03           2181 	mov	b,#0x03
   7224 A4                 2182 	mul	ab
   7225 F7                 2183 	mov	@r1,a
                           2184 ;	genPlus
   7226 E5 10              2185 	mov	a,_bp
   7228 24 0B              2186 	add	a,#0x0b
   722A F8                 2187 	mov	r0,a
   722B E6                 2188 	mov	a,@r0
   722C 24 BE              2189 	add	a,#(_neighbor_table + 0x0002)
   722E F5 82              2190 	mov	dpl,a
                           2191 ;	Peephole 181	changed mov to clr
   7230 E4                 2192 	clr	a
   7231 34 EF              2193 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7233 F5 83              2194 	mov	dph,a
                           2195 ;	genPointerGet
                           2196 ;	genFarPointerGet
   7235 E0                 2197 	movx	a,@dptr
   7236 FB                 2198 	mov	r3,a
   7237 A3                 2199 	inc	dptr
   7238 E0                 2200 	movx	a,@dptr
   7239 FC                 2201 	mov	r4,a
   723A A3                 2202 	inc	dptr
   723B E0                 2203 	movx	a,@dptr
   723C FD                 2204 	mov	r5,a
                           2205 ;	genIfx
   723D EB                 2206 	mov	a,r3
   723E 4C                 2207 	orl	a,r4
   723F 4D                 2208 	orl	a,r5
                           2209 ;	genIpop
   7240 D0 05              2210 	pop	ar5
                           2211 ;	genIfxJump
   7242 70 03              2212 	jnz	00187$
   7244 02 73 5F           2213 	ljmp	00123$
   7247                    2214 00187$:
                           2215 ;	../../Common/routing.c:322: if(type==ADDR_802_15_4_PAN_LONG)
                           2216 ;	genIfx
   7247 ED                 2217 	mov	a,r5
                           2218 ;	genIfxJump
                           2219 ;	Peephole 108.c	removed ljmp by inverse jump logic
   7248 60 07              2220 	jz	00160$
                           2221 ;	Peephole 300	removed redundant label 00188$
                           2222 ;	../../Common/routing.c:324: length+=2;
                           2223 ;	genPlus
   724A E5 10              2224 	mov	a,_bp
   724C 24 06              2225 	add	a,#0x06
   724E F8                 2226 	mov	r0,a
                           2227 ;     genPlusIncr
   724F 06                 2228 	inc	@r0
   7250 06                 2229 	inc	@r0
                           2230 ;	../../Common/routing.c:326: for(j=0; j < length ; j++)
   7251                    2231 00160$:
                           2232 ;	genPlus
   7251 E5 10              2233 	mov	a,_bp
   7253 24 0B              2234 	add	a,#0x0b
   7255 F8                 2235 	mov	r0,a
   7256 E5 10              2236 	mov	a,_bp
   7258 24 09              2237 	add	a,#0x09
   725A F9                 2238 	mov	r1,a
   725B E6                 2239 	mov	a,@r0
   725C 24 BE              2240 	add	a,#(_neighbor_table + 0x0002)
   725E F7                 2241 	mov	@r1,a
                           2242 ;	Peephole 181	changed mov to clr
   725F E4                 2243 	clr	a
   7260 34 EF              2244 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7262 09                 2245 	inc	r1
   7263 F7                 2246 	mov	@r1,a
                           2247 ;	genAssign
   7264 A8 10              2248 	mov	r0,_bp
   7266 08                 2249 	inc	r0
   7267 08                 2250 	inc	r0
   7268 08                 2251 	inc	r0
   7269 76 00              2252 	mov	@r0,#0x00
   726B                    2253 00135$:
                           2254 ;	genCmpLt
   726B A8 10              2255 	mov	r0,_bp
   726D 08                 2256 	inc	r0
   726E 08                 2257 	inc	r0
   726F 08                 2258 	inc	r0
   7270 E5 10              2259 	mov	a,_bp
   7272 24 06              2260 	add	a,#0x06
   7274 F9                 2261 	mov	r1,a
                           2262 ;	genCmp
   7275 C3                 2263 	clr	c
   7276 E6                 2264 	mov	a,@r0
   7277 97                 2265 	subb	a,@r1
                           2266 ;	genIfxJump
                           2267 ;	Peephole 108.a	removed ljmp by inverse jump logic
   7278 50 4C              2268 	jnc	00138$
                           2269 ;	Peephole 300	removed redundant label 00189$
                           2270 ;	../../Common/routing.c:328: neighbor_table.neighbor_info[tmp_8]->address[j] = address[j];
                           2271 ;	genIpush
                           2272 ;	genPointerGet
                           2273 ;	genFarPointerGet
   727A E5 10              2274 	mov	a,_bp
   727C 24 09              2275 	add	a,#0x09
   727E F8                 2276 	mov	r0,a
   727F 86 82              2277 	mov	dpl,@r0
   7281 08                 2278 	inc	r0
   7282 86 83              2279 	mov	dph,@r0
   7284 E0                 2280 	movx	a,@dptr
   7285 FE                 2281 	mov	r6,a
   7286 A3                 2282 	inc	dptr
   7287 E0                 2283 	movx	a,@dptr
   7288 FF                 2284 	mov	r7,a
   7289 A3                 2285 	inc	dptr
   728A E0                 2286 	movx	a,@dptr
   728B FA                 2287 	mov	r2,a
                           2288 ;	genPlus
   728C A8 10              2289 	mov	r0,_bp
   728E 08                 2290 	inc	r0
   728F 08                 2291 	inc	r0
   7290 08                 2292 	inc	r0
   7291 E6                 2293 	mov	a,@r0
                           2294 ;	Peephole 236.a	used r6 instead of ar6
   7292 2E                 2295 	add	a,r6
   7293 FE                 2296 	mov	r6,a
                           2297 ;	Peephole 181	changed mov to clr
   7294 E4                 2298 	clr	a
                           2299 ;	Peephole 236.b	used r7 instead of ar7
   7295 3F                 2300 	addc	a,r7
   7296 FF                 2301 	mov	r7,a
                           2302 ;	genPlus
   7297 E5 10              2303 	mov	a,_bp
   7299 24 FB              2304 	add	a,#0xfffffffb
   729B F8                 2305 	mov	r0,a
   729C A9 10              2306 	mov	r1,_bp
   729E 09                 2307 	inc	r1
   729F 09                 2308 	inc	r1
   72A0 09                 2309 	inc	r1
   72A1 E7                 2310 	mov	a,@r1
   72A2 26                 2311 	add	a,@r0
   72A3 FD                 2312 	mov	r5,a
                           2313 ;	Peephole 181	changed mov to clr
   72A4 E4                 2314 	clr	a
   72A5 08                 2315 	inc	r0
   72A6 36                 2316 	addc	a,@r0
   72A7 FB                 2317 	mov	r3,a
   72A8 08                 2318 	inc	r0
   72A9 86 04              2319 	mov	ar4,@r0
                           2320 ;	genPointerGet
                           2321 ;	genGenPointerGet
   72AB 8D 82              2322 	mov	dpl,r5
   72AD 8B 83              2323 	mov	dph,r3
   72AF 8C F0              2324 	mov	b,r4
   72B1 12 E4 9F           2325 	lcall	__gptrget
                           2326 ;	genPointerSet
                           2327 ;	genGenPointerSet
   72B4 FD                 2328 	mov	r5,a
   72B5 8E 82              2329 	mov	dpl,r6
   72B7 8F 83              2330 	mov	dph,r7
   72B9 8A F0              2331 	mov	b,r2
                           2332 ;	Peephole 191	removed redundant mov
   72BB 12 DF B7           2333 	lcall	__gptrput
                           2334 ;	../../Common/routing.c:326: for(j=0; j < length ; j++)
                           2335 ;	genPlus
   72BE A8 10              2336 	mov	r0,_bp
   72C0 08                 2337 	inc	r0
   72C1 08                 2338 	inc	r0
   72C2 08                 2339 	inc	r0
                           2340 ;     genPlusIncr
   72C3 06                 2341 	inc	@r0
                           2342 ;	genIpop
                           2343 ;	Peephole 112.b	changed ljmp to sjmp
   72C4 80 A5              2344 	sjmp	00135$
   72C6                    2345 00138$:
                           2346 ;	../../Common/routing.c:336: neighbor_table.neighbor_info[tmp_8]->last_lqi  =	last_lqi;
                           2347 ;	genPlus
   72C6 E5 10              2348 	mov	a,_bp
   72C8 24 0B              2349 	add	a,#0x0b
   72CA F8                 2350 	mov	r0,a
   72CB E6                 2351 	mov	a,@r0
   72CC 24 BE              2352 	add	a,#(_neighbor_table + 0x0002)
   72CE F5 82              2353 	mov	dpl,a
                           2354 ;	Peephole 181	changed mov to clr
   72D0 E4                 2355 	clr	a
   72D1 34 EF              2356 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   72D3 F5 83              2357 	mov	dph,a
                           2358 ;	genPointerGet
                           2359 ;	genFarPointerGet
   72D5 E0                 2360 	movx	a,@dptr
   72D6 FB                 2361 	mov	r3,a
   72D7 A3                 2362 	inc	dptr
   72D8 E0                 2363 	movx	a,@dptr
   72D9 FC                 2364 	mov	r4,a
   72DA A3                 2365 	inc	dptr
   72DB E0                 2366 	movx	a,@dptr
   72DC FD                 2367 	mov	r5,a
                           2368 ;	genPlus
                           2369 ;     genPlusIncr
   72DD 74 0B              2370 	mov	a,#0x0B
                           2371 ;	Peephole 236.a	used r3 instead of ar3
   72DF 2B                 2372 	add	a,r3
   72E0 FE                 2373 	mov	r6,a
                           2374 ;	Peephole 181	changed mov to clr
   72E1 E4                 2375 	clr	a
                           2376 ;	Peephole 236.b	used r4 instead of ar4
   72E2 3C                 2377 	addc	a,r4
   72E3 FF                 2378 	mov	r7,a
   72E4 8D 02              2379 	mov	ar2,r5
                           2380 ;	genPointerSet
                           2381 ;	genGenPointerSet
   72E6 8E 82              2382 	mov	dpl,r6
   72E8 8F 83              2383 	mov	dph,r7
   72EA 8A F0              2384 	mov	b,r2
   72EC E5 10              2385 	mov	a,_bp
   72EE 24 FA              2386 	add	a,#0xfffffffa
   72F0 F8                 2387 	mov	r0,a
   72F1 E6                 2388 	mov	a,@r0
   72F2 12 DF B7           2389 	lcall	__gptrput
                           2390 ;	../../Common/routing.c:337: neighbor_table.neighbor_info[tmp_8]->last_sqn  =    last_sqn;
                           2391 ;	genPlus
                           2392 ;     genPlusIncr
   72F5 74 0C              2393 	mov	a,#0x0C
                           2394 ;	Peephole 236.a	used r3 instead of ar3
   72F7 2B                 2395 	add	a,r3
   72F8 FA                 2396 	mov	r2,a
                           2397 ;	Peephole 181	changed mov to clr
   72F9 E4                 2398 	clr	a
                           2399 ;	Peephole 236.b	used r4 instead of ar4
   72FA 3C                 2400 	addc	a,r4
   72FB FE                 2401 	mov	r6,a
   72FC 8D 07              2402 	mov	ar7,r5
                           2403 ;	genPointerSet
                           2404 ;	genGenPointerSet
   72FE 8A 82              2405 	mov	dpl,r2
   7300 8E 83              2406 	mov	dph,r6
   7302 8F F0              2407 	mov	b,r7
   7304 E5 10              2408 	mov	a,_bp
   7306 24 F9              2409 	add	a,#0xfffffff9
   7308 F8                 2410 	mov	r0,a
   7309 E6                 2411 	mov	a,@r0
   730A 12 DF B7           2412 	lcall	__gptrput
                           2413 ;	../../Common/routing.c:338: neighbor_table.neighbor_info[tmp_8]->child_dev =	0;
                           2414 ;	genPlus
                           2415 ;     genPlusIncr
   730D 74 0E              2416 	mov	a,#0x0E
                           2417 ;	Peephole 236.a	used r3 instead of ar3
   730F 2B                 2418 	add	a,r3
   7310 FA                 2419 	mov	r2,a
                           2420 ;	Peephole 181	changed mov to clr
   7311 E4                 2421 	clr	a
                           2422 ;	Peephole 236.b	used r4 instead of ar4
   7312 3C                 2423 	addc	a,r4
   7313 FE                 2424 	mov	r6,a
   7314 8D 07              2425 	mov	ar7,r5
                           2426 ;	genPointerSet
                           2427 ;	genGenPointerSet
   7316 8A 82              2428 	mov	dpl,r2
   7318 8E 83              2429 	mov	dph,r6
   731A 8F F0              2430 	mov	b,r7
                           2431 ;	Peephole 181	changed mov to clr
   731C E4                 2432 	clr	a
   731D 12 DF B7           2433 	lcall	__gptrput
                           2434 ;	../../Common/routing.c:339: sqn_check=1;
                           2435 ;	genAssign
   7320 E5 10              2436 	mov	a,_bp
   7322 24 05              2437 	add	a,#0x05
   7324 F8                 2438 	mov	r0,a
   7325 76 01              2439 	mov	@r0,#0x01
                           2440 ;	../../Common/routing.c:350: neighbor_table.neighbor_info[tmp_8]->ttl=TTL;
                           2441 ;	genPlus
                           2442 ;     genPlusIncr
   7327 74 0D              2443 	mov	a,#0x0D
                           2444 ;	Peephole 236.a	used r3 instead of ar3
   7329 2B                 2445 	add	a,r3
   732A FA                 2446 	mov	r2,a
                           2447 ;	Peephole 181	changed mov to clr
   732B E4                 2448 	clr	a
                           2449 ;	Peephole 236.b	used r4 instead of ar4
   732C 3C                 2450 	addc	a,r4
   732D FE                 2451 	mov	r6,a
   732E 8D 07              2452 	mov	ar7,r5
                           2453 ;	genPointerSet
                           2454 ;	genGenPointerSet
   7330 8A 82              2455 	mov	dpl,r2
   7332 8E 83              2456 	mov	dph,r6
   7334 8F F0              2457 	mov	b,r7
   7336 74 0F              2458 	mov	a,#0x0F
   7338 12 DF B7           2459 	lcall	__gptrput
                           2460 ;	../../Common/routing.c:352: neighbor_table.neighbor_info[tmp_8]->type = type;
                           2461 ;	genPlus
                           2462 ;     genPlusIncr
   733B 74 0A              2463 	mov	a,#0x0A
                           2464 ;	Peephole 236.a	used r3 instead of ar3
   733D 2B                 2465 	add	a,r3
   733E FB                 2466 	mov	r3,a
                           2467 ;	Peephole 181	changed mov to clr
   733F E4                 2468 	clr	a
                           2469 ;	Peephole 236.b	used r4 instead of ar4
   7340 3C                 2470 	addc	a,r4
   7341 FC                 2471 	mov	r4,a
                           2472 ;	genPointerSet
                           2473 ;	genGenPointerSet
   7342 8B 82              2474 	mov	dpl,r3
   7344 8C 83              2475 	mov	dph,r4
   7346 8D F0              2476 	mov	b,r5
   7348 A8 10              2477 	mov	r0,_bp
   734A 08                 2478 	inc	r0
   734B E6                 2479 	mov	a,@r0
   734C 12 DF B7           2480 	lcall	__gptrput
                           2481 ;	../../Common/routing.c:354: tmp_8++;
                           2482 ;	genPlus
   734F E5 10              2483 	mov	a,_bp
   7351 24 04              2484 	add	a,#0x04
   7353 F8                 2485 	mov	r0,a
                           2486 ;     genPlusIncr
   7354 06                 2487 	inc	@r0
                           2488 ;	../../Common/routing.c:355: neighbor_table.count = tmp_8;
                           2489 ;	genPointerSet
                           2490 ;     genFarPointerSet
   7355 90 EF BC           2491 	mov	dptr,#_neighbor_table
   7358 E5 10              2492 	mov	a,_bp
   735A 24 04              2493 	add	a,#0x04
   735C F8                 2494 	mov	r0,a
   735D E6                 2495 	mov	a,@r0
   735E F0                 2496 	movx	@dptr,a
                           2497 ;	../../Common/routing.c:359: delivery_mode = NEW_NEIGHBOR;
   735F                    2498 00123$:
                           2499 ;	../../Common/routing.c:362: free_table_semaphore();
                           2500 ;	genCall
   735F 12 6D 28           2501 	lcall	_free_table_semaphore
   7362                    2502 00126$:
                           2503 ;	../../Common/routing.c:364: return sqn_check;
                           2504 ;	genRet
   7362 E5 10              2505 	mov	a,_bp
   7364 24 05              2506 	add	a,#0x05
   7366 F8                 2507 	mov	r0,a
   7367 86 82              2508 	mov	dpl,@r0
                           2509 ;	Peephole 300	removed redundant label 00139$
   7369 85 10 81           2510 	mov	sp,_bp
   736C D0 10              2511 	pop	_bp
   736E 22                 2512 	ret
                           2513 ;------------------------------------------------------------
                           2514 ;Allocation info for local variables in function 'update_tables_ttl'
                           2515 ;------------------------------------------------------------
                           2516 ;address                   Allocated to stack - offset -5
                           2517 ;type                      Allocated to registers r2 
                           2518 ;i                         Allocated to stack - offset 1
                           2519 ;length                    Allocated to stack - offset 2
                           2520 ;final_length              Allocated to registers 
                           2521 ;------------------------------------------------------------
                           2522 ;	../../Common/routing.c:373: void update_tables_ttl(addrtype_t type, address_t address)
                           2523 ;	-----------------------------------------
                           2524 ;	 function update_tables_ttl
                           2525 ;	-----------------------------------------
   736F                    2526 _update_tables_ttl:
   736F C0 10              2527 	push	_bp
   7371 85 81 10           2528 	mov	_bp,sp
   7374 05 81              2529 	inc	sp
   7376 05 81              2530 	inc	sp
                           2531 ;	genReceive
   7378 AA 82              2532 	mov	r2,dpl
                           2533 ;	../../Common/routing.c:375: uint8_t i, length=0, final_length=0;
                           2534 ;	genAssign
   737A A8 10              2535 	mov	r0,_bp
   737C 08                 2536 	inc	r0
   737D 08                 2537 	inc	r0
   737E 76 00              2538 	mov	@r0,#0x00
                           2539 ;	../../Common/routing.c:376: if( xSemaphoreTake( table_lock, ( portTickType ) 10 ) == pdTRUE )
                           2540 ;	genAssign
   7380 90 F0 E7           2541 	mov	dptr,#_table_lock
   7383 E0                 2542 	movx	a,@dptr
   7384 FC                 2543 	mov	r4,a
   7385 A3                 2544 	inc	dptr
   7386 E0                 2545 	movx	a,@dptr
   7387 FD                 2546 	mov	r5,a
   7388 A3                 2547 	inc	dptr
   7389 E0                 2548 	movx	a,@dptr
   738A FE                 2549 	mov	r6,a
                           2550 ;	genIpush
   738B C0 02              2551 	push	ar2
   738D 74 0A              2552 	mov	a,#0x0A
   738F C0 E0              2553 	push	acc
                           2554 ;	Peephole 181	changed mov to clr
   7391 E4                 2555 	clr	a
   7392 C0 E0              2556 	push	acc
                           2557 ;	genIpush
                           2558 ;	Peephole 181	changed mov to clr
   7394 E4                 2559 	clr	a
   7395 C0 E0              2560 	push	acc
   7397 C0 E0              2561 	push	acc
   7399 C0 E0              2562 	push	acc
                           2563 ;	genCall
   739B 8C 82              2564 	mov	dpl,r4
   739D 8D 83              2565 	mov	dph,r5
   739F 8E F0              2566 	mov	b,r6
   73A1 12 23 5A           2567 	lcall	_xQueueReceive
   73A4 AC 82              2568 	mov	r4,dpl
   73A6 E5 81              2569 	mov	a,sp
   73A8 24 FB              2570 	add	a,#0xfb
   73AA F5 81              2571 	mov	sp,a
   73AC D0 02              2572 	pop	ar2
                           2573 ;	genCmpEq
                           2574 ;	gencjneshort
   73AE BC 01 02           2575 	cjne	r4,#0x01,00129$
   73B1 80 03              2576 	sjmp	00130$
   73B3                    2577 00129$:
   73B3 02 74 B9           2578 	ljmp	00118$
   73B6                    2579 00130$:
                           2580 ;	../../Common/routing.c:378: if(type==ADDR_802_15_4_PAN_LONG)
                           2581 ;	genCmpEq
                           2582 ;	gencjneshort
                           2583 ;	Peephole 112.b	changed ljmp to sjmp
                           2584 ;	Peephole 198.b	optimized misc jump sequence
   73B6 BA 04 06           2585 	cjne	r2,#0x04,00102$
                           2586 ;	Peephole 200.b	removed redundant sjmp
                           2587 ;	Peephole 300	removed redundant label 00131$
                           2588 ;	Peephole 300	removed redundant label 00132$
                           2589 ;	../../Common/routing.c:384: length=8;
                           2590 ;	genAssign
   73B9 A8 10              2591 	mov	r0,_bp
   73BB 08                 2592 	inc	r0
   73BC 08                 2593 	inc	r0
   73BD 76 08              2594 	mov	@r0,#0x08
                           2595 ;	../../Common/routing.c:385: final_length =10;					
   73BF                    2596 00102$:
                           2597 ;	../../Common/routing.c:388: if(type == ADDR_802_15_4_PAN_SHORT)
                           2598 ;	genCmpEq
                           2599 ;	gencjneshort
                           2600 ;	Peephole 112.b	changed ljmp to sjmp
                           2601 ;	Peephole 198.b	optimized misc jump sequence
   73BF BA 03 06           2602 	cjne	r2,#0x03,00104$
                           2603 ;	Peephole 200.b	removed redundant sjmp
                           2604 ;	Peephole 300	removed redundant label 00133$
                           2605 ;	Peephole 300	removed redundant label 00134$
                           2606 ;	../../Common/routing.c:390: length=4;
                           2607 ;	genAssign
   73C2 A8 10              2608 	mov	r0,_bp
   73C4 08                 2609 	inc	r0
   73C5 08                 2610 	inc	r0
   73C6 76 04              2611 	mov	@r0,#0x04
                           2612 ;	../../Common/routing.c:391: final_length=4;
   73C8                    2613 00104$:
                           2614 ;	../../Common/routing.c:394: if(neighbor_table.count > 0)
                           2615 ;	genPointerGet
                           2616 ;	genFarPointerGet
   73C8 90 EF BC           2617 	mov	dptr,#_neighbor_table
   73CB E0                 2618 	movx	a,@dptr
                           2619 ;	genIfxJump
   73CC 70 03              2620 	jnz	00135$
   73CE 02 74 B6           2621 	ljmp	00111$
   73D1                    2622 00135$:
                           2623 ;	../../Common/routing.c:396: for(i=0; i < neighbor_table.count ; i++)
                           2624 ;	genAssign
   73D1 A8 10              2625 	mov	r0,_bp
   73D3 08                 2626 	inc	r0
   73D4 76 00              2627 	mov	@r0,#0x00
   73D6                    2628 00114$:
                           2629 ;	genPointerGet
                           2630 ;	genFarPointerGet
   73D6 90 EF BC           2631 	mov	dptr,#_neighbor_table
   73D9 E0                 2632 	movx	a,@dptr
   73DA FD                 2633 	mov	r5,a
                           2634 ;	genCmpLt
   73DB A8 10              2635 	mov	r0,_bp
   73DD 08                 2636 	inc	r0
                           2637 ;	genCmp
   73DE C3                 2638 	clr	c
   73DF E6                 2639 	mov	a,@r0
   73E0 9D                 2640 	subb	a,r5
                           2641 ;	genIfxJump
   73E1 40 03              2642 	jc	00136$
   73E3 02 74 B6           2643 	ljmp	00111$
   73E6                    2644 00136$:
                           2645 ;	../../Common/routing.c:398: if(neighbor_table.neighbor_info[i] && (type == neighbor_table.neighbor_info[i]->type))
                           2646 ;	genMult
   73E6 A8 10              2647 	mov	r0,_bp
   73E8 08                 2648 	inc	r0
                           2649 ;	genMultOneByte
   73E9 E6                 2650 	mov	a,@r0
   73EA 75 F0 03           2651 	mov	b,#0x03
   73ED A4                 2652 	mul	ab
                           2653 ;	genPlus
   73EE FD                 2654 	mov	r5,a
                           2655 ;	Peephole 177.b	removed redundant mov
   73EF 24 BE              2656 	add	a,#(_neighbor_table + 0x0002)
   73F1 F5 82              2657 	mov	dpl,a
                           2658 ;	Peephole 181	changed mov to clr
   73F3 E4                 2659 	clr	a
   73F4 34 EF              2660 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   73F6 F5 83              2661 	mov	dph,a
                           2662 ;	genPointerGet
                           2663 ;	genFarPointerGet
   73F8 E0                 2664 	movx	a,@dptr
   73F9 FE                 2665 	mov	r6,a
   73FA A3                 2666 	inc	dptr
   73FB E0                 2667 	movx	a,@dptr
   73FC FF                 2668 	mov	r7,a
   73FD A3                 2669 	inc	dptr
   73FE E0                 2670 	movx	a,@dptr
   73FF FB                 2671 	mov	r3,a
                           2672 ;	genIfx
   7400 EE                 2673 	mov	a,r6
   7401 4F                 2674 	orl	a,r7
   7402 4B                 2675 	orl	a,r3
                           2676 ;	genIfxJump
   7403 70 03              2677 	jnz	00137$
   7405 02 74 AF           2678 	ljmp	00116$
   7408                    2679 00137$:
                           2680 ;	genPlus
                           2681 ;	Peephole 236.g	used r5 instead of ar5
   7408 ED                 2682 	mov	a,r5
   7409 24 BE              2683 	add	a,#(_neighbor_table + 0x0002)
   740B F5 82              2684 	mov	dpl,a
                           2685 ;	Peephole 181	changed mov to clr
   740D E4                 2686 	clr	a
   740E 34 EF              2687 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7410 F5 83              2688 	mov	dph,a
                           2689 ;	genPointerGet
                           2690 ;	genFarPointerGet
   7412 E0                 2691 	movx	a,@dptr
   7413 FB                 2692 	mov	r3,a
   7414 A3                 2693 	inc	dptr
   7415 E0                 2694 	movx	a,@dptr
   7416 FE                 2695 	mov	r6,a
   7417 A3                 2696 	inc	dptr
   7418 E0                 2697 	movx	a,@dptr
   7419 FF                 2698 	mov	r7,a
                           2699 ;	genPlus
                           2700 ;     genPlusIncr
   741A 74 0A              2701 	mov	a,#0x0A
                           2702 ;	Peephole 236.a	used r3 instead of ar3
   741C 2B                 2703 	add	a,r3
   741D FB                 2704 	mov	r3,a
                           2705 ;	Peephole 181	changed mov to clr
   741E E4                 2706 	clr	a
                           2707 ;	Peephole 236.b	used r6 instead of ar6
   741F 3E                 2708 	addc	a,r6
   7420 FE                 2709 	mov	r6,a
                           2710 ;	genPointerGet
                           2711 ;	genGenPointerGet
   7421 8B 82              2712 	mov	dpl,r3
   7423 8E 83              2713 	mov	dph,r6
   7425 8F F0              2714 	mov	b,r7
   7427 12 E4 9F           2715 	lcall	__gptrget
   742A FB                 2716 	mov	r3,a
                           2717 ;	genCmpEq
                           2718 ;	gencjneshort
   742B EA                 2719 	mov	a,r2
   742C B5 03 02           2720 	cjne	a,ar3,00138$
   742F 80 03              2721 	sjmp	00139$
   7431                    2722 00138$:
   7431 02 74 AF           2723 	ljmp	00116$
   7434                    2724 00139$:
                           2725 ;	../../Common/routing.c:400: if(memcmp(neighbor_table.neighbor_info[i]->address, address,length) == 0)
                           2726 ;	genIpush
   7434 C0 02              2727 	push	ar2
                           2728 ;	genCast
   7436 A8 10              2729 	mov	r0,_bp
   7438 08                 2730 	inc	r0
   7439 08                 2731 	inc	r0
   743A 86 03              2732 	mov	ar3,@r0
   743C 7E 00              2733 	mov	r6,#0x00
                           2734 ;	genPlus
                           2735 ;	Peephole 236.g	used r5 instead of ar5
   743E ED                 2736 	mov	a,r5
   743F 24 BE              2737 	add	a,#(_neighbor_table + 0x0002)
   7441 F5 82              2738 	mov	dpl,a
                           2739 ;	Peephole 181	changed mov to clr
   7443 E4                 2740 	clr	a
   7444 34 EF              2741 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7446 F5 83              2742 	mov	dph,a
                           2743 ;	genPointerGet
                           2744 ;	genFarPointerGet
   7448 E0                 2745 	movx	a,@dptr
   7449 FF                 2746 	mov	r7,a
   744A A3                 2747 	inc	dptr
   744B E0                 2748 	movx	a,@dptr
   744C FA                 2749 	mov	r2,a
   744D A3                 2750 	inc	dptr
   744E E0                 2751 	movx	a,@dptr
   744F FC                 2752 	mov	r4,a
                           2753 ;	genIpush
   7450 C0 05              2754 	push	ar5
   7452 C0 03              2755 	push	ar3
   7454 C0 06              2756 	push	ar6
                           2757 ;	genIpush
   7456 E5 10              2758 	mov	a,_bp
   7458 24 FB              2759 	add	a,#0xfffffffb
   745A F8                 2760 	mov	r0,a
   745B E6                 2761 	mov	a,@r0
   745C C0 E0              2762 	push	acc
   745E 08                 2763 	inc	r0
   745F E6                 2764 	mov	a,@r0
   7460 C0 E0              2765 	push	acc
   7462 08                 2766 	inc	r0
   7463 E6                 2767 	mov	a,@r0
   7464 C0 E0              2768 	push	acc
                           2769 ;	genCall
   7466 8F 82              2770 	mov	dpl,r7
   7468 8A 83              2771 	mov	dph,r2
   746A 8C F0              2772 	mov	b,r4
   746C 12 E2 0A           2773 	lcall	_memcmp
   746F AA 82              2774 	mov	r2,dpl
   7471 AB 83              2775 	mov	r3,dph
   7473 E5 81              2776 	mov	a,sp
   7475 24 FB              2777 	add	a,#0xfb
   7477 F5 81              2778 	mov	sp,a
   7479 D0 05              2779 	pop	ar5
                           2780 ;	genIfx
   747B EA                 2781 	mov	a,r2
   747C 4B                 2782 	orl	a,r3
                           2783 ;	genIpop
   747D D0 02              2784 	pop	ar2
                           2785 ;	genIfxJump
                           2786 ;	Peephole 108.b	removed ljmp by inverse jump logic
   747F 70 2E              2787 	jnz	00116$
                           2788 ;	Peephole 300	removed redundant label 00140$
                           2789 ;	../../Common/routing.c:408: neighbor_table.neighbor_info[i]->ttl=TTL;
                           2790 ;	genPlus
                           2791 ;	Peephole 236.g	used r5 instead of ar5
   7481 ED                 2792 	mov	a,r5
   7482 24 BE              2793 	add	a,#(_neighbor_table + 0x0002)
   7484 F5 82              2794 	mov	dpl,a
                           2795 ;	Peephole 181	changed mov to clr
   7486 E4                 2796 	clr	a
   7487 34 EF              2797 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7489 F5 83              2798 	mov	dph,a
                           2799 ;	genPointerGet
                           2800 ;	genFarPointerGet
   748B E0                 2801 	movx	a,@dptr
   748C FB                 2802 	mov	r3,a
   748D A3                 2803 	inc	dptr
   748E E0                 2804 	movx	a,@dptr
   748F FC                 2805 	mov	r4,a
   7490 A3                 2806 	inc	dptr
   7491 E0                 2807 	movx	a,@dptr
   7492 FD                 2808 	mov	r5,a
                           2809 ;	genPlus
                           2810 ;     genPlusIncr
   7493 74 0D              2811 	mov	a,#0x0D
                           2812 ;	Peephole 236.a	used r3 instead of ar3
   7495 2B                 2813 	add	a,r3
   7496 FB                 2814 	mov	r3,a
                           2815 ;	Peephole 181	changed mov to clr
   7497 E4                 2816 	clr	a
                           2817 ;	Peephole 236.b	used r4 instead of ar4
   7498 3C                 2818 	addc	a,r4
   7499 FC                 2819 	mov	r4,a
                           2820 ;	genPointerSet
                           2821 ;	genGenPointerSet
   749A 8B 82              2822 	mov	dpl,r3
   749C 8C 83              2823 	mov	dph,r4
   749E 8D F0              2824 	mov	b,r5
   74A0 74 0F              2825 	mov	a,#0x0F
   74A2 12 DF B7           2826 	lcall	__gptrput
                           2827 ;	../../Common/routing.c:410: i=(neighbor_table.count);
                           2828 ;	genPointerGet
                           2829 ;	genFarPointerGet
   74A5 90 EF BC           2830 	mov	dptr,#_neighbor_table
   74A8 E0                 2831 	movx	a,@dptr
   74A9 FB                 2832 	mov	r3,a
                           2833 ;	genAssign
   74AA A8 10              2834 	mov	r0,_bp
   74AC 08                 2835 	inc	r0
   74AD A6 03              2836 	mov	@r0,ar3
   74AF                    2837 00116$:
                           2838 ;	../../Common/routing.c:396: for(i=0; i < neighbor_table.count ; i++)
                           2839 ;	genPlus
   74AF A8 10              2840 	mov	r0,_bp
   74B1 08                 2841 	inc	r0
                           2842 ;     genPlusIncr
   74B2 06                 2843 	inc	@r0
   74B3 02 73 D6           2844 	ljmp	00114$
   74B6                    2845 00111$:
                           2846 ;	../../Common/routing.c:431: free_table_semaphore();
                           2847 ;	genCall
   74B6 12 6D 28           2848 	lcall	_free_table_semaphore
   74B9                    2849 00118$:
   74B9 85 10 81           2850 	mov	sp,_bp
   74BC D0 10              2851 	pop	_bp
   74BE 22                 2852 	ret
                           2853 ;------------------------------------------------------------
                           2854 ;Allocation info for local variables in function 'check_neighbour_table'
                           2855 ;------------------------------------------------------------
                           2856 ;address                   Allocated to stack - offset -5
                           2857 ;type                      Allocated to stack - offset 1
                           2858 ;i                         Allocated to registers r3 
                           2859 ;j                         Allocated to stack - offset 2
                           2860 ;broadcast                 Allocated to registers r3 
                           2861 ;length                    Allocated to stack - offset 3
                           2862 ;temp                      Allocated to registers r6 
                           2863 ;delivery_mode             Allocated to stack - offset 4
                           2864 ;sloc0                     Allocated to stack - offset 5
                           2865 ;sloc1                     Allocated to stack - offset 10
                           2866 ;------------------------------------------------------------
                           2867 ;	../../Common/routing.c:450: dest_delivery_t check_neighbour_table(addrtype_t type, address_t address)
                           2868 ;	-----------------------------------------
                           2869 ;	 function check_neighbour_table
                           2870 ;	-----------------------------------------
   74BF                    2871 _check_neighbour_table:
   74BF C0 10              2872 	push	_bp
   74C1 85 81 10           2873 	mov	_bp,sp
                           2874 ;     genReceive
   74C4 C0 82              2875 	push	dpl
   74C6 E5 81              2876 	mov	a,sp
   74C8 24 06              2877 	add	a,#0x06
   74CA F5 81              2878 	mov	sp,a
                           2879 ;	../../Common/routing.c:452: uint8_t i,j, broadcast=1, length;
                           2880 ;	genAssign
   74CC 7B 01              2881 	mov	r3,#0x01
                           2882 ;	../../Common/routing.c:454: dest_delivery_t delivery_mode = NOT_NEIGHBOR;
                           2883 ;	genAssign
   74CE E5 10              2884 	mov	a,_bp
   74D0 24 04              2885 	add	a,#0x04
   74D2 F8                 2886 	mov	r0,a
   74D3 76 02              2887 	mov	@r0,#0x02
                           2888 ;	../../Common/routing.c:455: if( xSemaphoreTake( table_lock, ( portTickType ) 10 ) == pdTRUE )
                           2889 ;	genAssign
   74D5 90 F0 E7           2890 	mov	dptr,#_table_lock
   74D8 E0                 2891 	movx	a,@dptr
   74D9 FD                 2892 	mov	r5,a
   74DA A3                 2893 	inc	dptr
   74DB E0                 2894 	movx	a,@dptr
   74DC FE                 2895 	mov	r6,a
   74DD A3                 2896 	inc	dptr
   74DE E0                 2897 	movx	a,@dptr
   74DF FF                 2898 	mov	r7,a
                           2899 ;	genIpush
   74E0 C0 03              2900 	push	ar3
   74E2 74 0A              2901 	mov	a,#0x0A
   74E4 C0 E0              2902 	push	acc
                           2903 ;	Peephole 181	changed mov to clr
   74E6 E4                 2904 	clr	a
   74E7 C0 E0              2905 	push	acc
                           2906 ;	genIpush
                           2907 ;	Peephole 181	changed mov to clr
   74E9 E4                 2908 	clr	a
   74EA C0 E0              2909 	push	acc
   74EC C0 E0              2910 	push	acc
   74EE C0 E0              2911 	push	acc
                           2912 ;	genCall
   74F0 8D 82              2913 	mov	dpl,r5
   74F2 8E 83              2914 	mov	dph,r6
   74F4 8F F0              2915 	mov	b,r7
   74F6 12 23 5A           2916 	lcall	_xQueueReceive
   74F9 AD 82              2917 	mov	r5,dpl
   74FB E5 81              2918 	mov	a,sp
   74FD 24 FB              2919 	add	a,#0xfb
   74FF F5 81              2920 	mov	sp,a
   7501 D0 03              2921 	pop	ar3
                           2922 ;	genCmpEq
                           2923 ;	gencjneshort
   7503 BD 01 02           2924 	cjne	r5,#0x01,00144$
   7506 80 03              2925 	sjmp	00145$
   7508                    2926 00144$:
   7508 02 76 BC           2927 	ljmp	00119$
   750B                    2928 00145$:
                           2929 ;	../../Common/routing.c:457: switch (type)
                           2930 ;	genCmpEq
   750B A8 10              2931 	mov	r0,_bp
   750D 08                 2932 	inc	r0
                           2933 ;	gencjneshort
   750E B6 03 02           2934 	cjne	@r0,#0x03,00146$
                           2935 ;	Peephole 112.b	changed ljmp to sjmp
   7511 80 08              2936 	sjmp	00101$
   7513                    2937 00146$:
                           2938 ;	genCmpEq
   7513 A8 10              2939 	mov	r0,_bp
   7515 08                 2940 	inc	r0
                           2941 ;	gencjneshort
                           2942 ;	Peephole 112.b	changed ljmp to sjmp
                           2943 ;	../../Common/routing.c:459: case ADDR_802_15_4_PAN_SHORT:		
                           2944 ;	Peephole 112.b	changed ljmp to sjmp
                           2945 ;	Peephole 198.b	optimized misc jump sequence
   7516 B6 04 1B           2946 	cjne	@r0,#0x04,00103$
   7519 80 0B              2947 	sjmp	00102$
                           2948 ;	Peephole 300	removed redundant label 00147$
   751B                    2949 00101$:
                           2950 ;	../../Common/routing.c:461: length=2;
                           2951 ;	genAssign
   751B A8 10              2952 	mov	r0,_bp
   751D 08                 2953 	inc	r0
   751E 08                 2954 	inc	r0
   751F 08                 2955 	inc	r0
   7520 76 02              2956 	mov	@r0,#0x02
                           2957 ;	../../Common/routing.c:462: temp = ADDR_SHORT;
                           2958 ;	genAssign
   7522 7E 05              2959 	mov	r6,#0x05
                           2960 ;	../../Common/routing.c:463: break;
                           2961 ;	../../Common/routing.c:464: case ADDR_802_15_4_PAN_LONG:
                           2962 ;	Peephole 112.b	changed ljmp to sjmp
   7524 80 14              2963 	sjmp	00104$
   7526                    2964 00102$:
                           2965 ;	../../Common/routing.c:465: length=8;
                           2966 ;	genAssign
   7526 A8 10              2967 	mov	r0,_bp
   7528 08                 2968 	inc	r0
   7529 08                 2969 	inc	r0
   752A 08                 2970 	inc	r0
   752B 76 08              2971 	mov	@r0,#0x08
                           2972 ;	../../Common/routing.c:466: temp = type;
                           2973 ;	genAssign
   752D A8 10              2974 	mov	r0,_bp
   752F 08                 2975 	inc	r0
   7530 86 06              2976 	mov	ar6,@r0
                           2977 ;	../../Common/routing.c:467: break;
                           2978 ;	../../Common/routing.c:468: default:
                           2979 ;	Peephole 112.b	changed ljmp to sjmp
   7532 80 06              2980 	sjmp	00104$
   7534                    2981 00103$:
                           2982 ;	../../Common/routing.c:472: return NO_SUPPORT;
                           2983 ;	genRet
   7534 75 82 04           2984 	mov	dpl,#0x04
   7537 02 76 C3           2985 	ljmp	00128$
                           2986 ;	../../Common/routing.c:474: }
   753A                    2987 00104$:
                           2988 ;	../../Common/routing.c:476: if(stack_check_broadcast(address, temp) != pdTRUE)
                           2989 ;	genIpush
   753A C0 03              2990 	push	ar3
   753C C0 06              2991 	push	ar6
                           2992 ;	genCall
   753E E5 10              2993 	mov	a,_bp
   7540 24 FB              2994 	add	a,#0xfffffffb
   7542 F8                 2995 	mov	r0,a
   7543 86 82              2996 	mov	dpl,@r0
   7545 08                 2997 	inc	r0
   7546 86 83              2998 	mov	dph,@r0
   7548 08                 2999 	inc	r0
   7549 86 F0              3000 	mov	b,@r0
   754B 12 6B 44           3001 	lcall	_stack_check_broadcast
   754E AE 82              3002 	mov	r6,dpl
   7550 15 81              3003 	dec	sp
   7552 D0 03              3004 	pop	ar3
                           3005 ;	genCmpEq
                           3006 ;	gencjneshort
   7554 BE 01 02           3007 	cjne	r6,#0x01,00148$
                           3008 ;	Peephole 112.b	changed ljmp to sjmp
   7557 80 02              3009 	sjmp	00106$
   7559                    3010 00148$:
                           3011 ;	../../Common/routing.c:478: broadcast = 0;
                           3012 ;	genAssign
   7559 7B 00              3013 	mov	r3,#0x00
   755B                    3014 00106$:
                           3015 ;	../../Common/routing.c:481: if(broadcast == 0)
                           3016 ;	genIfx
   755B EB                 3017 	mov	a,r3
                           3018 ;	genIfxJump
   755C 60 03              3019 	jz	00149$
   755E 02 76 B2           3020 	ljmp	00116$
   7561                    3021 00149$:
                           3022 ;	../../Common/routing.c:483: if(neighbor_table.count > 0)
                           3023 ;	genPointerGet
                           3024 ;	genFarPointerGet
   7561 90 EF BC           3025 	mov	dptr,#_neighbor_table
   7564 E0                 3026 	movx	a,@dptr
                           3027 ;	genIfxJump
   7565 70 03              3028 	jnz	00150$
   7567 02 76 A9           3029 	ljmp	00113$
   756A                    3030 00150$:
                           3031 ;	../../Common/routing.c:485: for(i=0; i < neighbor_table.count ; i++)
                           3032 ;	genAssign
   756A 7B 00              3033 	mov	r3,#0x00
   756C                    3034 00124$:
                           3035 ;	genPointerGet
                           3036 ;	genFarPointerGet
   756C 90 EF BC           3037 	mov	dptr,#_neighbor_table
   756F E0                 3038 	movx	a,@dptr
   7570 FE                 3039 	mov	r6,a
                           3040 ;	genCmpLt
                           3041 ;	genCmp
   7571 C3                 3042 	clr	c
   7572 EB                 3043 	mov	a,r3
   7573 9E                 3044 	subb	a,r6
                           3045 ;	genIfxJump
   7574 40 03              3046 	jc	00151$
   7576 02 76 B9           3047 	ljmp	00117$
   7579                    3048 00151$:
                           3049 ;	../../Common/routing.c:487: if(neighbor_table.neighbor_info[i] && (neighbor_table.neighbor_info[i]->type == type))
                           3050 ;	genMult
                           3051 ;	genMultOneByte
   7579 EB                 3052 	mov	a,r3
   757A 75 F0 03           3053 	mov	b,#0x03
   757D A4                 3054 	mul	ab
                           3055 ;	genPlus
   757E FE                 3056 	mov	r6,a
                           3057 ;	Peephole 177.b	removed redundant mov
   757F 24 BE              3058 	add	a,#(_neighbor_table + 0x0002)
   7581 F5 82              3059 	mov	dpl,a
                           3060 ;	Peephole 181	changed mov to clr
   7583 E4                 3061 	clr	a
   7584 34 EF              3062 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7586 F5 83              3063 	mov	dph,a
                           3064 ;	genPointerGet
                           3065 ;	genFarPointerGet
   7588 E0                 3066 	movx	a,@dptr
   7589 FF                 3067 	mov	r7,a
   758A A3                 3068 	inc	dptr
   758B E0                 3069 	movx	a,@dptr
   758C FC                 3070 	mov	r4,a
   758D A3                 3071 	inc	dptr
   758E E0                 3072 	movx	a,@dptr
   758F FA                 3073 	mov	r2,a
                           3074 ;	genIfx
   7590 EF                 3075 	mov	a,r7
   7591 4C                 3076 	orl	a,r4
   7592 4A                 3077 	orl	a,r2
                           3078 ;	genIfxJump
   7593 70 03              3079 	jnz	00152$
   7595 02 76 A5           3080 	ljmp	00126$
   7598                    3081 00152$:
                           3082 ;	genPlus
                           3083 ;	Peephole 236.g	used r6 instead of ar6
   7598 EE                 3084 	mov	a,r6
   7599 24 BE              3085 	add	a,#(_neighbor_table + 0x0002)
   759B F5 82              3086 	mov	dpl,a
                           3087 ;	Peephole 181	changed mov to clr
   759D E4                 3088 	clr	a
   759E 34 EF              3089 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   75A0 F5 83              3090 	mov	dph,a
                           3091 ;	genPointerGet
                           3092 ;	genFarPointerGet
   75A2 E0                 3093 	movx	a,@dptr
   75A3 FA                 3094 	mov	r2,a
   75A4 A3                 3095 	inc	dptr
   75A5 E0                 3096 	movx	a,@dptr
   75A6 FC                 3097 	mov	r4,a
   75A7 A3                 3098 	inc	dptr
   75A8 E0                 3099 	movx	a,@dptr
   75A9 FF                 3100 	mov	r7,a
                           3101 ;	genPlus
                           3102 ;     genPlusIncr
   75AA 74 0A              3103 	mov	a,#0x0A
                           3104 ;	Peephole 236.a	used r2 instead of ar2
   75AC 2A                 3105 	add	a,r2
   75AD FA                 3106 	mov	r2,a
                           3107 ;	Peephole 181	changed mov to clr
   75AE E4                 3108 	clr	a
                           3109 ;	Peephole 236.b	used r4 instead of ar4
   75AF 3C                 3110 	addc	a,r4
   75B0 FC                 3111 	mov	r4,a
                           3112 ;	genPointerGet
                           3113 ;	genGenPointerGet
   75B1 8A 82              3114 	mov	dpl,r2
   75B3 8C 83              3115 	mov	dph,r4
   75B5 8F F0              3116 	mov	b,r7
   75B7 12 E4 9F           3117 	lcall	__gptrget
   75BA FA                 3118 	mov	r2,a
                           3119 ;	genCmpEq
   75BB A8 10              3120 	mov	r0,_bp
   75BD 08                 3121 	inc	r0
                           3122 ;	gencjneshort
   75BE E6                 3123 	mov	a,@r0
   75BF B5 02 02           3124 	cjne	a,ar2,00153$
   75C2 80 03              3125 	sjmp	00154$
   75C4                    3126 00153$:
   75C4 02 76 A5           3127 	ljmp	00126$
   75C7                    3128 00154$:
                           3129 ;	../../Common/routing.c:489: if(memcmp(neighbor_table.neighbor_info[i]->address, address,length) == 0)
                           3130 ;	genIpush
   75C7 C0 03              3131 	push	ar3
                           3132 ;	genCast
   75C9 A8 10              3133 	mov	r0,_bp
   75CB 08                 3134 	inc	r0
   75CC 08                 3135 	inc	r0
   75CD 08                 3136 	inc	r0
   75CE 86 02              3137 	mov	ar2,@r0
   75D0 7C 00              3138 	mov	r4,#0x00
                           3139 ;	genPlus
                           3140 ;	Peephole 236.g	used r6 instead of ar6
   75D2 EE                 3141 	mov	a,r6
   75D3 24 BE              3142 	add	a,#(_neighbor_table + 0x0002)
   75D5 F5 82              3143 	mov	dpl,a
                           3144 ;	Peephole 181	changed mov to clr
   75D7 E4                 3145 	clr	a
   75D8 34 EF              3146 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   75DA F5 83              3147 	mov	dph,a
                           3148 ;	genPointerGet
                           3149 ;	genFarPointerGet
   75DC E0                 3150 	movx	a,@dptr
   75DD FF                 3151 	mov	r7,a
   75DE A3                 3152 	inc	dptr
   75DF E0                 3153 	movx	a,@dptr
   75E0 FB                 3154 	mov	r3,a
   75E1 A3                 3155 	inc	dptr
   75E2 E0                 3156 	movx	a,@dptr
   75E3 FD                 3157 	mov	r5,a
                           3158 ;	genIpush
   75E4 C0 06              3159 	push	ar6
   75E6 C0 02              3160 	push	ar2
   75E8 C0 04              3161 	push	ar4
                           3162 ;	genIpush
   75EA E5 10              3163 	mov	a,_bp
   75EC 24 FB              3164 	add	a,#0xfffffffb
   75EE F8                 3165 	mov	r0,a
   75EF E6                 3166 	mov	a,@r0
   75F0 C0 E0              3167 	push	acc
   75F2 08                 3168 	inc	r0
   75F3 E6                 3169 	mov	a,@r0
   75F4 C0 E0              3170 	push	acc
   75F6 08                 3171 	inc	r0
   75F7 E6                 3172 	mov	a,@r0
   75F8 C0 E0              3173 	push	acc
                           3174 ;	genCall
   75FA 8F 82              3175 	mov	dpl,r7
   75FC 8B 83              3176 	mov	dph,r3
   75FE 8D F0              3177 	mov	b,r5
   7600 12 E2 0A           3178 	lcall	_memcmp
   7603 AA 82              3179 	mov	r2,dpl
   7605 AB 83              3180 	mov	r3,dph
   7607 E5 81              3181 	mov	a,sp
   7609 24 FB              3182 	add	a,#0xfb
   760B F5 81              3183 	mov	sp,a
   760D D0 06              3184 	pop	ar6
                           3185 ;	genIfx
   760F EA                 3186 	mov	a,r2
   7610 4B                 3187 	orl	a,r3
                           3188 ;	genIpop
   7611 D0 03              3189 	pop	ar3
                           3190 ;	genIfxJump
   7613 60 03              3191 	jz	00155$
   7615 02 76 A5           3192 	ljmp	00126$
   7618                    3193 00155$:
                           3194 ;	../../Common/routing.c:491: delivery_mode = NEIGHBOR;
                           3195 ;	genAssign
   7618 E5 10              3196 	mov	a,_bp
   761A 24 04              3197 	add	a,#0x04
   761C F8                 3198 	mov	r0,a
   761D 76 01              3199 	mov	@r0,#0x01
                           3200 ;	../../Common/routing.c:492: for(j=0; j<2; j++)
                           3201 ;	genPlus
   761F E5 10              3202 	mov	a,_bp
   7621 24 05              3203 	add	a,#0x05
   7623 F8                 3204 	mov	r0,a
                           3205 ;	Peephole 236.g	used r6 instead of ar6
   7624 EE                 3206 	mov	a,r6
   7625 24 BE              3207 	add	a,#(_neighbor_table + 0x0002)
   7627 F6                 3208 	mov	@r0,a
                           3209 ;	Peephole 181	changed mov to clr
   7628 E4                 3210 	clr	a
   7629 34 EF              3211 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   762B 08                 3212 	inc	r0
   762C F6                 3213 	mov	@r0,a
                           3214 ;	genAssign
   762D A8 10              3215 	mov	r0,_bp
   762F 08                 3216 	inc	r0
   7630 08                 3217 	inc	r0
   7631 76 00              3218 	mov	@r0,#0x00
   7633                    3219 00120$:
                           3220 ;	genCmpLt
   7633 A8 10              3221 	mov	r0,_bp
   7635 08                 3222 	inc	r0
   7636 08                 3223 	inc	r0
                           3224 ;	genCmp
   7637 B6 02 00           3225 	cjne	@r0,#0x02,00156$
   763A                    3226 00156$:
                           3227 ;	genIfxJump
                           3228 ;	Peephole 108.a	removed ljmp by inverse jump logic
   763A 50 62              3229 	jnc	00123$
                           3230 ;	Peephole 300	removed redundant label 00157$
                           3231 ;	../../Common/routing.c:494: address[length+j] = neighbor_table.neighbor_info[i]->address[length+j];
                           3232 ;	genCast
   763C A8 10              3233 	mov	r0,_bp
   763E 08                 3234 	inc	r0
   763F 08                 3235 	inc	r0
   7640 08                 3236 	inc	r0
   7641 86 06              3237 	mov	ar6,@r0
   7643 7F 00              3238 	mov	r7,#0x00
                           3239 ;	genCast
   7645 A8 10              3240 	mov	r0,_bp
   7647 08                 3241 	inc	r0
   7648 08                 3242 	inc	r0
   7649 86 05              3243 	mov	ar5,@r0
   764B 7A 00              3244 	mov	r2,#0x00
                           3245 ;	genPlus
                           3246 ;	Peephole 236.g	used r5 instead of ar5
   764D ED                 3247 	mov	a,r5
                           3248 ;	Peephole 236.a	used r6 instead of ar6
   764E 2E                 3249 	add	a,r6
   764F FE                 3250 	mov	r6,a
                           3251 ;	Peephole 236.g	used r2 instead of ar2
   7650 EA                 3252 	mov	a,r2
                           3253 ;	Peephole 236.b	used r7 instead of ar7
   7651 3F                 3254 	addc	a,r7
   7652 FF                 3255 	mov	r7,a
                           3256 ;	genPlus
   7653 E5 10              3257 	mov	a,_bp
   7655 24 FB              3258 	add	a,#0xfffffffb
   7657 F8                 3259 	mov	r0,a
                           3260 ;	Peephole 236.g	used r6 instead of ar6
   7658 EE                 3261 	mov	a,r6
   7659 26                 3262 	add	a,@r0
   765A FE                 3263 	mov	r6,a
                           3264 ;	Peephole 236.g	used r7 instead of ar7
   765B EF                 3265 	mov	a,r7
   765C 08                 3266 	inc	r0
   765D 36                 3267 	addc	a,@r0
   765E FB                 3268 	mov	r3,a
   765F 08                 3269 	inc	r0
   7660 86 07              3270 	mov	ar7,@r0
                           3271 ;	genPointerGet
                           3272 ;	genFarPointerGet
   7662 E5 10              3273 	mov	a,_bp
   7664 24 05              3274 	add	a,#0x05
   7666 F8                 3275 	mov	r0,a
   7667 86 82              3276 	mov	dpl,@r0
   7669 08                 3277 	inc	r0
   766A 86 83              3278 	mov	dph,@r0
   766C E0                 3279 	movx	a,@dptr
   766D FC                 3280 	mov	r4,a
   766E A3                 3281 	inc	dptr
   766F E0                 3282 	movx	a,@dptr
   7670 FD                 3283 	mov	r5,a
   7671 A3                 3284 	inc	dptr
   7672 E0                 3285 	movx	a,@dptr
   7673 FA                 3286 	mov	r2,a
                           3287 ;	genPlus
   7674 A8 10              3288 	mov	r0,_bp
   7676 08                 3289 	inc	r0
   7677 08                 3290 	inc	r0
   7678 08                 3291 	inc	r0
   7679 A9 10              3292 	mov	r1,_bp
   767B 09                 3293 	inc	r1
   767C 09                 3294 	inc	r1
   767D E7                 3295 	mov	a,@r1
   767E 26                 3296 	add	a,@r0
                           3297 ;	genPlus
                           3298 ;	Peephole 236.a	used r4 instead of ar4
   767F 2C                 3299 	add	a,r4
   7680 FC                 3300 	mov	r4,a
                           3301 ;	Peephole 236.g	used r5 instead of ar5
                           3302 ;	Peephole 240	use clr instead of addc a,#0
   7681 E4                 3303 	clr	a
   7682 3D                 3304 	addc	a,r5
   7683 FD                 3305 	mov	r5,a
                           3306 ;	genPointerGet
                           3307 ;	genGenPointerGet
   7684 8C 82              3308 	mov	dpl,r4
   7686 8D 83              3309 	mov	dph,r5
   7688 8A F0              3310 	mov	b,r2
   768A 12 E4 9F           3311 	lcall	__gptrget
                           3312 ;	genPointerSet
                           3313 ;	genGenPointerSet
   768D FC                 3314 	mov	r4,a
   768E 8E 82              3315 	mov	dpl,r6
   7690 8B 83              3316 	mov	dph,r3
   7692 8F F0              3317 	mov	b,r7
                           3318 ;	Peephole 191	removed redundant mov
   7694 12 DF B7           3319 	lcall	__gptrput
                           3320 ;	../../Common/routing.c:492: for(j=0; j<2; j++)
                           3321 ;	genPlus
   7697 A8 10              3322 	mov	r0,_bp
   7699 08                 3323 	inc	r0
   769A 08                 3324 	inc	r0
                           3325 ;     genPlusIncr
   769B 06                 3326 	inc	@r0
                           3327 ;	Peephole 112.b	changed ljmp to sjmp
   769C 80 95              3328 	sjmp	00120$
   769E                    3329 00123$:
                           3330 ;	../../Common/routing.c:496: i=neighbor_table.count;
                           3331 ;	genPointerGet
                           3332 ;	genFarPointerGet
   769E 90 EF BC           3333 	mov	dptr,#_neighbor_table
   76A1 E0                 3334 	movx	a,@dptr
   76A2 FA                 3335 	mov	r2,a
                           3336 ;	genAssign
   76A3 8A 03              3337 	mov	ar3,r2
   76A5                    3338 00126$:
                           3339 ;	../../Common/routing.c:485: for(i=0; i < neighbor_table.count ; i++)
                           3340 ;	genPlus
                           3341 ;     genPlusIncr
   76A5 0B                 3342 	inc	r3
   76A6 02 75 6C           3343 	ljmp	00124$
   76A9                    3344 00113$:
                           3345 ;	../../Common/routing.c:503: delivery_mode = NOT_NEIGHBOR;
                           3346 ;	genAssign
   76A9 E5 10              3347 	mov	a,_bp
   76AB 24 04              3348 	add	a,#0x04
   76AD F8                 3349 	mov	r0,a
   76AE 76 02              3350 	mov	@r0,#0x02
                           3351 ;	Peephole 112.b	changed ljmp to sjmp
   76B0 80 07              3352 	sjmp	00117$
   76B2                    3353 00116$:
                           3354 ;	../../Common/routing.c:508: delivery_mode = BROADCAST;
                           3355 ;	genAssign
   76B2 E5 10              3356 	mov	a,_bp
   76B4 24 04              3357 	add	a,#0x04
   76B6 F8                 3358 	mov	r0,a
   76B7 76 00              3359 	mov	@r0,#0x00
   76B9                    3360 00117$:
                           3361 ;	../../Common/routing.c:510: free_table_semaphore();
                           3362 ;	genCall
   76B9 12 6D 28           3363 	lcall	_free_table_semaphore
   76BC                    3364 00119$:
                           3365 ;	../../Common/routing.c:512: return delivery_mode;	
                           3366 ;	genRet
   76BC E5 10              3367 	mov	a,_bp
   76BE 24 04              3368 	add	a,#0x04
   76C0 F8                 3369 	mov	r0,a
   76C1 86 82              3370 	mov	dpl,@r0
   76C3                    3371 00128$:
   76C3 85 10 81           3372 	mov	sp,_bp
   76C6 D0 10              3373 	pop	_bp
   76C8 22                 3374 	ret
                           3375 ;------------------------------------------------------------
                           3376 ;Allocation info for local variables in function 'check_tables_status'
                           3377 ;------------------------------------------------------------
                           3378 ;unused_parameter          Allocated to registers 
                           3379 ;i                         Allocated to stack - offset 1
                           3380 ;temp                      Allocated to stack - offset 2
                           3381 ;minus_count               Allocated to stack - offset 3
                           3382 ;temp_index                Allocated to registers r4 
                           3383 ;t                         Allocated to stack - offset 4
                           3384 ;------------------------------------------------------------
                           3385 ;	../../Common/routing.c:972: void check_tables_status(void *unused_parameter)
                           3386 ;	-----------------------------------------
                           3387 ;	 function check_tables_status
                           3388 ;	-----------------------------------------
   76C9                    3389 _check_tables_status:
   76C9 C0 10              3390 	push	_bp
                           3391 ;	peephole 177.h	optimized mov sequence
   76CB E5 81              3392 	mov	a,sp
   76CD F5 10              3393 	mov	_bp,a
   76CF 24 04              3394 	add	a,#0x04
   76D1 F5 81              3395 	mov	sp,a
                           3396 ;	../../Common/routing.c:975: if( xSemaphoreTake( table_lock, ( portTickType ) 10 ) == pdTRUE )
                           3397 ;	genAssign
   76D3 90 F0 E7           3398 	mov	dptr,#_table_lock
   76D6 E0                 3399 	movx	a,@dptr
   76D7 FA                 3400 	mov	r2,a
   76D8 A3                 3401 	inc	dptr
   76D9 E0                 3402 	movx	a,@dptr
   76DA FB                 3403 	mov	r3,a
   76DB A3                 3404 	inc	dptr
   76DC E0                 3405 	movx	a,@dptr
   76DD FC                 3406 	mov	r4,a
                           3407 ;	genIpush
   76DE 74 0A              3408 	mov	a,#0x0A
   76E0 C0 E0              3409 	push	acc
                           3410 ;	Peephole 181	changed mov to clr
   76E2 E4                 3411 	clr	a
   76E3 C0 E0              3412 	push	acc
                           3413 ;	genIpush
                           3414 ;	Peephole 181	changed mov to clr
   76E5 E4                 3415 	clr	a
   76E6 C0 E0              3416 	push	acc
   76E8 C0 E0              3417 	push	acc
   76EA C0 E0              3418 	push	acc
                           3419 ;	genCall
   76EC 8A 82              3420 	mov	dpl,r2
   76EE 8B 83              3421 	mov	dph,r3
   76F0 8C F0              3422 	mov	b,r4
   76F2 12 23 5A           3423 	lcall	_xQueueReceive
   76F5 AA 82              3424 	mov	r2,dpl
   76F7 E5 81              3425 	mov	a,sp
   76F9 24 FB              3426 	add	a,#0xfb
   76FB F5 81              3427 	mov	sp,a
                           3428 ;	genCmpEq
                           3429 ;	gencjneshort
   76FD BA 01 02           3430 	cjne	r2,#0x01,00131$
   7700 80 03              3431 	sjmp	00132$
   7702                    3432 00131$:
   7702 02 78 7F           3433 	ljmp	00119$
   7705                    3434 00132$:
                           3435 ;	../../Common/routing.c:977: if(neighbor_table.count)
                           3436 ;	genPointerGet
                           3437 ;	genFarPointerGet
   7705 90 EF BC           3438 	mov	dptr,#_neighbor_table
   7708 E0                 3439 	movx	a,@dptr
                           3440 ;	genIfx
   7709 FA                 3441 	mov	r2,a
                           3442 ;	Peephole 105	removed redundant mov
                           3443 ;	genIfxJump
   770A 70 03              3444 	jnz	00133$
   770C 02 78 7C           3445 	ljmp	00112$
   770F                    3446 00133$:
                           3447 ;	../../Common/routing.c:979: temp=neighbor_table.count;
                           3448 ;	genAssign
                           3449 ;	genAssign
   770F A8 10              3450 	mov	r0,_bp
   7711 08                 3451 	inc	r0
   7712 08                 3452 	inc	r0
   7713 A6 02              3453 	mov	@r0,ar2
                           3454 ;	../../Common/routing.c:981: for(i=0; i < temp; i++)
                           3455 ;	genAssign
   7715 A8 10              3456 	mov	r0,_bp
   7717 08                 3457 	inc	r0
   7718 08                 3458 	inc	r0
   7719 08                 3459 	inc	r0
   771A 76 00              3460 	mov	@r0,#0x00
                           3461 ;	genAssign
   771C 7C 00              3462 	mov	r4,#0x00
                           3463 ;	genAssign
   771E A8 10              3464 	mov	r0,_bp
   7720 08                 3465 	inc	r0
   7721 76 00              3466 	mov	@r0,#0x00
   7723                    3467 00115$:
                           3468 ;	genCmpLt
   7723 A8 10              3469 	mov	r0,_bp
   7725 08                 3470 	inc	r0
   7726 A9 10              3471 	mov	r1,_bp
   7728 09                 3472 	inc	r1
   7729 09                 3473 	inc	r1
                           3474 ;	genCmp
   772A C3                 3475 	clr	c
   772B E6                 3476 	mov	a,@r0
   772C 97                 3477 	subb	a,@r1
                           3478 ;	genIfxJump
   772D 40 03              3479 	jc	00134$
   772F 02 78 62           3480 	ljmp	00118$
   7732                    3481 00134$:
                           3482 ;	../../Common/routing.c:983: if(neighbor_table.neighbor_info[temp_index]->ttl > 1)
                           3483 ;	genIpush
                           3484 ;	genMult
                           3485 ;	genMultOneByte
   7732 EC                 3486 	mov	a,r4
   7733 75 F0 03           3487 	mov	b,#0x03
   7736 A4                 3488 	mul	ab
                           3489 ;	genPlus
   7737 FE                 3490 	mov	r6,a
                           3491 ;	Peephole 177.b	removed redundant mov
   7738 24 BE              3492 	add	a,#(_neighbor_table + 0x0002)
   773A F5 82              3493 	mov	dpl,a
                           3494 ;	Peephole 181	changed mov to clr
   773C E4                 3495 	clr	a
   773D 34 EF              3496 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   773F F5 83              3497 	mov	dph,a
                           3498 ;	genPointerGet
                           3499 ;	genFarPointerGet
   7741 E0                 3500 	movx	a,@dptr
   7742 FF                 3501 	mov	r7,a
   7743 A3                 3502 	inc	dptr
   7744 E0                 3503 	movx	a,@dptr
   7745 FA                 3504 	mov	r2,a
   7746 A3                 3505 	inc	dptr
   7747 E0                 3506 	movx	a,@dptr
   7748 FB                 3507 	mov	r3,a
                           3508 ;	genPlus
                           3509 ;     genPlusIncr
   7749 74 0D              3510 	mov	a,#0x0D
                           3511 ;	Peephole 236.a	used r7 instead of ar7
   774B 2F                 3512 	add	a,r7
   774C FF                 3513 	mov	r7,a
                           3514 ;	Peephole 181	changed mov to clr
   774D E4                 3515 	clr	a
                           3516 ;	Peephole 236.b	used r2 instead of ar2
   774E 3A                 3517 	addc	a,r2
   774F FA                 3518 	mov	r2,a
                           3519 ;	genPointerGet
                           3520 ;	genGenPointerGet
   7750 8F 82              3521 	mov	dpl,r7
   7752 8A 83              3522 	mov	dph,r2
   7754 8B F0              3523 	mov	b,r3
   7756 12 E4 9F           3524 	lcall	__gptrget
                           3525 ;	genCmpGt
                           3526 ;	genCmp
                           3527 ;	genIpop
                           3528 ;	genIfx
                           3529 ;	genIfxJump
                           3530 ;	Peephole 108.c	removed ljmp by inverse jump logic
                           3531 ;	Peephole 128	jump optimization
                           3532 ;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
   7759 FF                 3533 	mov  r7,a
                           3534 ;	Peephole 177.a	removed redundant mov
   775A 24 FE              3535 	add	a,#0xff - 0x01
   775C 50 32              3536 	jnc	00107$
                           3537 ;	Peephole 300	removed redundant label 00135$
                           3538 ;	../../Common/routing.c:985: neighbor_table.neighbor_info[temp_index]->ttl--;
                           3539 ;	genIpush
                           3540 ;	genPlus
                           3541 ;	Peephole 236.g	used r6 instead of ar6
   775E EE                 3542 	mov	a,r6
   775F 24 BE              3543 	add	a,#(_neighbor_table + 0x0002)
   7761 F5 82              3544 	mov	dpl,a
                           3545 ;	Peephole 181	changed mov to clr
   7763 E4                 3546 	clr	a
   7764 34 EF              3547 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7766 F5 83              3548 	mov	dph,a
                           3549 ;	genPointerGet
                           3550 ;	genFarPointerGet
   7768 E0                 3551 	movx	a,@dptr
   7769 FB                 3552 	mov	r3,a
   776A A3                 3553 	inc	dptr
   776B E0                 3554 	movx	a,@dptr
   776C FF                 3555 	mov	r7,a
   776D A3                 3556 	inc	dptr
   776E E0                 3557 	movx	a,@dptr
   776F FA                 3558 	mov	r2,a
                           3559 ;	genPlus
                           3560 ;     genPlusIncr
   7770 74 0D              3561 	mov	a,#0x0D
                           3562 ;	Peephole 236.a	used r3 instead of ar3
   7772 2B                 3563 	add	a,r3
   7773 FB                 3564 	mov	r3,a
                           3565 ;	Peephole 181	changed mov to clr
   7774 E4                 3566 	clr	a
                           3567 ;	Peephole 236.b	used r7 instead of ar7
   7775 3F                 3568 	addc	a,r7
   7776 FF                 3569 	mov	r7,a
                           3570 ;	genPointerGet
                           3571 ;	genGenPointerGet
   7777 8B 82              3572 	mov	dpl,r3
   7779 8F 83              3573 	mov	dph,r7
   777B 8A F0              3574 	mov	b,r2
   777D 12 E4 9F           3575 	lcall	__gptrget
   7780 FD                 3576 	mov	r5,a
                           3577 ;	genMinus
                           3578 ;	genMinusDec
   7781 1D                 3579 	dec	r5
                           3580 ;	genPointerSet
                           3581 ;	genGenPointerSet
   7782 8B 82              3582 	mov	dpl,r3
   7784 8F 83              3583 	mov	dph,r7
   7786 8A F0              3584 	mov	b,r2
   7788 ED                 3585 	mov	a,r5
   7789 12 DF B7           3586 	lcall	__gptrput
                           3587 ;	../../Common/routing.c:986: temp_index++;
                           3588 ;	genPlus
                           3589 ;     genPlusIncr
   778C 0C                 3590 	inc	r4
                           3591 ;	genIpop
   778D 02 78 5B           3592 	ljmp	00117$
   7790                    3593 00107$:
                           3594 ;	../../Common/routing.c:990: if(neighbor_table.neighbor_info[temp_index]->child_dev)
                           3595 ;	genPlus
                           3596 ;	Peephole 236.g	used r6 instead of ar6
   7790 EE                 3597 	mov	a,r6
   7791 24 BE              3598 	add	a,#(_neighbor_table + 0x0002)
   7793 F5 82              3599 	mov	dpl,a
                           3600 ;	Peephole 181	changed mov to clr
   7795 E4                 3601 	clr	a
   7796 34 EF              3602 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7798 F5 83              3603 	mov	dph,a
                           3604 ;	genPointerGet
                           3605 ;	genFarPointerGet
   779A E0                 3606 	movx	a,@dptr
   779B FB                 3607 	mov	r3,a
   779C A3                 3608 	inc	dptr
   779D E0                 3609 	movx	a,@dptr
   779E FD                 3610 	mov	r5,a
   779F A3                 3611 	inc	dptr
   77A0 E0                 3612 	movx	a,@dptr
   77A1 FE                 3613 	mov	r6,a
                           3614 ;	genPlus
                           3615 ;     genPlusIncr
   77A2 74 0E              3616 	mov	a,#0x0E
                           3617 ;	Peephole 236.a	used r3 instead of ar3
   77A4 2B                 3618 	add	a,r3
   77A5 FB                 3619 	mov	r3,a
                           3620 ;	Peephole 181	changed mov to clr
   77A6 E4                 3621 	clr	a
                           3622 ;	Peephole 236.b	used r5 instead of ar5
   77A7 3D                 3623 	addc	a,r5
   77A8 FD                 3624 	mov	r5,a
                           3625 ;	genPointerGet
                           3626 ;	genGenPointerGet
   77A9 8B 82              3627 	mov	dpl,r3
   77AB 8D 83              3628 	mov	dph,r5
   77AD 8E F0              3629 	mov	b,r6
   77AF 12 E4 9F           3630 	lcall	__gptrget
                           3631 ;	genIfxJump
                           3632 ;	Peephole 108.c	removed ljmp by inverse jump logic
   77B2 60 0B              3633 	jz	00102$
                           3634 ;	Peephole 300	removed redundant label 00136$
                           3635 ;	../../Common/routing.c:992: neighbor_table.child_count--;
                           3636 ;	genPointerGet
                           3637 ;	genFarPointerGet
   77B4 90 EF BD           3638 	mov	dptr,#(_neighbor_table + 0x0001)
   77B7 E0                 3639 	movx	a,@dptr
   77B8 FB                 3640 	mov	r3,a
                           3641 ;	genMinus
                           3642 ;	genMinusDec
   77B9 1B                 3643 	dec	r3
                           3644 ;	genPointerSet
                           3645 ;     genFarPointerSet
   77BA 90 EF BD           3646 	mov	dptr,#(_neighbor_table + 0x0001)
   77BD EB                 3647 	mov	a,r3
   77BE F0                 3648 	movx	@dptr,a
   77BF                    3649 00102$:
                           3650 ;	../../Common/routing.c:994: neigh_buffer_free(neighbor_table.neighbor_info[temp_index]);
                           3651 ;	genMult
                           3652 ;	genMultOneByte
   77BF EC                 3653 	mov	a,r4
   77C0 75 F0 03           3654 	mov	b,#0x03
   77C3 A4                 3655 	mul	ab
                           3656 ;	genPlus
   77C4 FB                 3657 	mov	r3,a
                           3658 ;	Peephole 177.b	removed redundant mov
   77C5 24 BE              3659 	add	a,#(_neighbor_table + 0x0002)
   77C7 F5 82              3660 	mov	dpl,a
                           3661 ;	Peephole 181	changed mov to clr
   77C9 E4                 3662 	clr	a
   77CA 34 EF              3663 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   77CC F5 83              3664 	mov	dph,a
                           3665 ;	genPointerGet
                           3666 ;	genFarPointerGet
   77CE E0                 3667 	movx	a,@dptr
   77CF FD                 3668 	mov	r5,a
   77D0 A3                 3669 	inc	dptr
   77D1 E0                 3670 	movx	a,@dptr
   77D2 FE                 3671 	mov	r6,a
   77D3 A3                 3672 	inc	dptr
   77D4 E0                 3673 	movx	a,@dptr
   77D5 FF                 3674 	mov	r7,a
                           3675 ;	genCall
   77D6 8D 82              3676 	mov	dpl,r5
   77D8 8E 83              3677 	mov	dph,r6
   77DA 8F F0              3678 	mov	b,r7
   77DC C0 03              3679 	push	ar3
   77DE C0 04              3680 	push	ar4
   77E0 12 6E 68           3681 	lcall	_neigh_buffer_free
   77E3 D0 04              3682 	pop	ar4
   77E5 D0 03              3683 	pop	ar3
                           3684 ;	../../Common/routing.c:995: neighbor_table.neighbor_info[temp_index]=0;
                           3685 ;	genPlus
                           3686 ;	Peephole 236.g	used r3 instead of ar3
   77E7 EB                 3687 	mov	a,r3
   77E8 24 BE              3688 	add	a,#(_neighbor_table + 0x0002)
   77EA F5 82              3689 	mov	dpl,a
                           3690 ;	Peephole 181	changed mov to clr
   77EC E4                 3691 	clr	a
   77ED 34 EF              3692 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   77EF F5 83              3693 	mov	dph,a
                           3694 ;	genPointerSet
                           3695 ;     genFarPointerSet
                           3696 ;	Peephole 181	changed mov to clr
   77F1 E4                 3697 	clr	a
   77F2 F0                 3698 	movx	@dptr,a
                           3699 ;	../../Common/routing.c:996: minus_count++;
                           3700 ;	genPlus
   77F3 A8 10              3701 	mov	r0,_bp
   77F5 08                 3702 	inc	r0
   77F6 08                 3703 	inc	r0
   77F7 08                 3704 	inc	r0
                           3705 ;     genPlusIncr
   77F8 06                 3706 	inc	@r0
                           3707 ;	../../Common/routing.c:998: t++;
                           3708 ;	genPlus
   77F9 A8 10              3709 	mov	r0,_bp
   77FB 08                 3710 	inc	r0
   77FC E5 10              3711 	mov	a,_bp
   77FE 24 04              3712 	add	a,#0x04
   7800 F9                 3713 	mov	r1,a
                           3714 ;     genPlusIncr
   7801 74 01              3715 	mov	a,#0x01
   7803 26                 3716 	add	a,@r0
   7804 F7                 3717 	mov	@r1,a
                           3718 ;	../../Common/routing.c:999: if(neighbor_table.neighbor_info[t] && t < neighbor_table.count)
                           3719 ;	genMult
   7805 E5 10              3720 	mov	a,_bp
   7807 24 04              3721 	add	a,#0x04
   7809 F8                 3722 	mov	r0,a
                           3723 ;	genMultOneByte
   780A E6                 3724 	mov	a,@r0
   780B 75 F0 03           3725 	mov	b,#0x03
   780E A4                 3726 	mul	ab
                           3727 ;	genPlus
   780F FE                 3728 	mov	r6,a
                           3729 ;	Peephole 177.b	removed redundant mov
   7810 24 BE              3730 	add	a,#(_neighbor_table + 0x0002)
   7812 F5 82              3731 	mov	dpl,a
                           3732 ;	Peephole 181	changed mov to clr
   7814 E4                 3733 	clr	a
   7815 34 EF              3734 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7817 F5 83              3735 	mov	dph,a
                           3736 ;	genPointerGet
                           3737 ;	genFarPointerGet
   7819 E0                 3738 	movx	a,@dptr
   781A FF                 3739 	mov	r7,a
   781B A3                 3740 	inc	dptr
   781C E0                 3741 	movx	a,@dptr
   781D FA                 3742 	mov	r2,a
   781E A3                 3743 	inc	dptr
   781F E0                 3744 	movx	a,@dptr
   7820 FD                 3745 	mov	r5,a
                           3746 ;	genIfx
   7821 EF                 3747 	mov	a,r7
   7822 4A                 3748 	orl	a,r2
   7823 4D                 3749 	orl	a,r5
                           3750 ;	genIfxJump
                           3751 ;	Peephole 108.c	removed ljmp by inverse jump logic
   7824 60 35              3752 	jz	00117$
                           3753 ;	Peephole 300	removed redundant label 00137$
                           3754 ;	genPointerGet
                           3755 ;	genFarPointerGet
   7826 90 EF BC           3756 	mov	dptr,#_neighbor_table
   7829 E0                 3757 	movx	a,@dptr
   782A FA                 3758 	mov	r2,a
                           3759 ;	genCmpLt
   782B E5 10              3760 	mov	a,_bp
   782D 24 04              3761 	add	a,#0x04
   782F F8                 3762 	mov	r0,a
                           3763 ;	genCmp
   7830 C3                 3764 	clr	c
   7831 E6                 3765 	mov	a,@r0
   7832 9A                 3766 	subb	a,r2
                           3767 ;	genIfxJump
                           3768 ;	Peephole 108.a	removed ljmp by inverse jump logic
   7833 50 26              3769 	jnc	00117$
                           3770 ;	Peephole 300	removed redundant label 00138$
                           3771 ;	../../Common/routing.c:1002: neighbor_table.neighbor_info[temp_index] = (neighbor_info_t*)neighbor_table.neighbor_info[t];
                           3772 ;	genPlus
                           3773 ;	Peephole 236.g	used r3 instead of ar3
   7835 EB                 3774 	mov	a,r3
   7836 24 BE              3775 	add	a,#(_neighbor_table + 0x0002)
   7838 FB                 3776 	mov	r3,a
                           3777 ;	Peephole 181	changed mov to clr
   7839 E4                 3778 	clr	a
   783A 34 EF              3779 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   783C FA                 3780 	mov	r2,a
                           3781 ;	genPlus
                           3782 ;	Peephole 236.g	used r6 instead of ar6
   783D EE                 3783 	mov	a,r6
   783E 24 BE              3784 	add	a,#(_neighbor_table + 0x0002)
   7840 F5 82              3785 	mov	dpl,a
                           3786 ;	Peephole 181	changed mov to clr
   7842 E4                 3787 	clr	a
   7843 34 EF              3788 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7845 F5 83              3789 	mov	dph,a
                           3790 ;	genPointerGet
                           3791 ;	genFarPointerGet
   7847 E0                 3792 	movx	a,@dptr
   7848 FD                 3793 	mov	r5,a
   7849 A3                 3794 	inc	dptr
   784A E0                 3795 	movx	a,@dptr
   784B FE                 3796 	mov	r6,a
   784C A3                 3797 	inc	dptr
   784D E0                 3798 	movx	a,@dptr
   784E FF                 3799 	mov	r7,a
                           3800 ;	genPointerSet
                           3801 ;     genFarPointerSet
   784F 8B 82              3802 	mov	dpl,r3
   7851 8A 83              3803 	mov	dph,r2
   7853 ED                 3804 	mov	a,r5
   7854 F0                 3805 	movx	@dptr,a
   7855 A3                 3806 	inc	dptr
   7856 EE                 3807 	mov	a,r6
   7857 F0                 3808 	movx	@dptr,a
   7858 A3                 3809 	inc	dptr
   7859 EF                 3810 	mov	a,r7
   785A F0                 3811 	movx	@dptr,a
   785B                    3812 00117$:
                           3813 ;	../../Common/routing.c:981: for(i=0; i < temp; i++)
                           3814 ;	genPlus
   785B A8 10              3815 	mov	r0,_bp
   785D 08                 3816 	inc	r0
                           3817 ;     genPlusIncr
   785E 06                 3818 	inc	@r0
   785F 02 77 23           3819 	ljmp	00115$
   7862                    3820 00118$:
                           3821 ;	../../Common/routing.c:1006: if(minus_count)
                           3822 ;	genIfx
   7862 A8 10              3823 	mov	r0,_bp
   7864 08                 3824 	inc	r0
   7865 08                 3825 	inc	r0
   7866 08                 3826 	inc	r0
   7867 E6                 3827 	mov	a,@r0
                           3828 ;	genIfxJump
                           3829 ;	Peephole 108.c	removed ljmp by inverse jump logic
   7868 60 12              3830 	jz	00112$
                           3831 ;	Peephole 300	removed redundant label 00139$
                           3832 ;	../../Common/routing.c:1008: neighbor_table.count -= minus_count;
                           3833 ;	genPointerGet
                           3834 ;	genFarPointerGet
   786A 90 EF BC           3835 	mov	dptr,#_neighbor_table
   786D E0                 3836 	movx	a,@dptr
   786E FA                 3837 	mov	r2,a
                           3838 ;	genMinus
   786F A8 10              3839 	mov	r0,_bp
   7871 08                 3840 	inc	r0
   7872 08                 3841 	inc	r0
   7873 08                 3842 	inc	r0
   7874 EA                 3843 	mov	a,r2
   7875 C3                 3844 	clr	c
   7876 96                 3845 	subb	a,@r0
                           3846 ;	genPointerSet
                           3847 ;     genFarPointerSet
   7877 FA                 3848 	mov	r2,a
   7878 90 EF BC           3849 	mov	dptr,#_neighbor_table
                           3850 ;	Peephole 100	removed redundant mov
   787B F0                 3851 	movx	@dptr,a
   787C                    3852 00112$:
                           3853 ;	../../Common/routing.c:1044: free_table_semaphore();
                           3854 ;	genCall
   787C 12 6D 28           3855 	lcall	_free_table_semaphore
   787F                    3856 00119$:
   787F 85 10 81           3857 	mov	sp,_bp
   7882 D0 10              3858 	pop	_bp
   7884 22                 3859 	ret
                           3860 ;------------------------------------------------------------
                           3861 ;Allocation info for local variables in function 'print_table_information'
                           3862 ;------------------------------------------------------------
                           3863 ;i                         Allocated to registers r2 
                           3864 ;j                         Allocated to registers r4 
                           3865 ;------------------------------------------------------------
                           3866 ;	../../Common/routing.c:1052: void print_table_information(void)
                           3867 ;	-----------------------------------------
                           3868 ;	 function print_table_information
                           3869 ;	-----------------------------------------
   7885                    3870 _print_table_information:
                           3871 ;	../../Common/routing.c:1054: if( xSemaphoreTake( table_lock, ( portTickType ) 10 ) == pdTRUE )
                           3872 ;	genAssign
   7885 90 F0 E7           3873 	mov	dptr,#_table_lock
   7888 E0                 3874 	movx	a,@dptr
   7889 FA                 3875 	mov	r2,a
   788A A3                 3876 	inc	dptr
   788B E0                 3877 	movx	a,@dptr
   788C FB                 3878 	mov	r3,a
   788D A3                 3879 	inc	dptr
   788E E0                 3880 	movx	a,@dptr
   788F FC                 3881 	mov	r4,a
                           3882 ;	genIpush
   7890 74 0A              3883 	mov	a,#0x0A
   7892 C0 E0              3884 	push	acc
                           3885 ;	Peephole 181	changed mov to clr
   7894 E4                 3886 	clr	a
   7895 C0 E0              3887 	push	acc
                           3888 ;	genIpush
                           3889 ;	Peephole 181	changed mov to clr
   7897 E4                 3890 	clr	a
   7898 C0 E0              3891 	push	acc
   789A C0 E0              3892 	push	acc
   789C C0 E0              3893 	push	acc
                           3894 ;	genCall
   789E 8A 82              3895 	mov	dpl,r2
   78A0 8B 83              3896 	mov	dph,r3
   78A2 8C F0              3897 	mov	b,r4
   78A4 12 23 5A           3898 	lcall	_xQueueReceive
   78A7 AA 82              3899 	mov	r2,dpl
   78A9 E5 81              3900 	mov	a,sp
   78AB 24 FB              3901 	add	a,#0xfb
   78AD F5 81              3902 	mov	sp,a
                           3903 ;	genCmpEq
                           3904 ;	gencjneshort
   78AF BA 01 02           3905 	cjne	r2,#0x01,00163$
   78B2 80 01              3906 	sjmp	00164$
   78B4                    3907 00163$:
                           3908 ;	Peephole 251.a	replaced ljmp to ret with ret
   78B4 22                 3909 	ret
   78B5                    3910 00164$:
                           3911 ;	../../Common/routing.c:1058: if(neighbor_table.count)
                           3912 ;	genPointerGet
                           3913 ;	genFarPointerGet
   78B5 90 EF BC           3914 	mov	dptr,#_neighbor_table
   78B8 E0                 3915 	movx	a,@dptr
                           3916 ;	genIfxJump
   78B9 70 03              3917 	jnz	00165$
   78BB 02 7B F8           3918 	ljmp	00114$
   78BE                    3919 00165$:
                           3920 ;	../../Common/routing.c:1060: debug("Neighbor Info count:");
                           3921 ;	genCall
                           3922 ;	Peephole 182.a	used 16 bit load of DPTR
   78BE 90 E7 BB           3923 	mov	dptr,#__str_0
   78C1 12 38 E8           3924 	lcall	_debug_constant
                           3925 ;	../../Common/routing.c:1061: debug_hex(neighbor_table.count);
                           3926 ;	genPointerGet
                           3927 ;	genFarPointerGet
   78C4 90 EF BC           3928 	mov	dptr,#_neighbor_table
   78C7 E0                 3929 	movx	a,@dptr
   78C8 FA                 3930 	mov	r2,a
                           3931 ;	genCast
   78C9 7B 00              3932 	mov	r3,#0x00
                           3933 ;	genIpush
   78CB C0 02              3934 	push	ar2
   78CD C0 03              3935 	push	ar3
                           3936 ;	genIpush
   78CF 74 10              3937 	mov	a,#0x10
   78D1 C0 E0              3938 	push	acc
                           3939 ;	genCall
   78D3 75 82 02           3940 	mov	dpl,#0x02
   78D6 12 39 23           3941 	lcall	_debug_integer
   78D9 15 81              3942 	dec	sp
   78DB 15 81              3943 	dec	sp
   78DD 15 81              3944 	dec	sp
                           3945 ;	../../Common/routing.c:1062: debug("\r\n");
                           3946 ;	genCall
                           3947 ;	Peephole 182.a	used 16 bit load of DPTR
   78DF 90 E7 D0           3948 	mov	dptr,#__str_1
   78E2 12 38 E8           3949 	lcall	_debug_constant
                           3950 ;	../../Common/routing.c:1063: debug("Child count:");
                           3951 ;	genCall
                           3952 ;	Peephole 182.a	used 16 bit load of DPTR
   78E5 90 E7 D3           3953 	mov	dptr,#__str_2
   78E8 12 38 E8           3954 	lcall	_debug_constant
                           3955 ;	../../Common/routing.c:1064: debug_hex(neighbor_table.child_count);
                           3956 ;	genPointerGet
                           3957 ;	genFarPointerGet
   78EB 90 EF BD           3958 	mov	dptr,#(_neighbor_table + 0x0001)
   78EE E0                 3959 	movx	a,@dptr
   78EF FA                 3960 	mov	r2,a
                           3961 ;	genCast
   78F0 7B 00              3962 	mov	r3,#0x00
                           3963 ;	genIpush
   78F2 C0 02              3964 	push	ar2
   78F4 C0 03              3965 	push	ar3
                           3966 ;	genIpush
   78F6 74 10              3967 	mov	a,#0x10
   78F8 C0 E0              3968 	push	acc
                           3969 ;	genCall
   78FA 75 82 02           3970 	mov	dpl,#0x02
   78FD 12 39 23           3971 	lcall	_debug_integer
   7900 15 81              3972 	dec	sp
   7902 15 81              3973 	dec	sp
   7904 15 81              3974 	dec	sp
                           3975 ;	../../Common/routing.c:1065: debug("\r\n");
                           3976 ;	genCall
                           3977 ;	Peephole 182.a	used 16 bit load of DPTR
   7906 90 E7 D0           3978 	mov	dptr,#__str_1
   7909 12 38 E8           3979 	lcall	_debug_constant
                           3980 ;	../../Common/routing.c:1066: for(i=0; i < neighbor_table.count; i++)
                           3981 ;	genAssign
   790C 7A 00              3982 	mov	r2,#0x00
   790E                    3983 00134$:
                           3984 ;	genPointerGet
                           3985 ;	genFarPointerGet
   790E 90 EF BC           3986 	mov	dptr,#_neighbor_table
   7911 E0                 3987 	movx	a,@dptr
   7912 FB                 3988 	mov	r3,a
                           3989 ;	genCmpLt
                           3990 ;	genCmp
   7913 C3                 3991 	clr	c
   7914 EA                 3992 	mov	a,r2
   7915 9B                 3993 	subb	a,r3
                           3994 ;	genIfxJump
   7916 40 03              3995 	jc	00166$
   7918 02 7B FE           3996 	ljmp	00115$
   791B                    3997 00166$:
                           3998 ;	../../Common/routing.c:1068: if(neighbor_table.neighbor_info[i]->type== ADDR_802_15_4_PAN_LONG)
                           3999 ;	genMult
                           4000 ;	genMultOneByte
   791B EA                 4001 	mov	a,r2
   791C 75 F0 03           4002 	mov	b,#0x03
   791F A4                 4003 	mul	ab
                           4004 ;	genPlus
   7920 FB                 4005 	mov	r3,a
                           4006 ;	Peephole 177.b	removed redundant mov
   7921 24 BE              4007 	add	a,#(_neighbor_table + 0x0002)
   7923 F5 82              4008 	mov	dpl,a
                           4009 ;	Peephole 181	changed mov to clr
   7925 E4                 4010 	clr	a
   7926 34 EF              4011 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7928 F5 83              4012 	mov	dph,a
                           4013 ;	genPointerGet
                           4014 ;	genFarPointerGet
   792A E0                 4015 	movx	a,@dptr
   792B FC                 4016 	mov	r4,a
   792C A3                 4017 	inc	dptr
   792D E0                 4018 	movx	a,@dptr
   792E FD                 4019 	mov	r5,a
   792F A3                 4020 	inc	dptr
   7930 E0                 4021 	movx	a,@dptr
   7931 FE                 4022 	mov	r6,a
                           4023 ;	genPlus
                           4024 ;     genPlusIncr
   7932 74 0A              4025 	mov	a,#0x0A
                           4026 ;	Peephole 236.a	used r4 instead of ar4
   7934 2C                 4027 	add	a,r4
   7935 FC                 4028 	mov	r4,a
                           4029 ;	Peephole 181	changed mov to clr
   7936 E4                 4030 	clr	a
                           4031 ;	Peephole 236.b	used r5 instead of ar5
   7937 3D                 4032 	addc	a,r5
   7938 FD                 4033 	mov	r5,a
                           4034 ;	genPointerGet
                           4035 ;	genGenPointerGet
   7939 8C 82              4036 	mov	dpl,r4
   793B 8D 83              4037 	mov	dph,r5
   793D 8E F0              4038 	mov	b,r6
   793F 12 E4 9F           4039 	lcall	__gptrget
   7942 FC                 4040 	mov	r4,a
                           4041 ;	genCmpEq
                           4042 ;	gencjneshort
   7943 BC 04 02           4043 	cjne	r4,#0x04,00167$
   7946 80 03              4044 	sjmp	00168$
   7948                    4045 00167$:
   7948 02 7A 35           4046 	ljmp	00106$
   794B                    4047 00168$:
                           4048 ;	../../Common/routing.c:1070: debug("Long:  ");
                           4049 ;	genCall
                           4050 ;	Peephole 182.a	used 16 bit load of DPTR
   794B 90 E7 E0           4051 	mov	dptr,#__str_3
   794E C0 02              4052 	push	ar2
   7950 C0 03              4053 	push	ar3
   7952 12 38 E8           4054 	lcall	_debug_constant
   7955 D0 03              4055 	pop	ar3
   7957 D0 02              4056 	pop	ar2
                           4057 ;	../../Common/routing.c:1071: for(j=0; j < 2 ; j++)
                           4058 ;	genAssign
   7959 7C 00              4059 	mov	r4,#0x00
   795B                    4060 00118$:
                           4061 ;	genCmpLt
                           4062 ;	genCmp
   795B BC 02 00           4063 	cjne	r4,#0x02,00169$
   795E                    4064 00169$:
                           4065 ;	genIfxJump
                           4066 ;	Peephole 108.a	removed ljmp by inverse jump logic
   795E 50 5F              4067 	jnc	00121$
                           4068 ;	Peephole 300	removed redundant label 00170$
                           4069 ;	../../Common/routing.c:1073: if (j) debug_put(':');
                           4070 ;	genIfx
   7960 EC                 4071 	mov	a,r4
                           4072 ;	genIfxJump
                           4073 ;	Peephole 108.c	removed ljmp by inverse jump logic
   7961 60 12              4074 	jz	00102$
                           4075 ;	Peephole 300	removed redundant label 00171$
                           4076 ;	genCall
   7963 75 82 3A           4077 	mov	dpl,#0x3A
   7966 C0 02              4078 	push	ar2
   7968 C0 03              4079 	push	ar3
   796A C0 04              4080 	push	ar4
   796C 12 38 E3           4081 	lcall	_debug_put
   796F D0 04              4082 	pop	ar4
   7971 D0 03              4083 	pop	ar3
   7973 D0 02              4084 	pop	ar2
   7975                    4085 00102$:
                           4086 ;	../../Common/routing.c:1074: debug_hex( neighbor_table.neighbor_info[i]->address[3-j]);
                           4087 ;	genPlus
                           4088 ;	Peephole 236.g	used r3 instead of ar3
   7975 EB                 4089 	mov	a,r3
   7976 24 BE              4090 	add	a,#(_neighbor_table + 0x0002)
   7978 F5 82              4091 	mov	dpl,a
                           4092 ;	Peephole 181	changed mov to clr
   797A E4                 4093 	clr	a
   797B 34 EF              4094 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   797D F5 83              4095 	mov	dph,a
                           4096 ;	genPointerGet
                           4097 ;	genFarPointerGet
   797F E0                 4098 	movx	a,@dptr
   7980 FD                 4099 	mov	r5,a
   7981 A3                 4100 	inc	dptr
   7982 E0                 4101 	movx	a,@dptr
   7983 FE                 4102 	mov	r6,a
   7984 A3                 4103 	inc	dptr
   7985 E0                 4104 	movx	a,@dptr
   7986 FF                 4105 	mov	r7,a
                           4106 ;	genMinus
   7987 74 03              4107 	mov	a,#0x03
   7989 C3                 4108 	clr	c
                           4109 ;	Peephole 236.l	used r4 instead of ar4
   798A 9C                 4110 	subb	a,r4
                           4111 ;	genPlus
                           4112 ;	Peephole 236.a	used r5 instead of ar5
   798B 2D                 4113 	add	a,r5
   798C FD                 4114 	mov	r5,a
                           4115 ;	Peephole 236.g	used r6 instead of ar6
                           4116 ;	Peephole 240	use clr instead of addc a,#0
   798D E4                 4117 	clr	a
   798E 3E                 4118 	addc	a,r6
   798F FE                 4119 	mov	r6,a
                           4120 ;	genPointerGet
                           4121 ;	genGenPointerGet
   7990 8D 82              4122 	mov	dpl,r5
   7992 8E 83              4123 	mov	dph,r6
   7994 8F F0              4124 	mov	b,r7
   7996 12 E4 9F           4125 	lcall	__gptrget
   7999 FD                 4126 	mov	r5,a
                           4127 ;	genCast
   799A 7E 00              4128 	mov	r6,#0x00
                           4129 ;	genIpush
   799C C0 02              4130 	push	ar2
   799E C0 03              4131 	push	ar3
   79A0 C0 04              4132 	push	ar4
   79A2 C0 05              4133 	push	ar5
   79A4 C0 06              4134 	push	ar6
                           4135 ;	genIpush
   79A6 74 10              4136 	mov	a,#0x10
   79A8 C0 E0              4137 	push	acc
                           4138 ;	genCall
   79AA 75 82 02           4139 	mov	dpl,#0x02
   79AD 12 39 23           4140 	lcall	_debug_integer
   79B0 15 81              4141 	dec	sp
   79B2 15 81              4142 	dec	sp
   79B4 15 81              4143 	dec	sp
   79B6 D0 04              4144 	pop	ar4
   79B8 D0 03              4145 	pop	ar3
   79BA D0 02              4146 	pop	ar2
                           4147 ;	../../Common/routing.c:1071: for(j=0; j < 2 ; j++)
                           4148 ;	genPlus
                           4149 ;     genPlusIncr
   79BC 0C                 4150 	inc	r4
                           4151 ;	Peephole 112.b	changed ljmp to sjmp
   79BD 80 9C              4152 	sjmp	00118$
   79BF                    4153 00121$:
                           4154 ;	../../Common/routing.c:1076: debug("  ");
                           4155 ;	genCall
                           4156 ;	Peephole 182.a	used 16 bit load of DPTR
   79BF 90 E7 E8           4157 	mov	dptr,#__str_4
   79C2 C0 02              4158 	push	ar2
   79C4 12 38 E8           4159 	lcall	_debug_constant
   79C7 D0 02              4160 	pop	ar2
                           4161 ;	../../Common/routing.c:1077: for(j=0; j < 2 ; j++)
                           4162 ;	genMult
                           4163 ;	genMultOneByte
   79C9 EA                 4164 	mov	a,r2
   79CA 75 F0 03           4165 	mov	b,#0x03
   79CD A4                 4166 	mul	ab
   79CE FB                 4167 	mov	r3,a
                           4168 ;	genAssign
   79CF 7C 00              4169 	mov	r4,#0x00
   79D1                    4170 00122$:
                           4171 ;	genCmpLt
                           4172 ;	genCmp
   79D1 BC 02 00           4173 	cjne	r4,#0x02,00172$
   79D4                    4174 00172$:
                           4175 ;	genIfxJump
                           4176 ;	Peephole 108.a	removed ljmp by inverse jump logic
   79D4 50 5F              4177 	jnc	00106$
                           4178 ;	Peephole 300	removed redundant label 00173$
                           4179 ;	../../Common/routing.c:1079: if (j) debug_put(':');
                           4180 ;	genIfx
   79D6 EC                 4181 	mov	a,r4
                           4182 ;	genIfxJump
                           4183 ;	Peephole 108.c	removed ljmp by inverse jump logic
   79D7 60 12              4184 	jz	00104$
                           4185 ;	Peephole 300	removed redundant label 00174$
                           4186 ;	genCall
   79D9 75 82 3A           4187 	mov	dpl,#0x3A
   79DC C0 02              4188 	push	ar2
   79DE C0 03              4189 	push	ar3
   79E0 C0 04              4190 	push	ar4
   79E2 12 38 E3           4191 	lcall	_debug_put
   79E5 D0 04              4192 	pop	ar4
   79E7 D0 03              4193 	pop	ar3
   79E9 D0 02              4194 	pop	ar2
   79EB                    4195 00104$:
                           4196 ;	../../Common/routing.c:1080: debug_hex( neighbor_table.neighbor_info[i]->address[1-j]);
                           4197 ;	genPlus
                           4198 ;	Peephole 236.g	used r3 instead of ar3
   79EB EB                 4199 	mov	a,r3
   79EC 24 BE              4200 	add	a,#(_neighbor_table + 0x0002)
   79EE F5 82              4201 	mov	dpl,a
                           4202 ;	Peephole 181	changed mov to clr
   79F0 E4                 4203 	clr	a
   79F1 34 EF              4204 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   79F3 F5 83              4205 	mov	dph,a
                           4206 ;	genPointerGet
                           4207 ;	genFarPointerGet
   79F5 E0                 4208 	movx	a,@dptr
   79F6 FD                 4209 	mov	r5,a
   79F7 A3                 4210 	inc	dptr
   79F8 E0                 4211 	movx	a,@dptr
   79F9 FE                 4212 	mov	r6,a
   79FA A3                 4213 	inc	dptr
   79FB E0                 4214 	movx	a,@dptr
   79FC FF                 4215 	mov	r7,a
                           4216 ;	genMinus
   79FD 74 01              4217 	mov	a,#0x01
   79FF C3                 4218 	clr	c
                           4219 ;	Peephole 236.l	used r4 instead of ar4
   7A00 9C                 4220 	subb	a,r4
                           4221 ;	genPlus
                           4222 ;	Peephole 236.a	used r5 instead of ar5
   7A01 2D                 4223 	add	a,r5
   7A02 FD                 4224 	mov	r5,a
                           4225 ;	Peephole 236.g	used r6 instead of ar6
                           4226 ;	Peephole 240	use clr instead of addc a,#0
   7A03 E4                 4227 	clr	a
   7A04 3E                 4228 	addc	a,r6
   7A05 FE                 4229 	mov	r6,a
                           4230 ;	genPointerGet
                           4231 ;	genGenPointerGet
   7A06 8D 82              4232 	mov	dpl,r5
   7A08 8E 83              4233 	mov	dph,r6
   7A0A 8F F0              4234 	mov	b,r7
   7A0C 12 E4 9F           4235 	lcall	__gptrget
   7A0F FD                 4236 	mov	r5,a
                           4237 ;	genCast
   7A10 7E 00              4238 	mov	r6,#0x00
                           4239 ;	genIpush
   7A12 C0 02              4240 	push	ar2
   7A14 C0 03              4241 	push	ar3
   7A16 C0 04              4242 	push	ar4
   7A18 C0 05              4243 	push	ar5
   7A1A C0 06              4244 	push	ar6
                           4245 ;	genIpush
   7A1C 74 10              4246 	mov	a,#0x10
   7A1E C0 E0              4247 	push	acc
                           4248 ;	genCall
   7A20 75 82 02           4249 	mov	dpl,#0x02
   7A23 12 39 23           4250 	lcall	_debug_integer
   7A26 15 81              4251 	dec	sp
   7A28 15 81              4252 	dec	sp
   7A2A 15 81              4253 	dec	sp
   7A2C D0 04              4254 	pop	ar4
   7A2E D0 03              4255 	pop	ar3
   7A30 D0 02              4256 	pop	ar2
                           4257 ;	../../Common/routing.c:1077: for(j=0; j < 2 ; j++)
                           4258 ;	genPlus
                           4259 ;     genPlusIncr
   7A32 0C                 4260 	inc	r4
                           4261 ;	Peephole 112.b	changed ljmp to sjmp
   7A33 80 9C              4262 	sjmp	00122$
   7A35                    4263 00106$:
                           4264 ;	../../Common/routing.c:1084: if(neighbor_table.neighbor_info[i]->type == ADDR_802_15_4_PAN_SHORT)
                           4265 ;	genMult
                           4266 ;	genMultOneByte
   7A35 EA                 4267 	mov	a,r2
   7A36 75 F0 03           4268 	mov	b,#0x03
   7A39 A4                 4269 	mul	ab
                           4270 ;	genPlus
   7A3A FB                 4271 	mov	r3,a
                           4272 ;	Peephole 177.b	removed redundant mov
   7A3B 24 BE              4273 	add	a,#(_neighbor_table + 0x0002)
   7A3D F5 82              4274 	mov	dpl,a
                           4275 ;	Peephole 181	changed mov to clr
   7A3F E4                 4276 	clr	a
   7A40 34 EF              4277 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7A42 F5 83              4278 	mov	dph,a
                           4279 ;	genPointerGet
                           4280 ;	genFarPointerGet
   7A44 E0                 4281 	movx	a,@dptr
   7A45 FC                 4282 	mov	r4,a
   7A46 A3                 4283 	inc	dptr
   7A47 E0                 4284 	movx	a,@dptr
   7A48 FD                 4285 	mov	r5,a
   7A49 A3                 4286 	inc	dptr
   7A4A E0                 4287 	movx	a,@dptr
   7A4B FE                 4288 	mov	r6,a
                           4289 ;	genPlus
                           4290 ;     genPlusIncr
   7A4C 74 0A              4291 	mov	a,#0x0A
                           4292 ;	Peephole 236.a	used r4 instead of ar4
   7A4E 2C                 4293 	add	a,r4
   7A4F FC                 4294 	mov	r4,a
                           4295 ;	Peephole 181	changed mov to clr
   7A50 E4                 4296 	clr	a
                           4297 ;	Peephole 236.b	used r5 instead of ar5
   7A51 3D                 4298 	addc	a,r5
   7A52 FD                 4299 	mov	r5,a
                           4300 ;	genPointerGet
                           4301 ;	genGenPointerGet
   7A53 8C 82              4302 	mov	dpl,r4
   7A55 8D 83              4303 	mov	dph,r5
   7A57 8E F0              4304 	mov	b,r6
   7A59 12 E4 9F           4305 	lcall	__gptrget
   7A5C FC                 4306 	mov	r4,a
                           4307 ;	genCmpEq
                           4308 ;	gencjneshort
   7A5D BC 03 02           4309 	cjne	r4,#0x03,00175$
   7A60 80 03              4310 	sjmp	00176$
   7A62                    4311 00175$:
   7A62 02 7B 4F           4312 	ljmp	00112$
   7A65                    4313 00176$:
                           4314 ;	../../Common/routing.c:1086: debug("Short:  ");
                           4315 ;	genCall
                           4316 ;	Peephole 182.a	used 16 bit load of DPTR
   7A65 90 E7 EB           4317 	mov	dptr,#__str_5
   7A68 C0 02              4318 	push	ar2
   7A6A C0 03              4319 	push	ar3
   7A6C 12 38 E8           4320 	lcall	_debug_constant
   7A6F D0 03              4321 	pop	ar3
   7A71 D0 02              4322 	pop	ar2
                           4323 ;	../../Common/routing.c:1087: for(j=0; j < 2 ; j++)
                           4324 ;	genAssign
   7A73 7C 00              4325 	mov	r4,#0x00
   7A75                    4326 00126$:
                           4327 ;	genCmpLt
                           4328 ;	genCmp
   7A75 BC 02 00           4329 	cjne	r4,#0x02,00177$
   7A78                    4330 00177$:
                           4331 ;	genIfxJump
                           4332 ;	Peephole 108.a	removed ljmp by inverse jump logic
   7A78 50 5F              4333 	jnc	00129$
                           4334 ;	Peephole 300	removed redundant label 00178$
                           4335 ;	../../Common/routing.c:1089: if (j) debug_put(':');
                           4336 ;	genIfx
   7A7A EC                 4337 	mov	a,r4
                           4338 ;	genIfxJump
                           4339 ;	Peephole 108.c	removed ljmp by inverse jump logic
   7A7B 60 12              4340 	jz	00108$
                           4341 ;	Peephole 300	removed redundant label 00179$
                           4342 ;	genCall
   7A7D 75 82 3A           4343 	mov	dpl,#0x3A
   7A80 C0 02              4344 	push	ar2
   7A82 C0 03              4345 	push	ar3
   7A84 C0 04              4346 	push	ar4
   7A86 12 38 E3           4347 	lcall	_debug_put
   7A89 D0 04              4348 	pop	ar4
   7A8B D0 03              4349 	pop	ar3
   7A8D D0 02              4350 	pop	ar2
   7A8F                    4351 00108$:
                           4352 ;	../../Common/routing.c:1090: debug_hex( neighbor_table.neighbor_info[i]->address[3-j]);
                           4353 ;	genPlus
                           4354 ;	Peephole 236.g	used r3 instead of ar3
   7A8F EB                 4355 	mov	a,r3
   7A90 24 BE              4356 	add	a,#(_neighbor_table + 0x0002)
   7A92 F5 82              4357 	mov	dpl,a
                           4358 ;	Peephole 181	changed mov to clr
   7A94 E4                 4359 	clr	a
   7A95 34 EF              4360 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7A97 F5 83              4361 	mov	dph,a
                           4362 ;	genPointerGet
                           4363 ;	genFarPointerGet
   7A99 E0                 4364 	movx	a,@dptr
   7A9A FD                 4365 	mov	r5,a
   7A9B A3                 4366 	inc	dptr
   7A9C E0                 4367 	movx	a,@dptr
   7A9D FE                 4368 	mov	r6,a
   7A9E A3                 4369 	inc	dptr
   7A9F E0                 4370 	movx	a,@dptr
   7AA0 FF                 4371 	mov	r7,a
                           4372 ;	genMinus
   7AA1 74 03              4373 	mov	a,#0x03
   7AA3 C3                 4374 	clr	c
                           4375 ;	Peephole 236.l	used r4 instead of ar4
   7AA4 9C                 4376 	subb	a,r4
                           4377 ;	genPlus
                           4378 ;	Peephole 236.a	used r5 instead of ar5
   7AA5 2D                 4379 	add	a,r5
   7AA6 FD                 4380 	mov	r5,a
                           4381 ;	Peephole 236.g	used r6 instead of ar6
                           4382 ;	Peephole 240	use clr instead of addc a,#0
   7AA7 E4                 4383 	clr	a
   7AA8 3E                 4384 	addc	a,r6
   7AA9 FE                 4385 	mov	r6,a
                           4386 ;	genPointerGet
                           4387 ;	genGenPointerGet
   7AAA 8D 82              4388 	mov	dpl,r5
   7AAC 8E 83              4389 	mov	dph,r6
   7AAE 8F F0              4390 	mov	b,r7
   7AB0 12 E4 9F           4391 	lcall	__gptrget
   7AB3 FD                 4392 	mov	r5,a
                           4393 ;	genCast
   7AB4 7E 00              4394 	mov	r6,#0x00
                           4395 ;	genIpush
   7AB6 C0 02              4396 	push	ar2
   7AB8 C0 03              4397 	push	ar3
   7ABA C0 04              4398 	push	ar4
   7ABC C0 05              4399 	push	ar5
   7ABE C0 06              4400 	push	ar6
                           4401 ;	genIpush
   7AC0 74 10              4402 	mov	a,#0x10
   7AC2 C0 E0              4403 	push	acc
                           4404 ;	genCall
   7AC4 75 82 02           4405 	mov	dpl,#0x02
   7AC7 12 39 23           4406 	lcall	_debug_integer
   7ACA 15 81              4407 	dec	sp
   7ACC 15 81              4408 	dec	sp
   7ACE 15 81              4409 	dec	sp
   7AD0 D0 04              4410 	pop	ar4
   7AD2 D0 03              4411 	pop	ar3
   7AD4 D0 02              4412 	pop	ar2
                           4413 ;	../../Common/routing.c:1087: for(j=0; j < 2 ; j++)
                           4414 ;	genPlus
                           4415 ;     genPlusIncr
   7AD6 0C                 4416 	inc	r4
                           4417 ;	Peephole 112.b	changed ljmp to sjmp
   7AD7 80 9C              4418 	sjmp	00126$
   7AD9                    4419 00129$:
                           4420 ;	../../Common/routing.c:1092: debug("  ");
                           4421 ;	genCall
                           4422 ;	Peephole 182.a	used 16 bit load of DPTR
   7AD9 90 E7 E8           4423 	mov	dptr,#__str_4
   7ADC C0 02              4424 	push	ar2
   7ADE 12 38 E8           4425 	lcall	_debug_constant
   7AE1 D0 02              4426 	pop	ar2
                           4427 ;	../../Common/routing.c:1093: for(j=0; j < 2 ; j++)
                           4428 ;	genMult
                           4429 ;	genMultOneByte
   7AE3 EA                 4430 	mov	a,r2
   7AE4 75 F0 03           4431 	mov	b,#0x03
   7AE7 A4                 4432 	mul	ab
   7AE8 FB                 4433 	mov	r3,a
                           4434 ;	genAssign
   7AE9 7C 00              4435 	mov	r4,#0x00
   7AEB                    4436 00130$:
                           4437 ;	genCmpLt
                           4438 ;	genCmp
   7AEB BC 02 00           4439 	cjne	r4,#0x02,00180$
   7AEE                    4440 00180$:
                           4441 ;	genIfxJump
                           4442 ;	Peephole 108.a	removed ljmp by inverse jump logic
   7AEE 50 5F              4443 	jnc	00112$
                           4444 ;	Peephole 300	removed redundant label 00181$
                           4445 ;	../../Common/routing.c:1095: if (j) debug_put(':');
                           4446 ;	genIfx
   7AF0 EC                 4447 	mov	a,r4
                           4448 ;	genIfxJump
                           4449 ;	Peephole 108.c	removed ljmp by inverse jump logic
   7AF1 60 12              4450 	jz	00110$
                           4451 ;	Peephole 300	removed redundant label 00182$
                           4452 ;	genCall
   7AF3 75 82 3A           4453 	mov	dpl,#0x3A
   7AF6 C0 02              4454 	push	ar2
   7AF8 C0 03              4455 	push	ar3
   7AFA C0 04              4456 	push	ar4
   7AFC 12 38 E3           4457 	lcall	_debug_put
   7AFF D0 04              4458 	pop	ar4
   7B01 D0 03              4459 	pop	ar3
   7B03 D0 02              4460 	pop	ar2
   7B05                    4461 00110$:
                           4462 ;	../../Common/routing.c:1096: debug_hex( neighbor_table.neighbor_info[i]->address[1-j]);
                           4463 ;	genPlus
                           4464 ;	Peephole 236.g	used r3 instead of ar3
   7B05 EB                 4465 	mov	a,r3
   7B06 24 BE              4466 	add	a,#(_neighbor_table + 0x0002)
   7B08 F5 82              4467 	mov	dpl,a
                           4468 ;	Peephole 181	changed mov to clr
   7B0A E4                 4469 	clr	a
   7B0B 34 EF              4470 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7B0D F5 83              4471 	mov	dph,a
                           4472 ;	genPointerGet
                           4473 ;	genFarPointerGet
   7B0F E0                 4474 	movx	a,@dptr
   7B10 FD                 4475 	mov	r5,a
   7B11 A3                 4476 	inc	dptr
   7B12 E0                 4477 	movx	a,@dptr
   7B13 FE                 4478 	mov	r6,a
   7B14 A3                 4479 	inc	dptr
   7B15 E0                 4480 	movx	a,@dptr
   7B16 FF                 4481 	mov	r7,a
                           4482 ;	genMinus
   7B17 74 01              4483 	mov	a,#0x01
   7B19 C3                 4484 	clr	c
                           4485 ;	Peephole 236.l	used r4 instead of ar4
   7B1A 9C                 4486 	subb	a,r4
                           4487 ;	genPlus
                           4488 ;	Peephole 236.a	used r5 instead of ar5
   7B1B 2D                 4489 	add	a,r5
   7B1C FD                 4490 	mov	r5,a
                           4491 ;	Peephole 236.g	used r6 instead of ar6
                           4492 ;	Peephole 240	use clr instead of addc a,#0
   7B1D E4                 4493 	clr	a
   7B1E 3E                 4494 	addc	a,r6
   7B1F FE                 4495 	mov	r6,a
                           4496 ;	genPointerGet
                           4497 ;	genGenPointerGet
   7B20 8D 82              4498 	mov	dpl,r5
   7B22 8E 83              4499 	mov	dph,r6
   7B24 8F F0              4500 	mov	b,r7
   7B26 12 E4 9F           4501 	lcall	__gptrget
   7B29 FD                 4502 	mov	r5,a
                           4503 ;	genCast
   7B2A 7E 00              4504 	mov	r6,#0x00
                           4505 ;	genIpush
   7B2C C0 02              4506 	push	ar2
   7B2E C0 03              4507 	push	ar3
   7B30 C0 04              4508 	push	ar4
   7B32 C0 05              4509 	push	ar5
   7B34 C0 06              4510 	push	ar6
                           4511 ;	genIpush
   7B36 74 10              4512 	mov	a,#0x10
   7B38 C0 E0              4513 	push	acc
                           4514 ;	genCall
   7B3A 75 82 02           4515 	mov	dpl,#0x02
   7B3D 12 39 23           4516 	lcall	_debug_integer
   7B40 15 81              4517 	dec	sp
   7B42 15 81              4518 	dec	sp
   7B44 15 81              4519 	dec	sp
   7B46 D0 04              4520 	pop	ar4
   7B48 D0 03              4521 	pop	ar3
   7B4A D0 02              4522 	pop	ar2
                           4523 ;	../../Common/routing.c:1093: for(j=0; j < 2 ; j++)
                           4524 ;	genPlus
                           4525 ;     genPlusIncr
   7B4C 0C                 4526 	inc	r4
                           4527 ;	Peephole 112.b	changed ljmp to sjmp
   7B4D 80 9C              4528 	sjmp	00130$
   7B4F                    4529 00112$:
                           4530 ;	../../Common/routing.c:1099: debug("\r\nlast_lqi: ");
                           4531 ;	genCall
                           4532 ;	Peephole 182.a	used 16 bit load of DPTR
   7B4F 90 E7 F4           4533 	mov	dptr,#__str_6
   7B52 C0 02              4534 	push	ar2
   7B54 12 38 E8           4535 	lcall	_debug_constant
   7B57 D0 02              4536 	pop	ar2
                           4537 ;	../../Common/routing.c:1100: debug_hex(neighbor_table.neighbor_info[i]->last_lqi);
                           4538 ;	genMult
                           4539 ;	genMultOneByte
   7B59 EA                 4540 	mov	a,r2
   7B5A 75 F0 03           4541 	mov	b,#0x03
   7B5D A4                 4542 	mul	ab
                           4543 ;	genPlus
   7B5E FB                 4544 	mov	r3,a
                           4545 ;	Peephole 177.b	removed redundant mov
   7B5F 24 BE              4546 	add	a,#(_neighbor_table + 0x0002)
   7B61 F5 82              4547 	mov	dpl,a
                           4548 ;	Peephole 181	changed mov to clr
   7B63 E4                 4549 	clr	a
   7B64 34 EF              4550 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7B66 F5 83              4551 	mov	dph,a
                           4552 ;	genPointerGet
                           4553 ;	genFarPointerGet
   7B68 E0                 4554 	movx	a,@dptr
   7B69 FC                 4555 	mov	r4,a
   7B6A A3                 4556 	inc	dptr
   7B6B E0                 4557 	movx	a,@dptr
   7B6C FD                 4558 	mov	r5,a
   7B6D A3                 4559 	inc	dptr
   7B6E E0                 4560 	movx	a,@dptr
   7B6F FE                 4561 	mov	r6,a
                           4562 ;	genPlus
                           4563 ;     genPlusIncr
   7B70 74 0B              4564 	mov	a,#0x0B
                           4565 ;	Peephole 236.a	used r4 instead of ar4
   7B72 2C                 4566 	add	a,r4
   7B73 FC                 4567 	mov	r4,a
                           4568 ;	Peephole 181	changed mov to clr
   7B74 E4                 4569 	clr	a
                           4570 ;	Peephole 236.b	used r5 instead of ar5
   7B75 3D                 4571 	addc	a,r5
   7B76 FD                 4572 	mov	r5,a
                           4573 ;	genPointerGet
                           4574 ;	genGenPointerGet
   7B77 8C 82              4575 	mov	dpl,r4
   7B79 8D 83              4576 	mov	dph,r5
   7B7B 8E F0              4577 	mov	b,r6
   7B7D 12 E4 9F           4578 	lcall	__gptrget
   7B80 FC                 4579 	mov	r4,a
                           4580 ;	genCast
   7B81 7D 00              4581 	mov	r5,#0x00
                           4582 ;	genIpush
   7B83 C0 02              4583 	push	ar2
   7B85 C0 03              4584 	push	ar3
   7B87 C0 04              4585 	push	ar4
   7B89 C0 05              4586 	push	ar5
                           4587 ;	genIpush
   7B8B 74 10              4588 	mov	a,#0x10
   7B8D C0 E0              4589 	push	acc
                           4590 ;	genCall
   7B8F 75 82 02           4591 	mov	dpl,#0x02
   7B92 12 39 23           4592 	lcall	_debug_integer
   7B95 15 81              4593 	dec	sp
   7B97 15 81              4594 	dec	sp
   7B99 15 81              4595 	dec	sp
   7B9B D0 03              4596 	pop	ar3
   7B9D D0 02              4597 	pop	ar2
                           4598 ;	../../Common/routing.c:1101: debug("\r\nTTL: ");
                           4599 ;	genCall
                           4600 ;	Peephole 182.a	used 16 bit load of DPTR
   7B9F 90 E8 01           4601 	mov	dptr,#__str_7
   7BA2 C0 02              4602 	push	ar2
   7BA4 C0 03              4603 	push	ar3
   7BA6 12 38 E8           4604 	lcall	_debug_constant
   7BA9 D0 03              4605 	pop	ar3
   7BAB D0 02              4606 	pop	ar2
                           4607 ;	../../Common/routing.c:1102: debug_hex(neighbor_table.neighbor_info[i]->ttl);
                           4608 ;	genPlus
                           4609 ;	Peephole 236.g	used r3 instead of ar3
   7BAD EB                 4610 	mov	a,r3
   7BAE 24 BE              4611 	add	a,#(_neighbor_table + 0x0002)
   7BB0 F5 82              4612 	mov	dpl,a
                           4613 ;	Peephole 181	changed mov to clr
   7BB2 E4                 4614 	clr	a
   7BB3 34 EF              4615 	addc	a,#((_neighbor_table + 0x0002) >> 8)
   7BB5 F5 83              4616 	mov	dph,a
                           4617 ;	genPointerGet
                           4618 ;	genFarPointerGet
   7BB7 E0                 4619 	movx	a,@dptr
   7BB8 FB                 4620 	mov	r3,a
   7BB9 A3                 4621 	inc	dptr
   7BBA E0                 4622 	movx	a,@dptr
   7BBB FC                 4623 	mov	r4,a
   7BBC A3                 4624 	inc	dptr
   7BBD E0                 4625 	movx	a,@dptr
   7BBE FD                 4626 	mov	r5,a
                           4627 ;	genPlus
                           4628 ;     genPlusIncr
   7BBF 74 0D              4629 	mov	a,#0x0D
                           4630 ;	Peephole 236.a	used r3 instead of ar3
   7BC1 2B                 4631 	add	a,r3
   7BC2 FB                 4632 	mov	r3,a
                           4633 ;	Peephole 181	changed mov to clr
   7BC3 E4                 4634 	clr	a
                           4635 ;	Peephole 236.b	used r4 instead of ar4
   7BC4 3C                 4636 	addc	a,r4
   7BC5 FC                 4637 	mov	r4,a
                           4638 ;	genPointerGet
                           4639 ;	genGenPointerGet
   7BC6 8B 82              4640 	mov	dpl,r3
   7BC8 8C 83              4641 	mov	dph,r4
   7BCA 8D F0              4642 	mov	b,r5
   7BCC 12 E4 9F           4643 	lcall	__gptrget
   7BCF FB                 4644 	mov	r3,a
                           4645 ;	genCast
   7BD0 7C 00              4646 	mov	r4,#0x00
                           4647 ;	genIpush
   7BD2 C0 02              4648 	push	ar2
   7BD4 C0 03              4649 	push	ar3
   7BD6 C0 04              4650 	push	ar4
                           4651 ;	genIpush
   7BD8 74 10              4652 	mov	a,#0x10
   7BDA C0 E0              4653 	push	acc
                           4654 ;	genCall
   7BDC 75 82 02           4655 	mov	dpl,#0x02
   7BDF 12 39 23           4656 	lcall	_debug_integer
   7BE2 15 81              4657 	dec	sp
   7BE4 15 81              4658 	dec	sp
   7BE6 15 81              4659 	dec	sp
   7BE8 D0 02              4660 	pop	ar2
                           4661 ;	../../Common/routing.c:1103: debug("\r\n");
                           4662 ;	genCall
                           4663 ;	Peephole 182.a	used 16 bit load of DPTR
   7BEA 90 E7 D0           4664 	mov	dptr,#__str_1
   7BED C0 02              4665 	push	ar2
   7BEF 12 38 E8           4666 	lcall	_debug_constant
   7BF2 D0 02              4667 	pop	ar2
                           4668 ;	../../Common/routing.c:1066: for(i=0; i < neighbor_table.count; i++)
                           4669 ;	genPlus
                           4670 ;     genPlusIncr
   7BF4 0A                 4671 	inc	r2
   7BF5 02 79 0E           4672 	ljmp	00134$
   7BF8                    4673 00114$:
                           4674 ;	../../Common/routing.c:1108: debug("No Neighbor info\r\n");
                           4675 ;	genCall
                           4676 ;	Peephole 182.a	used 16 bit load of DPTR
   7BF8 90 E8 09           4677 	mov	dptr,#__str_8
   7BFB 12 38 E8           4678 	lcall	_debug_constant
   7BFE                    4679 00115$:
                           4680 ;	../../Common/routing.c:1164: debug("Routing disable\r\n");
                           4681 ;	genCall
                           4682 ;	Peephole 182.a	used 16 bit load of DPTR
   7BFE 90 E8 1C           4683 	mov	dptr,#__str_9
   7C01 12 38 E8           4684 	lcall	_debug_constant
                           4685 ;	../../Common/routing.c:1167: free_table_semaphore();
                           4686 ;	genCall
                           4687 ;	Peephole 253.b	replaced lcall/ret with ljmp
   7C04 02 6D 28           4688 	ljmp	_free_table_semaphore
                           4689 ;
                           4690 	.area CSEG    (CODE)
                           4691 	.area CONST   (CODE)
   E7BB                    4692 __str_0:
   E7BB 4E 65 69 67 68 62  4693 	.ascii "Neighbor Info count:"
        6F 72 20 49 6E 66
        6F 20 63 6F 75 6E
        74 3A
   E7CF 00                 4694 	.db 0x00
   E7D0                    4695 __str_1:
   E7D0 0D                 4696 	.db 0x0D
   E7D1 0A                 4697 	.db 0x0A
   E7D2 00                 4698 	.db 0x00
   E7D3                    4699 __str_2:
   E7D3 43 68 69 6C 64 20  4700 	.ascii "Child count:"
        63 6F 75 6E 74 3A
   E7DF 00                 4701 	.db 0x00
   E7E0                    4702 __str_3:
   E7E0 4C 6F 6E 67 3A 20  4703 	.ascii "Long:  "
        20
   E7E7 00                 4704 	.db 0x00
   E7E8                    4705 __str_4:
   E7E8 20 20              4706 	.ascii "  "
   E7EA 00                 4707 	.db 0x00
   E7EB                    4708 __str_5:
   E7EB 53 68 6F 72 74 3A  4709 	.ascii "Short:  "
        20 20
   E7F3 00                 4710 	.db 0x00
   E7F4                    4711 __str_6:
   E7F4 0D                 4712 	.db 0x0D
   E7F5 0A                 4713 	.db 0x0A
   E7F6 6C 61 73 74 5F 6C  4714 	.ascii "last_lqi: "
        71 69 3A 20
   E800 00                 4715 	.db 0x00
   E801                    4716 __str_7:
   E801 0D                 4717 	.db 0x0D
   E802 0A                 4718 	.db 0x0A
   E803 54 54 4C 3A 20     4719 	.ascii "TTL: "
   E808 00                 4720 	.db 0x00
   E809                    4721 __str_8:
   E809 4E 6F 20 4E 65 69  4722 	.ascii "No Neighbor info"
        67 68 62 6F 72 20
        69 6E 66 6F
   E819 0D                 4723 	.db 0x0D
   E81A 0A                 4724 	.db 0x0A
   E81B 00                 4725 	.db 0x00
   E81C                    4726 __str_9:
   E81C 52 6F 75 74 69 6E  4727 	.ascii "Routing disable"
        67 20 64 69 73 61
        62 6C 65
   E82B 0D                 4728 	.db 0x0D
   E82C 0A                 4729 	.db 0x0A
   E82D 00                 4730 	.db 0x00
                           4731 	.area XINIT   (CODE)
   E8E4                    4732 __xinit__table_lock:
                           4733 ; generic printIvalPtr
   E8E4 00 00 00           4734 	.byte #0x00,#0x00,#0x00
   E8E7                    4735 __xinit__n_neigh_buffer:
   E8E7 00                 4736 	.db #0x00
