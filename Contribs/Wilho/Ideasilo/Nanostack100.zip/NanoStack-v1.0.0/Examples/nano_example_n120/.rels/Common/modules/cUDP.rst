                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Nov 10 2006)
                              4 ; This file generated Fri Feb  1 13:33:41 2008
                              5 ;--------------------------------------------------------
                              6 	.module cUDP
                              7 	.optsdcc -mmcs51 --model-large
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _IRCON2_P2IF
                             13 	.globl _IRCON2_UTX0IF
                             14 	.globl _IRCON2_UTX1IF
                             15 	.globl _IRCON2_P1IF
                             16 	.globl _IRCON2_WDTIF
                             17 	.globl _CY
                             18 	.globl _AC
                             19 	.globl _F0
                             20 	.globl _RS1
                             21 	.globl _RS0
                             22 	.globl _OV
                             23 	.globl _F1
                             24 	.globl _P
                             25 	.globl _IRCON_DMAIF
                             26 	.globl _IRCON_T1IF
                             27 	.globl _IRCON_T2IF
                             28 	.globl _IRCON_T3IF
                             29 	.globl _IRCON_T4IF
                             30 	.globl _IRCON_P0IF
                             31 	.globl _IRCON_STIF
                             32 	.globl _IEN1_DMAIE
                             33 	.globl _IEN1_T1IE
                             34 	.globl _IEN1_T2IE
                             35 	.globl _IEN1_T3IE
                             36 	.globl _IEN1_T4IE
                             37 	.globl _IEN1_P0IE
                             38 	.globl _IEN0_RFERRIE
                             39 	.globl _IEN0_ADCIE
                             40 	.globl _IEN0_URX0IE
                             41 	.globl _IEN0_URX1IE
                             42 	.globl _IEN0_ENCIE
                             43 	.globl _IEN0_STIE
                             44 	.globl _IEN0_EA
                             45 	.globl _EA
                             46 	.globl _P2_4
                             47 	.globl _P2_3
                             48 	.globl _P2_2
                             49 	.globl _P2_1
                             50 	.globl _P2_0
                             51 	.globl _S0CON_ENCIF_0
                             52 	.globl _S0CON_ENCIF_1
                             53 	.globl _P1_7
                             54 	.globl _P1_6
                             55 	.globl _P1_5
                             56 	.globl _P1_4
                             57 	.globl _P1_3
                             58 	.globl _P1_2
                             59 	.globl _P1_1
                             60 	.globl _P1_0
                             61 	.globl _TCON_IT0
                             62 	.globl _TCON_RFERRIF
                             63 	.globl _TCON_IT1
                             64 	.globl _TCON_URX0IF
                             65 	.globl _TCON_ADCIF
                             66 	.globl _TCON_URX1IF
                             67 	.globl _P0_0
                             68 	.globl _P0_1
                             69 	.globl _P0_2
                             70 	.globl _P0_3
                             71 	.globl _P0_4
                             72 	.globl _P0_5
                             73 	.globl _P0_6
                             74 	.globl _P0_7
                             75 	.globl _P2DIR
                             76 	.globl _P1DIR
                             77 	.globl _P0DIR
                             78 	.globl _U1GCR
                             79 	.globl _U1UCR
                             80 	.globl _U1BAUD
                             81 	.globl _U1BUF
                             82 	.globl _U1CSR
                             83 	.globl _P2INP
                             84 	.globl _P1INP
                             85 	.globl _P2SEL
                             86 	.globl _P1SEL
                             87 	.globl _P0SEL
                             88 	.globl _ADCCFG
                             89 	.globl _PERCFG
                             90 	.globl _B
                             91 	.globl _T4CC1
                             92 	.globl _T4CCTL1
                             93 	.globl _T4CC0
                             94 	.globl _T4CCTL0
                             95 	.globl _T4CTL
                             96 	.globl _T4CNT
                             97 	.globl _RFIF
                             98 	.globl _IRCON2
                             99 	.globl _T1CCTL2
                            100 	.globl _T1CCTL1
                            101 	.globl _T1CCTL0
                            102 	.globl _T1CTL
                            103 	.globl _T1CNTH
                            104 	.globl _T1CNTL
                            105 	.globl _RFST
                            106 	.globl _ACC
                            107 	.globl _T1CC2H
                            108 	.globl _T1CC2L
                            109 	.globl _T1CC1H
                            110 	.globl _T1CC1L
                            111 	.globl _T1CC0H
                            112 	.globl _T1CC0L
                            113 	.globl _RFD
                            114 	.globl _TIMIF
                            115 	.globl _DMAREQ
                            116 	.globl _DMAARM
                            117 	.globl _DMA0CFGH
                            118 	.globl _DMA0CFGL
                            119 	.globl _DMA1CFGH
                            120 	.globl _DMA1CFGL
                            121 	.globl _DMAIRQ
                            122 	.globl _PSW
                            123 	.globl _T3CC1
                            124 	.globl _T3CCTL1
                            125 	.globl _T3CC0
                            126 	.globl _T3CCTL0
                            127 	.globl _T3CTL
                            128 	.globl _T3CNT
                            129 	.globl _WDCTL
                            130 	.globl _T2CON
                            131 	.globl _MEMCTR
                            132 	.globl _CLKCON
                            133 	.globl _U0GCR
                            134 	.globl _U0UCR
                            135 	.globl _T2CNF
                            136 	.globl _U0BAUD
                            137 	.globl _U0BUF
                            138 	.globl _IRCON
                            139 	.globl _SLEEP
                            140 	.globl _RNDH
                            141 	.globl _RNDL
                            142 	.globl _ADCH
                            143 	.globl _ADCL
                            144 	.globl _IP1
                            145 	.globl _IEN1
                            146 	.globl _RCCTL
                            147 	.globl _ADCCON3
                            148 	.globl _ADCCON2
                            149 	.globl _ADCCON1
                            150 	.globl _ENCCS
                            151 	.globl _ENCDO
                            152 	.globl _ENCDI
                            153 	.globl _FWDATA
                            154 	.globl _FCTL
                            155 	.globl _FADDRH
                            156 	.globl _FADDRL
                            157 	.globl _FWT
                            158 	.globl _IP0
                            159 	.globl _IEN0
                            160 	.globl _IE
                            161 	.globl _T2THD
                            162 	.globl _T2TLD
                            163 	.globl _T2CAPHPH
                            164 	.globl _T2CAPLPL
                            165 	.globl _T2OF2
                            166 	.globl _T2OF1
                            167 	.globl _T2OF0
                            168 	.globl _P2
                            169 	.globl _T2PEROF2
                            170 	.globl _T2PEROF1
                            171 	.globl _T2PEROF0
                            172 	.globl _S1CON
                            173 	.globl _IEN2
                            174 	.globl _HSRC
                            175 	.globl _S0CON
                            176 	.globl _ST2
                            177 	.globl _ST1
                            178 	.globl _ST0
                            179 	.globl _T2CMP
                            180 	.globl __XPAGE
                            181 	.globl _DPS
                            182 	.globl _RFIM
                            183 	.globl _P1
                            184 	.globl _P0INP
                            185 	.globl _P1IEN
                            186 	.globl _PICTL
                            187 	.globl _P2IFG
                            188 	.globl _P1IFG
                            189 	.globl _P0IFG
                            190 	.globl _TCON
                            191 	.globl _PCON
                            192 	.globl _U0CSR
                            193 	.globl _DPH1
                            194 	.globl _DPL1
                            195 	.globl _DPH0
                            196 	.globl _DPL0
                            197 	.globl _SP
                            198 	.globl _P0
                            199 	.globl _use_compress
                            200 	.globl _RFD_SHADOW
                            201 	.globl _RFSTATUS
                            202 	.globl _CHIPID
                            203 	.globl _CHVER
                            204 	.globl _FSMTC1
                            205 	.globl _RXFIFOCNT
                            206 	.globl _IOCFG3
                            207 	.globl _IOCFG2
                            208 	.globl _IOCFG1
                            209 	.globl _IOCFG0
                            210 	.globl _SHORTADDRL
                            211 	.globl _SHORTADDRH
                            212 	.globl _PANIDL
                            213 	.globl _PANIDH
                            214 	.globl _IEEE_ADDR7
                            215 	.globl _IEEE_ADDR6
                            216 	.globl _IEEE_ADDR5
                            217 	.globl _IEEE_ADDR4
                            218 	.globl _IEEE_ADDR3
                            219 	.globl _IEEE_ADDR2
                            220 	.globl _IEEE_ADDR1
                            221 	.globl _IEEE_ADDR0
                            222 	.globl _DACTSTL
                            223 	.globl _DACTSTH
                            224 	.globl _ADCTSTL
                            225 	.globl _ADCTSTH
                            226 	.globl _FSMSTATE
                            227 	.globl _AGCCTRLL
                            228 	.globl _AGCCTRLH
                            229 	.globl _MANORL
                            230 	.globl _MANORH
                            231 	.globl _MANANDL
                            232 	.globl _MANANDH
                            233 	.globl _FSMTCL
                            234 	.globl _FSMTCH
                            235 	.globl _RFPWR
                            236 	.globl _CSPT
                            237 	.globl _CSPCTRL
                            238 	.globl _CSPZ
                            239 	.globl _CSPY
                            240 	.globl _CSPX
                            241 	.globl _FSCTRLL
                            242 	.globl _FSCTRLH
                            243 	.globl _RXCTRL1L
                            244 	.globl _RXCTRL1H
                            245 	.globl _RXCTRL0L
                            246 	.globl _RXCTRL0H
                            247 	.globl _TXCTRLL
                            248 	.globl _TXCTRLH
                            249 	.globl _SYNCWORDL
                            250 	.globl _SYNCWORDH
                            251 	.globl _RSSIL
                            252 	.globl _RSSIH
                            253 	.globl _MDMCTRL1L
                            254 	.globl _MDMCTRL1H
                            255 	.globl _MDMCTRL0L
                            256 	.globl _MDMCTRL0H
                            257 	.globl _cudp_init
                            258 	.globl _cudp_compress_mode
                            259 	.globl _cudp_handle
                            260 	.globl _cudp_check
                            261 ;--------------------------------------------------------
                            262 ; special function registers
                            263 ;--------------------------------------------------------
                            264 	.area RSEG    (DATA)
                    0080    265 _P0	=	0x0080
                    0081    266 _SP	=	0x0081
                    0082    267 _DPL0	=	0x0082
                    0083    268 _DPH0	=	0x0083
                    0084    269 _DPL1	=	0x0084
                    0085    270 _DPH1	=	0x0085
                    0086    271 _U0CSR	=	0x0086
                    0087    272 _PCON	=	0x0087
                    0088    273 _TCON	=	0x0088
                    0089    274 _P0IFG	=	0x0089
                    008A    275 _P1IFG	=	0x008a
                    008B    276 _P2IFG	=	0x008b
                    008C    277 _PICTL	=	0x008c
                    008D    278 _P1IEN	=	0x008d
                    008F    279 _P0INP	=	0x008f
                    0090    280 _P1	=	0x0090
                    0091    281 _RFIM	=	0x0091
                    0092    282 _DPS	=	0x0092
                    0093    283 __XPAGE	=	0x0093
                    0094    284 _T2CMP	=	0x0094
                    0095    285 _ST0	=	0x0095
                    0096    286 _ST1	=	0x0096
                    0097    287 _ST2	=	0x0097
                    0098    288 _S0CON	=	0x0098
                    0099    289 _HSRC	=	0x0099
                    009A    290 _IEN2	=	0x009a
                    009B    291 _S1CON	=	0x009b
                    009C    292 _T2PEROF0	=	0x009c
                    009D    293 _T2PEROF1	=	0x009d
                    009E    294 _T2PEROF2	=	0x009e
                    00A0    295 _P2	=	0x00a0
                    00A1    296 _T2OF0	=	0x00a1
                    00A2    297 _T2OF1	=	0x00a2
                    00A3    298 _T2OF2	=	0x00a3
                    00A4    299 _T2CAPLPL	=	0x00a4
                    00A5    300 _T2CAPHPH	=	0x00a5
                    00A6    301 _T2TLD	=	0x00a6
                    00A7    302 _T2THD	=	0x00a7
                    00A8    303 _IE	=	0x00a8
                    00A8    304 _IEN0	=	0x00a8
                    00A9    305 _IP0	=	0x00a9
                    00AB    306 _FWT	=	0x00ab
                    00AC    307 _FADDRL	=	0x00ac
                    00AD    308 _FADDRH	=	0x00ad
                    00AE    309 _FCTL	=	0x00ae
                    00AF    310 _FWDATA	=	0x00af
                    00B1    311 _ENCDI	=	0x00b1
                    00B2    312 _ENCDO	=	0x00b2
                    00B3    313 _ENCCS	=	0x00b3
                    00B4    314 _ADCCON1	=	0x00b4
                    00B5    315 _ADCCON2	=	0x00b5
                    00B6    316 _ADCCON3	=	0x00b6
                    00B7    317 _RCCTL	=	0x00b7
                    00B8    318 _IEN1	=	0x00b8
                    00B9    319 _IP1	=	0x00b9
                    00BA    320 _ADCL	=	0x00ba
                    00BB    321 _ADCH	=	0x00bb
                    00BC    322 _RNDL	=	0x00bc
                    00BD    323 _RNDH	=	0x00bd
                    00BE    324 _SLEEP	=	0x00be
                    00C0    325 _IRCON	=	0x00c0
                    00C1    326 _U0BUF	=	0x00c1
                    00C2    327 _U0BAUD	=	0x00c2
                    00C3    328 _T2CNF	=	0x00c3
                    00C4    329 _U0UCR	=	0x00c4
                    00C5    330 _U0GCR	=	0x00c5
                    00C6    331 _CLKCON	=	0x00c6
                    00C7    332 _MEMCTR	=	0x00c7
                    00C8    333 _T2CON	=	0x00c8
                    00C9    334 _WDCTL	=	0x00c9
                    00CA    335 _T3CNT	=	0x00ca
                    00CB    336 _T3CTL	=	0x00cb
                    00CC    337 _T3CCTL0	=	0x00cc
                    00CD    338 _T3CC0	=	0x00cd
                    00CE    339 _T3CCTL1	=	0x00ce
                    00CF    340 _T3CC1	=	0x00cf
                    00D0    341 _PSW	=	0x00d0
                    00D1    342 _DMAIRQ	=	0x00d1
                    00D2    343 _DMA1CFGL	=	0x00d2
                    00D3    344 _DMA1CFGH	=	0x00d3
                    00D4    345 _DMA0CFGL	=	0x00d4
                    00D5    346 _DMA0CFGH	=	0x00d5
                    00D6    347 _DMAARM	=	0x00d6
                    00D7    348 _DMAREQ	=	0x00d7
                    00D8    349 _TIMIF	=	0x00d8
                    00D9    350 _RFD	=	0x00d9
                    00DA    351 _T1CC0L	=	0x00da
                    00DB    352 _T1CC0H	=	0x00db
                    00DC    353 _T1CC1L	=	0x00dc
                    00DD    354 _T1CC1H	=	0x00dd
                    00DE    355 _T1CC2L	=	0x00de
                    00DF    356 _T1CC2H	=	0x00df
                    00E0    357 _ACC	=	0x00e0
                    00E1    358 _RFST	=	0x00e1
                    00E2    359 _T1CNTL	=	0x00e2
                    00E3    360 _T1CNTH	=	0x00e3
                    00E4    361 _T1CTL	=	0x00e4
                    00E5    362 _T1CCTL0	=	0x00e5
                    00E6    363 _T1CCTL1	=	0x00e6
                    00E7    364 _T1CCTL2	=	0x00e7
                    00E8    365 _IRCON2	=	0x00e8
                    00E9    366 _RFIF	=	0x00e9
                    00EA    367 _T4CNT	=	0x00ea
                    00EB    368 _T4CTL	=	0x00eb
                    00EC    369 _T4CCTL0	=	0x00ec
                    00ED    370 _T4CC0	=	0x00ed
                    00EE    371 _T4CCTL1	=	0x00ee
                    00EF    372 _T4CC1	=	0x00ef
                    00F0    373 _B	=	0x00f0
                    00F1    374 _PERCFG	=	0x00f1
                    00F2    375 _ADCCFG	=	0x00f2
                    00F3    376 _P0SEL	=	0x00f3
                    00F4    377 _P1SEL	=	0x00f4
                    00F5    378 _P2SEL	=	0x00f5
                    00F6    379 _P1INP	=	0x00f6
                    00F7    380 _P2INP	=	0x00f7
                    00F8    381 _U1CSR	=	0x00f8
                    00F9    382 _U1BUF	=	0x00f9
                    00FA    383 _U1BAUD	=	0x00fa
                    00FB    384 _U1UCR	=	0x00fb
                    00FC    385 _U1GCR	=	0x00fc
                    00FD    386 _P0DIR	=	0x00fd
                    00FE    387 _P1DIR	=	0x00fe
                    00FF    388 _P2DIR	=	0x00ff
                            389 ;--------------------------------------------------------
                            390 ; special function bits
                            391 ;--------------------------------------------------------
                            392 	.area RSEG    (DATA)
                    0087    393 _P0_7	=	0x0087
                    0086    394 _P0_6	=	0x0086
                    0085    395 _P0_5	=	0x0085
                    0084    396 _P0_4	=	0x0084
                    0083    397 _P0_3	=	0x0083
                    0082    398 _P0_2	=	0x0082
                    0081    399 _P0_1	=	0x0081
                    0080    400 _P0_0	=	0x0080
                    008F    401 _TCON_URX1IF	=	0x008f
                    008D    402 _TCON_ADCIF	=	0x008d
                    008B    403 _TCON_URX0IF	=	0x008b
                    008A    404 _TCON_IT1	=	0x008a
                    0089    405 _TCON_RFERRIF	=	0x0089
                    0088    406 _TCON_IT0	=	0x0088
                    0090    407 _P1_0	=	0x0090
                    0091    408 _P1_1	=	0x0091
                    0092    409 _P1_2	=	0x0092
                    0093    410 _P1_3	=	0x0093
                    0094    411 _P1_4	=	0x0094
                    0095    412 _P1_5	=	0x0095
                    0096    413 _P1_6	=	0x0096
                    0097    414 _P1_7	=	0x0097
                    0099    415 _S0CON_ENCIF_1	=	0x0099
                    0098    416 _S0CON_ENCIF_0	=	0x0098
                    00A0    417 _P2_0	=	0x00a0
                    00A1    418 _P2_1	=	0x00a1
                    00A2    419 _P2_2	=	0x00a2
                    00A3    420 _P2_3	=	0x00a3
                    00A4    421 _P2_4	=	0x00a4
                    00AF    422 _EA	=	0x00af
                    00AF    423 _IEN0_EA	=	0x00af
                    00AD    424 _IEN0_STIE	=	0x00ad
                    00AC    425 _IEN0_ENCIE	=	0x00ac
                    00AB    426 _IEN0_URX1IE	=	0x00ab
                    00AA    427 _IEN0_URX0IE	=	0x00aa
                    00A9    428 _IEN0_ADCIE	=	0x00a9
                    00A8    429 _IEN0_RFERRIE	=	0x00a8
                    00BD    430 _IEN1_P0IE	=	0x00bd
                    00BC    431 _IEN1_T4IE	=	0x00bc
                    00BB    432 _IEN1_T3IE	=	0x00bb
                    00BA    433 _IEN1_T2IE	=	0x00ba
                    00B9    434 _IEN1_T1IE	=	0x00b9
                    00B8    435 _IEN1_DMAIE	=	0x00b8
                    00C7    436 _IRCON_STIF	=	0x00c7
                    00C5    437 _IRCON_P0IF	=	0x00c5
                    00C4    438 _IRCON_T4IF	=	0x00c4
                    00C3    439 _IRCON_T3IF	=	0x00c3
                    00C2    440 _IRCON_T2IF	=	0x00c2
                    00C1    441 _IRCON_T1IF	=	0x00c1
                    00C0    442 _IRCON_DMAIF	=	0x00c0
                    00D0    443 _P	=	0x00d0
                    00D1    444 _F1	=	0x00d1
                    00D2    445 _OV	=	0x00d2
                    00D3    446 _RS0	=	0x00d3
                    00D4    447 _RS1	=	0x00d4
                    00D5    448 _F0	=	0x00d5
                    00D6    449 _AC	=	0x00d6
                    00D7    450 _CY	=	0x00d7
                    00EC    451 _IRCON2_WDTIF	=	0x00ec
                    00EB    452 _IRCON2_P1IF	=	0x00eb
                    00EA    453 _IRCON2_UTX1IF	=	0x00ea
                    00E9    454 _IRCON2_UTX0IF	=	0x00e9
                    00E8    455 _IRCON2_P2IF	=	0x00e8
                            456 ;--------------------------------------------------------
                            457 ; overlayable register banks
                            458 ;--------------------------------------------------------
                            459 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     460 	.ds 8
                            461 ;--------------------------------------------------------
                            462 ; internal ram data
                            463 ;--------------------------------------------------------
                            464 	.area DSEG    (DATA)
                            465 ;--------------------------------------------------------
                            466 ; overlayable items in internal ram 
                            467 ;--------------------------------------------------------
                            468 	.area OSEG    (OVR,DATA)
                            469 ;--------------------------------------------------------
                            470 ; indirectly addressable internal ram data
                            471 ;--------------------------------------------------------
                            472 	.area ISEG    (DATA)
                            473 ;--------------------------------------------------------
                            474 ; bit data
                            475 ;--------------------------------------------------------
                            476 	.area BSEG    (BIT)
                            477 ;--------------------------------------------------------
                            478 ; paged external ram data
                            479 ;--------------------------------------------------------
                            480 	.area PSEG    (PAG,XDATA)
                            481 ;--------------------------------------------------------
                            482 ; external ram data
                            483 ;--------------------------------------------------------
                            484 	.area XSEG    (XDATA)
                    DF02    485 _MDMCTRL0H	=	0xdf02
                    DF03    486 _MDMCTRL0L	=	0xdf03
                    DF04    487 _MDMCTRL1H	=	0xdf04
                    DF05    488 _MDMCTRL1L	=	0xdf05
                    DF06    489 _RSSIH	=	0xdf06
                    DF07    490 _RSSIL	=	0xdf07
                    DF08    491 _SYNCWORDH	=	0xdf08
                    DF09    492 _SYNCWORDL	=	0xdf09
                    DF0A    493 _TXCTRLH	=	0xdf0a
                    DF0B    494 _TXCTRLL	=	0xdf0b
                    DF0C    495 _RXCTRL0H	=	0xdf0c
                    DF0D    496 _RXCTRL0L	=	0xdf0d
                    DF0E    497 _RXCTRL1H	=	0xdf0e
                    DF0F    498 _RXCTRL1L	=	0xdf0f
                    DF10    499 _FSCTRLH	=	0xdf10
                    DF11    500 _FSCTRLL	=	0xdf11
                    DF12    501 _CSPX	=	0xdf12
                    DF13    502 _CSPY	=	0xdf13
                    DF14    503 _CSPZ	=	0xdf14
                    DF15    504 _CSPCTRL	=	0xdf15
                    DF16    505 _CSPT	=	0xdf16
                    DF17    506 _RFPWR	=	0xdf17
                    DF20    507 _FSMTCH	=	0xdf20
                    DF21    508 _FSMTCL	=	0xdf21
                    DF22    509 _MANANDH	=	0xdf22
                    DF23    510 _MANANDL	=	0xdf23
                    DF24    511 _MANORH	=	0xdf24
                    DF25    512 _MANORL	=	0xdf25
                    DF26    513 _AGCCTRLH	=	0xdf26
                    DF27    514 _AGCCTRLL	=	0xdf27
                    DF39    515 _FSMSTATE	=	0xdf39
                    DF3A    516 _ADCTSTH	=	0xdf3a
                    DF3B    517 _ADCTSTL	=	0xdf3b
                    DF3C    518 _DACTSTH	=	0xdf3c
                    DF3D    519 _DACTSTL	=	0xdf3d
                    DF43    520 _IEEE_ADDR0	=	0xdf43
                    DF44    521 _IEEE_ADDR1	=	0xdf44
                    DF45    522 _IEEE_ADDR2	=	0xdf45
                    DF46    523 _IEEE_ADDR3	=	0xdf46
                    DF47    524 _IEEE_ADDR4	=	0xdf47
                    DF48    525 _IEEE_ADDR5	=	0xdf48
                    DF49    526 _IEEE_ADDR6	=	0xdf49
                    DF4A    527 _IEEE_ADDR7	=	0xdf4a
                    DF4B    528 _PANIDH	=	0xdf4b
                    DF4C    529 _PANIDL	=	0xdf4c
                    DF4D    530 _SHORTADDRH	=	0xdf4d
                    DF4E    531 _SHORTADDRL	=	0xdf4e
                    DF4F    532 _IOCFG0	=	0xdf4f
                    DF50    533 _IOCFG1	=	0xdf50
                    DF51    534 _IOCFG2	=	0xdf51
                    DF52    535 _IOCFG3	=	0xdf52
                    DF53    536 _RXFIFOCNT	=	0xdf53
                    DF54    537 _FSMTC1	=	0xdf54
                    DF60    538 _CHVER	=	0xdf60
                    DF61    539 _CHIPID	=	0xdf61
                    DF62    540 _RFSTATUS	=	0xdf62
                    DFD9    541 _RFD_SHADOW	=	0xdfd9
                            542 ;--------------------------------------------------------
                            543 ; external initialized ram data
                            544 ;--------------------------------------------------------
                            545 	.area XISEG   (XDATA)
   F0F5                     546 _use_compress::
   F0F5                     547 	.ds 1
                            548 	.area HOME    (CODE)
                            549 	.area GSINIT0 (CODE)
                            550 	.area GSINIT1 (CODE)
                            551 	.area GSINIT2 (CODE)
                            552 	.area GSINIT3 (CODE)
                            553 	.area GSINIT4 (CODE)
                            554 	.area GSINIT5 (CODE)
                            555 	.area GSINIT  (CODE)
                            556 	.area GSFINAL (CODE)
                            557 	.area CSEG    (CODE)
                            558 ;--------------------------------------------------------
                            559 ; global & static initialisations
                            560 ;--------------------------------------------------------
                            561 	.area HOME    (CODE)
                            562 	.area GSINIT  (CODE)
                            563 	.area GSFINAL (CODE)
                            564 	.area GSINIT  (CODE)
                            565 ;--------------------------------------------------------
                            566 ; Home
                            567 ;--------------------------------------------------------
                            568 	.area HOME    (CODE)
                            569 	.area CSEG    (CODE)
                            570 ;--------------------------------------------------------
                            571 ; code
                            572 ;--------------------------------------------------------
                            573 	.area CSEG    (CODE)
                            574 ;------------------------------------------------------------
                            575 ;Allocation info for local variables in function 'cudp_init'
                            576 ;------------------------------------------------------------
                            577 ;buf                       Allocated to registers 
                            578 ;------------------------------------------------------------
                            579 ;	../../Common/modules/cUDP.c:104: portCHAR cudp_init( buffer_t *buf )
                            580 ;	-----------------------------------------
                            581 ;	 function cudp_init
                            582 ;	-----------------------------------------
   CDC3                     583 _cudp_init:
                    0002    584 	ar2 = 0x02
                    0003    585 	ar3 = 0x03
                    0004    586 	ar4 = 0x04
                    0005    587 	ar5 = 0x05
                    0006    588 	ar6 = 0x06
                    0007    589 	ar7 = 0x07
                    0000    590 	ar0 = 0x00
                    0001    591 	ar1 = 0x01
                            592 ;	../../Common/modules/cUDP.c:107: return pdTRUE;
                            593 ;	genRet
   CDC3 75 82 01            594 	mov	dpl,#0x01
                            595 ;	Peephole 300	removed redundant label 00101$
   CDC6 22                  596 	ret
                            597 ;------------------------------------------------------------
                            598 ;Allocation info for local variables in function 'cudp_compress_mode'
                            599 ;------------------------------------------------------------
                            600 ;mode                      Allocated to registers 
                            601 ;------------------------------------------------------------
                            602 ;	../../Common/modules/cUDP.c:110: void cudp_compress_mode( uint8_t mode )
                            603 ;	-----------------------------------------
                            604 ;	 function cudp_compress_mode
                            605 ;	-----------------------------------------
   CDC7                     606 _cudp_compress_mode:
                            607 ;	genReceive
   CDC7 E5 82               608 	mov	a,dpl
   CDC9 90 F0 F5            609 	mov	dptr,#_use_compress
   CDCC F0                  610 	movx	@dptr,a
                            611 ;	../../Common/modules/cUDP.c:112: use_compress = mode;
                            612 ;	Peephole 300	removed redundant label 00101$
   CDCD 22                  613 	ret
                            614 ;------------------------------------------------------------
                            615 ;Allocation info for local variables in function 'cudp_handle'
                            616 ;------------------------------------------------------------
                            617 ;buf                       Allocated to stack - offset 1
                            618 ;tmp_8                     Allocated to stack - offset 4
                            619 ;dest_length               Allocated to registers r2 
                            620 ;ind                       Allocated to stack - offset 5
                            621 ;hc_udp                    Allocated to stack - offset 6
                            622 ;i                         Allocated to stack - offset 7
                            623 ;header_length             Allocated to registers 
                            624 ;tmp                       Allocated to registers 
                            625 ;dptr                      Allocated to stack - offset 8
                            626 ;port                      Allocated to stack - offset 11
                            627 ;data_length               Allocated to stack - offset 13
                            628 ;length                    Allocated to stack - offset 15
                            629 ;portfield                 Allocated to stack - offset 17
                            630 ;sloc0                     Allocated to stack - offset 18
                            631 ;sloc1                     Allocated to stack - offset 20
                            632 ;sloc2                     Allocated to stack - offset 21
                            633 ;sloc3                     Allocated to stack - offset 23
                            634 ;sloc4                     Allocated to stack - offset 24
                            635 ;sloc5                     Allocated to stack - offset 25
                            636 ;sloc6                     Allocated to stack - offset 27
                            637 ;sloc7                     Allocated to stack - offset 30
                            638 ;sloc8                     Allocated to stack - offset 33
                            639 ;sloc9                     Allocated to stack - offset 36
                            640 ;sloc10                    Allocated to stack - offset 39
                            641 ;------------------------------------------------------------
                            642 ;	../../Common/modules/cUDP.c:122: portCHAR cudp_handle( buffer_t *buf )
                            643 ;	-----------------------------------------
                            644 ;	 function cudp_handle
                            645 ;	-----------------------------------------
   CDCE                     646 _cudp_handle:
   CDCE C0 10               647 	push	_bp
   CDD0 85 81 10            648 	mov	_bp,sp
                            649 ;     genReceive
   CDD3 C0 82               650 	push	dpl
   CDD5 C0 83               651 	push	dph
   CDD7 C0 F0               652 	push	b
   CDD9 E5 81               653 	mov	a,sp
   CDDB 24 29               654 	add	a,#0x29
   CDDD F5 81               655 	mov	sp,a
                            656 ;	../../Common/modules/cUDP.c:130: uint8_t portfield=0;
                            657 ;	genAssign
   CDDF E5 10               658 	mov	a,_bp
   CDE1 24 11               659 	add	a,#0x11
   CDE3 F8                  660 	mov	r0,a
   CDE4 76 00               661 	mov	@r0,#0x00
                            662 ;	../../Common/modules/cUDP.c:137: switch(buf->dir)
                            663 ;	genPlus
   CDE6 A8 10               664 	mov	r0,_bp
   CDE8 08                  665 	inc	r0
                            666 ;     genPlusIncr
   CDE9 74 1F               667 	mov	a,#0x1F
   CDEB 26                  668 	add	a,@r0
   CDEC FE                  669 	mov	r6,a
                            670 ;	Peephole 181	changed mov to clr
   CDED E4                  671 	clr	a
   CDEE 08                  672 	inc	r0
   CDEF 36                  673 	addc	a,@r0
   CDF0 FF                  674 	mov	r7,a
   CDF1 08                  675 	inc	r0
   CDF2 86 05               676 	mov	ar5,@r0
                            677 ;	genPointerGet
                            678 ;	genGenPointerGet
   CDF4 8E 82               679 	mov	dpl,r6
   CDF6 8F 83               680 	mov	dph,r7
   CDF8 8D F0               681 	mov	b,r5
   CDFA 12 E4 9F            682 	lcall	__gptrget
   CDFD FD                  683 	mov	r5,a
                            684 ;	genCmpEq
                            685 ;	gencjneshort
   CDFE BD 00 03            686 	cjne	r5,#0x00,00181$
   CE01 02 D2 D8            687 	ljmp	00115$
   CE04                     688 00181$:
                            689 ;	genCmpEq
                            690 ;	gencjneshort
   CE04 BD 01 02            691 	cjne	r5,#0x01,00182$
   CE07 80 03               692 	sjmp	00183$
   CE09                     693 00182$:
   CE09 02 DE 54            694 	ljmp	00147$
   CE0C                     695 00183$:
                            696 ;	../../Common/modules/cUDP.c:149: data_length = (buf->buf_end - buf->buf_ptr);
                            697 ;	genPlus
   CE0C A8 10               698 	mov	r0,_bp
   CE0E 08                  699 	inc	r0
                            700 ;     genPlusIncr
   CE0F 74 22               701 	mov	a,#0x22
   CE11 26                  702 	add	a,@r0
   CE12 FD                  703 	mov	r5,a
                            704 ;	Peephole 181	changed mov to clr
   CE13 E4                  705 	clr	a
   CE14 08                  706 	inc	r0
   CE15 36                  707 	addc	a,@r0
   CE16 FE                  708 	mov	r6,a
   CE17 08                  709 	inc	r0
   CE18 86 07               710 	mov	ar7,@r0
                            711 ;	genPointerGet
                            712 ;	genGenPointerGet
   CE1A 8D 82               713 	mov	dpl,r5
   CE1C 8E 83               714 	mov	dph,r6
   CE1E 8F F0               715 	mov	b,r7
   CE20 12 E4 9F            716 	lcall	__gptrget
   CE23 FD                  717 	mov	r5,a
   CE24 A3                  718 	inc	dptr
   CE25 12 E4 9F            719 	lcall	__gptrget
   CE28 FE                  720 	mov	r6,a
                            721 ;	genPlus
   CE29 A8 10               722 	mov	r0,_bp
   CE2B 08                  723 	inc	r0
                            724 ;     genPlusIncr
   CE2C 74 20               725 	mov	a,#0x20
   CE2E 26                  726 	add	a,@r0
   CE2F FF                  727 	mov	r7,a
                            728 ;	Peephole 181	changed mov to clr
   CE30 E4                  729 	clr	a
   CE31 08                  730 	inc	r0
   CE32 36                  731 	addc	a,@r0
   CE33 FA                  732 	mov	r2,a
   CE34 08                  733 	inc	r0
   CE35 86 03               734 	mov	ar3,@r0
                            735 ;	genPointerGet
                            736 ;	genGenPointerGet
   CE37 8F 82               737 	mov	dpl,r7
   CE39 8A 83               738 	mov	dph,r2
   CE3B 8B F0               739 	mov	b,r3
   CE3D 12 E4 9F            740 	lcall	__gptrget
   CE40 FF                  741 	mov	r7,a
   CE41 A3                  742 	inc	dptr
   CE42 12 E4 9F            743 	lcall	__gptrget
   CE45 FA                  744 	mov	r2,a
                            745 ;	genMinus
   CE46 ED                  746 	mov	a,r5
   CE47 C3                  747 	clr	c
                            748 ;	Peephole 236.l	used r7 instead of ar7
   CE48 9F                  749 	subb	a,r7
   CE49 FD                  750 	mov	r5,a
   CE4A EE                  751 	mov	a,r6
                            752 ;	Peephole 236.l	used r2 instead of ar2
   CE4B 9A                  753 	subb	a,r2
   CE4C FE                  754 	mov	r6,a
                            755 ;	genAssign
   CE4D E5 10               756 	mov	a,_bp
   CE4F 24 0D               757 	add	a,#0x0d
   CE51 F8                  758 	mov	r0,a
   CE52 A6 05               759 	mov	@r0,ar5
   CE54 08                  760 	inc	r0
   CE55 A6 06               761 	mov	@r0,ar6
                            762 ;	../../Common/modules/cUDP.c:153: data_length +=8;
                            763 ;	genPlus
   CE57 E5 10               764 	mov	a,_bp
   CE59 24 0D               765 	add	a,#0x0d
   CE5B F8                  766 	mov	r0,a
                            767 ;     genPlusIncr
   CE5C 74 08               768 	mov	a,#0x08
   CE5E 26                  769 	add	a,@r0
   CE5F F6                  770 	mov	@r0,a
                            771 ;	Peephole 181	changed mov to clr
   CE60 E4                  772 	clr	a
   CE61 08                  773 	inc	r0
   CE62 36                  774 	addc	a,@r0
   CE63 F6                  775 	mov	@r0,a
                            776 ;	../../Common/modules/cUDP.c:154: if(stack_buffer_headroom( buf,8)==pdFALSE)
                            777 ;	genIpush
   CE64 74 08               778 	mov	a,#0x08
   CE66 C0 E0               779 	push	acc
                            780 ;	Peephole 181	changed mov to clr
   CE68 E4                  781 	clr	a
   CE69 C0 E0               782 	push	acc
                            783 ;	genCall
   CE6B A8 10               784 	mov	r0,_bp
   CE6D 08                  785 	inc	r0
   CE6E 86 82               786 	mov	dpl,@r0
   CE70 08                  787 	inc	r0
   CE71 86 83               788 	mov	dph,@r0
   CE73 08                  789 	inc	r0
   CE74 86 F0               790 	mov	b,@r0
   CE76 12 63 20            791 	lcall	_stack_buffer_headroom
   CE79 AC 82               792 	mov	r4,dpl
   CE7B 15 81               793 	dec	sp
   CE7D 15 81               794 	dec	sp
                            795 ;	genIfx
   CE7F EC                  796 	mov	a,r4
                            797 ;	genIfxJump
                            798 ;	Peephole 108.b	removed ljmp by inverse jump logic
   CE80 70 14               799 	jnz	00103$
                            800 ;	Peephole 300	removed redundant label 00184$
                            801 ;	../../Common/modules/cUDP.c:156: stack_buffer_free(buf);
                            802 ;	genCall
   CE82 A8 10               803 	mov	r0,_bp
   CE84 08                  804 	inc	r0
   CE85 86 82               805 	mov	dpl,@r0
   CE87 08                  806 	inc	r0
   CE88 86 83               807 	mov	dph,@r0
   CE8A 08                  808 	inc	r0
   CE8B 86 F0               809 	mov	b,@r0
   CE8D 12 61 FA            810 	lcall	_stack_buffer_free
                            811 ;	../../Common/modules/cUDP.c:157: return pdTRUE;
                            812 ;	genRet
   CE90 75 82 01            813 	mov	dpl,#0x01
   CE93 02 DE 57            814 	ljmp	00152$
   CE96                     815 00103$:
                            816 ;	../../Common/modules/cUDP.c:160: buf->buf_ptr -= 8; /* HC2, SPORT,DPORT and Check Sum */
                            817 ;	genPlus
   CE96 A8 10               818 	mov	r0,_bp
   CE98 08                  819 	inc	r0
                            820 ;     genPlusIncr
   CE99 74 20               821 	mov	a,#0x20
   CE9B 26                  822 	add	a,@r0
   CE9C FC                  823 	mov	r4,a
                            824 ;	Peephole 181	changed mov to clr
   CE9D E4                  825 	clr	a
   CE9E 08                  826 	inc	r0
   CE9F 36                  827 	addc	a,@r0
   CEA0 FD                  828 	mov	r5,a
   CEA1 08                  829 	inc	r0
   CEA2 86 06               830 	mov	ar6,@r0
                            831 ;	genPointerGet
                            832 ;	genGenPointerGet
   CEA4 8C 82               833 	mov	dpl,r4
   CEA6 8D 83               834 	mov	dph,r5
   CEA8 8E F0               835 	mov	b,r6
   CEAA 12 E4 9F            836 	lcall	__gptrget
   CEAD FF                  837 	mov	r7,a
   CEAE A3                  838 	inc	dptr
   CEAF 12 E4 9F            839 	lcall	__gptrget
   CEB2 FA                  840 	mov	r2,a
                            841 ;	genMinus
   CEB3 E5 10               842 	mov	a,_bp
   CEB5 24 12               843 	add	a,#0x12
   CEB7 F8                  844 	mov	r0,a
   CEB8 EF                  845 	mov	a,r7
   CEB9 24 F8               846 	add	a,#0xf8
   CEBB F6                  847 	mov	@r0,a
   CEBC EA                  848 	mov	a,r2
   CEBD 34 FF               849 	addc	a,#0xff
   CEBF 08                  850 	inc	r0
   CEC0 F6                  851 	mov	@r0,a
                            852 ;	genPointerSet
                            853 ;	genGenPointerSet
   CEC1 8C 82               854 	mov	dpl,r4
   CEC3 8D 83               855 	mov	dph,r5
   CEC5 8E F0               856 	mov	b,r6
   CEC7 E5 10               857 	mov	a,_bp
   CEC9 24 12               858 	add	a,#0x12
   CECB F8                  859 	mov	r0,a
   CECC E6                  860 	mov	a,@r0
   CECD 12 DF B7            861 	lcall	__gptrput
   CED0 A3                  862 	inc	dptr
   CED1 08                  863 	inc	r0
   CED2 E6                  864 	mov	a,@r0
   CED3 12 DF B7            865 	lcall	__gptrput
                            866 ;	../../Common/modules/cUDP.c:162: dptr = buf->buf + buf->buf_ptr;
                            867 ;	genPlus
   CED6 A8 10               868 	mov	r0,_bp
   CED8 08                  869 	inc	r0
                            870 ;     genPlusIncr
   CED9 74 2C               871 	mov	a,#0x2C
   CEDB 26                  872 	add	a,@r0
   CEDC FB                  873 	mov	r3,a
                            874 ;	Peephole 181	changed mov to clr
   CEDD E4                  875 	clr	a
   CEDE 08                  876 	inc	r0
   CEDF 36                  877 	addc	a,@r0
   CEE0 FA                  878 	mov	r2,a
   CEE1 08                  879 	inc	r0
   CEE2 86 07               880 	mov	ar7,@r0
                            881 ;	genPlus
   CEE4 E5 10               882 	mov	a,_bp
   CEE6 24 12               883 	add	a,#0x12
   CEE8 F8                  884 	mov	r0,a
   CEE9 E6                  885 	mov	a,@r0
                            886 ;	Peephole 236.a	used r3 instead of ar3
   CEEA 2B                  887 	add	a,r3
   CEEB FB                  888 	mov	r3,a
   CEEC 08                  889 	inc	r0
   CEED E6                  890 	mov	a,@r0
                            891 ;	Peephole 236.b	used r2 instead of ar2
   CEEE 3A                  892 	addc	a,r2
   CEEF FA                  893 	mov	r2,a
                            894 ;	genAssign
   CEF0 E5 10               895 	mov	a,_bp
   CEF2 24 08               896 	add	a,#0x08
   CEF4 F8                  897 	mov	r0,a
   CEF5 A6 03               898 	mov	@r0,ar3
   CEF7 08                  899 	inc	r0
   CEF8 A6 02               900 	mov	@r0,ar2
   CEFA 08                  901 	inc	r0
   CEFB A6 07               902 	mov	@r0,ar7
                            903 ;	../../Common/modules/cUDP.c:164: *dptr++ = (buf->src_sa.port >> 8);		
                            904 ;	genPlus
   CEFD A8 10               905 	mov	r0,_bp
   CEFF 08                  906 	inc	r0
                            907 ;     genPlusIncr
   CF00 74 10               908 	mov	a,#0x10
   CF02 26                  909 	add	a,@r0
   CF03 FA                  910 	mov	r2,a
                            911 ;	Peephole 181	changed mov to clr
   CF04 E4                  912 	clr	a
   CF05 08                  913 	inc	r0
   CF06 36                  914 	addc	a,@r0
   CF07 FB                  915 	mov	r3,a
   CF08 08                  916 	inc	r0
   CF09 86 07               917 	mov	ar7,@r0
                            918 ;	genPlus
                            919 ;     genPlusIncr
   CF0B 74 0B               920 	mov	a,#0x0B
                            921 ;	Peephole 236.a	used r2 instead of ar2
   CF0D 2A                  922 	add	a,r2
   CF0E FA                  923 	mov	r2,a
                            924 ;	Peephole 181	changed mov to clr
   CF0F E4                  925 	clr	a
                            926 ;	Peephole 236.b	used r3 instead of ar3
   CF10 3B                  927 	addc	a,r3
   CF11 FB                  928 	mov	r3,a
                            929 ;	genPointerGet
                            930 ;	genGenPointerGet
   CF12 8A 82               931 	mov	dpl,r2
   CF14 8B 83               932 	mov	dph,r3
   CF16 8F F0               933 	mov	b,r7
   CF18 E5 10               934 	mov	a,_bp
   CF1A 24 15               935 	add	a,#0x15
   CF1C F8                  936 	mov	r0,a
   CF1D 12 E4 9F            937 	lcall	__gptrget
   CF20 F6                  938 	mov	@r0,a
   CF21 A3                  939 	inc	dptr
   CF22 12 E4 9F            940 	lcall	__gptrget
   CF25 08                  941 	inc	r0
   CF26 F6                  942 	mov	@r0,a
                            943 ;	genGetByte
   CF27 E5 10               944 	mov	a,_bp
   CF29 24 15               945 	add	a,#0x15
   CF2B F8                  946 	mov	r0,a
   CF2C E5 10               947 	mov	a,_bp
   CF2E 24 14               948 	add	a,#0x14
   CF30 F9                  949 	mov	r1,a
   CF31 08                  950 	inc	r0
   CF32 E6                  951 	mov	a,@r0
   CF33 F7                  952 	mov	@r1,a
                            953 ;	genPointerSet
                            954 ;	genGenPointerSet
   CF34 E5 10               955 	mov	a,_bp
   CF36 24 08               956 	add	a,#0x08
   CF38 F8                  957 	mov	r0,a
   CF39 86 82               958 	mov	dpl,@r0
   CF3B 08                  959 	inc	r0
   CF3C 86 83               960 	mov	dph,@r0
   CF3E 08                  961 	inc	r0
   CF3F 86 F0               962 	mov	b,@r0
   CF41 E5 10               963 	mov	a,_bp
   CF43 24 14               964 	add	a,#0x14
   CF45 F9                  965 	mov	r1,a
   CF46 E7                  966 	mov	a,@r1
   CF47 12 DF B7            967 	lcall	__gptrput
   CF4A A3                  968 	inc	dptr
   CF4B 18                  969 	dec	r0
   CF4C 18                  970 	dec	r0
   CF4D A6 82               971 	mov	@r0,dpl
   CF4F 08                  972 	inc	r0
   CF50 A6 83               973 	mov	@r0,dph
                            974 ;	../../Common/modules/cUDP.c:165: *dptr++ = (uint8_t) buf->src_sa.port;
                            975 ;	genCast
   CF52 E5 10               976 	mov	a,_bp
   CF54 24 15               977 	add	a,#0x15
   CF56 F8                  978 	mov	r0,a
   CF57 E5 10               979 	mov	a,_bp
   CF59 24 12               980 	add	a,#0x12
   CF5B F9                  981 	mov	r1,a
   CF5C E6                  982 	mov	a,@r0
   CF5D F7                  983 	mov	@r1,a
                            984 ;	genPointerSet
                            985 ;	genGenPointerSet
   CF5E E5 10               986 	mov	a,_bp
   CF60 24 08               987 	add	a,#0x08
   CF62 F8                  988 	mov	r0,a
   CF63 86 82               989 	mov	dpl,@r0
   CF65 08                  990 	inc	r0
   CF66 86 83               991 	mov	dph,@r0
   CF68 08                  992 	inc	r0
   CF69 86 F0               993 	mov	b,@r0
   CF6B E5 10               994 	mov	a,_bp
   CF6D 24 12               995 	add	a,#0x12
   CF6F F9                  996 	mov	r1,a
   CF70 E7                  997 	mov	a,@r1
   CF71 12 DF B7            998 	lcall	__gptrput
   CF74 A3                  999 	inc	dptr
   CF75 18                 1000 	dec	r0
   CF76 18                 1001 	dec	r0
   CF77 A6 82              1002 	mov	@r0,dpl
   CF79 08                 1003 	inc	r0
   CF7A A6 83              1004 	mov	@r0,dph
                           1005 ;	../../Common/modules/cUDP.c:166: *dptr++ = (buf->dst_sa.port >> 8);		
                           1006 ;	genPlus
   CF7C A8 10              1007 	mov	r0,_bp
   CF7E 08                 1008 	inc	r0
                           1009 ;     genPlusIncr
   CF7F 74 03              1010 	mov	a,#0x03
   CF81 26                 1011 	add	a,@r0
   CF82 FF                 1012 	mov	r7,a
                           1013 ;	Peephole 181	changed mov to clr
   CF83 E4                 1014 	clr	a
   CF84 08                 1015 	inc	r0
   CF85 36                 1016 	addc	a,@r0
   CF86 FA                 1017 	mov	r2,a
   CF87 08                 1018 	inc	r0
   CF88 86 03              1019 	mov	ar3,@r0
                           1020 ;	genPlus
                           1021 ;     genPlusIncr
   CF8A 74 0B              1022 	mov	a,#0x0B
                           1023 ;	Peephole 236.a	used r7 instead of ar7
   CF8C 2F                 1024 	add	a,r7
   CF8D FF                 1025 	mov	r7,a
                           1026 ;	Peephole 181	changed mov to clr
   CF8E E4                 1027 	clr	a
                           1028 ;	Peephole 236.b	used r2 instead of ar2
   CF8F 3A                 1029 	addc	a,r2
   CF90 FA                 1030 	mov	r2,a
                           1031 ;	genPointerGet
                           1032 ;	genGenPointerGet
   CF91 8F 82              1033 	mov	dpl,r7
   CF93 8A 83              1034 	mov	dph,r2
   CF95 8B F0              1035 	mov	b,r3
   CF97 E5 10              1036 	mov	a,_bp
   CF99 24 19              1037 	add	a,#0x19
   CF9B F8                 1038 	mov	r0,a
   CF9C 12 E4 9F           1039 	lcall	__gptrget
   CF9F F6                 1040 	mov	@r0,a
   CFA0 A3                 1041 	inc	dptr
   CFA1 12 E4 9F           1042 	lcall	__gptrget
   CFA4 08                 1043 	inc	r0
   CFA5 F6                 1044 	mov	@r0,a
                           1045 ;	genGetByte
   CFA6 E5 10              1046 	mov	a,_bp
   CFA8 24 19              1047 	add	a,#0x19
   CFAA F8                 1048 	mov	r0,a
   CFAB E5 10              1049 	mov	a,_bp
   CFAD 24 18              1050 	add	a,#0x18
   CFAF F9                 1051 	mov	r1,a
   CFB0 08                 1052 	inc	r0
   CFB1 E6                 1053 	mov	a,@r0
   CFB2 F7                 1054 	mov	@r1,a
                           1055 ;	genPointerSet
                           1056 ;	genGenPointerSet
   CFB3 E5 10              1057 	mov	a,_bp
   CFB5 24 08              1058 	add	a,#0x08
   CFB7 F8                 1059 	mov	r0,a
   CFB8 86 82              1060 	mov	dpl,@r0
   CFBA 08                 1061 	inc	r0
   CFBB 86 83              1062 	mov	dph,@r0
   CFBD 08                 1063 	inc	r0
   CFBE 86 F0              1064 	mov	b,@r0
   CFC0 E5 10              1065 	mov	a,_bp
   CFC2 24 18              1066 	add	a,#0x18
   CFC4 F9                 1067 	mov	r1,a
   CFC5 E7                 1068 	mov	a,@r1
   CFC6 12 DF B7           1069 	lcall	__gptrput
   CFC9 A3                 1070 	inc	dptr
   CFCA 18                 1071 	dec	r0
   CFCB 18                 1072 	dec	r0
   CFCC A6 82              1073 	mov	@r0,dpl
   CFCE 08                 1074 	inc	r0
   CFCF A6 83              1075 	mov	@r0,dph
                           1076 ;	../../Common/modules/cUDP.c:167: *dptr++ = (uint8_t)buf->dst_sa.port;
                           1077 ;	genCast
   CFD1 E5 10              1078 	mov	a,_bp
   CFD3 24 19              1079 	add	a,#0x19
   CFD5 F8                 1080 	mov	r0,a
   CFD6 E5 10              1081 	mov	a,_bp
   CFD8 24 17              1082 	add	a,#0x17
   CFDA F9                 1083 	mov	r1,a
   CFDB E6                 1084 	mov	a,@r0
   CFDC F7                 1085 	mov	@r1,a
                           1086 ;	genPointerSet
                           1087 ;	genGenPointerSet
   CFDD E5 10              1088 	mov	a,_bp
   CFDF 24 08              1089 	add	a,#0x08
   CFE1 F8                 1090 	mov	r0,a
   CFE2 86 82              1091 	mov	dpl,@r0
   CFE4 08                 1092 	inc	r0
   CFE5 86 83              1093 	mov	dph,@r0
   CFE7 08                 1094 	inc	r0
   CFE8 86 F0              1095 	mov	b,@r0
   CFEA E5 10              1096 	mov	a,_bp
   CFEC 24 17              1097 	add	a,#0x17
   CFEE F9                 1098 	mov	r1,a
   CFEF E7                 1099 	mov	a,@r1
   CFF0 12 DF B7           1100 	lcall	__gptrput
   CFF3 A3                 1101 	inc	dptr
   CFF4 18                 1102 	dec	r0
   CFF5 18                 1103 	dec	r0
   CFF6 A6 82              1104 	mov	@r0,dpl
   CFF8 08                 1105 	inc	r0
   CFF9 A6 83              1106 	mov	@r0,dph
                           1107 ;	../../Common/modules/cUDP.c:168: *dptr++ = (data_length >> 8);	
                           1108 ;	genGetByte
   CFFB E5 10              1109 	mov	a,_bp
   CFFD 24 0D              1110 	add	a,#0x0d
                           1111 ;	Peephole 185	changed order of increment (acc incremented also!)
   CFFF 04                 1112 	inc	a
   D000 F8                 1113 	mov	r0,a
   D001 86 07              1114 	mov	ar7,@r0
                           1115 ;	genPointerSet
                           1116 ;	genGenPointerSet
   D003 E5 10              1117 	mov	a,_bp
   D005 24 08              1118 	add	a,#0x08
   D007 F8                 1119 	mov	r0,a
   D008 86 82              1120 	mov	dpl,@r0
   D00A 08                 1121 	inc	r0
   D00B 86 83              1122 	mov	dph,@r0
   D00D 08                 1123 	inc	r0
   D00E 86 F0              1124 	mov	b,@r0
   D010 EF                 1125 	mov	a,r7
   D011 12 DF B7           1126 	lcall	__gptrput
   D014 A3                 1127 	inc	dptr
   D015 18                 1128 	dec	r0
   D016 18                 1129 	dec	r0
   D017 A6 82              1130 	mov	@r0,dpl
   D019 08                 1131 	inc	r0
   D01A A6 83              1132 	mov	@r0,dph
                           1133 ;	../../Common/modules/cUDP.c:169: *dptr++ = (uint8_t) data_length;	
                           1134 ;	genCast
   D01C E5 10              1135 	mov	a,_bp
   D01E 24 0D              1136 	add	a,#0x0d
   D020 F8                 1137 	mov	r0,a
   D021 86 07              1138 	mov	ar7,@r0
                           1139 ;	genPointerSet
                           1140 ;	genGenPointerSet
   D023 E5 10              1141 	mov	a,_bp
   D025 24 08              1142 	add	a,#0x08
   D027 F8                 1143 	mov	r0,a
   D028 86 82              1144 	mov	dpl,@r0
   D02A 08                 1145 	inc	r0
   D02B 86 83              1146 	mov	dph,@r0
   D02D 08                 1147 	inc	r0
   D02E 86 F0              1148 	mov	b,@r0
   D030 EF                 1149 	mov	a,r7
   D031 12 DF B7           1150 	lcall	__gptrput
   D034 A3                 1151 	inc	dptr
   D035 18                 1152 	dec	r0
   D036 18                 1153 	dec	r0
   D037 A6 82              1154 	mov	@r0,dpl
   D039 08                 1155 	inc	r0
   D03A A6 83              1156 	mov	@r0,dph
                           1157 ;	../../Common/modules/cUDP.c:170: *dptr++ = 0x00;
                           1158 ;	genPointerSet
                           1159 ;	genGenPointerSet
   D03C E5 10              1160 	mov	a,_bp
   D03E 24 08              1161 	add	a,#0x08
   D040 F8                 1162 	mov	r0,a
   D041 86 82              1163 	mov	dpl,@r0
   D043 08                 1164 	inc	r0
   D044 86 83              1165 	mov	dph,@r0
   D046 08                 1166 	inc	r0
   D047 86 F0              1167 	mov	b,@r0
                           1168 ;	Peephole 181	changed mov to clr
   D049 E4                 1169 	clr	a
   D04A 12 DF B7           1170 	lcall	__gptrput
   D04D A3                 1171 	inc	dptr
   D04E 18                 1172 	dec	r0
   D04F 18                 1173 	dec	r0
   D050 A6 82              1174 	mov	@r0,dpl
   D052 08                 1175 	inc	r0
   D053 A6 83              1176 	mov	@r0,dph
                           1177 ;	../../Common/modules/cUDP.c:171: *dptr++ = 0x00;
                           1178 ;	genPointerSet
                           1179 ;	genGenPointerSet
   D055 E5 10              1180 	mov	a,_bp
   D057 24 08              1181 	add	a,#0x08
   D059 F8                 1182 	mov	r0,a
   D05A 86 82              1183 	mov	dpl,@r0
   D05C 08                 1184 	inc	r0
   D05D 86 83              1185 	mov	dph,@r0
   D05F 08                 1186 	inc	r0
   D060 86 F0              1187 	mov	b,@r0
                           1188 ;	Peephole 181	changed mov to clr
   D062 E4                 1189 	clr	a
   D063 12 DF B7           1190 	lcall	__gptrput
   D066 A3                 1191 	inc	dptr
   D067 18                 1192 	dec	r0
   D068 18                 1193 	dec	r0
   D069 A6 82              1194 	mov	@r0,dpl
   D06B 08                 1195 	inc	r0
   D06C A6 83              1196 	mov	@r0,dph
                           1197 ;	../../Common/modules/cUDP.c:175: if( use_compress==0)
                           1198 ;	genAssign
   D06E 90 F0 F5           1199 	mov	dptr,#_use_compress
   D071 E0                 1200 	movx	a,@dptr
                           1201 ;	genIfx
   D072 FF                 1202 	mov	r7,a
                           1203 ;	Peephole 105	removed redundant mov
                           1204 ;	genIfxJump
                           1205 ;	Peephole 108.b	removed ljmp by inverse jump logic
   D073 70 4B              1206 	jnz	00105$
                           1207 ;	Peephole 300	removed redundant label 00185$
                           1208 ;	../../Common/modules/cUDP.c:177: dptr = buf->buf + (buf->buf_ptr + 6);
                           1209 ;	genIpush
   D075 C0 07              1210 	push	ar7
                           1211 ;	genPlus
   D077 A8 10              1212 	mov	r0,_bp
   D079 08                 1213 	inc	r0
   D07A E5 10              1214 	mov	a,_bp
   D07C 24 1B              1215 	add	a,#0x1b
   D07E F9                 1216 	mov	r1,a
                           1217 ;     genPlusIncr
   D07F 74 2C              1218 	mov	a,#0x2C
   D081 26                 1219 	add	a,@r0
   D082 F7                 1220 	mov	@r1,a
                           1221 ;	Peephole 181	changed mov to clr
   D083 E4                 1222 	clr	a
   D084 08                 1223 	inc	r0
   D085 36                 1224 	addc	a,@r0
   D086 09                 1225 	inc	r1
   D087 F7                 1226 	mov	@r1,a
   D088 08                 1227 	inc	r0
   D089 09                 1228 	inc	r1
   D08A E6                 1229 	mov	a,@r0
   D08B F7                 1230 	mov	@r1,a
                           1231 ;	genPointerGet
                           1232 ;	genGenPointerGet
   D08C 8C 82              1233 	mov	dpl,r4
   D08E 8D 83              1234 	mov	dph,r5
   D090 8E F0              1235 	mov	b,r6
   D092 12 E4 9F           1236 	lcall	__gptrget
   D095 FA                 1237 	mov	r2,a
   D096 A3                 1238 	inc	dptr
   D097 12 E4 9F           1239 	lcall	__gptrget
   D09A FB                 1240 	mov	r3,a
                           1241 ;	genPlus
                           1242 ;     genPlusIncr
   D09B 74 06              1243 	mov	a,#0x06
                           1244 ;	Peephole 236.a	used r2 instead of ar2
   D09D 2A                 1245 	add	a,r2
   D09E FA                 1246 	mov	r2,a
                           1247 ;	Peephole 181	changed mov to clr
   D09F E4                 1248 	clr	a
                           1249 ;	Peephole 236.b	used r3 instead of ar3
   D0A0 3B                 1250 	addc	a,r3
   D0A1 FB                 1251 	mov	r3,a
                           1252 ;	genPlus
   D0A2 E5 10              1253 	mov	a,_bp
   D0A4 24 1B              1254 	add	a,#0x1b
   D0A6 F8                 1255 	mov	r0,a
                           1256 ;	Peephole 236.g	used r2 instead of ar2
   D0A7 EA                 1257 	mov	a,r2
   D0A8 26                 1258 	add	a,@r0
   D0A9 FA                 1259 	mov	r2,a
                           1260 ;	Peephole 236.g	used r3 instead of ar3
   D0AA EB                 1261 	mov	a,r3
   D0AB 08                 1262 	inc	r0
   D0AC 36                 1263 	addc	a,@r0
   D0AD FB                 1264 	mov	r3,a
   D0AE 08                 1265 	inc	r0
   D0AF 86 07              1266 	mov	ar7,@r0
                           1267 ;	genAssign
   D0B1 E5 10              1268 	mov	a,_bp
   D0B3 24 08              1269 	add	a,#0x08
   D0B5 F8                 1270 	mov	r0,a
   D0B6 A6 02              1271 	mov	@r0,ar2
   D0B8 08                 1272 	inc	r0
   D0B9 A6 03              1273 	mov	@r0,ar3
   D0BB 08                 1274 	inc	r0
   D0BC A6 07              1275 	mov	@r0,ar7
                           1276 ;	../../Common/modules/cUDP.c:471: return pdTRUE;
                           1277 ;	genIpop
   D0BE D0 07              1278 	pop	ar7
                           1279 ;	../../Common/modules/cUDP.c:177: dptr = buf->buf + (buf->buf_ptr + 6);
   D0C0                    1280 00105$:
                           1281 ;	../../Common/modules/cUDP.c:179: if ( use_compress )
                           1282 ;	genIfx
   D0C0 EF                 1283 	mov	a,r7
                           1284 ;	genIfxJump
   D0C1 70 03              1285 	jnz	00186$
   D0C3 02 D2 54           1286 	ljmp	00114$
   D0C6                    1287 00186$:
                           1288 ;	../../Common/modules/cUDP.c:181: portfield = 0;
                           1289 ;	genAssign
   D0C6 E5 10              1290 	mov	a,_bp
   D0C8 24 11              1291 	add	a,#0x11
   D0CA F8                 1292 	mov	r0,a
   D0CB 76 00              1293 	mov	@r0,#0x00
                           1294 ;	../../Common/modules/cUDP.c:183: hc_udp=LENGTH_COMPRESSED;
                           1295 ;	genAssign
   D0CD E5 10              1296 	mov	a,_bp
   D0CF 24 06              1297 	add	a,#0x06
   D0D1 F8                 1298 	mov	r0,a
   D0D2 76 04              1299 	mov	@r0,#0x04
                           1300 ;	../../Common/modules/cUDP.c:184: if(buf->src_sa.port > HC2_PORT_ENCODE && buf->dst_sa.port > HC2_PORT_ENCODE)
                           1301 ;	genCmpGt
   D0D4 E5 10              1302 	mov	a,_bp
   D0D6 24 15              1303 	add	a,#0x15
   D0D8 F8                 1304 	mov	r0,a
                           1305 ;	genCmp
   D0D9 C3                 1306 	clr	c
   D0DA 74 AF              1307 	mov	a,#0xAF
   D0DC 96                 1308 	subb	a,@r0
   D0DD 74 F0              1309 	mov	a,#0xF0
   D0DF 08                 1310 	inc	r0
   D0E0 96                 1311 	subb	a,@r0
                           1312 ;	genIfxJump
                           1313 ;	Peephole 108.a	removed ljmp by inverse jump logic
   D0E1 50 42              1314 	jnc	00107$
                           1315 ;	Peephole 300	removed redundant label 00187$
                           1316 ;	genCmpGt
   D0E3 E5 10              1317 	mov	a,_bp
   D0E5 24 19              1318 	add	a,#0x19
   D0E7 F8                 1319 	mov	r0,a
                           1320 ;	genCmp
   D0E8 C3                 1321 	clr	c
   D0E9 74 AF              1322 	mov	a,#0xAF
   D0EB 96                 1323 	subb	a,@r0
   D0EC 74 F0              1324 	mov	a,#0xF0
   D0EE 08                 1325 	inc	r0
   D0EF 96                 1326 	subb	a,@r0
                           1327 ;	genIfxJump
                           1328 ;	Peephole 108.a	removed ljmp by inverse jump logic
   D0F0 50 33              1329 	jnc	00107$
                           1330 ;	Peephole 300	removed redundant label 00188$
                           1331 ;	../../Common/modules/cUDP.c:187: portfield = (buf->src_sa.port - HC2_ENCODE_P_VALUE);
                           1332 ;	genMinus
   D0F2 E5 10              1333 	mov	a,_bp
   D0F4 24 12              1334 	add	a,#0x12
   D0F6 F8                 1335 	mov	r0,a
   D0F7 E5 10              1336 	mov	a,_bp
   D0F9 24 11              1337 	add	a,#0x11
   D0FB F9                 1338 	mov	r1,a
   D0FC E6                 1339 	mov	a,@r0
   D0FD 24 50              1340 	add	a,#0x50
   D0FF F7                 1341 	mov	@r1,a
                           1342 ;	../../Common/modules/cUDP.c:189: hc_udp |= D_PORT_COMPRESSED;
                           1343 ;	genAssign
   D100 E5 10              1344 	mov	a,_bp
   D102 24 06              1345 	add	a,#0x06
   D104 F8                 1346 	mov	r0,a
   D105 76 07              1347 	mov	@r0,#0x07
                           1348 ;	../../Common/modules/cUDP.c:190: portfield |= ((buf->dst_sa.port - HC2_ENCODE_P_VALUE) << 4);
                           1349 ;	genMinus
   D107 E5 10              1350 	mov	a,_bp
   D109 24 17              1351 	add	a,#0x17
   D10B F8                 1352 	mov	r0,a
   D10C E6                 1353 	mov	a,@r0
   D10D 24 50              1354 	add	a,#0x50
                           1355 ;	genLeftShift
                           1356 ;	genLeftShiftLiteral
                           1357 ;	genlshOne
   D10F FB                 1358 	mov	r3,a
                           1359 ;	Peephole 105	removed redundant mov
   D110 C4                 1360 	swap	a
   D111 54 F0              1361 	anl	a,#0xf0
   D113 FB                 1362 	mov	r3,a
                           1363 ;	genOr
   D114 E5 10              1364 	mov	a,_bp
   D116 24 11              1365 	add	a,#0x11
   D118 F8                 1366 	mov	r0,a
   D119 EB                 1367 	mov	a,r3
   D11A 46                 1368 	orl	a,@r0
   D11B F6                 1369 	mov	@r0,a
                           1370 ;	../../Common/modules/cUDP.c:191: tmp_8++;
                           1371 ;	genAssign
   D11C E5 10              1372 	mov	a,_bp
   D11E 24 04              1373 	add	a,#0x04
   D120 F8                 1374 	mov	r0,a
   D121 76 03              1375 	mov	@r0,#0x03
                           1376 ;	Peephole 112.b	changed ljmp to sjmp
   D123 80 07              1377 	sjmp	00108$
   D125                    1378 00107$:
                           1379 ;	../../Common/modules/cUDP.c:195: tmp_8 +=4;
                           1380 ;	genAssign
   D125 E5 10              1381 	mov	a,_bp
   D127 24 04              1382 	add	a,#0x04
   D129 F8                 1383 	mov	r0,a
   D12A 76 06              1384 	mov	@r0,#0x06
   D12C                    1385 00108$:
                           1386 ;	../../Common/modules/cUDP.c:197: buf->buf_ptr +=(8 - tmp_8);
                           1387 ;	genPointerGet
                           1388 ;	genGenPointerGet
   D12C 8C 82              1389 	mov	dpl,r4
   D12E 8D 83              1390 	mov	dph,r5
   D130 8E F0              1391 	mov	b,r6
   D132 E5 10              1392 	mov	a,_bp
   D134 24 1B              1393 	add	a,#0x1b
   D136 F8                 1394 	mov	r0,a
   D137 12 E4 9F           1395 	lcall	__gptrget
   D13A F6                 1396 	mov	@r0,a
   D13B A3                 1397 	inc	dptr
   D13C 12 E4 9F           1398 	lcall	__gptrget
   D13F 08                 1399 	inc	r0
   D140 F6                 1400 	mov	@r0,a
                           1401 ;	genCast
   D141 E5 10              1402 	mov	a,_bp
   D143 24 04              1403 	add	a,#0x04
   D145 F8                 1404 	mov	r0,a
   D146 86 03              1405 	mov	ar3,@r0
   D148 7A 00              1406 	mov	r2,#0x00
                           1407 ;	genMinus
   D14A 74 08              1408 	mov	a,#0x08
   D14C C3                 1409 	clr	c
                           1410 ;	Peephole 236.l	used r3 instead of ar3
   D14D 9B                 1411 	subb	a,r3
   D14E FB                 1412 	mov	r3,a
                           1413 ;	Peephole 181	changed mov to clr
   D14F E4                 1414 	clr	a
                           1415 ;	Peephole 236.l	used r2 instead of ar2
   D150 9A                 1416 	subb	a,r2
   D151 FA                 1417 	mov	r2,a
                           1418 ;	genPlus
   D152 E5 10              1419 	mov	a,_bp
   D154 24 1B              1420 	add	a,#0x1b
   D156 F8                 1421 	mov	r0,a
                           1422 ;	Peephole 236.g	used r3 instead of ar3
   D157 EB                 1423 	mov	a,r3
   D158 26                 1424 	add	a,@r0
   D159 FB                 1425 	mov	r3,a
                           1426 ;	Peephole 236.g	used r2 instead of ar2
   D15A EA                 1427 	mov	a,r2
   D15B 08                 1428 	inc	r0
   D15C 36                 1429 	addc	a,@r0
   D15D FA                 1430 	mov	r2,a
                           1431 ;	genPointerSet
                           1432 ;	genGenPointerSet
   D15E 8C 82              1433 	mov	dpl,r4
   D160 8D 83              1434 	mov	dph,r5
   D162 8E F0              1435 	mov	b,r6
   D164 EB                 1436 	mov	a,r3
   D165 12 DF B7           1437 	lcall	__gptrput
   D168 A3                 1438 	inc	dptr
   D169 EA                 1439 	mov	a,r2
   D16A 12 DF B7           1440 	lcall	__gptrput
                           1441 ;	../../Common/modules/cUDP.c:199: dptr = buf->buf + buf->buf_ptr;
                           1442 ;	genPlus
   D16D A8 10              1443 	mov	r0,_bp
   D16F 08                 1444 	inc	r0
                           1445 ;     genPlusIncr
   D170 74 2C              1446 	mov	a,#0x2C
   D172 26                 1447 	add	a,@r0
   D173 FC                 1448 	mov	r4,a
                           1449 ;	Peephole 181	changed mov to clr
   D174 E4                 1450 	clr	a
   D175 08                 1451 	inc	r0
   D176 36                 1452 	addc	a,@r0
   D177 FD                 1453 	mov	r5,a
   D178 08                 1454 	inc	r0
   D179 86 06              1455 	mov	ar6,@r0
                           1456 ;	genPlus
                           1457 ;	Peephole 236.g	used r3 instead of ar3
   D17B EB                 1458 	mov	a,r3
                           1459 ;	Peephole 236.a	used r4 instead of ar4
   D17C 2C                 1460 	add	a,r4
   D17D FB                 1461 	mov	r3,a
                           1462 ;	Peephole 236.g	used r2 instead of ar2
   D17E EA                 1463 	mov	a,r2
                           1464 ;	Peephole 236.b	used r5 instead of ar5
   D17F 3D                 1465 	addc	a,r5
   D180 FA                 1466 	mov	r2,a
   D181 8E 07              1467 	mov	ar7,r6
                           1468 ;	genAssign
   D183 E5 10              1469 	mov	a,_bp
   D185 24 08              1470 	add	a,#0x08
   D187 F8                 1471 	mov	r0,a
   D188 A6 03              1472 	mov	@r0,ar3
   D18A 08                 1473 	inc	r0
   D18B A6 02              1474 	mov	@r0,ar2
   D18D 08                 1475 	inc	r0
   D18E A6 07              1476 	mov	@r0,ar7
                           1477 ;	../../Common/modules/cUDP.c:200: buf->options.lowpan_compressed = hc_udp;
                           1478 ;	genPlus
   D190 A8 10              1479 	mov	r0,_bp
   D192 08                 1480 	inc	r0
                           1481 ;     genPlusIncr
   D193 74 26              1482 	mov	a,#0x26
   D195 26                 1483 	add	a,@r0
   D196 FA                 1484 	mov	r2,a
                           1485 ;	Peephole 181	changed mov to clr
   D197 E4                 1486 	clr	a
   D198 08                 1487 	inc	r0
   D199 36                 1488 	addc	a,@r0
   D19A FB                 1489 	mov	r3,a
   D19B 08                 1490 	inc	r0
   D19C 86 04              1491 	mov	ar4,@r0
                           1492 ;	genPlus
                           1493 ;     genPlusIncr
   D19E 74 05              1494 	mov	a,#0x05
                           1495 ;	Peephole 236.a	used r2 instead of ar2
   D1A0 2A                 1496 	add	a,r2
   D1A1 FA                 1497 	mov	r2,a
                           1498 ;	Peephole 181	changed mov to clr
   D1A2 E4                 1499 	clr	a
                           1500 ;	Peephole 236.b	used r3 instead of ar3
   D1A3 3B                 1501 	addc	a,r3
   D1A4 FB                 1502 	mov	r3,a
                           1503 ;	genPointerSet
                           1504 ;	genGenPointerSet
   D1A5 8A 82              1505 	mov	dpl,r2
   D1A7 8B 83              1506 	mov	dph,r3
   D1A9 8C F0              1507 	mov	b,r4
   D1AB E5 10              1508 	mov	a,_bp
   D1AD 24 06              1509 	add	a,#0x06
   D1AF F8                 1510 	mov	r0,a
   D1B0 E6                 1511 	mov	a,@r0
   D1B1 12 DF B7           1512 	lcall	__gptrput
                           1513 ;	../../Common/modules/cUDP.c:201: if(tmp_8 == 3)
                           1514 ;	genCmpEq
   D1B4 E5 10              1515 	mov	a,_bp
   D1B6 24 04              1516 	add	a,#0x04
   D1B8 F8                 1517 	mov	r0,a
                           1518 ;	gencjneshort
                           1519 ;	Peephole 112.b	changed ljmp to sjmp
                           1520 ;	Peephole 198.b	optimized misc jump sequence
   D1B9 B6 03 20           1521 	cjne	@r0,#0x03,00111$
                           1522 ;	Peephole 200.b	removed redundant sjmp
                           1523 ;	Peephole 300	removed redundant label 00189$
                           1524 ;	Peephole 300	removed redundant label 00190$
                           1525 ;	../../Common/modules/cUDP.c:203: *dptr++ = portfield;	/* Encoded Source and Destination-port*/
                           1526 ;	genPointerSet
                           1527 ;	genGenPointerSet
   D1BC E5 10              1528 	mov	a,_bp
   D1BE 24 08              1529 	add	a,#0x08
   D1C0 F8                 1530 	mov	r0,a
   D1C1 86 82              1531 	mov	dpl,@r0
   D1C3 08                 1532 	inc	r0
   D1C4 86 83              1533 	mov	dph,@r0
   D1C6 08                 1534 	inc	r0
   D1C7 86 F0              1535 	mov	b,@r0
   D1C9 E5 10              1536 	mov	a,_bp
   D1CB 24 11              1537 	add	a,#0x11
   D1CD F9                 1538 	mov	r1,a
   D1CE E7                 1539 	mov	a,@r1
   D1CF 12 DF B7           1540 	lcall	__gptrput
   D1D2 A3                 1541 	inc	dptr
   D1D3 18                 1542 	dec	r0
   D1D4 18                 1543 	dec	r0
   D1D5 A6 82              1544 	mov	@r0,dpl
   D1D7 08                 1545 	inc	r0
   D1D8 A6 83              1546 	mov	@r0,dph
                           1547 ;	Peephole 112.b	changed ljmp to sjmp
   D1DA 80 78              1548 	sjmp	00114$
   D1DC                    1549 00111$:
                           1550 ;	../../Common/modules/cUDP.c:207: *dptr++ = (buf->src_sa.port >> 8);		
                           1551 ;	genPointerSet
                           1552 ;	genGenPointerSet
   D1DC E5 10              1553 	mov	a,_bp
   D1DE 24 08              1554 	add	a,#0x08
   D1E0 F8                 1555 	mov	r0,a
   D1E1 86 82              1556 	mov	dpl,@r0
   D1E3 08                 1557 	inc	r0
   D1E4 86 83              1558 	mov	dph,@r0
   D1E6 08                 1559 	inc	r0
   D1E7 86 F0              1560 	mov	b,@r0
   D1E9 E5 10              1561 	mov	a,_bp
   D1EB 24 14              1562 	add	a,#0x14
   D1ED F9                 1563 	mov	r1,a
   D1EE E7                 1564 	mov	a,@r1
   D1EF 12 DF B7           1565 	lcall	__gptrput
   D1F2 A3                 1566 	inc	dptr
   D1F3 18                 1567 	dec	r0
   D1F4 18                 1568 	dec	r0
   D1F5 A6 82              1569 	mov	@r0,dpl
   D1F7 08                 1570 	inc	r0
   D1F8 A6 83              1571 	mov	@r0,dph
                           1572 ;	../../Common/modules/cUDP.c:208: *dptr++ = (uint8_t) buf->src_sa.port;
                           1573 ;	genPointerSet
                           1574 ;	genGenPointerSet
   D1FA E5 10              1575 	mov	a,_bp
   D1FC 24 08              1576 	add	a,#0x08
   D1FE F8                 1577 	mov	r0,a
   D1FF 86 82              1578 	mov	dpl,@r0
   D201 08                 1579 	inc	r0
   D202 86 83              1580 	mov	dph,@r0
   D204 08                 1581 	inc	r0
   D205 86 F0              1582 	mov	b,@r0
   D207 E5 10              1583 	mov	a,_bp
   D209 24 12              1584 	add	a,#0x12
   D20B F9                 1585 	mov	r1,a
   D20C E7                 1586 	mov	a,@r1
   D20D 12 DF B7           1587 	lcall	__gptrput
   D210 A3                 1588 	inc	dptr
   D211 18                 1589 	dec	r0
   D212 18                 1590 	dec	r0
   D213 A6 82              1591 	mov	@r0,dpl
   D215 08                 1592 	inc	r0
   D216 A6 83              1593 	mov	@r0,dph
                           1594 ;	../../Common/modules/cUDP.c:209: *dptr++ = (buf->dst_sa.port >> 8);		
                           1595 ;	genPointerSet
                           1596 ;	genGenPointerSet
   D218 E5 10              1597 	mov	a,_bp
   D21A 24 08              1598 	add	a,#0x08
   D21C F8                 1599 	mov	r0,a
   D21D 86 82              1600 	mov	dpl,@r0
   D21F 08                 1601 	inc	r0
   D220 86 83              1602 	mov	dph,@r0
   D222 08                 1603 	inc	r0
   D223 86 F0              1604 	mov	b,@r0
   D225 E5 10              1605 	mov	a,_bp
   D227 24 18              1606 	add	a,#0x18
   D229 F9                 1607 	mov	r1,a
   D22A E7                 1608 	mov	a,@r1
   D22B 12 DF B7           1609 	lcall	__gptrput
   D22E A3                 1610 	inc	dptr
   D22F 18                 1611 	dec	r0
   D230 18                 1612 	dec	r0
   D231 A6 82              1613 	mov	@r0,dpl
   D233 08                 1614 	inc	r0
   D234 A6 83              1615 	mov	@r0,dph
                           1616 ;	../../Common/modules/cUDP.c:210: *dptr++ = (uint8_t)buf->dst_sa.port;
                           1617 ;	genPointerSet
                           1618 ;	genGenPointerSet
   D236 E5 10              1619 	mov	a,_bp
   D238 24 08              1620 	add	a,#0x08
   D23A F8                 1621 	mov	r0,a
   D23B 86 82              1622 	mov	dpl,@r0
   D23D 08                 1623 	inc	r0
   D23E 86 83              1624 	mov	dph,@r0
   D240 08                 1625 	inc	r0
   D241 86 F0              1626 	mov	b,@r0
   D243 E5 10              1627 	mov	a,_bp
   D245 24 17              1628 	add	a,#0x17
   D247 F9                 1629 	mov	r1,a
   D248 E7                 1630 	mov	a,@r1
   D249 12 DF B7           1631 	lcall	__gptrput
   D24C A3                 1632 	inc	dptr
   D24D 18                 1633 	dec	r0
   D24E 18                 1634 	dec	r0
   D24F A6 82              1635 	mov	@r0,dpl
   D251 08                 1636 	inc	r0
   D252 A6 83              1637 	mov	@r0,dph
   D254                    1638 00114$:
                           1639 ;	../../Common/modules/cUDP.c:218: *dptr++ = 0;		
                           1640 ;	genPointerSet
                           1641 ;	genGenPointerSet
   D254 E5 10              1642 	mov	a,_bp
   D256 24 08              1643 	add	a,#0x08
   D258 F8                 1644 	mov	r0,a
   D259 86 82              1645 	mov	dpl,@r0
   D25B 08                 1646 	inc	r0
   D25C 86 83              1647 	mov	dph,@r0
   D25E 08                 1648 	inc	r0
   D25F 86 F0              1649 	mov	b,@r0
                           1650 ;	Peephole 181	changed mov to clr
   D261 E4                 1651 	clr	a
   D262 12 DF B7           1652 	lcall	__gptrput
   D265 A3                 1653 	inc	dptr
   D266 18                 1654 	dec	r0
   D267 18                 1655 	dec	r0
   D268 A6 82              1656 	mov	@r0,dpl
   D26A 08                 1657 	inc	r0
   D26B A6 83              1658 	mov	@r0,dph
                           1659 ;	../../Common/modules/cUDP.c:219: *dptr++ = 0;		
                           1660 ;	genPointerSet
                           1661 ;	genGenPointerSet
   D26D E5 10              1662 	mov	a,_bp
   D26F 24 08              1663 	add	a,#0x08
   D271 F8                 1664 	mov	r0,a
   D272 86 82              1665 	mov	dpl,@r0
   D274 08                 1666 	inc	r0
   D275 86 83              1667 	mov	dph,@r0
   D277 08                 1668 	inc	r0
   D278 86 F0              1669 	mov	b,@r0
                           1670 ;	Peephole 181	changed mov to clr
   D27A E4                 1671 	clr	a
   D27B 12 DF B7           1672 	lcall	__gptrput
                           1673 ;	../../Common/modules/cUDP.c:222: buf->src_sa.addr_type = ADDR_NONE;
                           1674 ;	genPlus
   D27E A8 10              1675 	mov	r0,_bp
   D280 08                 1676 	inc	r0
                           1677 ;     genPlusIncr
   D281 74 10              1678 	mov	a,#0x10
   D283 26                 1679 	add	a,@r0
   D284 FA                 1680 	mov	r2,a
                           1681 ;	Peephole 181	changed mov to clr
   D285 E4                 1682 	clr	a
   D286 08                 1683 	inc	r0
   D287 36                 1684 	addc	a,@r0
   D288 FB                 1685 	mov	r3,a
   D289 08                 1686 	inc	r0
   D28A 86 04              1687 	mov	ar4,@r0
                           1688 ;	genPointerSet
                           1689 ;	genGenPointerSet
   D28C 8A 82              1690 	mov	dpl,r2
   D28E 8B 83              1691 	mov	dph,r3
   D290 8C F0              1692 	mov	b,r4
                           1693 ;	Peephole 181	changed mov to clr
   D292 E4                 1694 	clr	a
   D293 12 DF B7           1695 	lcall	__gptrput
                           1696 ;	../../Common/modules/cUDP.c:223: buf->from = MODULE_CUDP;
                           1697 ;	genPlus
   D296 A8 10              1698 	mov	r0,_bp
   D298 08                 1699 	inc	r0
                           1700 ;     genPlusIncr
   D299 74 1D              1701 	mov	a,#0x1D
   D29B 26                 1702 	add	a,@r0
   D29C FA                 1703 	mov	r2,a
                           1704 ;	Peephole 181	changed mov to clr
   D29D E4                 1705 	clr	a
   D29E 08                 1706 	inc	r0
   D29F 36                 1707 	addc	a,@r0
   D2A0 FB                 1708 	mov	r3,a
   D2A1 08                 1709 	inc	r0
   D2A2 86 04              1710 	mov	ar4,@r0
                           1711 ;	genPointerSet
                           1712 ;	genGenPointerSet
   D2A4 8A 82              1713 	mov	dpl,r2
   D2A6 8B 83              1714 	mov	dph,r3
   D2A8 8C F0              1715 	mov	b,r4
   D2AA 74 02              1716 	mov	a,#0x02
   D2AC 12 DF B7           1717 	lcall	__gptrput
                           1718 ;	../../Common/modules/cUDP.c:224: buf->to = MODULE_NONE;
                           1719 ;	genPlus
   D2AF A8 10              1720 	mov	r0,_bp
   D2B1 08                 1721 	inc	r0
                           1722 ;     genPlusIncr
   D2B2 74 1E              1723 	mov	a,#0x1E
   D2B4 26                 1724 	add	a,@r0
   D2B5 FA                 1725 	mov	r2,a
                           1726 ;	Peephole 181	changed mov to clr
   D2B6 E4                 1727 	clr	a
   D2B7 08                 1728 	inc	r0
   D2B8 36                 1729 	addc	a,@r0
   D2B9 FB                 1730 	mov	r3,a
   D2BA 08                 1731 	inc	r0
   D2BB 86 04              1732 	mov	ar4,@r0
                           1733 ;	genPointerSet
                           1734 ;	genGenPointerSet
   D2BD 8A 82              1735 	mov	dpl,r2
   D2BF 8B 83              1736 	mov	dph,r3
   D2C1 8C F0              1737 	mov	b,r4
                           1738 ;	Peephole 181	changed mov to clr
   D2C3 E4                 1739 	clr	a
   D2C4 12 DF B7           1740 	lcall	__gptrput
                           1741 ;	../../Common/modules/cUDP.c:225: stack_buffer_push(buf);
                           1742 ;	genCall
   D2C7 A8 10              1743 	mov	r0,_bp
   D2C9 08                 1744 	inc	r0
   D2CA 86 82              1745 	mov	dpl,@r0
   D2CC 08                 1746 	inc	r0
   D2CD 86 83              1747 	mov	dph,@r0
   D2CF 08                 1748 	inc	r0
   D2D0 86 F0              1749 	mov	b,@r0
   D2D2 12 62 C4           1750 	lcall	_stack_buffer_push
                           1751 ;	../../Common/modules/cUDP.c:227: break;
   D2D5 02 DE 54           1752 	ljmp	00147$
                           1753 ;	../../Common/modules/cUDP.c:229: case BUFFER_UP:
   D2D8                    1754 00115$:
                           1755 ;	../../Common/modules/cUDP.c:231: data_length = (buf->buf_end - buf->buf_ptr);
                           1756 ;	genPlus
   D2D8 A8 10              1757 	mov	r0,_bp
   D2DA 08                 1758 	inc	r0
                           1759 ;     genPlusIncr
   D2DB 74 22              1760 	mov	a,#0x22
   D2DD 26                 1761 	add	a,@r0
   D2DE FA                 1762 	mov	r2,a
                           1763 ;	Peephole 181	changed mov to clr
   D2DF E4                 1764 	clr	a
   D2E0 08                 1765 	inc	r0
   D2E1 36                 1766 	addc	a,@r0
   D2E2 FB                 1767 	mov	r3,a
   D2E3 08                 1768 	inc	r0
   D2E4 86 04              1769 	mov	ar4,@r0
                           1770 ;	genPointerGet
                           1771 ;	genGenPointerGet
   D2E6 8A 82              1772 	mov	dpl,r2
   D2E8 8B 83              1773 	mov	dph,r3
   D2EA 8C F0              1774 	mov	b,r4
   D2EC E5 10              1775 	mov	a,_bp
   D2EE 24 19              1776 	add	a,#0x19
   D2F0 F8                 1777 	mov	r0,a
   D2F1 12 E4 9F           1778 	lcall	__gptrget
   D2F4 F6                 1779 	mov	@r0,a
   D2F5 A3                 1780 	inc	dptr
   D2F6 12 E4 9F           1781 	lcall	__gptrget
   D2F9 08                 1782 	inc	r0
   D2FA F6                 1783 	mov	@r0,a
                           1784 ;	genPlus
   D2FB A8 10              1785 	mov	r0,_bp
   D2FD 08                 1786 	inc	r0
                           1787 ;     genPlusIncr
   D2FE 74 20              1788 	mov	a,#0x20
   D300 26                 1789 	add	a,@r0
   D301 FC                 1790 	mov	r4,a
                           1791 ;	Peephole 181	changed mov to clr
   D302 E4                 1792 	clr	a
   D303 08                 1793 	inc	r0
   D304 36                 1794 	addc	a,@r0
   D305 FD                 1795 	mov	r5,a
   D306 08                 1796 	inc	r0
   D307 86 06              1797 	mov	ar6,@r0
                           1798 ;	genPointerGet
                           1799 ;	genGenPointerGet
   D309 8C 82              1800 	mov	dpl,r4
   D30B 8D 83              1801 	mov	dph,r5
   D30D 8E F0              1802 	mov	b,r6
   D30F E5 10              1803 	mov	a,_bp
   D311 24 1B              1804 	add	a,#0x1b
   D313 F8                 1805 	mov	r0,a
   D314 12 E4 9F           1806 	lcall	__gptrget
   D317 F6                 1807 	mov	@r0,a
   D318 A3                 1808 	inc	dptr
   D319 12 E4 9F           1809 	lcall	__gptrget
   D31C 08                 1810 	inc	r0
   D31D F6                 1811 	mov	@r0,a
                           1812 ;	../../Common/modules/cUDP.c:232: length=0;
                           1813 ;	genAssign
   D31E E5 10              1814 	mov	a,_bp
   D320 24 0F              1815 	add	a,#0x0f
   D322 F8                 1816 	mov	r0,a
   D323 E4                 1817 	clr	a
   D324 F6                 1818 	mov	@r0,a
   D325 08                 1819 	inc	r0
   D326 F6                 1820 	mov	@r0,a
                           1821 ;	../../Common/modules/cUDP.c:233: ind = buf->buf_ptr;
                           1822 ;	genCast
   D327 E5 10              1823 	mov	a,_bp
   D329 24 1B              1824 	add	a,#0x1b
   D32B F8                 1825 	mov	r0,a
   D32C E5 10              1826 	mov	a,_bp
   D32E 24 05              1827 	add	a,#0x05
   D330 F9                 1828 	mov	r1,a
   D331 E6                 1829 	mov	a,@r0
   D332 F7                 1830 	mov	@r1,a
                           1831 ;	../../Common/modules/cUDP.c:235: switch (buf->options.lowpan_compressed)
                           1832 ;	genPlus
   D333 A8 10              1833 	mov	r0,_bp
   D335 08                 1834 	inc	r0
                           1835 ;     genPlusIncr
   D336 74 26              1836 	mov	a,#0x26
   D338 26                 1837 	add	a,@r0
   D339 FA                 1838 	mov	r2,a
                           1839 ;	Peephole 181	changed mov to clr
   D33A E4                 1840 	clr	a
   D33B 08                 1841 	inc	r0
   D33C 36                 1842 	addc	a,@r0
   D33D FF                 1843 	mov	r7,a
   D33E 08                 1844 	inc	r0
   D33F 86 03              1845 	mov	ar3,@r0
                           1846 ;	genPlus
                           1847 ;     genPlusIncr
   D341 74 05              1848 	mov	a,#0x05
                           1849 ;	Peephole 236.a	used r2 instead of ar2
   D343 2A                 1850 	add	a,r2
   D344 FA                 1851 	mov	r2,a
                           1852 ;	Peephole 181	changed mov to clr
   D345 E4                 1853 	clr	a
                           1854 ;	Peephole 236.b	used r7 instead of ar7
   D346 3F                 1855 	addc	a,r7
   D347 FF                 1856 	mov	r7,a
                           1857 ;	genPointerGet
                           1858 ;	genGenPointerGet
   D348 8A 82              1859 	mov	dpl,r2
   D34A 8F 83              1860 	mov	dph,r7
   D34C 8B F0              1861 	mov	b,r3
   D34E 12 E4 9F           1862 	lcall	__gptrget
                           1863 ;	genCmpEq
                           1864 ;	gencjneshort
                           1865 ;	Peephole 112.b	changed ljmp to sjmp
   D351 FA                 1866 	mov	r2,a
                           1867 ;	Peephole 115.b	jump optimization
   D352 60 0F              1868 	jz	00116$
                           1869 ;	Peephole 300	removed redundant label 00191$
                           1870 ;	genCmpEq
                           1871 ;	gencjneshort
   D354 BA 04 03           1872 	cjne	r2,#0x04,00192$
   D357 02 D5 D9           1873 	ljmp	00118$
   D35A                    1874 00192$:
                           1875 ;	genCmpEq
                           1876 ;	gencjneshort
   D35A BA 07 03           1877 	cjne	r2,#0x07,00193$
   D35D 02 D4 F5           1878 	ljmp	00117$
   D360                    1879 00193$:
   D360 02 D7 3B           1880 	ljmp	00119$
                           1881 ;	../../Common/modules/cUDP.c:237: case UNCOMPRESSED_HC_UDP:
   D363                    1882 00116$:
                           1883 ;	../../Common/modules/cUDP.c:239: port = buf->buf[ind++];
                           1884 ;	genIpush
   D363 C0 04              1885 	push	ar4
   D365 C0 05              1886 	push	ar5
   D367 C0 06              1887 	push	ar6
                           1888 ;	genPlus
   D369 A8 10              1889 	mov	r0,_bp
   D36B 08                 1890 	inc	r0
                           1891 ;     genPlusIncr
   D36C 74 2C              1892 	mov	a,#0x2C
   D36E 26                 1893 	add	a,@r0
   D36F FA                 1894 	mov	r2,a
                           1895 ;	Peephole 181	changed mov to clr
   D370 E4                 1896 	clr	a
   D371 08                 1897 	inc	r0
   D372 36                 1898 	addc	a,@r0
   D373 FB                 1899 	mov	r3,a
   D374 08                 1900 	inc	r0
   D375 86 07              1901 	mov	ar7,@r0
                           1902 ;	genAssign
   D377 E5 10              1903 	mov	a,_bp
   D379 24 05              1904 	add	a,#0x05
   D37B F8                 1905 	mov	r0,a
   D37C 86 04              1906 	mov	ar4,@r0
                           1907 ;	genPlus
   D37E E5 10              1908 	mov	a,_bp
   D380 24 05              1909 	add	a,#0x05
   D382 F8                 1910 	mov	r0,a
                           1911 ;     genPlusIncr
   D383 06                 1912 	inc	@r0
                           1913 ;	genPlus
                           1914 ;	Peephole 236.g	used r4 instead of ar4
   D384 EC                 1915 	mov	a,r4
                           1916 ;	Peephole 236.a	used r2 instead of ar2
   D385 2A                 1917 	add	a,r2
   D386 FC                 1918 	mov	r4,a
                           1919 ;	Peephole 181	changed mov to clr
   D387 E4                 1920 	clr	a
                           1921 ;	Peephole 236.b	used r3 instead of ar3
   D388 3B                 1922 	addc	a,r3
   D389 FD                 1923 	mov	r5,a
   D38A 8F 06              1924 	mov	ar6,r7
                           1925 ;	genPointerGet
                           1926 ;	genGenPointerGet
   D38C 8C 82              1927 	mov	dpl,r4
   D38E 8D 83              1928 	mov	dph,r5
   D390 8E F0              1929 	mov	b,r6
   D392 12 E4 9F           1930 	lcall	__gptrget
   D395 FC                 1931 	mov	r4,a
                           1932 ;	genCast
   D396 E5 10              1933 	mov	a,_bp
   D398 24 0B              1934 	add	a,#0x0b
   D39A F8                 1935 	mov	r0,a
   D39B A6 04              1936 	mov	@r0,ar4
   D39D 08                 1937 	inc	r0
   D39E 76 00              1938 	mov	@r0,#0x00
                           1939 ;	../../Common/modules/cUDP.c:240: port <<= 8;
                           1940 ;	genLeftShift
                           1941 ;	genLeftShiftLiteral
   D3A0 E5 10              1942 	mov	a,_bp
   D3A2 24 0B              1943 	add	a,#0x0b
   D3A4 F8                 1944 	mov	r0,a
                           1945 ;	genlshTwo
   D3A5 E6                 1946 	mov	a,@r0
   D3A6 08                 1947 	inc	r0
   D3A7 F6                 1948 	mov	@r0,a
   D3A8 18                 1949 	dec	r0
   D3A9 76 00              1950 	mov	@r0,#0x00
                           1951 ;	../../Common/modules/cUDP.c:241: port += buf->buf[ind++];
                           1952 ;	genAssign
   D3AB E5 10              1953 	mov	a,_bp
   D3AD 24 05              1954 	add	a,#0x05
   D3AF F8                 1955 	mov	r0,a
   D3B0 86 04              1956 	mov	ar4,@r0
                           1957 ;	genPlus
   D3B2 E5 10              1958 	mov	a,_bp
   D3B4 24 05              1959 	add	a,#0x05
   D3B6 F8                 1960 	mov	r0,a
                           1961 ;     genPlusIncr
   D3B7 06                 1962 	inc	@r0
                           1963 ;	genPlus
                           1964 ;	Peephole 236.g	used r4 instead of ar4
   D3B8 EC                 1965 	mov	a,r4
                           1966 ;	Peephole 236.a	used r2 instead of ar2
   D3B9 2A                 1967 	add	a,r2
   D3BA FC                 1968 	mov	r4,a
                           1969 ;	Peephole 181	changed mov to clr
   D3BB E4                 1970 	clr	a
                           1971 ;	Peephole 236.b	used r3 instead of ar3
   D3BC 3B                 1972 	addc	a,r3
   D3BD FD                 1973 	mov	r5,a
   D3BE 8F 06              1974 	mov	ar6,r7
                           1975 ;	genPointerGet
                           1976 ;	genGenPointerGet
   D3C0 8C 82              1977 	mov	dpl,r4
   D3C2 8D 83              1978 	mov	dph,r5
   D3C4 8E F0              1979 	mov	b,r6
   D3C6 12 E4 9F           1980 	lcall	__gptrget
   D3C9 FC                 1981 	mov	r4,a
                           1982 ;	genCast
   D3CA 7D 00              1983 	mov	r5,#0x00
                           1984 ;	genPlus
   D3CC E5 10              1985 	mov	a,_bp
   D3CE 24 0B              1986 	add	a,#0x0b
   D3D0 F8                 1987 	mov	r0,a
                           1988 ;	Peephole 236.g	used r4 instead of ar4
   D3D1 EC                 1989 	mov	a,r4
   D3D2 26                 1990 	add	a,@r0
   D3D3 F6                 1991 	mov	@r0,a
                           1992 ;	Peephole 236.g	used r5 instead of ar5
   D3D4 ED                 1993 	mov	a,r5
   D3D5 08                 1994 	inc	r0
   D3D6 36                 1995 	addc	a,@r0
   D3D7 F6                 1996 	mov	@r0,a
                           1997 ;	../../Common/modules/cUDP.c:242: buf->src_sa.port=port;
                           1998 ;	genPlus
   D3D8 A8 10              1999 	mov	r0,_bp
   D3DA 08                 2000 	inc	r0
                           2001 ;     genPlusIncr
   D3DB 74 10              2002 	mov	a,#0x10
   D3DD 26                 2003 	add	a,@r0
   D3DE FC                 2004 	mov	r4,a
                           2005 ;	Peephole 181	changed mov to clr
   D3DF E4                 2006 	clr	a
   D3E0 08                 2007 	inc	r0
   D3E1 36                 2008 	addc	a,@r0
   D3E2 FD                 2009 	mov	r5,a
   D3E3 08                 2010 	inc	r0
   D3E4 86 06              2011 	mov	ar6,@r0
                           2012 ;	genPlus
                           2013 ;     genPlusIncr
   D3E6 74 0B              2014 	mov	a,#0x0B
                           2015 ;	Peephole 236.a	used r4 instead of ar4
   D3E8 2C                 2016 	add	a,r4
   D3E9 FC                 2017 	mov	r4,a
                           2018 ;	Peephole 181	changed mov to clr
   D3EA E4                 2019 	clr	a
                           2020 ;	Peephole 236.b	used r5 instead of ar5
   D3EB 3D                 2021 	addc	a,r5
   D3EC FD                 2022 	mov	r5,a
                           2023 ;	genPointerSet
                           2024 ;	genGenPointerSet
   D3ED 8C 82              2025 	mov	dpl,r4
   D3EF 8D 83              2026 	mov	dph,r5
   D3F1 8E F0              2027 	mov	b,r6
   D3F3 E5 10              2028 	mov	a,_bp
   D3F5 24 0B              2029 	add	a,#0x0b
   D3F7 F8                 2030 	mov	r0,a
   D3F8 E6                 2031 	mov	a,@r0
   D3F9 12 DF B7           2032 	lcall	__gptrput
   D3FC A3                 2033 	inc	dptr
   D3FD 08                 2034 	inc	r0
   D3FE E6                 2035 	mov	a,@r0
   D3FF 12 DF B7           2036 	lcall	__gptrput
                           2037 ;	../../Common/modules/cUDP.c:244: port = buf->buf[ind++];
                           2038 ;	genAssign
   D402 E5 10              2039 	mov	a,_bp
   D404 24 05              2040 	add	a,#0x05
   D406 F8                 2041 	mov	r0,a
   D407 86 04              2042 	mov	ar4,@r0
                           2043 ;	genPlus
   D409 E5 10              2044 	mov	a,_bp
   D40B 24 05              2045 	add	a,#0x05
   D40D F8                 2046 	mov	r0,a
                           2047 ;     genPlusIncr
   D40E 06                 2048 	inc	@r0
                           2049 ;	genPlus
                           2050 ;	Peephole 236.g	used r4 instead of ar4
   D40F EC                 2051 	mov	a,r4
                           2052 ;	Peephole 236.a	used r2 instead of ar2
   D410 2A                 2053 	add	a,r2
   D411 FC                 2054 	mov	r4,a
                           2055 ;	Peephole 181	changed mov to clr
   D412 E4                 2056 	clr	a
                           2057 ;	Peephole 236.b	used r3 instead of ar3
   D413 3B                 2058 	addc	a,r3
   D414 FD                 2059 	mov	r5,a
   D415 8F 06              2060 	mov	ar6,r7
                           2061 ;	genPointerGet
                           2062 ;	genGenPointerGet
   D417 8C 82              2063 	mov	dpl,r4
   D419 8D 83              2064 	mov	dph,r5
   D41B 8E F0              2065 	mov	b,r6
   D41D 12 E4 9F           2066 	lcall	__gptrget
   D420 FC                 2067 	mov	r4,a
                           2068 ;	genCast
   D421 E5 10              2069 	mov	a,_bp
   D423 24 0B              2070 	add	a,#0x0b
   D425 F8                 2071 	mov	r0,a
   D426 A6 04              2072 	mov	@r0,ar4
   D428 08                 2073 	inc	r0
   D429 76 00              2074 	mov	@r0,#0x00
                           2075 ;	../../Common/modules/cUDP.c:245: port <<= 8;
                           2076 ;	genLeftShift
                           2077 ;	genLeftShiftLiteral
   D42B E5 10              2078 	mov	a,_bp
   D42D 24 0B              2079 	add	a,#0x0b
   D42F F8                 2080 	mov	r0,a
                           2081 ;	genlshTwo
   D430 E6                 2082 	mov	a,@r0
   D431 08                 2083 	inc	r0
   D432 F6                 2084 	mov	@r0,a
   D433 18                 2085 	dec	r0
   D434 76 00              2086 	mov	@r0,#0x00
                           2087 ;	../../Common/modules/cUDP.c:246: port += buf->buf[ind++];
                           2088 ;	genAssign
   D436 E5 10              2089 	mov	a,_bp
   D438 24 05              2090 	add	a,#0x05
   D43A F8                 2091 	mov	r0,a
   D43B 86 04              2092 	mov	ar4,@r0
                           2093 ;	genPlus
   D43D E5 10              2094 	mov	a,_bp
   D43F 24 05              2095 	add	a,#0x05
   D441 F8                 2096 	mov	r0,a
                           2097 ;     genPlusIncr
   D442 06                 2098 	inc	@r0
                           2099 ;	genPlus
                           2100 ;	Peephole 236.g	used r4 instead of ar4
   D443 EC                 2101 	mov	a,r4
                           2102 ;	Peephole 236.a	used r2 instead of ar2
   D444 2A                 2103 	add	a,r2
   D445 FC                 2104 	mov	r4,a
                           2105 ;	Peephole 181	changed mov to clr
   D446 E4                 2106 	clr	a
                           2107 ;	Peephole 236.b	used r3 instead of ar3
   D447 3B                 2108 	addc	a,r3
   D448 FD                 2109 	mov	r5,a
   D449 8F 06              2110 	mov	ar6,r7
                           2111 ;	genPointerGet
                           2112 ;	genGenPointerGet
   D44B 8C 82              2113 	mov	dpl,r4
   D44D 8D 83              2114 	mov	dph,r5
   D44F 8E F0              2115 	mov	b,r6
   D451 12 E4 9F           2116 	lcall	__gptrget
   D454 FC                 2117 	mov	r4,a
                           2118 ;	genCast
   D455 7D 00              2119 	mov	r5,#0x00
                           2120 ;	genPlus
   D457 E5 10              2121 	mov	a,_bp
   D459 24 0B              2122 	add	a,#0x0b
   D45B F8                 2123 	mov	r0,a
                           2124 ;	Peephole 236.g	used r4 instead of ar4
   D45C EC                 2125 	mov	a,r4
   D45D 26                 2126 	add	a,@r0
   D45E F6                 2127 	mov	@r0,a
                           2128 ;	Peephole 236.g	used r5 instead of ar5
   D45F ED                 2129 	mov	a,r5
   D460 08                 2130 	inc	r0
   D461 36                 2131 	addc	a,@r0
   D462 F6                 2132 	mov	@r0,a
                           2133 ;	../../Common/modules/cUDP.c:247: buf->dst_sa.port=port;
                           2134 ;	genPlus
   D463 A8 10              2135 	mov	r0,_bp
   D465 08                 2136 	inc	r0
                           2137 ;     genPlusIncr
   D466 74 03              2138 	mov	a,#0x03
   D468 26                 2139 	add	a,@r0
   D469 FC                 2140 	mov	r4,a
                           2141 ;	Peephole 181	changed mov to clr
   D46A E4                 2142 	clr	a
   D46B 08                 2143 	inc	r0
   D46C 36                 2144 	addc	a,@r0
   D46D FD                 2145 	mov	r5,a
   D46E 08                 2146 	inc	r0
   D46F 86 06              2147 	mov	ar6,@r0
                           2148 ;	genPlus
                           2149 ;     genPlusIncr
   D471 74 0B              2150 	mov	a,#0x0B
                           2151 ;	Peephole 236.a	used r4 instead of ar4
   D473 2C                 2152 	add	a,r4
   D474 FC                 2153 	mov	r4,a
                           2154 ;	Peephole 181	changed mov to clr
   D475 E4                 2155 	clr	a
                           2156 ;	Peephole 236.b	used r5 instead of ar5
   D476 3D                 2157 	addc	a,r5
   D477 FD                 2158 	mov	r5,a
                           2159 ;	genPointerSet
                           2160 ;	genGenPointerSet
   D478 8C 82              2161 	mov	dpl,r4
   D47A 8D 83              2162 	mov	dph,r5
   D47C 8E F0              2163 	mov	b,r6
   D47E E5 10              2164 	mov	a,_bp
   D480 24 0B              2165 	add	a,#0x0b
   D482 F8                 2166 	mov	r0,a
   D483 E6                 2167 	mov	a,@r0
   D484 12 DF B7           2168 	lcall	__gptrput
   D487 A3                 2169 	inc	dptr
   D488 08                 2170 	inc	r0
   D489 E6                 2171 	mov	a,@r0
   D48A 12 DF B7           2172 	lcall	__gptrput
                           2173 ;	../../Common/modules/cUDP.c:249: length = buf->buf[ind++];
                           2174 ;	genAssign
   D48D E5 10              2175 	mov	a,_bp
   D48F 24 05              2176 	add	a,#0x05
   D491 F8                 2177 	mov	r0,a
   D492 86 04              2178 	mov	ar4,@r0
                           2179 ;	genPlus
   D494 E5 10              2180 	mov	a,_bp
   D496 24 05              2181 	add	a,#0x05
   D498 F8                 2182 	mov	r0,a
                           2183 ;     genPlusIncr
   D499 06                 2184 	inc	@r0
                           2185 ;	genPlus
                           2186 ;	Peephole 236.g	used r4 instead of ar4
   D49A EC                 2187 	mov	a,r4
                           2188 ;	Peephole 236.a	used r2 instead of ar2
   D49B 2A                 2189 	add	a,r2
   D49C FC                 2190 	mov	r4,a
                           2191 ;	Peephole 181	changed mov to clr
   D49D E4                 2192 	clr	a
                           2193 ;	Peephole 236.b	used r3 instead of ar3
   D49E 3B                 2194 	addc	a,r3
   D49F FD                 2195 	mov	r5,a
   D4A0 8F 06              2196 	mov	ar6,r7
                           2197 ;	genPointerGet
                           2198 ;	genGenPointerGet
   D4A2 8C 82              2199 	mov	dpl,r4
   D4A4 8D 83              2200 	mov	dph,r5
   D4A6 8E F0              2201 	mov	b,r6
   D4A8 12 E4 9F           2202 	lcall	__gptrget
   D4AB FC                 2203 	mov	r4,a
                           2204 ;	genCast
   D4AC E5 10              2205 	mov	a,_bp
   D4AE 24 0F              2206 	add	a,#0x0f
   D4B0 F8                 2207 	mov	r0,a
   D4B1 A6 04              2208 	mov	@r0,ar4
   D4B3 08                 2209 	inc	r0
   D4B4 76 00              2210 	mov	@r0,#0x00
                           2211 ;	../../Common/modules/cUDP.c:250: length <<= 8;
                           2212 ;	genLeftShift
                           2213 ;	genLeftShiftLiteral
   D4B6 E5 10              2214 	mov	a,_bp
   D4B8 24 0F              2215 	add	a,#0x0f
   D4BA F8                 2216 	mov	r0,a
                           2217 ;	genlshTwo
   D4BB E6                 2218 	mov	a,@r0
   D4BC 08                 2219 	inc	r0
   D4BD F6                 2220 	mov	@r0,a
   D4BE 18                 2221 	dec	r0
   D4BF 76 00              2222 	mov	@r0,#0x00
                           2223 ;	../../Common/modules/cUDP.c:251: length += buf->buf[ind++];
                           2224 ;	genAssign
   D4C1 E5 10              2225 	mov	a,_bp
   D4C3 24 05              2226 	add	a,#0x05
   D4C5 F8                 2227 	mov	r0,a
   D4C6 86 04              2228 	mov	ar4,@r0
                           2229 ;	genPlus
   D4C8 E5 10              2230 	mov	a,_bp
   D4CA 24 05              2231 	add	a,#0x05
   D4CC F8                 2232 	mov	r0,a
                           2233 ;     genPlusIncr
   D4CD 06                 2234 	inc	@r0
                           2235 ;	genPlus
                           2236 ;	Peephole 236.g	used r4 instead of ar4
   D4CE EC                 2237 	mov	a,r4
                           2238 ;	Peephole 236.a	used r2 instead of ar2
   D4CF 2A                 2239 	add	a,r2
   D4D0 FA                 2240 	mov	r2,a
                           2241 ;	Peephole 181	changed mov to clr
   D4D1 E4                 2242 	clr	a
                           2243 ;	Peephole 236.b	used r3 instead of ar3
   D4D2 3B                 2244 	addc	a,r3
   D4D3 FB                 2245 	mov	r3,a
                           2246 ;	genPointerGet
                           2247 ;	genGenPointerGet
   D4D4 8A 82              2248 	mov	dpl,r2
   D4D6 8B 83              2249 	mov	dph,r3
   D4D8 8F F0              2250 	mov	b,r7
   D4DA 12 E4 9F           2251 	lcall	__gptrget
   D4DD FA                 2252 	mov	r2,a
                           2253 ;	genCast
   D4DE 7B 00              2254 	mov	r3,#0x00
                           2255 ;	genPlus
   D4E0 E5 10              2256 	mov	a,_bp
   D4E2 24 0F              2257 	add	a,#0x0f
   D4E4 F8                 2258 	mov	r0,a
                           2259 ;	Peephole 236.g	used r2 instead of ar2
   D4E5 EA                 2260 	mov	a,r2
   D4E6 26                 2261 	add	a,@r0
   D4E7 F6                 2262 	mov	@r0,a
                           2263 ;	Peephole 236.g	used r3 instead of ar3
   D4E8 EB                 2264 	mov	a,r3
   D4E9 08                 2265 	inc	r0
   D4EA 36                 2266 	addc	a,@r0
   D4EB F6                 2267 	mov	@r0,a
                           2268 ;	../../Common/modules/cUDP.c:254: break;
                           2269 ;	genIpop
   D4EC D0 06              2270 	pop	ar6
   D4EE D0 05              2271 	pop	ar5
   D4F0 D0 04              2272 	pop	ar4
   D4F2 02 D7 3B           2273 	ljmp	00119$
                           2274 ;	../../Common/modules/cUDP.c:256: case COMPRESSED_HC_UDP:
   D4F5                    2275 00117$:
                           2276 ;	../../Common/modules/cUDP.c:259: portfield = buf->buf[ind++];
                           2277 ;	genIpush
   D4F5 C0 04              2278 	push	ar4
   D4F7 C0 05              2279 	push	ar5
   D4F9 C0 06              2280 	push	ar6
                           2281 ;	genPlus
   D4FB A8 10              2282 	mov	r0,_bp
   D4FD 08                 2283 	inc	r0
                           2284 ;     genPlusIncr
   D4FE 74 2C              2285 	mov	a,#0x2C
   D500 26                 2286 	add	a,@r0
   D501 FA                 2287 	mov	r2,a
                           2288 ;	Peephole 181	changed mov to clr
   D502 E4                 2289 	clr	a
   D503 08                 2290 	inc	r0
   D504 36                 2291 	addc	a,@r0
   D505 FB                 2292 	mov	r3,a
   D506 08                 2293 	inc	r0
   D507 86 07              2294 	mov	ar7,@r0
                           2295 ;	genAssign
   D509 E5 10              2296 	mov	a,_bp
   D50B 24 05              2297 	add	a,#0x05
   D50D F8                 2298 	mov	r0,a
   D50E 86 04              2299 	mov	ar4,@r0
                           2300 ;	genPlus
   D510 E5 10              2301 	mov	a,_bp
   D512 24 05              2302 	add	a,#0x05
   D514 F8                 2303 	mov	r0,a
                           2304 ;     genPlusIncr
   D515 06                 2305 	inc	@r0
                           2306 ;	genPlus
                           2307 ;	Peephole 236.g	used r4 instead of ar4
   D516 EC                 2308 	mov	a,r4
                           2309 ;	Peephole 236.a	used r2 instead of ar2
   D517 2A                 2310 	add	a,r2
   D518 FA                 2311 	mov	r2,a
                           2312 ;	Peephole 181	changed mov to clr
   D519 E4                 2313 	clr	a
                           2314 ;	Peephole 236.b	used r3 instead of ar3
   D51A 3B                 2315 	addc	a,r3
   D51B FB                 2316 	mov	r3,a
                           2317 ;	genPointerGet
                           2318 ;	genGenPointerGet
   D51C 8A 82              2319 	mov	dpl,r2
   D51E 8B 83              2320 	mov	dph,r3
   D520 8F F0              2321 	mov	b,r7
   D522 12 E4 9F           2322 	lcall	__gptrget
   D525 FA                 2323 	mov	r2,a
                           2324 ;	genAssign
   D526 E5 10              2325 	mov	a,_bp
   D528 24 11              2326 	add	a,#0x11
   D52A F8                 2327 	mov	r0,a
   D52B A6 02              2328 	mov	@r0,ar2
                           2329 ;	../../Common/modules/cUDP.c:261: buf->src_sa.port = ((portfield & S_PORTBM) + HC2_ENCODE_P_VALUE );
                           2330 ;	genPlus
   D52D A8 10              2331 	mov	r0,_bp
   D52F 08                 2332 	inc	r0
                           2333 ;     genPlusIncr
   D530 74 10              2334 	mov	a,#0x10
   D532 26                 2335 	add	a,@r0
   D533 FA                 2336 	mov	r2,a
                           2337 ;	Peephole 181	changed mov to clr
   D534 E4                 2338 	clr	a
   D535 08                 2339 	inc	r0
   D536 36                 2340 	addc	a,@r0
   D537 FB                 2341 	mov	r3,a
   D538 08                 2342 	inc	r0
   D539 86 04              2343 	mov	ar4,@r0
                           2344 ;	genPlus
                           2345 ;     genPlusIncr
   D53B 74 0B              2346 	mov	a,#0x0B
                           2347 ;	Peephole 236.a	used r2 instead of ar2
   D53D 2A                 2348 	add	a,r2
   D53E FA                 2349 	mov	r2,a
                           2350 ;	Peephole 181	changed mov to clr
   D53F E4                 2351 	clr	a
                           2352 ;	Peephole 236.b	used r3 instead of ar3
   D540 3B                 2353 	addc	a,r3
   D541 FB                 2354 	mov	r3,a
                           2355 ;	genAnd
   D542 E5 10              2356 	mov	a,_bp
   D544 24 11              2357 	add	a,#0x11
   D546 F8                 2358 	mov	r0,a
   D547 74 0F              2359 	mov	a,#0x0F
   D549 56                 2360 	anl	a,@r0
   D54A FD                 2361 	mov	r5,a
                           2362 ;	genCast
   D54B 7E 00              2363 	mov	r6,#0x00
                           2364 ;	genPlus
                           2365 ;     genPlusIncr
   D54D 74 B0              2366 	mov	a,#0xB0
                           2367 ;	Peephole 236.a	used r5 instead of ar5
   D54F 2D                 2368 	add	a,r5
   D550 FD                 2369 	mov	r5,a
   D551 74 F0              2370 	mov	a,#0xF0
                           2371 ;	Peephole 236.b	used r6 instead of ar6
   D553 3E                 2372 	addc	a,r6
   D554 FE                 2373 	mov	r6,a
                           2374 ;	genPointerSet
                           2375 ;	genGenPointerSet
   D555 8A 82              2376 	mov	dpl,r2
   D557 8B 83              2377 	mov	dph,r3
   D559 8C F0              2378 	mov	b,r4
   D55B ED                 2379 	mov	a,r5
   D55C 12 DF B7           2380 	lcall	__gptrput
   D55F A3                 2381 	inc	dptr
   D560 EE                 2382 	mov	a,r6
   D561 12 DF B7           2383 	lcall	__gptrput
                           2384 ;	../../Common/modules/cUDP.c:263: buf->dst_sa.port = ((portfield >> 4) + HC2_ENCODE_P_VALUE);
                           2385 ;	genPlus
   D564 A8 10              2386 	mov	r0,_bp
   D566 08                 2387 	inc	r0
                           2388 ;     genPlusIncr
   D567 74 03              2389 	mov	a,#0x03
   D569 26                 2390 	add	a,@r0
   D56A FA                 2391 	mov	r2,a
                           2392 ;	Peephole 181	changed mov to clr
   D56B E4                 2393 	clr	a
   D56C 08                 2394 	inc	r0
   D56D 36                 2395 	addc	a,@r0
   D56E FB                 2396 	mov	r3,a
   D56F 08                 2397 	inc	r0
   D570 86 04              2398 	mov	ar4,@r0
                           2399 ;	genPlus
                           2400 ;     genPlusIncr
   D572 74 0B              2401 	mov	a,#0x0B
                           2402 ;	Peephole 236.a	used r2 instead of ar2
   D574 2A                 2403 	add	a,r2
   D575 FA                 2404 	mov	r2,a
                           2405 ;	Peephole 181	changed mov to clr
   D576 E4                 2406 	clr	a
                           2407 ;	Peephole 236.b	used r3 instead of ar3
   D577 3B                 2408 	addc	a,r3
   D578 FB                 2409 	mov	r3,a
                           2410 ;	genRightShift
                           2411 ;	genRightShiftLiteral
   D579 E5 10              2412 	mov	a,_bp
   D57B 24 11              2413 	add	a,#0x11
   D57D F8                 2414 	mov	r0,a
                           2415 ;	genrshOne
   D57E E6                 2416 	mov	a,@r0
   D57F C4                 2417 	swap	a
   D580 54 0F              2418 	anl	a,#0x0f
   D582 FD                 2419 	mov	r5,a
                           2420 ;	genCast
   D583 7E 00              2421 	mov	r6,#0x00
                           2422 ;	genPlus
                           2423 ;     genPlusIncr
   D585 74 B0              2424 	mov	a,#0xB0
                           2425 ;	Peephole 236.a	used r5 instead of ar5
   D587 2D                 2426 	add	a,r5
   D588 FD                 2427 	mov	r5,a
   D589 74 F0              2428 	mov	a,#0xF0
                           2429 ;	Peephole 236.b	used r6 instead of ar6
   D58B 3E                 2430 	addc	a,r6
   D58C FE                 2431 	mov	r6,a
                           2432 ;	genPointerSet
                           2433 ;	genGenPointerSet
   D58D 8A 82              2434 	mov	dpl,r2
   D58F 8B 83              2435 	mov	dph,r3
   D591 8C F0              2436 	mov	b,r4
   D593 ED                 2437 	mov	a,r5
   D594 12 DF B7           2438 	lcall	__gptrput
   D597 A3                 2439 	inc	dptr
   D598 EE                 2440 	mov	a,r6
   D599 12 DF B7           2441 	lcall	__gptrput
                           2442 ;	../../Common/modules/cUDP.c:265: data_length = ((buf->buf_end - buf->buf_ptr) - header_length);
                           2443 ;	genMinus
   D59C E5 10              2444 	mov	a,_bp
   D59E 24 19              2445 	add	a,#0x19
   D5A0 F8                 2446 	mov	r0,a
   D5A1 E5 10              2447 	mov	a,_bp
   D5A3 24 1B              2448 	add	a,#0x1b
   D5A5 F9                 2449 	mov	r1,a
   D5A6 E6                 2450 	mov	a,@r0
   D5A7 C3                 2451 	clr	c
   D5A8 97                 2452 	subb	a,@r1
   D5A9 FA                 2453 	mov	r2,a
   D5AA 08                 2454 	inc	r0
   D5AB E6                 2455 	mov	a,@r0
   D5AC 09                 2456 	inc	r1
   D5AD 97                 2457 	subb	a,@r1
   D5AE FB                 2458 	mov	r3,a
                           2459 ;	genMinus
   D5AF E5 10              2460 	mov	a,_bp
   D5B1 24 0D              2461 	add	a,#0x0d
   D5B3 F8                 2462 	mov	r0,a
                           2463 ;	genMinusDec
   D5B4 EA                 2464 	mov	a,r2
   D5B5 24 FD              2465 	add	a,#0xfd
   D5B7 F6                 2466 	mov	@r0,a
   D5B8 EB                 2467 	mov	a,r3
   D5B9 34 FF              2468 	addc	a,#0xff
   D5BB 08                 2469 	inc	r0
   D5BC F6                 2470 	mov	@r0,a
                           2471 ;	../../Common/modules/cUDP.c:266: length =(data_length + 8);
                           2472 ;	genPlus
   D5BD E5 10              2473 	mov	a,_bp
   D5BF 24 0D              2474 	add	a,#0x0d
   D5C1 F8                 2475 	mov	r0,a
   D5C2 E5 10              2476 	mov	a,_bp
   D5C4 24 0F              2477 	add	a,#0x0f
   D5C6 F9                 2478 	mov	r1,a
                           2479 ;     genPlusIncr
   D5C7 74 08              2480 	mov	a,#0x08
   D5C9 26                 2481 	add	a,@r0
   D5CA F7                 2482 	mov	@r1,a
                           2483 ;	Peephole 181	changed mov to clr
   D5CB E4                 2484 	clr	a
   D5CC 08                 2485 	inc	r0
   D5CD 36                 2486 	addc	a,@r0
   D5CE 09                 2487 	inc	r1
   D5CF F7                 2488 	mov	@r1,a
                           2489 ;	../../Common/modules/cUDP.c:267: break;
                           2490 ;	genIpop
   D5D0 D0 06              2491 	pop	ar6
   D5D2 D0 05              2492 	pop	ar5
   D5D4 D0 04              2493 	pop	ar4
   D5D6 02 D7 3B           2494 	ljmp	00119$
                           2495 ;	../../Common/modules/cUDP.c:268: case LENGTH_COMPRESSED_HC_UDP:
   D5D9                    2496 00118$:
                           2497 ;	../../Common/modules/cUDP.c:271: port = buf->buf[ind++];
                           2498 ;	genIpush
   D5D9 C0 04              2499 	push	ar4
   D5DB C0 05              2500 	push	ar5
   D5DD C0 06              2501 	push	ar6
                           2502 ;	genPlus
   D5DF A8 10              2503 	mov	r0,_bp
   D5E1 08                 2504 	inc	r0
                           2505 ;     genPlusIncr
   D5E2 74 2C              2506 	mov	a,#0x2C
   D5E4 26                 2507 	add	a,@r0
   D5E5 FA                 2508 	mov	r2,a
                           2509 ;	Peephole 181	changed mov to clr
   D5E6 E4                 2510 	clr	a
   D5E7 08                 2511 	inc	r0
   D5E8 36                 2512 	addc	a,@r0
   D5E9 FB                 2513 	mov	r3,a
   D5EA 08                 2514 	inc	r0
   D5EB 86 07              2515 	mov	ar7,@r0
                           2516 ;	genAssign
   D5ED E5 10              2517 	mov	a,_bp
   D5EF 24 05              2518 	add	a,#0x05
   D5F1 F8                 2519 	mov	r0,a
   D5F2 86 04              2520 	mov	ar4,@r0
                           2521 ;	genPlus
   D5F4 E5 10              2522 	mov	a,_bp
   D5F6 24 05              2523 	add	a,#0x05
   D5F8 F8                 2524 	mov	r0,a
                           2525 ;     genPlusIncr
   D5F9 06                 2526 	inc	@r0
                           2527 ;	genPlus
                           2528 ;	Peephole 236.g	used r4 instead of ar4
   D5FA EC                 2529 	mov	a,r4
                           2530 ;	Peephole 236.a	used r2 instead of ar2
   D5FB 2A                 2531 	add	a,r2
   D5FC FC                 2532 	mov	r4,a
                           2533 ;	Peephole 181	changed mov to clr
   D5FD E4                 2534 	clr	a
                           2535 ;	Peephole 236.b	used r3 instead of ar3
   D5FE 3B                 2536 	addc	a,r3
   D5FF FD                 2537 	mov	r5,a
   D600 8F 06              2538 	mov	ar6,r7
                           2539 ;	genPointerGet
                           2540 ;	genGenPointerGet
   D602 8C 82              2541 	mov	dpl,r4
   D604 8D 83              2542 	mov	dph,r5
   D606 8E F0              2543 	mov	b,r6
   D608 12 E4 9F           2544 	lcall	__gptrget
   D60B FC                 2545 	mov	r4,a
                           2546 ;	genCast
   D60C E5 10              2547 	mov	a,_bp
   D60E 24 0B              2548 	add	a,#0x0b
   D610 F8                 2549 	mov	r0,a
   D611 A6 04              2550 	mov	@r0,ar4
   D613 08                 2551 	inc	r0
   D614 76 00              2552 	mov	@r0,#0x00
                           2553 ;	../../Common/modules/cUDP.c:272: port <<= 8;
                           2554 ;	genLeftShift
                           2555 ;	genLeftShiftLiteral
   D616 E5 10              2556 	mov	a,_bp
   D618 24 0B              2557 	add	a,#0x0b
   D61A F8                 2558 	mov	r0,a
                           2559 ;	genlshTwo
   D61B E6                 2560 	mov	a,@r0
   D61C 08                 2561 	inc	r0
   D61D F6                 2562 	mov	@r0,a
   D61E 18                 2563 	dec	r0
   D61F 76 00              2564 	mov	@r0,#0x00
                           2565 ;	../../Common/modules/cUDP.c:273: port += buf->buf[ind++];
                           2566 ;	genAssign
   D621 E5 10              2567 	mov	a,_bp
   D623 24 05              2568 	add	a,#0x05
   D625 F8                 2569 	mov	r0,a
   D626 86 04              2570 	mov	ar4,@r0
                           2571 ;	genPlus
   D628 E5 10              2572 	mov	a,_bp
   D62A 24 05              2573 	add	a,#0x05
   D62C F8                 2574 	mov	r0,a
                           2575 ;     genPlusIncr
   D62D 06                 2576 	inc	@r0
                           2577 ;	genPlus
                           2578 ;	Peephole 236.g	used r4 instead of ar4
   D62E EC                 2579 	mov	a,r4
                           2580 ;	Peephole 236.a	used r2 instead of ar2
   D62F 2A                 2581 	add	a,r2
   D630 FC                 2582 	mov	r4,a
                           2583 ;	Peephole 181	changed mov to clr
   D631 E4                 2584 	clr	a
                           2585 ;	Peephole 236.b	used r3 instead of ar3
   D632 3B                 2586 	addc	a,r3
   D633 FD                 2587 	mov	r5,a
   D634 8F 06              2588 	mov	ar6,r7
                           2589 ;	genPointerGet
                           2590 ;	genGenPointerGet
   D636 8C 82              2591 	mov	dpl,r4
   D638 8D 83              2592 	mov	dph,r5
   D63A 8E F0              2593 	mov	b,r6
   D63C 12 E4 9F           2594 	lcall	__gptrget
   D63F FC                 2595 	mov	r4,a
                           2596 ;	genCast
   D640 7D 00              2597 	mov	r5,#0x00
                           2598 ;	genPlus
   D642 E5 10              2599 	mov	a,_bp
   D644 24 0B              2600 	add	a,#0x0b
   D646 F8                 2601 	mov	r0,a
                           2602 ;	Peephole 236.g	used r4 instead of ar4
   D647 EC                 2603 	mov	a,r4
   D648 26                 2604 	add	a,@r0
   D649 F6                 2605 	mov	@r0,a
                           2606 ;	Peephole 236.g	used r5 instead of ar5
   D64A ED                 2607 	mov	a,r5
   D64B 08                 2608 	inc	r0
   D64C 36                 2609 	addc	a,@r0
   D64D F6                 2610 	mov	@r0,a
                           2611 ;	../../Common/modules/cUDP.c:274: buf->src_sa.port=port;
                           2612 ;	genPlus
   D64E A8 10              2613 	mov	r0,_bp
   D650 08                 2614 	inc	r0
                           2615 ;     genPlusIncr
   D651 74 10              2616 	mov	a,#0x10
   D653 26                 2617 	add	a,@r0
   D654 FC                 2618 	mov	r4,a
                           2619 ;	Peephole 181	changed mov to clr
   D655 E4                 2620 	clr	a
   D656 08                 2621 	inc	r0
   D657 36                 2622 	addc	a,@r0
   D658 FD                 2623 	mov	r5,a
   D659 08                 2624 	inc	r0
   D65A 86 06              2625 	mov	ar6,@r0
                           2626 ;	genPlus
                           2627 ;     genPlusIncr
   D65C 74 0B              2628 	mov	a,#0x0B
                           2629 ;	Peephole 236.a	used r4 instead of ar4
   D65E 2C                 2630 	add	a,r4
   D65F FC                 2631 	mov	r4,a
                           2632 ;	Peephole 181	changed mov to clr
   D660 E4                 2633 	clr	a
                           2634 ;	Peephole 236.b	used r5 instead of ar5
   D661 3D                 2635 	addc	a,r5
   D662 FD                 2636 	mov	r5,a
                           2637 ;	genPointerSet
                           2638 ;	genGenPointerSet
   D663 8C 82              2639 	mov	dpl,r4
   D665 8D 83              2640 	mov	dph,r5
   D667 8E F0              2641 	mov	b,r6
   D669 E5 10              2642 	mov	a,_bp
   D66B 24 0B              2643 	add	a,#0x0b
   D66D F8                 2644 	mov	r0,a
   D66E E6                 2645 	mov	a,@r0
   D66F 12 DF B7           2646 	lcall	__gptrput
   D672 A3                 2647 	inc	dptr
   D673 08                 2648 	inc	r0
   D674 E6                 2649 	mov	a,@r0
   D675 12 DF B7           2650 	lcall	__gptrput
                           2651 ;	../../Common/modules/cUDP.c:276: port = buf->buf[ind++];
                           2652 ;	genAssign
   D678 E5 10              2653 	mov	a,_bp
   D67A 24 05              2654 	add	a,#0x05
   D67C F8                 2655 	mov	r0,a
   D67D 86 04              2656 	mov	ar4,@r0
                           2657 ;	genPlus
   D67F E5 10              2658 	mov	a,_bp
   D681 24 05              2659 	add	a,#0x05
   D683 F8                 2660 	mov	r0,a
                           2661 ;     genPlusIncr
   D684 06                 2662 	inc	@r0
                           2663 ;	genPlus
                           2664 ;	Peephole 236.g	used r4 instead of ar4
   D685 EC                 2665 	mov	a,r4
                           2666 ;	Peephole 236.a	used r2 instead of ar2
   D686 2A                 2667 	add	a,r2
   D687 FC                 2668 	mov	r4,a
                           2669 ;	Peephole 181	changed mov to clr
   D688 E4                 2670 	clr	a
                           2671 ;	Peephole 236.b	used r3 instead of ar3
   D689 3B                 2672 	addc	a,r3
   D68A FD                 2673 	mov	r5,a
   D68B 8F 06              2674 	mov	ar6,r7
                           2675 ;	genPointerGet
                           2676 ;	genGenPointerGet
   D68D 8C 82              2677 	mov	dpl,r4
   D68F 8D 83              2678 	mov	dph,r5
   D691 8E F0              2679 	mov	b,r6
   D693 12 E4 9F           2680 	lcall	__gptrget
   D696 FC                 2681 	mov	r4,a
                           2682 ;	genCast
   D697 E5 10              2683 	mov	a,_bp
   D699 24 0B              2684 	add	a,#0x0b
   D69B F8                 2685 	mov	r0,a
   D69C A6 04              2686 	mov	@r0,ar4
   D69E 08                 2687 	inc	r0
   D69F 76 00              2688 	mov	@r0,#0x00
                           2689 ;	../../Common/modules/cUDP.c:277: port <<= 8;
                           2690 ;	genLeftShift
                           2691 ;	genLeftShiftLiteral
   D6A1 E5 10              2692 	mov	a,_bp
   D6A3 24 0B              2693 	add	a,#0x0b
   D6A5 F8                 2694 	mov	r0,a
                           2695 ;	genlshTwo
   D6A6 E6                 2696 	mov	a,@r0
   D6A7 08                 2697 	inc	r0
   D6A8 F6                 2698 	mov	@r0,a
   D6A9 18                 2699 	dec	r0
   D6AA 76 00              2700 	mov	@r0,#0x00
                           2701 ;	../../Common/modules/cUDP.c:278: port += buf->buf[ind++];
                           2702 ;	genAssign
   D6AC E5 10              2703 	mov	a,_bp
   D6AE 24 05              2704 	add	a,#0x05
   D6B0 F8                 2705 	mov	r0,a
   D6B1 86 04              2706 	mov	ar4,@r0
                           2707 ;	genPlus
   D6B3 E5 10              2708 	mov	a,_bp
   D6B5 24 05              2709 	add	a,#0x05
   D6B7 F8                 2710 	mov	r0,a
                           2711 ;     genPlusIncr
   D6B8 06                 2712 	inc	@r0
                           2713 ;	genPlus
                           2714 ;	Peephole 236.g	used r4 instead of ar4
   D6B9 EC                 2715 	mov	a,r4
                           2716 ;	Peephole 236.a	used r2 instead of ar2
   D6BA 2A                 2717 	add	a,r2
   D6BB FA                 2718 	mov	r2,a
                           2719 ;	Peephole 181	changed mov to clr
   D6BC E4                 2720 	clr	a
                           2721 ;	Peephole 236.b	used r3 instead of ar3
   D6BD 3B                 2722 	addc	a,r3
   D6BE FB                 2723 	mov	r3,a
                           2724 ;	genPointerGet
                           2725 ;	genGenPointerGet
   D6BF 8A 82              2726 	mov	dpl,r2
   D6C1 8B 83              2727 	mov	dph,r3
   D6C3 8F F0              2728 	mov	b,r7
   D6C5 12 E4 9F           2729 	lcall	__gptrget
   D6C8 FA                 2730 	mov	r2,a
                           2731 ;	genCast
   D6C9 7B 00              2732 	mov	r3,#0x00
                           2733 ;	genPlus
   D6CB E5 10              2734 	mov	a,_bp
   D6CD 24 0B              2735 	add	a,#0x0b
   D6CF F8                 2736 	mov	r0,a
                           2737 ;	Peephole 236.g	used r2 instead of ar2
   D6D0 EA                 2738 	mov	a,r2
   D6D1 26                 2739 	add	a,@r0
   D6D2 F6                 2740 	mov	@r0,a
                           2741 ;	Peephole 236.g	used r3 instead of ar3
   D6D3 EB                 2742 	mov	a,r3
   D6D4 08                 2743 	inc	r0
   D6D5 36                 2744 	addc	a,@r0
   D6D6 F6                 2745 	mov	@r0,a
                           2746 ;	../../Common/modules/cUDP.c:279: buf->dst_sa.port=port;
                           2747 ;	genPlus
   D6D7 A8 10              2748 	mov	r0,_bp
   D6D9 08                 2749 	inc	r0
                           2750 ;     genPlusIncr
   D6DA 74 03              2751 	mov	a,#0x03
   D6DC 26                 2752 	add	a,@r0
   D6DD FA                 2753 	mov	r2,a
                           2754 ;	Peephole 181	changed mov to clr
   D6DE E4                 2755 	clr	a
   D6DF 08                 2756 	inc	r0
   D6E0 36                 2757 	addc	a,@r0
   D6E1 FB                 2758 	mov	r3,a
   D6E2 08                 2759 	inc	r0
   D6E3 86 04              2760 	mov	ar4,@r0
                           2761 ;	genPlus
                           2762 ;     genPlusIncr
   D6E5 74 0B              2763 	mov	a,#0x0B
                           2764 ;	Peephole 236.a	used r2 instead of ar2
   D6E7 2A                 2765 	add	a,r2
   D6E8 FA                 2766 	mov	r2,a
                           2767 ;	Peephole 181	changed mov to clr
   D6E9 E4                 2768 	clr	a
                           2769 ;	Peephole 236.b	used r3 instead of ar3
   D6EA 3B                 2770 	addc	a,r3
   D6EB FB                 2771 	mov	r3,a
                           2772 ;	genPointerSet
                           2773 ;	genGenPointerSet
   D6EC 8A 82              2774 	mov	dpl,r2
   D6EE 8B 83              2775 	mov	dph,r3
   D6F0 8C F0              2776 	mov	b,r4
   D6F2 E5 10              2777 	mov	a,_bp
   D6F4 24 0B              2778 	add	a,#0x0b
   D6F6 F8                 2779 	mov	r0,a
   D6F7 E6                 2780 	mov	a,@r0
   D6F8 12 DF B7           2781 	lcall	__gptrput
   D6FB A3                 2782 	inc	dptr
   D6FC 08                 2783 	inc	r0
   D6FD E6                 2784 	mov	a,@r0
   D6FE 12 DF B7           2785 	lcall	__gptrput
                           2786 ;	../../Common/modules/cUDP.c:280: data_length = ((buf->buf_end - buf->buf_ptr) - header_length);
                           2787 ;	genMinus
   D701 E5 10              2788 	mov	a,_bp
   D703 24 19              2789 	add	a,#0x19
   D705 F8                 2790 	mov	r0,a
   D706 E5 10              2791 	mov	a,_bp
   D708 24 1B              2792 	add	a,#0x1b
   D70A F9                 2793 	mov	r1,a
   D70B E6                 2794 	mov	a,@r0
   D70C C3                 2795 	clr	c
   D70D 97                 2796 	subb	a,@r1
   D70E FA                 2797 	mov	r2,a
   D70F 08                 2798 	inc	r0
   D710 E6                 2799 	mov	a,@r0
   D711 09                 2800 	inc	r1
   D712 97                 2801 	subb	a,@r1
   D713 FB                 2802 	mov	r3,a
                           2803 ;	genMinus
   D714 E5 10              2804 	mov	a,_bp
   D716 24 0D              2805 	add	a,#0x0d
   D718 F8                 2806 	mov	r0,a
   D719 EA                 2807 	mov	a,r2
   D71A 24 FA              2808 	add	a,#0xfa
   D71C F6                 2809 	mov	@r0,a
   D71D EB                 2810 	mov	a,r3
   D71E 34 FF              2811 	addc	a,#0xff
   D720 08                 2812 	inc	r0
   D721 F6                 2813 	mov	@r0,a
                           2814 ;	../../Common/modules/cUDP.c:281: length =(data_length + 8);
                           2815 ;	genPlus
   D722 E5 10              2816 	mov	a,_bp
   D724 24 0D              2817 	add	a,#0x0d
   D726 F8                 2818 	mov	r0,a
   D727 E5 10              2819 	mov	a,_bp
   D729 24 0F              2820 	add	a,#0x0f
   D72B F9                 2821 	mov	r1,a
                           2822 ;     genPlusIncr
   D72C 74 08              2823 	mov	a,#0x08
   D72E 26                 2824 	add	a,@r0
   D72F F7                 2825 	mov	@r1,a
                           2826 ;	Peephole 181	changed mov to clr
   D730 E4                 2827 	clr	a
   D731 08                 2828 	inc	r0
   D732 36                 2829 	addc	a,@r0
   D733 09                 2830 	inc	r1
   D734 F7                 2831 	mov	@r1,a
                           2832 ;	../../Common/modules/cUDP.c:471: return pdTRUE;
                           2833 ;	genIpop
   D735 D0 06              2834 	pop	ar6
   D737 D0 05              2835 	pop	ar5
   D739 D0 04              2836 	pop	ar4
                           2837 ;	../../Common/modules/cUDP.c:283: }
   D73B                    2838 00119$:
                           2839 ;	../../Common/modules/cUDP.c:329: ind += 2;
                           2840 ;	genPlus
   D73B E5 10              2841 	mov	a,_bp
   D73D 24 05              2842 	add	a,#0x05
   D73F F8                 2843 	mov	r0,a
                           2844 ;     genPlusIncr
   D740 06                 2845 	inc	@r0
   D741 06                 2846 	inc	@r0
                           2847 ;	../../Common/modules/cUDP.c:330: buf-> buf_ptr = ind;			
                           2848 ;	genCast
   D742 E5 10              2849 	mov	a,_bp
   D744 24 05              2850 	add	a,#0x05
   D746 F8                 2851 	mov	r0,a
   D747 86 03              2852 	mov	ar3,@r0
   D749 7A 00              2853 	mov	r2,#0x00
                           2854 ;	genPointerSet
                           2855 ;	genGenPointerSet
   D74B 8C 82              2856 	mov	dpl,r4
   D74D 8D 83              2857 	mov	dph,r5
   D74F 8E F0              2858 	mov	b,r6
   D751 EB                 2859 	mov	a,r3
   D752 12 DF B7           2860 	lcall	__gptrput
   D755 A3                 2861 	inc	dptr
   D756 EA                 2862 	mov	a,r2
   D757 12 DF B7           2863 	lcall	__gptrput
                           2864 ;	../../Common/modules/cUDP.c:333: if (buf && (buf->dst_sa.port == NPING_PORT || buf->dst_sa.port == UDP_ECHO_PORT) )
                           2865 ;	genIfx
   D75A A8 10              2866 	mov	r0,_bp
   D75C 08                 2867 	inc	r0
   D75D E6                 2868 	mov	a,@r0
   D75E 08                 2869 	inc	r0
   D75F 46                 2870 	orl	a,@r0
   D760 08                 2871 	inc	r0
   D761 46                 2872 	orl	a,@r0
                           2873 ;	genIfxJump
   D762 70 03              2874 	jnz	00194$
   D764 02 DD E5           2875 	ljmp	00142$
   D767                    2876 00194$:
                           2877 ;	genPlus
   D767 A8 10              2878 	mov	r0,_bp
   D769 08                 2879 	inc	r0
                           2880 ;     genPlusIncr
   D76A 74 03              2881 	mov	a,#0x03
   D76C 26                 2882 	add	a,@r0
   D76D FA                 2883 	mov	r2,a
                           2884 ;	Peephole 181	changed mov to clr
   D76E E4                 2885 	clr	a
   D76F 08                 2886 	inc	r0
   D770 36                 2887 	addc	a,@r0
   D771 FB                 2888 	mov	r3,a
   D772 08                 2889 	inc	r0
   D773 86 04              2890 	mov	ar4,@r0
                           2891 ;	genPlus
                           2892 ;     genPlusIncr
   D775 74 0B              2893 	mov	a,#0x0B
                           2894 ;	Peephole 236.a	used r2 instead of ar2
   D777 2A                 2895 	add	a,r2
   D778 FA                 2896 	mov	r2,a
                           2897 ;	Peephole 181	changed mov to clr
   D779 E4                 2898 	clr	a
                           2899 ;	Peephole 236.b	used r3 instead of ar3
   D77A 3B                 2900 	addc	a,r3
   D77B FB                 2901 	mov	r3,a
                           2902 ;	genPointerGet
                           2903 ;	genGenPointerGet
   D77C 8A 82              2904 	mov	dpl,r2
   D77E 8B 83              2905 	mov	dph,r3
   D780 8C F0              2906 	mov	b,r4
   D782 12 E4 9F           2907 	lcall	__gptrget
   D785 FA                 2908 	mov	r2,a
   D786 A3                 2909 	inc	dptr
   D787 12 E4 9F           2910 	lcall	__gptrget
   D78A FB                 2911 	mov	r3,a
                           2912 ;	genCmpEq
                           2913 ;	gencjne
                           2914 ;	gencjneshort
                           2915 ;	Peephole 241.c	optimized compare
   D78B E4                 2916 	clr	a
   D78C BA FE 04           2917 	cjne	r2,#0xFE,00195$
   D78F BB 00 01           2918 	cjne	r3,#0x00,00195$
   D792 04                 2919 	inc	a
   D793                    2920 00195$:
                           2921 ;	Peephole 300	removed redundant label 00196$
                           2922 ;	genIfx
   D793 FC                 2923 	mov	r4,a
                           2924 ;	Peephole 105	removed redundant mov
                           2925 ;	genIfxJump
                           2926 ;	Peephole 108.b	removed ljmp by inverse jump logic
   D794 70 0B              2927 	jnz	00141$
                           2928 ;	Peephole 300	removed redundant label 00197$
                           2929 ;	genCmpEq
                           2930 ;	gencjneshort
   D796 BA 07 05           2931 	cjne	r2,#0x07,00198$
   D799 BB 00 02           2932 	cjne	r3,#0x00,00198$
   D79C 80 03              2933 	sjmp	00199$
   D79E                    2934 00198$:
   D79E 02 DD E5           2935 	ljmp	00142$
   D7A1                    2936 00199$:
   D7A1                    2937 00141$:
                           2938 ;	../../Common/modules/cUDP.c:335: if ((buf->src_sa.port == NPING_PORT && buf->dst_sa.port == NPING_PORT) || (buf->src_sa.port == UDP_ECHO_PORT  && buf->dst_sa.port == UDP_ECHO_PORT) )
                           2939 ;	genPlus
   D7A1 A8 10              2940 	mov	r0,_bp
   D7A3 08                 2941 	inc	r0
                           2942 ;     genPlusIncr
   D7A4 74 10              2943 	mov	a,#0x10
   D7A6 26                 2944 	add	a,@r0
   D7A7 FD                 2945 	mov	r5,a
                           2946 ;	Peephole 181	changed mov to clr
   D7A8 E4                 2947 	clr	a
   D7A9 08                 2948 	inc	r0
   D7AA 36                 2949 	addc	a,@r0
   D7AB FE                 2950 	mov	r6,a
   D7AC 08                 2951 	inc	r0
   D7AD 86 07              2952 	mov	ar7,@r0
                           2953 ;	genPlus
                           2954 ;     genPlusIncr
   D7AF 74 0B              2955 	mov	a,#0x0B
                           2956 ;	Peephole 236.a	used r5 instead of ar5
   D7B1 2D                 2957 	add	a,r5
   D7B2 FD                 2958 	mov	r5,a
                           2959 ;	Peephole 181	changed mov to clr
   D7B3 E4                 2960 	clr	a
                           2961 ;	Peephole 236.b	used r6 instead of ar6
   D7B4 3E                 2962 	addc	a,r6
   D7B5 FE                 2963 	mov	r6,a
                           2964 ;	genPointerGet
                           2965 ;	genGenPointerGet
   D7B6 8D 82              2966 	mov	dpl,r5
   D7B8 8E 83              2967 	mov	dph,r6
   D7BA 8F F0              2968 	mov	b,r7
   D7BC 12 E4 9F           2969 	lcall	__gptrget
   D7BF FD                 2970 	mov	r5,a
   D7C0 A3                 2971 	inc	dptr
   D7C1 12 E4 9F           2972 	lcall	__gptrget
   D7C4 FE                 2973 	mov	r6,a
                           2974 ;	genCmpEq
                           2975 ;	gencjneshort
                           2976 ;	Peephole 112.b	changed ljmp to sjmp
                           2977 ;	Peephole 198.a	optimized misc jump sequence
   D7C5 BD FE 06           2978 	cjne	r5,#0xFE,00124$
   D7C8 BE 00 03           2979 	cjne	r6,#0x00,00124$
                           2980 ;	Peephole 200.b	removed redundant sjmp
                           2981 ;	Peephole 300	removed redundant label 00200$
                           2982 ;	Peephole 300	removed redundant label 00201$
                           2983 ;	genIfx
   D7CB EC                 2984 	mov	a,r4
                           2985 ;	genIfxJump
                           2986 ;	Peephole 108.b	removed ljmp by inverse jump logic
   D7CC 70 0C              2987 	jnz	00120$
                           2988 ;	Peephole 300	removed redundant label 00202$
   D7CE                    2989 00124$:
                           2990 ;	genCmpEq
                           2991 ;	gencjneshort
                           2992 ;	Peephole 112.b	changed ljmp to sjmp
                           2993 ;	Peephole 198.a	optimized misc jump sequence
   D7CE BD 07 20           2994 	cjne	r5,#0x07,00121$
   D7D1 BE 00 1D           2995 	cjne	r6,#0x00,00121$
                           2996 ;	Peephole 200.b	removed redundant sjmp
                           2997 ;	Peephole 300	removed redundant label 00203$
                           2998 ;	Peephole 300	removed redundant label 00204$
                           2999 ;	genCmpEq
                           3000 ;	gencjneshort
                           3001 ;	Peephole 112.b	changed ljmp to sjmp
                           3002 ;	Peephole 198.a	optimized misc jump sequence
   D7D4 BA 07 1A           3003 	cjne	r2,#0x07,00121$
   D7D7 BB 00 17           3004 	cjne	r3,#0x00,00121$
                           3005 ;	Peephole 200.b	removed redundant sjmp
                           3006 ;	Peephole 300	removed redundant label 00205$
                           3007 ;	Peephole 300	removed redundant label 00206$
   D7DA                    3008 00120$:
                           3009 ;	../../Common/modules/cUDP.c:337: stack_buffer_free(buf);
                           3010 ;	genCall
   D7DA A8 10              3011 	mov	r0,_bp
   D7DC 08                 3012 	inc	r0
   D7DD 86 82              3013 	mov	dpl,@r0
   D7DF 08                 3014 	inc	r0
   D7E0 86 83              3015 	mov	dph,@r0
   D7E2 08                 3016 	inc	r0
   D7E3 86 F0              3017 	mov	b,@r0
   D7E5 12 61 FA           3018 	lcall	_stack_buffer_free
                           3019 ;	../../Common/modules/cUDP.c:338: buf=0;						
                           3020 ;	genAssign
   D7E8 A8 10              3021 	mov	r0,_bp
   D7EA 08                 3022 	inc	r0
   D7EB E4                 3023 	clr	a
   D7EC F6                 3024 	mov	@r0,a
   D7ED 08                 3025 	inc	r0
   D7EE F6                 3026 	mov	@r0,a
   D7EF 08                 3027 	inc	r0
   D7F0 F6                 3028 	mov	@r0,a
   D7F1                    3029 00121$:
                           3030 ;	../../Common/modules/cUDP.c:340: if (buf)
                           3031 ;	genIfx
   D7F1 A8 10              3032 	mov	r0,_bp
   D7F3 08                 3033 	inc	r0
   D7F4 E6                 3034 	mov	a,@r0
   D7F5 08                 3035 	inc	r0
   D7F6 46                 3036 	orl	a,@r0
   D7F7 08                 3037 	inc	r0
   D7F8 46                 3038 	orl	a,@r0
                           3039 ;	genIfxJump
   D7F9 70 03              3040 	jnz	00207$
   D7FB 02 DD E5           3041 	ljmp	00142$
   D7FE                    3042 00207$:
                           3043 ;	../../Common/modules/cUDP.c:357: port = buf->dst_sa.port;
                           3044 ;	genPlus
   D7FE A8 10              3045 	mov	r0,_bp
   D800 08                 3046 	inc	r0
                           3047 ;     genPlusIncr
   D801 74 03              3048 	mov	a,#0x03
   D803 26                 3049 	add	a,@r0
   D804 FC                 3050 	mov	r4,a
                           3051 ;	Peephole 181	changed mov to clr
   D805 E4                 3052 	clr	a
   D806 08                 3053 	inc	r0
   D807 36                 3054 	addc	a,@r0
   D808 FD                 3055 	mov	r5,a
   D809 08                 3056 	inc	r0
   D80A 86 06              3057 	mov	ar6,@r0
                           3058 ;	genPlus
   D80C E5 10              3059 	mov	a,_bp
   D80E 24 27              3060 	add	a,#0x27
   D810 F8                 3061 	mov	r0,a
                           3062 ;     genPlusIncr
   D811 74 0B              3063 	mov	a,#0x0B
                           3064 ;	Peephole 236.a	used r4 instead of ar4
   D813 2C                 3065 	add	a,r4
   D814 F6                 3066 	mov	@r0,a
                           3067 ;	Peephole 181	changed mov to clr
   D815 E4                 3068 	clr	a
                           3069 ;	Peephole 236.b	used r5 instead of ar5
   D816 3D                 3070 	addc	a,r5
   D817 08                 3071 	inc	r0
   D818 F6                 3072 	mov	@r0,a
   D819 08                 3073 	inc	r0
   D81A A6 06              3074 	mov	@r0,ar6
                           3075 ;	genPointerGet
                           3076 ;	genGenPointerGet
   D81C E5 10              3077 	mov	a,_bp
   D81E 24 27              3078 	add	a,#0x27
   D820 F8                 3079 	mov	r0,a
   D821 86 82              3080 	mov	dpl,@r0
   D823 08                 3081 	inc	r0
   D824 86 83              3082 	mov	dph,@r0
   D826 08                 3083 	inc	r0
   D827 86 F0              3084 	mov	b,@r0
   D829 12 E4 9F           3085 	lcall	__gptrget
   D82C FA                 3086 	mov	r2,a
   D82D A3                 3087 	inc	dptr
   D82E 12 E4 9F           3088 	lcall	__gptrget
   D831 FB                 3089 	mov	r3,a
                           3090 ;	genAssign
   D832 E5 10              3091 	mov	a,_bp
   D834 24 0B              3092 	add	a,#0x0b
   D836 F8                 3093 	mov	r0,a
   D837 A6 02              3094 	mov	@r0,ar2
   D839 08                 3095 	inc	r0
   D83A A6 03              3096 	mov	@r0,ar3
                           3097 ;	../../Common/modules/cUDP.c:358: buf->dst_sa.port = buf->src_sa.port;
                           3098 ;	genPlus
   D83C A8 10              3099 	mov	r0,_bp
   D83E 08                 3100 	inc	r0
   D83F E5 10              3101 	mov	a,_bp
   D841 24 21              3102 	add	a,#0x21
   D843 F9                 3103 	mov	r1,a
                           3104 ;     genPlusIncr
   D844 74 10              3105 	mov	a,#0x10
   D846 26                 3106 	add	a,@r0
   D847 F7                 3107 	mov	@r1,a
                           3108 ;	Peephole 181	changed mov to clr
   D848 E4                 3109 	clr	a
   D849 08                 3110 	inc	r0
   D84A 36                 3111 	addc	a,@r0
   D84B 09                 3112 	inc	r1
   D84C F7                 3113 	mov	@r1,a
   D84D 08                 3114 	inc	r0
   D84E 09                 3115 	inc	r1
   D84F E6                 3116 	mov	a,@r0
   D850 F7                 3117 	mov	@r1,a
                           3118 ;	genPlus
   D851 E5 10              3119 	mov	a,_bp
   D853 24 21              3120 	add	a,#0x21
   D855 F8                 3121 	mov	r0,a
   D856 E5 10              3122 	mov	a,_bp
   D858 24 1E              3123 	add	a,#0x1e
   D85A F9                 3124 	mov	r1,a
                           3125 ;     genPlusIncr
   D85B 74 0B              3126 	mov	a,#0x0B
   D85D 26                 3127 	add	a,@r0
   D85E F7                 3128 	mov	@r1,a
                           3129 ;	Peephole 181	changed mov to clr
   D85F E4                 3130 	clr	a
   D860 08                 3131 	inc	r0
   D861 36                 3132 	addc	a,@r0
   D862 09                 3133 	inc	r1
   D863 F7                 3134 	mov	@r1,a
   D864 08                 3135 	inc	r0
   D865 09                 3136 	inc	r1
   D866 E6                 3137 	mov	a,@r0
   D867 F7                 3138 	mov	@r1,a
                           3139 ;	genPointerGet
                           3140 ;	genGenPointerGet
   D868 E5 10              3141 	mov	a,_bp
   D86A 24 1E              3142 	add	a,#0x1e
   D86C F8                 3143 	mov	r0,a
   D86D 86 82              3144 	mov	dpl,@r0
   D86F 08                 3145 	inc	r0
   D870 86 83              3146 	mov	dph,@r0
   D872 08                 3147 	inc	r0
   D873 86 F0              3148 	mov	b,@r0
   D875 12 E4 9F           3149 	lcall	__gptrget
   D878 FA                 3150 	mov	r2,a
   D879 A3                 3151 	inc	dptr
   D87A 12 E4 9F           3152 	lcall	__gptrget
   D87D FB                 3153 	mov	r3,a
                           3154 ;	genPointerSet
                           3155 ;	genGenPointerSet
   D87E E5 10              3156 	mov	a,_bp
   D880 24 27              3157 	add	a,#0x27
   D882 F8                 3158 	mov	r0,a
   D883 86 82              3159 	mov	dpl,@r0
   D885 08                 3160 	inc	r0
   D886 86 83              3161 	mov	dph,@r0
   D888 08                 3162 	inc	r0
   D889 86 F0              3163 	mov	b,@r0
   D88B EA                 3164 	mov	a,r2
   D88C 12 DF B7           3165 	lcall	__gptrput
   D88F A3                 3166 	inc	dptr
   D890 EB                 3167 	mov	a,r3
   D891 12 DF B7           3168 	lcall	__gptrput
                           3169 ;	../../Common/modules/cUDP.c:359: buf->src_sa.port = port;
                           3170 ;	genPointerSet
                           3171 ;	genGenPointerSet
   D894 E5 10              3172 	mov	a,_bp
   D896 24 1E              3173 	add	a,#0x1e
   D898 F8                 3174 	mov	r0,a
   D899 86 82              3175 	mov	dpl,@r0
   D89B 08                 3176 	inc	r0
   D89C 86 83              3177 	mov	dph,@r0
   D89E 08                 3178 	inc	r0
   D89F 86 F0              3179 	mov	b,@r0
   D8A1 E5 10              3180 	mov	a,_bp
   D8A3 24 0B              3181 	add	a,#0x0b
   D8A5 F9                 3182 	mov	r1,a
   D8A6 E7                 3183 	mov	a,@r1
   D8A7 12 DF B7           3184 	lcall	__gptrput
   D8AA A3                 3185 	inc	dptr
   D8AB 09                 3186 	inc	r1
   D8AC E7                 3187 	mov	a,@r1
   D8AD 12 DF B7           3188 	lcall	__gptrput
                           3189 ;	../../Common/modules/cUDP.c:360: buf->dst_sa.addr_type = buf->src_sa.addr_type;
                           3190 ;	genPointerGet
                           3191 ;	genGenPointerGet
   D8B0 E5 10              3192 	mov	a,_bp
   D8B2 24 21              3193 	add	a,#0x21
   D8B4 F8                 3194 	mov	r0,a
   D8B5 86 82              3195 	mov	dpl,@r0
   D8B7 08                 3196 	inc	r0
   D8B8 86 83              3197 	mov	dph,@r0
   D8BA 08                 3198 	inc	r0
   D8BB 86 F0              3199 	mov	b,@r0
   D8BD 12 E4 9F           3200 	lcall	__gptrget
                           3201 ;	genPointerSet
                           3202 ;	genGenPointerSet
   D8C0 FA                 3203 	mov	r2,a
   D8C1 8C 82              3204 	mov	dpl,r4
   D8C3 8D 83              3205 	mov	dph,r5
   D8C5 8E F0              3206 	mov	b,r6
                           3207 ;	Peephole 191	removed redundant mov
   D8C7 12 DF B7           3208 	lcall	__gptrput
                           3209 ;	../../Common/modules/cUDP.c:361: buf->src_sa.addr_type = ADDR_NONE;
                           3210 ;	genPointerSet
                           3211 ;	genGenPointerSet
   D8CA E5 10              3212 	mov	a,_bp
   D8CC 24 21              3213 	add	a,#0x21
   D8CE F8                 3214 	mov	r0,a
   D8CF 86 82              3215 	mov	dpl,@r0
   D8D1 08                 3216 	inc	r0
   D8D2 86 83              3217 	mov	dph,@r0
   D8D4 08                 3218 	inc	r0
   D8D5 86 F0              3219 	mov	b,@r0
                           3220 ;	Peephole 181	changed mov to clr
   D8D7 E4                 3221 	clr	a
   D8D8 12 DF B7           3222 	lcall	__gptrput
                           3223 ;	../../Common/modules/cUDP.c:362: if(buf->dst_sa.addr_type == ADDR_802_15_4_PAN_LONG)
                           3224 ;	genCmpEq
                           3225 ;	gencjneshort
                           3226 ;	Peephole 112.b	changed ljmp to sjmp
                           3227 ;	Peephole 198.b	optimized misc jump sequence
   D8DB BA 04 04           3228 	cjne	r2,#0x04,00126$
                           3229 ;	Peephole 200.b	removed redundant sjmp
                           3230 ;	Peephole 300	removed redundant label 00208$
                           3231 ;	Peephole 300	removed redundant label 00209$
                           3232 ;	../../Common/modules/cUDP.c:363: dest_length=8;
                           3233 ;	genAssign
   D8DE 7A 08              3234 	mov	r2,#0x08
                           3235 ;	Peephole 112.b	changed ljmp to sjmp
   D8E0 80 02              3236 	sjmp	00172$
   D8E2                    3237 00126$:
                           3238 ;	../../Common/modules/cUDP.c:365: dest_length=2;
                           3239 ;	genAssign
   D8E2 7A 02              3240 	mov	r2,#0x02
                           3241 ;	../../Common/modules/cUDP.c:367: for (i=0; i < dest_length; i++)
   D8E4                    3242 00172$:
                           3243 ;	genPlus
                           3244 ;     genPlusIncr
   D8E4 74 01              3245 	mov	a,#0x01
                           3246 ;	Peephole 236.a	used r4 instead of ar4
   D8E6 2C                 3247 	add	a,r4
   D8E7 FF                 3248 	mov	r7,a
                           3249 ;	Peephole 181	changed mov to clr
   D8E8 E4                 3250 	clr	a
                           3251 ;	Peephole 236.b	used r5 instead of ar5
   D8E9 3D                 3252 	addc	a,r5
   D8EA FD                 3253 	mov	r5,a
                           3254 ;	genPlus
   D8EB E5 10              3255 	mov	a,_bp
   D8ED 24 21              3256 	add	a,#0x21
   D8EF F8                 3257 	mov	r0,a
                           3258 ;     genPlusIncr
   D8F0 74 01              3259 	mov	a,#0x01
   D8F2 26                 3260 	add	a,@r0
   D8F3 F6                 3261 	mov	@r0,a
                           3262 ;	Peephole 181	changed mov to clr
   D8F4 E4                 3263 	clr	a
   D8F5 08                 3264 	inc	r0
   D8F6 36                 3265 	addc	a,@r0
   D8F7 F6                 3266 	mov	@r0,a
                           3267 ;	genAssign
   D8F8 E5 10              3268 	mov	a,_bp
   D8FA 24 07              3269 	add	a,#0x07
   D8FC F8                 3270 	mov	r0,a
   D8FD 76 00              3271 	mov	@r0,#0x00
   D8FF                    3272 00148$:
                           3273 ;	genCmpLt
   D8FF E5 10              3274 	mov	a,_bp
   D901 24 07              3275 	add	a,#0x07
   D903 F8                 3276 	mov	r0,a
                           3277 ;	genCmp
   D904 C3                 3278 	clr	c
   D905 E6                 3279 	mov	a,@r0
   D906 9A                 3280 	subb	a,r2
                           3281 ;	genIfxJump
                           3282 ;	Peephole 108.a	removed ljmp by inverse jump logic
   D907 50 4F              3283 	jnc	00151$
                           3284 ;	Peephole 300	removed redundant label 00210$
                           3285 ;	../../Common/modules/cUDP.c:369: buf->dst_sa.address[i] = buf->src_sa.address[i];
                           3286 ;	genIpush
   D909 C0 02              3287 	push	ar2
                           3288 ;	genPlus
   D90B E5 10              3289 	mov	a,_bp
   D90D 24 07              3290 	add	a,#0x07
   D90F F8                 3291 	mov	r0,a
   D910 E5 10              3292 	mov	a,_bp
   D912 24 24              3293 	add	a,#0x24
   D914 F9                 3294 	mov	r1,a
   D915 E6                 3295 	mov	a,@r0
                           3296 ;	Peephole 236.a	used r7 instead of ar7
   D916 2F                 3297 	add	a,r7
   D917 F7                 3298 	mov	@r1,a
                           3299 ;	Peephole 181	changed mov to clr
   D918 E4                 3300 	clr	a
                           3301 ;	Peephole 236.b	used r5 instead of ar5
   D919 3D                 3302 	addc	a,r5
   D91A 09                 3303 	inc	r1
   D91B F7                 3304 	mov	@r1,a
   D91C 09                 3305 	inc	r1
   D91D A7 06              3306 	mov	@r1,ar6
                           3307 ;	genPlus
   D91F E5 10              3308 	mov	a,_bp
   D921 24 21              3309 	add	a,#0x21
   D923 F8                 3310 	mov	r0,a
   D924 E5 10              3311 	mov	a,_bp
   D926 24 07              3312 	add	a,#0x07
   D928 F9                 3313 	mov	r1,a
   D929 E7                 3314 	mov	a,@r1
   D92A 26                 3315 	add	a,@r0
   D92B FA                 3316 	mov	r2,a
                           3317 ;	Peephole 181	changed mov to clr
   D92C E4                 3318 	clr	a
   D92D 08                 3319 	inc	r0
   D92E 36                 3320 	addc	a,@r0
   D92F FB                 3321 	mov	r3,a
   D930 08                 3322 	inc	r0
   D931 86 04              3323 	mov	ar4,@r0
                           3324 ;	genPointerGet
                           3325 ;	genGenPointerGet
   D933 8A 82              3326 	mov	dpl,r2
   D935 8B 83              3327 	mov	dph,r3
   D937 8C F0              3328 	mov	b,r4
   D939 12 E4 9F           3329 	lcall	__gptrget
   D93C FA                 3330 	mov	r2,a
                           3331 ;	genPointerSet
                           3332 ;	genGenPointerSet
   D93D E5 10              3333 	mov	a,_bp
   D93F 24 24              3334 	add	a,#0x24
   D941 F8                 3335 	mov	r0,a
   D942 86 82              3336 	mov	dpl,@r0
   D944 08                 3337 	inc	r0
   D945 86 83              3338 	mov	dph,@r0
   D947 08                 3339 	inc	r0
   D948 86 F0              3340 	mov	b,@r0
   D94A EA                 3341 	mov	a,r2
   D94B 12 DF B7           3342 	lcall	__gptrput
                           3343 ;	../../Common/modules/cUDP.c:367: for (i=0; i < dest_length; i++)
                           3344 ;	genPlus
   D94E E5 10              3345 	mov	a,_bp
   D950 24 07              3346 	add	a,#0x07
   D952 F8                 3347 	mov	r0,a
                           3348 ;     genPlusIncr
   D953 06                 3349 	inc	@r0
                           3350 ;	genIpop
   D954 D0 02              3351 	pop	ar2
                           3352 ;	Peephole 112.b	changed ljmp to sjmp
   D956 80 A7              3353 	sjmp	00148$
   D958                    3354 00151$:
                           3355 ;	../../Common/modules/cUDP.c:387: if(use_compress)
                           3356 ;	genAssign
   D958 90 F0 F5           3357 	mov	dptr,#_use_compress
   D95B E0                 3358 	movx	a,@dptr
                           3359 ;	genIfx
   D95C FA                 3360 	mov	r2,a
                           3361 ;	Peephole 105	removed redundant mov
                           3362 ;	genIfxJump
   D95D 70 03              3363 	jnz	00211$
   D95F 02 D9 E0           3364 	ljmp	00133$
   D962                    3365 00211$:
                           3366 ;	../../Common/modules/cUDP.c:391: if(buf->src_sa.port > HC2_PORT_ENCODE && buf->dst_sa.port > HC2_PORT_ENCODE)
                           3367 ;	genPointerGet
                           3368 ;	genGenPointerGet
   D962 E5 10              3369 	mov	a,_bp
   D964 24 1E              3370 	add	a,#0x1e
   D966 F8                 3371 	mov	r0,a
   D967 86 82              3372 	mov	dpl,@r0
   D969 08                 3373 	inc	r0
   D96A 86 83              3374 	mov	dph,@r0
   D96C 08                 3375 	inc	r0
   D96D 86 F0              3376 	mov	b,@r0
   D96F 12 E4 9F           3377 	lcall	__gptrget
   D972 FA                 3378 	mov	r2,a
   D973 A3                 3379 	inc	dptr
   D974 12 E4 9F           3380 	lcall	__gptrget
   D977 FB                 3381 	mov	r3,a
                           3382 ;	genCmpGt
                           3383 ;	genCmp
   D978 C3                 3384 	clr	c
   D979 74 AF              3385 	mov	a,#0xAF
   D97B 9A                 3386 	subb	a,r2
   D97C 74 F0              3387 	mov	a,#0xF0
   D97E 9B                 3388 	subb	a,r3
                           3389 ;	genIfxJump
                           3390 ;	Peephole 108.a	removed ljmp by inverse jump logic
   D97F 50 56              3391 	jnc	00129$
                           3392 ;	Peephole 300	removed redundant label 00212$
                           3393 ;	genPointerGet
                           3394 ;	genGenPointerGet
   D981 E5 10              3395 	mov	a,_bp
   D983 24 27              3396 	add	a,#0x27
   D985 F8                 3397 	mov	r0,a
   D986 86 82              3398 	mov	dpl,@r0
   D988 08                 3399 	inc	r0
   D989 86 83              3400 	mov	dph,@r0
   D98B 08                 3401 	inc	r0
   D98C 86 F0              3402 	mov	b,@r0
   D98E 12 E4 9F           3403 	lcall	__gptrget
   D991 FA                 3404 	mov	r2,a
   D992 A3                 3405 	inc	dptr
   D993 12 E4 9F           3406 	lcall	__gptrget
   D996 FB                 3407 	mov	r3,a
                           3408 ;	genCmpGt
                           3409 ;	genCmp
   D997 C3                 3410 	clr	c
   D998 74 AF              3411 	mov	a,#0xAF
   D99A 9A                 3412 	subb	a,r2
   D99B 74 F0              3413 	mov	a,#0xF0
   D99D 9B                 3414 	subb	a,r3
                           3415 ;	genIfxJump
                           3416 ;	Peephole 108.a	removed ljmp by inverse jump logic
   D99E 50 37              3417 	jnc	00129$
                           3418 ;	Peephole 300	removed redundant label 00213$
                           3419 ;	../../Common/modules/cUDP.c:394: portfield = (buf->src_sa.port - HC2_ENCODE_P_VALUE);
                           3420 ;	genPointerGet
                           3421 ;	genGenPointerGet
   D9A0 E5 10              3422 	mov	a,_bp
   D9A2 24 1E              3423 	add	a,#0x1e
   D9A4 F8                 3424 	mov	r0,a
   D9A5 86 82              3425 	mov	dpl,@r0
   D9A7 08                 3426 	inc	r0
   D9A8 86 83              3427 	mov	dph,@r0
   D9AA 08                 3428 	inc	r0
   D9AB 86 F0              3429 	mov	b,@r0
   D9AD 12 E4 9F           3430 	lcall	__gptrget
   D9B0 FA                 3431 	mov	r2,a
   D9B1 A3                 3432 	inc	dptr
   D9B2 12 E4 9F           3433 	lcall	__gptrget
   D9B5 FB                 3434 	mov	r3,a
                           3435 ;	genCast
                           3436 ;	genMinus
   D9B6 EA                 3437 	mov	a,r2
   D9B7 24 50              3438 	add	a,#0x50
   D9B9 FA                 3439 	mov	r2,a
                           3440 ;	genAssign
   D9BA E5 10              3441 	mov	a,_bp
   D9BC 24 11              3442 	add	a,#0x11
   D9BE F8                 3443 	mov	r0,a
   D9BF A6 02              3444 	mov	@r0,ar2
                           3445 ;	../../Common/modules/cUDP.c:396: portfield |= ((buf->src_sa.port - HC2_ENCODE_P_VALUE) << 4);
                           3446 ;	genLeftShift
                           3447 ;	genLeftShiftLiteral
                           3448 ;	genlshOne
   D9C1 EA                 3449 	mov	a,r2
   D9C2 C4                 3450 	swap	a
   D9C3 54 F0              3451 	anl	a,#0xf0
   D9C5 FA                 3452 	mov	r2,a
                           3453 ;	genOr
   D9C6 E5 10              3454 	mov	a,_bp
   D9C8 24 11              3455 	add	a,#0x11
   D9CA F8                 3456 	mov	r0,a
   D9CB EA                 3457 	mov	a,r2
   D9CC 46                 3458 	orl	a,@r0
   D9CD F6                 3459 	mov	@r0,a
                           3460 ;	../../Common/modules/cUDP.c:397: tmp_8++;
                           3461 ;	genAssign
   D9CE E5 10              3462 	mov	a,_bp
   D9D0 24 04              3463 	add	a,#0x04
   D9D2 F8                 3464 	mov	r0,a
   D9D3 76 03              3465 	mov	@r0,#0x03
                           3466 ;	Peephole 112.b	changed ljmp to sjmp
   D9D5 80 10              3467 	sjmp	00134$
   D9D7                    3468 00129$:
                           3469 ;	../../Common/modules/cUDP.c:400: tmp_8 +=4;
                           3470 ;	genAssign
   D9D7 E5 10              3471 	mov	a,_bp
   D9D9 24 04              3472 	add	a,#0x04
   D9DB F8                 3473 	mov	r0,a
   D9DC 76 06              3474 	mov	@r0,#0x06
                           3475 ;	Peephole 112.b	changed ljmp to sjmp
   D9DE 80 07              3476 	sjmp	00134$
   D9E0                    3477 00133$:
                           3478 ;	../../Common/modules/cUDP.c:403: tmp_8=8;
                           3479 ;	genAssign
   D9E0 E5 10              3480 	mov	a,_bp
   D9E2 24 04              3481 	add	a,#0x04
   D9E4 F8                 3482 	mov	r0,a
   D9E5 76 08              3483 	mov	@r0,#0x08
   D9E7                    3484 00134$:
                           3485 ;	../../Common/modules/cUDP.c:405: buf->buf_ptr -= tmp_8;
                           3486 ;	genIpush
                           3487 ;	genPlus
   D9E7 A8 10              3488 	mov	r0,_bp
   D9E9 08                 3489 	inc	r0
                           3490 ;     genPlusIncr
   D9EA 74 20              3491 	mov	a,#0x20
   D9EC 26                 3492 	add	a,@r0
   D9ED FA                 3493 	mov	r2,a
                           3494 ;	Peephole 181	changed mov to clr
   D9EE E4                 3495 	clr	a
   D9EF 08                 3496 	inc	r0
   D9F0 36                 3497 	addc	a,@r0
   D9F1 FB                 3498 	mov	r3,a
   D9F2 08                 3499 	inc	r0
   D9F3 86 04              3500 	mov	ar4,@r0
                           3501 ;	genPointerGet
                           3502 ;	genGenPointerGet
   D9F5 8A 82              3503 	mov	dpl,r2
   D9F7 8B 83              3504 	mov	dph,r3
   D9F9 8C F0              3505 	mov	b,r4
   D9FB E5 10              3506 	mov	a,_bp
   D9FD 24 24              3507 	add	a,#0x24
   D9FF F8                 3508 	mov	r0,a
   DA00 12 E4 9F           3509 	lcall	__gptrget
   DA03 F6                 3510 	mov	@r0,a
   DA04 A3                 3511 	inc	dptr
   DA05 12 E4 9F           3512 	lcall	__gptrget
   DA08 08                 3513 	inc	r0
   DA09 F6                 3514 	mov	@r0,a
                           3515 ;	genCast
   DA0A E5 10              3516 	mov	a,_bp
   DA0C 24 04              3517 	add	a,#0x04
   DA0E F8                 3518 	mov	r0,a
   DA0F 86 07              3519 	mov	ar7,@r0
   DA11 7D 00              3520 	mov	r5,#0x00
                           3521 ;	genMinus
   DA13 E5 10              3522 	mov	a,_bp
   DA15 24 24              3523 	add	a,#0x24
   DA17 F8                 3524 	mov	r0,a
   DA18 E6                 3525 	mov	a,@r0
   DA19 C3                 3526 	clr	c
                           3527 ;	Peephole 236.l	used r7 instead of ar7
   DA1A 9F                 3528 	subb	a,r7
   DA1B FF                 3529 	mov	r7,a
   DA1C 08                 3530 	inc	r0
   DA1D E6                 3531 	mov	a,@r0
                           3532 ;	Peephole 236.l	used r5 instead of ar5
   DA1E 9D                 3533 	subb	a,r5
   DA1F FD                 3534 	mov	r5,a
                           3535 ;	genPointerSet
                           3536 ;	genGenPointerSet
   DA20 8A 82              3537 	mov	dpl,r2
   DA22 8B 83              3538 	mov	dph,r3
   DA24 8C F0              3539 	mov	b,r4
   DA26 EF                 3540 	mov	a,r7
   DA27 12 DF B7           3541 	lcall	__gptrput
   DA2A A3                 3542 	inc	dptr
   DA2B ED                 3543 	mov	a,r5
   DA2C 12 DF B7           3544 	lcall	__gptrput
                           3545 ;	../../Common/modules/cUDP.c:406: ind = buf->buf_ptr;
                           3546 ;	genCast
   DA2F E5 10              3547 	mov	a,_bp
   DA31 24 05              3548 	add	a,#0x05
   DA33 F8                 3549 	mov	r0,a
   DA34 A6 07              3550 	mov	@r0,ar7
                           3551 ;	../../Common/modules/cUDP.c:407: switch (tmp_8)
                           3552 ;	genCmpEq
   DA36 E5 10              3553 	mov	a,_bp
   DA38 24 04              3554 	add	a,#0x04
   DA3A F8                 3555 	mov	r0,a
                           3556 ;	gencjne
                           3557 ;	gencjneshort
                           3558 ;	Peephole 241.h	optimized compare
   DA3B E4                 3559 	clr	a
   DA3C B6 03 01           3560 	cjne	@r0,#0x03,00214$
   DA3F 04                 3561 	inc	a
   DA40                    3562 00214$:
                           3563 ;	Peephole 300	removed redundant label 00215$
                           3564 ;	genIpop
                           3565 ;	genIfx
                           3566 ;	genIfxJump
   DA40 60 03              3567 	jz	00216$
   DA42 02 DB 64           3568 	ljmp	00136$
   DA45                    3569 00216$:
                           3570 ;	genCmpEq
   DA45 E5 10              3571 	mov	a,_bp
   DA47 24 04              3572 	add	a,#0x04
   DA49 F8                 3573 	mov	r0,a
                           3574 ;	gencjneshort
   DA4A B6 06 02           3575 	cjne	@r0,#0x06,00217$
                           3576 ;	Peephole 112.b	changed ljmp to sjmp
   DA4D 80 0E              3577 	sjmp	00135$
   DA4F                    3578 00217$:
                           3579 ;	genCmpEq
   DA4F E5 10              3580 	mov	a,_bp
   DA51 24 04              3581 	add	a,#0x04
   DA53 F8                 3582 	mov	r0,a
                           3583 ;	gencjneshort
   DA54 B6 08 03           3584 	cjne	@r0,#0x08,00218$
   DA57 02 DB B7           3585 	ljmp	00137$
   DA5A                    3586 00218$:
   DA5A 02 DD 21           3587 	ljmp	00138$
                           3588 ;	../../Common/modules/cUDP.c:409: case 6:
   DA5D                    3589 00135$:
                           3590 ;	../../Common/modules/cUDP.c:410: buf->options.lowpan_compressed = LENGTH_COMPRESSED_HC_UDP; 
                           3591 ;	genPlus
   DA5D A8 10              3592 	mov	r0,_bp
   DA5F 08                 3593 	inc	r0
                           3594 ;     genPlusIncr
   DA60 74 26              3595 	mov	a,#0x26
   DA62 26                 3596 	add	a,@r0
   DA63 FA                 3597 	mov	r2,a
                           3598 ;	Peephole 181	changed mov to clr
   DA64 E4                 3599 	clr	a
   DA65 08                 3600 	inc	r0
   DA66 36                 3601 	addc	a,@r0
   DA67 FB                 3602 	mov	r3,a
   DA68 08                 3603 	inc	r0
   DA69 86 04              3604 	mov	ar4,@r0
                           3605 ;	genPlus
                           3606 ;     genPlusIncr
   DA6B 74 05              3607 	mov	a,#0x05
                           3608 ;	Peephole 236.a	used r2 instead of ar2
   DA6D 2A                 3609 	add	a,r2
   DA6E FA                 3610 	mov	r2,a
                           3611 ;	Peephole 181	changed mov to clr
   DA6F E4                 3612 	clr	a
                           3613 ;	Peephole 236.b	used r3 instead of ar3
   DA70 3B                 3614 	addc	a,r3
   DA71 FB                 3615 	mov	r3,a
                           3616 ;	genPointerSet
                           3617 ;	genGenPointerSet
   DA72 8A 82              3618 	mov	dpl,r2
   DA74 8B 83              3619 	mov	dph,r3
   DA76 8C F0              3620 	mov	b,r4
   DA78 74 04              3621 	mov	a,#0x04
   DA7A 12 DF B7           3622 	lcall	__gptrput
                           3623 ;	../../Common/modules/cUDP.c:411: buf->buf[ind++] = (buf->src_sa.port >> 8);		
                           3624 ;	genPlus
   DA7D A8 10              3625 	mov	r0,_bp
   DA7F 08                 3626 	inc	r0
                           3627 ;     genPlusIncr
   DA80 74 2C              3628 	mov	a,#0x2C
   DA82 26                 3629 	add	a,@r0
   DA83 FB                 3630 	mov	r3,a
                           3631 ;	Peephole 181	changed mov to clr
   DA84 E4                 3632 	clr	a
   DA85 08                 3633 	inc	r0
   DA86 36                 3634 	addc	a,@r0
   DA87 FD                 3635 	mov	r5,a
   DA88 08                 3636 	inc	r0
   DA89 86 06              3637 	mov	ar6,@r0
                           3638 ;	genAssign
   DA8B E5 10              3639 	mov	a,_bp
   DA8D 24 05              3640 	add	a,#0x05
   DA8F F8                 3641 	mov	r0,a
   DA90 86 02              3642 	mov	ar2,@r0
                           3643 ;	genPlus
   DA92 E5 10              3644 	mov	a,_bp
   DA94 24 05              3645 	add	a,#0x05
   DA96 F8                 3646 	mov	r0,a
                           3647 ;     genPlusIncr
   DA97 06                 3648 	inc	@r0
                           3649 ;	genPlus
   DA98 E5 10              3650 	mov	a,_bp
   DA9A 24 21              3651 	add	a,#0x21
   DA9C F8                 3652 	mov	r0,a
                           3653 ;	Peephole 236.g	used r2 instead of ar2
   DA9D EA                 3654 	mov	a,r2
                           3655 ;	Peephole 236.a	used r3 instead of ar3
   DA9E 2B                 3656 	add	a,r3
   DA9F F6                 3657 	mov	@r0,a
                           3658 ;	Peephole 181	changed mov to clr
   DAA0 E4                 3659 	clr	a
                           3660 ;	Peephole 236.b	used r5 instead of ar5
   DAA1 3D                 3661 	addc	a,r5
   DAA2 08                 3662 	inc	r0
   DAA3 F6                 3663 	mov	@r0,a
   DAA4 08                 3664 	inc	r0
   DAA5 A6 06              3665 	mov	@r0,ar6
                           3666 ;	genPointerGet
                           3667 ;	genGenPointerGet
   DAA7 E5 10              3668 	mov	a,_bp
   DAA9 24 1E              3669 	add	a,#0x1e
   DAAB F8                 3670 	mov	r0,a
   DAAC 86 82              3671 	mov	dpl,@r0
   DAAE 08                 3672 	inc	r0
   DAAF 86 83              3673 	mov	dph,@r0
   DAB1 08                 3674 	inc	r0
   DAB2 86 F0              3675 	mov	b,@r0
   DAB4 12 E4 9F           3676 	lcall	__gptrget
   DAB7 FA                 3677 	mov	r2,a
   DAB8 A3                 3678 	inc	dptr
   DAB9 12 E4 9F           3679 	lcall	__gptrget
   DABC FF                 3680 	mov	r7,a
                           3681 ;	genGetByte
   DABD 8F 04              3682 	mov	ar4,r7
                           3683 ;	genPointerSet
                           3684 ;	genGenPointerSet
   DABF E5 10              3685 	mov	a,_bp
   DAC1 24 21              3686 	add	a,#0x21
   DAC3 F8                 3687 	mov	r0,a
   DAC4 86 82              3688 	mov	dpl,@r0
   DAC6 08                 3689 	inc	r0
   DAC7 86 83              3690 	mov	dph,@r0
   DAC9 08                 3691 	inc	r0
   DACA 86 F0              3692 	mov	b,@r0
   DACC EC                 3693 	mov	a,r4
   DACD 12 DF B7           3694 	lcall	__gptrput
                           3695 ;	../../Common/modules/cUDP.c:412: buf->buf[ind++] = (uint8_t) buf->src_sa.port;
                           3696 ;	genAssign
   DAD0 E5 10              3697 	mov	a,_bp
   DAD2 24 05              3698 	add	a,#0x05
   DAD4 F8                 3699 	mov	r0,a
   DAD5 86 04              3700 	mov	ar4,@r0
                           3701 ;	genPlus
   DAD7 E5 10              3702 	mov	a,_bp
   DAD9 24 05              3703 	add	a,#0x05
   DADB F8                 3704 	mov	r0,a
                           3705 ;     genPlusIncr
   DADC 06                 3706 	inc	@r0
                           3707 ;	genPlus
   DADD E5 10              3708 	mov	a,_bp
   DADF 24 21              3709 	add	a,#0x21
   DAE1 F8                 3710 	mov	r0,a
                           3711 ;	Peephole 236.g	used r4 instead of ar4
   DAE2 EC                 3712 	mov	a,r4
                           3713 ;	Peephole 236.a	used r3 instead of ar3
   DAE3 2B                 3714 	add	a,r3
   DAE4 F6                 3715 	mov	@r0,a
                           3716 ;	Peephole 181	changed mov to clr
   DAE5 E4                 3717 	clr	a
                           3718 ;	Peephole 236.b	used r5 instead of ar5
   DAE6 3D                 3719 	addc	a,r5
   DAE7 08                 3720 	inc	r0
   DAE8 F6                 3721 	mov	@r0,a
   DAE9 08                 3722 	inc	r0
   DAEA A6 06              3723 	mov	@r0,ar6
                           3724 ;	genCast
                           3725 ;	genPointerSet
                           3726 ;	genGenPointerSet
   DAEC E5 10              3727 	mov	a,_bp
   DAEE 24 21              3728 	add	a,#0x21
   DAF0 F8                 3729 	mov	r0,a
   DAF1 86 82              3730 	mov	dpl,@r0
   DAF3 08                 3731 	inc	r0
   DAF4 86 83              3732 	mov	dph,@r0
   DAF6 08                 3733 	inc	r0
   DAF7 86 F0              3734 	mov	b,@r0
   DAF9 EA                 3735 	mov	a,r2
   DAFA 12 DF B7           3736 	lcall	__gptrput
                           3737 ;	../../Common/modules/cUDP.c:413: buf->buf[ind++] = (buf->dst_sa.port >> 8);		
                           3738 ;	genAssign
   DAFD E5 10              3739 	mov	a,_bp
   DAFF 24 05              3740 	add	a,#0x05
   DB01 F8                 3741 	mov	r0,a
   DB02 86 02              3742 	mov	ar2,@r0
                           3743 ;	genPlus
   DB04 E5 10              3744 	mov	a,_bp
   DB06 24 05              3745 	add	a,#0x05
   DB08 F8                 3746 	mov	r0,a
                           3747 ;     genPlusIncr
   DB09 06                 3748 	inc	@r0
                           3749 ;	genPlus
   DB0A E5 10              3750 	mov	a,_bp
   DB0C 24 21              3751 	add	a,#0x21
   DB0E F8                 3752 	mov	r0,a
                           3753 ;	Peephole 236.g	used r2 instead of ar2
   DB0F EA                 3754 	mov	a,r2
                           3755 ;	Peephole 236.a	used r3 instead of ar3
   DB10 2B                 3756 	add	a,r3
   DB11 F6                 3757 	mov	@r0,a
                           3758 ;	Peephole 181	changed mov to clr
   DB12 E4                 3759 	clr	a
                           3760 ;	Peephole 236.b	used r5 instead of ar5
   DB13 3D                 3761 	addc	a,r5
   DB14 08                 3762 	inc	r0
   DB15 F6                 3763 	mov	@r0,a
   DB16 08                 3764 	inc	r0
   DB17 A6 06              3765 	mov	@r0,ar6
                           3766 ;	genPointerGet
                           3767 ;	genGenPointerGet
   DB19 E5 10              3768 	mov	a,_bp
   DB1B 24 27              3769 	add	a,#0x27
   DB1D F8                 3770 	mov	r0,a
   DB1E 86 82              3771 	mov	dpl,@r0
   DB20 08                 3772 	inc	r0
   DB21 86 83              3773 	mov	dph,@r0
   DB23 08                 3774 	inc	r0
   DB24 86 F0              3775 	mov	b,@r0
   DB26 12 E4 9F           3776 	lcall	__gptrget
   DB29 FA                 3777 	mov	r2,a
   DB2A A3                 3778 	inc	dptr
   DB2B 12 E4 9F           3779 	lcall	__gptrget
   DB2E FF                 3780 	mov	r7,a
                           3781 ;	genGetByte
   DB2F 8F 04              3782 	mov	ar4,r7
                           3783 ;	genPointerSet
                           3784 ;	genGenPointerSet
   DB31 E5 10              3785 	mov	a,_bp
   DB33 24 21              3786 	add	a,#0x21
   DB35 F8                 3787 	mov	r0,a
   DB36 86 82              3788 	mov	dpl,@r0
   DB38 08                 3789 	inc	r0
   DB39 86 83              3790 	mov	dph,@r0
   DB3B 08                 3791 	inc	r0
   DB3C 86 F0              3792 	mov	b,@r0
   DB3E EC                 3793 	mov	a,r4
   DB3F 12 DF B7           3794 	lcall	__gptrput
                           3795 ;	../../Common/modules/cUDP.c:414: buf->buf[ind++] = (uint8_t)buf->dst_sa.port;
                           3796 ;	genAssign
   DB42 E5 10              3797 	mov	a,_bp
   DB44 24 05              3798 	add	a,#0x05
   DB46 F8                 3799 	mov	r0,a
   DB47 86 04              3800 	mov	ar4,@r0
                           3801 ;	genPlus
   DB49 E5 10              3802 	mov	a,_bp
   DB4B 24 05              3803 	add	a,#0x05
   DB4D F8                 3804 	mov	r0,a
                           3805 ;     genPlusIncr
   DB4E 06                 3806 	inc	@r0
                           3807 ;	genPlus
                           3808 ;	Peephole 236.g	used r4 instead of ar4
   DB4F EC                 3809 	mov	a,r4
                           3810 ;	Peephole 236.a	used r3 instead of ar3
   DB50 2B                 3811 	add	a,r3
   DB51 FB                 3812 	mov	r3,a
                           3813 ;	Peephole 181	changed mov to clr
   DB52 E4                 3814 	clr	a
                           3815 ;	Peephole 236.b	used r5 instead of ar5
   DB53 3D                 3816 	addc	a,r5
   DB54 FD                 3817 	mov	r5,a
   DB55 8E 04              3818 	mov	ar4,r6
                           3819 ;	genCast
                           3820 ;	genPointerSet
                           3821 ;	genGenPointerSet
   DB57 8B 82              3822 	mov	dpl,r3
   DB59 8D 83              3823 	mov	dph,r5
   DB5B 8C F0              3824 	mov	b,r4
   DB5D EA                 3825 	mov	a,r2
   DB5E 12 DF B7           3826 	lcall	__gptrput
                           3827 ;	../../Common/modules/cUDP.c:415: break;
   DB61 02 DD 21           3828 	ljmp	00138$
                           3829 ;	../../Common/modules/cUDP.c:417: case 3:
   DB64                    3830 00136$:
                           3831 ;	../../Common/modules/cUDP.c:418: buf->options.lowpan_compressed = COMPRESSED_HC_UDP; 
                           3832 ;	genPlus
   DB64 A8 10              3833 	mov	r0,_bp
   DB66 08                 3834 	inc	r0
                           3835 ;     genPlusIncr
   DB67 74 26              3836 	mov	a,#0x26
   DB69 26                 3837 	add	a,@r0
   DB6A FA                 3838 	mov	r2,a
                           3839 ;	Peephole 181	changed mov to clr
   DB6B E4                 3840 	clr	a
   DB6C 08                 3841 	inc	r0
   DB6D 36                 3842 	addc	a,@r0
   DB6E FB                 3843 	mov	r3,a
   DB6F 08                 3844 	inc	r0
   DB70 86 04              3845 	mov	ar4,@r0
                           3846 ;	genPlus
                           3847 ;     genPlusIncr
   DB72 74 05              3848 	mov	a,#0x05
                           3849 ;	Peephole 236.a	used r2 instead of ar2
   DB74 2A                 3850 	add	a,r2
   DB75 FA                 3851 	mov	r2,a
                           3852 ;	Peephole 181	changed mov to clr
   DB76 E4                 3853 	clr	a
                           3854 ;	Peephole 236.b	used r3 instead of ar3
   DB77 3B                 3855 	addc	a,r3
   DB78 FB                 3856 	mov	r3,a
                           3857 ;	genPointerSet
                           3858 ;	genGenPointerSet
   DB79 8A 82              3859 	mov	dpl,r2
   DB7B 8B 83              3860 	mov	dph,r3
   DB7D 8C F0              3861 	mov	b,r4
   DB7F 74 07              3862 	mov	a,#0x07
   DB81 12 DF B7           3863 	lcall	__gptrput
                           3864 ;	../../Common/modules/cUDP.c:419: buf->buf[ind++] = portfield;
                           3865 ;	genPlus
   DB84 A8 10              3866 	mov	r0,_bp
   DB86 08                 3867 	inc	r0
                           3868 ;     genPlusIncr
   DB87 74 2C              3869 	mov	a,#0x2C
   DB89 26                 3870 	add	a,@r0
   DB8A FD                 3871 	mov	r5,a
                           3872 ;	Peephole 181	changed mov to clr
   DB8B E4                 3873 	clr	a
   DB8C 08                 3874 	inc	r0
   DB8D 36                 3875 	addc	a,@r0
   DB8E FB                 3876 	mov	r3,a
   DB8F 08                 3877 	inc	r0
   DB90 86 04              3878 	mov	ar4,@r0
                           3879 ;	genAssign
   DB92 E5 10              3880 	mov	a,_bp
   DB94 24 05              3881 	add	a,#0x05
   DB96 F8                 3882 	mov	r0,a
   DB97 86 02              3883 	mov	ar2,@r0
                           3884 ;	genPlus
   DB99 E5 10              3885 	mov	a,_bp
   DB9B 24 05              3886 	add	a,#0x05
   DB9D F8                 3887 	mov	r0,a
                           3888 ;     genPlusIncr
   DB9E 06                 3889 	inc	@r0
                           3890 ;	genPlus
                           3891 ;	Peephole 236.g	used r2 instead of ar2
   DB9F EA                 3892 	mov	a,r2
                           3893 ;	Peephole 236.a	used r5 instead of ar5
   DBA0 2D                 3894 	add	a,r5
   DBA1 FA                 3895 	mov	r2,a
                           3896 ;	Peephole 181	changed mov to clr
   DBA2 E4                 3897 	clr	a
                           3898 ;	Peephole 236.b	used r3 instead of ar3
   DBA3 3B                 3899 	addc	a,r3
   DBA4 FB                 3900 	mov	r3,a
                           3901 ;	genPointerSet
                           3902 ;	genGenPointerSet
   DBA5 8A 82              3903 	mov	dpl,r2
   DBA7 8B 83              3904 	mov	dph,r3
   DBA9 8C F0              3905 	mov	b,r4
   DBAB E5 10              3906 	mov	a,_bp
   DBAD 24 11              3907 	add	a,#0x11
   DBAF F8                 3908 	mov	r0,a
   DBB0 E6                 3909 	mov	a,@r0
   DBB1 12 DF B7           3910 	lcall	__gptrput
                           3911 ;	../../Common/modules/cUDP.c:420: break;
   DBB4 02 DD 21           3912 	ljmp	00138$
                           3913 ;	../../Common/modules/cUDP.c:422: case 8:
   DBB7                    3914 00137$:
                           3915 ;	../../Common/modules/cUDP.c:423: buf->options.lowpan_compressed = 0;
                           3916 ;	genPlus
   DBB7 A8 10              3917 	mov	r0,_bp
   DBB9 08                 3918 	inc	r0
                           3919 ;     genPlusIncr
   DBBA 74 26              3920 	mov	a,#0x26
   DBBC 26                 3921 	add	a,@r0
   DBBD FA                 3922 	mov	r2,a
                           3923 ;	Peephole 181	changed mov to clr
   DBBE E4                 3924 	clr	a
   DBBF 08                 3925 	inc	r0
   DBC0 36                 3926 	addc	a,@r0
   DBC1 FB                 3927 	mov	r3,a
   DBC2 08                 3928 	inc	r0
   DBC3 86 04              3929 	mov	ar4,@r0
                           3930 ;	genPlus
                           3931 ;     genPlusIncr
   DBC5 74 05              3932 	mov	a,#0x05
                           3933 ;	Peephole 236.a	used r2 instead of ar2
   DBC7 2A                 3934 	add	a,r2
   DBC8 FA                 3935 	mov	r2,a
                           3936 ;	Peephole 181	changed mov to clr
   DBC9 E4                 3937 	clr	a
                           3938 ;	Peephole 236.b	used r3 instead of ar3
   DBCA 3B                 3939 	addc	a,r3
   DBCB FB                 3940 	mov	r3,a
                           3941 ;	genPointerSet
                           3942 ;	genGenPointerSet
   DBCC 8A 82              3943 	mov	dpl,r2
   DBCE 8B 83              3944 	mov	dph,r3
   DBD0 8C F0              3945 	mov	b,r4
                           3946 ;	Peephole 181	changed mov to clr
   DBD2 E4                 3947 	clr	a
   DBD3 12 DF B7           3948 	lcall	__gptrput
                           3949 ;	../../Common/modules/cUDP.c:424: buf->buf[ind++] = (buf->src_sa.port >> 8);		
                           3950 ;	genPlus
   DBD6 A8 10              3951 	mov	r0,_bp
   DBD8 08                 3952 	inc	r0
                           3953 ;     genPlusIncr
   DBD9 74 2C              3954 	mov	a,#0x2C
   DBDB 26                 3955 	add	a,@r0
   DBDC FA                 3956 	mov	r2,a
                           3957 ;	Peephole 181	changed mov to clr
   DBDD E4                 3958 	clr	a
   DBDE 08                 3959 	inc	r0
   DBDF 36                 3960 	addc	a,@r0
   DBE0 FB                 3961 	mov	r3,a
   DBE1 08                 3962 	inc	r0
   DBE2 86 04              3963 	mov	ar4,@r0
                           3964 ;	genAssign
   DBE4 E5 10              3965 	mov	a,_bp
   DBE6 24 05              3966 	add	a,#0x05
   DBE8 F8                 3967 	mov	r0,a
   DBE9 86 05              3968 	mov	ar5,@r0
                           3969 ;	genPlus
   DBEB E5 10              3970 	mov	a,_bp
   DBED 24 05              3971 	add	a,#0x05
   DBEF F8                 3972 	mov	r0,a
                           3973 ;     genPlusIncr
   DBF0 06                 3974 	inc	@r0
                           3975 ;	genPlus
   DBF1 E5 10              3976 	mov	a,_bp
   DBF3 24 24              3977 	add	a,#0x24
   DBF5 F8                 3978 	mov	r0,a
                           3979 ;	Peephole 236.g	used r5 instead of ar5
   DBF6 ED                 3980 	mov	a,r5
                           3981 ;	Peephole 236.a	used r2 instead of ar2
   DBF7 2A                 3982 	add	a,r2
   DBF8 F6                 3983 	mov	@r0,a
                           3984 ;	Peephole 181	changed mov to clr
   DBF9 E4                 3985 	clr	a
                           3986 ;	Peephole 236.b	used r3 instead of ar3
   DBFA 3B                 3987 	addc	a,r3
   DBFB 08                 3988 	inc	r0
   DBFC F6                 3989 	mov	@r0,a
   DBFD 08                 3990 	inc	r0
   DBFE A6 04              3991 	mov	@r0,ar4
                           3992 ;	genPointerGet
                           3993 ;	genGenPointerGet
   DC00 E5 10              3994 	mov	a,_bp
   DC02 24 1E              3995 	add	a,#0x1e
   DC04 F8                 3996 	mov	r0,a
   DC05 86 82              3997 	mov	dpl,@r0
   DC07 08                 3998 	inc	r0
   DC08 86 83              3999 	mov	dph,@r0
   DC0A 08                 4000 	inc	r0
   DC0B 86 F0              4001 	mov	b,@r0
   DC0D 12 E4 9F           4002 	lcall	__gptrget
   DC10 FD                 4003 	mov	r5,a
   DC11 A3                 4004 	inc	dptr
   DC12 12 E4 9F           4005 	lcall	__gptrget
   DC15 FE                 4006 	mov	r6,a
                           4007 ;	genGetByte
   DC16 8E 07              4008 	mov	ar7,r6
                           4009 ;	genPointerSet
                           4010 ;	genGenPointerSet
   DC18 E5 10              4011 	mov	a,_bp
   DC1A 24 24              4012 	add	a,#0x24
   DC1C F8                 4013 	mov	r0,a
   DC1D 86 82              4014 	mov	dpl,@r0
   DC1F 08                 4015 	inc	r0
   DC20 86 83              4016 	mov	dph,@r0
   DC22 08                 4017 	inc	r0
   DC23 86 F0              4018 	mov	b,@r0
   DC25 EF                 4019 	mov	a,r7
   DC26 12 DF B7           4020 	lcall	__gptrput
                           4021 ;	../../Common/modules/cUDP.c:425: buf->buf[ind++] = (uint8_t) buf->src_sa.port;
                           4022 ;	genAssign
   DC29 E5 10              4023 	mov	a,_bp
   DC2B 24 05              4024 	add	a,#0x05
   DC2D F8                 4025 	mov	r0,a
   DC2E 86 07              4026 	mov	ar7,@r0
                           4027 ;	genPlus
   DC30 E5 10              4028 	mov	a,_bp
   DC32 24 05              4029 	add	a,#0x05
   DC34 F8                 4030 	mov	r0,a
                           4031 ;     genPlusIncr
   DC35 06                 4032 	inc	@r0
                           4033 ;	genPlus
   DC36 E5 10              4034 	mov	a,_bp
   DC38 24 24              4035 	add	a,#0x24
   DC3A F8                 4036 	mov	r0,a
                           4037 ;	Peephole 236.g	used r7 instead of ar7
   DC3B EF                 4038 	mov	a,r7
                           4039 ;	Peephole 236.a	used r2 instead of ar2
   DC3C 2A                 4040 	add	a,r2
   DC3D F6                 4041 	mov	@r0,a
                           4042 ;	Peephole 181	changed mov to clr
   DC3E E4                 4043 	clr	a
                           4044 ;	Peephole 236.b	used r3 instead of ar3
   DC3F 3B                 4045 	addc	a,r3
   DC40 08                 4046 	inc	r0
   DC41 F6                 4047 	mov	@r0,a
   DC42 08                 4048 	inc	r0
   DC43 A6 04              4049 	mov	@r0,ar4
                           4050 ;	genCast
                           4051 ;	genPointerSet
                           4052 ;	genGenPointerSet
   DC45 E5 10              4053 	mov	a,_bp
   DC47 24 24              4054 	add	a,#0x24
   DC49 F8                 4055 	mov	r0,a
   DC4A 86 82              4056 	mov	dpl,@r0
   DC4C 08                 4057 	inc	r0
   DC4D 86 83              4058 	mov	dph,@r0
   DC4F 08                 4059 	inc	r0
   DC50 86 F0              4060 	mov	b,@r0
   DC52 ED                 4061 	mov	a,r5
   DC53 12 DF B7           4062 	lcall	__gptrput
                           4063 ;	../../Common/modules/cUDP.c:426: buf->buf[ind++] = (buf->dst_sa.port >> 8);		
                           4064 ;	genAssign
   DC56 E5 10              4065 	mov	a,_bp
   DC58 24 05              4066 	add	a,#0x05
   DC5A F8                 4067 	mov	r0,a
   DC5B 86 05              4068 	mov	ar5,@r0
                           4069 ;	genPlus
   DC5D E5 10              4070 	mov	a,_bp
   DC5F 24 05              4071 	add	a,#0x05
   DC61 F8                 4072 	mov	r0,a
                           4073 ;     genPlusIncr
   DC62 06                 4074 	inc	@r0
                           4075 ;	genPlus
   DC63 E5 10              4076 	mov	a,_bp
   DC65 24 24              4077 	add	a,#0x24
   DC67 F8                 4078 	mov	r0,a
                           4079 ;	Peephole 236.g	used r5 instead of ar5
   DC68 ED                 4080 	mov	a,r5
                           4081 ;	Peephole 236.a	used r2 instead of ar2
   DC69 2A                 4082 	add	a,r2
   DC6A F6                 4083 	mov	@r0,a
                           4084 ;	Peephole 181	changed mov to clr
   DC6B E4                 4085 	clr	a
                           4086 ;	Peephole 236.b	used r3 instead of ar3
   DC6C 3B                 4087 	addc	a,r3
   DC6D 08                 4088 	inc	r0
   DC6E F6                 4089 	mov	@r0,a
   DC6F 08                 4090 	inc	r0
   DC70 A6 04              4091 	mov	@r0,ar4
                           4092 ;	genPointerGet
                           4093 ;	genGenPointerGet
   DC72 E5 10              4094 	mov	a,_bp
   DC74 24 27              4095 	add	a,#0x27
   DC76 F8                 4096 	mov	r0,a
   DC77 86 82              4097 	mov	dpl,@r0
   DC79 08                 4098 	inc	r0
   DC7A 86 83              4099 	mov	dph,@r0
   DC7C 08                 4100 	inc	r0
   DC7D 86 F0              4101 	mov	b,@r0
   DC7F 12 E4 9F           4102 	lcall	__gptrget
   DC82 FD                 4103 	mov	r5,a
   DC83 A3                 4104 	inc	dptr
   DC84 12 E4 9F           4105 	lcall	__gptrget
   DC87 FE                 4106 	mov	r6,a
                           4107 ;	genGetByte
   DC88 8E 07              4108 	mov	ar7,r6
                           4109 ;	genPointerSet
                           4110 ;	genGenPointerSet
   DC8A E5 10              4111 	mov	a,_bp
   DC8C 24 24              4112 	add	a,#0x24
   DC8E F8                 4113 	mov	r0,a
   DC8F 86 82              4114 	mov	dpl,@r0
   DC91 08                 4115 	inc	r0
   DC92 86 83              4116 	mov	dph,@r0
   DC94 08                 4117 	inc	r0
   DC95 86 F0              4118 	mov	b,@r0
   DC97 EF                 4119 	mov	a,r7
   DC98 12 DF B7           4120 	lcall	__gptrput
                           4121 ;	../../Common/modules/cUDP.c:427: buf->buf[ind++] = (uint8_t)buf->dst_sa.port;
                           4122 ;	genAssign
   DC9B E5 10              4123 	mov	a,_bp
   DC9D 24 05              4124 	add	a,#0x05
   DC9F F8                 4125 	mov	r0,a
   DCA0 86 07              4126 	mov	ar7,@r0
                           4127 ;	genPlus
   DCA2 E5 10              4128 	mov	a,_bp
   DCA4 24 05              4129 	add	a,#0x05
   DCA6 F8                 4130 	mov	r0,a
                           4131 ;     genPlusIncr
   DCA7 06                 4132 	inc	@r0
                           4133 ;	genPlus
   DCA8 E5 10              4134 	mov	a,_bp
   DCAA 24 24              4135 	add	a,#0x24
   DCAC F8                 4136 	mov	r0,a
                           4137 ;	Peephole 236.g	used r7 instead of ar7
   DCAD EF                 4138 	mov	a,r7
                           4139 ;	Peephole 236.a	used r2 instead of ar2
   DCAE 2A                 4140 	add	a,r2
   DCAF F6                 4141 	mov	@r0,a
                           4142 ;	Peephole 181	changed mov to clr
   DCB0 E4                 4143 	clr	a
                           4144 ;	Peephole 236.b	used r3 instead of ar3
   DCB1 3B                 4145 	addc	a,r3
   DCB2 08                 4146 	inc	r0
   DCB3 F6                 4147 	mov	@r0,a
   DCB4 08                 4148 	inc	r0
   DCB5 A6 04              4149 	mov	@r0,ar4
                           4150 ;	genCast
                           4151 ;	genPointerSet
                           4152 ;	genGenPointerSet
   DCB7 E5 10              4153 	mov	a,_bp
   DCB9 24 24              4154 	add	a,#0x24
   DCBB F8                 4155 	mov	r0,a
   DCBC 86 82              4156 	mov	dpl,@r0
   DCBE 08                 4157 	inc	r0
   DCBF 86 83              4158 	mov	dph,@r0
   DCC1 08                 4159 	inc	r0
   DCC2 86 F0              4160 	mov	b,@r0
   DCC4 ED                 4161 	mov	a,r5
   DCC5 12 DF B7           4162 	lcall	__gptrput
                           4163 ;	../../Common/modules/cUDP.c:428: buf->buf[ind++] = (length >> 8);
                           4164 ;	genAssign
   DCC8 E5 10              4165 	mov	a,_bp
   DCCA 24 05              4166 	add	a,#0x05
   DCCC F8                 4167 	mov	r0,a
   DCCD 86 05              4168 	mov	ar5,@r0
                           4169 ;	genPlus
   DCCF E5 10              4170 	mov	a,_bp
   DCD1 24 05              4171 	add	a,#0x05
   DCD3 F8                 4172 	mov	r0,a
                           4173 ;     genPlusIncr
   DCD4 06                 4174 	inc	@r0
                           4175 ;	genPlus
   DCD5 E5 10              4176 	mov	a,_bp
   DCD7 24 27              4177 	add	a,#0x27
   DCD9 F8                 4178 	mov	r0,a
                           4179 ;	Peephole 236.g	used r5 instead of ar5
   DCDA ED                 4180 	mov	a,r5
                           4181 ;	Peephole 236.a	used r2 instead of ar2
   DCDB 2A                 4182 	add	a,r2
   DCDC F6                 4183 	mov	@r0,a
                           4184 ;	Peephole 181	changed mov to clr
   DCDD E4                 4185 	clr	a
                           4186 ;	Peephole 236.b	used r3 instead of ar3
   DCDE 3B                 4187 	addc	a,r3
   DCDF 08                 4188 	inc	r0
   DCE0 F6                 4189 	mov	@r0,a
   DCE1 08                 4190 	inc	r0
   DCE2 A6 04              4191 	mov	@r0,ar4
                           4192 ;	genGetByte
   DCE4 E5 10              4193 	mov	a,_bp
   DCE6 24 0F              4194 	add	a,#0x0f
                           4195 ;	Peephole 185	changed order of increment (acc incremented also!)
   DCE8 04                 4196 	inc	a
   DCE9 F8                 4197 	mov	r0,a
   DCEA 86 05              4198 	mov	ar5,@r0
                           4199 ;	genPointerSet
                           4200 ;	genGenPointerSet
   DCEC E5 10              4201 	mov	a,_bp
   DCEE 24 27              4202 	add	a,#0x27
   DCF0 F8                 4203 	mov	r0,a
   DCF1 86 82              4204 	mov	dpl,@r0
   DCF3 08                 4205 	inc	r0
   DCF4 86 83              4206 	mov	dph,@r0
   DCF6 08                 4207 	inc	r0
   DCF7 86 F0              4208 	mov	b,@r0
   DCF9 ED                 4209 	mov	a,r5
   DCFA 12 DF B7           4210 	lcall	__gptrput
                           4211 ;	../../Common/modules/cUDP.c:429: buf->buf[ind++] = (uint8_t) length;
                           4212 ;	genAssign
   DCFD E5 10              4213 	mov	a,_bp
   DCFF 24 05              4214 	add	a,#0x05
   DD01 F8                 4215 	mov	r0,a
   DD02 86 05              4216 	mov	ar5,@r0
                           4217 ;	genPlus
   DD04 E5 10              4218 	mov	a,_bp
   DD06 24 05              4219 	add	a,#0x05
   DD08 F8                 4220 	mov	r0,a
                           4221 ;     genPlusIncr
   DD09 06                 4222 	inc	@r0
                           4223 ;	genPlus
                           4224 ;	Peephole 236.g	used r5 instead of ar5
   DD0A ED                 4225 	mov	a,r5
                           4226 ;	Peephole 236.a	used r2 instead of ar2
   DD0B 2A                 4227 	add	a,r2
   DD0C FA                 4228 	mov	r2,a
                           4229 ;	Peephole 181	changed mov to clr
   DD0D E4                 4230 	clr	a
                           4231 ;	Peephole 236.b	used r3 instead of ar3
   DD0E 3B                 4232 	addc	a,r3
   DD0F FB                 4233 	mov	r3,a
                           4234 ;	genCast
   DD10 E5 10              4235 	mov	a,_bp
   DD12 24 0F              4236 	add	a,#0x0f
   DD14 F8                 4237 	mov	r0,a
   DD15 86 07              4238 	mov	ar7,@r0
                           4239 ;	genPointerSet
                           4240 ;	genGenPointerSet
   DD17 8A 82              4241 	mov	dpl,r2
   DD19 8B 83              4242 	mov	dph,r3
   DD1B 8C F0              4243 	mov	b,r4
   DD1D EF                 4244 	mov	a,r7
   DD1E 12 DF B7           4245 	lcall	__gptrput
                           4246 ;	../../Common/modules/cUDP.c:431: }
   DD21                    4247 00138$:
                           4248 ;	../../Common/modules/cUDP.c:437: buf->buf[ind++] = 0;		
                           4249 ;	genPlus
   DD21 A8 10              4250 	mov	r0,_bp
   DD23 08                 4251 	inc	r0
                           4252 ;     genPlusIncr
   DD24 74 2C              4253 	mov	a,#0x2C
   DD26 26                 4254 	add	a,@r0
   DD27 FA                 4255 	mov	r2,a
                           4256 ;	Peephole 181	changed mov to clr
   DD28 E4                 4257 	clr	a
   DD29 08                 4258 	inc	r0
   DD2A 36                 4259 	addc	a,@r0
   DD2B FB                 4260 	mov	r3,a
   DD2C 08                 4261 	inc	r0
   DD2D 86 04              4262 	mov	ar4,@r0
                           4263 ;	genAssign
   DD2F E5 10              4264 	mov	a,_bp
   DD31 24 05              4265 	add	a,#0x05
   DD33 F8                 4266 	mov	r0,a
   DD34 86 05              4267 	mov	ar5,@r0
                           4268 ;	genPlus
   DD36 E5 10              4269 	mov	a,_bp
   DD38 24 05              4270 	add	a,#0x05
   DD3A F8                 4271 	mov	r0,a
                           4272 ;     genPlusIncr
   DD3B 06                 4273 	inc	@r0
                           4274 ;	genPlus
                           4275 ;	Peephole 236.g	used r5 instead of ar5
   DD3C ED                 4276 	mov	a,r5
                           4277 ;	Peephole 236.a	used r2 instead of ar2
   DD3D 2A                 4278 	add	a,r2
   DD3E FD                 4279 	mov	r5,a
                           4280 ;	Peephole 181	changed mov to clr
   DD3F E4                 4281 	clr	a
                           4282 ;	Peephole 236.b	used r3 instead of ar3
   DD40 3B                 4283 	addc	a,r3
   DD41 FE                 4284 	mov	r6,a
   DD42 8C 07              4285 	mov	ar7,r4
                           4286 ;	genPointerSet
                           4287 ;	genGenPointerSet
   DD44 8D 82              4288 	mov	dpl,r5
   DD46 8E 83              4289 	mov	dph,r6
   DD48 8F F0              4290 	mov	b,r7
                           4291 ;	Peephole 181	changed mov to clr
   DD4A E4                 4292 	clr	a
   DD4B 12 DF B7           4293 	lcall	__gptrput
                           4294 ;	../../Common/modules/cUDP.c:438: buf->buf[ind++] = 0;
                           4295 ;	genAssign
   DD4E E5 10              4296 	mov	a,_bp
   DD50 24 05              4297 	add	a,#0x05
   DD52 F8                 4298 	mov	r0,a
   DD53 86 05              4299 	mov	ar5,@r0
                           4300 ;	genPlus
   DD55 E5 10              4301 	mov	a,_bp
   DD57 24 05              4302 	add	a,#0x05
   DD59 F8                 4303 	mov	r0,a
                           4304 ;     genPlusIncr
   DD5A 06                 4305 	inc	@r0
                           4306 ;	genPlus
                           4307 ;	Peephole 236.g	used r5 instead of ar5
   DD5B ED                 4308 	mov	a,r5
                           4309 ;	Peephole 236.a	used r2 instead of ar2
   DD5C 2A                 4310 	add	a,r2
   DD5D FA                 4311 	mov	r2,a
                           4312 ;	Peephole 181	changed mov to clr
   DD5E E4                 4313 	clr	a
                           4314 ;	Peephole 236.b	used r3 instead of ar3
   DD5F 3B                 4315 	addc	a,r3
   DD60 FB                 4316 	mov	r3,a
                           4317 ;	genPointerSet
                           4318 ;	genGenPointerSet
   DD61 8A 82              4319 	mov	dpl,r2
   DD63 8B 83              4320 	mov	dph,r3
   DD65 8C F0              4321 	mov	b,r4
                           4322 ;	Peephole 181	changed mov to clr
   DD67 E4                 4323 	clr	a
   DD68 12 DF B7           4324 	lcall	__gptrput
                           4325 ;	../../Common/modules/cUDP.c:440: buf->socket = 0;
                           4326 ;	genPointerSet
                           4327 ;	genGenPointerSet
   DD6B A8 10              4328 	mov	r0,_bp
   DD6D 08                 4329 	inc	r0
   DD6E 86 82              4330 	mov	dpl,@r0
   DD70 08                 4331 	inc	r0
   DD71 86 83              4332 	mov	dph,@r0
   DD73 08                 4333 	inc	r0
   DD74 86 F0              4334 	mov	b,@r0
                           4335 ;	Peephole 181	changed mov to clr
   DD76 E4                 4336 	clr	a
   DD77 12 DF B7           4337 	lcall	__gptrput
   DD7A A3                 4338 	inc	dptr
                           4339 ;	Peephole 181	changed mov to clr
   DD7B E4                 4340 	clr	a
   DD7C 12 DF B7           4341 	lcall	__gptrput
   DD7F A3                 4342 	inc	dptr
                           4343 ;	Peephole 181	changed mov to clr
   DD80 E4                 4344 	clr	a
   DD81 12 DF B7           4345 	lcall	__gptrput
                           4346 ;	../../Common/modules/cUDP.c:441: buf->from = MODULE_CUDP;
                           4347 ;	genPlus
   DD84 A8 10              4348 	mov	r0,_bp
   DD86 08                 4349 	inc	r0
                           4350 ;     genPlusIncr
   DD87 74 1D              4351 	mov	a,#0x1D
   DD89 26                 4352 	add	a,@r0
   DD8A FA                 4353 	mov	r2,a
                           4354 ;	Peephole 181	changed mov to clr
   DD8B E4                 4355 	clr	a
   DD8C 08                 4356 	inc	r0
   DD8D 36                 4357 	addc	a,@r0
   DD8E FB                 4358 	mov	r3,a
   DD8F 08                 4359 	inc	r0
   DD90 86 04              4360 	mov	ar4,@r0
                           4361 ;	genPointerSet
                           4362 ;	genGenPointerSet
   DD92 8A 82              4363 	mov	dpl,r2
   DD94 8B 83              4364 	mov	dph,r3
   DD96 8C F0              4365 	mov	b,r4
   DD98 74 02              4366 	mov	a,#0x02
   DD9A 12 DF B7           4367 	lcall	__gptrput
                           4368 ;	../../Common/modules/cUDP.c:442: buf->dir = BUFFER_DOWN;
                           4369 ;	genPlus
   DD9D A8 10              4370 	mov	r0,_bp
   DD9F 08                 4371 	inc	r0
                           4372 ;     genPlusIncr
   DDA0 74 1F              4373 	mov	a,#0x1F
   DDA2 26                 4374 	add	a,@r0
   DDA3 FA                 4375 	mov	r2,a
                           4376 ;	Peephole 181	changed mov to clr
   DDA4 E4                 4377 	clr	a
   DDA5 08                 4378 	inc	r0
   DDA6 36                 4379 	addc	a,@r0
   DDA7 FB                 4380 	mov	r3,a
   DDA8 08                 4381 	inc	r0
   DDA9 86 04              4382 	mov	ar4,@r0
                           4383 ;	genPointerSet
                           4384 ;	genGenPointerSet
   DDAB 8A 82              4385 	mov	dpl,r2
   DDAD 8B 83              4386 	mov	dph,r3
   DDAF 8C F0              4387 	mov	b,r4
   DDB1 74 01              4388 	mov	a,#0x01
   DDB3 12 DF B7           4389 	lcall	__gptrput
                           4390 ;	../../Common/modules/cUDP.c:443: buf->to = MODULE_NONE;
                           4391 ;	genPlus
   DDB6 A8 10              4392 	mov	r0,_bp
   DDB8 08                 4393 	inc	r0
                           4394 ;     genPlusIncr
   DDB9 74 1E              4395 	mov	a,#0x1E
   DDBB 26                 4396 	add	a,@r0
   DDBC FA                 4397 	mov	r2,a
                           4398 ;	Peephole 181	changed mov to clr
   DDBD E4                 4399 	clr	a
   DDBE 08                 4400 	inc	r0
   DDBF 36                 4401 	addc	a,@r0
   DDC0 FB                 4402 	mov	r3,a
   DDC1 08                 4403 	inc	r0
   DDC2 86 04              4404 	mov	ar4,@r0
                           4405 ;	genPointerSet
                           4406 ;	genGenPointerSet
   DDC4 8A 82              4407 	mov	dpl,r2
   DDC6 8B 83              4408 	mov	dph,r3
   DDC8 8C F0              4409 	mov	b,r4
                           4410 ;	Peephole 181	changed mov to clr
   DDCA E4                 4411 	clr	a
   DDCB 12 DF B7           4412 	lcall	__gptrput
                           4413 ;	../../Common/modules/cUDP.c:444: stack_buffer_push(buf);
                           4414 ;	genCall
   DDCE A8 10              4415 	mov	r0,_bp
   DDD0 08                 4416 	inc	r0
   DDD1 86 82              4417 	mov	dpl,@r0
   DDD3 08                 4418 	inc	r0
   DDD4 86 83              4419 	mov	dph,@r0
   DDD6 08                 4420 	inc	r0
   DDD7 86 F0              4421 	mov	b,@r0
   DDD9 12 62 C4           4422 	lcall	_stack_buffer_push
                           4423 ;	../../Common/modules/cUDP.c:445: buf=0;
                           4424 ;	genAssign
   DDDC A8 10              4425 	mov	r0,_bp
   DDDE 08                 4426 	inc	r0
   DDDF E4                 4427 	clr	a
   DDE0 F6                 4428 	mov	@r0,a
   DDE1 08                 4429 	inc	r0
   DDE2 F6                 4430 	mov	@r0,a
   DDE3 08                 4431 	inc	r0
   DDE4 F6                 4432 	mov	@r0,a
   DDE5                    4433 00142$:
                           4434 ;	../../Common/modules/cUDP.c:448: if (buf)
                           4435 ;	genIfx
   DDE5 A8 10              4436 	mov	r0,_bp
   DDE7 08                 4437 	inc	r0
   DDE8 E6                 4438 	mov	a,@r0
   DDE9 08                 4439 	inc	r0
   DDEA 46                 4440 	orl	a,@r0
   DDEB 08                 4441 	inc	r0
   DDEC 46                 4442 	orl	a,@r0
                           4443 ;	genIfxJump
                           4444 ;	Peephole 108.c	removed ljmp by inverse jump logic
   DDED 60 65              4445 	jz	00147$
                           4446 ;	Peephole 300	removed redundant label 00219$
                           4447 ;	../../Common/modules/cUDP.c:463: buf->from = MODULE_CUDP;
                           4448 ;	genPlus
   DDEF A8 10              4449 	mov	r0,_bp
   DDF1 08                 4450 	inc	r0
                           4451 ;     genPlusIncr
   DDF2 74 1D              4452 	mov	a,#0x1D
   DDF4 26                 4453 	add	a,@r0
   DDF5 FA                 4454 	mov	r2,a
                           4455 ;	Peephole 181	changed mov to clr
   DDF6 E4                 4456 	clr	a
   DDF7 08                 4457 	inc	r0
   DDF8 36                 4458 	addc	a,@r0
   DDF9 FB                 4459 	mov	r3,a
   DDFA 08                 4460 	inc	r0
   DDFB 86 04              4461 	mov	ar4,@r0
                           4462 ;	genPointerSet
                           4463 ;	genGenPointerSet
   DDFD 8A 82              4464 	mov	dpl,r2
   DDFF 8B 83              4465 	mov	dph,r3
   DE01 8C F0              4466 	mov	b,r4
   DE03 74 02              4467 	mov	a,#0x02
   DE05 12 DF B7           4468 	lcall	__gptrput
                           4469 ;	../../Common/modules/cUDP.c:464: buf->to = MODULE_NONE;
                           4470 ;	genPlus
   DE08 A8 10              4471 	mov	r0,_bp
   DE0A 08                 4472 	inc	r0
                           4473 ;     genPlusIncr
   DE0B 74 1E              4474 	mov	a,#0x1E
   DE0D 26                 4475 	add	a,@r0
   DE0E FA                 4476 	mov	r2,a
                           4477 ;	Peephole 181	changed mov to clr
   DE0F E4                 4478 	clr	a
   DE10 08                 4479 	inc	r0
   DE11 36                 4480 	addc	a,@r0
   DE12 FB                 4481 	mov	r3,a
   DE13 08                 4482 	inc	r0
   DE14 86 04              4483 	mov	ar4,@r0
                           4484 ;	genPointerSet
                           4485 ;	genGenPointerSet
   DE16 8A 82              4486 	mov	dpl,r2
   DE18 8B 83              4487 	mov	dph,r3
   DE1A 8C F0              4488 	mov	b,r4
                           4489 ;	Peephole 181	changed mov to clr
   DE1C E4                 4490 	clr	a
   DE1D 12 DF B7           4491 	lcall	__gptrput
                           4492 ;	../../Common/modules/cUDP.c:465: buf->buf_ptr = ind; // Move the buffer pointer
                           4493 ;	genPlus
   DE20 A8 10              4494 	mov	r0,_bp
   DE22 08                 4495 	inc	r0
                           4496 ;     genPlusIncr
   DE23 74 20              4497 	mov	a,#0x20
   DE25 26                 4498 	add	a,@r0
   DE26 FA                 4499 	mov	r2,a
                           4500 ;	Peephole 181	changed mov to clr
   DE27 E4                 4501 	clr	a
   DE28 08                 4502 	inc	r0
   DE29 36                 4503 	addc	a,@r0
   DE2A FB                 4504 	mov	r3,a
   DE2B 08                 4505 	inc	r0
   DE2C 86 04              4506 	mov	ar4,@r0
                           4507 ;	genCast
   DE2E E5 10              4508 	mov	a,_bp
   DE30 24 05              4509 	add	a,#0x05
   DE32 F8                 4510 	mov	r0,a
   DE33 86 05              4511 	mov	ar5,@r0
   DE35 7E 00              4512 	mov	r6,#0x00
                           4513 ;	genPointerSet
                           4514 ;	genGenPointerSet
   DE37 8A 82              4515 	mov	dpl,r2
   DE39 8B 83              4516 	mov	dph,r3
   DE3B 8C F0              4517 	mov	b,r4
   DE3D ED                 4518 	mov	a,r5
   DE3E 12 DF B7           4519 	lcall	__gptrput
   DE41 A3                 4520 	inc	dptr
   DE42 EE                 4521 	mov	a,r6
   DE43 12 DF B7           4522 	lcall	__gptrput
                           4523 ;	../../Common/modules/cUDP.c:466: stack_buffer_push(buf);
                           4524 ;	genCall
   DE46 A8 10              4525 	mov	r0,_bp
   DE48 08                 4526 	inc	r0
   DE49 86 82              4527 	mov	dpl,@r0
   DE4B 08                 4528 	inc	r0
   DE4C 86 83              4529 	mov	dph,@r0
   DE4E 08                 4530 	inc	r0
   DE4F 86 F0              4531 	mov	b,@r0
   DE51 12 62 C4           4532 	lcall	_stack_buffer_push
                           4533 ;	../../Common/modules/cUDP.c:470: }
   DE54                    4534 00147$:
                           4535 ;	../../Common/modules/cUDP.c:471: return pdTRUE;
                           4536 ;	genRet
   DE54 75 82 01           4537 	mov	dpl,#0x01
   DE57                    4538 00152$:
   DE57 85 10 81           4539 	mov	sp,_bp
   DE5A D0 10              4540 	pop	_bp
   DE5C 22                 4541 	ret
                           4542 ;------------------------------------------------------------
                           4543 ;Allocation info for local variables in function 'cudp_check'
                           4544 ;------------------------------------------------------------
                           4545 ;buf                       Allocated to stack - offset 1
                           4546 ;payload_length            Allocated to stack - offset 4
                           4547 ;ind                       Allocated to stack - offset 5
                           4548 ;length                    Allocated to registers r7 r5 
                           4549 ;------------------------------------------------------------
                           4550 ;	../../Common/modules/cUDP.c:482: portCHAR cudp_check( buffer_t *buf )
                           4551 ;	-----------------------------------------
                           4552 ;	 function cudp_check
                           4553 ;	-----------------------------------------
   DE5D                    4554 _cudp_check:
   DE5D C0 10              4555 	push	_bp
   DE5F 85 81 10           4556 	mov	_bp,sp
                           4557 ;     genReceive
   DE62 C0 82              4558 	push	dpl
   DE64 C0 83              4559 	push	dph
   DE66 C0 F0              4560 	push	b
   DE68 05 81              4561 	inc	sp
   DE6A 05 81              4562 	inc	sp
                           4563 ;	../../Common/modules/cUDP.c:486: switch (buf->options.lowpan_compressed)
                           4564 ;	genPlus
   DE6C A8 10              4565 	mov	r0,_bp
   DE6E 08                 4566 	inc	r0
                           4567 ;     genPlusIncr
   DE6F 74 26              4568 	mov	a,#0x26
   DE71 26                 4569 	add	a,@r0
   DE72 FD                 4570 	mov	r5,a
                           4571 ;	Peephole 181	changed mov to clr
   DE73 E4                 4572 	clr	a
   DE74 08                 4573 	inc	r0
   DE75 36                 4574 	addc	a,@r0
   DE76 FE                 4575 	mov	r6,a
   DE77 08                 4576 	inc	r0
   DE78 86 07              4577 	mov	ar7,@r0
                           4578 ;	genPlus
                           4579 ;     genPlusIncr
   DE7A 74 05              4580 	mov	a,#0x05
                           4581 ;	Peephole 236.a	used r5 instead of ar5
   DE7C 2D                 4582 	add	a,r5
   DE7D FD                 4583 	mov	r5,a
                           4584 ;	Peephole 181	changed mov to clr
   DE7E E4                 4585 	clr	a
                           4586 ;	Peephole 236.b	used r6 instead of ar6
   DE7F 3E                 4587 	addc	a,r6
   DE80 FE                 4588 	mov	r6,a
                           4589 ;	genPointerGet
                           4590 ;	genGenPointerGet
   DE81 8D 82              4591 	mov	dpl,r5
   DE83 8E 83              4592 	mov	dph,r6
   DE85 8F F0              4593 	mov	b,r7
   DE87 12 E4 9F           4594 	lcall	__gptrget
                           4595 ;	genCmpEq
                           4596 ;	gencjneshort
                           4597 ;	Peephole 112.b	changed ljmp to sjmp
   DE8A FD                 4598 	mov	r5,a
                           4599 ;	Peephole 115.b	jump optimization
   DE8B 60 0F              4600 	jz	00101$
                           4601 ;	Peephole 300	removed redundant label 00114$
                           4602 ;	genCmpEq
                           4603 ;	gencjneshort
   DE8D BD 04 03           4604 	cjne	r5,#0x04,00115$
   DE90 02 DF 5C           4605 	ljmp	00107$
   DE93                    4606 00115$:
                           4607 ;	genCmpEq
                           4608 ;	gencjneshort
   DE93 BD 07 03           4609 	cjne	r5,#0x07,00116$
   DE96 02 DF 5C           4610 	ljmp	00107$
   DE99                    4611 00116$:
   DE99 02 DF 57           4612 	ljmp	00106$
                           4613 ;	../../Common/modules/cUDP.c:488: case UNCOMPRESSED_HC_UDP:
   DE9C                    4614 00101$:
                           4615 ;	../../Common/modules/cUDP.c:489: payload_length = (buf->buf_end - buf->buf_ptr);
                           4616 ;	genPlus
   DE9C A8 10              4617 	mov	r0,_bp
   DE9E 08                 4618 	inc	r0
                           4619 ;     genPlusIncr
   DE9F 74 22              4620 	mov	a,#0x22
   DEA1 26                 4621 	add	a,@r0
   DEA2 FD                 4622 	mov	r5,a
                           4623 ;	Peephole 181	changed mov to clr
   DEA3 E4                 4624 	clr	a
   DEA4 08                 4625 	inc	r0
   DEA5 36                 4626 	addc	a,@r0
   DEA6 FE                 4627 	mov	r6,a
   DEA7 08                 4628 	inc	r0
   DEA8 86 07              4629 	mov	ar7,@r0
                           4630 ;	genPointerGet
                           4631 ;	genGenPointerGet
   DEAA 8D 82              4632 	mov	dpl,r5
   DEAC 8E 83              4633 	mov	dph,r6
   DEAE 8F F0              4634 	mov	b,r7
   DEB0 12 E4 9F           4635 	lcall	__gptrget
   DEB3 FD                 4636 	mov	r5,a
   DEB4 A3                 4637 	inc	dptr
   DEB5 12 E4 9F           4638 	lcall	__gptrget
   DEB8 FE                 4639 	mov	r6,a
                           4640 ;	genCast
                           4641 ;	genPlus
   DEB9 A8 10              4642 	mov	r0,_bp
   DEBB 08                 4643 	inc	r0
                           4644 ;     genPlusIncr
   DEBC 74 20              4645 	mov	a,#0x20
   DEBE 26                 4646 	add	a,@r0
   DEBF FE                 4647 	mov	r6,a
                           4648 ;	Peephole 181	changed mov to clr
   DEC0 E4                 4649 	clr	a
   DEC1 08                 4650 	inc	r0
   DEC2 36                 4651 	addc	a,@r0
   DEC3 FF                 4652 	mov	r7,a
   DEC4 08                 4653 	inc	r0
   DEC5 86 02              4654 	mov	ar2,@r0
                           4655 ;	genPointerGet
                           4656 ;	genGenPointerGet
   DEC7 8E 82              4657 	mov	dpl,r6
   DEC9 8F 83              4658 	mov	dph,r7
   DECB 8A F0              4659 	mov	b,r2
   DECD 12 E4 9F           4660 	lcall	__gptrget
   DED0 FE                 4661 	mov	r6,a
   DED1 A3                 4662 	inc	dptr
   DED2 12 E4 9F           4663 	lcall	__gptrget
   DED5 FF                 4664 	mov	r7,a
                           4665 ;	genCast
                           4666 ;	genMinus
   DED6 ED                 4667 	mov	a,r5
   DED7 C3                 4668 	clr	c
                           4669 ;	Peephole 236.l	used r6 instead of ar6
   DED8 9E                 4670 	subb	a,r6
   DED9 FD                 4671 	mov	r5,a
                           4672 ;	genAssign
   DEDA E5 10              4673 	mov	a,_bp
   DEDC 24 04              4674 	add	a,#0x04
   DEDE F8                 4675 	mov	r0,a
   DEDF A6 05              4676 	mov	@r0,ar5
                           4677 ;	../../Common/modules/cUDP.c:490: ind=buf->buf_ptr;
                           4678 ;	genAssign
                           4679 ;	genAssign
   DEE1 E5 10              4680 	mov	a,_bp
   DEE3 24 05              4681 	add	a,#0x05
   DEE5 F8                 4682 	mov	r0,a
   DEE6 A6 06              4683 	mov	@r0,ar6
                           4684 ;	../../Common/modules/cUDP.c:491: ind+=4;
                           4685 ;	genPlus
   DEE8 E5 10              4686 	mov	a,_bp
   DEEA 24 05              4687 	add	a,#0x05
   DEEC F8                 4688 	mov	r0,a
                           4689 ;     genPlusIncr
   DEED E6                 4690 	mov	a,@r0
   DEEE 24 04              4691 	add	a,#0x04
   DEF0 F6                 4692 	mov	@r0,a
                           4693 ;	../../Common/modules/cUDP.c:492: length = buf->buf[ind++];
                           4694 ;	genPlus
   DEF1 A8 10              4695 	mov	r0,_bp
   DEF3 08                 4696 	inc	r0
                           4697 ;     genPlusIncr
   DEF4 74 2C              4698 	mov	a,#0x2C
   DEF6 26                 4699 	add	a,@r0
   DEF7 FA                 4700 	mov	r2,a
                           4701 ;	Peephole 181	changed mov to clr
   DEF8 E4                 4702 	clr	a
   DEF9 08                 4703 	inc	r0
   DEFA 36                 4704 	addc	a,@r0
   DEFB FB                 4705 	mov	r3,a
   DEFC 08                 4706 	inc	r0
   DEFD 86 04              4707 	mov	ar4,@r0
                           4708 ;	genAssign
   DEFF E5 10              4709 	mov	a,_bp
   DF01 24 05              4710 	add	a,#0x05
   DF03 F8                 4711 	mov	r0,a
   DF04 86 07              4712 	mov	ar7,@r0
                           4713 ;	genPlus
   DF06 E5 10              4714 	mov	a,_bp
   DF08 24 05              4715 	add	a,#0x05
   DF0A F8                 4716 	mov	r0,a
                           4717 ;     genPlusIncr
   DF0B 06                 4718 	inc	@r0
                           4719 ;	genPlus
                           4720 ;	Peephole 236.g	used r7 instead of ar7
   DF0C EF                 4721 	mov	a,r7
                           4722 ;	Peephole 236.a	used r2 instead of ar2
   DF0D 2A                 4723 	add	a,r2
   DF0E FF                 4724 	mov	r7,a
                           4725 ;	Peephole 181	changed mov to clr
   DF0F E4                 4726 	clr	a
                           4727 ;	Peephole 236.b	used r3 instead of ar3
   DF10 3B                 4728 	addc	a,r3
   DF11 FD                 4729 	mov	r5,a
   DF12 8C 06              4730 	mov	ar6,r4
                           4731 ;	genPointerGet
                           4732 ;	genGenPointerGet
   DF14 8F 82              4733 	mov	dpl,r7
   DF16 8D 83              4734 	mov	dph,r5
   DF18 8E F0              4735 	mov	b,r6
   DF1A 12 E4 9F           4736 	lcall	__gptrget
   DF1D FF                 4737 	mov	r7,a
                           4738 ;	genCast
                           4739 ;	../../Common/modules/cUDP.c:493: length <<= 8;
                           4740 ;	genLeftShift
                           4741 ;	genLeftShiftLiteral
                           4742 ;	genlshTwo
                           4743 ;	peephole 177.e	removed redundant move
   DF1E 8F 05              4744 	mov	ar5,r7
   DF20 7F 00              4745 	mov	r7,#0x00
                           4746 ;	../../Common/modules/cUDP.c:494: length += buf->buf[ind++];
                           4747 ;	genPlus
   DF22 E5 10              4748 	mov	a,_bp
   DF24 24 05              4749 	add	a,#0x05
   DF26 F8                 4750 	mov	r0,a
   DF27 E6                 4751 	mov	a,@r0
                           4752 ;	Peephole 236.a	used r2 instead of ar2
   DF28 2A                 4753 	add	a,r2
   DF29 FA                 4754 	mov	r2,a
                           4755 ;	Peephole 181	changed mov to clr
   DF2A E4                 4756 	clr	a
                           4757 ;	Peephole 236.b	used r3 instead of ar3
   DF2B 3B                 4758 	addc	a,r3
   DF2C FB                 4759 	mov	r3,a
                           4760 ;	genPointerGet
                           4761 ;	genGenPointerGet
   DF2D 8A 82              4762 	mov	dpl,r2
   DF2F 8B 83              4763 	mov	dph,r3
   DF31 8C F0              4764 	mov	b,r4
   DF33 12 E4 9F           4765 	lcall	__gptrget
   DF36 FA                 4766 	mov	r2,a
                           4767 ;	genCast
   DF37 7B 00              4768 	mov	r3,#0x00
                           4769 ;	genPlus
                           4770 ;	Peephole 236.g	used r2 instead of ar2
   DF39 EA                 4771 	mov	a,r2
                           4772 ;	Peephole 236.a	used r7 instead of ar7
   DF3A 2F                 4773 	add	a,r7
   DF3B FF                 4774 	mov	r7,a
                           4775 ;	Peephole 236.g	used r3 instead of ar3
   DF3C EB                 4776 	mov	a,r3
                           4777 ;	Peephole 236.b	used r5 instead of ar5
   DF3D 3D                 4778 	addc	a,r5
   DF3E FD                 4779 	mov	r5,a
                           4780 ;	../../Common/modules/cUDP.c:495: if(length !=payload_length)
                           4781 ;	genCast
   DF3F E5 10              4782 	mov	a,_bp
   DF41 24 04              4783 	add	a,#0x04
   DF43 F8                 4784 	mov	r0,a
   DF44 86 02              4785 	mov	ar2,@r0
   DF46 7B 00              4786 	mov	r3,#0x00
                           4787 ;	genCmpEq
                           4788 ;	gencjneshort
   DF48 EF                 4789 	mov	a,r7
   DF49 B5 02 06           4790 	cjne	a,ar2,00117$
   DF4C ED                 4791 	mov	a,r5
   DF4D B5 03 02           4792 	cjne	a,ar3,00117$
                           4793 ;	Peephole 112.b	changed ljmp to sjmp
   DF50 80 0A              4794 	sjmp	00107$
   DF52                    4795 00117$:
                           4796 ;	../../Common/modules/cUDP.c:497: return pdFALSE;
                           4797 ;	genRet
   DF52 75 82 00           4798 	mov	dpl,#0x00
                           4799 ;	../../Common/modules/cUDP.c:507: default:
                           4800 ;	Peephole 112.b	changed ljmp to sjmp
   DF55 80 08              4801 	sjmp	00108$
   DF57                    4802 00106$:
                           4803 ;	../../Common/modules/cUDP.c:508: return pdFALSE;
                           4804 ;	genRet
   DF57 75 82 00           4805 	mov	dpl,#0x00
                           4806 ;	../../Common/modules/cUDP.c:511: }
                           4807 ;	Peephole 112.b	changed ljmp to sjmp
   DF5A 80 03              4808 	sjmp	00108$
   DF5C                    4809 00107$:
                           4810 ;	../../Common/modules/cUDP.c:512: return pdTRUE; 
                           4811 ;	genRet
   DF5C 75 82 01           4812 	mov	dpl,#0x01
   DF5F                    4813 00108$:
   DF5F 85 10 81           4814 	mov	sp,_bp
   DF62 D0 10              4815 	pop	_bp
   DF64 22                 4816 	ret
                           4817 	.area CSEG    (CODE)
                           4818 	.area CONST   (CODE)
                           4819 	.area XINIT   (CODE)
   E8F2                    4820 __xinit__use_compress:
   E8F2 00                 4821 	.db #0x00
