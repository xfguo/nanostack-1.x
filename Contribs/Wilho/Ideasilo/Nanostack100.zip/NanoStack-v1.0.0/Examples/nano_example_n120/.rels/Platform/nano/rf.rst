                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Nov 10 2006)
                              4 ; This file generated Fri Feb  1 13:33:40 2008
                              5 ;--------------------------------------------------------
                              6 	.module rf
                              7 	.optsdcc -mmcs51 --model-large
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _rf_tx_enable
                             13 	.globl _rf_command
                             14 	.globl _IRCON2_P2IF
                             15 	.globl _IRCON2_UTX0IF
                             16 	.globl _IRCON2_UTX1IF
                             17 	.globl _IRCON2_P1IF
                             18 	.globl _IRCON2_WDTIF
                             19 	.globl _CY
                             20 	.globl _AC
                             21 	.globl _F0
                             22 	.globl _RS1
                             23 	.globl _RS0
                             24 	.globl _OV
                             25 	.globl _F1
                             26 	.globl _P
                             27 	.globl _IRCON_DMAIF
                             28 	.globl _IRCON_T1IF
                             29 	.globl _IRCON_T2IF
                             30 	.globl _IRCON_T3IF
                             31 	.globl _IRCON_T4IF
                             32 	.globl _IRCON_P0IF
                             33 	.globl _IRCON_STIF
                             34 	.globl _IEN1_DMAIE
                             35 	.globl _IEN1_T1IE
                             36 	.globl _IEN1_T2IE
                             37 	.globl _IEN1_T3IE
                             38 	.globl _IEN1_T4IE
                             39 	.globl _IEN1_P0IE
                             40 	.globl _IEN0_RFERRIE
                             41 	.globl _IEN0_ADCIE
                             42 	.globl _IEN0_URX0IE
                             43 	.globl _IEN0_URX1IE
                             44 	.globl _IEN0_ENCIE
                             45 	.globl _IEN0_STIE
                             46 	.globl _IEN0_EA
                             47 	.globl _EA
                             48 	.globl _P2_4
                             49 	.globl _P2_3
                             50 	.globl _P2_2
                             51 	.globl _P2_1
                             52 	.globl _P2_0
                             53 	.globl _S0CON_ENCIF_0
                             54 	.globl _S0CON_ENCIF_1
                             55 	.globl _P1_7
                             56 	.globl _P1_6
                             57 	.globl _P1_5
                             58 	.globl _P1_4
                             59 	.globl _P1_3
                             60 	.globl _P1_2
                             61 	.globl _P1_1
                             62 	.globl _P1_0
                             63 	.globl _TCON_IT0
                             64 	.globl _TCON_RFERRIF
                             65 	.globl _TCON_IT1
                             66 	.globl _TCON_URX0IF
                             67 	.globl _TCON_ADCIF
                             68 	.globl _TCON_URX1IF
                             69 	.globl _P0_0
                             70 	.globl _P0_1
                             71 	.globl _P0_2
                             72 	.globl _P0_3
                             73 	.globl _P0_4
                             74 	.globl _P0_5
                             75 	.globl _P0_6
                             76 	.globl _P0_7
                             77 	.globl _P2DIR
                             78 	.globl _P1DIR
                             79 	.globl _P0DIR
                             80 	.globl _U1GCR
                             81 	.globl _U1UCR
                             82 	.globl _U1BAUD
                             83 	.globl _U1BUF
                             84 	.globl _U1CSR
                             85 	.globl _P2INP
                             86 	.globl _P1INP
                             87 	.globl _P2SEL
                             88 	.globl _P1SEL
                             89 	.globl _P0SEL
                             90 	.globl _ADCCFG
                             91 	.globl _PERCFG
                             92 	.globl _B
                             93 	.globl _T4CC1
                             94 	.globl _T4CCTL1
                             95 	.globl _T4CC0
                             96 	.globl _T4CCTL0
                             97 	.globl _T4CTL
                             98 	.globl _T4CNT
                             99 	.globl _RFIF
                            100 	.globl _IRCON2
                            101 	.globl _T1CCTL2
                            102 	.globl _T1CCTL1
                            103 	.globl _T1CCTL0
                            104 	.globl _T1CTL
                            105 	.globl _T1CNTH
                            106 	.globl _T1CNTL
                            107 	.globl _RFST
                            108 	.globl _ACC
                            109 	.globl _T1CC2H
                            110 	.globl _T1CC2L
                            111 	.globl _T1CC1H
                            112 	.globl _T1CC1L
                            113 	.globl _T1CC0H
                            114 	.globl _T1CC0L
                            115 	.globl _RFD
                            116 	.globl _TIMIF
                            117 	.globl _DMAREQ
                            118 	.globl _DMAARM
                            119 	.globl _DMA0CFGH
                            120 	.globl _DMA0CFGL
                            121 	.globl _DMA1CFGH
                            122 	.globl _DMA1CFGL
                            123 	.globl _DMAIRQ
                            124 	.globl _PSW
                            125 	.globl _T3CC1
                            126 	.globl _T3CCTL1
                            127 	.globl _T3CC0
                            128 	.globl _T3CCTL0
                            129 	.globl _T3CTL
                            130 	.globl _T3CNT
                            131 	.globl _WDCTL
                            132 	.globl _T2CON
                            133 	.globl _MEMCTR
                            134 	.globl _CLKCON
                            135 	.globl _U0GCR
                            136 	.globl _U0UCR
                            137 	.globl _T2CNF
                            138 	.globl _U0BAUD
                            139 	.globl _U0BUF
                            140 	.globl _IRCON
                            141 	.globl _SLEEP
                            142 	.globl _RNDH
                            143 	.globl _RNDL
                            144 	.globl _ADCH
                            145 	.globl _ADCL
                            146 	.globl _IP1
                            147 	.globl _IEN1
                            148 	.globl _RCCTL
                            149 	.globl _ADCCON3
                            150 	.globl _ADCCON2
                            151 	.globl _ADCCON1
                            152 	.globl _ENCCS
                            153 	.globl _ENCDO
                            154 	.globl _ENCDI
                            155 	.globl _FWDATA
                            156 	.globl _FCTL
                            157 	.globl _FADDRH
                            158 	.globl _FADDRL
                            159 	.globl _FWT
                            160 	.globl _IP0
                            161 	.globl _IEN0
                            162 	.globl _IE
                            163 	.globl _T2THD
                            164 	.globl _T2TLD
                            165 	.globl _T2CAPHPH
                            166 	.globl _T2CAPLPL
                            167 	.globl _T2OF2
                            168 	.globl _T2OF1
                            169 	.globl _T2OF0
                            170 	.globl _P2
                            171 	.globl _T2PEROF2
                            172 	.globl _T2PEROF1
                            173 	.globl _T2PEROF0
                            174 	.globl _S1CON
                            175 	.globl _IEN2
                            176 	.globl _HSRC
                            177 	.globl _S0CON
                            178 	.globl _ST2
                            179 	.globl _ST1
                            180 	.globl _ST0
                            181 	.globl _T2CMP
                            182 	.globl __XPAGE
                            183 	.globl _DPS
                            184 	.globl _RFIM
                            185 	.globl _P1
                            186 	.globl _P0INP
                            187 	.globl _P1IEN
                            188 	.globl _PICTL
                            189 	.globl _P2IFG
                            190 	.globl _P1IFG
                            191 	.globl _P0IFG
                            192 	.globl _TCON
                            193 	.globl _PCON
                            194 	.globl _U0CSR
                            195 	.globl _DPH1
                            196 	.globl _DPL1
                            197 	.globl _DPH0
                            198 	.globl _DPL0
                            199 	.globl _SP
                            200 	.globl _P0
                            201 	.globl _rf_initialized
                            202 	.globl _rf_lock
                            203 	.globl _ft_buffer
                            204 	.globl _rf_mac_address
                            205 	.globl _rf_manfid
                            206 	.globl _tx_flags
                            207 	.globl _rx_flags
                            208 	.globl _rf_tx_power
                            209 	.globl _RFD_SHADOW
                            210 	.globl _RFSTATUS
                            211 	.globl _CHIPID
                            212 	.globl _CHVER
                            213 	.globl _FSMTC1
                            214 	.globl _RXFIFOCNT
                            215 	.globl _IOCFG3
                            216 	.globl _IOCFG2
                            217 	.globl _IOCFG1
                            218 	.globl _IOCFG0
                            219 	.globl _SHORTADDRL
                            220 	.globl _SHORTADDRH
                            221 	.globl _PANIDL
                            222 	.globl _PANIDH
                            223 	.globl _IEEE_ADDR7
                            224 	.globl _IEEE_ADDR6
                            225 	.globl _IEEE_ADDR5
                            226 	.globl _IEEE_ADDR4
                            227 	.globl _IEEE_ADDR3
                            228 	.globl _IEEE_ADDR2
                            229 	.globl _IEEE_ADDR1
                            230 	.globl _IEEE_ADDR0
                            231 	.globl _DACTSTL
                            232 	.globl _DACTSTH
                            233 	.globl _ADCTSTL
                            234 	.globl _ADCTSTH
                            235 	.globl _FSMSTATE
                            236 	.globl _AGCCTRLL
                            237 	.globl _AGCCTRLH
                            238 	.globl _MANORL
                            239 	.globl _MANORH
                            240 	.globl _MANANDL
                            241 	.globl _MANANDH
                            242 	.globl _FSMTCL
                            243 	.globl _FSMTCH
                            244 	.globl _RFPWR
                            245 	.globl _CSPT
                            246 	.globl _CSPCTRL
                            247 	.globl _CSPZ
                            248 	.globl _CSPY
                            249 	.globl _CSPX
                            250 	.globl _FSCTRLL
                            251 	.globl _FSCTRLH
                            252 	.globl _RXCTRL1L
                            253 	.globl _RXCTRL1H
                            254 	.globl _RXCTRL0L
                            255 	.globl _RXCTRL0H
                            256 	.globl _TXCTRLL
                            257 	.globl _TXCTRLH
                            258 	.globl _SYNCWORDL
                            259 	.globl _SYNCWORDH
                            260 	.globl _RSSIL
                            261 	.globl _RSSIH
                            262 	.globl _MDMCTRL1L
                            263 	.globl _MDMCTRL1H
                            264 	.globl _MDMCTRL0L
                            265 	.globl _MDMCTRL0H
                            266 	.globl _rf_channel_set
                            267 	.globl _rf_power_set
                            268 	.globl _rf_rx_enable
                            269 	.globl _rf_rx_disable
                            270 	.globl _rf_init
                            271 	.globl _rf_set_address
                            272 	.globl _rf_address_decoder_mode
                            273 	.globl _rf_analyze_rssi
                            274 	.globl _rf_cca_check
                            275 	.globl _rf_send_ack
                            276 	.globl _rf_write
                            277 	.globl _rf_mac_get
                            278 	.globl _rf_rx_callback
                            279 	.globl _rf_ISR
                            280 	.globl _rf_error_ISR
                            281 ;--------------------------------------------------------
                            282 ; special function registers
                            283 ;--------------------------------------------------------
                            284 	.area RSEG    (DATA)
                    0080    285 _P0	=	0x0080
                    0081    286 _SP	=	0x0081
                    0082    287 _DPL0	=	0x0082
                    0083    288 _DPH0	=	0x0083
                    0084    289 _DPL1	=	0x0084
                    0085    290 _DPH1	=	0x0085
                    0086    291 _U0CSR	=	0x0086
                    0087    292 _PCON	=	0x0087
                    0088    293 _TCON	=	0x0088
                    0089    294 _P0IFG	=	0x0089
                    008A    295 _P1IFG	=	0x008a
                    008B    296 _P2IFG	=	0x008b
                    008C    297 _PICTL	=	0x008c
                    008D    298 _P1IEN	=	0x008d
                    008F    299 _P0INP	=	0x008f
                    0090    300 _P1	=	0x0090
                    0091    301 _RFIM	=	0x0091
                    0092    302 _DPS	=	0x0092
                    0093    303 __XPAGE	=	0x0093
                    0094    304 _T2CMP	=	0x0094
                    0095    305 _ST0	=	0x0095
                    0096    306 _ST1	=	0x0096
                    0097    307 _ST2	=	0x0097
                    0098    308 _S0CON	=	0x0098
                    0099    309 _HSRC	=	0x0099
                    009A    310 _IEN2	=	0x009a
                    009B    311 _S1CON	=	0x009b
                    009C    312 _T2PEROF0	=	0x009c
                    009D    313 _T2PEROF1	=	0x009d
                    009E    314 _T2PEROF2	=	0x009e
                    00A0    315 _P2	=	0x00a0
                    00A1    316 _T2OF0	=	0x00a1
                    00A2    317 _T2OF1	=	0x00a2
                    00A3    318 _T2OF2	=	0x00a3
                    00A4    319 _T2CAPLPL	=	0x00a4
                    00A5    320 _T2CAPHPH	=	0x00a5
                    00A6    321 _T2TLD	=	0x00a6
                    00A7    322 _T2THD	=	0x00a7
                    00A8    323 _IE	=	0x00a8
                    00A8    324 _IEN0	=	0x00a8
                    00A9    325 _IP0	=	0x00a9
                    00AB    326 _FWT	=	0x00ab
                    00AC    327 _FADDRL	=	0x00ac
                    00AD    328 _FADDRH	=	0x00ad
                    00AE    329 _FCTL	=	0x00ae
                    00AF    330 _FWDATA	=	0x00af
                    00B1    331 _ENCDI	=	0x00b1
                    00B2    332 _ENCDO	=	0x00b2
                    00B3    333 _ENCCS	=	0x00b3
                    00B4    334 _ADCCON1	=	0x00b4
                    00B5    335 _ADCCON2	=	0x00b5
                    00B6    336 _ADCCON3	=	0x00b6
                    00B7    337 _RCCTL	=	0x00b7
                    00B8    338 _IEN1	=	0x00b8
                    00B9    339 _IP1	=	0x00b9
                    00BA    340 _ADCL	=	0x00ba
                    00BB    341 _ADCH	=	0x00bb
                    00BC    342 _RNDL	=	0x00bc
                    00BD    343 _RNDH	=	0x00bd
                    00BE    344 _SLEEP	=	0x00be
                    00C0    345 _IRCON	=	0x00c0
                    00C1    346 _U0BUF	=	0x00c1
                    00C2    347 _U0BAUD	=	0x00c2
                    00C3    348 _T2CNF	=	0x00c3
                    00C4    349 _U0UCR	=	0x00c4
                    00C5    350 _U0GCR	=	0x00c5
                    00C6    351 _CLKCON	=	0x00c6
                    00C7    352 _MEMCTR	=	0x00c7
                    00C8    353 _T2CON	=	0x00c8
                    00C9    354 _WDCTL	=	0x00c9
                    00CA    355 _T3CNT	=	0x00ca
                    00CB    356 _T3CTL	=	0x00cb
                    00CC    357 _T3CCTL0	=	0x00cc
                    00CD    358 _T3CC0	=	0x00cd
                    00CE    359 _T3CCTL1	=	0x00ce
                    00CF    360 _T3CC1	=	0x00cf
                    00D0    361 _PSW	=	0x00d0
                    00D1    362 _DMAIRQ	=	0x00d1
                    00D2    363 _DMA1CFGL	=	0x00d2
                    00D3    364 _DMA1CFGH	=	0x00d3
                    00D4    365 _DMA0CFGL	=	0x00d4
                    00D5    366 _DMA0CFGH	=	0x00d5
                    00D6    367 _DMAARM	=	0x00d6
                    00D7    368 _DMAREQ	=	0x00d7
                    00D8    369 _TIMIF	=	0x00d8
                    00D9    370 _RFD	=	0x00d9
                    00DA    371 _T1CC0L	=	0x00da
                    00DB    372 _T1CC0H	=	0x00db
                    00DC    373 _T1CC1L	=	0x00dc
                    00DD    374 _T1CC1H	=	0x00dd
                    00DE    375 _T1CC2L	=	0x00de
                    00DF    376 _T1CC2H	=	0x00df
                    00E0    377 _ACC	=	0x00e0
                    00E1    378 _RFST	=	0x00e1
                    00E2    379 _T1CNTL	=	0x00e2
                    00E3    380 _T1CNTH	=	0x00e3
                    00E4    381 _T1CTL	=	0x00e4
                    00E5    382 _T1CCTL0	=	0x00e5
                    00E6    383 _T1CCTL1	=	0x00e6
                    00E7    384 _T1CCTL2	=	0x00e7
                    00E8    385 _IRCON2	=	0x00e8
                    00E9    386 _RFIF	=	0x00e9
                    00EA    387 _T4CNT	=	0x00ea
                    00EB    388 _T4CTL	=	0x00eb
                    00EC    389 _T4CCTL0	=	0x00ec
                    00ED    390 _T4CC0	=	0x00ed
                    00EE    391 _T4CCTL1	=	0x00ee
                    00EF    392 _T4CC1	=	0x00ef
                    00F0    393 _B	=	0x00f0
                    00F1    394 _PERCFG	=	0x00f1
                    00F2    395 _ADCCFG	=	0x00f2
                    00F3    396 _P0SEL	=	0x00f3
                    00F4    397 _P1SEL	=	0x00f4
                    00F5    398 _P2SEL	=	0x00f5
                    00F6    399 _P1INP	=	0x00f6
                    00F7    400 _P2INP	=	0x00f7
                    00F8    401 _U1CSR	=	0x00f8
                    00F9    402 _U1BUF	=	0x00f9
                    00FA    403 _U1BAUD	=	0x00fa
                    00FB    404 _U1UCR	=	0x00fb
                    00FC    405 _U1GCR	=	0x00fc
                    00FD    406 _P0DIR	=	0x00fd
                    00FE    407 _P1DIR	=	0x00fe
                    00FF    408 _P2DIR	=	0x00ff
                            409 ;--------------------------------------------------------
                            410 ; special function bits
                            411 ;--------------------------------------------------------
                            412 	.area RSEG    (DATA)
                    0087    413 _P0_7	=	0x0087
                    0086    414 _P0_6	=	0x0086
                    0085    415 _P0_5	=	0x0085
                    0084    416 _P0_4	=	0x0084
                    0083    417 _P0_3	=	0x0083
                    0082    418 _P0_2	=	0x0082
                    0081    419 _P0_1	=	0x0081
                    0080    420 _P0_0	=	0x0080
                    008F    421 _TCON_URX1IF	=	0x008f
                    008D    422 _TCON_ADCIF	=	0x008d
                    008B    423 _TCON_URX0IF	=	0x008b
                    008A    424 _TCON_IT1	=	0x008a
                    0089    425 _TCON_RFERRIF	=	0x0089
                    0088    426 _TCON_IT0	=	0x0088
                    0090    427 _P1_0	=	0x0090
                    0091    428 _P1_1	=	0x0091
                    0092    429 _P1_2	=	0x0092
                    0093    430 _P1_3	=	0x0093
                    0094    431 _P1_4	=	0x0094
                    0095    432 _P1_5	=	0x0095
                    0096    433 _P1_6	=	0x0096
                    0097    434 _P1_7	=	0x0097
                    0099    435 _S0CON_ENCIF_1	=	0x0099
                    0098    436 _S0CON_ENCIF_0	=	0x0098
                    00A0    437 _P2_0	=	0x00a0
                    00A1    438 _P2_1	=	0x00a1
                    00A2    439 _P2_2	=	0x00a2
                    00A3    440 _P2_3	=	0x00a3
                    00A4    441 _P2_4	=	0x00a4
                    00AF    442 _EA	=	0x00af
                    00AF    443 _IEN0_EA	=	0x00af
                    00AD    444 _IEN0_STIE	=	0x00ad
                    00AC    445 _IEN0_ENCIE	=	0x00ac
                    00AB    446 _IEN0_URX1IE	=	0x00ab
                    00AA    447 _IEN0_URX0IE	=	0x00aa
                    00A9    448 _IEN0_ADCIE	=	0x00a9
                    00A8    449 _IEN0_RFERRIE	=	0x00a8
                    00BD    450 _IEN1_P0IE	=	0x00bd
                    00BC    451 _IEN1_T4IE	=	0x00bc
                    00BB    452 _IEN1_T3IE	=	0x00bb
                    00BA    453 _IEN1_T2IE	=	0x00ba
                    00B9    454 _IEN1_T1IE	=	0x00b9
                    00B8    455 _IEN1_DMAIE	=	0x00b8
                    00C7    456 _IRCON_STIF	=	0x00c7
                    00C5    457 _IRCON_P0IF	=	0x00c5
                    00C4    458 _IRCON_T4IF	=	0x00c4
                    00C3    459 _IRCON_T3IF	=	0x00c3
                    00C2    460 _IRCON_T2IF	=	0x00c2
                    00C1    461 _IRCON_T1IF	=	0x00c1
                    00C0    462 _IRCON_DMAIF	=	0x00c0
                    00D0    463 _P	=	0x00d0
                    00D1    464 _F1	=	0x00d1
                    00D2    465 _OV	=	0x00d2
                    00D3    466 _RS0	=	0x00d3
                    00D4    467 _RS1	=	0x00d4
                    00D5    468 _F0	=	0x00d5
                    00D6    469 _AC	=	0x00d6
                    00D7    470 _CY	=	0x00d7
                    00EC    471 _IRCON2_WDTIF	=	0x00ec
                    00EB    472 _IRCON2_P1IF	=	0x00eb
                    00EA    473 _IRCON2_UTX1IF	=	0x00ea
                    00E9    474 _IRCON2_UTX0IF	=	0x00e9
                    00E8    475 _IRCON2_P2IF	=	0x00e8
                            476 ;--------------------------------------------------------
                            477 ; overlayable register banks
                            478 ;--------------------------------------------------------
                            479 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     480 	.ds 8
                            481 ;--------------------------------------------------------
                            482 ; overlayable bit register bank
                            483 ;--------------------------------------------------------
                            484 	.area BIT_BANK	(REL,OVR,DATA)
   0020                     485 bits:
   0020                     486 	.ds 1
                    8000    487 	b0 = bits[0]
                    8100    488 	b1 = bits[1]
                    8200    489 	b2 = bits[2]
                    8300    490 	b3 = bits[3]
                    8400    491 	b4 = bits[4]
                    8500    492 	b5 = bits[5]
                    8600    493 	b6 = bits[6]
                    8700    494 	b7 = bits[7]
                            495 ;--------------------------------------------------------
                            496 ; internal ram data
                            497 ;--------------------------------------------------------
                            498 	.area DSEG    (DATA)
                            499 ;--------------------------------------------------------
                            500 ; overlayable items in internal ram 
                            501 ;--------------------------------------------------------
                            502 	.area OSEG    (OVR,DATA)
                            503 ;--------------------------------------------------------
                            504 ; indirectly addressable internal ram data
                            505 ;--------------------------------------------------------
                            506 	.area ISEG    (DATA)
                            507 ;--------------------------------------------------------
                            508 ; bit data
                            509 ;--------------------------------------------------------
                            510 	.area BSEG    (BIT)
                            511 ;--------------------------------------------------------
                            512 ; paged external ram data
                            513 ;--------------------------------------------------------
                            514 	.area PSEG    (PAG,XDATA)
                            515 ;--------------------------------------------------------
                            516 ; external ram data
                            517 ;--------------------------------------------------------
                            518 	.area XSEG    (XDATA)
                    DF02    519 _MDMCTRL0H	=	0xdf02
                    DF03    520 _MDMCTRL0L	=	0xdf03
                    DF04    521 _MDMCTRL1H	=	0xdf04
                    DF05    522 _MDMCTRL1L	=	0xdf05
                    DF06    523 _RSSIH	=	0xdf06
                    DF07    524 _RSSIL	=	0xdf07
                    DF08    525 _SYNCWORDH	=	0xdf08
                    DF09    526 _SYNCWORDL	=	0xdf09
                    DF0A    527 _TXCTRLH	=	0xdf0a
                    DF0B    528 _TXCTRLL	=	0xdf0b
                    DF0C    529 _RXCTRL0H	=	0xdf0c
                    DF0D    530 _RXCTRL0L	=	0xdf0d
                    DF0E    531 _RXCTRL1H	=	0xdf0e
                    DF0F    532 _RXCTRL1L	=	0xdf0f
                    DF10    533 _FSCTRLH	=	0xdf10
                    DF11    534 _FSCTRLL	=	0xdf11
                    DF12    535 _CSPX	=	0xdf12
                    DF13    536 _CSPY	=	0xdf13
                    DF14    537 _CSPZ	=	0xdf14
                    DF15    538 _CSPCTRL	=	0xdf15
                    DF16    539 _CSPT	=	0xdf16
                    DF17    540 _RFPWR	=	0xdf17
                    DF20    541 _FSMTCH	=	0xdf20
                    DF21    542 _FSMTCL	=	0xdf21
                    DF22    543 _MANANDH	=	0xdf22
                    DF23    544 _MANANDL	=	0xdf23
                    DF24    545 _MANORH	=	0xdf24
                    DF25    546 _MANORL	=	0xdf25
                    DF26    547 _AGCCTRLH	=	0xdf26
                    DF27    548 _AGCCTRLL	=	0xdf27
                    DF39    549 _FSMSTATE	=	0xdf39
                    DF3A    550 _ADCTSTH	=	0xdf3a
                    DF3B    551 _ADCTSTL	=	0xdf3b
                    DF3C    552 _DACTSTH	=	0xdf3c
                    DF3D    553 _DACTSTL	=	0xdf3d
                    DF43    554 _IEEE_ADDR0	=	0xdf43
                    DF44    555 _IEEE_ADDR1	=	0xdf44
                    DF45    556 _IEEE_ADDR2	=	0xdf45
                    DF46    557 _IEEE_ADDR3	=	0xdf46
                    DF47    558 _IEEE_ADDR4	=	0xdf47
                    DF48    559 _IEEE_ADDR5	=	0xdf48
                    DF49    560 _IEEE_ADDR6	=	0xdf49
                    DF4A    561 _IEEE_ADDR7	=	0xdf4a
                    DF4B    562 _PANIDH	=	0xdf4b
                    DF4C    563 _PANIDL	=	0xdf4c
                    DF4D    564 _SHORTADDRH	=	0xdf4d
                    DF4E    565 _SHORTADDRL	=	0xdf4e
                    DF4F    566 _IOCFG0	=	0xdf4f
                    DF50    567 _IOCFG1	=	0xdf50
                    DF51    568 _IOCFG2	=	0xdf51
                    DF52    569 _IOCFG3	=	0xdf52
                    DF53    570 _RXFIFOCNT	=	0xdf53
                    DF54    571 _FSMTC1	=	0xdf54
                    DF60    572 _CHVER	=	0xdf60
                    DF61    573 _CHIPID	=	0xdf61
                    DF62    574 _RFSTATUS	=	0xdf62
                    DFD9    575 _RFD_SHADOW	=	0xdfd9
   F033                     576 _rf_tx_power::
   F033                     577 	.ds 1
   F034                     578 _rx_flags::
   F034                     579 	.ds 1
   F035                     580 _tx_flags::
   F035                     581 	.ds 1
   F036                     582 _rf_manfid::
   F036                     583 	.ds 2
   F038                     584 _rf_mac_address::
   F038                     585 	.ds 13
   F045                     586 _ft_buffer::
   F045                     587 	.ds 8
                            588 ;--------------------------------------------------------
                            589 ; external initialized ram data
                            590 ;--------------------------------------------------------
                            591 	.area XISEG   (XDATA)
   F0F1                     592 _rf_lock::
   F0F1                     593 	.ds 3
   F0F4                     594 _rf_initialized::
   F0F4                     595 	.ds 1
                            596 	.area HOME    (CODE)
                            597 	.area GSINIT0 (CODE)
                            598 	.area GSINIT1 (CODE)
                            599 	.area GSINIT2 (CODE)
                            600 	.area GSINIT3 (CODE)
                            601 	.area GSINIT4 (CODE)
                            602 	.area GSINIT5 (CODE)
                            603 	.area GSINIT  (CODE)
                            604 	.area GSFINAL (CODE)
                            605 	.area CSEG    (CODE)
                            606 ;--------------------------------------------------------
                            607 ; global & static initialisations
                            608 ;--------------------------------------------------------
                            609 	.area HOME    (CODE)
                            610 	.area GSINIT  (CODE)
                            611 	.area GSFINAL (CODE)
                            612 	.area GSINIT  (CODE)
                            613 ;--------------------------------------------------------
                            614 ; Home
                            615 ;--------------------------------------------------------
                            616 	.area HOME    (CODE)
                            617 	.area CSEG    (CODE)
                            618 ;--------------------------------------------------------
                            619 ; code
                            620 ;--------------------------------------------------------
                            621 	.area CSEG    (CODE)
                            622 ;------------------------------------------------------------
                            623 ;Allocation info for local variables in function 'rf_command'
                            624 ;------------------------------------------------------------
                            625 ;command                   Allocated to registers r2 
                            626 ;fifo_count                Allocated to registers r3 
                            627 ;------------------------------------------------------------
                            628 ;	../../Platform/nano/rf.c:117: void rf_command(uint8_t command)
                            629 ;	-----------------------------------------
                            630 ;	 function rf_command
                            631 ;	-----------------------------------------
   A06C                     632 _rf_command:
                    0002    633 	ar2 = 0x02
                    0003    634 	ar3 = 0x03
                    0004    635 	ar4 = 0x04
                    0005    636 	ar5 = 0x05
                    0006    637 	ar6 = 0x06
                    0007    638 	ar7 = 0x07
                    0000    639 	ar0 = 0x00
                    0001    640 	ar1 = 0x01
                            641 ;	genReceive
   A06C AA 82               642 	mov	r2,dpl
                            643 ;	../../Platform/nano/rf.c:119: if (command >= 0xE0)
                            644 ;	genCmpLt
                            645 ;	genCmp
   A06E BA E0 00            646 	cjne	r2,#0xE0,00126$
   A071                     647 00126$:
                            648 ;	genIfxJump
                            649 ;	Peephole 112.b	changed ljmp to sjmp
                            650 ;	Peephole 160.a	removed sjmp by inverse jump logic
   A071 40 3E               651 	jc	00115$
                            652 ;	Peephole 300	removed redundant label 00127$
                            653 ;	../../Platform/nano/rf.c:122: switch (command)
                            654 ;	genCmpEq
                            655 ;	gencjneshort
   A073 BA E2 02            656 	cjne	r2,#0xE2,00128$
                            657 ;	Peephole 112.b	changed ljmp to sjmp
   A076 80 08               658 	sjmp	00103$
   A078                     659 00128$:
                            660 ;	genCmpEq
                            661 ;	gencjneshort
   A078 BA E3 02            662 	cjne	r2,#0xE3,00129$
                            663 ;	Peephole 112.b	changed ljmp to sjmp
   A07B 80 03               664 	sjmp	00103$
   A07D                     665 00129$:
                            666 ;	genCmpEq
                            667 ;	gencjneshort
                            668 ;	Peephole 112.b	changed ljmp to sjmp
                            669 ;	Peephole 198.b	optimized misc jump sequence
   A07D BA E5 2E            670 	cjne	r2,#0xE5,00106$
                            671 ;	Peephole 200.b	removed redundant sjmp
                            672 ;	Peephole 300	removed redundant label 00130$
                            673 ;	Peephole 300	removed redundant label 00131$
                            674 ;	../../Platform/nano/rf.c:126: case ISTXON:
   A080                     675 00103$:
                            676 ;	../../Platform/nano/rf.c:127: fifo_count = RXFIFOCNT;
                            677 ;	genAssign
   A080 90 DF 53            678 	mov	dptr,#_RXFIFOCNT
   A083 E0                  679 	movx	a,@dptr
   A084 FB                  680 	mov	r3,a
   A085 A3                  681 	inc	dptr
   A086 E0                  682 	movx	a,@dptr
   A087 FC                  683 	mov	r4,a
                            684 ;	genCast
                            685 ;	../../Platform/nano/rf.c:128: RFST = command;
                            686 ;	genAssign
   A088 8A E1               687 	mov	_RFST,r2
                            688 ;	../../Platform/nano/rf.c:129: pause_us(1);
                            689 ;	genCall
                            690 ;	Peephole 182.b	used 16 bit load of dptr
   A08A 90 00 01            691 	mov	dptr,#0x0001
   A08D C0 03               692 	push	ar3
   A08F 12 37 B7            693 	lcall	_pause_us
   A092 D0 03               694 	pop	ar3
                            695 ;	../../Platform/nano/rf.c:130: if (fifo_count != RXFIFOCNT)
                            696 ;	genAssign
   A094 90 DF 53            697 	mov	dptr,#_RXFIFOCNT
   A097 E0                  698 	movx	a,@dptr
   A098 FC                  699 	mov	r4,a
   A099 A3                  700 	inc	dptr
   A09A E0                  701 	movx	a,@dptr
   A09B FD                  702 	mov	r5,a
                            703 ;	genCast
   A09C 7E 00               704 	mov	r6,#0x00
                            705 ;	genCmpEq
                            706 ;	gencjneshort
   A09E EB                  707 	mov	a,r3
   A09F B5 04 05            708 	cjne	a,ar4,00132$
   A0A2 EE                  709 	mov	a,r6
   A0A3 B5 05 01            710 	cjne	a,ar5,00132$
                            711 ;	Peephole 112.b	changed ljmp to sjmp
                            712 ;	Peephole 251.b	replaced sjmp to ret with ret
   A0A6 22                  713 	ret
   A0A7                     714 00132$:
                            715 ;	../../Platform/nano/rf.c:132: RFST = ISFLUSHRX;
                            716 ;	genAssign
   A0A7 75 E1 E6            717 	mov	_RFST,#0xE6
                            718 ;	../../Platform/nano/rf.c:133: RFST = ISFLUSHRX;
                            719 ;	genAssign
   A0AA 75 E1 E6            720 	mov	_RFST,#0xE6
                            721 ;	../../Platform/nano/rf.c:135: break;
                            722 ;	../../Platform/nano/rf.c:137: default:
                            723 ;	Peephole 112.b	changed ljmp to sjmp
                            724 ;	Peephole 251.b	replaced sjmp to ret with ret
   A0AD 22                  725 	ret
   A0AE                     726 00106$:
                            727 ;	../../Platform/nano/rf.c:138: RFST = command;
                            728 ;	genAssign
   A0AE 8A E1               729 	mov	_RFST,r2
                            730 ;	../../Platform/nano/rf.c:139: }
                            731 ;	Peephole 112.b	changed ljmp to sjmp
                            732 ;	Peephole 251.b	replaced sjmp to ret with ret
   A0B0 22                  733 	ret
   A0B1                     734 00115$:
                            735 ;	../../Platform/nano/rf.c:141: else if (command == SSTART)
                            736 ;	genCmpEq
                            737 ;	gencjneshort
                            738 ;	Peephole 112.b	changed ljmp to sjmp
                            739 ;	Peephole 198.b	optimized misc jump sequence
   A0B1 BA DE 10            740 	cjne	r2,#0xDE,00112$
                            741 ;	Peephole 200.b	removed redundant sjmp
                            742 ;	Peephole 300	removed redundant label 00133$
                            743 ;	Peephole 300	removed redundant label 00134$
                            744 ;	../../Platform/nano/rf.c:143: RFIF &= ~IRQ_CSP_STOP;	/*clear IRQ flag*/
                            745 ;	genAnd
   A0B4 53 E9 FD            746 	anl	_RFIF,#0xFD
                            747 ;	../../Platform/nano/rf.c:144: RFST = SSTOP;	/*make sure there is a stop in the end*/
                            748 ;	genAssign
   A0B7 75 E1 DF            749 	mov	_RFST,#0xDF
                            750 ;	../../Platform/nano/rf.c:145: RFST = ISSTART;	/*start execution*/
                            751 ;	genAssign
   A0BA 75 E1 FE            752 	mov	_RFST,#0xFE
                            753 ;	../../Platform/nano/rf.c:146: while((RFIF & IRQ_CSP_STOP) == 0);
   A0BD                     754 00108$:
                            755 ;	genAnd
   A0BD E5 E9               756 	mov	a,_RFIF
                            757 ;	genIfxJump
                            758 ;	Peephole 108.e	removed ljmp by inverse jump logic
   A0BF 20 E1 04            759 	jb	acc.1,00117$
                            760 ;	Peephole 300	removed redundant label 00135$
                            761 ;	Peephole 112.b	changed ljmp to sjmp
   A0C2 80 F9               762 	sjmp	00108$
   A0C4                     763 00112$:
                            764 ;	../../Platform/nano/rf.c:150: RFST = command;	/*write command*/
                            765 ;	genAssign
   A0C4 8A E1               766 	mov	_RFST,r2
   A0C6                     767 00117$:
   A0C6 22                  768 	ret
                            769 ;------------------------------------------------------------
                            770 ;Allocation info for local variables in function 'rf_channel_set'
                            771 ;------------------------------------------------------------
                            772 ;channel                   Allocated to registers r2 
                            773 ;freq                      Allocated to registers r3 r4 
                            774 ;------------------------------------------------------------
                            775 ;	../../Platform/nano/rf.c:166: portCHAR rf_channel_set(uint8_t channel)
                            776 ;	-----------------------------------------
                            777 ;	 function rf_channel_set
                            778 ;	-----------------------------------------
   A0C7                     779 _rf_channel_set:
                            780 ;	genReceive
   A0C7 AA 82               781 	mov	r2,dpl
                            782 ;	../../Platform/nano/rf.c:170: if ( (channel < 11) || (channel > 26) ) return -1;
                            783 ;	genCmpLt
                            784 ;	genCmp
   A0C9 BA 0B 00            785 	cjne	r2,#0x0B,00107$
   A0CC                     786 00107$:
                            787 ;	genIfxJump
                            788 ;	Peephole 112.b	changed ljmp to sjmp
                            789 ;	Peephole 160.a	removed sjmp by inverse jump logic
   A0CC 40 05               790 	jc	00101$
                            791 ;	Peephole 300	removed redundant label 00108$
                            792 ;	genCmpGt
                            793 ;	genCmp
                            794 ;	genIfxJump
                            795 ;	Peephole 108.a	removed ljmp by inverse jump logic
                            796 ;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
   A0CE EA                  797 	mov	a,r2
   A0CF 24 E5               798 	add	a,#0xff - 0x1A
   A0D1 50 04               799 	jnc	00102$
                            800 ;	Peephole 300	removed redundant label 00109$
   A0D3                     801 00101$:
                            802 ;	genRet
   A0D3 75 82 FF            803 	mov	dpl,#0xFF
                            804 ;	Peephole 112.b	changed ljmp to sjmp
                            805 ;	Peephole 251.b	replaced sjmp to ret with ret
   A0D6 22                  806 	ret
   A0D7                     807 00102$:
                            808 ;	../../Platform/nano/rf.c:173: freq = (uint16_t) channel - 11;
                            809 ;	genCast
   A0D7 8A 03               810 	mov	ar3,r2
   A0D9 7C 00               811 	mov	r4,#0x00
                            812 ;	genMinus
   A0DB EB                  813 	mov	a,r3
   A0DC 24 F5               814 	add	a,#0xf5
   A0DE FB                  815 	mov	r3,a
   A0DF EC                  816 	mov	a,r4
   A0E0 34 FF               817 	addc	a,#0xff
   A0E2 FC                  818 	mov	r4,a
                            819 ;	../../Platform/nano/rf.c:174: freq *= 5;	/*channel spacing*/
                            820 ;	genIpush
   A0E3 C0 02               821 	push	ar2
   A0E5 74 05               822 	mov	a,#0x05
   A0E7 C0 E0               823 	push	acc
                            824 ;	Peephole 181	changed mov to clr
   A0E9 E4                  825 	clr	a
   A0EA C0 E0               826 	push	acc
                            827 ;	genCall
   A0EC 8B 82               828 	mov	dpl,r3
   A0EE 8C 83               829 	mov	dph,r4
   A0F0 12 E1 6A            830 	lcall	__mulint
   A0F3 AD 82               831 	mov	r5,dpl
   A0F5 AE 83               832 	mov	r6,dph
   A0F7 15 81               833 	dec	sp
   A0F9 15 81               834 	dec	sp
   A0FB D0 02               835 	pop	ar2
                            836 ;	genAssign
   A0FD 8D 03               837 	mov	ar3,r5
   A0FF 8E 04               838 	mov	ar4,r6
                            839 ;	../../Platform/nano/rf.c:175: freq += 357; /*correct channel range*/
                            840 ;	genPlus
                            841 ;     genPlusIncr
   A101 74 65               842 	mov	a,#0x65
                            843 ;	Peephole 236.a	used r3 instead of ar3
   A103 2B                  844 	add	a,r3
   A104 FB                  845 	mov	r3,a
   A105 74 01               846 	mov	a,#0x01
                            847 ;	Peephole 236.b	used r4 instead of ar4
   A107 3C                  848 	addc	a,r4
   A108 FC                  849 	mov	r4,a
                            850 ;	../../Platform/nano/rf.c:176: freq |= 0x4000; /*LOCK_THR = 1*/
                            851 ;	genOr
   A109 43 04 40            852 	orl	ar4,#0x40
                            853 ;	../../Platform/nano/rf.c:178: FSCTRLH = (freq >> 8);
                            854 ;	genRightShift
                            855 ;	genRightShiftLiteral
                            856 ;	genrshTwo
   A10C 8C 05               857 	mov	ar5,r4
   A10E 7E 00               858 	mov	r6,#0x00
                            859 ;	genAssign
   A110 90 DF 10            860 	mov	dptr,#_FSCTRLH
   A113 ED                  861 	mov	a,r5
   A114 F0                  862 	movx	@dptr,a
   A115 A3                  863 	inc	dptr
   A116 EE                  864 	mov	a,r6
   A117 F0                  865 	movx	@dptr,a
                            866 ;	../../Platform/nano/rf.c:179: FSCTRLL = (uint8_t)freq;	
                            867 ;	genCast
                            868 ;	genCast
   A118 90 DF 11            869 	mov	dptr,#_FSCTRLL
   A11B EB                  870 	mov	a,r3
   A11C F0                  871 	movx	@dptr,a
   A11D A3                  872 	inc	dptr
                            873 ;	Peephole 181	changed mov to clr
   A11E E4                  874 	clr	a
   A11F F0                  875 	movx	@dptr,a
                            876 ;	../../Platform/nano/rf.c:181: return (int8_t) channel;
                            877 ;	genRet
   A120 8A 82               878 	mov	dpl,r2
                            879 ;	Peephole 300	removed redundant label 00104$
   A122 22                  880 	ret
                            881 ;------------------------------------------------------------
                            882 ;Allocation info for local variables in function 'rf_power_set'
                            883 ;------------------------------------------------------------
                            884 ;new_power                 Allocated to registers r2 
                            885 ;power                     Allocated to registers r3 r4 
                            886 ;------------------------------------------------------------
                            887 ;	../../Platform/nano/rf.c:202: portCHAR rf_power_set(uint8_t new_power)
                            888 ;	-----------------------------------------
                            889 ;	 function rf_power_set
                            890 ;	-----------------------------------------
   A123                     891 _rf_power_set:
                            892 ;	genReceive
                            893 ;	../../Platform/nano/rf.c:206: if (new_power > 100) return -1;
                            894 ;	genCmpGt
                            895 ;	genCmp
                            896 ;	genIfxJump
                            897 ;	Peephole 108.a	removed ljmp by inverse jump logic
                            898 ;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
                            899 ;	peephole 177.g	optimized mov sequence
   A123 E5 82               900 	mov	a,dpl
   A125 FA                  901 	mov	r2,a
   A126 24 9B               902 	add	a,#0xff - 0x64
   A128 50 04               903 	jnc	00102$
                            904 ;	Peephole 300	removed redundant label 00106$
                            905 ;	genRet
   A12A 75 82 FF            906 	mov	dpl,#0xFF
                            907 ;	Peephole 112.b	changed ljmp to sjmp
                            908 ;	Peephole 251.b	replaced sjmp to ret with ret
   A12D 22                  909 	ret
   A12E                     910 00102$:
                            911 ;	../../Platform/nano/rf.c:208: power = 31 * new_power;
                            912 ;	genMult
                            913 ;	genMultOneByte
   A12E EA                  914 	mov	a,r2
   A12F 75 F0 1F            915 	mov	b,#0x1F
   A132 A4                  916 	mul	ab
   A133 FB                  917 	mov	r3,a
   A134 AC F0               918 	mov	r4,b
                            919 ;	../../Platform/nano/rf.c:209: power /= 100;
                            920 ;	genIpush
   A136 C0 02               921 	push	ar2
   A138 74 64               922 	mov	a,#0x64
   A13A C0 E0               923 	push	acc
                            924 ;	Peephole 181	changed mov to clr
   A13C E4                  925 	clr	a
   A13D C0 E0               926 	push	acc
                            927 ;	genCall
   A13F 8B 82               928 	mov	dpl,r3
   A141 8C 83               929 	mov	dph,r4
   A143 12 DF 65            930 	lcall	__divuint
   A146 AD 82               931 	mov	r5,dpl
   A148 AE 83               932 	mov	r6,dph
   A14A 15 81               933 	dec	sp
   A14C 15 81               934 	dec	sp
   A14E D0 02               935 	pop	ar2
                            936 ;	genAssign
   A150 8D 03               937 	mov	ar3,r5
   A152 8E 04               938 	mov	ar4,r6
                            939 ;	../../Platform/nano/rf.c:210: power += 0xA160;
                            940 ;	genPlus
                            941 ;     genPlusIncr
   A154 74 60               942 	mov	a,#0x60
                            943 ;	Peephole 236.a	used r3 instead of ar3
   A156 2B                  944 	add	a,r3
   A157 FB                  945 	mov	r3,a
   A158 74 A1               946 	mov	a,#0xA1
                            947 ;	Peephole 236.b	used r4 instead of ar4
   A15A 3C                  948 	addc	a,r4
   A15B FC                  949 	mov	r4,a
                            950 ;	../../Platform/nano/rf.c:213: TXCTRLH = (power >> 8);
                            951 ;	genRightShift
                            952 ;	genRightShiftLiteral
                            953 ;	genrshTwo
   A15C 8C 05               954 	mov	ar5,r4
   A15E 7E 00               955 	mov	r6,#0x00
                            956 ;	genAssign
   A160 90 DF 0A            957 	mov	dptr,#_TXCTRLH
   A163 ED                  958 	mov	a,r5
   A164 F0                  959 	movx	@dptr,a
   A165 A3                  960 	inc	dptr
   A166 EE                  961 	mov	a,r6
   A167 F0                  962 	movx	@dptr,a
                            963 ;	../../Platform/nano/rf.c:214: TXCTRLL = (uint8_t)power;	
                            964 ;	genCast
                            965 ;	genCast
   A168 90 DF 0B            966 	mov	dptr,#_TXCTRLL
   A16B EB                  967 	mov	a,r3
   A16C F0                  968 	movx	@dptr,a
   A16D A3                  969 	inc	dptr
                            970 ;	Peephole 181	changed mov to clr
   A16E E4                  971 	clr	a
   A16F F0                  972 	movx	@dptr,a
                            973 ;	../../Platform/nano/rf.c:216: rf_tx_power = (int8_t) new_power;
                            974 ;	genAssign
   A170 90 F0 33            975 	mov	dptr,#_rf_tx_power
   A173 EA                  976 	mov	a,r2
   A174 F0                  977 	movx	@dptr,a
                            978 ;	../../Platform/nano/rf.c:217: return rf_tx_power;
                            979 ;	genRet
   A175 8A 82               980 	mov	dpl,r2
                            981 ;	Peephole 300	removed redundant label 00103$
   A177 22                  982 	ret
                            983 ;------------------------------------------------------------
                            984 ;Allocation info for local variables in function 'rf_rx_enable'
                            985 ;------------------------------------------------------------
                            986 ;------------------------------------------------------------
                            987 ;	../../Platform/nano/rf.c:227: portCHAR rf_rx_enable(void)
                            988 ;	-----------------------------------------
                            989 ;	 function rf_rx_enable
                            990 ;	-----------------------------------------
   A178                     991 _rf_rx_enable:
                            992 ;	../../Platform/nano/rf.c:229: if (rx_flags == 0)
                            993 ;	genAssign
   A178 90 F0 34            994 	mov	dptr,#_rx_flags
   A17B E0                  995 	movx	a,@dptr
                            996 ;	genIfx
   A17C FA                  997 	mov	r2,a
                            998 ;	Peephole 105	removed redundant mov
                            999 ;	genIfxJump
                           1000 ;	Peephole 108.b	removed ljmp by inverse jump logic
   A17D 70 4B              1001 	jnz	00108$
                           1002 ;	Peephole 300	removed redundant label 00116$
                           1003 ;	../../Platform/nano/rf.c:231: RFIF &= ~(IRQ_SFD);
                           1004 ;	genAnd
   A17F 53 E9 EF           1005 	anl	_RFIF,#0xEF
                           1006 ;	../../Platform/nano/rf.c:233: IOCFG0 = 0x04;   // Set the FIFOP threshold
                           1007 ;	genAssign
   A182 90 DF 4F           1008 	mov	dptr,#_IOCFG0
   A185 74 04              1009 	mov	a,#0x04
   A187 F0                 1010 	movx	@dptr,a
   A188 E4                 1011 	clr	a
   A189 A3                 1012 	inc	dptr
   A18A F0                 1013 	movx	@dptr,a
                           1014 ;	../../Platform/nano/rf.c:234: tx_flags = 0;
                           1015 ;	genAssign
   A18B 90 F0 35           1016 	mov	dptr,#_tx_flags
                           1017 ;	Peephole 181	changed mov to clr
   A18E E4                 1018 	clr	a
   A18F F0                 1019 	movx	@dptr,a
                           1020 ;	../../Platform/nano/rf.c:235: rx_flags = RX_ACTIVE;
                           1021 ;	genAssign
   A190 90 F0 34           1022 	mov	dptr,#_rx_flags
   A193 74 80              1023 	mov	a,#0x80
   A195 F0                 1024 	movx	@dptr,a
                           1025 ;	../../Platform/nano/rf.c:236: S1CON &= ~(RFIF_0 | RFIF_1);
                           1026 ;	genAnd
   A196 53 9B FC           1027 	anl	_S1CON,#0xFC
                           1028 ;	../../Platform/nano/rf.c:237: RFPWR &= ~RREG_RADIO_PD;	/*make sure it's powered*/
                           1029 ;	genAssign
   A199 90 DF 17           1030 	mov	dptr,#_RFPWR
   A19C E0                 1031 	movx	a,@dptr
   A19D FA                 1032 	mov	r2,a
   A19E A3                 1033 	inc	dptr
   A19F E0                 1034 	movx	a,@dptr
   A1A0 FB                 1035 	mov	r3,a
                           1036 ;	genAnd
   A1A1 90 DF 17           1037 	mov	dptr,#_RFPWR
   A1A4 74 F7              1038 	mov	a,#0xF7
   A1A6 5A                 1039 	anl	a,r2
   A1A7 F0                 1040 	movx	@dptr,a
   A1A8 A3                 1041 	inc	dptr
   A1A9 EB                 1042 	mov	a,r3
   A1AA F0                 1043 	movx	@dptr,a
                           1044 ;	../../Platform/nano/rf.c:238: while((RFIF & IRQ_RREG_ON) == 0);	/*wait for power up*/
   A1AB                    1045 00101$:
                           1046 ;	genAnd
   A1AB E5 E9              1047 	mov	a,_RFIF
                           1048 ;	genIfxJump
                           1049 ;	Peephole 108.d	removed ljmp by inverse jump logic
   A1AD 30 E7 FB           1050 	jnb	acc.7,00101$
                           1051 ;	Peephole 300	removed redundant label 00117$
                           1052 ;	../../Platform/nano/rf.c:239: SLEEP &= ~OSC_PD; /*Osc on*/
                           1053 ;	genAnd
   A1B0 53 BE FB           1054 	anl	_SLEEP,#0xFB
                           1055 ;	../../Platform/nano/rf.c:240: while((SLEEP & XOSC_STB) == 0);	/*wait for power up*/
   A1B3                    1056 00104$:
                           1057 ;	genAnd
   A1B3 E5 BE              1058 	mov	a,_SLEEP
                           1059 ;	genIfxJump
                           1060 ;	Peephole 108.d	removed ljmp by inverse jump logic
   A1B5 30 E6 FB           1061 	jnb	acc.6,00104$
                           1062 ;	Peephole 300	removed redundant label 00118$
                           1063 ;	../../Platform/nano/rf.c:242: RFIM |= IRQ_SFD;
                           1064 ;	genOr
   A1B8 43 91 10           1065 	orl	_RFIM,#0x10
                           1066 ;	../../Platform/nano/rf.c:243: RFIF &= ~(IRQ_SFD);
                           1067 ;	genAnd
   A1BB 53 E9 EF           1068 	anl	_RFIF,#0xEF
                           1069 ;	../../Platform/nano/rf.c:245: S1CON &= ~(RFIF_0 | RFIF_1);
                           1070 ;	genAnd
   A1BE 53 9B FC           1071 	anl	_S1CON,#0xFC
                           1072 ;	../../Platform/nano/rf.c:246: IEN2 |= RFIE;
                           1073 ;	genOr
   A1C1 43 9A 01           1074 	orl	_IEN2,#0x01
                           1075 ;	../../Platform/nano/rf.c:247: rf_command(ISRXON);
                           1076 ;	genCall
   A1C4 75 82 E2           1077 	mov	dpl,#0xE2
   A1C7 12 A0 6C           1078 	lcall	_rf_command
   A1CA                    1079 00108$:
                           1080 ;	../../Platform/nano/rf.c:250: return pdTRUE;
                           1081 ;	genRet
   A1CA 75 82 01           1082 	mov	dpl,#0x01
                           1083 ;	Peephole 300	removed redundant label 00109$
   A1CD 22                 1084 	ret
                           1085 ;------------------------------------------------------------
                           1086 ;Allocation info for local variables in function 'rf_rx_disable'
                           1087 ;------------------------------------------------------------
                           1088 ;------------------------------------------------------------
                           1089 ;	../../Platform/nano/rf.c:260: portCHAR rf_rx_disable(void)
                           1090 ;	-----------------------------------------
                           1091 ;	 function rf_rx_disable
                           1092 ;	-----------------------------------------
   A1CE                    1093 _rf_rx_disable:
                           1094 ;	../../Platform/nano/rf.c:262: RFIM &= ~IRQ_SFD;
                           1095 ;	genAnd
   A1CE 53 91 EF           1096 	anl	_RFIM,#0xEF
                           1097 ;	../../Platform/nano/rf.c:264: rf_command(ISSTOP);
                           1098 ;	genCall
   A1D1 75 82 FF           1099 	mov	dpl,#0xFF
   A1D4 12 A0 6C           1100 	lcall	_rf_command
                           1101 ;	../../Platform/nano/rf.c:265: rf_command(ISRFOFF);
                           1102 ;	genCall
   A1D7 75 82 E5           1103 	mov	dpl,#0xE5
   A1DA 12 A0 6C           1104 	lcall	_rf_command
                           1105 ;	../../Platform/nano/rf.c:267: RFPWR |= RREG_RADIO_PD;		/*RF powerdown*/
                           1106 ;	genAssign
   A1DD 90 DF 17           1107 	mov	dptr,#_RFPWR
   A1E0 E0                 1108 	movx	a,@dptr
   A1E1 FA                 1109 	mov	r2,a
   A1E2 A3                 1110 	inc	dptr
   A1E3 E0                 1111 	movx	a,@dptr
   A1E4 FB                 1112 	mov	r3,a
                           1113 ;	genOr
   A1E5 90 DF 17           1114 	mov	dptr,#_RFPWR
   A1E8 74 08              1115 	mov	a,#0x08
   A1EA 4A                 1116 	orl	a,r2
   A1EB F0                 1117 	movx	@dptr,a
   A1EC A3                 1118 	inc	dptr
   A1ED EB                 1119 	mov	a,r3
   A1EE F0                 1120 	movx	@dptr,a
                           1121 ;	../../Platform/nano/rf.c:268: IEN2 &= ~RFIE;
                           1122 ;	genAnd
   A1EF 53 9A FE           1123 	anl	_IEN2,#0xFE
                           1124 ;	../../Platform/nano/rf.c:269: rx_flags = 0;
                           1125 ;	genAssign
   A1F2 90 F0 34           1126 	mov	dptr,#_rx_flags
                           1127 ;	Peephole 181	changed mov to clr
   A1F5 E4                 1128 	clr	a
   A1F6 F0                 1129 	movx	@dptr,a
                           1130 ;	../../Platform/nano/rf.c:271: return pdTRUE;
                           1131 ;	genRet
   A1F7 75 82 01           1132 	mov	dpl,#0x01
                           1133 ;	Peephole 300	removed redundant label 00101$
   A1FA 22                 1134 	ret
                           1135 ;------------------------------------------------------------
                           1136 ;Allocation info for local variables in function 'rf_tx_enable'
                           1137 ;------------------------------------------------------------
                           1138 ;------------------------------------------------------------
                           1139 ;	../../Platform/nano/rf.c:281: portCHAR rf_tx_enable(void)
                           1140 ;	-----------------------------------------
                           1141 ;	 function rf_tx_enable
                           1142 ;	-----------------------------------------
   A1FB                    1143 _rf_tx_enable:
                           1144 ;	../../Platform/nano/rf.c:283: RFIM &= ~IRQ_SFD;
                           1145 ;	genAnd
   A1FB 53 91 EF           1146 	anl	_RFIM,#0xEF
                           1147 ;	../../Platform/nano/rf.c:285: IEN2 &= ~RFIE;
                           1148 ;	genAnd
   A1FE 53 9A FE           1149 	anl	_IEN2,#0xFE
                           1150 ;	../../Platform/nano/rf.c:286: tx_flags |= RX_ACTIVE;
                           1151 ;	genAssign
                           1152 ;	genOr
   A201 90 F0 35           1153 	mov	dptr,#_tx_flags
   A204 E0                 1154 	movx	a,@dptr
   A205 FA                 1155 	mov	r2,a
                           1156 ;	Peephole 248.a	optimized or to xdata
   A206 44 80              1157 	orl	a,#0x80
   A208 F0                 1158 	movx	@dptr,a
                           1159 ;	../../Platform/nano/rf.c:287: rx_flags = 0;
                           1160 ;	genAssign
   A209 90 F0 34           1161 	mov	dptr,#_rx_flags
                           1162 ;	Peephole 181	changed mov to clr
   A20C E4                 1163 	clr	a
   A20D F0                 1164 	movx	@dptr,a
                           1165 ;	../../Platform/nano/rf.c:288: return pdTRUE;
                           1166 ;	genRet
   A20E 75 82 01           1167 	mov	dpl,#0x01
                           1168 ;	Peephole 300	removed redundant label 00101$
   A211 22                 1169 	ret
                           1170 ;------------------------------------------------------------
                           1171 ;Allocation info for local variables in function 'rf_init'
                           1172 ;------------------------------------------------------------
                           1173 ;retval                    Allocated to registers 
                           1174 ;------------------------------------------------------------
                           1175 ;	../../Platform/nano/rf.c:299: portCHAR rf_init(void)
                           1176 ;	-----------------------------------------
                           1177 ;	 function rf_init
                           1178 ;	-----------------------------------------
   A212                    1179 _rf_init:
                           1180 ;	../../Platform/nano/rf.c:303: if (rf_initialized) return pdTRUE;
                           1181 ;	genAssign
   A212 90 F0 F4           1182 	mov	dptr,#_rf_initialized
   A215 E0                 1183 	movx	a,@dptr
                           1184 ;	genIfx
   A216 FA                 1185 	mov	r2,a
                           1186 ;	Peephole 105	removed redundant mov
                           1187 ;	genIfxJump
                           1188 ;	Peephole 108.c	removed ljmp by inverse jump logic
   A217 60 04              1189 	jz	00102$
                           1190 ;	Peephole 300	removed redundant label 00129$
                           1191 ;	genRet
   A219 75 82 01           1192 	mov	dpl,#0x01
                           1193 ;	Peephole 251.a	replaced ljmp to ret with ret
   A21C 22                 1194 	ret
   A21D                    1195 00102$:
                           1196 ;	../../Platform/nano/rf.c:305: RFPWR &= ~RREG_RADIO_PD;	/*make sure it's powered*/
                           1197 ;	genAssign
   A21D 90 DF 17           1198 	mov	dptr,#_RFPWR
   A220 E0                 1199 	movx	a,@dptr
   A221 FA                 1200 	mov	r2,a
   A222 A3                 1201 	inc	dptr
   A223 E0                 1202 	movx	a,@dptr
   A224 FB                 1203 	mov	r3,a
                           1204 ;	genAnd
   A225 90 DF 17           1205 	mov	dptr,#_RFPWR
   A228 74 F7              1206 	mov	a,#0xF7
   A22A 5A                 1207 	anl	a,r2
   A22B F0                 1208 	movx	@dptr,a
   A22C A3                 1209 	inc	dptr
   A22D EB                 1210 	mov	a,r3
   A22E F0                 1211 	movx	@dptr,a
                           1212 ;	../../Platform/nano/rf.c:306: while ((RFPWR & ADI_RADIO_PD) == 1);
   A22F                    1213 00103$:
                           1214 ;	genAssign
   A22F 90 DF 17           1215 	mov	dptr,#_RFPWR
   A232 E0                 1216 	movx	a,@dptr
   A233 FA                 1217 	mov	r2,a
   A234 A3                 1218 	inc	dptr
   A235 E0                 1219 	movx	a,@dptr
   A236 FB                 1220 	mov	r3,a
                           1221 ;	genAnd
   A237 53 02 10           1222 	anl	ar2,#0x10
   A23A 7B 00              1223 	mov	r3,#0x00
                           1224 ;	genCmpEq
                           1225 ;	gencjneshort
   A23C BA 01 05           1226 	cjne	r2,#0x01,00130$
   A23F BB 00 02           1227 	cjne	r3,#0x00,00130$
                           1228 ;	Peephole 112.b	changed ljmp to sjmp
   A242 80 EB              1229 	sjmp	00103$
   A244                    1230 00130$:
                           1231 ;	../../Platform/nano/rf.c:307: while((RFIF & IRQ_RREG_ON) == 0);	/*wait for power up*/
   A244                    1232 00106$:
                           1233 ;	genAnd
   A244 E5 E9              1234 	mov	a,_RFIF
                           1235 ;	genIfxJump
                           1236 ;	Peephole 108.d	removed ljmp by inverse jump logic
   A246 30 E7 FB           1237 	jnb	acc.7,00106$
                           1238 ;	Peephole 300	removed redundant label 00131$
                           1239 ;	../../Platform/nano/rf.c:308: SLEEP &= ~OSC_PD; /*Osc on*/
                           1240 ;	genAnd
   A249 53 BE FB           1241 	anl	_SLEEP,#0xFB
                           1242 ;	../../Platform/nano/rf.c:309: while((SLEEP & XOSC_STB) == 0);	/*wait for power up*/
   A24C                    1243 00109$:
                           1244 ;	genAnd
   A24C E5 BE              1245 	mov	a,_SLEEP
                           1246 ;	genIfxJump
                           1247 ;	Peephole 108.d	removed ljmp by inverse jump logic
   A24E 30 E6 FB           1248 	jnb	acc.6,00109$
                           1249 ;	Peephole 300	removed redundant label 00132$
                           1250 ;	../../Platform/nano/rf.c:311: rx_flags = tx_flags = 0;
                           1251 ;	genAssign
   A251 90 F0 35           1252 	mov	dptr,#_tx_flags
                           1253 ;	Peephole 181	changed mov to clr
                           1254 ;	genAssign
                           1255 ;	Peephole 181	changed mov to clr
                           1256 ;	Peephole 219.a	removed redundant clear
   A254 E4                 1257 	clr	a
   A255 F0                 1258 	movx	@dptr,a
   A256 90 F0 34           1259 	mov	dptr,#_rx_flags
   A259 F0                 1260 	movx	@dptr,a
                           1261 ;	../../Platform/nano/rf.c:315: FSMTC1 &= ~ABORTRX_ON_SRXON;	/*don't abort reception, if enable called*/
                           1262 ;	genAssign
   A25A 90 DF 54           1263 	mov	dptr,#_FSMTC1
   A25D E0                 1264 	movx	a,@dptr
   A25E FA                 1265 	mov	r2,a
   A25F A3                 1266 	inc	dptr
   A260 E0                 1267 	movx	a,@dptr
   A261 FB                 1268 	mov	r3,a
                           1269 ;	genAnd
   A262 90 DF 54           1270 	mov	dptr,#_FSMTC1
   A265 74 DF              1271 	mov	a,#0xDF
   A267 5A                 1272 	anl	a,r2
   A268 F0                 1273 	movx	@dptr,a
   A269 A3                 1274 	inc	dptr
   A26A EB                 1275 	mov	a,r3
   A26B F0                 1276 	movx	@dptr,a
                           1277 ;	../../Platform/nano/rf.c:316: MDMCTRL0H &= ~0x18;	 /* Generic client */
                           1278 ;	genAssign
   A26C 90 DF 02           1279 	mov	dptr,#_MDMCTRL0H
   A26F E0                 1280 	movx	a,@dptr
   A270 FA                 1281 	mov	r2,a
   A271 A3                 1282 	inc	dptr
   A272 E0                 1283 	movx	a,@dptr
   A273 FB                 1284 	mov	r3,a
                           1285 ;	genAnd
   A274 90 DF 02           1286 	mov	dptr,#_MDMCTRL0H
   A277 74 E7              1287 	mov	a,#0xE7
   A279 5A                 1288 	anl	a,r2
   A27A F0                 1289 	movx	@dptr,a
   A27B A3                 1290 	inc	dptr
   A27C EB                 1291 	mov	a,r3
   A27D F0                 1292 	movx	@dptr,a
                           1293 ;	../../Platform/nano/rf.c:317: MDMCTRL0L &= ~0x10;	 /* no automatic ACK */
                           1294 ;	genAssign
   A27E 90 DF 03           1295 	mov	dptr,#_MDMCTRL0L
   A281 E0                 1296 	movx	a,@dptr
   A282 FA                 1297 	mov	r2,a
   A283 A3                 1298 	inc	dptr
   A284 E0                 1299 	movx	a,@dptr
   A285 FB                 1300 	mov	r3,a
                           1301 ;	genAnd
   A286 90 DF 03           1302 	mov	dptr,#_MDMCTRL0L
   A289 74 EF              1303 	mov	a,#0xEF
   A28B 5A                 1304 	anl	a,r2
   A28C F0                 1305 	movx	@dptr,a
   A28D A3                 1306 	inc	dptr
   A28E EB                 1307 	mov	a,r3
   A28F F0                 1308 	movx	@dptr,a
                           1309 ;	../../Platform/nano/rf.c:320: MDMCTRL1H = 0x14;	/* CC2420 behaviour*/
                           1310 ;	genAssign
   A290 90 DF 04           1311 	mov	dptr,#_MDMCTRL1H
   A293 74 14              1312 	mov	a,#0x14
   A295 F0                 1313 	movx	@dptr,a
   A296 E4                 1314 	clr	a
   A297 A3                 1315 	inc	dptr
   A298 F0                 1316 	movx	@dptr,a
                           1317 ;	../../Platform/nano/rf.c:321: MDMCTRL1L = 0x00;
                           1318 ;	genAssign
   A299 90 DF 05           1319 	mov	dptr,#_MDMCTRL1L
   A29C E4                 1320 	clr	a
   A29D F0                 1321 	movx	@dptr,a
   A29E A3                 1322 	inc	dptr
   A29F F0                 1323 	movx	@dptr,a
                           1324 ;	../../Platform/nano/rf.c:326: rf_manfid = CHVER;
                           1325 ;	genAssign
   A2A0 90 DF 60           1326 	mov	dptr,#_CHVER
   A2A3 E0                 1327 	movx	a,@dptr
   A2A4 FA                 1328 	mov	r2,a
   A2A5 A3                 1329 	inc	dptr
   A2A6 E0                 1330 	movx	a,@dptr
                           1331 ;	../../Platform/nano/rf.c:327: rf_manfid <<= 8;		
                           1332 ;	genLeftShift
                           1333 ;	genLeftShiftLiteral
                           1334 ;	genlshTwo
                           1335 ;	peephole 177.e	removed redundant move
   A2A7 8A 03              1336 	mov	ar3,r2
   A2A9 7A 00              1337 	mov	r2,#0x00
                           1338 ;	../../Platform/nano/rf.c:328: rf_manfid += CHIPID;
                           1339 ;	genAssign
   A2AB 90 DF 61           1340 	mov	dptr,#_CHIPID
   A2AE E0                 1341 	movx	a,@dptr
   A2AF FC                 1342 	mov	r4,a
   A2B0 A3                 1343 	inc	dptr
   A2B1 E0                 1344 	movx	a,@dptr
   A2B2 FD                 1345 	mov	r5,a
                           1346 ;	genPlus
   A2B3 90 F0 36           1347 	mov	dptr,#_rf_manfid
                           1348 ;	Peephole 236.g	used r4 instead of ar4
   A2B6 EC                 1349 	mov	a,r4
                           1350 ;	Peephole 236.a	used r2 instead of ar2
   A2B7 2A                 1351 	add	a,r2
   A2B8 F0                 1352 	movx	@dptr,a
                           1353 ;	Peephole 236.g	used r5 instead of ar5
   A2B9 ED                 1354 	mov	a,r5
                           1355 ;	Peephole 236.b	used r3 instead of ar3
   A2BA 3B                 1356 	addc	a,r3
   A2BB A3                 1357 	inc	dptr
   A2BC F0                 1358 	movx	@dptr,a
                           1359 ;	../../Platform/nano/rf.c:330: rf_channel_set(RF_DEFAULT_CHANNEL);
                           1360 ;	genCall
   A2BD 75 82 12           1361 	mov	dpl,#0x12
   A2C0 12 A0 C7           1362 	lcall	_rf_channel_set
                           1363 ;	../../Platform/nano/rf.c:333: rf_power_set(RF_DEFAULT_POWER);
                           1364 ;	genCall
   A2C3 75 82 64           1365 	mov	dpl,#0x64
   A2C6 12 A1 23           1366 	lcall	_rf_power_set
                           1367 ;	../../Platform/nano/rf.c:343: rf_command(ISFLUSHTX);
                           1368 ;	genCall
   A2C9 75 82 E7           1369 	mov	dpl,#0xE7
   A2CC 12 A0 6C           1370 	lcall	_rf_command
                           1371 ;	../../Platform/nano/rf.c:344: rf_command(ISFLUSHRX);
                           1372 ;	genCall
   A2CF 75 82 E6           1373 	mov	dpl,#0xE6
   A2D2 12 A0 6C           1374 	lcall	_rf_command
                           1375 ;	../../Platform/nano/rf.c:345: tx_flags = 0;
                           1376 ;	genAssign
   A2D5 90 F0 35           1377 	mov	dptr,#_tx_flags
                           1378 ;	Peephole 181	changed mov to clr
   A2D8 E4                 1379 	clr	a
   A2D9 F0                 1380 	movx	@dptr,a
                           1381 ;	../../Platform/nano/rf.c:347: if( rf_lock == NULL )
                           1382 ;	genAssign
   A2DA 90 F0 F1           1383 	mov	dptr,#_rf_lock
   A2DD E0                 1384 	movx	a,@dptr
   A2DE FA                 1385 	mov	r2,a
   A2DF A3                 1386 	inc	dptr
   A2E0 E0                 1387 	movx	a,@dptr
   A2E1 FB                 1388 	mov	r3,a
   A2E2 A3                 1389 	inc	dptr
   A2E3 E0                 1390 	movx	a,@dptr
   A2E4 FC                 1391 	mov	r4,a
                           1392 ;	genCmpEq
                           1393 ;	gencjneshort
                           1394 ;	Peephole 112.b	changed ljmp to sjmp
                           1395 ;	Peephole 196	optimized misc jump sequence
   A2E5 BA 00 60           1396 	cjne	r2,#0x00,00117$
   A2E8 BB 00 5D           1397 	cjne	r3,#0x00,00117$
   A2EB BC 00 5A           1398 	cjne	r4,#0x00,00117$
                           1399 ;	Peephole 200.b	removed redundant sjmp
                           1400 ;	Peephole 300	removed redundant label 00133$
                           1401 ;	Peephole 300	removed redundant label 00134$
                           1402 ;	../../Platform/nano/rf.c:349: vSemaphoreCreateBinary( rf_lock );
                           1403 ;	genIpush
                           1404 ;	Peephole 181	changed mov to clr
   A2EE E4                 1405 	clr	a
   A2EF C0 E0              1406 	push	acc
                           1407 ;	genCall
   A2F1 75 82 01           1408 	mov	dpl,#0x01
   A2F4 12 1B 2D           1409 	lcall	_xQueueCreate
   A2F7 AA 82              1410 	mov	r2,dpl
   A2F9 AB 83              1411 	mov	r3,dph
   A2FB AC F0              1412 	mov	r4,b
   A2FD 15 81              1413 	dec	sp
                           1414 ;	genAssign
   A2FF 90 F0 F1           1415 	mov	dptr,#_rf_lock
   A302 EA                 1416 	mov	a,r2
   A303 F0                 1417 	movx	@dptr,a
   A304 A3                 1418 	inc	dptr
   A305 EB                 1419 	mov	a,r3
   A306 F0                 1420 	movx	@dptr,a
   A307 A3                 1421 	inc	dptr
   A308 EC                 1422 	mov	a,r4
   A309 F0                 1423 	movx	@dptr,a
                           1424 ;	genCmpEq
                           1425 ;	gencjneshort
   A30A BA 00 08           1426 	cjne	r2,#0x00,00135$
   A30D BB 00 05           1427 	cjne	r3,#0x00,00135$
   A310 BC 00 02           1428 	cjne	r4,#0x00,00135$
                           1429 ;	Peephole 112.b	changed ljmp to sjmp
   A313 80 1B              1430 	sjmp	00113$
   A315                    1431 00135$:
                           1432 ;	genIpush
                           1433 ;	Peephole 181	changed mov to clr
   A315 E4                 1434 	clr	a
   A316 C0 E0              1435 	push	acc
   A318 C0 E0              1436 	push	acc
                           1437 ;	genIpush
                           1438 ;	Peephole 181	changed mov to clr
   A31A E4                 1439 	clr	a
   A31B C0 E0              1440 	push	acc
   A31D C0 E0              1441 	push	acc
   A31F C0 E0              1442 	push	acc
                           1443 ;	genCall
   A321 8A 82              1444 	mov	dpl,r2
   A323 8B 83              1445 	mov	dph,r3
   A325 8C F0              1446 	mov	b,r4
   A327 12 1D 8E           1447 	lcall	_xQueueSend
   A32A E5 81              1448 	mov	a,sp
   A32C 24 FB              1449 	add	a,#0xfb
   A32E F5 81              1450 	mov	sp,a
   A330                    1451 00113$:
                           1452 ;	../../Platform/nano/rf.c:351: if( rf_lock == NULL ) return pdFALSE;
                           1453 ;	genAssign
   A330 90 F0 F1           1454 	mov	dptr,#_rf_lock
   A333 E0                 1455 	movx	a,@dptr
   A334 FA                 1456 	mov	r2,a
   A335 A3                 1457 	inc	dptr
   A336 E0                 1458 	movx	a,@dptr
   A337 FB                 1459 	mov	r3,a
   A338 A3                 1460 	inc	dptr
   A339 E0                 1461 	movx	a,@dptr
   A33A FC                 1462 	mov	r4,a
                           1463 ;	genCmpEq
                           1464 ;	gencjneshort
                           1465 ;	Peephole 112.b	changed ljmp to sjmp
                           1466 ;	Peephole 196	optimized misc jump sequence
   A33B BA 00 0A           1467 	cjne	r2,#0x00,00117$
   A33E BB 00 07           1468 	cjne	r3,#0x00,00117$
   A341 BC 00 04           1469 	cjne	r4,#0x00,00117$
                           1470 ;	Peephole 200.b	removed redundant sjmp
                           1471 ;	Peephole 300	removed redundant label 00136$
                           1472 ;	Peephole 300	removed redundant label 00137$
                           1473 ;	genRet
   A344 75 82 00           1474 	mov	dpl,#0x00
                           1475 ;	Peephole 112.b	changed ljmp to sjmp
                           1476 ;	Peephole 251.b	replaced sjmp to ret with ret
   A347 22                 1477 	ret
   A348                    1478 00117$:
                           1479 ;	../../Platform/nano/rf.c:354: rf_rx_enable();
                           1480 ;	genCall
   A348 12 A1 78           1481 	lcall	_rf_rx_enable
                           1482 ;	../../Platform/nano/rf.c:356: rf_initialized = 1;
                           1483 ;	genAssign
   A34B 90 F0 F4           1484 	mov	dptr,#_rf_initialized
   A34E 74 01              1485 	mov	a,#0x01
   A350 F0                 1486 	movx	@dptr,a
                           1487 ;	../../Platform/nano/rf.c:357: return retval;
                           1488 ;	genRet
   A351 75 82 01           1489 	mov	dpl,#0x01
                           1490 ;	Peephole 300	removed redundant label 00118$
   A354 22                 1491 	ret
                           1492 ;------------------------------------------------------------
                           1493 ;Allocation info for local variables in function 'rf_set_address'
                           1494 ;------------------------------------------------------------
                           1495 ;address                   Allocated to stack - offset 1
                           1496 ;i                         Allocated to stack - offset 4
                           1497 ;ptr                       Allocated to registers 
                           1498 ;sloc0                     Allocated to stack - offset 5
                           1499 ;------------------------------------------------------------
                           1500 ;	../../Platform/nano/rf.c:365: void rf_set_address(sockaddr_t *address)
                           1501 ;	-----------------------------------------
                           1502 ;	 function rf_set_address
                           1503 ;	-----------------------------------------
   A355                    1504 _rf_set_address:
   A355 C0 10              1505 	push	_bp
   A357 85 81 10           1506 	mov	_bp,sp
                           1507 ;     genReceive
   A35A C0 82              1508 	push	dpl
   A35C C0 83              1509 	push	dph
   A35E C0 F0              1510 	push	b
   A360 05 81              1511 	inc	sp
   A362 05 81              1512 	inc	sp
   A364 05 81              1513 	inc	sp
                           1514 ;	../../Platform/nano/rf.c:370: switch(address->addr_type)
                           1515 ;	genPointerGet
                           1516 ;	genGenPointerGet
   A366 A8 10              1517 	mov	r0,_bp
   A368 08                 1518 	inc	r0
   A369 86 82              1519 	mov	dpl,@r0
   A36B 08                 1520 	inc	r0
   A36C 86 83              1521 	mov	dph,@r0
   A36E 08                 1522 	inc	r0
   A36F 86 F0              1523 	mov	b,@r0
   A371 12 E4 9F           1524 	lcall	__gptrget
   A374 FD                 1525 	mov	r5,a
                           1526 ;	genCmpEq
                           1527 ;	gencjneshort
   A375 BD 03 03           1528 	cjne	r5,#0x03,00116$
   A378 02 A4 21           1529 	ljmp	00102$
   A37B                    1530 00116$:
                           1531 ;	genCmpEq
                           1532 ;	gencjneshort
   A37B BD 04 02           1533 	cjne	r5,#0x04,00117$
   A37E 80 03              1534 	sjmp	00118$
   A380                    1535 00117$:
   A380 02 A4 92           1536 	ljmp	00109$
   A383                    1537 00118$:
                           1538 ;	../../Platform/nano/rf.c:373: ptr = &IEEE_ADDR0;
                           1539 ;	../../Platform/nano/rf.c:374: for(i=0; i<8;i++)
                           1540 ;	genPlus
   A383 A8 10              1541 	mov	r0,_bp
   A385 08                 1542 	inc	r0
                           1543 ;     genPlusIncr
   A386 74 01              1544 	mov	a,#0x01
   A388 26                 1545 	add	a,@r0
   A389 FD                 1546 	mov	r5,a
                           1547 ;	Peephole 181	changed mov to clr
   A38A E4                 1548 	clr	a
   A38B 08                 1549 	inc	r0
   A38C 36                 1550 	addc	a,@r0
   A38D FE                 1551 	mov	r6,a
   A38E 08                 1552 	inc	r0
   A38F 86 07              1553 	mov	ar7,@r0
                           1554 ;	genAssign
   A391 E5 10              1555 	mov	a,_bp
   A393 24 05              1556 	add	a,#0x05
   A395 F8                 1557 	mov	r0,a
   A396 76 43              1558 	mov	@r0,#_IEEE_ADDR0
   A398 08                 1559 	inc	r0
   A399 76 DF              1560 	mov	@r0,#(_IEEE_ADDR0 >> 8)
                           1561 ;	genAssign
   A39B E5 10              1562 	mov	a,_bp
   A39D 24 04              1563 	add	a,#0x04
   A39F F8                 1564 	mov	r0,a
   A3A0 76 00              1565 	mov	@r0,#0x00
   A3A2                    1566 00105$:
                           1567 ;	genCmpLt
   A3A2 E5 10              1568 	mov	a,_bp
   A3A4 24 04              1569 	add	a,#0x04
   A3A6 F8                 1570 	mov	r0,a
                           1571 ;	genCmp
   A3A7 B6 08 00           1572 	cjne	@r0,#0x08,00119$
   A3AA                    1573 00119$:
                           1574 ;	genIfxJump
                           1575 ;	Peephole 108.a	removed ljmp by inverse jump logic
   A3AA 50 32              1576 	jnc	00108$
                           1577 ;	Peephole 300	removed redundant label 00120$
                           1578 ;	../../Platform/nano/rf.c:376: *ptr++ = address->address[i];
                           1579 ;	genPlus
   A3AC E5 10              1580 	mov	a,_bp
   A3AE 24 04              1581 	add	a,#0x04
   A3B0 F8                 1582 	mov	r0,a
   A3B1 E6                 1583 	mov	a,@r0
                           1584 ;	Peephole 236.a	used r5 instead of ar5
   A3B2 2D                 1585 	add	a,r5
   A3B3 FB                 1586 	mov	r3,a
                           1587 ;	Peephole 181	changed mov to clr
   A3B4 E4                 1588 	clr	a
                           1589 ;	Peephole 236.b	used r6 instead of ar6
   A3B5 3E                 1590 	addc	a,r6
   A3B6 FC                 1591 	mov	r4,a
   A3B7 8F 02              1592 	mov	ar2,r7
                           1593 ;	genPointerGet
                           1594 ;	genGenPointerGet
   A3B9 8B 82              1595 	mov	dpl,r3
   A3BB 8C 83              1596 	mov	dph,r4
   A3BD 8A F0              1597 	mov	b,r2
   A3BF 12 E4 9F           1598 	lcall	__gptrget
   A3C2 FB                 1599 	mov	r3,a
                           1600 ;	genPointerSet
                           1601 ;     genFarPointerSet
   A3C3 E5 10              1602 	mov	a,_bp
   A3C5 24 05              1603 	add	a,#0x05
   A3C7 F8                 1604 	mov	r0,a
   A3C8 86 82              1605 	mov	dpl,@r0
   A3CA 08                 1606 	inc	r0
   A3CB 86 83              1607 	mov	dph,@r0
   A3CD EB                 1608 	mov	a,r3
   A3CE F0                 1609 	movx	@dptr,a
   A3CF A3                 1610 	inc	dptr
   A3D0 18                 1611 	dec	r0
   A3D1 A6 82              1612 	mov	@r0,dpl
   A3D3 08                 1613 	inc	r0
   A3D4 A6 83              1614 	mov	@r0,dph
                           1615 ;	../../Platform/nano/rf.c:374: for(i=0; i<8;i++)
                           1616 ;	genPlus
   A3D6 E5 10              1617 	mov	a,_bp
   A3D8 24 04              1618 	add	a,#0x04
   A3DA F8                 1619 	mov	r0,a
                           1620 ;     genPlusIncr
   A3DB 06                 1621 	inc	@r0
                           1622 ;	Peephole 112.b	changed ljmp to sjmp
   A3DC 80 C4              1623 	sjmp	00105$
   A3DE                    1624 00108$:
                           1625 ;	../../Platform/nano/rf.c:378: PANIDH = address->address[8];
                           1626 ;	genPlus
   A3DE A8 10              1627 	mov	r0,_bp
   A3E0 08                 1628 	inc	r0
                           1629 ;     genPlusIncr
   A3E1 74 01              1630 	mov	a,#0x01
   A3E3 26                 1631 	add	a,@r0
   A3E4 FA                 1632 	mov	r2,a
                           1633 ;	Peephole 181	changed mov to clr
   A3E5 E4                 1634 	clr	a
   A3E6 08                 1635 	inc	r0
   A3E7 36                 1636 	addc	a,@r0
   A3E8 FB                 1637 	mov	r3,a
   A3E9 08                 1638 	inc	r0
   A3EA 86 04              1639 	mov	ar4,@r0
                           1640 ;	genPlus
                           1641 ;     genPlusIncr
   A3EC 74 08              1642 	mov	a,#0x08
                           1643 ;	Peephole 236.a	used r2 instead of ar2
   A3EE 2A                 1644 	add	a,r2
   A3EF FD                 1645 	mov	r5,a
                           1646 ;	Peephole 181	changed mov to clr
   A3F0 E4                 1647 	clr	a
                           1648 ;	Peephole 236.b	used r3 instead of ar3
   A3F1 3B                 1649 	addc	a,r3
   A3F2 FE                 1650 	mov	r6,a
   A3F3 8C 07              1651 	mov	ar7,r4
                           1652 ;	genPointerGet
                           1653 ;	genGenPointerGet
   A3F5 8D 82              1654 	mov	dpl,r5
   A3F7 8E 83              1655 	mov	dph,r6
   A3F9 8F F0              1656 	mov	b,r7
   A3FB 12 E4 9F           1657 	lcall	__gptrget
                           1658 ;	genCast
   A3FE FD                 1659 	mov	r5,a
   A3FF 90 DF 4B           1660 	mov	dptr,#_PANIDH
                           1661 ;	Peephole 100	removed redundant mov
   A402 F0                 1662 	movx	@dptr,a
   A403 A3                 1663 	inc	dptr
                           1664 ;	Peephole 181	changed mov to clr
   A404 E4                 1665 	clr	a
   A405 F0                 1666 	movx	@dptr,a
                           1667 ;	../../Platform/nano/rf.c:379: PANIDL = address->address[9];
                           1668 ;	genPlus
                           1669 ;     genPlusIncr
   A406 74 09              1670 	mov	a,#0x09
                           1671 ;	Peephole 236.a	used r2 instead of ar2
   A408 2A                 1672 	add	a,r2
   A409 FA                 1673 	mov	r2,a
                           1674 ;	Peephole 181	changed mov to clr
   A40A E4                 1675 	clr	a
                           1676 ;	Peephole 236.b	used r3 instead of ar3
   A40B 3B                 1677 	addc	a,r3
   A40C FB                 1678 	mov	r3,a
                           1679 ;	genPointerGet
                           1680 ;	genGenPointerGet
   A40D 8A 82              1681 	mov	dpl,r2
   A40F 8B 83              1682 	mov	dph,r3
   A411 8C F0              1683 	mov	b,r4
   A413 12 E4 9F           1684 	lcall	__gptrget
                           1685 ;	genCast
   A416 FA                 1686 	mov	r2,a
   A417 90 DF 4C           1687 	mov	dptr,#_PANIDL
                           1688 ;	Peephole 100	removed redundant mov
   A41A F0                 1689 	movx	@dptr,a
   A41B A3                 1690 	inc	dptr
                           1691 ;	Peephole 181	changed mov to clr
   A41C E4                 1692 	clr	a
   A41D F0                 1693 	movx	@dptr,a
                           1694 ;	../../Platform/nano/rf.c:380: break;
   A41E 02 A4 92           1695 	ljmp	00109$
                           1696 ;	../../Platform/nano/rf.c:382: case ADDR_802_15_4_PAN_SHORT:
   A421                    1697 00102$:
                           1698 ;	../../Platform/nano/rf.c:383: SHORTADDRH = address->address[0];
                           1699 ;	genPlus
   A421 A8 10              1700 	mov	r0,_bp
   A423 08                 1701 	inc	r0
                           1702 ;     genPlusIncr
   A424 74 01              1703 	mov	a,#0x01
   A426 26                 1704 	add	a,@r0
   A427 FA                 1705 	mov	r2,a
                           1706 ;	Peephole 181	changed mov to clr
   A428 E4                 1707 	clr	a
   A429 08                 1708 	inc	r0
   A42A 36                 1709 	addc	a,@r0
   A42B FB                 1710 	mov	r3,a
   A42C 08                 1711 	inc	r0
   A42D 86 04              1712 	mov	ar4,@r0
                           1713 ;	genCast
   A42F 8A 05              1714 	mov	ar5,r2
   A431 8B 06              1715 	mov	ar6,r3
   A433 8C 07              1716 	mov	ar7,r4
                           1717 ;	genPointerGet
                           1718 ;	genGenPointerGet
   A435 8D 82              1719 	mov	dpl,r5
   A437 8E 83              1720 	mov	dph,r6
   A439 8F F0              1721 	mov	b,r7
   A43B 12 E4 9F           1722 	lcall	__gptrget
                           1723 ;	genCast
   A43E FD                 1724 	mov	r5,a
   A43F 90 DF 4D           1725 	mov	dptr,#_SHORTADDRH
                           1726 ;	Peephole 100	removed redundant mov
   A442 F0                 1727 	movx	@dptr,a
   A443 A3                 1728 	inc	dptr
                           1729 ;	Peephole 181	changed mov to clr
   A444 E4                 1730 	clr	a
   A445 F0                 1731 	movx	@dptr,a
                           1732 ;	../../Platform/nano/rf.c:384: SHORTADDRL = address->address[1];
                           1733 ;	genPlus
                           1734 ;     genPlusIncr
   A446 74 01              1735 	mov	a,#0x01
                           1736 ;	Peephole 236.a	used r2 instead of ar2
   A448 2A                 1737 	add	a,r2
   A449 FD                 1738 	mov	r5,a
                           1739 ;	Peephole 181	changed mov to clr
   A44A E4                 1740 	clr	a
                           1741 ;	Peephole 236.b	used r3 instead of ar3
   A44B 3B                 1742 	addc	a,r3
   A44C FE                 1743 	mov	r6,a
   A44D 8C 07              1744 	mov	ar7,r4
                           1745 ;	genPointerGet
                           1746 ;	genGenPointerGet
   A44F 8D 82              1747 	mov	dpl,r5
   A451 8E 83              1748 	mov	dph,r6
   A453 8F F0              1749 	mov	b,r7
   A455 12 E4 9F           1750 	lcall	__gptrget
                           1751 ;	genCast
   A458 FD                 1752 	mov	r5,a
   A459 90 DF 4E           1753 	mov	dptr,#_SHORTADDRL
                           1754 ;	Peephole 100	removed redundant mov
   A45C F0                 1755 	movx	@dptr,a
   A45D A3                 1756 	inc	dptr
                           1757 ;	Peephole 181	changed mov to clr
   A45E E4                 1758 	clr	a
   A45F F0                 1759 	movx	@dptr,a
                           1760 ;	../../Platform/nano/rf.c:385: PANIDH = address->address[2];
                           1761 ;	genPlus
                           1762 ;     genPlusIncr
   A460 74 02              1763 	mov	a,#0x02
                           1764 ;	Peephole 236.a	used r2 instead of ar2
   A462 2A                 1765 	add	a,r2
   A463 FD                 1766 	mov	r5,a
                           1767 ;	Peephole 181	changed mov to clr
   A464 E4                 1768 	clr	a
                           1769 ;	Peephole 236.b	used r3 instead of ar3
   A465 3B                 1770 	addc	a,r3
   A466 FE                 1771 	mov	r6,a
   A467 8C 07              1772 	mov	ar7,r4
                           1773 ;	genPointerGet
                           1774 ;	genGenPointerGet
   A469 8D 82              1775 	mov	dpl,r5
   A46B 8E 83              1776 	mov	dph,r6
   A46D 8F F0              1777 	mov	b,r7
   A46F 12 E4 9F           1778 	lcall	__gptrget
                           1779 ;	genCast
   A472 FD                 1780 	mov	r5,a
   A473 90 DF 4B           1781 	mov	dptr,#_PANIDH
                           1782 ;	Peephole 100	removed redundant mov
   A476 F0                 1783 	movx	@dptr,a
   A477 A3                 1784 	inc	dptr
                           1785 ;	Peephole 181	changed mov to clr
   A478 E4                 1786 	clr	a
   A479 F0                 1787 	movx	@dptr,a
                           1788 ;	../../Platform/nano/rf.c:386: PANIDL = address->address[3];
                           1789 ;	genPlus
                           1790 ;     genPlusIncr
   A47A 74 03              1791 	mov	a,#0x03
                           1792 ;	Peephole 236.a	used r2 instead of ar2
   A47C 2A                 1793 	add	a,r2
   A47D FA                 1794 	mov	r2,a
                           1795 ;	Peephole 181	changed mov to clr
   A47E E4                 1796 	clr	a
                           1797 ;	Peephole 236.b	used r3 instead of ar3
   A47F 3B                 1798 	addc	a,r3
   A480 FB                 1799 	mov	r3,a
                           1800 ;	genPointerGet
                           1801 ;	genGenPointerGet
   A481 8A 82              1802 	mov	dpl,r2
   A483 8B 83              1803 	mov	dph,r3
   A485 8C F0              1804 	mov	b,r4
   A487 12 E4 9F           1805 	lcall	__gptrget
                           1806 ;	genCast
   A48A FA                 1807 	mov	r2,a
   A48B 90 DF 4C           1808 	mov	dptr,#_PANIDL
                           1809 ;	Peephole 100	removed redundant mov
   A48E F0                 1810 	movx	@dptr,a
   A48F A3                 1811 	inc	dptr
                           1812 ;	Peephole 181	changed mov to clr
   A490 E4                 1813 	clr	a
   A491 F0                 1814 	movx	@dptr,a
                           1815 ;	../../Platform/nano/rf.c:391: }			
   A492                    1816 00109$:
   A492 85 10 81           1817 	mov	sp,_bp
   A495 D0 10              1818 	pop	_bp
   A497 22                 1819 	ret
                           1820 ;------------------------------------------------------------
                           1821 ;Allocation info for local variables in function 'rf_address_decoder_mode'
                           1822 ;------------------------------------------------------------
                           1823 ;param                     Allocated to registers r2 
                           1824 ;retval                    Allocated to registers 
                           1825 ;------------------------------------------------------------
                           1826 ;	../../Platform/nano/rf.c:468: portCHAR rf_address_decoder_mode(uint8_t param)
                           1827 ;	-----------------------------------------
                           1828 ;	 function rf_address_decoder_mode
                           1829 ;	-----------------------------------------
   A498                    1830 _rf_address_decoder_mode:
                           1831 ;	genReceive
                           1832 ;	../../Platform/nano/rf.c:473: if(param)
                           1833 ;	genIfx
                           1834 ;	peephole 177.g	optimized mov sequence
   A498 E5 82              1835 	mov	a,dpl
   A49A FA                 1836 	mov	r2,a
                           1837 ;	genIfxJump
                           1838 ;	Peephole 108.c	removed ljmp by inverse jump logic
   A49B 60 26              1839 	jz	00102$
                           1840 ;	Peephole 300	removed redundant label 00107$
                           1841 ;	../../Platform/nano/rf.c:483: MDMCTRL0H |= 0x08;	 /*Address-decode on */
                           1842 ;	genAssign
   A49D 90 DF 02           1843 	mov	dptr,#_MDMCTRL0H
   A4A0 E0                 1844 	movx	a,@dptr
   A4A1 FA                 1845 	mov	r2,a
   A4A2 A3                 1846 	inc	dptr
   A4A3 E0                 1847 	movx	a,@dptr
   A4A4 FB                 1848 	mov	r3,a
                           1849 ;	genOr
   A4A5 90 DF 02           1850 	mov	dptr,#_MDMCTRL0H
   A4A8 74 08              1851 	mov	a,#0x08
   A4AA 4A                 1852 	orl	a,r2
   A4AB F0                 1853 	movx	@dptr,a
   A4AC A3                 1854 	inc	dptr
   A4AD EB                 1855 	mov	a,r3
   A4AE F0                 1856 	movx	@dptr,a
                           1857 ;	../../Platform/nano/rf.c:484: MDMCTRL0L |= 0x10;	 /*automatic ACK */ /* Enable receive beacon if address decoder is enabled */
                           1858 ;	genAssign
   A4AF 90 DF 03           1859 	mov	dptr,#_MDMCTRL0L
   A4B2 E0                 1860 	movx	a,@dptr
   A4B3 FA                 1861 	mov	r2,a
   A4B4 A3                 1862 	inc	dptr
   A4B5 E0                 1863 	movx	a,@dptr
   A4B6 FB                 1864 	mov	r3,a
                           1865 ;	genOr
   A4B7 90 DF 03           1866 	mov	dptr,#_MDMCTRL0L
   A4BA 74 10              1867 	mov	a,#0x10
   A4BC 4A                 1868 	orl	a,r2
   A4BD F0                 1869 	movx	@dptr,a
   A4BE A3                 1870 	inc	dptr
   A4BF EB                 1871 	mov	a,r3
   A4C0 F0                 1872 	movx	@dptr,a
                           1873 ;	Peephole 112.b	changed ljmp to sjmp
   A4C1 80 24              1874 	sjmp	00103$
   A4C3                    1875 00102$:
                           1876 ;	../../Platform/nano/rf.c:490: MDMCTRL0H &= ~0x18;	 /* Generic client */
                           1877 ;	genAssign
   A4C3 90 DF 02           1878 	mov	dptr,#_MDMCTRL0H
   A4C6 E0                 1879 	movx	a,@dptr
   A4C7 FA                 1880 	mov	r2,a
   A4C8 A3                 1881 	inc	dptr
   A4C9 E0                 1882 	movx	a,@dptr
   A4CA FB                 1883 	mov	r3,a
                           1884 ;	genAnd
   A4CB 90 DF 02           1885 	mov	dptr,#_MDMCTRL0H
   A4CE 74 E7              1886 	mov	a,#0xE7
   A4D0 5A                 1887 	anl	a,r2
   A4D1 F0                 1888 	movx	@dptr,a
   A4D2 A3                 1889 	inc	dptr
   A4D3 EB                 1890 	mov	a,r3
   A4D4 F0                 1891 	movx	@dptr,a
                           1892 ;	../../Platform/nano/rf.c:491: MDMCTRL0L &= ~0x10;	 /* no automatic ACK */
                           1893 ;	genAssign
   A4D5 90 DF 03           1894 	mov	dptr,#_MDMCTRL0L
   A4D8 E0                 1895 	movx	a,@dptr
   A4D9 FA                 1896 	mov	r2,a
   A4DA A3                 1897 	inc	dptr
   A4DB E0                 1898 	movx	a,@dptr
   A4DC FB                 1899 	mov	r3,a
                           1900 ;	genAnd
   A4DD 90 DF 03           1901 	mov	dptr,#_MDMCTRL0L
   A4E0 74 EF              1902 	mov	a,#0xEF
   A4E2 5A                 1903 	anl	a,r2
   A4E3 F0                 1904 	movx	@dptr,a
   A4E4 A3                 1905 	inc	dptr
   A4E5 EB                 1906 	mov	a,r3
   A4E6 F0                 1907 	movx	@dptr,a
   A4E7                    1908 00103$:
                           1909 ;	../../Platform/nano/rf.c:494: return retval; 
                           1910 ;	genRet
   A4E7 75 82 01           1911 	mov	dpl,#0x01
                           1912 ;	Peephole 300	removed redundant label 00104$
   A4EA 22                 1913 	ret
                           1914 ;------------------------------------------------------------
                           1915 ;Allocation info for local variables in function 'rf_analyze_rssi'
                           1916 ;------------------------------------------------------------
                           1917 ;counter                   Allocated to registers 
                           1918 ;i                         Allocated to registers r4 
                           1919 ;sum                       Allocated to registers r2 r3 
                           1920 ;retval                    Allocated to registers r2 
                           1921 ;temp                      Allocated to registers r5 
                           1922 ;------------------------------------------------------------
                           1923 ;	../../Platform/nano/rf.c:505: int8_t rf_analyze_rssi(void)
                           1924 ;	-----------------------------------------
                           1925 ;	 function rf_analyze_rssi
                           1926 ;	-----------------------------------------
   A4EB                    1927 _rf_analyze_rssi:
                           1928 ;	../../Platform/nano/rf.c:508: int16_t sum=0;
                           1929 ;	genAssign
   A4EB 7A 00              1930 	mov	r2,#0x00
   A4ED 7B 00              1931 	mov	r3,#0x00
                           1932 ;	../../Platform/nano/rf.c:511: rf_command(ISRXON);
                           1933 ;	genCall
   A4EF 75 82 E2           1934 	mov	dpl,#0xE2
   A4F2 C0 02              1935 	push	ar2
   A4F4 C0 03              1936 	push	ar3
   A4F6 12 A0 6C           1937 	lcall	_rf_command
   A4F9 D0 03              1938 	pop	ar3
   A4FB D0 02              1939 	pop	ar2
                           1940 ;	../../Platform/nano/rf.c:512: pause_us(16);				/* waiting one symbol period */
                           1941 ;	genCall
                           1942 ;	Peephole 182.b	used 16 bit load of dptr
   A4FD 90 00 10           1943 	mov	dptr,#0x0010
   A500 C0 02              1944 	push	ar2
   A502 C0 03              1945 	push	ar3
   A504 12 37 B7           1946 	lcall	_pause_us
   A507 D0 03              1947 	pop	ar3
   A509 D0 02              1948 	pop	ar2
                           1949 ;	../../Platform/nano/rf.c:514: for(i=0; i<8; i++)
                           1950 ;	genAssign
   A50B 7C 08              1951 	mov	r4,#0x08
   A50D                    1952 00103$:
                           1953 ;	../../Platform/nano/rf.c:516: temp = (int8_t)RSSIL;
                           1954 ;	genAssign
   A50D 90 DF 07           1955 	mov	dptr,#_RSSIL
   A510 E0                 1956 	movx	a,@dptr
   A511 FD                 1957 	mov	r5,a
   A512 A3                 1958 	inc	dptr
   A513 E0                 1959 	movx	a,@dptr
   A514 FE                 1960 	mov	r6,a
                           1961 ;	genCast
                           1962 ;	../../Platform/nano/rf.c:517: temp -= 45;
                           1963 ;	genMinus
   A515 ED                 1964 	mov	a,r5
   A516 24 D3              1965 	add	a,#0xd3
                           1966 ;	../../Platform/nano/rf.c:518: sum += (int16_t)temp;
                           1967 ;	genCast
   A518 FD                 1968 	mov	r5,a
                           1969 ;	Peephole 105	removed redundant mov
   A519 33                 1970 	rlc	a
   A51A 95 E0              1971 	subb	a,acc
   A51C FE                 1972 	mov	r6,a
                           1973 ;	genPlus
                           1974 ;	Peephole 236.g	used r5 instead of ar5
   A51D ED                 1975 	mov	a,r5
                           1976 ;	Peephole 236.a	used r2 instead of ar2
   A51E 2A                 1977 	add	a,r2
   A51F FA                 1978 	mov	r2,a
                           1979 ;	Peephole 236.g	used r6 instead of ar6
   A520 EE                 1980 	mov	a,r6
                           1981 ;	Peephole 236.b	used r3 instead of ar3
   A521 3B                 1982 	addc	a,r3
   A522 FB                 1983 	mov	r3,a
                           1984 ;	../../Platform/nano/rf.c:519: pause_us(16);				/* waiting one symbol period */
                           1985 ;	genCall
                           1986 ;	Peephole 182.b	used 16 bit load of dptr
   A523 90 00 10           1987 	mov	dptr,#0x0010
   A526 C0 02              1988 	push	ar2
   A528 C0 03              1989 	push	ar3
   A52A C0 04              1990 	push	ar4
   A52C 12 37 B7           1991 	lcall	_pause_us
   A52F D0 04              1992 	pop	ar4
   A531 D0 03              1993 	pop	ar3
   A533 D0 02              1994 	pop	ar2
                           1995 ;	genDjnz
                           1996 ;	Peephole 112.b	changed ljmp to sjmp
                           1997 ;	Peephole 205	optimized misc jump sequence
   A535 DC D6              1998 	djnz	r4,00103$
                           1999 ;	Peephole 300	removed redundant label 00109$
                           2000 ;	Peephole 300	removed redundant label 00110$
                           2001 ;	../../Platform/nano/rf.c:514: for(i=0; i<8; i++)
                           2002 ;	../../Platform/nano/rf.c:521: sum /=8;
                           2003 ;	genIpush
   A537 74 08              2004 	mov	a,#0x08
   A539 C0 E0              2005 	push	acc
                           2006 ;	Peephole 181	changed mov to clr
   A53B E4                 2007 	clr	a
   A53C C0 E0              2008 	push	acc
                           2009 ;	genCall
   A53E 8A 82              2010 	mov	dpl,r2
   A540 8B 83              2011 	mov	dph,r3
   A542 12 E5 BE           2012 	lcall	__divsint
   A545 AC 82              2013 	mov	r4,dpl
   A547 AD 83              2014 	mov	r5,dph
   A549 15 81              2015 	dec	sp
   A54B 15 81              2016 	dec	sp
                           2017 ;	genAssign
   A54D 8C 02              2018 	mov	ar2,r4
   A54F 8D 03              2019 	mov	ar3,r5
                           2020 ;	../../Platform/nano/rf.c:522: retval = (int8_t)sum;
                           2021 ;	genCast
                           2022 ;	../../Platform/nano/rf.c:524: return retval; 
                           2023 ;	genRet
   A551 8A 82              2024 	mov	dpl,r2
                           2025 ;	Peephole 300	removed redundant label 00104$
   A553 22                 2026 	ret
                           2027 ;------------------------------------------------------------
                           2028 ;Allocation info for local variables in function 'rf_cca_check'
                           2029 ;------------------------------------------------------------
                           2030 ;slotted                   Allocated to stack - offset -3
                           2031 ;backoff_count             Allocated to registers 
                           2032 ;counter                   Allocated to registers r4 
                           2033 ;cca                       Allocated to registers r3 
                           2034 ;retval                    Allocated to registers r2 
                           2035 ;------------------------------------------------------------
                           2036 ;	../../Platform/nano/rf.c:533: portCHAR rf_cca_check(uint8_t backoff_count, uint8_t slotted)
                           2037 ;	-----------------------------------------
                           2038 ;	 function rf_cca_check
                           2039 ;	-----------------------------------------
   A554                    2040 _rf_cca_check:
   A554 C0 10              2041 	push	_bp
   A556 85 81 10           2042 	mov	_bp,sp
                           2043 ;	../../Platform/nano/rf.c:536: portCHAR retval = pdTRUE;
                           2044 ;	genAssign
   A559 7A 01              2045 	mov	r2,#0x01
                           2046 ;	../../Platform/nano/rf.c:538: rf_command(ISRXON);
                           2047 ;	genCall
   A55B 75 82 E2           2048 	mov	dpl,#0xE2
   A55E C0 02              2049 	push	ar2
   A560 12 A0 6C           2050 	lcall	_rf_command
   A563 D0 02              2051 	pop	ar2
                           2052 ;	../../Platform/nano/rf.c:540: pause_us(16);
                           2053 ;	genCall
                           2054 ;	Peephole 182.b	used 16 bit load of dptr
   A565 90 00 10           2055 	mov	dptr,#0x0010
   A568 C0 02              2056 	push	ar2
   A56A 12 37 B7           2057 	lcall	_pause_us
   A56D D0 02              2058 	pop	ar2
                           2059 ;	../../Platform/nano/rf.c:541: pause_us(16);
                           2060 ;	genCall
                           2061 ;	Peephole 182.b	used 16 bit load of dptr
   A56F 90 00 10           2062 	mov	dptr,#0x0010
   A572 C0 02              2063 	push	ar2
   A574 12 37 B7           2064 	lcall	_pause_us
   A577 D0 02              2065 	pop	ar2
                           2066 ;	../../Platform/nano/rf.c:542: pause_us(16);
                           2067 ;	genCall
                           2068 ;	Peephole 182.b	used 16 bit load of dptr
   A579 90 00 10           2069 	mov	dptr,#0x0010
   A57C C0 02              2070 	push	ar2
   A57E 12 37 B7           2071 	lcall	_pause_us
   A581 D0 02              2072 	pop	ar2
                           2073 ;	../../Platform/nano/rf.c:543: pause_us(16);
                           2074 ;	genCall
                           2075 ;	Peephole 182.b	used 16 bit load of dptr
   A583 90 00 10           2076 	mov	dptr,#0x0010
   A586 C0 02              2077 	push	ar2
   A588 12 37 B7           2078 	lcall	_pause_us
   A58B D0 02              2079 	pop	ar2
                           2080 ;	../../Platform/nano/rf.c:544: switch (slotted)
                           2081 ;	genCmpEq
   A58D A8 10              2082 	mov	r0,_bp
   A58F 18                 2083 	dec	r0
   A590 18                 2084 	dec	r0
   A591 18                 2085 	dec	r0
                           2086 ;	gencjneshort
   A592 B6 00 02           2087 	cjne	@r0,#0x00,00127$
                           2088 ;	Peephole 112.b	changed ljmp to sjmp
   A595 80 4D              2089 	sjmp	00112$
   A597                    2090 00127$:
                           2091 ;	genCmpEq
   A597 A8 10              2092 	mov	r0,_bp
   A599 18                 2093 	dec	r0
   A59A 18                 2094 	dec	r0
   A59B 18                 2095 	dec	r0
                           2096 ;	gencjneshort
                           2097 ;	Peephole 112.b	changed ljmp to sjmp
                           2098 ;	Peephole 198.b	optimized misc jump sequence
   A59C B6 01 53           2099 	cjne	@r0,#0x01,00115$
                           2100 ;	Peephole 200.b	removed redundant sjmp
                           2101 ;	Peephole 300	removed redundant label 00128$
                           2102 ;	Peephole 300	removed redundant label 00129$
                           2103 ;	../../Platform/nano/rf.c:548: if(RFSTATUS & CCA)
                           2104 ;	genAssign
   A59F 90 DF 62           2105 	mov	dptr,#_RFSTATUS
   A5A2 E0                 2106 	movx	a,@dptr
   A5A3 FB                 2107 	mov	r3,a
   A5A4 A3                 2108 	inc	dptr
   A5A5 E0                 2109 	movx	a,@dptr
   A5A6 FC                 2110 	mov	r4,a
                           2111 ;	genAnd
   A5A7 EB                 2112 	mov	a,r3
                           2113 ;	genIfxJump
                           2114 ;	Peephole 108.d	removed ljmp by inverse jump logic
   A5A8 30 E0 35           2115 	jnb	acc.0,00110$
                           2116 ;	Peephole 300	removed redundant label 00130$
                           2117 ;	../../Platform/nano/rf.c:551: cca=1;
                           2118 ;	genAssign
   A5AB 7B 01              2119 	mov	r3,#0x01
                           2120 ;	../../Platform/nano/rf.c:552: while(cca!=0) 
                           2121 ;	genAssign
   A5AD 7C 00              2122 	mov	r4,#0x00
   A5AF                    2123 00106$:
                           2124 ;	genCmpEq
                           2125 ;	gencjneshort
   A5AF BB 00 02           2126 	cjne	r3,#0x00,00131$
                           2127 ;	Peephole 112.b	changed ljmp to sjmp
   A5B2 80 3E              2128 	sjmp	00115$
   A5B4                    2129 00131$:
                           2130 ;	../../Platform/nano/rf.c:554: if(counter > 1)
                           2131 ;	genCmpGt
                           2132 ;	genCmp
                           2133 ;	genIfxJump
                           2134 ;	Peephole 108.a	removed ljmp by inverse jump logic
                           2135 ;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
   A5B4 EC                 2136 	mov	a,r4
   A5B5 24 FE              2137 	add	a,#0xff - 0x01
   A5B7 50 02              2138 	jnc	00103$
                           2139 ;	Peephole 300	removed redundant label 00132$
                           2140 ;	../../Platform/nano/rf.c:555: cca=0;
                           2141 ;	genAssign
   A5B9 7B 00              2142 	mov	r3,#0x00
   A5BB                    2143 00103$:
                           2144 ;	../../Platform/nano/rf.c:556: pause_us(250);
                           2145 ;	genCall
                           2146 ;	Peephole 182.b	used 16 bit load of dptr
   A5BB 90 00 FA           2147 	mov	dptr,#0x00FA
   A5BE C0 02              2148 	push	ar2
   A5C0 C0 03              2149 	push	ar3
   A5C2 C0 04              2150 	push	ar4
   A5C4 12 37 B7           2151 	lcall	_pause_us
   A5C7 D0 04              2152 	pop	ar4
   A5C9 D0 03              2153 	pop	ar3
   A5CB D0 02              2154 	pop	ar2
                           2155 ;	../../Platform/nano/rf.c:557: if(!(RFSTATUS & CCA))
                           2156 ;	genAssign
   A5CD 90 DF 62           2157 	mov	dptr,#_RFSTATUS
   A5D0 E0                 2158 	movx	a,@dptr
   A5D1 FD                 2159 	mov	r5,a
   A5D2 A3                 2160 	inc	dptr
   A5D3 E0                 2161 	movx	a,@dptr
   A5D4 FE                 2162 	mov	r6,a
                           2163 ;	genAnd
   A5D5 ED                 2164 	mov	a,r5
                           2165 ;	genIfxJump
                           2166 ;	Peephole 108.e	removed ljmp by inverse jump logic
   A5D6 20 E0 04           2167 	jb	acc.0,00105$
                           2168 ;	Peephole 300	removed redundant label 00133$
                           2169 ;	../../Platform/nano/rf.c:559: cca=0;
                           2170 ;	genAssign
   A5D9 7B 00              2171 	mov	r3,#0x00
                           2172 ;	../../Platform/nano/rf.c:560: retval = pdFALSE;
                           2173 ;	genAssign
   A5DB 7A 00              2174 	mov	r2,#0x00
   A5DD                    2175 00105$:
                           2176 ;	../../Platform/nano/rf.c:562: counter++;
                           2177 ;	genPlus
                           2178 ;     genPlusIncr
   A5DD 0C                 2179 	inc	r4
                           2180 ;	Peephole 112.b	changed ljmp to sjmp
   A5DE 80 CF              2181 	sjmp	00106$
   A5E0                    2182 00110$:
                           2183 ;	../../Platform/nano/rf.c:566: retval = pdFALSE;
                           2184 ;	genAssign
   A5E0 7A 00              2185 	mov	r2,#0x00
                           2186 ;	../../Platform/nano/rf.c:567: break;
                           2187 ;	../../Platform/nano/rf.c:569: case 0:
                           2188 ;	Peephole 112.b	changed ljmp to sjmp
   A5E2 80 0E              2189 	sjmp	00115$
   A5E4                    2190 00112$:
                           2191 ;	../../Platform/nano/rf.c:570: if(!(RFSTATUS & CCA))
                           2192 ;	genAssign
   A5E4 90 DF 62           2193 	mov	dptr,#_RFSTATUS
   A5E7 E0                 2194 	movx	a,@dptr
   A5E8 FB                 2195 	mov	r3,a
   A5E9 A3                 2196 	inc	dptr
   A5EA E0                 2197 	movx	a,@dptr
   A5EB FC                 2198 	mov	r4,a
                           2199 ;	genAnd
   A5EC EB                 2200 	mov	a,r3
                           2201 ;	genIfxJump
                           2202 ;	Peephole 108.e	removed ljmp by inverse jump logic
   A5ED 20 E0 02           2203 	jb	acc.0,00115$
                           2204 ;	Peephole 300	removed redundant label 00134$
                           2205 ;	../../Platform/nano/rf.c:572: retval = pdFALSE;
                           2206 ;	genAssign
   A5F0 7A 00              2207 	mov	r2,#0x00
                           2208 ;	../../Platform/nano/rf.c:578: }
   A5F2                    2209 00115$:
                           2210 ;	../../Platform/nano/rf.c:579: return retval;		
                           2211 ;	genRet
   A5F2 8A 82              2212 	mov	dpl,r2
                           2213 ;	Peephole 300	removed redundant label 00116$
   A5F4 D0 10              2214 	pop	_bp
   A5F6 22                 2215 	ret
                           2216 ;------------------------------------------------------------
                           2217 ;Allocation info for local variables in function 'rf_send_ack'
                           2218 ;------------------------------------------------------------
                           2219 ;pending                   Allocated to registers r2 
                           2220 ;------------------------------------------------------------
                           2221 ;	../../Platform/nano/rf.c:588: void rf_send_ack(uint8_t pending)
                           2222 ;	-----------------------------------------
                           2223 ;	 function rf_send_ack
                           2224 ;	-----------------------------------------
   A5F7                    2225 _rf_send_ack:
                           2226 ;	genReceive
                           2227 ;	../../Platform/nano/rf.c:590: if(pending)
                           2228 ;	genIfx
                           2229 ;	peephole 177.g	optimized mov sequence
   A5F7 E5 82              2230 	mov	a,dpl
   A5F9 FA                 2231 	mov	r2,a
                           2232 ;	genIfxJump
                           2233 ;	Peephole 108.c	removed ljmp by inverse jump logic
   A5FA 60 06              2234 	jz	00102$
                           2235 ;	Peephole 300	removed redundant label 00107$
                           2236 ;	../../Platform/nano/rf.c:592: rf_command(ISACKPEND);
                           2237 ;	genCall
   A5FC 75 82 E9           2238 	mov	dpl,#0xE9
                           2239 ;	Peephole 112.b	changed ljmp to sjmp
                           2240 ;	Peephole 251.b	replaced sjmp to ret with ret
                           2241 ;	Peephole 253.a	replaced lcall/ret with ljmp
   A5FF 02 A0 6C           2242 	ljmp	_rf_command
   A602                    2243 00102$:
                           2244 ;	../../Platform/nano/rf.c:596: rf_command(ISACK);
                           2245 ;	genCall
   A602 75 82 E8           2246 	mov	dpl,#0xE8
                           2247 ;	Peephole 253.b	replaced lcall/ret with ljmp
   A605 02 A0 6C           2248 	ljmp	_rf_command
                           2249 ;
                           2250 ;------------------------------------------------------------
                           2251 ;Allocation info for local variables in function 'rf_write'
                           2252 ;------------------------------------------------------------
                           2253 ;buffer                    Allocated to stack - offset 1
                           2254 ;counter                   Allocated to registers r3 
                           2255 ;i                         Allocated to registers r2 
                           2256 ;retval                    Allocated to stack - offset 4
                           2257 ;length                    Allocated to stack - offset 5
                           2258 ;ptr                       Allocated to stack - offset 7
                           2259 ;sloc0                     Allocated to stack - offset 10
                           2260 ;------------------------------------------------------------
                           2261 ;	../../Platform/nano/rf.c:616: portCHAR rf_write(buffer_t *buffer)
                           2262 ;	-----------------------------------------
                           2263 ;	 function rf_write
                           2264 ;	-----------------------------------------
   A608                    2265 _rf_write:
   A608 C0 10              2266 	push	_bp
   A60A 85 81 10           2267 	mov	_bp,sp
                           2268 ;     genReceive
   A60D C0 82              2269 	push	dpl
   A60F C0 83              2270 	push	dph
   A611 C0 F0              2271 	push	b
   A613 E5 81              2272 	mov	a,sp
   A615 24 0C              2273 	add	a,#0x0c
   A617 F5 81              2274 	mov	sp,a
                           2275 ;	../../Platform/nano/rf.c:619: portCHAR retval = pdTRUE;
                           2276 ;	genAssign
   A619 E5 10              2277 	mov	a,_bp
   A61B 24 04              2278 	add	a,#0x04
   A61D F8                 2279 	mov	r0,a
   A61E 76 01              2280 	mov	@r0,#0x01
                           2281 ;	../../Platform/nano/rf.c:620: int16_t length =  buffer->buf_end - buffer->buf_ptr;
                           2282 ;	genPlus
   A620 A8 10              2283 	mov	r0,_bp
   A622 08                 2284 	inc	r0
                           2285 ;     genPlusIncr
   A623 74 22              2286 	mov	a,#0x22
   A625 26                 2287 	add	a,@r0
   A626 FE                 2288 	mov	r6,a
                           2289 ;	Peephole 181	changed mov to clr
   A627 E4                 2290 	clr	a
   A628 08                 2291 	inc	r0
   A629 36                 2292 	addc	a,@r0
   A62A FF                 2293 	mov	r7,a
   A62B 08                 2294 	inc	r0
   A62C 86 05              2295 	mov	ar5,@r0
                           2296 ;	genPointerGet
                           2297 ;	genGenPointerGet
   A62E 8E 82              2298 	mov	dpl,r6
   A630 8F 83              2299 	mov	dph,r7
   A632 8D F0              2300 	mov	b,r5
   A634 12 E4 9F           2301 	lcall	__gptrget
   A637 FE                 2302 	mov	r6,a
   A638 A3                 2303 	inc	dptr
   A639 12 E4 9F           2304 	lcall	__gptrget
   A63C FF                 2305 	mov	r7,a
                           2306 ;	genPlus
   A63D A8 10              2307 	mov	r0,_bp
   A63F 08                 2308 	inc	r0
   A640 E5 10              2309 	mov	a,_bp
   A642 24 0A              2310 	add	a,#0x0a
   A644 F9                 2311 	mov	r1,a
                           2312 ;     genPlusIncr
   A645 74 20              2313 	mov	a,#0x20
   A647 26                 2314 	add	a,@r0
   A648 F7                 2315 	mov	@r1,a
                           2316 ;	Peephole 181	changed mov to clr
   A649 E4                 2317 	clr	a
   A64A 08                 2318 	inc	r0
   A64B 36                 2319 	addc	a,@r0
   A64C 09                 2320 	inc	r1
   A64D F7                 2321 	mov	@r1,a
   A64E 08                 2322 	inc	r0
   A64F 09                 2323 	inc	r1
   A650 E6                 2324 	mov	a,@r0
   A651 F7                 2325 	mov	@r1,a
                           2326 ;	genPointerGet
                           2327 ;	genGenPointerGet
   A652 E5 10              2328 	mov	a,_bp
   A654 24 0A              2329 	add	a,#0x0a
   A656 F8                 2330 	mov	r0,a
   A657 86 82              2331 	mov	dpl,@r0
   A659 08                 2332 	inc	r0
   A65A 86 83              2333 	mov	dph,@r0
   A65C 08                 2334 	inc	r0
   A65D 86 F0              2335 	mov	b,@r0
   A65F 12 E4 9F           2336 	lcall	__gptrget
   A662 FD                 2337 	mov	r5,a
   A663 A3                 2338 	inc	dptr
   A664 12 E4 9F           2339 	lcall	__gptrget
   A667 FA                 2340 	mov	r2,a
                           2341 ;	genMinus
   A668 EE                 2342 	mov	a,r6
   A669 C3                 2343 	clr	c
                           2344 ;	Peephole 236.l	used r5 instead of ar5
   A66A 9D                 2345 	subb	a,r5
   A66B FE                 2346 	mov	r6,a
   A66C EF                 2347 	mov	a,r7
                           2348 ;	Peephole 236.l	used r2 instead of ar2
   A66D 9A                 2349 	subb	a,r2
   A66E FF                 2350 	mov	r7,a
                           2351 ;	genAssign
   A66F E5 10              2352 	mov	a,_bp
   A671 24 05              2353 	add	a,#0x05
   A673 F8                 2354 	mov	r0,a
   A674 A6 06              2355 	mov	@r0,ar6
   A676 08                 2356 	inc	r0
   A677 A6 07              2357 	mov	@r0,ar7
                           2358 ;	../../Platform/nano/rf.c:623: if (rx_flags & RX_ACTIVE)
                           2359 ;	genAssign
   A679 90 F0 34           2360 	mov	dptr,#_rx_flags
   A67C E0                 2361 	movx	a,@dptr
                           2362 ;	genAnd
   A67D FC                 2363 	mov	r4,a
                           2364 ;	Peephole 105	removed redundant mov
                           2365 ;	genIfxJump
                           2366 ;	Peephole 108.d	removed ljmp by inverse jump logic
   A67E 30 E7 3D           2367 	jnb	acc.7,00107$
                           2368 ;	Peephole 300	removed redundant label 00158$
                           2369 ;	../../Platform/nano/rf.c:625: if ( (RFSTATUS & FIFOP) || (RFSTATUS & SFD) )
                           2370 ;	genAssign
   A681 90 DF 62           2371 	mov	dptr,#_RFSTATUS
   A684 E0                 2372 	movx	a,@dptr
   A685 FC                 2373 	mov	r4,a
   A686 A3                 2374 	inc	dptr
   A687 E0                 2375 	movx	a,@dptr
   A688 FD                 2376 	mov	r5,a
                           2377 ;	genAnd
   A689 EC                 2378 	mov	a,r4
                           2379 ;	genIfxJump
                           2380 ;	Peephole 108.e	removed ljmp by inverse jump logic
   A68A 20 E2 0C           2381 	jb	acc.2,00103$
                           2382 ;	Peephole 300	removed redundant label 00159$
                           2383 ;	genAssign
   A68D 90 DF 62           2384 	mov	dptr,#_RFSTATUS
   A690 E0                 2385 	movx	a,@dptr
   A691 FC                 2386 	mov	r4,a
   A692 A3                 2387 	inc	dptr
   A693 E0                 2388 	movx	a,@dptr
   A694 FD                 2389 	mov	r5,a
                           2390 ;	genAnd
   A695 EC                 2391 	mov	a,r4
                           2392 ;	genIfxJump
                           2393 ;	Peephole 108.d	removed ljmp by inverse jump logic
   A696 30 E1 25           2394 	jnb	acc.1,00107$
                           2395 ;	Peephole 300	removed redundant label 00160$
   A699                    2396 00103$:
                           2397 ;	../../Platform/nano/rf.c:630: if ((RFSTATUS & FIFOP))
                           2398 ;	genAssign
   A699 90 DF 62           2399 	mov	dptr,#_RFSTATUS
   A69C E0                 2400 	movx	a,@dptr
   A69D FC                 2401 	mov	r4,a
   A69E A3                 2402 	inc	dptr
   A69F E0                 2403 	movx	a,@dptr
   A6A0 FD                 2404 	mov	r5,a
                           2405 ;	genAnd
   A6A1 EC                 2406 	mov	a,r4
                           2407 ;	genIfxJump
                           2408 ;	Peephole 108.d	removed ljmp by inverse jump logic
   A6A2 30 E2 12           2409 	jnb	acc.2,00102$
                           2410 ;	Peephole 300	removed redundant label 00161$
                           2411 ;	../../Platform/nano/rf.c:632: rf_command(ISFLUSHTX);
                           2412 ;	genCall
   A6A5 75 82 E7           2413 	mov	dpl,#0xE7
   A6A8 12 A0 6C           2414 	lcall	_rf_command
                           2415 ;	../../Platform/nano/rf.c:633: rf_command(ISFLUSHRX);
                           2416 ;	genCall
   A6AB 75 82 E6           2417 	mov	dpl,#0xE6
   A6AE 12 A0 6C           2418 	lcall	_rf_command
                           2419 ;	../../Platform/nano/rf.c:634: rf_command(ISFLUSHRX);
                           2420 ;	genCall
   A6B1 75 82 E6           2421 	mov	dpl,#0xE6
   A6B4 12 A0 6C           2422 	lcall	_rf_command
   A6B7                    2423 00102$:
                           2424 ;	../../Platform/nano/rf.c:637: retval = pdFALSE;		
                           2425 ;	genAssign
   A6B7 E5 10              2426 	mov	a,_bp
   A6B9 24 04              2427 	add	a,#0x04
   A6BB F8                 2428 	mov	r0,a
   A6BC 76 00              2429 	mov	@r0,#0x00
   A6BE                    2430 00107$:
                           2431 ;	../../Platform/nano/rf.c:641: rf_tx_enable();
                           2432 ;	genCall
   A6BE 12 A1 FB           2433 	lcall	_rf_tx_enable
                           2434 ;	../../Platform/nano/rf.c:642: if ( (length <= 128) && (retval == pdTRUE) )
                           2435 ;	genCmpGt
   A6C1 E5 10              2436 	mov	a,_bp
   A6C3 24 05              2437 	add	a,#0x05
   A6C5 F8                 2438 	mov	r0,a
                           2439 ;	genCmp
   A6C6 C3                 2440 	clr	c
   A6C7 74 80              2441 	mov	a,#0x80
   A6C9 96                 2442 	subb	a,@r0
                           2443 ;	Peephole 159	avoided xrl during execution
   A6CA 74 80              2444 	mov	a,#(0x00 ^ 0x80)
   A6CC 08                 2445 	inc	r0
   A6CD 86 F0              2446 	mov	b,@r0
   A6CF 63 F0 80           2447 	xrl	b,#0x80
   A6D2 95 F0              2448 	subb	a,b
   A6D4 E4                 2449 	clr	a
   A6D5 33                 2450 	rlc	a
                           2451 ;	genIfx
   A6D6 FC                 2452 	mov	r4,a
                           2453 ;	Peephole 105	removed redundant mov
                           2454 ;	genIfxJump
   A6D7 60 03              2455 	jz	00162$
   A6D9 02 A8 2A           2456 	ljmp	00126$
   A6DC                    2457 00162$:
                           2458 ;	genCmpEq
   A6DC E5 10              2459 	mov	a,_bp
   A6DE 24 04              2460 	add	a,#0x04
   A6E0 F8                 2461 	mov	r0,a
                           2462 ;	gencjneshort
   A6E1 B6 01 02           2463 	cjne	@r0,#0x01,00163$
   A6E4 80 03              2464 	sjmp	00164$
   A6E6                    2465 00163$:
   A6E6 02 A8 2A           2466 	ljmp	00126$
   A6E9                    2467 00164$:
                           2468 ;	../../Platform/nano/rf.c:644: uint8_t *ptr = buffer->buf + buffer->buf_ptr;
                           2469 ;	genIpush
   A6E9 C0 04              2470 	push	ar4
                           2471 ;	genPlus
   A6EB A8 10              2472 	mov	r0,_bp
   A6ED 08                 2473 	inc	r0
                           2474 ;     genPlusIncr
   A6EE 74 2C              2475 	mov	a,#0x2C
   A6F0 26                 2476 	add	a,@r0
   A6F1 FD                 2477 	mov	r5,a
                           2478 ;	Peephole 181	changed mov to clr
   A6F2 E4                 2479 	clr	a
   A6F3 08                 2480 	inc	r0
   A6F4 36                 2481 	addc	a,@r0
   A6F5 FE                 2482 	mov	r6,a
   A6F6 08                 2483 	inc	r0
   A6F7 86 07              2484 	mov	ar7,@r0
                           2485 ;	genPointerGet
                           2486 ;	genGenPointerGet
   A6F9 E5 10              2487 	mov	a,_bp
   A6FB 24 0A              2488 	add	a,#0x0a
   A6FD F8                 2489 	mov	r0,a
   A6FE 86 82              2490 	mov	dpl,@r0
   A700 08                 2491 	inc	r0
   A701 86 83              2492 	mov	dph,@r0
   A703 08                 2493 	inc	r0
   A704 86 F0              2494 	mov	b,@r0
   A706 12 E4 9F           2495 	lcall	__gptrget
   A709 FC                 2496 	mov	r4,a
   A70A A3                 2497 	inc	dptr
   A70B 12 E4 9F           2498 	lcall	__gptrget
   A70E FA                 2499 	mov	r2,a
                           2500 ;	genPlus
                           2501 ;	Peephole 236.g	used r4 instead of ar4
   A70F EC                 2502 	mov	a,r4
                           2503 ;	Peephole 236.a	used r5 instead of ar5
   A710 2D                 2504 	add	a,r5
   A711 FD                 2505 	mov	r5,a
                           2506 ;	Peephole 236.g	used r2 instead of ar2
   A712 EA                 2507 	mov	a,r2
                           2508 ;	Peephole 236.b	used r6 instead of ar6
   A713 3E                 2509 	addc	a,r6
   A714 FE                 2510 	mov	r6,a
                           2511 ;	genAssign
   A715 E5 10              2512 	mov	a,_bp
   A717 24 07              2513 	add	a,#0x07
   A719 F8                 2514 	mov	r0,a
   A71A A6 05              2515 	mov	@r0,ar5
   A71C 08                 2516 	inc	r0
   A71D A6 06              2517 	mov	@r0,ar6
   A71F 08                 2518 	inc	r0
   A720 A6 07              2519 	mov	@r0,ar7
                           2520 ;	../../Platform/nano/rf.c:646: rf_command(ISFLUSHTX);
                           2521 ;	genCall
   A722 75 82 E7           2522 	mov	dpl,#0xE7
   A725 C0 04              2523 	push	ar4
   A727 12 A0 6C           2524 	lcall	_rf_command
   A72A D0 04              2525 	pop	ar4
                           2526 ;	../../Platform/nano/rf.c:648: RFD = (length+2);
                           2527 ;	genCast
   A72C E5 10              2528 	mov	a,_bp
   A72E 24 05              2529 	add	a,#0x05
   A730 F8                 2530 	mov	r0,a
   A731 86 02              2531 	mov	ar2,@r0
                           2532 ;	genPlus
                           2533 ;     genPlusIncr
   A733 74 02              2534 	mov	a,#0x02
                           2535 ;	Peephole 236.a	used r2 instead of ar2
   A735 2A                 2536 	add	a,r2
   A736 F5 D9              2537 	mov	_RFD,a
                           2538 ;	../../Platform/nano/rf.c:710: return retval;		
                           2539 ;	genIpop
   A738 D0 04              2540 	pop	ar4
                           2541 ;	../../Platform/nano/rf.c:650: for (i = 0 ; i < length ; i++)
                           2542 ;	genAssign
   A73A E5 10              2543 	mov	a,_bp
   A73C 24 07              2544 	add	a,#0x07
   A73E F8                 2545 	mov	r0,a
   A73F 86 02              2546 	mov	ar2,@r0
   A741 08                 2547 	inc	r0
   A742 86 03              2548 	mov	ar3,@r0
   A744 08                 2549 	inc	r0
   A745 86 05              2550 	mov	ar5,@r0
                           2551 ;	genAssign
   A747 7E 00              2552 	mov	r6,#0x00
   A749                    2553 00131$:
                           2554 ;	genIpush
   A749 C0 04              2555 	push	ar4
                           2556 ;	genCast
   A74B 8E 07              2557 	mov	ar7,r6
   A74D 7C 00              2558 	mov	r4,#0x00
                           2559 ;	genCmpLt
   A74F E5 10              2560 	mov	a,_bp
   A751 24 05              2561 	add	a,#0x05
   A753 F8                 2562 	mov	r0,a
                           2563 ;	genCmp
   A754 C3                 2564 	clr	c
   A755 EF                 2565 	mov	a,r7
   A756 96                 2566 	subb	a,@r0
   A757 EC                 2567 	mov	a,r4
   A758 64 80              2568 	xrl	a,#0x80
   A75A 08                 2569 	inc	r0
   A75B 86 F0              2570 	mov	b,@r0
   A75D 63 F0 80           2571 	xrl	b,#0x80
   A760 95 F0              2572 	subb	a,b
   A762 E4                 2573 	clr	a
   A763 33                 2574 	rlc	a
                           2575 ;	genIpop
   A764 D0 04              2576 	pop	ar4
                           2577 ;	genIfx
                           2578 ;	genIfxJump
                           2579 ;	Peephole 108.c	removed ljmp by inverse jump logic
   A766 60 13              2580 	jz	00134$
                           2581 ;	Peephole 300	removed redundant label 00165$
                           2582 ;	../../Platform/nano/rf.c:652: RFD = *ptr++;
                           2583 ;	genPointerGet
                           2584 ;	genGenPointerGet
   A768 8A 82              2585 	mov	dpl,r2
   A76A 8B 83              2586 	mov	dph,r3
   A76C 8D F0              2587 	mov	b,r5
   A76E 12 E4 9F           2588 	lcall	__gptrget
   A771 F5 D9              2589 	mov	_RFD,a
   A773 A3                 2590 	inc	dptr
   A774 AA 82              2591 	mov	r2,dpl
   A776 AB 83              2592 	mov	r3,dph
                           2593 ;	../../Platform/nano/rf.c:650: for (i = 0 ; i < length ; i++)
                           2594 ;	genPlus
                           2595 ;     genPlusIncr
   A778 0E                 2596 	inc	r6
                           2597 ;	Peephole 112.b	changed ljmp to sjmp
   A779 80 CE              2598 	sjmp	00131$
   A77B                    2599 00134$:
                           2600 ;	../../Platform/nano/rf.c:654: RFD = (0);
                           2601 ;	genAssign
   A77B 75 D9 00           2602 	mov	_RFD,#0x00
                           2603 ;	../../Platform/nano/rf.c:655: RFD = (0);
                           2604 ;	genAssign
   A77E 75 D9 00           2605 	mov	_RFD,#0x00
                           2606 ;	../../Platform/nano/rf.c:657: if (rf_cca_check(0,0) == pdFALSE)
                           2607 ;	genIpush
   A781 C0 04              2608 	push	ar4
                           2609 ;	Peephole 181	changed mov to clr
   A783 E4                 2610 	clr	a
   A784 C0 E0              2611 	push	acc
                           2612 ;	genCall
   A786 75 82 00           2613 	mov	dpl,#0x00
   A789 12 A5 54           2614 	lcall	_rf_cca_check
   A78C AA 82              2615 	mov	r2,dpl
   A78E 15 81              2616 	dec	sp
   A790 D0 04              2617 	pop	ar4
                           2618 ;	genIfx
   A792 EA                 2619 	mov	a,r2
                           2620 ;	genIfxJump
                           2621 ;	Peephole 108.b	removed ljmp by inverse jump logic
   A793 70 14              2622 	jnz	00109$
                           2623 ;	Peephole 300	removed redundant label 00166$
                           2624 ;	../../Platform/nano/rf.c:659: rf_command(ISFLUSHTX);
                           2625 ;	genCall
   A795 75 82 E7           2626 	mov	dpl,#0xE7
   A798 12 A0 6C           2627 	lcall	_rf_command
                           2628 ;	../../Platform/nano/rf.c:660: rx_flags = 0;
                           2629 ;	genAssign
   A79B 90 F0 34           2630 	mov	dptr,#_rx_flags
                           2631 ;	Peephole 181	changed mov to clr
   A79E E4                 2632 	clr	a
   A79F F0                 2633 	movx	@dptr,a
                           2634 ;	../../Platform/nano/rf.c:661: rf_rx_enable();
                           2635 ;	genCall
   A7A0 12 A1 78           2636 	lcall	_rf_rx_enable
                           2637 ;	../../Platform/nano/rf.c:663: return pdTRUE+1;
                           2638 ;	genRet
   A7A3 75 82 02           2639 	mov	dpl,#0x02
   A7A6 02 A8 4B           2640 	ljmp	00135$
   A7A9                    2641 00109$:
                           2642 ;	../../Platform/nano/rf.c:666: i= 0;
                           2643 ;	genAssign
   A7A9 7A 00              2644 	mov	r2,#0x00
                           2645 ;	../../Platform/nano/rf.c:667: RFIF &= ~IRQ_TXDONE;
                           2646 ;	genAnd
   A7AB 53 E9 BF           2647 	anl	_RFIF,#0xBF
                           2648 ;	../../Platform/nano/rf.c:668: while (i++ < 3)
   A7AE                    2649 00116$:
                           2650 ;	genAssign
   A7AE 8A 03              2651 	mov	ar3,r2
                           2652 ;	genPlus
                           2653 ;     genPlusIncr
   A7B0 0A                 2654 	inc	r2
                           2655 ;	genCmpLt
                           2656 ;	genCmp
   A7B1 BB 03 00           2657 	cjne	r3,#0x03,00167$
   A7B4                    2658 00167$:
                           2659 ;	genIfxJump
                           2660 ;	Peephole 108.a	removed ljmp by inverse jump logic
   A7B4 50 48              2661 	jnc	00118$
                           2662 ;	Peephole 300	removed redundant label 00168$
                           2663 ;	../../Platform/nano/rf.c:670: rf_command(ISTXON);
                           2664 ;	genCall
   A7B6 75 82 E3           2665 	mov	dpl,#0xE3
   A7B9 C0 02              2666 	push	ar2
   A7BB C0 04              2667 	push	ar4
   A7BD 12 A0 6C           2668 	lcall	_rf_command
   A7C0 D0 04              2669 	pop	ar4
   A7C2 D0 02              2670 	pop	ar2
                           2671 ;	../../Platform/nano/rf.c:672: while(!(RFSTATUS & TX_ACTIVE) && (counter++ < 200))
                           2672 ;	genAssign
   A7C4 7B 00              2673 	mov	r3,#0x00
   A7C6                    2674 00111$:
                           2675 ;	genAssign
   A7C6 90 DF 62           2676 	mov	dptr,#_RFSTATUS
   A7C9 E0                 2677 	movx	a,@dptr
   A7CA FD                 2678 	mov	r5,a
   A7CB A3                 2679 	inc	dptr
   A7CC E0                 2680 	movx	a,@dptr
   A7CD FE                 2681 	mov	r6,a
                           2682 ;	genAnd
   A7CE ED                 2683 	mov	a,r5
                           2684 ;	genIfxJump
                           2685 ;	Peephole 108.e	removed ljmp by inverse jump logic
   A7CF 20 E4 1C           2686 	jb	acc.4,00113$
                           2687 ;	Peephole 300	removed redundant label 00169$
                           2688 ;	genAssign
   A7D2 8B 05              2689 	mov	ar5,r3
                           2690 ;	genPlus
                           2691 ;     genPlusIncr
   A7D4 0B                 2692 	inc	r3
                           2693 ;	genCmpLt
                           2694 ;	genCmp
   A7D5 BD C8 00           2695 	cjne	r5,#0xC8,00170$
   A7D8                    2696 00170$:
                           2697 ;	genIfxJump
                           2698 ;	Peephole 108.a	removed ljmp by inverse jump logic
   A7D8 50 14              2699 	jnc	00113$
                           2700 ;	Peephole 300	removed redundant label 00171$
                           2701 ;	../../Platform/nano/rf.c:674: pause_us(10);
                           2702 ;	genCall
                           2703 ;	Peephole 182.b	used 16 bit load of dptr
   A7DA 90 00 0A           2704 	mov	dptr,#0x000A
   A7DD C0 02              2705 	push	ar2
   A7DF C0 03              2706 	push	ar3
   A7E1 C0 04              2707 	push	ar4
   A7E3 12 37 B7           2708 	lcall	_pause_us
   A7E6 D0 04              2709 	pop	ar4
   A7E8 D0 03              2710 	pop	ar3
   A7EA D0 02              2711 	pop	ar2
                           2712 ;	Peephole 112.b	changed ljmp to sjmp
   A7EC 80 D8              2713 	sjmp	00111$
   A7EE                    2714 00113$:
                           2715 ;	../../Platform/nano/rf.c:676: if (RFSTATUS & TX_ACTIVE) i = 200;
                           2716 ;	genAssign
   A7EE 90 DF 62           2717 	mov	dptr,#_RFSTATUS
   A7F1 E0                 2718 	movx	a,@dptr
   A7F2 FB                 2719 	mov	r3,a
   A7F3 A3                 2720 	inc	dptr
   A7F4 E0                 2721 	movx	a,@dptr
   A7F5 FD                 2722 	mov	r5,a
                           2723 ;	genAnd
   A7F6 EB                 2724 	mov	a,r3
                           2725 ;	genIfxJump
                           2726 ;	Peephole 108.d	removed ljmp by inverse jump logic
   A7F7 30 E4 B4           2727 	jnb	acc.4,00116$
                           2728 ;	Peephole 300	removed redundant label 00172$
                           2729 ;	genAssign
   A7FA 7A C8              2730 	mov	r2,#0xC8
                           2731 ;	Peephole 112.b	changed ljmp to sjmp
   A7FC 80 B0              2732 	sjmp	00116$
   A7FE                    2733 00118$:
                           2734 ;	../../Platform/nano/rf.c:679: if (i ==3)
                           2735 ;	genCmpEq
                           2736 ;	gencjneshort
                           2737 ;	Peephole 112.b	changed ljmp to sjmp
                           2738 ;	Peephole 198.b	optimized misc jump sequence
   A7FE BA 03 18           2739 	cjne	r2,#0x03,00119$
                           2740 ;	Peephole 200.b	removed redundant sjmp
                           2741 ;	Peephole 300	removed redundant label 00173$
                           2742 ;	Peephole 300	removed redundant label 00174$
                           2743 ;	../../Platform/nano/rf.c:684: rf_command(ISRFOFF);
                           2744 ;	genCall
   A801 75 82 E5           2745 	mov	dpl,#0xE5
   A804 C0 04              2746 	push	ar4
   A806 12 A0 6C           2747 	lcall	_rf_command
   A809 D0 04              2748 	pop	ar4
                           2749 ;	../../Platform/nano/rf.c:685: tx_flags = 0;
                           2750 ;	genAssign
   A80B 90 F0 35           2751 	mov	dptr,#_tx_flags
                           2752 ;	Peephole 181	changed mov to clr
   A80E E4                 2753 	clr	a
   A80F F0                 2754 	movx	@dptr,a
                           2755 ;	../../Platform/nano/rf.c:686: retval = pdFALSE;
                           2756 ;	genAssign
   A810 E5 10              2757 	mov	a,_bp
   A812 24 04              2758 	add	a,#0x04
   A814 F8                 2759 	mov	r0,a
   A815 76 00              2760 	mov	@r0,#0x00
                           2761 ;	../../Platform/nano/rf.c:690: while(!(RFIF & IRQ_TXDONE))
                           2762 ;	Peephole 112.b	changed ljmp to sjmp
   A817 80 11              2763 	sjmp	00126$
   A819                    2764 00119$:
                           2765 ;	genAnd
   A819 E5 E9              2766 	mov	a,_RFIF
                           2767 ;	genIfxJump
                           2768 ;	Peephole 108.e	removed ljmp by inverse jump logic
   A81B 20 E6 0C           2769 	jb	acc.6,00126$
                           2770 ;	Peephole 300	removed redundant label 00175$
                           2771 ;	../../Platform/nano/rf.c:692: pause_us(10);
                           2772 ;	genCall
                           2773 ;	Peephole 182.b	used 16 bit load of dptr
   A81E 90 00 0A           2774 	mov	dptr,#0x000A
   A821 C0 04              2775 	push	ar4
   A823 12 37 B7           2776 	lcall	_pause_us
   A826 D0 04              2777 	pop	ar4
                           2778 ;	Peephole 112.b	changed ljmp to sjmp
   A828 80 EF              2779 	sjmp	00119$
   A82A                    2780 00126$:
                           2781 ;	../../Platform/nano/rf.c:697: if ((retval == pdTRUE) && (length > 128))
                           2782 ;	genCmpEq
   A82A E5 10              2783 	mov	a,_bp
   A82C 24 04              2784 	add	a,#0x04
   A82E F8                 2785 	mov	r0,a
                           2786 ;	gencjneshort
                           2787 ;	Peephole 112.b	changed ljmp to sjmp
                           2788 ;	Peephole 198.b	optimized misc jump sequence
   A82F B6 01 0A           2789 	cjne	@r0,#0x01,00129$
                           2790 ;	Peephole 200.b	removed redundant sjmp
                           2791 ;	Peephole 300	removed redundant label 00176$
                           2792 ;	Peephole 300	removed redundant label 00177$
                           2793 ;	genIfx
   A832 EC                 2794 	mov	a,r4
                           2795 ;	genIfxJump
                           2796 ;	Peephole 108.c	removed ljmp by inverse jump logic
   A833 60 07              2797 	jz	00129$
                           2798 ;	Peephole 300	removed redundant label 00178$
                           2799 ;	../../Platform/nano/rf.c:704: retval = pdFALSE;
                           2800 ;	genAssign
   A835 E5 10              2801 	mov	a,_bp
   A837 24 04              2802 	add	a,#0x04
   A839 F8                 2803 	mov	r0,a
   A83A 76 00              2804 	mov	@r0,#0x00
   A83C                    2805 00129$:
                           2806 ;	../../Platform/nano/rf.c:706: tx_flags = 0;
                           2807 ;	genAssign
   A83C 90 F0 35           2808 	mov	dptr,#_tx_flags
                           2809 ;	Peephole 181	changed mov to clr
   A83F E4                 2810 	clr	a
   A840 F0                 2811 	movx	@dptr,a
                           2812 ;	../../Platform/nano/rf.c:707: rf_rx_enable();
                           2813 ;	genCall
   A841 12 A1 78           2814 	lcall	_rf_rx_enable
                           2815 ;	../../Platform/nano/rf.c:710: return retval;		
                           2816 ;	genRet
   A844 E5 10              2817 	mov	a,_bp
   A846 24 04              2818 	add	a,#0x04
   A848 F8                 2819 	mov	r0,a
   A849 86 82              2820 	mov	dpl,@r0
   A84B                    2821 00135$:
   A84B 85 10 81           2822 	mov	sp,_bp
   A84E D0 10              2823 	pop	_bp
   A850 22                 2824 	ret
                           2825 ;------------------------------------------------------------
                           2826 ;Allocation info for local variables in function 'rf_mac_get'
                           2827 ;------------------------------------------------------------
                           2828 ;address                   Allocated to registers r2 r3 r4 
                           2829 ;i                         Allocated to stack - offset 1
                           2830 ;sloc0                     Allocated to stack - offset 2
                           2831 ;------------------------------------------------------------
                           2832 ;	../../Platform/nano/rf.c:719: portCHAR rf_mac_get(sockaddr_t *address)
                           2833 ;	-----------------------------------------
                           2834 ;	 function rf_mac_get
                           2835 ;	-----------------------------------------
   A851                    2836 _rf_mac_get:
   A851 C0 10              2837 	push	_bp
                           2838 ;	peephole 177.h	optimized mov sequence
   A853 E5 81              2839 	mov	a,sp
   A855 F5 10              2840 	mov	_bp,a
   A857 24 04              2841 	add	a,#0x04
   A859 F5 81              2842 	mov	sp,a
                           2843 ;	genReceive
                           2844 ;	../../Platform/nano/rf.c:721: mac_get(address);
                           2845 ;	genCall
   A85B AA 82              2846 	mov	r2,dpl
   A85D AB 83              2847 	mov	r3,dph
   A85F AC F0              2848 	mov	r4,b
                           2849 ;	Peephole 238.d	removed 3 redundant moves
   A861 C0 02              2850 	push	ar2
   A863 C0 03              2851 	push	ar3
   A865 C0 04              2852 	push	ar4
   A867 12 37 FC           2853 	lcall	_mac_get
   A86A D0 04              2854 	pop	ar4
   A86C D0 03              2855 	pop	ar3
   A86E D0 02              2856 	pop	ar2
                           2857 ;	../../Platform/nano/rf.c:722: if (address->addr_type == ADDR_NONE)
                           2858 ;	genPointerGet
                           2859 ;	genGenPointerGet
   A870 8A 82              2860 	mov	dpl,r2
   A872 8B 83              2861 	mov	dph,r3
   A874 8C F0              2862 	mov	b,r4
   A876 12 E4 9F           2863 	lcall	__gptrget
                           2864 ;	genIfxJump
   A879 60 03              2865 	jz	00116$
   A87B 02 AA 03           2866 	ljmp	00104$
   A87E                    2867 00116$:
                           2868 ;	../../Platform/nano/rf.c:725: flash_read(&ft_buffer[0], 0x1FFF8, 8);
                           2869 ;	genIpush
   A87E C0 02              2870 	push	ar2
   A880 C0 03              2871 	push	ar3
   A882 C0 04              2872 	push	ar4
   A884 74 08              2873 	mov	a,#0x08
   A886 C0 E0              2874 	push	acc
                           2875 ;	genIpush
   A888 74 F8              2876 	mov	a,#0xF8
   A88A C0 E0              2877 	push	acc
   A88C 74 FF              2878 	mov	a,#0xFF
   A88E C0 E0              2879 	push	acc
   A890 74 01              2880 	mov	a,#0x01
   A892 C0 E0              2881 	push	acc
                           2882 ;	Peephole 181	changed mov to clr
   A894 E4                 2883 	clr	a
   A895 C0 E0              2884 	push	acc
                           2885 ;	genCall
                           2886 ;	Peephole 182.a	used 16 bit load of DPTR
   A897 90 F0 45           2887 	mov	dptr,#_ft_buffer
   A89A 75 F0 00           2888 	mov	b,#0x00
   A89D 12 37 5B           2889 	lcall	_flash_read
   A8A0 E5 81              2890 	mov	a,sp
   A8A2 24 FB              2891 	add	a,#0xfb
   A8A4 F5 81              2892 	mov	sp,a
   A8A6 D0 04              2893 	pop	ar4
   A8A8 D0 03              2894 	pop	ar3
   A8AA D0 02              2895 	pop	ar2
                           2896 ;	../../Platform/nano/rf.c:726: for (i=0; i<8; i++)
                           2897 ;	genPlus
                           2898 ;     genPlusIncr
   A8AC 74 01              2899 	mov	a,#0x01
                           2900 ;	Peephole 236.a	used r2 instead of ar2
   A8AE 2A                 2901 	add	a,r2
   A8AF FD                 2902 	mov	r5,a
                           2903 ;	Peephole 181	changed mov to clr
   A8B0 E4                 2904 	clr	a
                           2905 ;	Peephole 236.b	used r3 instead of ar3
   A8B1 3B                 2906 	addc	a,r3
   A8B2 FE                 2907 	mov	r6,a
   A8B3 8C 07              2908 	mov	ar7,r4
                           2909 ;	genAssign
   A8B5 A8 10              2910 	mov	r0,_bp
   A8B7 08                 2911 	inc	r0
   A8B8 76 00              2912 	mov	@r0,#0x00
   A8BA                    2913 00105$:
                           2914 ;	genCmpLt
   A8BA A8 10              2915 	mov	r0,_bp
   A8BC 08                 2916 	inc	r0
                           2917 ;	genCmp
   A8BD B6 08 00           2918 	cjne	@r0,#0x08,00117$
   A8C0                    2919 00117$:
                           2920 ;	genIfxJump
                           2921 ;	Peephole 108.a	removed ljmp by inverse jump logic
   A8C0 50 45              2922 	jnc	00108$
                           2923 ;	Peephole 300	removed redundant label 00118$
                           2924 ;	../../Platform/nano/rf.c:728: address->address[7-i] = ft_buffer[i];
                           2925 ;	genIpush
   A8C2 C0 02              2926 	push	ar2
   A8C4 C0 03              2927 	push	ar3
   A8C6 C0 04              2928 	push	ar4
                           2929 ;	genMinus
   A8C8 A8 10              2930 	mov	r0,_bp
   A8CA 08                 2931 	inc	r0
   A8CB 74 07              2932 	mov	a,#0x07
   A8CD C3                 2933 	clr	c
   A8CE 96                 2934 	subb	a,@r0
                           2935 ;	genPlus
   A8CF A8 10              2936 	mov	r0,_bp
   A8D1 08                 2937 	inc	r0
   A8D2 08                 2938 	inc	r0
                           2939 ;	Peephole 236.a	used r5 instead of ar5
   A8D3 2D                 2940 	add	a,r5
   A8D4 F6                 2941 	mov	@r0,a
                           2942 ;	Peephole 236.g	used r6 instead of ar6
                           2943 ;	Peephole 240	use clr instead of addc a,#0
   A8D5 E4                 2944 	clr	a
   A8D6 3E                 2945 	addc	a,r6
   A8D7 08                 2946 	inc	r0
   A8D8 F6                 2947 	mov	@r0,a
   A8D9 08                 2948 	inc	r0
   A8DA A6 07              2949 	mov	@r0,ar7
                           2950 ;	genPlus
   A8DC A8 10              2951 	mov	r0,_bp
   A8DE 08                 2952 	inc	r0
   A8DF E6                 2953 	mov	a,@r0
   A8E0 24 45              2954 	add	a,#_ft_buffer
   A8E2 F5 82              2955 	mov	dpl,a
                           2956 ;	Peephole 181	changed mov to clr
   A8E4 E4                 2957 	clr	a
   A8E5 34 F0              2958 	addc	a,#(_ft_buffer >> 8)
   A8E7 F5 83              2959 	mov	dph,a
                           2960 ;	genPointerGet
                           2961 ;	genFarPointerGet
   A8E9 E0                 2962 	movx	a,@dptr
   A8EA FC                 2963 	mov	r4,a
                           2964 ;	genPointerSet
                           2965 ;	genGenPointerSet
   A8EB A8 10              2966 	mov	r0,_bp
   A8ED 08                 2967 	inc	r0
   A8EE 08                 2968 	inc	r0
   A8EF 86 82              2969 	mov	dpl,@r0
   A8F1 08                 2970 	inc	r0
   A8F2 86 83              2971 	mov	dph,@r0
   A8F4 08                 2972 	inc	r0
   A8F5 86 F0              2973 	mov	b,@r0
   A8F7 EC                 2974 	mov	a,r4
   A8F8 12 DF B7           2975 	lcall	__gptrput
                           2976 ;	../../Platform/nano/rf.c:726: for (i=0; i<8; i++)
                           2977 ;	genPlus
   A8FB A8 10              2978 	mov	r0,_bp
   A8FD 08                 2979 	inc	r0
                           2980 ;     genPlusIncr
   A8FE 06                 2981 	inc	@r0
                           2982 ;	genIpop
   A8FF D0 04              2983 	pop	ar4
   A901 D0 03              2984 	pop	ar3
   A903 D0 02              2985 	pop	ar2
                           2986 ;	Peephole 112.b	changed ljmp to sjmp
   A905 80 B3              2987 	sjmp	00105$
   A907                    2988 00108$:
                           2989 ;	../../Platform/nano/rf.c:730: address->addr_type = ADDR_802_15_4_LONG;
                           2990 ;	genPointerSet
                           2991 ;	genGenPointerSet
   A907 8A 82              2992 	mov	dpl,r2
   A909 8B 83              2993 	mov	dph,r3
   A90B 8C F0              2994 	mov	b,r4
                           2995 ;	../../Platform/nano/rf.c:731: if (stack_check_broadcast(address->address, ADDR_802_15_4_LONG) == pdTRUE)
                           2996 ;	genPlus
                           2997 ;     genPlusIncr
   A90D 74 01              2998 	mov	a,#0x01
   A90F 12 DF B7           2999 	lcall	__gptrput
                           3000 ;	Peephole 190	removed redundant mov
                           3001 ;	Peephole 236.a	used r2 instead of ar2
   A912 2A                 3002 	add	a,r2
   A913 FD                 3003 	mov	r5,a
                           3004 ;	Peephole 181	changed mov to clr
   A914 E4                 3005 	clr	a
                           3006 ;	Peephole 236.b	used r3 instead of ar3
   A915 3B                 3007 	addc	a,r3
   A916 FE                 3008 	mov	r6,a
   A917 8C 07              3009 	mov	ar7,r4
                           3010 ;	genIpush
   A919 C0 02              3011 	push	ar2
   A91B C0 03              3012 	push	ar3
   A91D C0 04              3013 	push	ar4
   A91F 74 01              3014 	mov	a,#0x01
   A921 C0 E0              3015 	push	acc
                           3016 ;	genCall
   A923 8D 82              3017 	mov	dpl,r5
   A925 8E 83              3018 	mov	dph,r6
   A927 8F F0              3019 	mov	b,r7
   A929 12 6B 44           3020 	lcall	_stack_check_broadcast
   A92C AD 82              3021 	mov	r5,dpl
   A92E 15 81              3022 	dec	sp
   A930 D0 04              3023 	pop	ar4
   A932 D0 03              3024 	pop	ar3
   A934 D0 02              3025 	pop	ar2
                           3026 ;	genCmpEq
                           3027 ;	gencjneshort
   A936 BD 01 02           3028 	cjne	r5,#0x01,00119$
   A939 80 03              3029 	sjmp	00120$
   A93B                    3030 00119$:
   A93B 02 A9 FA           3031 	ljmp	00102$
   A93E                    3032 00120$:
                           3033 ;	../../Platform/nano/rf.c:733: debug("No address in flash.\n");
                           3034 ;	genCall
                           3035 ;	Peephole 182.a	used 16 bit load of DPTR
   A93E 90 E8 42           3036 	mov	dptr,#__str_0
   A941 C0 02              3037 	push	ar2
   A943 C0 03              3038 	push	ar3
   A945 C0 04              3039 	push	ar4
   A947 12 38 E8           3040 	lcall	_debug_constant
   A94A D0 04              3041 	pop	ar4
   A94C D0 03              3042 	pop	ar3
   A94E D0 02              3043 	pop	ar2
                           3044 ;	../../Platform/nano/rf.c:734: address->address[0]=0x00;
                           3045 ;	genPlus
                           3046 ;     genPlusIncr
   A950 74 01              3047 	mov	a,#0x01
                           3048 ;	Peephole 236.a	used r2 instead of ar2
   A952 2A                 3049 	add	a,r2
   A953 FD                 3050 	mov	r5,a
                           3051 ;	Peephole 181	changed mov to clr
   A954 E4                 3052 	clr	a
                           3053 ;	Peephole 236.b	used r3 instead of ar3
   A955 3B                 3054 	addc	a,r3
   A956 FE                 3055 	mov	r6,a
   A957 8C 07              3056 	mov	ar7,r4
                           3057 ;	genIpush
   A959 C0 02              3058 	push	ar2
   A95B C0 03              3059 	push	ar3
   A95D C0 04              3060 	push	ar4
                           3061 ;	genCast
   A95F 8D 02              3062 	mov	ar2,r5
   A961 8E 03              3063 	mov	ar3,r6
   A963 8F 04              3064 	mov	ar4,r7
                           3065 ;	genPointerSet
                           3066 ;	genGenPointerSet
   A965 8A 82              3067 	mov	dpl,r2
   A967 8B 83              3068 	mov	dph,r3
   A969 8C F0              3069 	mov	b,r4
                           3070 ;	Peephole 181	changed mov to clr
   A96B E4                 3071 	clr	a
   A96C 12 DF B7           3072 	lcall	__gptrput
                           3073 ;	../../Platform/nano/rf.c:735: address->address[1]=0x00;
                           3074 ;	genPlus
                           3075 ;     genPlusIncr
   A96F 74 01              3076 	mov	a,#0x01
                           3077 ;	Peephole 236.a	used r5 instead of ar5
   A971 2D                 3078 	add	a,r5
   A972 FA                 3079 	mov	r2,a
                           3080 ;	Peephole 181	changed mov to clr
   A973 E4                 3081 	clr	a
                           3082 ;	Peephole 236.b	used r6 instead of ar6
   A974 3E                 3083 	addc	a,r6
   A975 FB                 3084 	mov	r3,a
   A976 8F 04              3085 	mov	ar4,r7
                           3086 ;	genPointerSet
                           3087 ;	genGenPointerSet
   A978 8A 82              3088 	mov	dpl,r2
   A97A 8B 83              3089 	mov	dph,r3
   A97C 8C F0              3090 	mov	b,r4
                           3091 ;	Peephole 181	changed mov to clr
   A97E E4                 3092 	clr	a
   A97F 12 DF B7           3093 	lcall	__gptrput
                           3094 ;	../../Platform/nano/rf.c:736: address->address[2]=0x00;
                           3095 ;	genPlus
                           3096 ;     genPlusIncr
   A982 74 02              3097 	mov	a,#0x02
                           3098 ;	Peephole 236.a	used r5 instead of ar5
   A984 2D                 3099 	add	a,r5
   A985 FA                 3100 	mov	r2,a
                           3101 ;	Peephole 181	changed mov to clr
   A986 E4                 3102 	clr	a
                           3103 ;	Peephole 236.b	used r6 instead of ar6
   A987 3E                 3104 	addc	a,r6
   A988 FB                 3105 	mov	r3,a
   A989 8F 04              3106 	mov	ar4,r7
                           3107 ;	genPointerSet
                           3108 ;	genGenPointerSet
   A98B 8A 82              3109 	mov	dpl,r2
   A98D 8B 83              3110 	mov	dph,r3
   A98F 8C F0              3111 	mov	b,r4
                           3112 ;	Peephole 181	changed mov to clr
   A991 E4                 3113 	clr	a
   A992 12 DF B7           3114 	lcall	__gptrput
                           3115 ;	../../Platform/nano/rf.c:737: address->address[3]=0x00;
                           3116 ;	genPlus
                           3117 ;     genPlusIncr
   A995 74 03              3118 	mov	a,#0x03
                           3119 ;	Peephole 236.a	used r5 instead of ar5
   A997 2D                 3120 	add	a,r5
   A998 FA                 3121 	mov	r2,a
                           3122 ;	Peephole 181	changed mov to clr
   A999 E4                 3123 	clr	a
                           3124 ;	Peephole 236.b	used r6 instead of ar6
   A99A 3E                 3125 	addc	a,r6
   A99B FB                 3126 	mov	r3,a
   A99C 8F 04              3127 	mov	ar4,r7
                           3128 ;	genPointerSet
                           3129 ;	genGenPointerSet
   A99E 8A 82              3130 	mov	dpl,r2
   A9A0 8B 83              3131 	mov	dph,r3
   A9A2 8C F0              3132 	mov	b,r4
                           3133 ;	Peephole 181	changed mov to clr
   A9A4 E4                 3134 	clr	a
   A9A5 12 DF B7           3135 	lcall	__gptrput
                           3136 ;	../../Platform/nano/rf.c:738: address->address[4]=0x00;
                           3137 ;	genPlus
                           3138 ;     genPlusIncr
   A9A8 74 04              3139 	mov	a,#0x04
                           3140 ;	Peephole 236.a	used r5 instead of ar5
   A9AA 2D                 3141 	add	a,r5
   A9AB FA                 3142 	mov	r2,a
                           3143 ;	Peephole 181	changed mov to clr
   A9AC E4                 3144 	clr	a
                           3145 ;	Peephole 236.b	used r6 instead of ar6
   A9AD 3E                 3146 	addc	a,r6
   A9AE FB                 3147 	mov	r3,a
   A9AF 8F 04              3148 	mov	ar4,r7
                           3149 ;	genPointerSet
                           3150 ;	genGenPointerSet
   A9B1 8A 82              3151 	mov	dpl,r2
   A9B3 8B 83              3152 	mov	dph,r3
   A9B5 8C F0              3153 	mov	b,r4
                           3154 ;	Peephole 181	changed mov to clr
   A9B7 E4                 3155 	clr	a
   A9B8 12 DF B7           3156 	lcall	__gptrput
                           3157 ;	../../Platform/nano/rf.c:739: address->address[5]=0x00;
                           3158 ;	genPlus
                           3159 ;     genPlusIncr
   A9BB 74 05              3160 	mov	a,#0x05
                           3161 ;	Peephole 236.a	used r5 instead of ar5
   A9BD 2D                 3162 	add	a,r5
   A9BE FA                 3163 	mov	r2,a
                           3164 ;	Peephole 181	changed mov to clr
   A9BF E4                 3165 	clr	a
                           3166 ;	Peephole 236.b	used r6 instead of ar6
   A9C0 3E                 3167 	addc	a,r6
   A9C1 FB                 3168 	mov	r3,a
   A9C2 8F 04              3169 	mov	ar4,r7
                           3170 ;	genPointerSet
                           3171 ;	genGenPointerSet
   A9C4 8A 82              3172 	mov	dpl,r2
   A9C6 8B 83              3173 	mov	dph,r3
   A9C8 8C F0              3174 	mov	b,r4
                           3175 ;	Peephole 181	changed mov to clr
   A9CA E4                 3176 	clr	a
   A9CB 12 DF B7           3177 	lcall	__gptrput
                           3178 ;	../../Platform/nano/rf.c:741: address->address[6]= (SHORT_ADDRESS & 0xff);
                           3179 ;	genPlus
                           3180 ;     genPlusIncr
   A9CE 74 06              3181 	mov	a,#0x06
                           3182 ;	Peephole 236.a	used r5 instead of ar5
   A9D0 2D                 3183 	add	a,r5
   A9D1 FA                 3184 	mov	r2,a
                           3185 ;	Peephole 181	changed mov to clr
   A9D2 E4                 3186 	clr	a
                           3187 ;	Peephole 236.b	used r6 instead of ar6
   A9D3 3E                 3188 	addc	a,r6
   A9D4 FB                 3189 	mov	r3,a
   A9D5 8F 04              3190 	mov	ar4,r7
                           3191 ;	genPointerSet
                           3192 ;	genGenPointerSet
   A9D7 8A 82              3193 	mov	dpl,r2
   A9D9 8B 83              3194 	mov	dph,r3
   A9DB 8C F0              3195 	mov	b,r4
   A9DD 74 44              3196 	mov	a,#0x44
   A9DF 12 DF B7           3197 	lcall	__gptrput
                           3198 ;	../../Platform/nano/rf.c:742: address->address[7]= (SHORT_ADDRESS >> 8);
                           3199 ;	genPlus
                           3200 ;     genPlusIncr
   A9E2 74 07              3201 	mov	a,#0x07
                           3202 ;	Peephole 236.a	used r5 instead of ar5
   A9E4 2D                 3203 	add	a,r5
   A9E5 FD                 3204 	mov	r5,a
                           3205 ;	Peephole 181	changed mov to clr
   A9E6 E4                 3206 	clr	a
                           3207 ;	Peephole 236.b	used r6 instead of ar6
   A9E7 3E                 3208 	addc	a,r6
   A9E8 FE                 3209 	mov	r6,a
                           3210 ;	genPointerSet
                           3211 ;	genGenPointerSet
   A9E9 8D 82              3212 	mov	dpl,r5
   A9EB 8E 83              3213 	mov	dph,r6
   A9ED 8F F0              3214 	mov	b,r7
   A9EF 74 44              3215 	mov	a,#0x44
   A9F1 12 DF B7           3216 	lcall	__gptrput
                           3217 ;	../../Platform/nano/rf.c:752: return pdTRUE;
                           3218 ;	genIpop
   A9F4 D0 04              3219 	pop	ar4
   A9F6 D0 03              3220 	pop	ar3
   A9F8 D0 02              3221 	pop	ar2
                           3222 ;	../../Platform/nano/rf.c:742: address->address[7]= (SHORT_ADDRESS >> 8);
   A9FA                    3223 00102$:
                           3224 ;	../../Platform/nano/rf.c:749: mac_set(address);
                           3225 ;	genCall
   A9FA 8A 82              3226 	mov	dpl,r2
   A9FC 8B 83              3227 	mov	dph,r3
   A9FE 8C F0              3228 	mov	b,r4
   AA00 12 38 5B           3229 	lcall	_mac_set
   AA03                    3230 00104$:
                           3231 ;	../../Platform/nano/rf.c:752: return pdTRUE;
                           3232 ;	genRet
   AA03 75 82 01           3233 	mov	dpl,#0x01
                           3234 ;	Peephole 300	removed redundant label 00109$
   AA06 85 10 81           3235 	mov	sp,_bp
   AA09 D0 10              3236 	pop	_bp
   AA0B 22                 3237 	ret
                           3238 ;------------------------------------------------------------
                           3239 ;Allocation info for local variables in function 'rf_rx_callback'
                           3240 ;------------------------------------------------------------
                           3241 ;param                     Allocated to registers 
                           3242 ;b                         Allocated to stack - offset 1
                           3243 ;i                         Allocated to stack - offset 4
                           3244 ;ptr                       Allocated to registers r2 r3 r4 
                           3245 ;tmp_16                    Allocated to registers r5 r6 
                           3246 ;sloc0                     Allocated to stack - offset 5
                           3247 ;------------------------------------------------------------
                           3248 ;	../../Platform/nano/rf.c:757: void rf_rx_callback(void *param)
                           3249 ;	-----------------------------------------
                           3250 ;	 function rf_rx_callback
                           3251 ;	-----------------------------------------
   AA0C                    3252 _rf_rx_callback:
   AA0C C0 10              3253 	push	_bp
                           3254 ;	peephole 177.h	optimized mov sequence
   AA0E E5 81              3255 	mov	a,sp
   AA10 F5 10              3256 	mov	_bp,a
   AA12 24 07              3257 	add	a,#0x07
   AA14 F5 81              3258 	mov	sp,a
                           3259 ;	../../Platform/nano/rf.c:766: b = stack_buffer_get(20);
                           3260 ;	genCall
                           3261 ;	Peephole 182.b	used 16 bit load of dptr
   AA16 90 00 14           3262 	mov	dptr,#0x0014
   AA19 12 5F CD           3263 	lcall	_stack_buffer_get
   AA1C AA 82              3264 	mov	r2,dpl
   AA1E AB 83              3265 	mov	r3,dph
   AA20 AC F0              3266 	mov	r4,b
                           3267 ;	genAssign
   AA22 A8 10              3268 	mov	r0,_bp
   AA24 08                 3269 	inc	r0
   AA25 A6 02              3270 	mov	@r0,ar2
   AA27 08                 3271 	inc	r0
   AA28 A6 03              3272 	mov	@r0,ar3
   AA2A 08                 3273 	inc	r0
   AA2B A6 04              3274 	mov	@r0,ar4
                           3275 ;	../../Platform/nano/rf.c:767: if (b)
                           3276 ;	genIfx
   AA2D A8 10              3277 	mov	r0,_bp
   AA2F 08                 3278 	inc	r0
   AA30 E6                 3279 	mov	a,@r0
   AA31 08                 3280 	inc	r0
   AA32 46                 3281 	orl	a,@r0
   AA33 08                 3282 	inc	r0
   AA34 46                 3283 	orl	a,@r0
                           3284 ;	genIfxJump
   AA35 70 03              3285 	jnz	00143$
   AA37 02 AC 46           3286 	ljmp	00125$
   AA3A                    3287 00143$:
                           3288 ;	../../Platform/nano/rf.c:769: b->options.type = BUFFER_DATA;
                           3289 ;	genPlus
   AA3A A8 10              3290 	mov	r0,_bp
   AA3C 08                 3291 	inc	r0
                           3292 ;     genPlusIncr
   AA3D 74 26              3293 	mov	a,#0x26
   AA3F 26                 3294 	add	a,@r0
   AA40 FD                 3295 	mov	r5,a
                           3296 ;	Peephole 181	changed mov to clr
   AA41 E4                 3297 	clr	a
   AA42 08                 3298 	inc	r0
   AA43 36                 3299 	addc	a,@r0
   AA44 FE                 3300 	mov	r6,a
   AA45 08                 3301 	inc	r0
   AA46 86 07              3302 	mov	ar7,@r0
                           3303 ;	genPointerSet
                           3304 ;	genGenPointerSet
   AA48 8D 82              3305 	mov	dpl,r5
   AA4A 8E 83              3306 	mov	dph,r6
   AA4C 8F F0              3307 	mov	b,r7
                           3308 ;	Peephole 181	changed mov to clr
   AA4E E4                 3309 	clr	a
   AA4F 12 DF B7           3310 	lcall	__gptrput
                           3311 ;	../../Platform/nano/rf.c:775: b->to = MODULE_RF_802_15_4;
                           3312 ;	genPlus
   AA52 A8 10              3313 	mov	r0,_bp
   AA54 08                 3314 	inc	r0
                           3315 ;     genPlusIncr
   AA55 74 1E              3316 	mov	a,#0x1E
   AA57 26                 3317 	add	a,@r0
   AA58 FD                 3318 	mov	r5,a
                           3319 ;	Peephole 181	changed mov to clr
   AA59 E4                 3320 	clr	a
   AA5A 08                 3321 	inc	r0
   AA5B 36                 3322 	addc	a,@r0
   AA5C FE                 3323 	mov	r6,a
   AA5D 08                 3324 	inc	r0
   AA5E 86 07              3325 	mov	ar7,@r0
                           3326 ;	genPointerSet
                           3327 ;	genGenPointerSet
   AA60 8D 82              3328 	mov	dpl,r5
   AA62 8E 83              3329 	mov	dph,r6
   AA64 8F F0              3330 	mov	b,r7
   AA66 74 08              3331 	mov	a,#0x08
   AA68 12 DF B7           3332 	lcall	__gptrput
                           3333 ;	../../Platform/nano/rf.c:777: b->dir = BUFFER_UP;
                           3334 ;	genPlus
   AA6B A8 10              3335 	mov	r0,_bp
   AA6D 08                 3336 	inc	r0
                           3337 ;     genPlusIncr
   AA6E 74 1F              3338 	mov	a,#0x1F
   AA70 26                 3339 	add	a,@r0
   AA71 FD                 3340 	mov	r5,a
                           3341 ;	Peephole 181	changed mov to clr
   AA72 E4                 3342 	clr	a
   AA73 08                 3343 	inc	r0
   AA74 36                 3344 	addc	a,@r0
   AA75 FE                 3345 	mov	r6,a
   AA76 08                 3346 	inc	r0
   AA77 86 07              3347 	mov	ar7,@r0
                           3348 ;	genPointerSet
                           3349 ;	genGenPointerSet
   AA79 8D 82              3350 	mov	dpl,r5
   AA7B 8E 83              3351 	mov	dph,r6
   AA7D 8F F0              3352 	mov	b,r7
                           3353 ;	Peephole 181	changed mov to clr
   AA7F E4                 3354 	clr	a
   AA80 12 DF B7           3355 	lcall	__gptrput
                           3356 ;	../../Platform/nano/rf.c:778: b->buf_ptr = 0;
                           3357 ;	genPlus
   AA83 A8 10              3358 	mov	r0,_bp
   AA85 08                 3359 	inc	r0
                           3360 ;     genPlusIncr
   AA86 74 20              3361 	mov	a,#0x20
   AA88 26                 3362 	add	a,@r0
   AA89 FD                 3363 	mov	r5,a
                           3364 ;	Peephole 181	changed mov to clr
   AA8A E4                 3365 	clr	a
   AA8B 08                 3366 	inc	r0
   AA8C 36                 3367 	addc	a,@r0
   AA8D FE                 3368 	mov	r6,a
   AA8E 08                 3369 	inc	r0
   AA8F 86 07              3370 	mov	ar7,@r0
                           3371 ;	genPointerSet
                           3372 ;	genGenPointerSet
   AA91 8D 82              3373 	mov	dpl,r5
   AA93 8E 83              3374 	mov	dph,r6
   AA95 8F F0              3375 	mov	b,r7
                           3376 ;	Peephole 181	changed mov to clr
   AA97 E4                 3377 	clr	a
   AA98 12 DF B7           3378 	lcall	__gptrput
   AA9B A3                 3379 	inc	dptr
                           3380 ;	Peephole 181	changed mov to clr
   AA9C E4                 3381 	clr	a
   AA9D 12 DF B7           3382 	lcall	__gptrput
                           3383 ;	../../Platform/nano/rf.c:780: tmp_16 = 0;
                           3384 ;	genAssign
   AAA0 7D 00              3385 	mov	r5,#0x00
   AAA2 7E 00              3386 	mov	r6,#0x00
                           3387 ;	../../Platform/nano/rf.c:781: if ((RFSTATUS & SFD) != 0)
                           3388 ;	genIpush
                           3389 ;	genAssign
   AAA4 90 DF 62           3390 	mov	dptr,#_RFSTATUS
   AAA7 E0                 3391 	movx	a,@dptr
   AAA8 FF                 3392 	mov	r7,a
   AAA9 A3                 3393 	inc	dptr
   AAAA E0                 3394 	movx	a,@dptr
   AAAB FA                 3395 	mov	r2,a
                           3396 ;	genAnd
   AAAC 53 07 02           3397 	anl	ar7,#0x02
   AAAF 7A 00              3398 	mov	r2,#0x00
                           3399 ;	genCmpEq
                           3400 ;	gencjne
                           3401 ;	gencjneshort
                           3402 ;	Peephole 241.c	optimized compare
   AAB1 E4                 3403 	clr	a
   AAB2 BF 00 04           3404 	cjne	r7,#0x00,00144$
   AAB5 BA 00 01           3405 	cjne	r2,#0x00,00144$
   AAB8 04                 3406 	inc	a
   AAB9                    3407 00144$:
                           3408 ;	Peephole 300	removed redundant label 00145$
                           3409 ;	genIpop
                           3410 ;	genIfx
                           3411 ;	genIfxJump
                           3412 ;	Peephole 108.b	removed ljmp by inverse jump logic
                           3413 ;	../../Platform/nano/rf.c:783: while( ((RFSTATUS & SFD) != 0) && (tmp_16++ > 1000))
                           3414 ;	genAssign
                           3415 ;	Peephole 256.c	loading r3 with zero from a
   AAB9 70 2F              3416 	jnz	00106$
                           3417 ;	Peephole 300	removed redundant label 00146$
   AABB FB                 3418 	mov	r3,a
                           3419 ;	Peephole 256.d	loading r4 with zero from a
   AABC FC                 3420 	mov	r4,a
   AABD                    3421 00102$:
                           3422 ;	genIpush
                           3423 ;	genAssign
   AABD 90 DF 62           3424 	mov	dptr,#_RFSTATUS
   AAC0 E0                 3425 	movx	a,@dptr
   AAC1 FF                 3426 	mov	r7,a
   AAC2 A3                 3427 	inc	dptr
   AAC3 E0                 3428 	movx	a,@dptr
   AAC4 FA                 3429 	mov	r2,a
                           3430 ;	genAnd
   AAC5 53 07 02           3431 	anl	ar7,#0x02
   AAC8 7A 00              3432 	mov	r2,#0x00
                           3433 ;	genCmpEq
                           3434 ;	gencjne
                           3435 ;	gencjneshort
                           3436 ;	Peephole 241.c	optimized compare
   AACA E4                 3437 	clr	a
   AACB BF 00 04           3438 	cjne	r7,#0x00,00147$
   AACE BA 00 01           3439 	cjne	r2,#0x00,00147$
   AAD1 04                 3440 	inc	a
   AAD2                    3441 00147$:
                           3442 ;	Peephole 300	removed redundant label 00148$
                           3443 ;	genIpop
                           3444 ;	genIfx
                           3445 ;	genIfxJump
                           3446 ;	Peephole 108.b	removed ljmp by inverse jump logic
   AAD2 70 12              3447 	jnz	00141$
                           3448 ;	Peephole 300	removed redundant label 00149$
                           3449 ;	genIpush
                           3450 ;	genAssign
   AAD4 8B 07              3451 	mov	ar7,r3
   AAD6 8C 02              3452 	mov	ar2,r4
                           3453 ;	genPlus
                           3454 ;     genPlusIncr
   AAD8 0B                 3455 	inc	r3
   AAD9 BB 00 01           3456 	cjne	r3,#0x00,00150$
   AADC 0C                 3457 	inc	r4
   AADD                    3458 00150$:
                           3459 ;	genCmpGt
                           3460 ;	genCmp
   AADD C3                 3461 	clr	c
   AADE 74 E8              3462 	mov	a,#0xE8
   AAE0 9F                 3463 	subb	a,r7
   AAE1 74 03              3464 	mov	a,#0x03
   AAE3 9A                 3465 	subb	a,r2
                           3466 ;	genIpop
                           3467 ;	genIfx
                           3468 ;	genIfxJump
                           3469 ;	Peephole 108.b	removed ljmp by inverse jump logic
                           3470 ;	Peephole 129.a	jump optimization
   AAE4 40 D7              3471 	jc	00102$
                           3472 ;	Peephole 300	removed redundant label 00151$
   AAE6                    3473 00141$:
                           3474 ;	genAssign
   AAE6 8B 05              3475 	mov	ar5,r3
   AAE8 8C 06              3476 	mov	ar6,r4
   AAEA                    3477 00106$:
                           3478 ;	../../Platform/nano/rf.c:787: if (tmp_16 <= 1000)
                           3479 ;	genCmpGt
                           3480 ;	genCmp
   AAEA C3                 3481 	clr	c
   AAEB 74 E8              3482 	mov	a,#0xE8
   AAED 9D                 3483 	subb	a,r5
   AAEE 74 03              3484 	mov	a,#0x03
   AAF0 9E                 3485 	subb	a,r6
                           3486 ;	genIfxJump
   AAF1 50 03              3487 	jnc	00152$
   AAF3 02 AC 20           3488 	ljmp	00120$
   AAF6                    3489 00152$:
                           3490 ;	../../Platform/nano/rf.c:789: if( ((RFSTATUS & FIFOP)) && (! ((RFSTATUS & FIFO)) ) ) 
                           3491 ;	genAssign
   AAF6 90 DF 62           3492 	mov	dptr,#_RFSTATUS
   AAF9 E0                 3493 	movx	a,@dptr
   AAFA FD                 3494 	mov	r5,a
   AAFB A3                 3495 	inc	dptr
   AAFC E0                 3496 	movx	a,@dptr
   AAFD FE                 3497 	mov	r6,a
                           3498 ;	genAnd
   AAFE ED                 3499 	mov	a,r5
                           3500 ;	genIfxJump
                           3501 ;	Peephole 108.d	removed ljmp by inverse jump logic
   AAFF 30 E2 18           3502 	jnb	acc.2,00116$
                           3503 ;	Peephole 300	removed redundant label 00153$
                           3504 ;	genAssign
   AB02 90 DF 62           3505 	mov	dptr,#_RFSTATUS
   AB05 E0                 3506 	movx	a,@dptr
   AB06 FD                 3507 	mov	r5,a
   AB07 A3                 3508 	inc	dptr
   AB08 E0                 3509 	movx	a,@dptr
   AB09 FE                 3510 	mov	r6,a
                           3511 ;	genAnd
   AB0A ED                 3512 	mov	a,r5
                           3513 ;	genIfxJump
                           3514 ;	Peephole 108.e	removed ljmp by inverse jump logic
   AB0B 20 E3 0C           3515 	jb	acc.3,00116$
                           3516 ;	Peephole 300	removed redundant label 00154$
                           3517 ;	../../Platform/nano/rf.c:794: rf_command(ISFLUSHRX);
                           3518 ;	genCall
   AB0E 75 82 E6           3519 	mov	dpl,#0xE6
   AB11 12 A0 6C           3520 	lcall	_rf_command
                           3521 ;	../../Platform/nano/rf.c:795: rf_rx_enable();
                           3522 ;	genCall
   AB14 12 A1 78           3523 	lcall	_rf_rx_enable
   AB17 02 AC 26           3524 	ljmp	00121$
   AB1A                    3525 00116$:
                           3526 ;	../../Platform/nano/rf.c:797: else if( ((RFSTATUS & FIFO)) && (! ((RFSTATUS & SFD)) ))
                           3527 ;	genAssign
   AB1A 90 DF 62           3528 	mov	dptr,#_RFSTATUS
   AB1D E0                 3529 	movx	a,@dptr
   AB1E FD                 3530 	mov	r5,a
   AB1F A3                 3531 	inc	dptr
   AB20 E0                 3532 	movx	a,@dptr
   AB21 FE                 3533 	mov	r6,a
                           3534 ;	genAnd
   AB22 ED                 3535 	mov	a,r5
                           3536 ;	genIfxJump
   AB23 20 E3 03           3537 	jb	acc.3,00155$
   AB26 02 AC 26           3538 	ljmp	00121$
   AB29                    3539 00155$:
                           3540 ;	genAssign
   AB29 90 DF 62           3541 	mov	dptr,#_RFSTATUS
   AB2C E0                 3542 	movx	a,@dptr
   AB2D FD                 3543 	mov	r5,a
   AB2E A3                 3544 	inc	dptr
   AB2F E0                 3545 	movx	a,@dptr
   AB30 FE                 3546 	mov	r6,a
                           3547 ;	genAnd
   AB31 ED                 3548 	mov	a,r5
                           3549 ;	genIfxJump
   AB32 30 E1 03           3550 	jnb	acc.1,00156$
   AB35 02 AC 26           3551 	ljmp	00121$
   AB38                    3552 00156$:
                           3553 ;	../../Platform/nano/rf.c:799: i = RFD & 0x7F;
                           3554 ;	genAnd
   AB38 E5 10              3555 	mov	a,_bp
   AB3A 24 04              3556 	add	a,#0x04
   AB3C F8                 3557 	mov	r0,a
   AB3D 74 7F              3558 	mov	a,#0x7F
   AB3F 55 D9              3559 	anl	a,_RFD
   AB41 F6                 3560 	mov	@r0,a
                           3561 ;	../../Platform/nano/rf.c:800: i -= 2;
                           3562 ;	genMinus
   AB42 E5 10              3563 	mov	a,_bp
   AB44 24 04              3564 	add	a,#0x04
   AB46 F8                 3565 	mov	r0,a
                           3566 ;	genMinusDec
   AB47 16                 3567 	dec	@r0
   AB48 16                 3568 	dec	@r0
                           3569 ;	../../Platform/nano/rf.c:802: b->buf_end = i;
                           3570 ;	genPlus
   AB49 A8 10              3571 	mov	r0,_bp
   AB4B 08                 3572 	inc	r0
                           3573 ;     genPlusIncr
   AB4C 74 22              3574 	mov	a,#0x22
   AB4E 26                 3575 	add	a,@r0
   AB4F FE                 3576 	mov	r6,a
                           3577 ;	Peephole 181	changed mov to clr
   AB50 E4                 3578 	clr	a
   AB51 08                 3579 	inc	r0
   AB52 36                 3580 	addc	a,@r0
   AB53 FF                 3581 	mov	r7,a
   AB54 08                 3582 	inc	r0
   AB55 86 05              3583 	mov	ar5,@r0
                           3584 ;	genCast
   AB57 E5 10              3585 	mov	a,_bp
   AB59 24 04              3586 	add	a,#0x04
   AB5B F8                 3587 	mov	r0,a
   AB5C 86 02              3588 	mov	ar2,@r0
   AB5E 7B 00              3589 	mov	r3,#0x00
                           3590 ;	genPointerSet
                           3591 ;	genGenPointerSet
   AB60 8E 82              3592 	mov	dpl,r6
   AB62 8F 83              3593 	mov	dph,r7
   AB64 8D F0              3594 	mov	b,r5
   AB66 EA                 3595 	mov	a,r2
   AB67 12 DF B7           3596 	lcall	__gptrput
   AB6A A3                 3597 	inc	dptr
   AB6B EB                 3598 	mov	a,r3
   AB6C 12 DF B7           3599 	lcall	__gptrput
                           3600 ;	../../Platform/nano/rf.c:803: ptr = b->buf;
                           3601 ;	genPlus
   AB6F A8 10              3602 	mov	r0,_bp
   AB71 08                 3603 	inc	r0
                           3604 ;     genPlusIncr
   AB72 74 2C              3605 	mov	a,#0x2C
   AB74 26                 3606 	add	a,@r0
   AB75 FA                 3607 	mov	r2,a
                           3608 ;	Peephole 181	changed mov to clr
   AB76 E4                 3609 	clr	a
   AB77 08                 3610 	inc	r0
   AB78 36                 3611 	addc	a,@r0
   AB79 FB                 3612 	mov	r3,a
   AB7A 08                 3613 	inc	r0
   AB7B 86 04              3614 	mov	ar4,@r0
                           3615 ;	../../Platform/nano/rf.c:805: while(i)
                           3616 ;	genAssign
                           3617 ;	genAssign
   AB7D E5 10              3618 	mov	a,_bp
   AB7F 24 04              3619 	add	a,#0x04
   AB81 F8                 3620 	mov	r0,a
   AB82 86 05              3621 	mov	ar5,@r0
   AB84                    3622 00107$:
                           3623 ;	genIfx
   AB84 ED                 3624 	mov	a,r5
                           3625 ;	genIfxJump
                           3626 ;	Peephole 108.c	removed ljmp by inverse jump logic
   AB85 60 13              3627 	jz	00109$
                           3628 ;	Peephole 300	removed redundant label 00157$
                           3629 ;	../../Platform/nano/rf.c:807: *ptr++ = RFD;			
                           3630 ;	genPointerSet
                           3631 ;	genGenPointerSet
   AB87 8A 82              3632 	mov	dpl,r2
   AB89 8B 83              3633 	mov	dph,r3
   AB8B 8C F0              3634 	mov	b,r4
   AB8D E5 D9              3635 	mov	a,_RFD
   AB8F 12 DF B7           3636 	lcall	__gptrput
   AB92 A3                 3637 	inc	dptr
   AB93 AA 82              3638 	mov	r2,dpl
   AB95 AB 83              3639 	mov	r3,dph
                           3640 ;	../../Platform/nano/rf.c:808: i--;
                           3641 ;	genMinus
                           3642 ;	genMinusDec
   AB97 1D                 3643 	dec	r5
                           3644 ;	Peephole 112.b	changed ljmp to sjmp
   AB98 80 EA              3645 	sjmp	00107$
   AB9A                    3646 00109$:
                           3647 ;	../../Platform/nano/rf.c:811: b->options.rf_dbm = ((int8_t) RFD) - 45;
                           3648 ;	genPlus
   AB9A A8 10              3649 	mov	r0,_bp
   AB9C 08                 3650 	inc	r0
                           3651 ;     genPlusIncr
   AB9D 74 26              3652 	mov	a,#0x26
   AB9F 26                 3653 	add	a,@r0
   ABA0 FA                 3654 	mov	r2,a
                           3655 ;	Peephole 181	changed mov to clr
   ABA1 E4                 3656 	clr	a
   ABA2 08                 3657 	inc	r0
   ABA3 36                 3658 	addc	a,@r0
   ABA4 FB                 3659 	mov	r3,a
   ABA5 08                 3660 	inc	r0
   ABA6 86 04              3661 	mov	ar4,@r0
                           3662 ;	genPlus
   ABA8 E5 10              3663 	mov	a,_bp
   ABAA 24 05              3664 	add	a,#0x05
   ABAC F8                 3665 	mov	r0,a
                           3666 ;     genPlusIncr
   ABAD 74 01              3667 	mov	a,#0x01
                           3668 ;	Peephole 236.a	used r2 instead of ar2
   ABAF 2A                 3669 	add	a,r2
   ABB0 F6                 3670 	mov	@r0,a
                           3671 ;	Peephole 181	changed mov to clr
   ABB1 E4                 3672 	clr	a
                           3673 ;	Peephole 236.b	used r3 instead of ar3
   ABB2 3B                 3674 	addc	a,r3
   ABB3 08                 3675 	inc	r0
   ABB4 F6                 3676 	mov	@r0,a
   ABB5 08                 3677 	inc	r0
   ABB6 A6 04              3678 	mov	@r0,ar4
                           3679 ;	genAssign
                           3680 ;	genMinus
                           3681 ;	peephole 177.g	optimized mov sequence
   ABB8 E5 D9              3682 	mov	a,_RFD
                           3683 ;	Peephole 215	removed some moves
   ABBA 24 D3              3684 	add	a,#0xd3
   ABBC FD                 3685 	mov	r5,a
                           3686 ;	genPointerSet
                           3687 ;	genGenPointerSet
   ABBD E5 10              3688 	mov	a,_bp
   ABBF 24 05              3689 	add	a,#0x05
   ABC1 F8                 3690 	mov	r0,a
   ABC2 86 82              3691 	mov	dpl,@r0
   ABC4 08                 3692 	inc	r0
   ABC5 86 83              3693 	mov	dph,@r0
   ABC7 08                 3694 	inc	r0
   ABC8 86 F0              3695 	mov	b,@r0
   ABCA ED                 3696 	mov	a,r5
   ABCB 12 DF B7           3697 	lcall	__gptrput
                           3698 ;	../../Platform/nano/rf.c:812: b->options.rf_lqi = RFD;
                           3699 ;	genPlus
                           3700 ;     genPlusIncr
   ABCE 74 02              3701 	mov	a,#0x02
                           3702 ;	Peephole 236.a	used r2 instead of ar2
   ABD0 2A                 3703 	add	a,r2
   ABD1 FA                 3704 	mov	r2,a
                           3705 ;	Peephole 181	changed mov to clr
   ABD2 E4                 3706 	clr	a
                           3707 ;	Peephole 236.b	used r3 instead of ar3
   ABD3 3B                 3708 	addc	a,r3
   ABD4 FB                 3709 	mov	r3,a
                           3710 ;	genPointerSet
                           3711 ;	genGenPointerSet
   ABD5 8A 82              3712 	mov	dpl,r2
   ABD7 8B 83              3713 	mov	dph,r3
   ABD9 8C F0              3714 	mov	b,r4
   ABDB E5 D9              3715 	mov	a,_RFD
   ABDD 12 DF B7           3716 	lcall	__gptrput
                           3717 ;	../../Platform/nano/rf.c:814: if (b->options.rf_lqi & 0x80)
                           3718 ;	genPointerGet
                           3719 ;	genGenPointerGet
   ABE0 8A 82              3720 	mov	dpl,r2
   ABE2 8B 83              3721 	mov	dph,r3
   ABE4 8C F0              3722 	mov	b,r4
   ABE6 12 E4 9F           3723 	lcall	__gptrget
                           3724 ;	genAnd
   ABE9 FD                 3725 	mov	r5,a
                           3726 ;	Peephole 105	removed redundant mov
                           3727 ;	genIfxJump
                           3728 ;	Peephole 108.d	removed ljmp by inverse jump logic
   ABEA 30 E7 2E           3729 	jnb	acc.7,00111$
                           3730 ;	Peephole 300	removed redundant label 00158$
                           3731 ;	../../Platform/nano/rf.c:816: b->options.rf_lqi &= ~0x80;
                           3732 ;	genPointerGet
                           3733 ;	genGenPointerGet
   ABED 8A 82              3734 	mov	dpl,r2
   ABEF 8B 83              3735 	mov	dph,r3
   ABF1 8C F0              3736 	mov	b,r4
   ABF3 12 E4 9F           3737 	lcall	__gptrget
   ABF6 FD                 3738 	mov	r5,a
                           3739 ;	genAnd
   ABF7 53 05 7F           3740 	anl	ar5,#0x7F
                           3741 ;	genPointerSet
                           3742 ;	genGenPointerSet
   ABFA 8A 82              3743 	mov	dpl,r2
   ABFC 8B 83              3744 	mov	dph,r3
   ABFE 8C F0              3745 	mov	b,r4
   AC00 ED                 3746 	mov	a,r5
   AC01 12 DF B7           3747 	lcall	__gptrput
                           3748 ;	../../Platform/nano/rf.c:817: stack_buffer_push(b);
                           3749 ;	genCall
   AC04 A8 10              3750 	mov	r0,_bp
   AC06 08                 3751 	inc	r0
   AC07 86 82              3752 	mov	dpl,@r0
   AC09 08                 3753 	inc	r0
   AC0A 86 83              3754 	mov	dph,@r0
   AC0C 08                 3755 	inc	r0
   AC0D 86 F0              3756 	mov	b,@r0
   AC0F 12 62 C4           3757 	lcall	_stack_buffer_push
                           3758 ;	../../Platform/nano/rf.c:818: b = 0;
                           3759 ;	genAssign
   AC12 A8 10              3760 	mov	r0,_bp
   AC14 08                 3761 	inc	r0
   AC15 E4                 3762 	clr	a
   AC16 F6                 3763 	mov	@r0,a
   AC17 08                 3764 	inc	r0
   AC18 F6                 3765 	mov	@r0,a
   AC19 08                 3766 	inc	r0
   AC1A F6                 3767 	mov	@r0,a
   AC1B                    3768 00111$:
                           3769 ;	../../Platform/nano/rf.c:826: rf_rx_enable();
                           3770 ;	genCall
   AC1B 12 A1 78           3771 	lcall	_rf_rx_enable
                           3772 ;	Peephole 112.b	changed ljmp to sjmp
   AC1E 80 06              3773 	sjmp	00121$
   AC20                    3774 00120$:
                           3775 ;	../../Platform/nano/rf.c:831: rf_command(ISFLUSHRX);
                           3776 ;	genCall
   AC20 75 82 E6           3777 	mov	dpl,#0xE6
   AC23 12 A0 6C           3778 	lcall	_rf_command
   AC26                    3779 00121$:
                           3780 ;	../../Platform/nano/rf.c:833: if (b != 0) stack_buffer_free(b);
                           3781 ;	genCmpEq
   AC26 A8 10              3782 	mov	r0,_bp
   AC28 08                 3783 	inc	r0
                           3784 ;	gencjneshort
   AC29 B6 00 0A           3785 	cjne	@r0,#0x00,00159$
   AC2C 08                 3786 	inc	r0
   AC2D B6 00 06           3787 	cjne	@r0,#0x00,00159$
   AC30 08                 3788 	inc	r0
   AC31 B6 00 02           3789 	cjne	@r0,#0x00,00159$
                           3790 ;	Peephole 112.b	changed ljmp to sjmp
   AC34 80 16              3791 	sjmp	00127$
   AC36                    3792 00159$:
                           3793 ;	genCall
   AC36 A8 10              3794 	mov	r0,_bp
   AC38 08                 3795 	inc	r0
   AC39 86 82              3796 	mov	dpl,@r0
   AC3B 08                 3797 	inc	r0
   AC3C 86 83              3798 	mov	dph,@r0
   AC3E 08                 3799 	inc	r0
   AC3F 86 F0              3800 	mov	b,@r0
   AC41 12 61 FA           3801 	lcall	_stack_buffer_free
                           3802 ;	Peephole 112.b	changed ljmp to sjmp
   AC44 80 06              3803 	sjmp	00127$
   AC46                    3804 00125$:
                           3805 ;	../../Platform/nano/rf.c:837: rf_command(ISFLUSHRX);
                           3806 ;	genCall
   AC46 75 82 E6           3807 	mov	dpl,#0xE6
   AC49 12 A0 6C           3808 	lcall	_rf_command
   AC4C                    3809 00127$:
   AC4C 85 10 81           3810 	mov	sp,_bp
   AC4F D0 10              3811 	pop	_bp
   AC51 22                 3812 	ret
                           3813 ;------------------------------------------------------------
                           3814 ;Allocation info for local variables in function 'rf_ISR'
                           3815 ;------------------------------------------------------------
                           3816 ;prev_task                 Allocated to registers r2 
                           3817 ;event                     Allocated to stack - offset 1
                           3818 ;------------------------------------------------------------
                           3819 ;	../../Platform/nano/rf.c:848: void rf_ISR( void ) interrupt (RF_VECTOR)
                           3820 ;	-----------------------------------------
                           3821 ;	 function rf_ISR
                           3822 ;	-----------------------------------------
   AC52                    3823 _rf_ISR:
   AC52 C0 E0              3824 	push	acc
   AC54 C0 F0              3825 	push	b
   AC56 C0 82              3826 	push	dpl
   AC58 C0 83              3827 	push	dph
   AC5A C0 02              3828 	push	(0+2)
   AC5C C0 03              3829 	push	(0+3)
   AC5E C0 04              3830 	push	(0+4)
   AC60 C0 05              3831 	push	(0+5)
   AC62 C0 06              3832 	push	(0+6)
   AC64 C0 07              3833 	push	(0+7)
   AC66 C0 00              3834 	push	(0+0)
   AC68 C0 01              3835 	push	(0+1)
   AC6A C0 20              3836 	push	bits
   AC6C C0 D0              3837 	push	psw
   AC6E 75 D0 00           3838 	mov	psw,#0x00
   AC71 C0 10              3839 	push	_bp
                           3840 ;	peephole 177.h	optimized mov sequence
   AC73 E5 81              3841 	mov	a,sp
   AC75 F5 10              3842 	mov	_bp,a
   AC77 24 05              3843 	add	a,#0x05
   AC79 F5 81              3844 	mov	sp,a
                           3845 ;	../../Platform/nano/rf.c:852: if ((RFIF & IRQ_SFD) && (tx_flags == 0))
                           3846 ;	genAnd
   AC7B E5 E9              3847 	mov	a,_RFIF
                           3848 ;	genIfxJump
                           3849 ;	Peephole 108.d	removed ljmp by inverse jump logic
   AC7D 30 E4 4F           3850 	jnb	acc.4,00104$
                           3851 ;	Peephole 300	removed redundant label 00114$
                           3852 ;	genAssign
   AC80 90 F0 35           3853 	mov	dptr,#_tx_flags
   AC83 E0                 3854 	movx	a,@dptr
                           3855 ;	genIfx
   AC84 FA                 3856 	mov	r2,a
                           3857 ;	Peephole 105	removed redundant mov
                           3858 ;	genIfxJump
                           3859 ;	Peephole 108.b	removed ljmp by inverse jump logic
   AC85 70 48              3860 	jnz	00104$
                           3861 ;	Peephole 300	removed redundant label 00115$
                           3862 ;	../../Platform/nano/rf.c:855: event.process = rf_rx_callback;
                           3863 ;	genAddrOf
   AC87 E5 10              3864 	mov	a,_bp
   AC89 24 01              3865 	add	a,#0x01
                           3866 ;	genPointerSet
                           3867 ;	genNearPointerSet
                           3868 ;	Peephole 239	used a instead of acc
   AC8B F8                 3869 	mov	r0,a
   AC8C 76 0C              3870 	mov	@r0,#_rf_rx_callback
   AC8E 08                 3871 	inc	r0
   AC8F 76 AA              3872 	mov	@r0,#(_rf_rx_callback >> 8)
                           3873 ;	../../Platform/nano/rf.c:856: event.param = (void *) 0;
                           3874 ;	genAddrOf
                           3875 ;	Peephole 212	reduced add sequence to inc
   AC91 AA 10              3876 	mov	r2,_bp
   AC93 0A                 3877 	inc	r2
                           3878 ;	genPlus
                           3879 ;     genPlusIncr
   AC94 74 02              3880 	mov	a,#0x02
                           3881 ;	Peephole 236.a	used r2 instead of ar2
   AC96 2A                 3882 	add	a,r2
                           3883 ;	genPointerSet
                           3884 ;	genNearPointerSet
                           3885 ;	Peephole 239	used a instead of acc
   AC97 F8                 3886 	mov	r0,a
   AC98 76 00              3887 	mov	@r0,#0x00
   AC9A 08                 3888 	inc	r0
   AC9B 76 00              3889 	mov	@r0,#0x00
   AC9D 08                 3890 	inc	r0
   AC9E 76 00              3891 	mov	@r0,#0x00
                           3892 ;	../../Platform/nano/rf.c:858: prev_task = xQueueSendFromISR(events, &event, prev_task);
                           3893 ;	genAssign
                           3894 ;	genCast
   ACA0 7B 00              3895 	mov	r3,#0x00
   ACA2 7C 40              3896 	mov	r4,#0x40
                           3897 ;	genAssign
   ACA4 90 F0 DA           3898 	mov	dptr,#_events
   ACA7 E0                 3899 	movx	a,@dptr
   ACA8 FD                 3900 	mov	r5,a
   ACA9 A3                 3901 	inc	dptr
   ACAA E0                 3902 	movx	a,@dptr
   ACAB FE                 3903 	mov	r6,a
   ACAC A3                 3904 	inc	dptr
   ACAD E0                 3905 	movx	a,@dptr
   ACAE FF                 3906 	mov	r7,a
                           3907 ;	genIpush
                           3908 ;	Peephole 181	changed mov to clr
   ACAF E4                 3909 	clr	a
   ACB0 C0 E0              3910 	push	acc
                           3911 ;	genIpush
   ACB2 C0 02              3912 	push	ar2
   ACB4 C0 03              3913 	push	ar3
   ACB6 C0 04              3914 	push	ar4
                           3915 ;	genCall
   ACB8 8D 82              3916 	mov	dpl,r5
   ACBA 8E 83              3917 	mov	dph,r6
   ACBC 8F F0              3918 	mov	b,r7
   ACBE 12 21 24           3919 	lcall	_xQueueSendFromISR
   ACC1 AA 82              3920 	mov	r2,dpl
   ACC3 E5 81              3921 	mov	a,sp
   ACC5 24 FC              3922 	add	a,#0xfc
   ACC7 F5 81              3923 	mov	sp,a
                           3924 ;	genAssign
                           3925 ;	../../Platform/nano/rf.c:859: if (prev_task == pdTRUE)
                           3926 ;	genCmpEq
                           3927 ;	gencjneshort
                           3928 ;	Peephole 112.b	changed ljmp to sjmp
                           3929 ;	Peephole 198.b	optimized misc jump sequence
   ACC9 BA 01 03           3930 	cjne	r2,#0x01,00104$
                           3931 ;	Peephole 200.b	removed redundant sjmp
                           3932 ;	Peephole 300	removed redundant label 00116$
                           3933 ;	Peephole 300	removed redundant label 00117$
                           3934 ;	../../Platform/nano/rf.c:861: taskYIELD();
                           3935 ;	genCall
   ACCC 12 33 E8           3936 	lcall	_vPortYield
   ACCF                    3937 00104$:
                           3938 ;	../../Platform/nano/rf.c:864: if (RFIF & IRQ_SFD)
                           3939 ;	genAnd
   ACCF E5 E9              3940 	mov	a,_RFIF
                           3941 ;	genIfxJump
                           3942 ;	Peephole 108.d	removed ljmp by inverse jump logic
   ACD1 30 E4 03           3943 	jnb	acc.4,00107$
                           3944 ;	Peephole 300	removed redundant label 00118$
                           3945 ;	../../Platform/nano/rf.c:866: RFIF &= ~IRQ_SFD;
                           3946 ;	genAnd
   ACD4 53 E9 EF           3947 	anl	_RFIF,#0xEF
   ACD7                    3948 00107$:
                           3949 ;	../../Platform/nano/rf.c:869: S1CON &= ~(RFIF_0 | RFIF_1);
                           3950 ;	genAnd
   ACD7 53 9B FC           3951 	anl	_S1CON,#0xFC
                           3952 ;	Peephole 300	removed redundant label 00108$
   ACDA 85 10 81           3953 	mov	sp,_bp
   ACDD D0 10              3954 	pop	_bp
   ACDF D0 D0              3955 	pop	psw
   ACE1 D0 20              3956 	pop	bits
   ACE3 D0 01              3957 	pop	(0+1)
   ACE5 D0 00              3958 	pop	(0+0)
   ACE7 D0 07              3959 	pop	(0+7)
   ACE9 D0 06              3960 	pop	(0+6)
   ACEB D0 05              3961 	pop	(0+5)
   ACED D0 04              3962 	pop	(0+4)
   ACEF D0 03              3963 	pop	(0+3)
   ACF1 D0 02              3964 	pop	(0+2)
   ACF3 D0 83              3965 	pop	dph
   ACF5 D0 82              3966 	pop	dpl
   ACF7 D0 F0              3967 	pop	b
   ACF9 D0 E0              3968 	pop	acc
   ACFB 32                 3969 	reti
                           3970 ;------------------------------------------------------------
                           3971 ;Allocation info for local variables in function 'rf_error_ISR'
                           3972 ;------------------------------------------------------------
                           3973 ;------------------------------------------------------------
                           3974 ;	../../Platform/nano/rf.c:879: void rf_error_ISR( void ) interrupt (RFERR_VECTOR)
                           3975 ;	-----------------------------------------
                           3976 ;	 function rf_error_ISR
                           3977 ;	-----------------------------------------
   ACFC                    3978 _rf_error_ISR:
                           3979 ;	../../Platform/nano/rf.c:881: TCON_RFERRIF = 0;
                           3980 ;	genAssign
   ACFC C2 89              3981 	clr	_TCON_RFERRIF
                           3982 ;	Peephole 300	removed redundant label 00101$
   ACFE 32                 3983 	reti
                           3984 ;	eliminated unneeded push/pop psw
                           3985 ;	eliminated unneeded push/pop dpl
                           3986 ;	eliminated unneeded push/pop dph
                           3987 ;	eliminated unneeded push/pop b
                           3988 ;	eliminated unneeded push/pop acc
                           3989 	.area CSEG    (CODE)
                           3990 	.area CONST   (CODE)
   E842                    3991 __str_0:
   E842 4E 6F 20 61 64 64  3992 	.ascii "No address in flash."
        72 65 73 73 20 69
        6E 20 66 6C 61 73
        68 2E
   E856 0A                 3993 	.db 0x0A
   E857 00                 3994 	.db 0x00
                           3995 	.area XINIT   (CODE)
   E8EE                    3996 __xinit__rf_lock:
                           3997 ; generic printIvalPtr
   E8EE 00 00 00           3998 	.byte #0x00,#0x00,#0x00
   E8F1                    3999 __xinit__rf_initialized:
   E8F1 00                 4000 	.db #0x00
