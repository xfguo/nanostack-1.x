                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Nov 10 2006)
                              4 ; This file generated Fri Feb  1 13:33:37 2008
                              5 ;--------------------------------------------------------
                              6 	.module mac
                              7 	.optsdcc -mmcs51 --model-large
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _IRCON2_P2IF
                             13 	.globl _IRCON2_UTX0IF
                             14 	.globl _IRCON2_UTX1IF
                             15 	.globl _IRCON2_P1IF
                             16 	.globl _IRCON2_WDTIF
                             17 	.globl _CY
                             18 	.globl _AC
                             19 	.globl _F0
                             20 	.globl _RS1
                             21 	.globl _RS0
                             22 	.globl _OV
                             23 	.globl _F1
                             24 	.globl _P
                             25 	.globl _IRCON_DMAIF
                             26 	.globl _IRCON_T1IF
                             27 	.globl _IRCON_T2IF
                             28 	.globl _IRCON_T3IF
                             29 	.globl _IRCON_T4IF
                             30 	.globl _IRCON_P0IF
                             31 	.globl _IRCON_STIF
                             32 	.globl _IEN1_DMAIE
                             33 	.globl _IEN1_T1IE
                             34 	.globl _IEN1_T2IE
                             35 	.globl _IEN1_T3IE
                             36 	.globl _IEN1_T4IE
                             37 	.globl _IEN1_P0IE
                             38 	.globl _IEN0_RFERRIE
                             39 	.globl _IEN0_ADCIE
                             40 	.globl _IEN0_URX0IE
                             41 	.globl _IEN0_URX1IE
                             42 	.globl _IEN0_ENCIE
                             43 	.globl _IEN0_STIE
                             44 	.globl _IEN0_EA
                             45 	.globl _EA
                             46 	.globl _P2_4
                             47 	.globl _P2_3
                             48 	.globl _P2_2
                             49 	.globl _P2_1
                             50 	.globl _P2_0
                             51 	.globl _S0CON_ENCIF_0
                             52 	.globl _S0CON_ENCIF_1
                             53 	.globl _P1_7
                             54 	.globl _P1_6
                             55 	.globl _P1_5
                             56 	.globl _P1_4
                             57 	.globl _P1_3
                             58 	.globl _P1_2
                             59 	.globl _P1_1
                             60 	.globl _P1_0
                             61 	.globl _TCON_IT0
                             62 	.globl _TCON_RFERRIF
                             63 	.globl _TCON_IT1
                             64 	.globl _TCON_URX0IF
                             65 	.globl _TCON_ADCIF
                             66 	.globl _TCON_URX1IF
                             67 	.globl _P0_0
                             68 	.globl _P0_1
                             69 	.globl _P0_2
                             70 	.globl _P0_3
                             71 	.globl _P0_4
                             72 	.globl _P0_5
                             73 	.globl _P0_6
                             74 	.globl _P0_7
                             75 	.globl _P2DIR
                             76 	.globl _P1DIR
                             77 	.globl _P0DIR
                             78 	.globl _U1GCR
                             79 	.globl _U1UCR
                             80 	.globl _U1BAUD
                             81 	.globl _U1BUF
                             82 	.globl _U1CSR
                             83 	.globl _P2INP
                             84 	.globl _P1INP
                             85 	.globl _P2SEL
                             86 	.globl _P1SEL
                             87 	.globl _P0SEL
                             88 	.globl _ADCCFG
                             89 	.globl _PERCFG
                             90 	.globl _B
                             91 	.globl _T4CC1
                             92 	.globl _T4CCTL1
                             93 	.globl _T4CC0
                             94 	.globl _T4CCTL0
                             95 	.globl _T4CTL
                             96 	.globl _T4CNT
                             97 	.globl _RFIF
                             98 	.globl _IRCON2
                             99 	.globl _T1CCTL2
                            100 	.globl _T1CCTL1
                            101 	.globl _T1CCTL0
                            102 	.globl _T1CTL
                            103 	.globl _T1CNTH
                            104 	.globl _T1CNTL
                            105 	.globl _RFST
                            106 	.globl _ACC
                            107 	.globl _T1CC2H
                            108 	.globl _T1CC2L
                            109 	.globl _T1CC1H
                            110 	.globl _T1CC1L
                            111 	.globl _T1CC0H
                            112 	.globl _T1CC0L
                            113 	.globl _RFD
                            114 	.globl _TIMIF
                            115 	.globl _DMAREQ
                            116 	.globl _DMAARM
                            117 	.globl _DMA0CFGH
                            118 	.globl _DMA0CFGL
                            119 	.globl _DMA1CFGH
                            120 	.globl _DMA1CFGL
                            121 	.globl _DMAIRQ
                            122 	.globl _PSW
                            123 	.globl _T3CC1
                            124 	.globl _T3CCTL1
                            125 	.globl _T3CC0
                            126 	.globl _T3CCTL0
                            127 	.globl _T3CTL
                            128 	.globl _T3CNT
                            129 	.globl _WDCTL
                            130 	.globl _T2CON
                            131 	.globl _MEMCTR
                            132 	.globl _CLKCON
                            133 	.globl _U0GCR
                            134 	.globl _U0UCR
                            135 	.globl _T2CNF
                            136 	.globl _U0BAUD
                            137 	.globl _U0BUF
                            138 	.globl _IRCON
                            139 	.globl _SLEEP
                            140 	.globl _RNDH
                            141 	.globl _RNDL
                            142 	.globl _ADCH
                            143 	.globl _ADCL
                            144 	.globl _IP1
                            145 	.globl _IEN1
                            146 	.globl _RCCTL
                            147 	.globl _ADCCON3
                            148 	.globl _ADCCON2
                            149 	.globl _ADCCON1
                            150 	.globl _ENCCS
                            151 	.globl _ENCDO
                            152 	.globl _ENCDI
                            153 	.globl _FWDATA
                            154 	.globl _FCTL
                            155 	.globl _FADDRH
                            156 	.globl _FADDRL
                            157 	.globl _FWT
                            158 	.globl _IP0
                            159 	.globl _IEN0
                            160 	.globl _IE
                            161 	.globl _T2THD
                            162 	.globl _T2TLD
                            163 	.globl _T2CAPHPH
                            164 	.globl _T2CAPLPL
                            165 	.globl _T2OF2
                            166 	.globl _T2OF1
                            167 	.globl _T2OF0
                            168 	.globl _P2
                            169 	.globl _T2PEROF2
                            170 	.globl _T2PEROF1
                            171 	.globl _T2PEROF0
                            172 	.globl _S1CON
                            173 	.globl _IEN2
                            174 	.globl _HSRC
                            175 	.globl _S0CON
                            176 	.globl _ST2
                            177 	.globl _ST1
                            178 	.globl _ST0
                            179 	.globl _T2CMP
                            180 	.globl __XPAGE
                            181 	.globl _DPS
                            182 	.globl _RFIM
                            183 	.globl _P1
                            184 	.globl _P0INP
                            185 	.globl _P1IEN
                            186 	.globl _PICTL
                            187 	.globl _P2IFG
                            188 	.globl _P1IFG
                            189 	.globl _P0IFG
                            190 	.globl _TCON
                            191 	.globl _PCON
                            192 	.globl _U0CSR
                            193 	.globl _DPH1
                            194 	.globl _DPL1
                            195 	.globl _DPH0
                            196 	.globl _DPL0
                            197 	.globl _SP
                            198 	.globl _P0
                            199 	.globl _mac_long
                            200 	.globl _mac_short
                            201 	.globl _RFD_SHADOW
                            202 	.globl _RFSTATUS
                            203 	.globl _CHIPID
                            204 	.globl _CHVER
                            205 	.globl _FSMTC1
                            206 	.globl _RXFIFOCNT
                            207 	.globl _IOCFG3
                            208 	.globl _IOCFG2
                            209 	.globl _IOCFG1
                            210 	.globl _IOCFG0
                            211 	.globl _SHORTADDRL
                            212 	.globl _SHORTADDRH
                            213 	.globl _PANIDL
                            214 	.globl _PANIDH
                            215 	.globl _IEEE_ADDR7
                            216 	.globl _IEEE_ADDR6
                            217 	.globl _IEEE_ADDR5
                            218 	.globl _IEEE_ADDR4
                            219 	.globl _IEEE_ADDR3
                            220 	.globl _IEEE_ADDR2
                            221 	.globl _IEEE_ADDR1
                            222 	.globl _IEEE_ADDR0
                            223 	.globl _DACTSTL
                            224 	.globl _DACTSTH
                            225 	.globl _ADCTSTL
                            226 	.globl _ADCTSTH
                            227 	.globl _FSMSTATE
                            228 	.globl _AGCCTRLL
                            229 	.globl _AGCCTRLH
                            230 	.globl _MANORL
                            231 	.globl _MANORH
                            232 	.globl _MANANDL
                            233 	.globl _MANANDH
                            234 	.globl _FSMTCL
                            235 	.globl _FSMTCH
                            236 	.globl _RFPWR
                            237 	.globl _CSPT
                            238 	.globl _CSPCTRL
                            239 	.globl _CSPZ
                            240 	.globl _CSPY
                            241 	.globl _CSPX
                            242 	.globl _FSCTRLL
                            243 	.globl _FSCTRLH
                            244 	.globl _RXCTRL1L
                            245 	.globl _RXCTRL1H
                            246 	.globl _RXCTRL0L
                            247 	.globl _RXCTRL0H
                            248 	.globl _TXCTRLL
                            249 	.globl _TXCTRLH
                            250 	.globl _SYNCWORDL
                            251 	.globl _SYNCWORDH
                            252 	.globl _RSSIL
                            253 	.globl _RSSIH
                            254 	.globl _MDMCTRL1L
                            255 	.globl _MDMCTRL1H
                            256 	.globl _MDMCTRL0L
                            257 	.globl _MDMCTRL0H
                            258 	.globl _mac_get
                            259 	.globl _mac_set
                            260 ;--------------------------------------------------------
                            261 ; special function registers
                            262 ;--------------------------------------------------------
                            263 	.area RSEG    (DATA)
                    0080    264 _P0	=	0x0080
                    0081    265 _SP	=	0x0081
                    0082    266 _DPL0	=	0x0082
                    0083    267 _DPH0	=	0x0083
                    0084    268 _DPL1	=	0x0084
                    0085    269 _DPH1	=	0x0085
                    0086    270 _U0CSR	=	0x0086
                    0087    271 _PCON	=	0x0087
                    0088    272 _TCON	=	0x0088
                    0089    273 _P0IFG	=	0x0089
                    008A    274 _P1IFG	=	0x008a
                    008B    275 _P2IFG	=	0x008b
                    008C    276 _PICTL	=	0x008c
                    008D    277 _P1IEN	=	0x008d
                    008F    278 _P0INP	=	0x008f
                    0090    279 _P1	=	0x0090
                    0091    280 _RFIM	=	0x0091
                    0092    281 _DPS	=	0x0092
                    0093    282 __XPAGE	=	0x0093
                    0094    283 _T2CMP	=	0x0094
                    0095    284 _ST0	=	0x0095
                    0096    285 _ST1	=	0x0096
                    0097    286 _ST2	=	0x0097
                    0098    287 _S0CON	=	0x0098
                    0099    288 _HSRC	=	0x0099
                    009A    289 _IEN2	=	0x009a
                    009B    290 _S1CON	=	0x009b
                    009C    291 _T2PEROF0	=	0x009c
                    009D    292 _T2PEROF1	=	0x009d
                    009E    293 _T2PEROF2	=	0x009e
                    00A0    294 _P2	=	0x00a0
                    00A1    295 _T2OF0	=	0x00a1
                    00A2    296 _T2OF1	=	0x00a2
                    00A3    297 _T2OF2	=	0x00a3
                    00A4    298 _T2CAPLPL	=	0x00a4
                    00A5    299 _T2CAPHPH	=	0x00a5
                    00A6    300 _T2TLD	=	0x00a6
                    00A7    301 _T2THD	=	0x00a7
                    00A8    302 _IE	=	0x00a8
                    00A8    303 _IEN0	=	0x00a8
                    00A9    304 _IP0	=	0x00a9
                    00AB    305 _FWT	=	0x00ab
                    00AC    306 _FADDRL	=	0x00ac
                    00AD    307 _FADDRH	=	0x00ad
                    00AE    308 _FCTL	=	0x00ae
                    00AF    309 _FWDATA	=	0x00af
                    00B1    310 _ENCDI	=	0x00b1
                    00B2    311 _ENCDO	=	0x00b2
                    00B3    312 _ENCCS	=	0x00b3
                    00B4    313 _ADCCON1	=	0x00b4
                    00B5    314 _ADCCON2	=	0x00b5
                    00B6    315 _ADCCON3	=	0x00b6
                    00B7    316 _RCCTL	=	0x00b7
                    00B8    317 _IEN1	=	0x00b8
                    00B9    318 _IP1	=	0x00b9
                    00BA    319 _ADCL	=	0x00ba
                    00BB    320 _ADCH	=	0x00bb
                    00BC    321 _RNDL	=	0x00bc
                    00BD    322 _RNDH	=	0x00bd
                    00BE    323 _SLEEP	=	0x00be
                    00C0    324 _IRCON	=	0x00c0
                    00C1    325 _U0BUF	=	0x00c1
                    00C2    326 _U0BAUD	=	0x00c2
                    00C3    327 _T2CNF	=	0x00c3
                    00C4    328 _U0UCR	=	0x00c4
                    00C5    329 _U0GCR	=	0x00c5
                    00C6    330 _CLKCON	=	0x00c6
                    00C7    331 _MEMCTR	=	0x00c7
                    00C8    332 _T2CON	=	0x00c8
                    00C9    333 _WDCTL	=	0x00c9
                    00CA    334 _T3CNT	=	0x00ca
                    00CB    335 _T3CTL	=	0x00cb
                    00CC    336 _T3CCTL0	=	0x00cc
                    00CD    337 _T3CC0	=	0x00cd
                    00CE    338 _T3CCTL1	=	0x00ce
                    00CF    339 _T3CC1	=	0x00cf
                    00D0    340 _PSW	=	0x00d0
                    00D1    341 _DMAIRQ	=	0x00d1
                    00D2    342 _DMA1CFGL	=	0x00d2
                    00D3    343 _DMA1CFGH	=	0x00d3
                    00D4    344 _DMA0CFGL	=	0x00d4
                    00D5    345 _DMA0CFGH	=	0x00d5
                    00D6    346 _DMAARM	=	0x00d6
                    00D7    347 _DMAREQ	=	0x00d7
                    00D8    348 _TIMIF	=	0x00d8
                    00D9    349 _RFD	=	0x00d9
                    00DA    350 _T1CC0L	=	0x00da
                    00DB    351 _T1CC0H	=	0x00db
                    00DC    352 _T1CC1L	=	0x00dc
                    00DD    353 _T1CC1H	=	0x00dd
                    00DE    354 _T1CC2L	=	0x00de
                    00DF    355 _T1CC2H	=	0x00df
                    00E0    356 _ACC	=	0x00e0
                    00E1    357 _RFST	=	0x00e1
                    00E2    358 _T1CNTL	=	0x00e2
                    00E3    359 _T1CNTH	=	0x00e3
                    00E4    360 _T1CTL	=	0x00e4
                    00E5    361 _T1CCTL0	=	0x00e5
                    00E6    362 _T1CCTL1	=	0x00e6
                    00E7    363 _T1CCTL2	=	0x00e7
                    00E8    364 _IRCON2	=	0x00e8
                    00E9    365 _RFIF	=	0x00e9
                    00EA    366 _T4CNT	=	0x00ea
                    00EB    367 _T4CTL	=	0x00eb
                    00EC    368 _T4CCTL0	=	0x00ec
                    00ED    369 _T4CC0	=	0x00ed
                    00EE    370 _T4CCTL1	=	0x00ee
                    00EF    371 _T4CC1	=	0x00ef
                    00F0    372 _B	=	0x00f0
                    00F1    373 _PERCFG	=	0x00f1
                    00F2    374 _ADCCFG	=	0x00f2
                    00F3    375 _P0SEL	=	0x00f3
                    00F4    376 _P1SEL	=	0x00f4
                    00F5    377 _P2SEL	=	0x00f5
                    00F6    378 _P1INP	=	0x00f6
                    00F7    379 _P2INP	=	0x00f7
                    00F8    380 _U1CSR	=	0x00f8
                    00F9    381 _U1BUF	=	0x00f9
                    00FA    382 _U1BAUD	=	0x00fa
                    00FB    383 _U1UCR	=	0x00fb
                    00FC    384 _U1GCR	=	0x00fc
                    00FD    385 _P0DIR	=	0x00fd
                    00FE    386 _P1DIR	=	0x00fe
                    00FF    387 _P2DIR	=	0x00ff
                            388 ;--------------------------------------------------------
                            389 ; special function bits
                            390 ;--------------------------------------------------------
                            391 	.area RSEG    (DATA)
                    0087    392 _P0_7	=	0x0087
                    0086    393 _P0_6	=	0x0086
                    0085    394 _P0_5	=	0x0085
                    0084    395 _P0_4	=	0x0084
                    0083    396 _P0_3	=	0x0083
                    0082    397 _P0_2	=	0x0082
                    0081    398 _P0_1	=	0x0081
                    0080    399 _P0_0	=	0x0080
                    008F    400 _TCON_URX1IF	=	0x008f
                    008D    401 _TCON_ADCIF	=	0x008d
                    008B    402 _TCON_URX0IF	=	0x008b
                    008A    403 _TCON_IT1	=	0x008a
                    0089    404 _TCON_RFERRIF	=	0x0089
                    0088    405 _TCON_IT0	=	0x0088
                    0090    406 _P1_0	=	0x0090
                    0091    407 _P1_1	=	0x0091
                    0092    408 _P1_2	=	0x0092
                    0093    409 _P1_3	=	0x0093
                    0094    410 _P1_4	=	0x0094
                    0095    411 _P1_5	=	0x0095
                    0096    412 _P1_6	=	0x0096
                    0097    413 _P1_7	=	0x0097
                    0099    414 _S0CON_ENCIF_1	=	0x0099
                    0098    415 _S0CON_ENCIF_0	=	0x0098
                    00A0    416 _P2_0	=	0x00a0
                    00A1    417 _P2_1	=	0x00a1
                    00A2    418 _P2_2	=	0x00a2
                    00A3    419 _P2_3	=	0x00a3
                    00A4    420 _P2_4	=	0x00a4
                    00AF    421 _EA	=	0x00af
                    00AF    422 _IEN0_EA	=	0x00af
                    00AD    423 _IEN0_STIE	=	0x00ad
                    00AC    424 _IEN0_ENCIE	=	0x00ac
                    00AB    425 _IEN0_URX1IE	=	0x00ab
                    00AA    426 _IEN0_URX0IE	=	0x00aa
                    00A9    427 _IEN0_ADCIE	=	0x00a9
                    00A8    428 _IEN0_RFERRIE	=	0x00a8
                    00BD    429 _IEN1_P0IE	=	0x00bd
                    00BC    430 _IEN1_T4IE	=	0x00bc
                    00BB    431 _IEN1_T3IE	=	0x00bb
                    00BA    432 _IEN1_T2IE	=	0x00ba
                    00B9    433 _IEN1_T1IE	=	0x00b9
                    00B8    434 _IEN1_DMAIE	=	0x00b8
                    00C7    435 _IRCON_STIF	=	0x00c7
                    00C5    436 _IRCON_P0IF	=	0x00c5
                    00C4    437 _IRCON_T4IF	=	0x00c4
                    00C3    438 _IRCON_T3IF	=	0x00c3
                    00C2    439 _IRCON_T2IF	=	0x00c2
                    00C1    440 _IRCON_T1IF	=	0x00c1
                    00C0    441 _IRCON_DMAIF	=	0x00c0
                    00D0    442 _P	=	0x00d0
                    00D1    443 _F1	=	0x00d1
                    00D2    444 _OV	=	0x00d2
                    00D3    445 _RS0	=	0x00d3
                    00D4    446 _RS1	=	0x00d4
                    00D5    447 _F0	=	0x00d5
                    00D6    448 _AC	=	0x00d6
                    00D7    449 _CY	=	0x00d7
                    00EC    450 _IRCON2_WDTIF	=	0x00ec
                    00EB    451 _IRCON2_P1IF	=	0x00eb
                    00EA    452 _IRCON2_UTX1IF	=	0x00ea
                    00E9    453 _IRCON2_UTX0IF	=	0x00e9
                    00E8    454 _IRCON2_P2IF	=	0x00e8
                            455 ;--------------------------------------------------------
                            456 ; overlayable register banks
                            457 ;--------------------------------------------------------
                            458 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     459 	.ds 8
                            460 ;--------------------------------------------------------
                            461 ; internal ram data
                            462 ;--------------------------------------------------------
                            463 	.area DSEG    (DATA)
                            464 ;--------------------------------------------------------
                            465 ; overlayable items in internal ram 
                            466 ;--------------------------------------------------------
                            467 	.area OSEG    (OVR,DATA)
                            468 ;--------------------------------------------------------
                            469 ; indirectly addressable internal ram data
                            470 ;--------------------------------------------------------
                            471 	.area ISEG    (DATA)
                            472 ;--------------------------------------------------------
                            473 ; bit data
                            474 ;--------------------------------------------------------
                            475 	.area BSEG    (BIT)
                            476 ;--------------------------------------------------------
                            477 ; paged external ram data
                            478 ;--------------------------------------------------------
                            479 	.area PSEG    (PAG,XDATA)
                            480 ;--------------------------------------------------------
                            481 ; external ram data
                            482 ;--------------------------------------------------------
                            483 	.area XSEG    (XDATA)
                    DF02    484 _MDMCTRL0H	=	0xdf02
                    DF03    485 _MDMCTRL0L	=	0xdf03
                    DF04    486 _MDMCTRL1H	=	0xdf04
                    DF05    487 _MDMCTRL1L	=	0xdf05
                    DF06    488 _RSSIH	=	0xdf06
                    DF07    489 _RSSIL	=	0xdf07
                    DF08    490 _SYNCWORDH	=	0xdf08
                    DF09    491 _SYNCWORDL	=	0xdf09
                    DF0A    492 _TXCTRLH	=	0xdf0a
                    DF0B    493 _TXCTRLL	=	0xdf0b
                    DF0C    494 _RXCTRL0H	=	0xdf0c
                    DF0D    495 _RXCTRL0L	=	0xdf0d
                    DF0E    496 _RXCTRL1H	=	0xdf0e
                    DF0F    497 _RXCTRL1L	=	0xdf0f
                    DF10    498 _FSCTRLH	=	0xdf10
                    DF11    499 _FSCTRLL	=	0xdf11
                    DF12    500 _CSPX	=	0xdf12
                    DF13    501 _CSPY	=	0xdf13
                    DF14    502 _CSPZ	=	0xdf14
                    DF15    503 _CSPCTRL	=	0xdf15
                    DF16    504 _CSPT	=	0xdf16
                    DF17    505 _RFPWR	=	0xdf17
                    DF20    506 _FSMTCH	=	0xdf20
                    DF21    507 _FSMTCL	=	0xdf21
                    DF22    508 _MANANDH	=	0xdf22
                    DF23    509 _MANANDL	=	0xdf23
                    DF24    510 _MANORH	=	0xdf24
                    DF25    511 _MANORL	=	0xdf25
                    DF26    512 _AGCCTRLH	=	0xdf26
                    DF27    513 _AGCCTRLL	=	0xdf27
                    DF39    514 _FSMSTATE	=	0xdf39
                    DF3A    515 _ADCTSTH	=	0xdf3a
                    DF3B    516 _ADCTSTL	=	0xdf3b
                    DF3C    517 _DACTSTH	=	0xdf3c
                    DF3D    518 _DACTSTL	=	0xdf3d
                    DF43    519 _IEEE_ADDR0	=	0xdf43
                    DF44    520 _IEEE_ADDR1	=	0xdf44
                    DF45    521 _IEEE_ADDR2	=	0xdf45
                    DF46    522 _IEEE_ADDR3	=	0xdf46
                    DF47    523 _IEEE_ADDR4	=	0xdf47
                    DF48    524 _IEEE_ADDR5	=	0xdf48
                    DF49    525 _IEEE_ADDR6	=	0xdf49
                    DF4A    526 _IEEE_ADDR7	=	0xdf4a
                    DF4B    527 _PANIDH	=	0xdf4b
                    DF4C    528 _PANIDL	=	0xdf4c
                    DF4D    529 _SHORTADDRH	=	0xdf4d
                    DF4E    530 _SHORTADDRL	=	0xdf4e
                    DF4F    531 _IOCFG0	=	0xdf4f
                    DF50    532 _IOCFG1	=	0xdf50
                    DF51    533 _IOCFG2	=	0xdf51
                    DF52    534 _IOCFG3	=	0xdf52
                    DF53    535 _RXFIFOCNT	=	0xdf53
                    DF54    536 _FSMTC1	=	0xdf54
                    DF60    537 _CHVER	=	0xdf60
                    DF61    538 _CHIPID	=	0xdf61
                    DF62    539 _RFSTATUS	=	0xdf62
                    DFD9    540 _RFD_SHADOW	=	0xdfd9
                            541 ;--------------------------------------------------------
                            542 ; external initialized ram data
                            543 ;--------------------------------------------------------
                            544 	.area XISEG   (XDATA)
   F085                     545 _mac_short::
   F085                     546 	.ds 13
   F092                     547 _mac_long::
   F092                     548 	.ds 13
                            549 	.area HOME    (CODE)
                            550 	.area GSINIT0 (CODE)
                            551 	.area GSINIT1 (CODE)
                            552 	.area GSINIT2 (CODE)
                            553 	.area GSINIT3 (CODE)
                            554 	.area GSINIT4 (CODE)
                            555 	.area GSINIT5 (CODE)
                            556 	.area GSINIT  (CODE)
                            557 	.area GSFINAL (CODE)
                            558 	.area CSEG    (CODE)
                            559 ;--------------------------------------------------------
                            560 ; global & static initialisations
                            561 ;--------------------------------------------------------
                            562 	.area HOME    (CODE)
                            563 	.area GSINIT  (CODE)
                            564 	.area GSFINAL (CODE)
                            565 	.area GSINIT  (CODE)
                            566 ;--------------------------------------------------------
                            567 ; Home
                            568 ;--------------------------------------------------------
                            569 	.area HOME    (CODE)
                            570 	.area CSEG    (CODE)
                            571 ;--------------------------------------------------------
                            572 ; code
                            573 ;--------------------------------------------------------
                            574 	.area CSEG    (CODE)
                            575 ;------------------------------------------------------------
                            576 ;Allocation info for local variables in function 'mac_get'
                            577 ;------------------------------------------------------------
                            578 ;address                   Allocated to registers r2 r3 r4 
                            579 ;------------------------------------------------------------
                            580 ;	../../Platform/nano/mac.c:71: portCHAR mac_get(sockaddr_t *address)
                            581 ;	-----------------------------------------
                            582 ;	 function mac_get
                            583 ;	-----------------------------------------
   37FC                     584 _mac_get:
                    0002    585 	ar2 = 0x02
                    0003    586 	ar3 = 0x03
                    0004    587 	ar4 = 0x04
                    0005    588 	ar5 = 0x05
                    0006    589 	ar6 = 0x06
                    0007    590 	ar7 = 0x07
                    0000    591 	ar0 = 0x00
                    0001    592 	ar1 = 0x01
                            593 ;	genReceive
                            594 ;	../../Platform/nano/mac.c:73: switch(address->addr_type)
                            595 ;	genPointerGet
                            596 ;	genGenPointerGet
   37FC AA 82               597 	mov	r2,dpl
   37FE AB 83               598 	mov	r3,dph
   3800 AC F0               599 	mov	r4,b
                            600 ;	Peephole 238.d	removed 3 redundant moves
   3802 12 E4 9F            601 	lcall	__gptrget
   3805 FD                  602 	mov	r5,a
                            603 ;	genCmpEq
                            604 ;	gencjneshort
   3806 BD 01 02            605 	cjne	r5,#0x01,00112$
                            606 ;	Peephole 112.b	changed ljmp to sjmp
   3809 80 2B               607 	sjmp	00105$
   380B                     608 00112$:
                            609 ;	genCmpEq
                            610 ;	gencjneshort
   380B BD 02 02            611 	cjne	r5,#0x02,00113$
                            612 ;	Peephole 112.b	changed ljmp to sjmp
   380E 80 03               613 	sjmp	00102$
   3810                     614 00113$:
                            615 ;	genCmpEq
                            616 ;	gencjneshort
                            617 ;	Peephole 112.b	changed ljmp to sjmp
                            618 ;	Peephole 198.b	optimized misc jump sequence
   3810 BD 03 23            619 	cjne	r5,#0x03,00105$
                            620 ;	Peephole 200.b	removed redundant sjmp
                            621 ;	Peephole 300	removed redundant label 00114$
                            622 ;	Peephole 300	removed redundant label 00115$
                            623 ;	../../Platform/nano/mac.c:76: case ADDR_802_15_4_SHORT:
   3813                     624 00102$:
                            625 ;	../../Platform/nano/mac.c:77: memcpy(address, &(mac_short), sizeof(sockaddr_t));
                            626 ;	genIpush
   3813 74 0D               627 	mov	a,#0x0D
   3815 C0 E0               628 	push	acc
                            629 ;	Peephole 181	changed mov to clr
   3817 E4                  630 	clr	a
   3818 C0 E0               631 	push	acc
                            632 ;	genIpush
   381A 74 85               633 	mov	a,#_mac_short
   381C C0 E0               634 	push	acc
   381E 74 F0               635 	mov	a,#(_mac_short >> 8)
   3820 C0 E0               636 	push	acc
                            637 ;	Peephole 181	changed mov to clr
   3822 E4                  638 	clr	a
   3823 C0 E0               639 	push	acc
                            640 ;	genCall
   3825 8A 82               641 	mov	dpl,r2
   3827 8B 83               642 	mov	dph,r3
   3829 8C F0               643 	mov	b,r4
   382B 12 E2 C7            644 	lcall	_memcpy
   382E E5 81               645 	mov	a,sp
   3830 24 FB               646 	add	a,#0xfb
   3832 F5 81               647 	mov	sp,a
                            648 ;	../../Platform/nano/mac.c:78: break;
                            649 ;	../../Platform/nano/mac.c:82: default:
                            650 ;	Peephole 112.b	changed ljmp to sjmp
   3834 80 21               651 	sjmp	00106$
   3836                     652 00105$:
                            653 ;	../../Platform/nano/mac.c:83: memcpy(address, &(mac_long), sizeof(sockaddr_t));
                            654 ;	genIpush
   3836 74 0D               655 	mov	a,#0x0D
   3838 C0 E0               656 	push	acc
                            657 ;	Peephole 181	changed mov to clr
   383A E4                  658 	clr	a
   383B C0 E0               659 	push	acc
                            660 ;	genIpush
   383D 74 92               661 	mov	a,#_mac_long
   383F C0 E0               662 	push	acc
   3841 74 F0               663 	mov	a,#(_mac_long >> 8)
   3843 C0 E0               664 	push	acc
                            665 ;	Peephole 181	changed mov to clr
   3845 E4                  666 	clr	a
   3846 C0 E0               667 	push	acc
                            668 ;	genCall
   3848 8A 82               669 	mov	dpl,r2
   384A 8B 83               670 	mov	dph,r3
   384C 8C F0               671 	mov	b,r4
   384E 12 E2 C7            672 	lcall	_memcpy
   3851 E5 81               673 	mov	a,sp
   3853 24 FB               674 	add	a,#0xfb
   3855 F5 81               675 	mov	sp,a
                            676 ;	../../Platform/nano/mac.c:85: }
   3857                     677 00106$:
                            678 ;	../../Platform/nano/mac.c:86: return pdTRUE;
                            679 ;	genRet
   3857 75 82 01            680 	mov	dpl,#0x01
                            681 ;	Peephole 300	removed redundant label 00107$
   385A 22                  682 	ret
                            683 ;------------------------------------------------------------
                            684 ;Allocation info for local variables in function 'mac_set'
                            685 ;------------------------------------------------------------
                            686 ;address                   Allocated to registers r2 r3 r4 
                            687 ;------------------------------------------------------------
                            688 ;	../../Platform/nano/mac.c:89: void mac_set(sockaddr_t *address)
                            689 ;	-----------------------------------------
                            690 ;	 function mac_set
                            691 ;	-----------------------------------------
   385B                     692 _mac_set:
                            693 ;	genReceive
                            694 ;	../../Platform/nano/mac.c:91: switch(address->addr_type)
                            695 ;	genPointerGet
                            696 ;	genGenPointerGet
   385B AA 82               697 	mov	r2,dpl
   385D AB 83               698 	mov	r3,dph
   385F AC F0               699 	mov	r4,b
                            700 ;	Peephole 238.d	removed 3 redundant moves
   3861 12 E4 9F            701 	lcall	__gptrget
   3864 FD                  702 	mov	r5,a
                            703 ;	genCmpEq
                            704 ;	gencjneshort
   3865 BD 01 02            705 	cjne	r5,#0x01,00112$
                            706 ;	Peephole 112.b	changed ljmp to sjmp
   3868 80 34               707 	sjmp	00105$
   386A                     708 00112$:
                            709 ;	genCmpEq
                            710 ;	gencjneshort
   386A BD 02 02            711 	cjne	r5,#0x02,00113$
                            712 ;	Peephole 112.b	changed ljmp to sjmp
   386D 80 03               713 	sjmp	00102$
   386F                     714 00113$:
                            715 ;	genCmpEq
                            716 ;	gencjneshort
                            717 ;	Peephole 112.b	changed ljmp to sjmp
                            718 ;	Peephole 198.b	optimized misc jump sequence
   386F BD 03 2C            719 	cjne	r5,#0x03,00105$
                            720 ;	Peephole 200.b	removed redundant sjmp
                            721 ;	Peephole 300	removed redundant label 00114$
                            722 ;	Peephole 300	removed redundant label 00115$
                            723 ;	../../Platform/nano/mac.c:94: case ADDR_802_15_4_SHORT:
   3872                     724 00102$:
                            725 ;	../../Platform/nano/mac.c:95: memcpy(&(mac_short), address,  sizeof(sockaddr_t));
                            726 ;	genIpush
   3872 74 0D               727 	mov	a,#0x0D
   3874 C0 E0               728 	push	acc
                            729 ;	Peephole 181	changed mov to clr
   3876 E4                  730 	clr	a
   3877 C0 E0               731 	push	acc
                            732 ;	genIpush
   3879 C0 02               733 	push	ar2
   387B C0 03               734 	push	ar3
   387D C0 04               735 	push	ar4
                            736 ;	genCall
                            737 ;	Peephole 182.a	used 16 bit load of DPTR
   387F 90 F0 85            738 	mov	dptr,#_mac_short
   3882 75 F0 00            739 	mov	b,#0x00
   3885 12 E2 C7            740 	lcall	_memcpy
   3888 E5 81               741 	mov	a,sp
   388A 24 FB               742 	add	a,#0xfb
   388C F5 81               743 	mov	sp,a
                            744 ;	../../Platform/nano/mac.c:97: mac_set_mac_pib_parameter(mac_short.address, MAC_SHORT_ADDRESS);
                            745 ;	genIpush
   388E 74 06               746 	mov	a,#0x06
   3890 C0 E0               747 	push	acc
                            748 ;	genCall
                            749 ;	Peephole 182.a	used 16 bit load of DPTR
   3892 90 F0 86            750 	mov	dptr,#(_mac_short + 0x0001)
   3895 75 F0 00            751 	mov	b,#0x00
   3898 12 98 A2            752 	lcall	_mac_set_mac_pib_parameter
   389B 15 81               753 	dec	sp
                            754 ;	../../Platform/nano/mac.c:99: break;
                            755 ;	../../Platform/nano/mac.c:103: default:
                            756 ;	Peephole 112.b	changed ljmp to sjmp
                            757 ;	Peephole 251.b	replaced sjmp to ret with ret
   389D 22                  758 	ret
   389E                     759 00105$:
                            760 ;	../../Platform/nano/mac.c:104: memcpy(&(mac_long), address, sizeof(sockaddr_t));
                            761 ;	genIpush
   389E 74 0D               762 	mov	a,#0x0D
   38A0 C0 E0               763 	push	acc
                            764 ;	Peephole 181	changed mov to clr
   38A2 E4                  765 	clr	a
   38A3 C0 E0               766 	push	acc
                            767 ;	genIpush
   38A5 C0 02               768 	push	ar2
   38A7 C0 03               769 	push	ar3
   38A9 C0 04               770 	push	ar4
                            771 ;	genCall
                            772 ;	Peephole 182.a	used 16 bit load of DPTR
   38AB 90 F0 92            773 	mov	dptr,#_mac_long
   38AE 75 F0 00            774 	mov	b,#0x00
   38B1 12 E2 C7            775 	lcall	_memcpy
   38B4 E5 81               776 	mov	a,sp
   38B6 24 FB               777 	add	a,#0xfb
   38B8 F5 81               778 	mov	sp,a
                            779 ;	../../Platform/nano/mac.c:106: mac_set_mac_pib_parameter(mac_long.address, MAC_IEEE_ADDRESS);
                            780 ;	genIpush
   38BA 74 01               781 	mov	a,#0x01
   38BC C0 E0               782 	push	acc
                            783 ;	genCall
                            784 ;	Peephole 182.a	used 16 bit load of DPTR
   38BE 90 F0 93            785 	mov	dptr,#(_mac_long + 0x0001)
   38C1 75 F0 00            786 	mov	b,#0x00
   38C4 12 98 A2            787 	lcall	_mac_set_mac_pib_parameter
   38C7 15 81               788 	dec	sp
                            789 ;	../../Platform/nano/mac.c:107: rf_802_15_4_ip_layer_address_mode_set(0);
                            790 ;	genCall
   38C9 75 82 00            791 	mov	dpl,#0x00
                            792 ;	../../Platform/nano/mac.c:110: }
                            793 ;	Peephole 253.b	replaced lcall/ret with ljmp
   38CC 02 96 A6            794 	ljmp	_rf_802_15_4_ip_layer_address_mode_set
                            795 ;
                            796 	.area CSEG    (CODE)
                            797 	.area CONST   (CODE)
                            798 	.area XINIT   (CODE)
   E882                     799 __xinit__mac_short:
   E882 00                  800 	.db #0x00
   E883 00                  801 	.db #0x00
   E884 00                  802 	.db #0x00
   E885 00                  803 	.db #0x00
   E886 00                  804 	.db #0x00
   E887 00                  805 	.db #0x00
   E888 00                  806 	.db #0x00
   E889 00                  807 	.db #0x00
   E88A 00                  808 	.db #0x00
   E88B 00                  809 	.db #0x00
   E88C 00                  810 	.db #0x00
   E88D 00 00               811 	.byte #0x00,#0x00
   E88F                     812 __xinit__mac_long:
   E88F 00                  813 	.db #0x00
   E890 00                  814 	.db #0x00
   E891 00                  815 	.db #0x00
   E892 00                  816 	.db #0x00
   E893 00                  817 	.db #0x00
   E894 00                  818 	.db #0x00
   E895 00                  819 	.db #0x00
   E896 00                  820 	.db #0x00
   E897 00                  821 	.db #0x00
   E898 00                  822 	.db #0x00
   E899 00                  823 	.db #0x00
   E89A 00 00               824 	.byte #0x00,#0x00
