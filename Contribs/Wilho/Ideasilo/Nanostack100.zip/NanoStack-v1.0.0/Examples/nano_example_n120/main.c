/*
    NanoStack: MCU software and PC tools for sensor networking.
		
    Copyright (C) 2006-2007 Sensinode Ltd.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

		Address:
		Sensinode Ltd.
		PO Box 1
		90571 Oulu, Finland

		E-mail:
		info@sensinode.com
*/


/* Standard includes. */
#include <stdlib.h>
#include <string.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#include <sys/inttypes.h>

#include "stack.h"
#include "uart.h"
#include "rf.h"
#include "bus.h"

#ifdef HAVE_DMA
#include "dma.h"
#endif

#include "debug.h"


/*-----------------------------------------------------------*/
static void vMain(int8_t *pvParameters );

int main( void )
{
	bus_init();

	LED1_ON();
	LED2_ON();

	xTaskCreate( vMain, "Main", configMAXIMUM_STACK_SIZE, NULL, ( tskIDLE_PRIORITY + 0 ), ( xTaskHandle * )NULL );	

	vTaskStartScheduler();

	return 0;
}

sockaddr_t test_address = 
{
	ADDR_802_15_4_PAN_LONG,
	{ 0x00, 0x00, 0x00, 0x00, 
	  0x00, 0x00, 0x00, 0x00 },
	253
};
//253
sockaddr_t broadcast_address = 
{
	ADDR_802_15_4_PAN_LONG,
	{ 0xFF, 0xFF, 0xFF, 0xFF, 
	  0xFF, 0xFF, 0xFF, 0xFF },
	254
};
//254

buffer_t *test_buffer;
socket_t *test_socket;

extern xQueueHandle buffers;

static void vMain(int8_t *pvParameters )
{
	int16_t byte;
	uint8_t count = (uint8_t) pvParameters;
	uint8_t msg;
	int8_t ping_active=0;
	uint16_t ping_counter = 0;
	portTickType ping_ticks;
	portTickType ping_start = 0;

	debug_init(115200);

	vTaskDelay(300 / portTICK_RATE_MS );
	debug("Task start.\r\n");

	stack_init();
/*	debug("Sensinode Nano Shell v0.9.3\r\n\r\n");*/

	LED2_OFF();
	for( ;; )
	{
		msg = 0;
		
		byte = debug_read_blocking(2 + ((ping_active ^ 1)* 100/portTICK_RATE_MS));

		if (byte != -1)
		{
			LED2_ON();
			count = 3;

			msg = 2;
	 		switch(byte)
			{
				case 'h':
					{
						debug("Shell help:\r\ns - Open/close socket, p - Send broadcast ping,  m - My MAC address\r\n\r\n");
					}
					break;
					
				case 's':
					if (test_socket == 0)
					{
						test_socket = socket(MODULE_CUDP, 0);
						if (test_socket)
						{
							if (socket_bind(test_socket, &test_address) == pdTRUE)
							{
								debug("Done.\r\n");
								test_buffer = 0;
								ping_counter = 0;
							}
							else
							{
								debug("Bind failed.\r\n");
							}							
						}
						else
						{
							debug("Socket creation failed.\r\n");							
						}
					}
					else
					{
						socket_close(test_socket);
						test_socket = 0;
						test_buffer = 0;
						debug("Socket closed.\r\n");
					}
					break;
					
				case 'p':
					if (test_socket != 0 && ping_active==0)
					{
						buffer_t *buffer = socket_buffer_get(test_socket);
						if (buffer)
						{
							buffer->buf[buffer->buf_end++] = (ping_counter >> 8);
							buffer->buf[buffer->buf_end++] = (uint8_t) ping_counter;
							test_buffer = 0;
							broadcast_address.port = 254;
							if (socket_sendto(test_socket, &broadcast_address, buffer) == pdTRUE)
							{
								ping_start = xTaskGetTickCount();
								vTaskDelay(10/portTICK_RATE_MS);
								debug("Ping ");
								debug_int(ping_counter);
								debug(" sent.\r\n");
								ping_active = 1;
								ping_counter++;
							}
							else
							{
								stack_buffer_free(buffer);
								debug("Ping send failed.\r\n");
							}
						}
						else
						{
							debug("No buffer.\r\n");
						}
					}
					else
					{
						if (!test_socket)
						{
							debug("No socket.\r\n");
						}
						else
						{
							debug("Active.\r\n");
							ping_active = 0;
						}
					}
					break;

				case '\r':
					debug("\r\n");
					msg = 0;
					break;

				case 'm':
					{
						sockaddr_t mac;
						
						rf_mac_get(&mac);
						
						debug("MAC: ");
						debug_address(&mac);
						debug("\r\n");
					}
					break;

				default:
					debug_put(byte);
			}	
		}
		if (test_socket)
		{
	 		debug("- ");
	 		test_buffer = socket_read(test_socket, ping_active * 100/portTICK_RATE_MS);
			if (test_buffer)
			{
				uint8_t i = 0;
				uint8_t length = test_buffer->buf_end - test_buffer->buf_ptr;
				uint16_t ping_time;
					
				sockaddr_t *src_sa = &(test_buffer->src_sa);

				ping_ticks = xTaskGetTickCount() - ping_start;
				
				ping_time = ping_ticks * portTICK_RATE_MS;

				debug(" address ");
				debug_address(src_sa);

				debug(" ");
				vTaskDelay(20/portTICK_RATE_MS);
				for(i=0; i<length; i++)
				{
					debug_hex(test_buffer->buf[test_buffer->buf_ptr+i]);
				}
				debug("level ");
				debug_int(test_buffer->options.rf_dbm);
				debug("dbm, lqi ");
				debug_int(test_buffer->options.rf_lqi);
				debug(", time=");
				debug_int(ping_time);
				debug("\r\n");
				ping_active = 0;
			}
			socket_buffer_free(test_buffer);
			test_buffer = 0;
		}
		if ((xTaskGetTickCount() - ping_start)*portTICK_RATE_MS > 1000 && ping_active)
		{
			debug("Ping timeout.\r\n");
			test_buffer = 0;
			ping_active = 0;
		}
		if (count > 20)
		{
		 	count = 0;
	 	}
		else if (count > 10)
		{
			LED2_OFF();
		}
		count++;
	}
}


