/*
    NanoStack: MCU software and PC tools for sensor networking.
		
    Copyright (C) 2006-2007 Sensinode Ltd.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

		Address:
		Sensinode Ltd.
		PO Box 1
		90571 Oulu, Finland

		E-mail:
		info@sensinode.com
*/


/**
 *
 * \file main.c
 * \brief Example for testing beacon enable mode client which discover PAN coordinator and send data. Client cuold send packet only to coordinator.
 *
 */

/* Standard includes. */
#include <stdlib.h>
#include <signal.h>
#include <string.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#include "bus.h"
#include "gpio.h"

#include "debug.h"
//#include "ssi.h"
//#include "adc.h"
#include "control_message.h"
#include "neighbor_routing_table.h"


typedef uint8_t b1w_reg[8];

static void vbeacon_rfd( void *pvParameters );

#include "socket.h"
#include "rf.h"

extern sockaddr_t mac_long;
extern xQueueHandle     buffers;

sockaddr_t broadcast_address = 
{
	ADDR_COORDINATOR,
	{ 0xFF, 0xFF, 0xFF, 0xFF,0xFF, 
	  0xFF, 0xFF, 0xFF, 0xFF, 0xFF },
	61619
};
sockaddr_t test = 
{
	ADDR_802_15_4_PAN_SHORT,
	{ 0x00, 0x00, 0x00, 0x00,0x00, 
	  0x00, 0x00, 0x00, 0x00, 0x00 },
	61619
};

sockaddr_t control = 
{
	ADDR_NONE,
	{ 0x00, 0x00, 0x00, 0x00, 
	  0x00, 0x00, 0x00, 0x00, 0x00, 0x00 },
	MAC_CTRL_PORT
};

int main( void )
{
	LED_INIT();
	if (bus_init() == pdFALSE)
	{
	}	
	LED1_ON();
	xTaskCreate( vbeacon_rfd, "Client", configMINIMAL_STACK_SIZE + 200, NULL, (tskIDLE_PRIORITY + 2 ), NULL );
	vTaskStartScheduler();

	return 0;
}
/*-----------------------------------------------------------*/
socket_t *data = 0, *mac_control=0;

static void vbeacon_rfd( void *pvParameters )
{
	portTickType xLastWakeTime;
	uint8_t send=0, i;
	int16_t byte;
	uint16_t count = 0;
	control_message_t *msg;
	buffer_t *buffer;
	pause(200);
	debug_init(115200);
	pause(300);


	debug("Init:\r\n");
	vTaskDelay(300/portTICK_RATE_MS);	
	stack_init();
	debug("Init done.\r\n");
	vTaskDelay(200/portTICK_RATE_MS);	
	/* Temp init variable */
	{
		stack_init_t stack_rules;
		start_status_t status;
		memset(stack_rules.mac_address, (uint8_t) 0, 8);

		stack_rules.channel = 18;
		stack_rules.type = BEACON_ENABLE_CLIENT;
		for(i=0; i<8; i++)
		{
			stack_rules.mac_address[i] = mac_long.address[i];
		}
		debug("Start.\r\n");
		vTaskDelay(300/portTICK_RATE_MS);
		status = stack_start(&stack_rules);
		if(status==START_SUCCESS)
		{
			debug("Start Ok\r\n");
		}
	}
/*****************************************************************************************************/

/****************************************************************************************************/

	xLastWakeTime = xTaskGetTickCount();
	LED1_ON();
	vTaskDelayUntil( &xLastWakeTime, 1000 / portTICK_RATE_MS );
	LED1_OFF();
	data = socket(MODULE_CUDP, 0);	/* Socket for response data from port number 61619 */
	mac_control 	= socket(MODULE_RF_802_15_4, 	0);	/* Socket for send and receive control message to MAC-layer */
	if (data)
	{
		if (socket_bind(data, &test) != pdTRUE)
		{
			debug("Bind failed.\r\n");
		}							
	}
	if (mac_control)
	{
		if (socket_bind(mac_control, &control) != pdTRUE)
			debug("Bind fail mac ctr.\r\n");					
	}
	cipv6_compress_mode(1);
	cudp_compress_mode(1);
	for (;;)
	{
		byte = debug_read_blocking(20);
		if(byte != -1)
		{
			switch(byte)
			{
				case 'b':
					debug_int(uxQueueMessagesWaiting(buffers));
					debug(" buffers available.\r\n");
					break;	
	

				case 'm':
					if(mac_control)
					{
						buffer_t *buf = socket_buffer_get(mac_control);
						if (buf)
						{
							buf->options.type = BUFFER_CONTROL;
							msg = ( control_message_t*) buf->buf;
							msg->message.mac_control.message_id = GET_REQ;
							msg->message.mac_control.message.get_attribute_req = MAC_IEEE_ADDRESS;
							if (socket_sendto(mac_control, &control, buf) == pdTRUE)
							{
								debug("GET devices mac-address from MAC-PIB: ");
								buf=0;
							}
							else
							{
								debug("Control send failed.\r\n");
								socket_buffer_free(buf);
								buf=0;
							}
						}
						else
						{
							debug("No buffer.\r\n");
						}
						
					}
					break;

				case 'c':
					if(mac_control)
					{
						buffer_t *buf = socket_buffer_get(mac_control);
						if (buf)
						{
							buf->options.type = BUFFER_CONTROL;
							msg = ( control_message_t*) buf->buf;
							msg->message.mac_control.message_id = GET_REQ;
							msg->message.mac_control.message.get_attribute_req = MAC_CURRENT_CHANNEL;
							if (socket_sendto(mac_control, &control, buf) == pdTRUE)
							{
								debug("GET current channel from MAC-PIB: ");
							}
							else
							{
								debug("Control send failed.\r\n");
								socket_buffer_free(buf);
								buf=0;
							}
						}
						else
						{
							debug("No buffer.\r\n");
						}
					}
					break;

	
				case '\r':
					
					debug("\r\n");
					break;

				default:
					debug_put(byte);
					break;
			}	
		}
		if(mac_control)
		{
			
			buffer=0;
			buffer = socket_read(mac_control, 10);
			if(buffer)
			{
				msg = ( control_message_t*) buffer->buf;
				if(msg->message.mac_control.message_id == GET_CONFIRM)
				{
					if( msg->message.mac_control.message.get_confirm.pib_attribute == MAC_CURRENT_CHANNEL)
					{
						debug_int(msg->message.mac_control.message.get_confirm.atribute_value[0]);
						debug("\r\n");
					}
					if( msg->message.mac_control.message.get_confirm.pib_attribute == MAC_IEEE_ADDRESS)
					{
						for(i=0; i< 8 ;i++)
						{
							debug_hex(msg->message.mac_control.message.get_confirm.atribute_value[7-i]);
							debug(" ");
						}
						debug("\r\n");
					}
				}
				socket_buffer_free(buffer);
				buffer = 0;	
			}
		}
		if(send)
		{	
			if (data)
			{
				buffer_t *buf = socket_buffer_get(data);
				if (buf)
				{
					/* Create data packet */
					buf->buf[buf->buf_end++] = 'S';
					buf->buf[buf->buf_end++] = 'e';
					buf->buf[buf->buf_end++] = 'n';
					buf->buf[buf->buf_end++] = 's';
					buf->buf[buf->buf_end++] = 'o';
					buf->buf[buf->buf_end++] = 'r';
					buf->buf[buf->buf_end++] = '_';
					buf->buf[buf->buf_end++] = mac_long.address[1];
					buf->buf[buf->buf_end++] = mac_long.address[0];
					if (socket_sendto(data, &broadcast_address, buf) != pdTRUE)
					{	
						debug("Data send failed.\r\n");
						socket_buffer_free(buf);
						buf=0;
					}
					send=0;
				}
			}
		}
		if (count++ >= 250)
		{
			send=1;
			count = 0;
		}
		LED1_ON();
		vTaskDelayUntil( &xLastWakeTime, 20 / portTICK_RATE_MS );
		LED1_OFF();
	}
}
