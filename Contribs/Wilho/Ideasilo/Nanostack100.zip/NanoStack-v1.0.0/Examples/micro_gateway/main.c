/*
    NanoStack: MCU software and PC tools for sensor networking.
		
    Copyright (C) 2006-2007 Sensinode Ltd.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

		Address:
		Sensinode Ltd.
		PO Box 1
		90571 Oulu, Finland

		E-mail:
		info@sensinode.com
*/


/**
 *
 * \file main.c
 * \brief Example for testing beacon enable mode Gateway device. Gateway advertisesment own status to network coordinator by flooding ICMP ROUTER ADVERTISMENT message. Gateway has one socket where its waiting data from coordinator.
 *
 */

/* Standard includes. */
#include <stdlib.h>
#include <signal.h>
#include <string.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

#include "bus.h"
#include "gpio.h"
#include "debug.h"
#include "socket.h"
#include "control_message.h"
#include "neighbor_routing_table.h"
static void vgateway( void *pvParameters );
extern sockaddr_t mac_long;

int main( void )
{
	LED_INIT();
	if (bus_init() == pdFALSE)
	{
	}	
	LED1_ON();
	
	xTaskCreate( vgateway, "gw", configMINIMAL_STACK_SIZE+150, NULL, ( tskIDLE_PRIORITY + 2 ), NULL );	
	vTaskStartScheduler();

	return 0;
}

sockaddr_t control_address = 
{
	ADDR_NONE,
	{ 0x00, 0x00, 0x00, 0x00},
	ICMP_CTRL_PORT
};
/* Address to  Partner */
sockaddr_t data_address = 
{
	ADDR_802_15_4_PAN_SHORT,
	{ 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00 },
	61620
};

/*-----------------------------------------------------------*/

static void vgateway( void *pvParameters )
{
	buffer_t *buf, *data, *buffer;
	control_message_t *msg;
	uint8_t sqn, ind, i, length, tx_power=CC2420_DEFAULT_POWER;
	uint16_t count=100;
	int16_t byte;
	socket_t *icmp_control=0, *data_rx=0;
	
	
	pause(200);
	debug_init(115200);
	pause(300);


	debug("Init:\r\n");
	vTaskDelay(300/portTICK_RATE_MS);	
	stack_init();
	debug("Init done.\r\n");
	vTaskDelay(200/portTICK_RATE_MS);	
	/* Temp init variable */
	{
		stack_init_t stack_rules;
		start_status_t status;
		memset(stack_rules.mac_address, (uint8_t) 0, 8);

		stack_rules.channel = PAN_CHANNEL;
		stack_rules.type = BEACON_ENABLE_ROUTER;
		for(i=0; i<8; i++)
		{
			stack_rules.mac_address[i] = mac_long.address[i];
		}
	
		stack_rules.short_address[0] = (SHORT_ADDRESS & 0xff);
		stack_rules.short_address[1] = (SHORT_ADDRESS >> 8);
		stack_rules.pan_id[0] = (PAN_ID & 0xff);
		stack_rules.pan_id[1] = (PAN_ID >> 8);

		debug("Start.\r\n");
		vTaskDelay(300/portTICK_RATE_MS);
		status = stack_start(&stack_rules);
		if(status==START_SUCCESS)
		{
			debug("Start Ok\r\n");
		}
	}

	
	vTaskDelay(500 / portTICK_RATE_MS );
	LED2_ON();
	vTaskDelay(500 / portTICK_RATE_MS );	
	LED2_OFF();
	data_rx = socket(MODULE_CUDP, 0);
	icmp_control = socket(MODULE_ICMP, 0);
	
	if (data_rx)
	{
		if (socket_bind(data_rx, &data_address) != pdTRUE)
		{
			debug(" Data Bind failed.\r\n");
		}							
	}

	if (icmp_control)
	{
		if (socket_bind(icmp_control, &control_address) != pdTRUE)
		{
			debug("Control bind fail.\r\n");
		}							
	}
	cipv6_compress_mode(1);
	cudp_compress_mode(1);
	vTaskDelay(5000/portTICK_RATE_MS);
	for( ;; )
	{
		vTaskDelay(10 / portTICK_RATE_MS );
		byte = debug_read_blocking(10);
		if(byte != -1)
		{
			switch(byte)
			{
				case '\r':
					debug("\r\n");
					break;

				case 't':
					print_table_information();
					break;

				case '+':	
					if(tx_power==100)
					{
						debug("Max Tx power set up.\r\n");
					}
					else
					{
						tx_power += 10;
						rf_power_set(tx_power);
						debug_printf("Increace Tx power, current state %d.\r\n", tx_power);
					}
					break;

				case '-':	
					if(tx_power==10)
					{
						debug("Min Tx power set up 10.\r\n");
					}
					else
					{
						tx_power -= 10;
						rf_power_set(tx_power);
						debug_printf("Decreace Tx power, current state %d.\r\n", tx_power);
					}
					break;
	
				default:
					break;
			}	
		}

		if(count++ >400)
		{
			if(icmp_control)
			{
				buf=0;
				buf = socket_buffer_get(icmp_control);
				if (buf)
				{
					buf->options.type = BUFFER_CONTROL;
					buf->options.hop_count = 5;
					msg = ( control_message_t*) buf->buf;
					msg->message.ip_control.message_id = ROUTER_ADVER_SEND;
					if (socket_sendto(icmp_control, &control_address, buf) != pdTRUE)
					{
						debug("Ctr send fail\r\n");
						socket_buffer_free(buf);
						buf=0;
					}
				}
			}
			count=0;
		}

		if (data_rx)
		{
			data=0;
			data = socket_read(data_rx, 10);
			if (data)
			{
				ind=data->buf_ptr;
				if (data->dst_sa.port == 61620)
				{
					length = data->buf_end - data->buf_ptr;
					ind=data->buf_ptr;
					sqn = data->buf[ind++];
					debug_printf("DATA, %d sqn %d bytes ,",sqn,length);
					debug("\r\nSRC PAN-ID ");
					debug_address(&(data->src_sa));
					debug("\r\n");
				}
				socket_buffer_free(data);
				data = 0;
			}
		}
		if(icmp_control)
		{
			buffer=0;
			buffer = socket_read(icmp_control, 10);
			if(buffer)
			{
				msg = ( control_message_t*) buffer->buf;
				if(msg->message.ip_control.message_id == BROKEN_LINK)
				{
					debug("Route broken to ");

					buffer->dst_sa.addr_type = msg->message.ip_control.message.broken_link_detect.type;
					debug_address(&(buffer->dst_sa));
					debug("\r\n");
				}
				if(buffer)
				{
					socket_buffer_free(buffer);
					buffer = 0;
				}
			}
		}

	}
}
