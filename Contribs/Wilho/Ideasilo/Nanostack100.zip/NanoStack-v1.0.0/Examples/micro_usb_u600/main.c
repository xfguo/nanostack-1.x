/*
    NanoStack: MCU software and PC tools for sensor networking.
		
    Copyright (C) 2006-2007 Sensinode Ltd.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

		Address:
		Sensinode Ltd.
		PO Box 1
		90571 Oulu, Finland

		E-mail:
		info@sensinode.com
*/


/* Standard includes. */
#include <stdlib.h>
#include <signal.h>
#include <string.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#include "bus.h"
#include "gpio.h"
#include "debug.h"
#include "nrp.h"

static void vMain( void *pvParameters );
extern sockaddr_t mac_long;

#include "socket.h"

int main( void )
{
	

	LED_INIT();
	if (bus_init() == pdFALSE)
	{
		for (;;)
		{
			LED1_ON();
			LED2_OFF();
			LED1_OFF();
			LED2_ON();
		}
	}	
	xTaskCreate( vMain, "Main", configMINIMAL_STACK_SIZE+60, NULL, ( tskIDLE_PRIORITY + 1 ), NULL );	
	vTaskStartScheduler();

	return 0;
}
/*-----------------------------------------------------------*/

static void vMain( void *pvParameters )
{
	buffer_t *buffer;
	uint8_t i;
	vTaskDelay(500 / portTICK_RATE_MS );
	pause(200);
	debug_init(115200);
	pause(300);


	vTaskDelay(300/portTICK_RATE_MS);	
	stack_init();
	vTaskDelay(200/portTICK_RATE_MS);	
	/* Temp init variable */
	{
		stack_init_t stack_rules;
		start_status_t status;
		memset(stack_rules.mac_address, (uint8_t) 0, 8);

		memset(stack_rules.mac_address, (uint8_t) 0, 8);

		stack_rules.channel = 18;
		stack_rules.type = AD_HOC_DEVICE;
		for(i=0; i<8; i++)
		{
			stack_rules.mac_address[i] = mac_long.address[i];
		}

		vTaskDelay(300/portTICK_RATE_MS);
		status = stack_start(&stack_rules);
	}


	buffer = stack_buffer_get(0);
	if (buffer)
	{
		buffer->from = MODULE_NRP;
		buffer->to = MODULE_NRP;
		buffer->options.type = BUFFER_CONTROL;
		buffer_push_uint8(buffer, NRPC_RESET);
		stack_buffer_push(buffer);
	}
	LED2_ON();
	vTaskDelay(500 / portTICK_RATE_MS );	
	LED2_OFF();

	for( ;; )
	{
		vTaskDelay(5000 / portTICK_RATE_MS );
	}
}

