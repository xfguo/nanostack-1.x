/*
    NanoStack: MCU software and PC tools for sensor networking.
		
    Copyright (C) 2006-2007 Sensinode Ltd.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

		Address:
		Sensinode Ltd.
		PO Box 1
		90571 Oulu, Finland

		E-mail:
		info@sensinode.com
*/


/**
 *
 * \file main.c
 * \brief 6lowpan Interop Level 0 and Level 1 Terminal
 *
 */

/* Standard includes. */
#include <stdlib.h>
#include <signal.h>
#include <string.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

#include "bus.h"
#include "gpio.h"

#include "debug.h"

static void v6lowpan_interop( void *pvParameters );
#include "socket.h"
#include "rf.h"
#include "stack.h"
#include "control_message.h"
#include "neighbor_routing_table.h"

portCHAR check_udp_socket(buffer_t *buffer);
portCHAR check_icmp_socket(buffer_t *buffer);

extern sockaddr_t mac_long;
sockaddr_t udp_echo_response_address = 
	{
		ADDR_802_15_4_PAN_LONG,
		{ 0x00, 0x00, 0x01, 0x00, 
		0x00, 0x00, 0x00, 0x01, 0x00, 0x00 },
		45
	};

	sockaddr_t control_address = 
	{
		ADDR_NONE,
		{ 0x00, 0x00, 0x00, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00 },
		MAC_CTRL_PORT
	};
	sockaddr_t icmp_control_address = 
	{
		ADDR_NONE,
		{ 0x00, 0x00, 0x00, 0x00, 
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00 },
		ICMP_CTRL_PORT
	};

	/* Address to  Partner */
	sockaddr_t data_address = 
	{
		ADDR_802_15_4_PAN_SHORT,
		{ 0xFF, 0xFF, 0xFF, 0xFF, 
		0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF },
		UDP_ECHO_PORT
	};

	sockaddr_t unicast_address = 
	{
		ADDR_802_15_4_PAN_LONG,
		{ 0xFF, 0xFF, 0xFF, 0xFF, 
		0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF },
		UDP_ECHO_PORT
	};


/* Main */
int main( void )
{
	LED_INIT();
	if (bus_init() == pdFALSE)
	{
	}	
	LED1_ON();

	xTaskCreate( v6lowpan_interop, "Term",356 , NULL, ( tskIDLE_PRIORITY + 1 ), NULL );	
	vTaskStartScheduler();
	return 0;
}


socket_t *udp_echo_socket=0, *icmp_control=0, *mac_control=0;
portTickType ping_start;

/*-----------------------------------------------------------*/
typedef uint8_t b1w_reg[8];
/**
 *	Application simple_6lowpan task. Handles commands triggered by debug
 *  	UART interface. Task open automatic socket for data transmissio, receive and one for control-message.
 * 	Note control-socket bind want to address type ADDR_NONE!!!
 *	
 *	Available commands:
 *	m - get mac address by using control-message
 *	c - get current channel by using control-message
 *	C - increase the channel
 *  p - send ping a broadcast, only for neighbor
 *  P - send ping a broadcast multi hop
 *  r - Give unicast MAC address
 *  b - Broadcast mode
 *  B - Unicast mode
 *	+ - Increase Transmit power 10 %
 *	- - Decrease Transmit power 10 %
 *
 *	\param pvParameters not used
 *
 */
static void v6lowpan_interop( void *pvParameters )
{
	
	buffer_t *buffer;
	buffer_t *data;
	control_message_t *msg;
	int16_t byte;
	uint8_t i=0, ind=0, channel=0, tmp_8=0, j=0, unicast=0, unicast_writed=0;
	uint8_t tx_power=CC2420_DEFAULT_POWER, compres_mode=0, echo_req=0;
	uint16_t test=0, echo_sqn=0;
	buffer = 0;
	data=0;
	channel = CC2420_DEFAULT_CHANNEL;


	pause(200);
	debug_init(115200);
	pause(300);


	debug("Init:\r\n");
	vTaskDelay(300/portTICK_RATE_MS);	
	stack_init();
	debug("Init done.\r\n");
	vTaskDelay(200/portTICK_RATE_MS);	
	/* Temp init variable */
	{
		stack_init_t stack_rules;
		start_status_t status;
		memset(stack_rules.mac_address, (uint8_t) 0, 8);

		stack_rules.channel = channel;
		stack_rules.type = AD_HOC_DEVICE;
		for(i=0; i<8; i++)
		{
			stack_rules.mac_address[i] = mac_long.address[i];
		}
		debug("Start.\r\n");
		vTaskDelay(300/portTICK_RATE_MS);
		status = stack_start(&stack_rules);
		if(status==START_SUCCESS)
		{
			debug("Start Ok\r\n");
		}
	}




	udp_echo_socket = socket(MODULE_CUDP, &check_udp_socket);
	mac_control		= socket(MODULE_RF_802_15_4, 	0);
	icmp_control 	= socket(MODULE_ICMP,	&check_icmp_socket);

	if (icmp_control)
	{
		if (socket_bind(icmp_control, &icmp_control_address) != pdTRUE) debug("Bind fail icmp.\r\n");
	}

	if (udp_echo_socket)
	{
		if (socket_bind(udp_echo_socket, &udp_echo_response_address) != pdTRUE) debug("Bind fail udp.\r\n");
	}
	
	if (mac_control)
	{
		if (socket_bind(mac_control, &control_address) != pdTRUE) debug("Bind fail mac.\r\n");							
	}
	cipv6_compress_mode(0);

	for( ;; )
	{
		byte = debug_read_blocking(20);
		if(byte != -1)
		{
			switch(byte)
			{
	
				case 'h':
					{
						debug("\r\nHelp:\r\n+ - Increase Tx Power\r\n- - Decrease Tx Power\r\nm - Show MAC address\r\n");
						debug("p - Send ICMP Echo req\r\nu - Send UDP Echo req \r\n");
						debug("b - Broadcast mode\r\nB - Unicast mode \r\n");
						debug("c - Show current channel \r\nC - Change channel \r\n");
						debug("0 - Set interop level 0\r\n1 - Set interop level 1\r\n");
						debug("r - Give unicast MAC address\r\n");
					}
					break;
	
				case 'c':
					if(mac_control)
					{
						buffer_t *buf = socket_buffer_get(mac_control);
						if (buf)
						{
							buf->options.type = BUFFER_CONTROL;
							msg = ( control_message_t*) buf->buf;
							msg->message.mac_control.message_id = GET_REQ;
							msg->message.mac_control.message.get_attribute_req = MAC_CURRENT_CHANNEL;
							if (socket_sendto(mac_control, &control_address, buf) == pdTRUE)
							{
								debug("Current channel: ");
							}
							else
							{
								debug("Control send failed.\r\n");
								socket_buffer_free(buf);
								buf=0;
							}
						}
					}
					break;
		
				case 'C':
					if(channel==26) channel=11;
					else channel++;

					if(mac_control)
					{
						buffer_t *buf = socket_buffer_get(mac_control);
						if (buf)
						{
							buf->options.type = BUFFER_CONTROL;
							msg = ( control_message_t*) buf->buf;
							msg->message.mac_control.message_id = SET_REQ;
							msg->message.mac_control.message.set_req.pib_attribute = MAC_CURRENT_CHANNEL;
							msg->message.mac_control.message.set_req.atribute_value[0] = channel;
							if (socket_sendto(mac_control, &control_address, buf) == pdTRUE)
							{
								debug_printf("Channel changed to %d ", channel);
							}
							else
							{
								debug("Control send failed.\r\n");
								socket_buffer_free(buf);
								buf=0;
							}
						}
					}
					break;
	
				case 'm':
					if(mac_control)
					{
						buffer_t *buf = socket_buffer_get(mac_control);
						if (buf)
						{
							buf->options.type = BUFFER_CONTROL;
							msg = ( control_message_t*) buf->buf;
							msg->message.mac_control.message_id = GET_REQ;
							msg->message.mac_control.message.get_attribute_req = MAC_IEEE_ADDRESS;
							if (socket_sendto(mac_control, &control_address, buf) == pdTRUE)
							{
								debug("MAC address: ");
								buf=0;
							}
							else
							{
								debug("Control send failed.\r\n");
								socket_buffer_free(buf);
								buf=0;
							}
						}
						
					}
					break;

					case 'u':
					if(udp_echo_socket && echo_req==0)
					{
						buffer_t *buf = socket_buffer_get(udp_echo_socket);
						if (buf)
						{
							buf->buf_end=0;
							buf->buf_ptr=0;
							buf->options.lowpan_compressed=compres_mode;
							buf->options.hop_count = 1;
							buf->buf[buf->buf_end++] = (test >> 8);
							buf->buf[buf->buf_end++] = (uint8_t) test;
							buf->buf[buf->buf_end++] = (test >> 8);
							buf->buf[buf->buf_end++] = (uint8_t) test;
							buf->buf[buf->buf_end++] = 0xff;
							buf->options.hop_count =5;
							//data_address.port=7;
							if(unicast==0)
							{
								if (socket_sendto(udp_echo_socket, &data_address, buf) == pdTRUE)
								{
									ping_start = xTaskGetTickCount();
									echo_req=1;
									debug_printf("UDP Echo req, seq=%2.2X\r\n", test);
									debug("Dest: Broadcast\r\n");
									test++;
								}
							}
							else
							{
								if (socket_sendto(udp_echo_socket, &unicast_address, buf) == pdTRUE)
								{
									ping_start = xTaskGetTickCount();
									echo_req=1;
									debug_printf("UDP Echo req, seq=%2.2X\r\n", test);
									debug("Dest: Unicast\r\n");
									test++;
								}
							}
						}
					}
					break;

				case 'p':
					if(icmp_control && echo_req==0)
					{
						buffer_t *buf = socket_buffer_get(icmp_control);
						if (buf)
						{
							buf->buf_end=0;
							buf->buf_ptr=0;
							buf->options.lowpan_compressed=compres_mode;
							buf->options.type = BUFFER_CONTROL;
							msg = ( control_message_t*) buf->buf;
							msg->message.ip_control.message_id = ECHO_REQ;
							msg->message.ip_control.message.ip_icmp_echo_req.echo_req_sqn =echo_sqn;
							msg->message.ip_control.message.ip_icmp_echo_req.echo_req_id = 0;
							msg->message.ip_control.message.ip_icmp_echo_req.data_length=6;
							msg->message.ip_control.message.ip_icmp_echo_req.echo_data[0] =0xdd;
							msg->message.ip_control.message.ip_icmp_echo_req.echo_data[1] =0xdd;
							msg->message.ip_control.message.ip_icmp_echo_req.echo_data[2] =0xdd;
							msg->message.ip_control.message.ip_icmp_echo_req.echo_data[3] =0xdd;
							msg->message.ip_control.message.ip_icmp_echo_req.echo_data[4] =0xdd;
							msg->message.ip_control.message.ip_icmp_echo_req.echo_data[5] =0xdd;

							buf->options.hop_count =5;
							if(unicast==0)
								msg->message.ip_control.message.ip_icmp_echo_req.unicast_address = 0;
							else
							{
								memcpy(&buf->dst_sa,&unicast_address, sizeof(sockaddr_t));
								msg->message.ip_control.message.ip_icmp_echo_req.unicast_address = 1;
							}
							if (socket_sendto(icmp_control, &control_address, buf) == pdTRUE)
							{
								ping_start = xTaskGetTickCount();
								echo_req=1;
								debug_printf("ICMP Echo req, seq=%2.2X\r\n", echo_sqn);
								if(unicast==0)
								{
									debug("Dest: Broadcast\r\n");
								}
								else
								{
									debug("Dest: Unicast\r\n");
								}
								echo_sqn++;
							}
						}
					}
					break;
				case 'b':	
					unicast = 0;
					debug("6lowpan-interop Broadcast-mode\r\n");
					break;

				case 'B':
					if(unicast_writed==1)
					{
						unicast = 1;
						debug("6lowpan-interop Unicast-mode\r\n");
					}
					else
						debug("Press r & give MAC address\r\n");
					break;

				case '1':
					cipv6_compress_mode(1);
					cudp_compress_mode(1);	
					if(compres_mode !=1) compres_mode=1;
					debug("6lowpan-interop Level 1\r\n");
					break;

				case '0':
					cipv6_compress_mode(0);
					cudp_compress_mode(0);	
					if(compres_mode !=0) compres_mode=0;;
					debug("6lowpan-interop Level 0\r\n");
					break;
					
				case '+':	
					if(tx_power==100)
					{
						debug("Max Tx power set up.\r\n");
					}
					else
					{
						tx_power += 10;
						rf_power_set(tx_power);
						debug_printf("Increace Tx power, current state %d.\r\n", tx_power);
					}
					break;

				case '-':	
					if(tx_power==10)
					{
						debug("Min Tx power set up 10.\r\n");
					}
					else
					{
						tx_power -= 10;
						rf_power_set(tx_power);
						debug_printf("Decreace Tx power, current state %d.\r\n", tx_power);
					}
					break;

				case 'r':
					ind=2;
					j=0;
					debug("Push MAC address MSB first!\r\n");
					while(j!=8)
					{
						byte = debug_read_blocking(20);
						if(byte != -1)
						{
							if((byte >=0x30 && byte <=0x39) || (byte >=0x61 && byte <=0x66) || (byte >=0x41 && byte <=0x46))
							{
								if(byte >=0x30 && byte <=0x39)
									byte -=0x30;
								else if(byte >=0x60 && byte <=0x66)
									byte -=0x57;
								else
									byte -=0x37;

								if(ind==2)
								{
								 tmp_8 = (uint8_t) byte;
								 tmp_8 <<= 4;
								 ind--;
								}
								else
								{
									byte &= 0x0f;
									tmp_8 |= ((uint8_t) byte);
									ind=0;
									i= (7-j);
									unicast_address.address[i] = tmp_8;
									debug_hex(tmp_8);
									if(i) debug(":");
									ind=2;
									j++;
								}
							}
						}
					}
					debug("\r\n");
					/* Add device to neighbourtable */
					i=update_neighbour_table(unicast_address.addr_type, unicast_address.address, 120, 0xff);

					unicast=1;
					unicast_writed=1;
					break;

	
				default:
					debug("\r\nNanoStack[20070710] 6lowpan-interop - Press h for help.\r\n\r\n");
					break;
			}	
		}
		
		if(mac_control)
		{
			buffer = socket_read(mac_control, 5);
			if(buffer)
			{
				msg = ( control_message_t*) buffer->buf;
				if(msg->message.mac_control.message_id == GET_CONFIRM)
				{
					if( msg->message.mac_control.message.get_confirm.pib_attribute == MAC_CURRENT_CHANNEL)
					{
						debug_int(msg->message.mac_control.message.get_confirm.atribute_value[0]);
						debug("\r\n");
					}
					if( msg->message.mac_control.message.get_confirm.pib_attribute == MAC_IEEE_ADDRESS)
					{
						for(i=0; i< 8 ;i++)
						{
							if(i)debug(":");
							debug_hex(msg->message.mac_control.message.get_confirm.atribute_value[7-i]);
						}
						debug("\r\n");
					}
				}
				if(msg->message.mac_control.message_id == SET_CONFIRM)
				{
					if( msg->message.mac_control.message.set_confirm.pib_attribute == MAC_CURRENT_CHANNEL && msg->message.mac_control.message.set_confirm.status==1)
					{
						debug("...OK\r\n");
					}
					else
					{
						debug("...Not supported value\r\n");
					}
				}
				socket_buffer_free(buffer);
				buffer = 0;	
			}
		}
		if ((xTaskGetTickCount() - ping_start)*portTICK_RATE_MS > 500 && echo_req) echo_req = 0;
	}
}



portCHAR check_udp_socket(buffer_t *buffer)
{
	uint8_t length, ind;
	uint16_t response_sqn=0;
	portTickType ping_ticks=0;
	ping_ticks = xTaskGetTickCount() - ping_start;
	if (buffer)
	{
		length = buffer->buf_end - buffer->buf_ptr;
		if (buffer->dst_sa.port == 45)
		{
			ind=buffer->buf_ptr;
			response_sqn =( buffer->buf[ind++] << 8 );
			response_sqn +=( buffer->buf[ind++]);
			debug_printf("UDP Echo response, seq=%2.2X, time %d ms,  %d dBm ",response_sqn, ping_ticks, buffer->options.rf_dbm);
			debug("\r\n");
			debug("SRC ");
			/*if(buffer->src_sa.addr_type==ADDR_802_15_4_PAN_LONG)
			{
				addres_length=8;
				s=7;
			}
			else
			{
				addres_length=2;
				s=1;
			}
			for (i=0; i<addres_length; i++)
			{
				if (i) debug(":");
				debug_hex(buffer->src_sa.address[s-i]);
			}*/
			debug_address(&(buffer->src_sa));
			debug("\r\n");
		}
		socket_buffer_free(buffer);
		buffer = 0;
	}
	return pdTRUE;
}

portCHAR check_icmp_socket(buffer_t *buffer)
{
	//uint8_t i, addres_length,s;
	uint16_t response_sqn=0;
	portTickType ping_ticks=0;
	ping_ticks = xTaskGetTickCount() - ping_start;
	if(buffer)
	{
		control_message_t *tmp_msg = ( control_message_t*) buffer->buf;
		if(tmp_msg->message.ip_control.message_id == ECHO_RES)
		{
			response_sqn =tmp_msg->message.ip_control.message.echo_response;
			debug_printf("ICMP Echo response, seq=%2.2X, time %d ms,  %d dBm ",response_sqn, ping_ticks, buffer->options.rf_dbm);
			debug("\r\n");
			debug("SRC ");
			/*if(buffer->src_sa.addr_type==ADDR_802_15_4_PAN_LONG)
			{
				addres_length=8;
				s=7;
			}
			else
			{
				addres_length=2;
				s=1;
			}
			for (i=0; i<addres_length; i++)
			{
				if (i) debug(":");
				debug_hex(buffer->src_sa.address[s-i]);
			}*/
			debug_address(&(buffer->src_sa));
			debug("\r\n");
		}
		else if(tmp_msg->message.ip_control.message_id == ROUTER_DISCOVER_RESPONSE)
		{
			/*if(tmp_msg->message.ip_control.message.router_discover_response.address_type==ADDR_802_15_4_PAN_LONG)
			{
				addres_length=8;
				s=7;
			}
			else
			{
				addres_length=2;
				s=1;
			}
			for (i=0; i<addres_length; i++)
			{
				if (i) debug(":");
				debug_hex(buffer->src_sa.address[s-i]);
			}*/
			debug_address(&(buffer->src_sa));
			debug("\r\n");
			debug_int(tmp_msg->message.ip_control.message.router_discover_response.hop_distance);
			debug(" Hop distance\r\n");
		}
		else
		{
	
		}
		socket_buffer_free(buffer);
		buffer = 0;	
	}
	return pdTRUE;
}

