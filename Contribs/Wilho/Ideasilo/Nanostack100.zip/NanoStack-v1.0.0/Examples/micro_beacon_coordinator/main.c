/*
    NanoStack: MCU software and PC tools for sensor networking.
		
    Copyright (C) 2006-2007 Sensinode Ltd.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

		Address:
		Sensinode Ltd.
		PO Box 1
		90571 Oulu, Finland

		E-mail:
		info@sensinode.com
*/


/**
 *
 * \file main.c
 * \brief Example for testing beacon enable mode Coordinator device. Coordinator handle client Assocation request and buffer their sended data to own data buffer. When coordinator has discovered gateway it send data buffer to gateway when buffer is full. 
 *
 */

/* Standard includes. */
#include <stdlib.h>
#include <signal.h>
#include <string.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

#include "bus.h"
#include "gpio.h"
#include "debug.h"

static void vmicro_beacon_server( void *pvParameters );

#include "socket.h"
#include "rf.h"
#include "control_message.h"
#include "neighbor_routing_table.h"

#define DATA_BUFFER_LENGTH 59
extern xQueueHandle     buffers;
extern sockaddr_t mac_long;

sockaddr_t control_address = 
{
	ADDR_NONE,
	{ 0x00, 0x00, 0x00, 0x00, 
	  0x00, 0x00, 0x00, 0x00, 0x00, 0x00 },
	ICMP_CTRL_PORT
};
sockaddr_t pending = 
{
	ADDR_NONE,
	{ 0x00, 0x00, 0x00, 0x00, 
	  0x00, 0x00, 0x00, 0x00, 0x00, 0x00 },
	MAC_CTRL_PORT
};

sockaddr_t datasensor_address = 
{
	ADDR_802_15_4_PAN_SHORT,
	{ 0x00, 0x00, 0x00, 0x00},
	61619
};

sockaddr_t data_address = 
{
	ADDR_802_15_4_PAN_SHORT,
	{ 0xff, 0xff, 0xff, 0xff},
	7
};


/* Here goes the code */
int main( void )
{
	LED_INIT();
	if (bus_init() == pdFALSE)
	{
	}	
	LED1_ON();
	xTaskCreate( vmicro_beacon_server, "cord", 250, NULL, ( tskIDLE_PRIORITY + 2 ), NULL );	
	vTaskStartScheduler();
	return 0;
}
/*-----------------------------------------------------------*/
typedef uint8_t b1w_reg[8];

uint8_t data_buffer[DATA_BUFFER_LENGTH], data_pac_index=0;
uint8_t data_proxy[DATA_BUFFER_LENGTH], data_proxy_index, data_proxy_send=0;


/**
 *	Application coordinator_6lowpan task. Handles commands triggered by debug
 *  	UART interface. Task open automatic socket for data transmissio, receive and one for control-message.
 * 	Note control-socket bind want to address type ADDR_NONE!!!
 *	
 *	Available commands:
 *	m - get mac address by using control-message
 *	c - get current channel by using control-message
 *  p - send a broadcast discover message
 *	d - send data to discover device
 *
 *	\param pvParameters not used
 *
 */
static void vmicro_beacon_server( void *pvParameters )
{
	gateway_cache_t gateway_info;
	gateway_info.count=0;

	int16_t byte;
	uint16_t tx_sqn=0, echo_sqn=0, test=0, channel=PAN_CHANNEL;
	uint8_t i=0, j,gw_index;
	uint8_t tx_power=CC2420_DEFAULT_POWER;
	uint8_t length, ind, rx_router_adv=0;

	uint8_t addres_length=0;
	portTickType xLastWakeTime;
	int8_t discover_active=0;
	portTickType discover_start;
	buffer_t *buffer;
	buffer_t *data;
	socket_t *mac_control=0, *data_soc=0, *icmp_control=0;
	control_message_t *msg;
	control_message_t *tmp_msg;


	buffer = 0;
	data=0;
	pause(200);
	debug_init(115200);
	pause(300);


	debug("Init:\r\n");
	vTaskDelay(300/portTICK_RATE_MS);	
	stack_init();
	debug("Init done.\r\n");
	vTaskDelay(200/portTICK_RATE_MS);	
	/* Temp init variable */
	{
		stack_init_t stack_rules;
		start_status_t status;
		memset(stack_rules.mac_address, (uint8_t) 0, 8);

		stack_rules.channel = PAN_CHANNEL;
		stack_rules.type = BEACON_ENABLE_COORDINATOR;
		for(i=0; i<8; i++)
		{
			stack_rules.mac_address[i] = mac_long.address[i];
		}

		stack_rules.short_address[0] = (SHORT_ADDRESS & 0xff);
		stack_rules.short_address[1] = (SHORT_ADDRESS >> 8);
		stack_rules.pan_id[0] = (PAN_ID & 0xff);
		stack_rules.pan_id[1] = (PAN_ID >> 8);
		stack_rules.pending_ttl_time = 5;

		debug("Start.\r\n");
		vTaskDelay(300/portTICK_RATE_MS);
		status = stack_start(&stack_rules);
		if(status==START_SUCCESS)
		{
			debug("Start Ok\r\n");
		}
	}
/*****************************************************************************************************/

/****************************************************************************************************/


	debug("Coordinator device 1.0\r\n\r\n");
	
	data_soc 			= socket(MODULE_CUDP, 		0);	/* Socket for response data from port number 45 */
	mac_control 		= socket(MODULE_RF_802_15_4, 	0);	/* Socket for send and receive control message to MAC-layer */
	icmp_control 		= socket(MODULE_ICMP, 		0);

	if (icmp_control)
	{
		if (socket_bind(icmp_control, &control_address) != pdTRUE)
			debug("Bind fail icmp.\r\n");
	}

	if (data_soc)
	{
		if (socket_bind(data_soc, &datasensor_address) != pdTRUE)
			debug("Bind fail rx.\r\n");					
	}
	
	if (mac_control)
	{
		if (socket_bind(mac_control, &pending) != pdTRUE)
			debug("Bind fail mac ctr.\r\n");					
	}
	/* Use compressed IP & UDP mode */
	cipv6_compress_mode(1);
	cudp_compress_mode(1);
	
	for( ;; )
	{
		if(xLastWakeTime==0) xLastWakeTime = xTaskGetTickCount();
		
		if ((xTaskGetTickCount() - xLastWakeTime)*portTICK_RATE_MS > 10000)
		{
			gw_index = gateway_info.count;
			if(gw_index)
			{
				/*Check first cache*/
				for(i=0; i<gw_index;i++)
				{
					if(gateway_info.gateway_info[i].ttl > 1)
						gateway_info.gateway_info[i].ttl--;
					else
					{
						if(i==0)
						{
							j=i;
							j++;
							for(ind=0; ind<2;ind++)
							{
								gateway_info.gateway_info[i].address[ind] = gateway_info.gateway_info[j].address[ind];
								gateway_info.gateway_info[i].ttl = gateway_info.gateway_info[j].ttl;
								gateway_info.gateway_info[i].lqi =gateway_info.gateway_info[j].lqi;
							}
						}
						i=gateway_info.count;
						gateway_info.count--;
					}
				}
			}
			xLastWakeTime=0;
		}

		byte = debug_read_blocking(20);
		if(byte != -1)
		{
			switch(byte)
			{
				case 'b':
					debug_int(uxQueueMessagesWaiting(buffers));
					debug(" buffers available.\r\n");
					break;	
	
				case 'g':
					if(icmp_control && discover_active==0)
					{
						buffer_t *buf = socket_buffer_get(icmp_control);
						if (buf)
						{
							discover_active=1;
							rx_router_adv=0;
							buf->options.type = BUFFER_CONTROL;
							buf->options.hop_count = 5;
							msg = ( control_message_t*) buf->buf;
							msg->message.ip_control.message_id = ROUTER_DISCOVER;
							if (socket_sendto(icmp_control, &control_address, buf) == pdTRUE) {}
						}
					}
					break;

				case 'm':
					if(mac_control)
					{
						buffer_t *buf = socket_buffer_get(mac_control);
						if (buf)
						{
							buf->options.type = BUFFER_CONTROL;
							msg = ( control_message_t*) buf->buf;
							msg->message.mac_control.message_id = GET_REQ;
							msg->message.mac_control.message.get_attribute_req = MAC_IEEE_ADDRESS;
							if (socket_sendto(mac_control, &pending, buf) == pdTRUE)
							{
								debug("GET devices mac-address from MAC-PIB: ");
								buf=0;
							}
							else
							{
								debug("Control send failed.\r\n");
								socket_buffer_free(buf);
								buf=0;
							}
						}
						else
						{
							debug("No buffer.\r\n");
						}
						
					}
					break;

				case 'c':
					if(mac_control)
					{
						buffer_t *buf = socket_buffer_get(mac_control);
						if (buf)
						{
							buf->options.type = BUFFER_CONTROL;
							msg = ( control_message_t*) buf->buf;
							msg->message.mac_control.message_id = GET_REQ;
							msg->message.mac_control.message.get_attribute_req = MAC_CURRENT_CHANNEL;
							if (socket_sendto(mac_control, &pending, buf) == pdTRUE)
							{
								debug("GET current channel from MAC-PIB: ");
							}
							else
							{
								debug("Control send failed.\r\n");
								socket_buffer_free(buf);
								buf=0;
							}
						}
						else
						{
							debug("No buffer.\r\n");
						}
					}
					break;

				case 'p':
					if(icmp_control)
					{
						buffer_t *buf = socket_buffer_get(icmp_control);
						if (buf)
						{
							buf->buf_end=0;
							buf->buf_ptr=0;
							buf->options.type = BUFFER_CONTROL;
							msg = ( control_message_t*) buf->buf;
							msg->message.ip_control.message_id = ECHO_REQ;
							msg->message.ip_control.message.ip_icmp_echo_req.echo_req_sqn =echo_sqn;
							msg->message.ip_control.message.ip_icmp_echo_req.echo_req_id = 0;
							msg->message.ip_control.message.ip_icmp_echo_req.unicast_address=0;
							msg->message.ip_control.message.ip_icmp_echo_req.data_length=0;
							buf->options.hop_count = 5;
							if (socket_sendto(icmp_control, &control_address, buf) == pdTRUE)
							{
								debug("echo req\r\n");
								echo_sqn++;
							}
						}
					}
					break;

				case 'C':
					if(channel==26) channel=11;
					else channel++;

					if(mac_control)
					{
						buffer_t *buf = socket_buffer_get(mac_control);
						if (buf)
						{
							buf->options.type = BUFFER_CONTROL;
							msg = ( control_message_t*) buf->buf;
							msg->message.mac_control.message_id = SET_REQ;
							msg->message.mac_control.message.set_req.pib_attribute = MAC_CURRENT_CHANNEL;
							msg->message.mac_control.message.set_req.atribute_value[0] = channel;
							if (socket_sendto(mac_control, &control_address, buf) == pdTRUE)
							{
								debug_printf("Channel changed to %d ", channel);
							}
							else
							{
								debug("Control send failed.\r\n");
								socket_buffer_free(buf);
								buf=0;
							}
						}
					}
					break;

				case 'u':
					if(data_soc)
					{
						buffer_t *buf = socket_buffer_get(data_soc);
						if (buf)
						{
							buf->buf_end=0;
							buf->buf_ptr=0;
							buf->options.hop_count = 1;
							buf->buf[buf->buf_end++] = 0x15;
							buf->buf[buf->buf_end++] = (test >> 8);
							buf->buf[buf->buf_end++] = (uint8_t) test;
							buf->buf[buf->buf_end++] = 0x55;
							buf->buf[buf->buf_end++] = 0xff;
							buf->buf[buf->buf_end++] = 0xcc;
							buf->options.hop_count =5;
							if (socket_sendto(data_soc, &data_address, buf) == pdTRUE)
							{
								debug("udp echo_req()\r\n");
								test++;
							}
						}
					}
					break;


				case 'P':
					if(mac_control)
					{
						buffer_t *buf = socket_buffer_get(mac_control);
						if (buf)
						{
							buf->buf_end=0;
							buf->buf_ptr=0;
							buf->dst_sa.addr_type = ADDR_NONE;
							buf->dst_sa.addr_type = ADDR_802_15_4_PAN_SHORT;
							buf->dst_sa.address[0]=0x11;
							buf->dst_sa.address[1]=0x11;
							buf->options.type = BUFFER_CONTROL;
							msg = ( control_message_t*) buf->buf;
							msg->message.mac_control.message_id = PEND_REQ;
							msg->message.mac_control.message.pending_data.type=1;
							msg->message.mac_control.message.pending_data.length=2;
							msg->message.mac_control.message.pending_data.pend_buffer[0] =  0x03;
							msg->message.mac_control.message.pending_data.pend_buffer[1] =  0xF0;
							if (socket_sendto(mac_control, &pending, buf) != pdTRUE)
							{
								debug("Pend_fail.\r\n");
								socket_buffer_free(buf);
								buf=0;
							}
						}
					}
					break;
	
				case '\r':
					
					debug("\r\n");
					break;

				case 't':
					print_table_information();
					if(gateway_info.count)
					{
						/*Check first cache*/
						for(i=0; i<gateway_info.count;i++)
						{
							debug("\r\nGW addr:");
							if(gateway_info.gateway_info[i].address_type==ADDR_802_15_4_PAN_LONG)
								addres_length=8;
							else
								addres_length=2;
							for(j=0; j < addres_length ; j++)
							{
								if (j) debug_put(':');
								debug_hex(gateway_info.gateway_info[i].address[j]);
							}
							debug("\r\nHops:");
							debug_hex(gateway_info.gateway_info[i].hop_distance);
							debug("\r\nLQI:");
							debug_hex(gateway_info.gateway_info[i].lqi);
							debug("\r\nTTL:");
							debug_hex(gateway_info.gateway_info[i].ttl);
							debug("\r\n");
						}
					}
					break;

				case '+':	
					if(tx_power==100)
					{
						debug("Max Tx power set up.\r\n");
					}
					else
					{
						tx_power += 10;
						rf_power_set(tx_power);
						debug_printf("Increace Tx power, current state %d.\r\n", tx_power);
					}
					break;

				case '-':	
					if(tx_power==10)
					{
						debug("Min Tx power set up 10.\r\n");
					}
					else
					{
						tx_power -= 10;
						rf_power_set(tx_power);
						debug_printf("Decreace Tx power, current state %d.\r\n", tx_power);
					}
					break;
				default:
					debug_put(byte);
					break;
			}	
		}
		if (data_soc)
		{
			data=0;
			data = socket_read(data_soc, 10);
			if (data)
			{
				ind=data->buf_ptr;
				if (data->dst_sa.port == 61619)
				{
					length = data->buf_end - data->buf_ptr;
					if (data->src_sa.port == 7)
					{
						debug("UDP Echo response\r\n");
						debug("SRC PAN-ID ");
						debug_address(&(data->src_sa));
						debug("\r\n");
					}
					else
					{
						length = data->buf_end - data->buf_ptr;
						if(length > 1)
						{
							if(gateway_info.count)
							{
								uint8_t temp;
								temp= (data_pac_index+length);
								temp +=2; /*css address 2 bytes */
								debug("Data PAC from PAN-ID ");
								debug_address(&(data->src_sa));
								debug("\r\n");
								if(temp < DATA_BUFFER_LENGTH)
								{
									data_buffer[data_pac_index++] = data->src_sa.address[0];
									data_buffer[data_pac_index++] = data->src_sa.address[1];
									for(i=0; i<length; i++)
									{
										data_buffer[data_pac_index++] = data->buf[ind++];
									}
								}
								else
								{
									buffer_t *buf = socket_buffer_get(data_soc);
									if(buf)
									{
										ind=buf->buf_end;
										buf->buf[ind++] = tx_sqn;
										data_proxy[0] = tx_sqn;
										data_proxy_index = data_pac_index;
										for(i=0; i< data_pac_index; i++)
										{
											buf->buf[ind++]=data_buffer[i];
											data_proxy[1+i]=data_buffer[i];
										}
										buf->buf_end=ind;
										data_pac_index=0;
										datasensor_address.port=61620;
										if (socket_sendto(data_soc, &datasensor_address, buf) == pdTRUE)
										{
											debug("Sensor data sended ,");	
											debug_int(tx_sqn);
											debug(" sqn\r\n");
											tx_sqn++;
										}
									}
									ind=data->buf_ptr;
									data_buffer[data_pac_index++] = data->src_sa.address[0];
									data_buffer[data_pac_index++] = data->src_sa.address[1];
									for(i=0; i<length; i++)
									{
										data_buffer[data_pac_index++] = data->buf[ind++];
									}
								}
							}
						}			
					}
				}
			}
			socket_buffer_free(data);
			data = 0;
		}
		if(mac_control)
		{
			
			buffer=0;
			buffer = socket_read(mac_control, 10);
			if(buffer)
			{
				msg = ( control_message_t*) buffer->buf;
				if(msg->message.mac_control.message_id == GET_CONFIRM)
				{
					if( msg->message.mac_control.message.get_confirm.pib_attribute == MAC_CURRENT_CHANNEL)
					{
						debug_int(msg->message.mac_control.message.get_confirm.atribute_value[0]);
						debug("\r\n");
					}
					if( msg->message.mac_control.message.get_confirm.pib_attribute == MAC_IEEE_ADDRESS)
					{
						for(i=0; i< 8 ;i++)
						{
							debug_hex(msg->message.mac_control.message.get_confirm.atribute_value[7-i]);
							debug(" ");
						}
						debug("\r\n");
					}
				}
				socket_buffer_free(buffer);
				buffer = 0;	
			}
		}
		if(icmp_control)
		{
			buffer=0;
			buffer = socket_read(icmp_control, 10);
			if(buffer)
			{
				tmp_msg = ( control_message_t*) buffer->buf;
				if(tmp_msg->message.ip_control.message_id == ROUTER_DISCOVER_RESPONSE)
				{
					rx_router_adv=1;
					uint8_t tmp_count, flag=1;
					if(tmp_msg->message.ip_control.message.router_discover_response.address_type==ADDR_802_15_4_PAN_LONG)
						addres_length=8;
					else
						addres_length=2;
					tmp_count = gateway_info.count;
					if(tmp_count)
					{
						/*Check first cache*/
						for(i=0; i<tmp_count;i++)
						{
							if(gateway_info.gateway_info[i].address_type == tmp_msg->message.ip_control.message.router_discover_response.address_type)
							{
								if(memcmp(gateway_info.gateway_info[i].address,tmp_msg->message.ip_control.message.router_discover_response.address,addres_length)==0)
								{
									gateway_info.gateway_info[i].lqi = tmp_msg->message.ip_control.message.router_discover_response.payload[1];
									gateway_info.gateway_info[i].ttl = 7;
									if(gateway_info.gateway_info[i].hop_distance!=tmp_msg->message.ip_control.message.router_discover_response.hop_distance)
										gateway_info.gateway_info[i].hop_distance = tmp_msg->message.ip_control.message.router_discover_response.hop_distance;

									flag=0; 
								}
							}
						}
					}
					if(flag)
					{
						gateway_info.gateway_info[tmp_count].address_type = tmp_msg->message.ip_control.message.router_discover_response.address_type;
						gateway_info.gateway_info[tmp_count].hop_distance = tmp_msg->message.ip_control.message.router_discover_response.hop_distance;
						gateway_info.gateway_info[tmp_count].lqi = tmp_msg->message.ip_control.message.router_discover_response.payload[1];
						gateway_info.gateway_info[tmp_count].ttl = 7;
						for(i=0;i<addres_length;i++)
						{
							gateway_info.gateway_info[tmp_count].address[i]=tmp_msg->message.ip_control.message.router_discover_response.address[i];
						}
						
						tmp_count++;
						gateway_info.count=tmp_count;
					}
					/* Check best gateway */
					if(gateway_info.count==1) gw_index=0;
					else
					{
						/* Compare Hop distance */
						if(gateway_info.gateway_info[0].hop_distance != gateway_info.gateway_info[1].hop_distance)
						{
							if(gateway_info.gateway_info[0].hop_distance < gateway_info.gateway_info[1].hop_distance) gw_index=0;
							else gw_index=1;
						}
						else
						{
							/* Compare LQI values */
							if(gateway_info.gateway_info[0].lqi > gateway_info.gateway_info[1].lqi) gw_index=0;
							else gw_index=1;
						}
					}
					for(i=0; i < 2; i++)
					{
						datasensor_address.address[i] = gateway_info.gateway_info[gw_index].address[i];
					}
					if(data_proxy_send)
					{
						debug("Response from gw\r\n");
						buffer->socket = 0;
						buffer->buf_end = 0;
						buffer->buf_ptr = 0;
						buffer->options.type = BUFFER_DATA;
						ind=buffer->buf_end;
						for(i=0; i< data_proxy_index; i++)
						{
							buffer->buf[ind++]=data_proxy[i];
						}
						buffer->buf_end=ind;
						data_proxy_index=0;
						datasensor_address.port=61620;
						if (socket_sendto(data_soc, &datasensor_address, buffer) == pdTRUE)
						{	
							debug_int(data_proxy[0]);
							debug(" re-tx sqn\r\n");
							buffer=0;
						}
						data_proxy_send=0;
					}


					if(buffer)
					{
						socket_buffer_free(buffer);
						buffer = 0;
					}
				}
				else if(tmp_msg->message.ip_control.message_id == ECHO_RES)
				{
					debug_printf("ICMP Echo response,  %d dBm ", buffer->options.rf_dbm);
					debug("\r\n");
					debug("SRC PAN-ID ");
					debug_address(&(buffer->src_sa));
					debug("\r\n");

					socket_buffer_free(buffer);
					buffer = 0;
				}
				else if(tmp_msg->message.ip_control.message_id == BROKEN_LINK)
				{
					debug("Route broken to ");
					debug("\r\n");
					buffer->dst_sa.addr_type = tmp_msg->message.ip_control.message.broken_link_detect.type;
					debug_address(&(buffer->dst_sa));
					debug("\r\n");
					/* Remove broken link */
					if(gateway_info.count)
					{
						for(i=0; i<gateway_info.count; i++)
						{
							if(memcmp(gateway_info.gateway_info[i].address, buffer->dst_sa.address, 2)==0)
							{
								gateway_info.gateway_info[i].address[0]=0x00;
								gateway_info.gateway_info[i].address[1]=0x00;
								gateway_info.gateway_info[i].lqi =0x00;
								gateway_info.gateway_info[i].hop_distance=0x00;
								gateway_info.count--;
							}
						}
					}
					buffer->socket = 0;
					buffer->buf_end = 0;
					buffer->buf_ptr = 0;
					buffer->options.type = BUFFER_CONTROL;
					buffer->options.hop_count = 5;
					msg = ( control_message_t*) buffer->buf;
					msg->message.ip_control.message_id = ROUTER_DISCOVER;
					data_proxy_send=1;
					if (socket_sendto(icmp_control, &control_address, buffer) == pdTRUE)
					{
						buffer=0;
					}
				}
				else
				{
					socket_buffer_free(buffer);
					buffer = 0;
				}
			}
		}
		if ((xTaskGetTickCount() - discover_start)*portTICK_RATE_MS > 1000 && discover_active)
		{
			if(rx_router_adv)
			{
				debug("ok.\r\n");
				rx_router_adv=0;
			}
			else
				rx_router_adv=0;

			discover_active = 0;
		}
		if(discover_active==0)
		{
			vTaskDelay(10/ portTICK_RATE_MS);
		}
	}
}

