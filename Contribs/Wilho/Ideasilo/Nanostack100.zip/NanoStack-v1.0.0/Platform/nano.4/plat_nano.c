/**
 *
 * \file     plat_nano.c
 * \brief    Embryo port for nano.
 *
 *  The Embedded Realtime yielding Operating System.
 *  Port for Sensinode nano series.
 */

/* 
 LICENSE_HEADER
 */

/*
 * This macro pushes the context into the stack. 
 */
#define platform_PUSH()	\
{							\
		_asm			\
		push	ACC	\
		/* Store the IE register state*/	\
		push	IE  \
		clr		_EA \
		push	b		\
		push	ar0	\
		push	ar1	\
		push	ar2	\
		push	ar3	\
		push	ar4	\
		push	ar5	\
		push	ar6	\
		push	ar7	\
		push	DPL	\
		push	DPH	\
		push	PSW	\
	_endasm;		\
		PSW = 0;	\
	_asm				\
		push	_bp	\
	_endasm;		\
}

/*
 * This macro pulls the context from the stack. 
 */
#define platform_PULL()		\
{								\
		_asm        \
		pop		_bp  	\
		pop		PSW		\
		pop		DPH		\
		pop		DPL		\
		pop		ar7		\
		pop		ar6		\
		pop		ar5		\
		pop		ar4		\
		pop		ar3		\
		pop		ar2		\
		pop		ar1		\
		pop		ar0		\
		pop		b			\
		/* Restore state of the IE register. */ \
		pop		ACC		\
		JB		ACC.7,0100$	\
		CLR		IE.7	\
		LJMP	0101$	\
	0100$:				\
		SETB	IE.7  \
	0101$:				\
		pop		ACC		\
		reti				\
	_endasm;			\
}

/*variables for context switch*/
data static uint8_t sch_stack_size;

/* Used during a context switch to point to the next byte in XRAM from/to which
a RAM byte is to be copied. */
xdata static PLATFORM_STACK * data sch_stack_buffer;

/* Used during a context switch to point to the next byte in RAM from/to which
an XRAM byte is to be copied. */
data static PLATFORM_STACK * data sch_stack;


#define platform_STORE_STACK()																\
{																								\
	sch_stack_buffer = task_state[sch_current].stack_start;		\
	sch_stack = ( data PLATFORM_STACK * data ) platform_STACK_ADDR;								\
	sch_stack_size = SP - ( platform_STACK_ADDR - 1 );												\
	task_state[sch_current].stack_size = sch_stack_size;																							\
	while( sch_stack_size )																		\
	{																							\
		*sch_stack_buffer = *sch_stack;																\
		sch_stack_buffer++;																			\
		sch_stack++;																			\
		sch_stack_size--;																			\
	}																							\
}

#define platform_RESTORE_STACK()																\
{																								\
	sch_stack_buffer = task_state[sch_current].stack_start;		\
	sch_stack = ( data PLATFORM_STACK * data ) platform_STACK_ADDR;								\
	sch_stack_size = SP - ( platform_STACK_ADDR - 1 );												\
	task_state[sch_current].stack_size = sch_stack_size;																							\
	while( sch_stack_size )																		\
	{																							\
		*sch_stack = *sch_stack_buffer;																\
		sch_stack_buffer++;																			\
		sch_stack++;																			\
		sch_stack_size--;																			\
	}																							\
	SP = ( uint8_t ) sch_stack - 1;														\
}

void platform_init(void)
{
	LED_INIT();

	LED1_ON();
	LED2_ON();

	IEN0_EA = 1;

	CLKCON |= OSC32K;
	CLKCON &= ~(OSC | CLKSPD); /*Osc on*/

/*	platform_timer_setup(); moved to launch*/
}

/**
 * Initialize task stack to initial context
 *
 *	\param task pointer to task description
 *	\param state pointer to task state structure
 *	\param stack_ptr pointer to start of task stack
 */
void platform_stack_init(sch_task_t *task, sch_task_state_t *state, uint8_t *stack_ptr)
{
	uint16_t address;
	
	address = task->task_code;
	state->stack_start = stack_ptr;
	
	/*Store function address*/
	*stack_ptr++ = address;
	*stack_ptr++ = address >> 8;
	
	*stack_ptr++ = 0x00; 	/*ACC*/
	*stack_ptr++ = 0x80		/*Interrupts enabled*/
	
	stack_ptr += 1+8+2+2; /*b + ar0-7 + dpH-L + psw + bp*/
	state->stack_size = 4+1+8+2+2; /*size of the stack*/
}

/**
 * Task switching
 *
 */
void platform_switch(void) _naked
{
	platform_PUSH();
	{
		uint8_t task_id = sch_task_next();
		if (task_id != sch_current)
		{
			platfrom_STORE_STACK();
			sch_task_select(task_id);
			platfrom_RESTORE_STACK();
		}
	}
	platform_PULL();
}

/**
 * Start first task
 *
 */
void platform_launch(void) _naked
{
	platform_timer_setup();
	{
		uint8_t task_id = sch_task_next();
		sch_task_select(task_id);
		platfrom_RESTORE_STACK();
	}
	platform_PULL();
}

/*Sleep timer runs on the 32k768 crystal */
#define TICK_VAL (PLATFORM_TIMER_RATE / PLATFORM_TICK_RATE)

/* Used in timer interrupt for calculating the next tick time */
data static unsigned long sch_timer_value;

/**
 * System timer interrupt setup
 *
 */
void platform_timer_setup(void)
{
	CLKCON = OSC32K |  TICKSPD2|TICKSPD1|TICKSPD0;
	
	/*Initialize tick value and enable interrupt*/
	sch_timer_value = ST0;
	sch_timer_value += ((unsigned long int)ST1) << 8;
	sch_timer_value += ((unsigned long int)ST2) << 16;
	sch_timer_value += TICK_VAL;
	ST2 = (unsigned char) (sch_timer_value >> 16);
	ST1 = (unsigned char) (sch_timer_value >> 8);
	ST0 = (unsigned char) sch_timer_value;
	IEN0 |= STIE;
}

/**
 * System timer interrupt
 *
 */
void ST_ISR( void ) interrupt (ST_VECTOR) _naked
{
	EA = 0;

	platform_PUSH();
	IRCON &= ~STIF;

	sch_timer_value = ST0;
	sch_timer_value += ((unsigned long int)ST1) << 8;
	sch_timer_value += ((unsigned long int)ST2) << 16;
	sch_timer_value += TICK_VAL;
	ST2 = (unsigned char) (sch_timer_value >> 16);
	ST1 = (unsigned char) (sch_timer_value >> 8);
	ST0 = (unsigned char) sch_timer_value;

	sch_timer_update();
	{
		uint8_t task_id = sch_task_next();
		if (task_id != sch_task())
		{
			platfrom_STORE_STACK();
			sch_switch(task_id);
			platfrom_RESTORE_STACK();
		}
	}

	platform_PULL();
	EA = 1;
	{		\
		_asm	\
		reti	\
		_endasm;\
	}
}
