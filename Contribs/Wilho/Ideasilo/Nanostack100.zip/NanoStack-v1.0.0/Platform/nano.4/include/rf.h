/**
 *
 * \file rf.h
 * \brief nano.4 RF driver.
 *
 *  Nano.4: RF control headers.
 *   
 *	
 */

/*
 LICENSE_HEADER
 */

#ifndef _RF_H
#define _RF_H

/*CSP command set*/
#define SSTOP		0xDF

#define SNOP		0xC0
#define SRXON		0xC2
#define STXON		0xC3
#define STXONCCA	0xC4
#define SRFOFF		0xC5
#define SFLUSHRX	0xC6
#define SFLUSHTX	0xC7

#define ISRXON		0xE2
#define ISTXON		0xE3
#define ISTXONCCA	0xE4
#define ISRFOFF		0xE5
#define ISFLUSHRX	0xE6
#define ISFLUSHTX	0xE7

#define ISSTOP		0xFF
#define ISSTART		0xFE

extern portCHAR rf_init(void);

extern portCHAR rf_rx_enable(void);
extern portCHAR rf_rx_disable(void);

extern portCHAR rf_write(buffer_t *buffer);

extern void rf_ISR( void ) interrupt (RF_VECTOR);
extern void rf_error_ISR( void ) interrupt (RFERR_VECTOR);

#endif /*_RF_H*/
