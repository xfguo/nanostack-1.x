#ifndef _UART_H
#define _UART_H
#ifdef CC2430_EM
void uart0_rxISR( void ) interrupt (URX0_VECTOR);

void uart0_txISR( void ) interrupt (UTX0_VECTOR);

extern void uart0_init(uint32_t speed);
extern int16_t uart0_get(void);
extern int8_t uart0_put(uint8_t byte);
extern int16_t uart0_get_blocking(portTickType time);
#else
void uart1_rxISR( void ) interrupt (URX1_VECTOR);

void uart1_txISR( void ) interrupt (UTX1_VECTOR);

extern void uart1_init(uint32_t speed);
extern int16_t uart1_get(void);
extern int8_t uart1_put(uint8_t byte);
extern int16_t uart1_get_blocking(portTickType time);
#endif

#endif /*_UART_H*/
