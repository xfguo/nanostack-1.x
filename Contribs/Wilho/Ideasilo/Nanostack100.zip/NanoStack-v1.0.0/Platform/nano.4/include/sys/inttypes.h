#ifndef _INTTYPES_H
#define _INTTYPES_H

typedef unsigned char uint8_t;
typedef signed char int8_t;
typedef unsigned short int uint16_t;
typedef unsigned long int uint32_t;
typedef signed short int int16_t;

#endif
