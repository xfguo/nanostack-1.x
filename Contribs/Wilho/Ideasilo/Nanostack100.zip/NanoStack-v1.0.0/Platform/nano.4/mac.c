/**
 *
 * \file mac.c
 * \brief MAC API.
 *
 *  Support library: getting HW MAC from device.
 *   
 */

/*
 * $Id: stack.c,v 1.15 2006/01/11 14:21:34 sandman Exp $
 
 LICENSE_HEADER
 */

#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "semphr.h"

#include <sys/inttypes.h>

#include "stack.h"
#include "mac.h"

#ifdef HAVE_802_15_4_RAW
extern portCHAR rf_mac_get(sockaddr_t *address);
#endif

portCHAR mac_get(sockaddr_t *address)
{
/*#ifdef HAVE_802_15_4_RAW
	return rf_mac_get(address);
#else*/
	address->addr_type = ADDR_NONE;
	return pdFALSE;
/*#endif*/
}
