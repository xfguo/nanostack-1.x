/**
 *
 * \file     platform.h
 * \brief    Embryo scheduler platfrom definition.
 *
 *  The Embedded Realtime yielding Operating System.
 *  Port for Sensinode nano series.
 */

/* 
 LICENSE_HEADER
 */
#ifndef _PLATFORM_H
#define _PLATFORM_H


#ifndef PLATFORM_SYSTEM_RATE
/**Platform main crystal*/
#define PLATFORM_SYSTEM_RATE 32000000
#endif

#ifndef PLATFORM_TIMER_RATE
/**Platform OS timer crystal*/
#define PLATFORM_TIMER_RATE 32768
#endif

#ifndef PLATFORM_TICK_RATE
/**Platform OS timer frequency*/
#define PLATFORM_TICK_RATE 256
#endif

typedef uint32_t PLATFORM_COUNT;

typedef __code char CONST_INT8;
typedef __code unsigned char CONST_UINT8;
typedef __code short int CONST_INT16;
typedef __code unsigned short int CONST_UINT16;
typedef __code long int CONST_INT32;
typedef __code unsigned long int CONST_UINT32;

#ifndef LED_N
#ifdef CC2430_EM
#define LED_N 2
void LED_INIT(void) { P1DIR |= 0x09; }
void LED1_ON(void) {P1_3 = 0;}
void LED1_OFF(void) {P1_3 = 1;}

void LED2_ON(void) {P1_0 = 0;}
void LED2_OFF(void) {P1_0 = 1;}
#else
#define LED_N 2
void LED_INIT(void) { P0DIR |= 0xC0; }
void LED1_ON(void) {P0_6 = 1;}
void LED1_OFF(void) {P0_6 = 0;}

void LED2_ON(void) {P0_7 = 1;}
void LED2_OFF(void) {P0_7 = 0;}
#endif
#endif

#endif /*_PLATFORM_H*/
