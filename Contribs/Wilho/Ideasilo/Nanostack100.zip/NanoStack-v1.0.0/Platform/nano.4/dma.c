/**
 *
 * \file dma.c
 * \brief DMA controller library.
 *
 *  DMA: mode control and support functions.
 *  General support functions and hardware initialization.
 *   
 *	
 */

/*
 * $Id: debug.c,v 1.5 2006/01/13 13:53:59 sandman Exp $
 
 LICENSE_HEADER
 */
 

#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "semphr.h"

#include <string.h>

#include <sys/inttypes.h>

#include "stack.h"
#include "debug.h"

#include "dma.h"

dma_config_t dma_conf[5];
dma_func dma_callback[5];

/**
 * Init DMA structures.
 *
 */
void dma_init(void)
{
	uint16_t tmp_ptr;
	
	memset(dma_conf, 0, 5*sizeof(dma_config_t));
	for (tmp_ptr = 0; tmp_ptr < 5; tmp_ptr++)
	{
		dma_callback[tmp_ptr] = 0;
	}
	tmp_ptr = (uint16_t) &(dma_conf[0]);

	DMA0CFGH = tmp_ptr >> 8;
	DMA0CFGL = tmp_ptr;
	
	tmp_ptr = (uint16_t) &(dma_conf[1]);

	DMA1CFGH = tmp_ptr >> 8;
	DMA1CFGL = tmp_ptr;
	
}

/**
 * Configure a DMA channel.
 *
 * \param channel channel ID;
 * \param src source address;
 * \param src_inc source increment mode;
 * \param dst dest address;
 * \param dst_inc dest increment mode;
 * \param length maximum length;
 * \param vlen_mode variable length mode;
 * \param t_mode DMA transfer mode;
 * \param trigger DMA trigger;
 * \param function event function;
 *
 * \return Handle to DMA channel
 * \return 0 invalid channel
 */
xDMAHandle dma_config(uint8_t channel, void *src, dma_inc_t src_inc, void *dst, dma_inc_t dst_inc, 
                             uint16_t length, dma_vlen_t vlen_mode, dma_type_t t_mode, dma_trigger_t trigger,
			     dma_func function)
{
	if (channel > 4) return 0;
	
	dma_conf[channel].src_h = ((uint16_t) src) >> 8;
	dma_conf[channel].src_l = ((uint16_t) src);
	dma_conf[channel].dst_h = ((uint16_t) dst) >> 8;
	dma_conf[channel].dst_l = ((uint16_t) dst);
	dma_conf[channel].len_h = vlen_mode + (length >> 8);
	dma_conf[channel].len_l = length;
	dma_conf[channel].t_mode = (t_mode << 5) + trigger;
	dma_conf[channel].addr_mode = (src_inc << 6) + (dst_inc << 4) + 2; /*DMA has priority*/
	DMAIRQ &= ~(1 << channel);
	if (function)
	{
		dma_conf[channel].addr_mode |= 8;	/*set IRQMASK*/
		IEN1_DMAIE = 1;	/*enable DMA interrupts*/
	}
	dma_callback[channel] = function;
	
	return (xDMAHandle) channel+1;
}


/**
 * Arm a DMA channel.
 *
 * \param channel channel handle;
 *
 * \return pdTRUE
 * \return pdFALSE	semaphore creation failed
 */
portCHAR dma_arm(xDMAHandle channel)
{
	uint8_t ch_id = ((uint8_t) channel) - 1;
	if (ch_id > 4) return pdFALSE;
	DMAARM |= (1 << ch_id);
	return pdTRUE;
}

/**
 * Stop a DMA channel.
 *
 * \param channel channel handle;
 *
 * \return pdTRUE
 * \return pdFALSE	semaphore creation failed
 */
portCHAR dma_abort(xDMAHandle channel)
{
	uint8_t ch_id = ((uint8_t) channel) - 1;
	if (ch_id > 4) return pdFALSE;
	DMAARM = 0x80 + (1 << ch_id);	/*ABORT + channel bit*/
	return pdTRUE;
}

/**
 * Trigger a DMA channel.
 *
 * \param channel channel handle;
 *
 * \return pdTRUE
 * \return pdFALSE	semaphore creation failed
 */
portCHAR dma_trigger(xDMAHandle channel)
{
	uint8_t ch_id = ((uint8_t) channel) - 1;
	if (ch_id > 4) return pdFALSE;
	DMAREQ |= (1 << ch_id);
	return pdTRUE;
}

/**
 * Get DMA state.
 *
 * \param channel channel handle;
 *
 * \return pdTRUE	active
 * \return pdFALSE	not active
 */
portCHAR dma_state(xDMAHandle channel)
{
	uint8_t ch_id = ((uint8_t) channel) - 1;
	if (ch_id > 4) return pdFALSE;
	if ((DMAIRQ &(1 << ch_id)) == 0)
	{
		return pdTRUE;
	}
	return pdFALSE;
}



void dma_config_print(xDMAHandle channel)
{
	uint8_t ch_id = channel - 1;

	if (ch_id > 4) return;

	debug("DMA config ");
	debug_int(ch_id);
	debug(" @ ");
	debug_hex( (uint16_t) &(dma_conf[ch_id]) >> 8);
	debug_hex( (uint16_t) &(dma_conf[ch_id]) & 0xFF);
	
	debug(":\r\n");
	{
		uint8_t i;
		uint8_t *ptr = (uint8_t *) &(dma_conf[ch_id]);
		for (i = 0; i< 8; i++)
		{
			if (i != 0) debug(":");
			debug_hex(*ptr++);
		}
		debug("\r\n");
	}
	debug(".\r\n");
}

/**
 * DMA interrupt service routine.
 *
 */
void dma_ISR( void ) interrupt (DMA_VECTOR)
{
	portBASE_TYPE prev_task = pdFALSE;
	uint8_t i;
	for (i=0; i<5; i++)
	{
		if ((DMAIRQ & (1 << i)) != 0)
		{
			DMAIRQ &= ~(1 << i);
			if (dma_callback[i] != 0)
			{
				event_t event;
				event.process = dma_callback[i];
				event.param = (void *) 0;
				prev_task = xQueueSendFromISR(events, &event, prev_task);
			}
		}
	}
	IRCON_DMAIF = 0;
#ifdef HAVE_POWERSAVE
	power_interrupt_epilogue();
#endif
}

