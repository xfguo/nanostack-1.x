/**
 *
 * \file uart.c
 * \brief nano.4 UART driver.
 *
 *  Nano.4: UART control functions.
 *   
 *	
 */

/*
 * $Id: debug.c,v 1.5 2006/01/13 13:53:59 sandman Exp $
 
 LICENSE_HEADER
 */

/* Standard includes. */
#include <stdlib.h>
#include <string.h>

/* Scheduler includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#include "semphr.h"

typedef unsigned char uint8_t;
typedef signed char int8_t;
typedef unsigned short int uint16_t;
typedef unsigned long int uint32_t;
typedef signed short int int16_t;

typedef void tskTCB;
extern volatile tskTCB * volatile pxCurrentTCB;

#include "uart.h"

#ifndef UART0_RX_LEN
#define UART0_RX_LEN 4
#endif

#ifndef UART0_TX_LEN
#define UART0_TX_LEN 128
#endif

volatile portCHAR uart0_txempty = pdTRUE;

/** The queue used to hold received characters. */
xQueueHandle uart0_rx = 0;

/** The queue used to hold characters waiting transmission. */
xQueueHandle uart0_tx = 0; 

#ifdef HAVE_POWERSAVE
xPowerHandle uart0_ph = 0;
#endif

void uart0_init(uint32_t speed)
{
	if (speed != 115200) return;
	if (uart0_tx == 0)
	{
		uart0_rx = xQueueCreate(UART0_RX_LEN, ( unsigned portBASE_TYPE ) sizeof( signed portCHAR ) );
		uart0_tx = xQueueCreate(UART0_TX_LEN, ( unsigned portBASE_TYPE ) sizeof( signed portCHAR ) );
	}
	/*Baud rate = ((256+UxBAUD) * 2^UxGCR)*crystal / (2^28)*/
	PERCFG &= ~U0CFG;	/*alternative port 1 = P0.5-2*/
	P0SEL |= 0x0C;		/*peripheral select for TX and RX*/
	U0BAUD=216;		/*115200*/
	U0GCR =/* U_ORDER |*/ 11; /*LSB first and 115200*/
	U0UCR = 0x02;	/*defaults: 8N1, no flow control, high stop bit*/
	U0CSR = U_MODE | U_RE |U_TXB; /*UART mode, receiver enable, TX done*/

	IEN0_URX0IE = 1;
	IEN2 |= UTX0IE;

	uart0_txempty = pdTRUE;
}

int16_t uart0_get_blocking(portTickType time)
{
	uint8_t byte;

	if ( xQueueReceive(uart0_rx, &byte, time ) == pdTRUE)
	{
		return 0 + (uint16_t) byte;
	}
	else
	{
		return -1;
	}
}

int16_t uart0_get(void)
{
	uint8_t byte;
	
	if ( xQueueReceive(uart0_rx, &byte, (portTickType) 0 ) == pdTRUE)
	{
		return 0 + (uint16_t) byte;
	}
	else
	{
		return -1;
	}
}

void uart0_put(uint8_t byte)
{
	if (uart0_txempty == pdTRUE)
	{
		uart0_txempty = pdFALSE;
		U0BUF = byte;	
	}
	else
	{
		portCHAR status = pdFALSE;
		while(status == pdFALSE)
		{
			status = xQueueSend(uart0_tx, &byte, 2);
		}
		if (uart0_txempty == pdTRUE)
		{
			xQueueReceive(uart0_tx, &byte, 0);
			uart0_txempty = pdFALSE;
			U0BUF = byte;	
		}
	}
/*	IEN0_EA = 0;
	IEN0_EA = 1;*/
}


/**
 * UART RX interrupt service routine
 * for UART 0
 */

void uart0_rxISR( void ) interrupt (URX0_VECTOR)
{
	uint8_t byte;
	
	TCON_URX0IF = 0;

	/* Get the character from the UART and post it on the queue of Rxed 
	characters. */
	byte = U0BUF;

	if( xQueueSendFromISR(uart0_rx, &byte, pdFALSE ) )
	{
		taskYIELD();
	}
#ifdef HAVE_POWERSAVE
	power_interrupt_epilogue();
#endif
}


/**
 * UART Tx interrupt service routine.
 * for UART 0
 */
void uart0_txISR( void ) interrupt (UTX0_VECTOR)
{
	uint8_t byte;
	portBASE_TYPE task = pdFALSE;

	if( xQueueReceiveFromISR( uart0_tx, &byte, &task ) == pdTRUE )
	{
		U0BUF = byte;
	}
	else
	{
		uart0_txempty = pdTRUE;
	}
	IRCON2_UTX0IF = 0;
#ifdef HAVE_POWERSAVE
	power_interrupt_epilogue();
#endif
}
