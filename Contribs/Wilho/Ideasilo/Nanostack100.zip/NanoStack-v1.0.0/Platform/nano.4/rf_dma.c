/**
 *
 * \file rf.c
 * \brief nano.4 RF driver.
 *
 *  Nano.4: RF control functions.
 *   
 *	
 */

/*
 * $Id: debug.c,v 1.5 2006/01/13 13:53:59 sandman Exp $
 
 LICENSE_HEADER
 */
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "semphr.h"

#include <string.h>

#include <sys/inttypes.h>

#include "stack.h"
#include "debug.h"

#include "dma.h"
#include "rf.h"

#ifndef RF_DEFAULT_POWER
#define RF_DEFAULT_POWER 100
#endif

#ifndef RF_DEFAULT_CHANNEL
#define RF_DEFAULT_CHANNEL 18
#endif

#ifdef HAVE_RF_LED
#ifdef HAVE_NRP
#define RF_RX_LED_ON() LED1_ON()
#define RF_RX_LED_OFF() LED1_OFF()
#define RF_TX_LED_ON() LED2_ON()
#define RF_TX_LED_OFF() LED2_OFF()
#else
#if HAVE_RF_LED == 1
#define RF_RX_LED_ON() LED1_ON()
#define RF_RX_LED_OFF() LED1_OFF()
#define RF_TX_LED_ON() LED1_ON()
#define RF_TX_LED_OFF() LED1_OFF()
#else
#define RF_RX_LED_ON() LED2_ON()
#define RF_RX_LED_OFF() LED2_OFF()
#define RF_TX_LED_ON() LED2_ON()
#define RF_TX_LED_OFF() LED2_OFF()
#endif /*RF_LED == 1 */
#endif	/*HAVE_NRP*/
#else
#define RF_RX_LED_ON()
#define RF_RX_LED_OFF()
#define RF_TX_LED_ON()
#define RF_TX_LED_OFF()
#endif /*HAVE_RF_LED*/

uint8_t rf_initialized = 0;

uint8_t rf_tx_power;
uint8_t rx_flags, tx_flags;
#define RX_ACTIVE 0x80

uint16_t rf_manfid;

sockaddr_t rf_mac_address;

xDMAHandle rf_dma = 0;
void rf_dma_callback(void *param);

extern void pause(uint16_t time);

#define RF_BUFFER volatile_ram1

/**
 * Execute a single CSP command.
 *
 * \param command command to execute
 *
 */
void rf_command(uint8_t command)
{
	RFIF &= ~IRQ_CSP_STOP;	/*clear IRQ flag*/
	RFST = command;	/*write command*/
	RFST = SSTOP;	/*single command and stop*/
	RFST = ISSTART;	/*start execution*/
	
	while((RFIF & IRQ_CSP_STOP) == 0);
}

/**
 * Select RF channel.
 *
 * \param channel channel number to select
 *
 * \return channel value or negative (invalid channel number)
 */
 
 /* channel freqdiv = (2048 + FSCTRL(9:0)) / 4
            freq = (2048 + FSCTRL(9:0)) MHz */

portCHAR rf_channel_set(uint8_t channel)
{
	uint16_t freq;
	
	if ( (channel < 11) || (channel > 26) ) return -1;
	
	/* Channel values: 11-26 */
	freq = (uint16_t) channel - 11;
	freq *= 5;	/*channel spacing*/
	freq += 357; /*correct channel range*/
	freq |= 0x4000; /*LOCK_THR = 1*/

	FSCTRLH = (freq >> 8);
	FSCTRLL = (uint8_t)freq;	
	
	return (int8_t) channel;
}

/*PA_LEVEL TXCTRL register Output Power [dBm] Current Consumption [mA] 
	31 0xA0FF 0 17.4 
	27 0xA0FB -1 16.5 
	23 0xA0F7 -3 15.2 
	19 0xA0F3 -5 13.9 
	15 0xA0EF -7 12.5 
	11 0xA0EB -10 11.2 
	 7 0xA0E7 -15 9.9 
	 3 0xA0E3 -25 8.5*/

/**
 * Select RF transmit power.
 *
 * \param new_power new power level (in per cent)
 *
 * \return new level or negative (value out of range)
 */
 
portCHAR rf_power_set(uint8_t new_power)
{
	uint16_t power;
	
	if (new_power > 100) return -1;
	
	power = 31 * new_power;
	power /= 100;
	power += 0xA160;
		
	/* Set transmitter power */
	TXCTRLH = (power >> 8);
	TXCTRLL = (uint8_t)power;	
	
	rf_tx_power = (int8_t) new_power;
	return rf_tx_power;
}

/* RF DMA setup should be:
	source RFD,
	destination volatile_ram2,
	length = VLEN_N3,
	LEN = 131, 128 + 2 RSSI + len,
	byte mode + single block transfer, trigger=RADIO,
	src_inc = none, dst_inc = increment 1,  IRQ on, priority = 2 */


/**
 * Enable RF receiver.
 *
 *
 * \return pdTRUE
 * \return pdFALSE	bus not free
 */
portCHAR rf_rx_enable(void)
{
	if (rx_flags == 0)
	{
		void *src = &RFD_SHADOW;
		
		RFIF &= ~(IRQ_SFD);
		tx_flags = 0;
		rx_flags = RX_ACTIVE;
		S1CON &= ~(RFIF_0 | RFIF_1);
		RFPWR &= ~RREG_RADIO_PD;	/*make sure it's powered*/
		while((RFIF & IRQ_RREG_ON) == 0);	/*wait for power up*/
		SLEEP &= ~OSC_PD; /*Osc on*/
		while((SLEEP & XOSC_STB) == 0);	/*wait for power up*/
		rf_command(SFLUSHTX);
		rf_command(SFLUSHRX);
		rf_command(SRXON);
		
		rf_dma = dma_config(4, (void *) src, DMA_NOINC, (void *) RF_BUFFER, DMA_INC,
				131, DMA_VLEN_N3, DMA_BLOCK, DMA_T_RADIO, rf_dma_callback);
		dma_arm(rf_dma);
		
/*		RFIM |= IRQ_SFD;
		RFIF &= ~(IRQ_SFD);
		S1CON &= ~(RFIF_0 | RFIF_1);
		IEN2 |= RFIE;*/
	}
	
	return pdTRUE;
}

/**
 * Disable RF receiver.
 *
 *
 * \return pdTRUE
 * \return pdFALSE	bus not free
 */
portCHAR rf_rx_disable(void)
{
	dma_abort(rf_dma);
	RFIM &= ~IRQ_SFD;
	rf_command(SRFOFF);
	rf_command(SFLUSHRX);
	RFPWR |= RREG_RADIO_PD;		/*RF powerdown*/
	IEN2 &= ~RFIE;
	rx_flags = 0;
	tx_flags = 0;
	return pdTRUE;
}


/**
 * Enable RF transmitter.
 *
 *
 * \return pdTRUE
 * \return pdFALSE	bus not free
 */
portCHAR rf_tx_enable(void)
{
	dma_abort(rf_dma);
	RFIM &= ~IRQ_SFD;
	IEN2 &= ~RFIE;
	tx_flags |= RX_ACTIVE;
	rx_flags = 0;
	RFPWR &= ~RREG_RADIO_PD;	/*make sure it's powered*/
	while((RFIF & IRQ_RREG_ON) == 0);	/*wait for power up*/
	SLEEP &= ~OSC_PD; /*Osc on*/
	while((SLEEP & XOSC_STB) == 0);	/*wait for power up*/
	rf_command(SFLUSHRX);
	rf_command(SFLUSHTX);
	return pdTRUE;
}

   
/**
 * Initialize RF.
 *
 *
 * \return pdTRUE
 * \return pdFALSE	bus not free or init failed
 */

portCHAR rf_init(void)
{
	portCHAR retval = pdFALSE;

	if (rf_initialized) return pdTRUE;

	dma_init();
		
	RFPWR &= ~RREG_RADIO_PD;	/*make sure it's powered*/
	while ((RFPWR & ADI_RADIO_PD) == 1);
	while((RFIF & IRQ_RREG_ON) == 0);	/*wait for power up*/
	SLEEP &= ~OSC_PD; /*Osc on*/
	while((SLEEP & XOSC_STB) == 0);	/*wait for power up*/
	
	rx_flags = tx_flags = 0;
	
	retval = pdTRUE;

#ifdef RF_DEBUG
	debug("RF setup.\r\n");		
#endif		
	FSMTC1 &= ~ABORTRX_ON_SRXON;	/*don't abort reception, if enable called*/
  	MDMCTRL0H = 0x02;
	MDMCTRL0L = 0xE2;

  	MDMCTRL1H = 0x30; 
	MDMCTRL1L = 0x00;
	
  	IOCFG0 = 0x7F;   // Set the FIFOP threshold to maximum 
/*  	CC2420_REG_SET(CC_REG_SECCTRL0, 0x01C4); // Turn off "Security enable"*/

	/* get ID for MAC */
	rf_manfid = CHVER;
	rf_manfid <<= 8;		
	rf_manfid += CHIPID;

	rf_channel_set(RF_DEFAULT_CHANNEL);

	/* Set transmitter power */
	rf_power_set(RF_DEFAULT_POWER);

/*	rf_mac_get(&rf_mac_address);*/
/*	debug_printf("MAC: %2.2X:%2.2X:%2.2X:%2.2X:%2.2X:%2.2X:%2.2X:%2.2X\r\n",
			rf_mac_address.address[0],rf_mac_address.address[1],
			rf_mac_address.address[2],rf_mac_address.address[3],
			rf_mac_address.address[4],rf_mac_address.address[5],
			rf_mac_address.address[6],rf_mac_address.address[7]);*/
	retval = pdTRUE;
		
	rf_command(SFLUSHTX);
	rf_command(SFLUSHRX);
	tx_flags = 0;

	rf_rx_enable();

	RF_BUFFER[0] = 0;
#ifdef RF_DEBUG				
	debug("RF: Up.\r\n");
#endif
	rf_initialized = 1;
	return retval;
}

/**
 * Transmit packet.
 *
 * Missing feature: address type check
 *
 * \param mac RF HW address
 * \param dst destination HW address
 * \param buffer data buffer pointer
 * \param length length of data
 *
 * \return pdTRUE+1 channel occupied
 * \return pdTRUE
 * \return pdFALSE	bus reserved
 */

portCHAR rf_write(buffer_t *buffer)
{
	uint8_t counter, i;
	portCHAR retval = pdTRUE;
	int16_t length =  buffer->buf_end - buffer->buf_ptr;
	
	if (rx_flags & RX_ACTIVE)
	{
		if ( (RFSTATUS & FIFOP) || (RFSTATUS & SFD) )
		{
			debug("RF: Packet IF busy.\r\n");
			if ((RFSTATUS & FIFOP))
			{
				rf_command(SFLUSHTX);
				rf_command(SFLUSHRX);
			}

			retval = pdFALSE;		
		}
	}
	rf_tx_enable();
	if ( (length <= 128) && (retval == pdTRUE) )
	{
/*		rx_disable();*/

		RF_TX_LED_ON();
/*		debug("RF: RX on.\r\n");*/

		rf_command(SRXON);

		pause(2);

		if ((RFSTATUS & CCA) == 0)
		{
			debug("RF: Channel occupied.\r\n");
			tx_flags = 0;
			retval = pdTRUE+1;
			
		}
		rf_command(SFLUSHTX);

		if (retval == pdTRUE)
		{
			uint8_t *ptr;
			
			if (buffer->buf_ptr == 0)
			{
				memmove(&(buffer->buf[1]),&(buffer->buf[0]), length);
				buffer->buf_ptr++;
				buffer->buf_end++;
			}
			
			ptr = buffer->buf + buffer->buf_ptr;
			ptr--;
			*ptr = length + 2;
			
			rf_dma = dma_config(4, (void *) ptr, DMA_INC, (void *) &RFD_SHADOW, DMA_NOINC,
				length + 3, DMA_VLEN_LEN, DMA_BLOCK, DMA_T_NONE, 0/*rf_dma_callback*/);
			dma_arm(rf_dma);
			dma_trigger(rf_dma);
			
			while (dma_state(rf_dma) == pdTRUE);
			rx_flags = 0;

			rf_command(STXONCCA);
			counter = 0;	
			while( ((RFSTATUS & TX_ACTIVE) == 0) && (counter++ < 200))
			{
				pause(1);
			}
			
			if (counter < 200)
			{
				while((RFIF & IRQ_TXDONE) == 0);
			}
			else
			{
				debug("\r\nRF: TX never active.\r\n");

				rf_command(SFLUSHTX);
				rf_command(SRFOFF);
				tx_flags = 0;

				retval = pdTRUE+1;
			}
		}

		if (retval == pdTRUE)
		{

			debug("RF: Done.\r\n");

			rf_command(SFLUSHTX);
			rf_command(SRFOFF);
		}
	}
	if ((retval == pdTRUE) && (length > 128))
	{
		debug("Packet too long(");
		debug_int(length);
		debug(").\r\n");

		retval = pdFALSE;
	}

	RF_TX_LED_OFF();
	tx_flags = 0;
	rf_rx_enable();

#ifdef RF_DEBUG				
	debug("RF: Close.\r\n");
#endif
	return retval;		
}


/**
 * RF DMA callback.
 *
 * \param param not used;
 *
 */
void rf_dma_callback(void *param)
{
	uint8_t *ptr = RF_BUFFER;
	uint8_t len;
	buffer_t *rf_buf = stack_buffer_get(20);
	
	param;
#ifdef RF_DEBUG
	debug("RF: DMA callback.\r\n");
#endif
	if (rf_buf != 0)
	{
		rf_buf->options.rf_dbm = -90;
		rf_buf->options.rf_lqi = 0;
		rf_buf->buf_end = 0;
		rf_buf->buf_ptr = 0;
		rf_buf->to = 0;

		len = *ptr++;
		len -= 2;

		if (len > 4)
		{
			rf_buf->options.rf_dbm = ((int8_t) ptr[len]) - 45;
			rf_buf->options.rf_lqi = ptr[len+1];
/*			{
				uint8_t i;
				for (i = 0; i< len+2; i++)
				{
					if ((i & 0x0F) == 0) debug("\r\n");
					else if (i != 0) debug(":");
					debug_hex(ptr[i]);

				}
				debug("\r\n");
			}*/
			memcpy(rf_buf->buf, ptr, len);
			ptr += len;

			rf_buf->to = MODULE_802_15_4_RAW;
			rf_buf->buf_ptr = 0;
			rf_buf->buf_end = len;
			rf_buf->options.rf_lqi &= 0x7F;

#ifdef RF_DEBUG_RSSI
/*			debug_printf("RSSI: %4.4X -> %d dBm, LQI %d.\r\n", tmp_16, rf_buf->options.rf_dbm, rf_buf->options.rf_lqi);*/
			debug("RSSI: ");
			debug_int(rf_buf->options.rf_dbm);
			debug(" dBm, LQI ");
			debug_int(rf_buf->options.rf_lqi);
			debug(".\r\n");
#endif	
			stack_buffer_push(rf_buf);
			rf_buf = 0;
		}
	}
#ifdef RF_DEBUG_RSSI
	else
	{
		debug("RF: No buffers. Drop.\r\n");
	}
#endif	
	
	ptr = RF_BUFFER;
	*ptr = 0;
	rx_flags = 0;
	rf_rx_enable();

}


/**
 * RF interrupt service routine.
 *
 */
void rf_ISR( void ) interrupt (RF_VECTOR)
{
/*	portBASE_TYPE task = pdFALSE;*/

	if (RFIF & IRQ_SFD)
	{
		RFIF &= ~IRQ_SFD;
#if 0
		if (tx_flags == 0)
		{
			if(xSemaphoreGiveFromISR( rf_lock, pdFALSE ) == pdTRUE )
			{
				taskYIELD();
			}
		}
#endif
	}
	S1CON &= ~(RFIF_0 | RFIF_1);
#ifdef HAVE_POWERSAVE
	power_interrupt_epilogue();
#endif
}

/**
 * RF error interrupt service routine.
 *
 */
void rf_error_ISR( void ) interrupt (RFERR_VECTOR)
{
	TCON_RFERRIF = 0;
#ifdef HAVE_POWERSAVE
	power_interrupt_epilogue();
#endif
}

#if 0
void vrf_task( void *pvParameters )
{
	uint8_t *ptr;

	pvParameters;
	
	ptr = RF_BUFFER;
	*ptr = 0;
	
	rf_buf = 0;
	while (rf_manfid == 0)
	{
		vTaskDelay(50 / portTICK_RATE_MS );
	}
#ifdef RF_DEBUG
	debug("rf_task: go.\r\n");
#endif
	xSemaphoreTake( rf_lock, 0);
	for(;;)
	{
		if (rf_buf == 0)
		{
			rf_buf = stack_buffer_get(20);
			if (rf_buf != 0)
			{
#ifdef RF_DEBUG
			  debug("rf_task: got buffer.\r\n");
#endif
			}
			else
			{
				vTaskDelay(50 / portTICK_RATE_MS );
			}
		}
		ptr = RF_BUFFER;
		if ( (xSemaphoreTake( rf_lock, ( portTickType ) 5000 / portTICK_RATE_MS )
		      == pdTRUE)  && ((tx_flags & RX_ACTIVE) == 0) )
		{
			uint8_t len;

			len = DMAIRQ;
			while (len == 0) len = DMAIRQ;		
			debug_hex(len);
			/*if (dma_state(rf_dma) == pdTRUE)
			{
				while(dma_state(rf_dma) == pdTRUE) taskYIELD();
			}*/
			
			rf_buf->options.rf_dbm = -90;
			rf_buf->options.rf_lqi = 0;
			rf_buf->buf_end = 0;
			rf_buf->buf_ptr = 0;
			rf_buf->to = 0;
			
			len = *ptr++;
			len -= 2;
			debug_int(len);
			if (len > 4)
			{
				rf_buf->options.rf_dbm = ((int8_t) ptr[len]) - 45;
				rf_buf->options.rf_lqi = ptr[len+1];
				memcpy(rf_buf->buf, ptr, len);
/*				{
					uint8_t i;
					for (i = 0; i< len+2; i++)
					{
						if ((i & 0x0F) == 0) debug("\r\n");
						else if (i != 0) debug(":");
						debug_hex(ptr[i]);
						
					}
					debug("\r\n");
				}*/
				ptr += len;

				rf_buf->to = MODULE_802_15_4_RAW;
				rf_buf->buf_ptr = 0;
				rf_buf->buf_end = len;
				rf_buf->options.rf_lqi &= 0x7F;

#ifdef RF_DEBUG_RSSI
	/*						debug_printf("RSSI: %4.4X -> %d dBm, LQI %d.\r\n", tmp_16, rf_buf->options.rf_dbm, rf_buf->options.rf_lqi);*/
				debug("RSSI: ");
				debug_int(rf_buf->options.rf_dbm);
				debug(" dBm, LQI ");
				debug_int(rf_buf->options.rf_lqi);
				debug(".\r\n");
#endif	
				stack_buffer_push(rf_buf);
				rf_buf = 0;
			}
			
			ptr = RF_BUFFER;
			*ptr = 0;
			rx_flags = 0;
			rf_rx_enable();
			len = DMAIRQ;
			debug_hex(len);
			xSemaphoreTake( rf_lock, 0);
		}
	}
}

portCHAR rf_write(buffer_t *buffer)
{
	uint8_t counter, i;
	portCHAR retval = pdTRUE;
	int16_t length =  buffer->buf_end - buffer->buf_ptr;
	
	if (rx_flags & RX_ACTIVE)
	{
		if ( (RFSTATUS & FIFOP) || (RFSTATUS & SFD) )
		{
			debug("RF: Packet IF busy.\r\n");
			if ((RFSTATUS & FIFOP))
			{
				rf_command(SFLUSHTX);
				rf_command(SFLUSHRX);
			}

			retval = pdFALSE;		
		}
	}
	rf_tx_enable();
	if ( (length <= 128) && (retval == pdTRUE) )
	{
/*		rx_disable();*/

		RF_TX_LED_ON();
		debug("RF: RX on.\r\n");

		rf_command(SRXON);

		pause(2);

		if ((RFSTATUS & CCA) == 0)
		{
			debug("RF: Channel occupied.\r\n");
			tx_flags = 0;
			retval = pdTRUE+1;
			
		}
		rf_command(SFLUSHTX);

		if (retval == pdTRUE)
		{
			uint8_t *ptr = buffer->buf + buffer->buf_ptr;

			RFD = (length+2);

			for (i = 0 ; i < length ; i++)
			{
				RFD = *ptr++;
			}
			RFD = (0);
			RFD = (0);

			rx_flags = 0;

			rf_command(STXONCCA);
			counter = 0;	
			while( ((RFSTATUS & TX_ACTIVE) == 0) && (counter++ < 200))
			{
				pause(1);
			}
			
			if (counter < 200)
			{
				while((RFIF & IRQ_TXDONE) == 0);
			}
			else
			{
				debug("\r\nRF: TX never active.\r\n");

				rf_command(SFLUSHTX);
				rf_command(SRFOFF);
				tx_flags = 0;

				retval = pdTRUE+1;
			}
		}

		if (retval == pdTRUE)
		{

			debug("RF: Done.\r\n");

			rf_command(SFLUSHTX);
			rf_command(SRFOFF);
		}
	}
	if ((retval == pdTRUE) && (length > 128))
	{
		debug("Packet too long(");
		debug_int(length);
		debug(").\r\n");

		retval = pdFALSE;
	}

	RF_TX_LED_OFF();
	tx_flags = 0;
	rf_rx_enable();

#ifdef RF_DEBUG				
	debug("RF: Close.\r\n");
#endif
	return retval;		
}
#endif

