/*
    NanoStack: MCU software and PC tools for sensor networking.
		
    Copyright (C) 2006-2007 Sensinode Ltd.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

		Address:
		Sensinode Ltd.
		PO Box 1
		90571 Oulu, Finland

		E-mail:
		info@sensinode.com
*/


/**
 *
 * \file bus.c
 * \brief nano bus controls.
 *
 *  Nano: basic mode control and support functions.
 *  General support functions and hardware initialization.
 *   
 *	
 */

/*
 LICENSE_HEADER
 */
 

#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "semphr.h"

#include <string.h>

#include "debug.h"
#include "bus.h"

#include "progmem.h"

#ifdef HAVE_POWERSAVE
#include "powersave.h"
#endif

#ifdef CC2430_EM
void LED_INIT(void) { P1DIR |= 0x09; }
void LED1_ON(void) {P1_3 = 0;}
void LED1_OFF(void) {P1_3 = 1;}

void LED2_ON(void) {P1_0 = 0;}
void LED2_OFF(void) {P1_0 = 1;}
#else
void LED_INIT(void) { P0DIR |= 0xC0; }
void LED1_ON(void) {P0_6 = 1;}
void LED1_OFF(void) {P0_6 = 0;}

void LED2_ON(void) {P0_7 = 1;}
void LED2_OFF(void) {P0_7 = 0;}
#endif


/**
 * Initialize bus and MCU clock. 
 * First function to call.
 *
 *
 * \return pdTRUE
 * \return pdFALSE	semaphore creation failed
 */
portCHAR bus_init(void)
{
	LED_INIT();
	
	CLKCON |= OSC32K;
	CLKCON &= ~(OSC | CLKSPD); /*Osc on*/

	return pdTRUE;
}


/**
 * Read a block of code memory.
 * The code must be placed in the lowest bank of flash.
 *
 * \param address address to read from flash
 * \param buffer  buffer to store data
 * \param size    number of bytes to read
 */
void flash_read(uint8_t *buffer, uint32_t address, uint8_t size)
{
	buffer;	 	/*dptr0*/
	address; 	/*stack-6*/
	size;			/*stack-7*/
	
	buffer;
	
	portDISABLE_INTERRUPTS();
	_asm
			mov dpl, r2
			mov dph, r3
			mov a, r0
			push acc
			mov a, r2
			push acc
			
			mov a, _bp
			add a, #0xf9 		;stack - 7 = size
			mov r0,a
			mov a, @r0  		;r2 = size
			mov r2, a   		;r2 = size
			
			inc r0
			mov a, @r0
			mov _DPL1, a		;DPTR1 = address & 0x7FFF | 0x8000
			inc r0
			mov a, @r0
			orl a, #0x80
			mov _DPH1, a
			inc r0					;MEMCTR = ((address >> 15 & 3) << 4) | 0x01 (bank select)
			mov a, @r0
			dec r0
			rrc a
			mov a, @r0
			rrc a
			rr a
			rr a
			anl a, #0x30
			orl a, #1
			mov _MEMCTR,a
lp1:
			mov _DPS, #1		;active DPTR = 1
			clr a
			movc a, @a+dptr			;read flash (DPTR1)
			inc dptr
			mov _DPS, #0 				;active DPTR = 0
			movx @dptr,a				;write to DPTR0
			inc dptr
			djnz r2,lp1					;while (--size)
			mov _MEMCTR, #0x11	;restore bank to 1
			
			pop acc
			mov r2,a
			pop acc
			mov r0,a
	_endasm;
	portENABLE_INTERRUPTS();
	DPL1 = *buffer++;
}

/**
 * Approximate CPU loop pause.
 *
 *	Approximates multiples of 1 us delay.
 *
 * \param time time in us
 *
 */
void pause_us(uint16_t time)
{
	uint16_t i;
	for (i = 0; i< time; i++)
	{
		portNOP();
	}
}

/**
 * Approximate CPU loop pause.
 *
 *	Approximates multiples of 1 ms delay.
 *
 * \param time time in ms
 *
 */
void pause(uint16_t time)
{
	uint16_t i;
	for (i = 0; i< time; i++)
	{
		pause_us(1000);
	}
}
