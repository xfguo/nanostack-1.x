/*
    NanoStack: MCU software and PC tools for sensor networking.
		
    Copyright (C) 2006-2007 Sensinode Ltd.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

		Address:
		Sensinode Ltd.
		PO Box 1
		90571 Oulu, Finland

		E-mail:
		info@sensinode.com
*/


/**
 *
 * \file rf.c
 * \brief nano.4 RF driver.
 *
 *  Nano.4: RF control functions.
 *   
 *	
 */

/*
 LICENSE_HEADER
 */
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "semphr.h"

#include <string.h>

#include <sys/inttypes.h>

#include "stack.h"
#include "debug.h"

#include "dma.h"
#include "rf.h"

#ifndef RF_DEFAULT_POWER
#define RF_DEFAULT_POWER 100
#endif

#ifndef RF_DEFAULT_CHANNEL
#define RF_DEFAULT_CHANNEL 18
#endif

#ifdef HAVE_RF_LED
#ifdef HAVE_NRP
#define RF_RX_LED_ON() LED1_ON()
#define RF_RX_LED_OFF() LED1_OFF()
#define RF_TX_LED_ON() LED2_ON()
#define RF_TX_LED_OFF() LED2_OFF()
#else
#if HAVE_RF_LED == 1
#define RF_RX_LED_ON() LED1_ON()
#define RF_RX_LED_OFF() LED1_OFF()
#define RF_TX_LED_ON() LED1_ON()
#define RF_TX_LED_OFF() LED1_OFF()
#else
#define RF_RX_LED_ON() LED2_ON()
#define RF_RX_LED_OFF() LED2_OFF()
#define RF_TX_LED_ON() LED2_ON()
#define RF_TX_LED_OFF() LED2_OFF()
#endif /*RF_LED == 1 */
#endif	/*HAVE_NRP*/
#else
#define RF_RX_LED_ON()
#define RF_RX_LED_OFF()
#define RF_TX_LED_ON()
#define RF_TX_LED_OFF()
#endif /*HAVE_RF_LED*/

uint8_t rf_initialized = 0;

uint8_t rf_tx_power;
uint8_t rx_flags, tx_flags;
#define RX_ACTIVE 0x80

uint16_t rf_manfid;

sockaddr_t rf_mac_address;

xDMAHandle rf_dma = 0;
void rf_dma_callback(void *param);
void rf_dma_callback_isr(void *param);

extern void pause(uint16_t time);

#define RF_BUFFER volatile_ram1

/**
 * Execute a single CSP command.
 *
 * \param command command to execute
 *
 */
void rf_command(uint8_t command)
{
	if (command >= 0xE0)
	{	/*immediate strobe*/
		uint8_t fifo_count;
		switch (command)
		{	/*hardware bug workaround*/
			case ISRFOFF:
			case ISRXON:
			case ISTXON:
				fifo_count = RXFIFOCNT;
				RFST = command;
				pause_us(1);
				if (fifo_count != RXFIFOCNT)
				{
					RFST = ISFLUSHRX;
					RFST = ISFLUSHRX;
				}
				break;
				
			default:
				RFST = command;
		}
	}
	else if (command == SSTART)
	{
		RFIF &= ~IRQ_CSP_STOP;	/*clear IRQ flag*/
		RFST = SSTOP;	/*make sure there is a stop in the end*/
		RFST = ISSTART;	/*start execution*/
		while((RFIF & IRQ_CSP_STOP) == 0);
	}
	else
	{
		RFST = command;	/*write command*/
	}
}

/**
 * Select RF channel.
 *
 * \param channel channel number to select
 *
 * \return channel value or negative (invalid channel number)
 */
 
 /* channel freqdiv = (2048 + FSCTRL(9:0)) / 4
            freq = (2048 + FSCTRL(9:0)) MHz */

portCHAR rf_channel_set(uint8_t channel)
{
	uint16_t freq;
	
	if ( (channel < 11) || (channel > 26) ) return -1;
	
	/* Channel values: 11-26 */
	freq = (uint16_t) channel - 11;
	freq *= 5;	/*channel spacing*/
	freq += 357; /*correct channel range*/
	freq |= 0x4000; /*LOCK_THR = 1*/

	FSCTRLH = (freq >> 8);
	FSCTRLL = (uint8_t)freq;	
	
	return (int8_t) channel;
}

/*PA_LEVEL TXCTRL register Output Power [dBm] Current Consumption [mA] 
	31 0xA0FF 0 17.4 
	27 0xA0FB -1 16.5 
	23 0xA0F7 -3 15.2 
	19 0xA0F3 -5 13.9 
	15 0xA0EF -7 12.5 
	11 0xA0EB -10 11.2 
	 7 0xA0E7 -15 9.9 
	 3 0xA0E3 -25 8.5*/

/**
 * Select RF transmit power.
 *
 * \param new_power new power level (in per cent)
 *
 * \return new level or negative (value out of range)
 */
 
portCHAR rf_power_set(uint8_t new_power)
{
	uint16_t power;
	
	if (new_power > 100) return -1;
	
	power = 31 * new_power;
	power /= 100;
	power += 0xA160;
		
	/* Set transmitter power */
	TXCTRLH = (power >> 8);
	TXCTRLL = (uint8_t)power;	
	
	rf_tx_power = (int8_t) new_power;
	return rf_tx_power;
}

/* RF DMA setup should be:
	source RFD,
	destination volatile_ram2,
	length = VLEN_N1,
	LEN = 131, 128 + 2 RSSI + len,
	byte mode + single block transfer, trigger=RADIO,
	src_inc = none, dst_inc = increment 1,  IRQ on, priority = 2 */


/**
 * Enable RF receiver.
 *
 *
 * \return pdTRUE
 * \return pdFALSE	bus not free
 */
portCHAR rf_rx_enable(void)
{
	if (rx_flags == 0)
	{
		void *src = &RFD_SHADOW;

		dma_abort(rf_dma);
				
		tx_flags = 0;
		rx_flags = RX_ACTIVE;

		RFPWR &= ~RREG_RADIO_PD;	/*make sure it's powered*/
		while((RFIF & IRQ_RREG_ON) == 0);	/*wait for power up*/
		SLEEP &= ~OSC_PD; /*Osc on*/
		while((SLEEP & XOSC_STB) == 0);	/*wait for power up*/

		rf_command(ISRXON);
		
		rf_dma = dma_config(4, (void *) src, DMA_NOINC, (void *) RF_BUFFER, DMA_INC,
				131, DMA_VLEN_N1, DMA_BLOCK, DMA_T_RADIO, rf_dma_callback);
		dma_arm(rf_dma);
	}
	
	return pdTRUE;
}

/**
 * Disable RF receiver.
 *
 *
 * \return pdTRUE
 * \return pdFALSE	bus not free
 */
portCHAR rf_rx_disable(void)
{
	rf_command(ISSTOP);	/*make sure CSP is not running*/
	dma_abort(rf_dma);

	rf_command(ISRFOFF);

	RFPWR |= RREG_RADIO_PD;		/*RF powerdown*/

	rx_flags = 0;
	tx_flags = 0;
	return pdTRUE;
}


/**
 * Enable RF transmitter.
 *
 *
 * \return pdTRUE
 * \return pdFALSE	bus not free
 */
portCHAR rf_tx_enable(void)
{
	dma_abort(rf_dma);
	tx_flags |= RX_ACTIVE;
	rx_flags = 0;
	RFPWR &= ~RREG_RADIO_PD;	/*make sure it's powered*/
	while((RFIF & IRQ_RREG_ON) == 0);	/*wait for power up*/
	SLEEP &= ~OSC_PD; /*Osc on*/
	while((SLEEP & XOSC_STB) == 0);	/*wait for power up*/

	return pdTRUE;
}

   
/**
 * Initialize RF.
 *
 *
 * \return pdTRUE
 * \return pdFALSE	bus not free or init failed
 */

portCHAR rf_init(void)
{
	portCHAR retval = pdFALSE;

	if (rf_initialized) return pdTRUE;

	dma_init();
		
	RFPWR &= ~RREG_RADIO_PD;	/*make sure it's powered*/
	while ((RFPWR & ADI_RADIO_PD) == 1);
	while((RFIF & IRQ_RREG_ON) == 0);	/*wait for power up*/
	SLEEP &= ~OSC_PD; /*Osc on*/
	while((SLEEP & XOSC_STB) == 0);	/*wait for power up*/
	
	rx_flags = tx_flags = 0;
	
	retval = pdTRUE;

#ifdef RF_DEBUG
	debug("RF setup.\r\n");		
#endif		
	FSMTC1 &= ~ABORTRX_ON_SRXON;	/*don't abort reception, if enable called*/
  	MDMCTRL0H = 0x02;
	MDMCTRL0L = 0xE2;

/*  	MDMCTRL1H = 0x30; */
	MDMCTRL1H = 0x14;			/*set correlation threshold to same as CC2420*/
	MDMCTRL1L = 0x00;
	
  	IOCFG0 = 0x7F;   // Set the FIFOP threshold to maximum 
/*  	CC2420_REG_SET(CC_REG_SECCTRL0, 0x01C4); // Turn off "Security enable"*/

	/* get ID for MAC */
	rf_manfid = CHVER;
	rf_manfid <<= 8;		
	rf_manfid += CHIPID;

	rf_channel_set(RF_DEFAULT_CHANNEL);

	/* Set transmitter power */
	rf_power_set(RF_DEFAULT_POWER);

	retval = pdTRUE;
		
	rf_command(ISFLUSHTX);
	rf_command(ISFLUSHRX);
	tx_flags = 0;

	rf_rx_enable();

	RF_BUFFER[0] = 0;
#ifdef RF_DEBUG				
	debug("RF: Up.\r\n");
#endif
	rf_initialized = 1;
	return retval;
}

/**
 * Set address decoder on/off.
 *
 * \param param 1=on 0=off. 
 * \return pdTRUE operation successful
 */
portCHAR rf_address_decoder_mode(uint8_t param)
{
	portCHAR retval = pdFALSE;

	/* set oscillator on*/	
	if(param)
	{
#ifdef COORDINATOR
		MDMCTRL0H = 0x1A;	 /*Coordinator, Address-decode on */
		MDMCTRL0L = 0xE2;	 /* no automatic ACK */
		
		
/*		CC2420_REG_SET(CC_REG_IOCFG0, 0x0840);*/		/* Enable receive beacon if address decoder is enabled */
#else
#ifdef HAVE_NRP
		MDMCTRL0H = 0x02;	 /* Generic client */
		MDMCTRL0L = 0xE2;	 /* no automatic ACK */
#else
		MDMCTRL0H = 0x0A;	 /*Address-decode on */
		MDMCTRL0L = 0xF2;	 /*automatic ACK */

/*		CC2420_REG_SET(CC_REG_IOCFG0, 0x0840);	*/	/* Enable receive beacon if address decoder is enabled */
#endif
#endif	
	}
	else
	{
		MDMCTRL0H = 0x02;	 /* Generic client */
		MDMCTRL0L = 0xE2;	 /* no automatic ACK */
	}
	retval = pdTRUE;
	return retval; 
}

/**
	* Set address decoder parameters
	*
	*	\param address address for decoder
	*/
void rf_set_address(sockaddr_t *address)
{
	uint8_t i;
	__xdata unsigned char *ptr;
	
	switch(address->addr_type)
	{
		case ADDR_802_15_4_PAN_LONG:
			ptr = &IEEE_ADDR0;
			for(i=0; i<8;i++)
			{
				*ptr++ = address->address[i];
			}
			PANIDH = address->address[8];
			PANIDL = address->address[9];
			break;
		
		case ADDR_802_15_4_PAN_SHORT:
			SHORTADDRH = address->address[0];
			SHORTADDRL = address->address[1];
			PANIDH = address->address[2];
			PANIDL = address->address[3];
			break;
		
		default:
			break;
	}			
}


/**
 * Send ACK.
 *
 *\param pending set up pending flag if pending > 0. 
 */
void rf_send_ack(uint8_t pending)
{
	if(pending)
	{
		rf_command(ISACKPEND);
	}
	else
	{
		rf_command(ISACK);
	}
}

/**
 * Transmit packet.
 *
 * Missing feature: address type check
 *
 * \param mac RF HW address
 * \param dst destination HW address
 * \param buffer data buffer pointer
 * \param length length of data
 *
 * \return pdTRUE+1 channel occupied
 * \return pdTRUE
 * \return pdFALSE	bus reserved
 */

portCHAR rf_write(buffer_t *buffer)
{
	uint8_t counter, i;
	portCHAR retval = pdTRUE;
	int16_t length =  buffer->buf_end - buffer->buf_ptr;
	
	if (rx_flags & RX_ACTIVE)
	{
		if ( (RFSTATUS & FIFOP) || (RFSTATUS & SFD) )
		{
			debug("RF: Packet IF busy.\r\n");
			if ((RFSTATUS & FIFOP))
			{
				rf_command(ISFLUSHTX);
				rf_command(ISFLUSHRX);
			}

			retval = pdFALSE;		
		}
	}
	rf_tx_enable();
	if ( (length <= 128) && (retval == pdTRUE) )
	{
/*		rx_disable();*/

		RF_TX_LED_ON();
/*		debug("RF: RX on.\r\n");*/

		rf_command(ISRXON);

		pause(1);

		if ((RFSTATUS & CCA) == 0)
		{
			debug("RF: Channel occupied.\r\n");
			tx_flags = 0;
			retval = pdTRUE+1;
			
		}
		rf_command(ISFLUSHTX);

		if (retval == pdTRUE)
		{
			uint8_t *ptr;
			
			rx_flags = 0;
#ifdef RF_TX_DMA
			if (buffer->buf_ptr == 0)
			{
				memmove(&(buffer->buf[1]),&(buffer->buf[0]), length);
				buffer->buf_ptr++;
				buffer->buf_end++;
			}
			ptr = buffer_data_end(buffer);
			*ptr++ = 0;
			*ptr++ = 0;

			ptr = buffer_data_pointer(buffer);
			ptr--;
			*ptr = length + 2;
			
			rf_dma = dma_config(4, (void *) ptr, DMA_INC, (void *) &RFD_SHADOW, DMA_NOINC,
				length + 3, DMA_VLEN_LEN, DMA_BLOCK, DMA_T_NONE, 0);
			dma_arm(rf_dma);
			dma_trigger(rf_dma);
			
			while (dma_state(rf_dma) == pdTRUE);			
#else
			ptr = buffer_data_pointer(buffer);
			
			RFD_SHADOW = length + 2;
			for (i=0; i<length; i++)
			{
				RFD_SHADOW = *ptr++;
			}
			RFD_SHADOW = 0;
			RFD_SHADOW = 0;
#endif
			
			rf_command(ISTXONCCA);
			counter = 0;	
			while( ((RFSTATUS & TX_ACTIVE) == 0) && (counter++ < 200))
			{
				pause(1);
			}
			
			if (counter < 200)
			{
				while((RFIF & IRQ_TXDONE) == 0);
			}
			else
			{
				debug("\r\nRF: TX never active.\r\n");

				rf_command(ISFLUSHTX);
				rf_command(ISRFOFF);
				tx_flags = 0;

				retval = pdTRUE+1;
			}
		}

#ifdef RF_DEBUG
		if (retval == pdTRUE)
		{
			debug("RF: Done.\r\n");
		}
#endif
	}
	if ((retval == pdTRUE) && (length > 128))
	{
		debug("Packet too long(");
		debug_int(length);
		debug(").\r\n");

		retval = pdFALSE;
	}

	RF_TX_LED_OFF();
	tx_flags = 0;
	rx_flags = 0;
	rf_rx_enable();

	return retval;		
}


/**
 * RF DMA callback.
 *
 * \param param not used;
 *
 */
void rf_dma_callback(void *param)
{
	uint8_t *ptr = RF_BUFFER;
	uint8_t len;
	buffer_t *rf_buf = stack_buffer_get(20);
	
	param;

	if (rf_buf != 0)
	{
		rf_buf->options.rf_dbm = -90;
		rf_buf->options.rf_lqi = 0;
		rf_buf->buf_end = 0;
		rf_buf->buf_ptr = 0;
		rf_buf->to = 0;
		rf_buf->dir = BUFFER_UP;
		
		len = *ptr++;
		len -= 2;

		if ((len > 4) && (len <= 128))
		{
			rf_buf->options.rf_dbm = ((int8_t) ptr[len]) - 45;
			rf_buf->options.rf_lqi = ptr[len+1];

			memcpy(rf_buf->buf, ptr, len);
			ptr += len;
			
			rf_buf->options.rf_dbm = ((int8_t) *ptr++) - 45;
			rf_buf->options.rf_lqi = *ptr++;

			rf_buf->to = MODULE_802_15_4_RAW;
			rf_buf->buf_ptr = 0;
			rf_buf->buf_end = len;
			
			rx_flags = 0;
			rf_rx_enable();
			
			if (rf_buf->options.rf_lqi & 0x80)
			{
				stack_buffer_free(rf_buf);
			}
			else
			{
#ifdef RF_DEBUG_RSSI
				debug("RSSI: ");
				debug_int(rf_buf->options.rf_dbm);
				debug(" dBm, LQI ");
				debug_int(rf_buf->options.rf_lqi);
				debug(".\r\n");
#endif	
			
				stack_buffer_push(rf_buf);
			}
			rf_buf = 0;
		}
		else
		{
			rx_flags = 0;
			rf_rx_enable();
			
			stack_buffer_free(rf_buf);
		}
	}
	else
	{
		rx_flags = 0;
		rf_rx_enable();
			
#ifdef RF_DEBUG_RSSI
		debug("RF: No buffers. Drop.\r\n");
#endif	
	}
	
}

extern xQueueHandle buffers;
/**
 * RF DMA callback, ISR version.
 *
 * \param param not used;
 *
 */
void rf_dma_callback_isr(void *param)
{
	portBASE_TYPE prev_task = pdFALSE;
	uint8_t *ptr = RF_BUFFER;
	uint8_t len;
	buffer_t *rf_buf = 0;
	
	param;
	if (xQueueReceiveFromISR( buffers, &( rf_buf ), &prev_task) == pdTRUE)
	{
		rf_buf->options.type = BUFFER_DATA;
		rf_buf->socket = 0;
		rf_buf->buf_ptr = 0;
		rf_buf->to = MODULE_802_15_4_RAW;
		rf_buf->dir = BUFFER_UP;
		
		len = *ptr++ & 0x7F;
		len -= 2;

		if (len > 4)
		{
			memcpy(rf_buf->buf, ptr, len);
			ptr += len;
			
			rf_buf->options.rf_dbm = ((int8_t) *ptr++) - 45;
			rf_buf->options.rf_lqi = *ptr++;

			rf_buf->buf_end = len;
			rf_buf->options.rf_lqi &= 0x7F;

			rx_flags = 0;
			
			rf_rx_enable();
			{
				event_t event;
				event.process = 0;
				event.param = (void *) rf_buf;
	
				prev_task = xQueueSendFromISR( events, ( void * ) &event, prev_task);
				taskYIELD();
			}
		}
		else
		{
			rx_flags = 0;
			rf_rx_enable();
			
			prev_task = xQueueSendFromISR( buffers, ( void * ) &rf_buf, prev_task);
			taskYIELD();
		}
	}
	else
	{
		rx_flags = 0;
		rf_rx_enable();
	}
	
}


/**
 * RF interrupt service routine.
 *
 */
void rf_ISR( void ) interrupt (RF_VECTOR)
{
/*	portBASE_TYPE task = pdFALSE;*/

	if (RFIF & IRQ_SFD)
	{
		RFIF &= ~IRQ_SFD;
	}
	S1CON &= ~(RFIF_0 | RFIF_1);
#ifdef HAVE_POWERSAVE
	power_interrupt_epilogue();
#endif
}

/**
 * RF error interrupt service routine.
 *
 */
void rf_error_ISR( void ) interrupt (RFERR_VECTOR)
{
	TCON_RFERRIF = 0;
#ifdef HAVE_POWERSAVE
	power_interrupt_epilogue();
#endif
}


