#!/bin/sh

MODULEFILE=/usr/share/ideasilo/ftdi_sio.ko
MODULE=ftdi_sio


case "$1" in
	start)
		test -e $MODULEFILE || exit 0
		insmod $MODULEFILE
#		exit 0
	;;
	stop)
		rmmod $MODULE
#		exit 0
	;;
	restart|reload|force-reload)
	;;
	*)
		echo "Usage: $0 {start|stop}"
	;;
esac

#exit 0
