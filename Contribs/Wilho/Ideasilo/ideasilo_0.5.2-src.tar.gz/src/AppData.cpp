#include "AppData.h"
#include <hildon-widgets/hildon-banner.h>
#include <gdk/gdkkeysyms.h>

const char * DEFAULT_ICONPATH = "/usr/share/";
const char * SETTINGSFILENAME = "ideasilo.cnf";

#include <iostream>
#include <sys/stat.h>
#include "util/Util.h"

AppData::AppData(list<string> args):
program(NULL),
window(NULL),
osso_context(NULL),
evbuf(NULL),
log(NULL),
_callbackwriter(NULL){
	// Find out the proper setting for the data and icon paths
	string newdatapath(APP_DATADIR);
	string newiconpath(DEFAULT_ICONPATH);
	userdatapath = string(g_get_home_dir()) + "/." + APP_UNIX_NAME;
	
	struct stat fileinfo;
	if (stat(userdatapath.c_str(), &fileinfo) == -1) {
		mkdir(userdatapath.c_str(), S_IRWXU | S_IRGRP | S_IROTH | S_IXGRP | S_IXOTH);
	}

	for (;!args.empty();) {
		string cmd = args.front();
		args.pop_front();
		if (!cmd.compare("--datadir") && args.size() > 0) {
			newdatapath = args.front();
			args.pop_front();	
		}
		if (!cmd.compare("--icondir") && args.size() > 0) {
			newiconpath = args.front();
			args.pop_front();	
		}
	}
	if (newdatapath.at(newdatapath.length()-1) != '/')
		newdatapath += "/";
	if (newiconpath.at(newiconpath.length()-1) != '/')
		newiconpath += "/";
	if (userdatapath.at(userdatapath.length()-1) != '/')
		userdatapath += "/";
	
	datapath = newdatapath;
	iconpath = newiconpath;

	if (stat((userdatapath + SETTINGSFILENAME).c_str(), &fileinfo) == -1) {
		//int result = 
		Util::copyFile(datapath + SETTINGSFILENAME, userdatapath + SETTINGSFILENAME);
	}
	
	// Prepare the logger
	string logfilename = userdatapath + "/" + APP_UNIX_NAME + ".log";
	//cout << "Logfilename: " << logfilename << endl;
	log = new Logger(logfilename.c_str());

	log->write("Logging started in: " + logfilename);
	log->write("Main: Set data path to: " + newdatapath);
	log->write("Main: Set icon search path to: " + newiconpath);
	
    evbuf = new EventBuffer(1,100); //TODO: Add unlimited writers and a release function
    _callbackwriter = evbuf->requestWriter();
    
    initOssoContext();
    
	// Create the hildon program and setup the title
   	program = HILDON_PROGRAM(hildon_program_get_instance());
    g_set_application_name(APP_NAME);
    
    // Create the main window and add it to the program
   	window = HILDON_WINDOW(hildon_window_new());
    hildon_program_add_window(program, window);
    
    // Set keypress and event handlers for the main window
	g_signal_connect(G_OBJECT(window), "key_press_event", G_CALLBACK(keypress_handler), window);
    g_signal_connect(G_OBJECT(window), "window_state_event", G_CALLBACK(window_state_handler), window);

}

AppData::~AppData() {
	delete evbuf;
	evbuf = NULL;
	
	if (log) {
		log->write("Logging ended.");
		delete log;
	}
	
	osso_deinitialize(osso_context);	// clean up osso
}


void AppData::setUIFilename(const char * filename) {
	// Ensure the last character in the path is a /
	string newfile;
	if (datapath.length() == 0 || filename[0] == '/')
		newfile = filename;
	else
		newfile = string(datapath) + filename;
	uifilename = newfile;
	if (log)
		log->write("Main: Icon search path to: " + newfile);
}

void AppData::fatal_error(const char * msg, int erno) {
	if (log)
		log->write(msg, erno);
	g_print("Error (%d): %s\n", erno, msg);
	exit(erno);
}

void AppData::initOssoContext() {
    // Initialize osso, so that the application does not exit automatically after a few seconds
	if (!(osso_context = osso_initialize(APP_NAME, APP_VER, TRUE, NULL)))
		fatal_error("Error initializing osso.", OSSO_ERROR);
    // Set handlers for D-BUS messages
    int result;
	if ((result = osso_rpc_set_cb_f(osso_context, APP_SERVICE, APP_METHOD, APP_IFACE, dbus_req_handler, this)) != OSSO_OK)
		fatal_error("Error setting D-BUS callback.", result);
	if ((result = osso_hw_set_event_cb(osso_context, NULL, dbus_hw_event_handler, this)) != OSSO_OK)
		fatal_error("Error setting HW state callback.", result);
	

}

static bool main_window_fullscreen = false;
gboolean AppData::keypress_handler(GtkWidget * widget, GdkEventKey * event, HildonWindow * window) {
	switch (event->keyval) {
	case GDK_F6:	// Fullscreen button
		if (main_window_fullscreen)
			gtk_window_unfullscreen(GTK_WINDOW(window));
		else
			gtk_window_fullscreen(GTK_WINDOW(window));
		return true;
	}
	return false;
}

void AppData::window_state_handler(GtkWidget * widget, GdkEventWindowState * event, HildonWindow * window) {
	main_window_fullscreen = (event->new_window_state & GDK_WINDOW_STATE_FULLSCREEN) > 0;
}

// Callback for normal D-Bus messages
gint AppData::dbus_req_handler(const gchar *interface, const gchar *method,
		GArray *arguments, gpointer data, osso_rpc_t *retval)
{
	printf("dbus: %s, %s\n", interface, method);
	AppData * appdata = (AppData*)data;
	string msg = string("D-Bus message: ") + method;
	if (appdata && appdata->log)
		appdata->log->write(msg.c_str());
	//osso_system_note_infoprint(appdata->osso_context, method, retval);
	osso_rpc_free_val(retval);

	return OSSO_OK;
}

// Callback for D-Bus hardware events
// TODO: Find out about thread safety
void AppData::dbus_hw_event_handler(osso_hw_state_t * state, gpointer data) {
	AppData * appdata = (AppData*)data;
	if (state->shutdown_ind) {
		hildon_banner_show_information(GTK_WIDGET(appdata->window), NULL, "Shutdown event!");
	}
	if (state->memory_low_ind) {
		hildon_banner_show_information(GTK_WIDGET(appdata->window), NULL, "Memory low event!");
	}
	if (state->save_unsaved_data_ind) {
		hildon_banner_show_information(GTK_WIDGET(appdata->window), NULL, "Must save unsaved data event!");
	}
	if (state->system_inactivity_ind) {
		hildon_banner_show_information(GTK_WIDGET(appdata->window), NULL, "Minimize application inactivity event!");
	}
}





