#ifndef EVENTBUFFER_H_
#define EVENTBUFFER_H_

#include <queue>
#include <pthread.h>

class Event;

using namespace std;



// A thread safe queue to store Events and deal out a controlled
// number of readers and writers.
class EventBuffer {
public:
	EventBuffer(int readers, int writers);
	~EventBuffer();
	class Reader;
	class Writer;
	
	Reader * requestReader();
	Writer * requestWriter();
	
private:
	queue<Event*> _queue;
	const int _READERS_AVAILABLE;
	const int _WRITERS_AVAILABLE;
	int _writersInUse;
	int _readersInUse;
	Reader ** _reservedReaders;
	Writer ** _reservedWriters;
	
	pthread_mutex_t	_lock;
	pthread_cond_t _emptyCondition;
	pthread_mutex_t _readerRequestLock;
	pthread_mutex_t _writerRequestLock;

};

class EventBuffer::Reader {
	friend class EventBuffer;
	public:
		Event* pop();
		Event* pop(unsigned long timeout);		// timeout in ms
		void release();
		int getID() { return ID; }
	private:
		Reader(EventBuffer * newParent):parent(*newParent) {}
		Reader(const Reader &);
		EventBuffer & parent;
		int ID;
};
	
class EventBuffer::Writer {
	friend class EventBuffer;
	public:
		void push(Event *);
		void release();
		int getID() { return ID; }
	private:
		Writer(EventBuffer * newParent):parent(*newParent) {}
		Writer(const Writer &);
		EventBuffer & parent;
		int ID;
};

#endif /*EVENTBUFFER_H_*/
