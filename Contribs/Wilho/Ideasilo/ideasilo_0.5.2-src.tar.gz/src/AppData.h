#ifndef APPDATA_H_
#define APPDATA_H_

#define APP_NAME "Ideasilo"
#define APP_UNIX_NAME "ideasilo"
#define APP_VER "1.0"
#define APP_SERVICE "isg.ideasilo"
#define APP_METHOD "/isg/ideasilo"
#define APP_IFACE "isg.ideasilo"

extern const char * SETTINGSFILENAME;

#include <list> 		// For argument handling
#include <libosso.h>
#include <hildon-widgets/hildon-program.h>
#include "event/EventBuffer.h"		
#include "util/Logger.h"



// A class for storing not-so-interesting data about the application 
class AppData {
public:
	AppData(list<string> args);
	~AppData();
	
	void setUIFilename(const char * filename);
	void fatal_error(const char * msg, int erno);
	
	HildonProgram * program;		// A Hildon widget representing the program
	HildonWindow * window;			// A Hildon widget representing the main window
	osso_context_t * osso_context;	
	EventBuffer	* evbuf;			// The event buffer where application generated events are stored
	string uifilename;				// The glade file containing the general UI layout
	string datapath;				// The path to the application data directory
	string userdatapath;			// The path to the user specific data directory
	string iconpath;				// The path to the icons
	Logger * log;					// Generic logging service
	
private:
	void initOssoContext();
	static gboolean 	keypress_handler(GtkWidget * widget, GdkEventKey * event, HildonWindow * window);
	static void 		window_state_handler(GtkWidget * widget, GdkEventWindowState * event, HildonWindow * window);
	static gint 		dbus_req_handler(const gchar *interface, const gchar *method, GArray *arguments, gpointer data, osso_rpc_t *retval);
	static void 		dbus_hw_event_handler(osso_hw_state_t * state, gpointer data);

	EventBuffer::Writer * 	_callbackwriter;
	
};

#endif /*APPDATA_H_*/
