#include "DataEntryView.h"
#include "util/widgethandler.h"
#include "event/DataPageViewEvent.h"
#include "event/GUIEvent.h"
#include "gui/ManagePageView.h"
#include <iostream> //DEBUG

namespace DataEntryTag {
	GtkIconSize ICONSIZE = GTK_ICON_SIZE_LARGE_TOOLBAR;
	const char * BUTTON_IMAGE = "[entry]button_image";
	const char * BUTTONROOT = "[entry]button_box";
	const char * BUTTON = "[entry]button";
	const char * LABELROOT = "[entry]label_box";
	const char * LABELBUTTON = "[entry]label_button";
	const char * DATA = "[entry]data";	
}


DataEntryView::DataEntryView(const char * uifilename, EventBuffer::Writer * writer, ManagePageView * pageview):
_writer(writer),
_uifilename(uifilename),
_pageview(pageview),
_set(NULL),
_entry(NULL),
_buttonxml(NULL),
_labelxml(NULL),
_dataxml(NULL),
_buttonroot(NULL),
_labelroot(NULL),
_dataroot(NULL),
_showbutton(false)
{
}

DataEntryView::~DataEntryView()
{
	if (_buttonxml) g_object_unref(_buttonxml);
	if (_labelxml) g_object_unref(_labelxml);
	if (_dataxml) g_object_unref(_dataxml);
	WidgetUtil::destroyWidget(_buttonroot);
	WidgetUtil::destroyWidget(_labelroot);
	WidgetUtil::destroyWidget(_dataroot);
	
}

DataEntryWidgets DataEntryView::getWidgets() {
	DataEntryWidgets temp;
	temp.buttonroot = _buttonroot;
	temp.labelroot = _labelroot;
	temp.dataroot = _dataroot;
	return temp;
}

void DataEntryView::displayEntry(DataEntry * entry, DataSet * set, bool showbutton) {
	if (!entry || !set)
		return;
	//cout << "DataEntryView::displayEntry:" << entry->getName() << " " << entry->getData() << endl;
	GdkThread::enter();
	if (_set != set || _entry != entry || _showbutton != showbutton) {
		_entry = entry;
		_set = set;
		_showbutton = showbutton;
		if (_buttonroot && _labelroot && _dataroot)
			redrawWidgets();
	}
	GdkThread::leave();
}


DataEntryWidgets DataEntryView::createEntryWidgets() {
	GdkThread::enter();
	if (!_buttonxml) {
		_buttonxml = glade_xml_new(_uifilename, DataEntryTag::BUTTONROOT, NULL);
		_buttonroot = glade_xml_get_widget(_buttonxml, DataEntryTag::BUTTONROOT);
		GtkWidget * button = glade_xml_get_widget(_buttonxml, DataEntryTag::BUTTON);
		g_signal_connect(G_OBJECT(button), "clicked", G_CALLBACK(entry_source_change), this);
	}
	if (!_labelxml) {
		_labelxml = glade_xml_new(_uifilename, DataEntryTag::LABELROOT, NULL);
		_labelroot = glade_xml_get_widget(_labelxml, DataEntryTag::LABELROOT);
		GtkWidget * labelbutton = glade_xml_get_widget(_labelxml, DataEntryTag::LABELBUTTON);
		g_signal_connect(G_OBJECT(labelbutton), "clicked", G_CALLBACK(entry_label_clicked), this);
		g_signal_connect(G_OBJECT(labelbutton), "enter-notify-event", G_CALLBACK(pointer_crossing_event), this);
		g_signal_connect(G_OBJECT(labelbutton), "leave-notify-event", G_CALLBACK(pointer_crossing_event), this);
		g_signal_connect(G_OBJECT(labelbutton), "button-press-event", G_CALLBACK(WidgetUtil::disable_event), this);
		g_signal_connect(G_OBJECT(labelbutton), "button-release-event", G_CALLBACK(WidgetUtil::disable_event), this);

	}
	if (!_dataxml) {
		_dataxml = glade_xml_new(_uifilename, DataEntryTag::DATA, NULL);
		_dataroot = glade_xml_get_widget(_dataxml, DataEntryTag::DATA);
	}
	GdkThread::leave();
	return getWidgets();
}

void DataEntryView::redrawWidgets() {
	if (!_entry)
		return;
	GdkThread::enter();
	if (_labelroot) {
		GtkButton * label = GTK_BUTTON(glade_xml_get_widget(_labelxml, DataEntryTag::LABELBUTTON));
		gtk_button_set_label(label, (_entry->getName() + ":").c_str());
	}
	if (_dataroot) {
		GtkTextBuffer * textbuf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(_dataroot));
		gtk_text_buffer_set_text(textbuf, _entry->getData().c_str(), -1);
	}
	if (_buttonroot) {
		if (_showbutton) {
			DataSource source = _set->getSource();
			const char * stockid = NULL;
			if (source == UNKNOWN)
				stockid = "gtk-information";	
			else if (source == RFID)
				stockid = "gtk-disconnect";	
			else if (source == SERVER)
				stockid = "gtk-connect";	
			else if (source == MODIFIED)
				stockid = "gtk-edit";
			GtkImage * image = GTK_IMAGE(glade_xml_get_widget(_buttonxml, DataEntryTag::BUTTON_IMAGE));
			gtk_image_set_from_stock(image, stockid, DataEntryTag::ICONSIZE);	
			gtk_widget_show_all(_buttonroot);	
		} else
			gtk_widget_hide_all(_buttonroot);
	}
	GdkThread::leave();
}

void DataEntryView::setHilight(bool hilight) {
	if (_labelxml) {
		GtkButton * label = GTK_BUTTON(glade_xml_get_widget(_labelxml, DataEntryTag::LABELBUTTON));
		if (hilight)
			gtk_button_set_relief(label, GTK_RELIEF_NORMAL);
		else
			gtk_button_set_relief(label, GTK_RELIEF_NONE);
	}
}

// ************* CALLBACKS ***************

void DataEntryView::entry_source_change(GtkWidget * widget, gpointer entryview) {
	DataEntryView * view = static_cast<DataEntryView*>(entryview);
	if (view->_showbutton)
		view->_writer->push(new SourceChangeEvent(view->_set->getID(), view->_entry->getID()));
}

bool DataEntryView::pointer_crossing_event(GtkWidget * widget, GdkEventCrossing * event, gpointer entryview) {
	if (event->mode == GDK_CROSSING_UNGRAB)
		entry_label_clicked(widget, entryview);
	return true;
}

void DataEntryView::entry_label_clicked(GtkWidget * widget, gpointer entryview) {
	DataEntryView * view = static_cast<DataEntryView*>(entryview);
	if (view && view->_set && view->_entry)
		view->_writer->push(new FocusChangeEvent(view->_set->getID(), view->_entry->getID()));
}
