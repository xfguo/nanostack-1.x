#include "ApplicationMode.h"

ApplicationMode::ApplicationMode(AppData * appdata, SettingHandler * appsettings, const DataBase & db, const rootnodes & rnodes):
_appdata(appdata),
_appsettings(appsettings),
_currentcontext(NULL),
_db(db),
_rootnodes(rnodes),
_frontwidget(NULL),
_toolbar(NULL)
{
	_writer = appdata->evbuf->requestWriter();
}

ApplicationMode::~ApplicationMode() {
	delete _currentcontext;
}

void ApplicationMode::setContext(const Context * newcontext) {
	if (!newcontext)
		return;
	if (!_currentcontext || newcontext != _currentcontext) {
		delete _currentcontext;
		_currentcontext = new Context(*newcontext);
	}
}

void ApplicationMode::refreshNodes() {
	const DataBase::nodes & db = _db.getNodes();
	for (DataBase::nodes::const_iterator it = db.begin(); it != db.end(); it++) {
		refreshNode(it->first);
	}
}

const Node * ApplicationMode::getNode(const string & ID) const {
	return _db.get(ID);
}

Node * ApplicationMode::getNodeCopy(const string & ID, int depth) const {
	return _db.getCopy(ID, depth);
}

int ApplicationMode::isRootNode(const string & nodeid) const {
	int index = 0;
	for (rootnodes::const_iterator it = _rootnodes.begin(); it != _rootnodes.end(); it++, index++) {
		if (!it->compare(nodeid))
			return index;
	}
	return -1;
}



