#include "GUI.h"

#include <iostream> //DEBUG
#include <fstream>
#include <sstream>
#include <glib-object.h>
#include <hildon-widgets/hildon-banner.h>	// For displaying hildon status messages
#include <dirent.h>
#include <errno.h>
#include "event/ApplicationEvent.h"
#include "event/GUIEvent.h"
#include "network/NetworkEvent.h"
#include "dialog/SettingsDialog.h"
#include "action/QuitAction.h"
#include "managemode/ManageMode.h"
#include "orderingmode/OrderingMode.h"
#include "dataformat/ImageLeaf.h"
#include "dataformat/Branch.h"

namespace MESSAGE {
	namespace ERROR {
		const char * GUI_MISSING= "Standing by for user interface...";
		const char * CONTEXT_MISSING = "Standing by for context information...";
		const char * MODE_MISSING = "Unable to display user interface";
	}
	namespace STATUS {
		const char * OFFLINE = "Not connected to server";
		const char * ONLINE = "Connected to server";
	}
	

}

namespace GLADE {
	const char * TOP = "[main]top";
	const char * STATUSBAR = "[main]statusbar";
}

namespace IO {
	const char * CONTEXT_FOLDER = "context/";
	const char * CONTEXT_SUFFIX = ".cnt";
	const char * DEFAULT_CONTEXT_FILE = "default.cnt";
	const char * SERVER_CONN_ON_FILE = "server-on.png";
	const char * SERVER_CONN_OFF_FILE = "server-off.png";
	const char * READER_CONN_ON_FILE = "reader-on.png";
	const char * READER_CONN_OFF_FILE = "reader-off.png";
}

GUI::GUI(AppData * appdata, SettingHandler * appsettings):
_evwriter(appdata->evbuf->requestWriter()),
_appdata(appdata),
_appsettings(appsettings),
_toolbar(NULL),
_menu(NULL),
_contexttoolitem(NULL),
_contextbox(NULL),
_frontpage(NULL),
_guierrorpage(NULL),
_readerstatusicon(NULL),
_serverstatusicon(NULL),
_serverstatus(false),
_opensettingsaction(NULL),
_quitaction(NULL),
_activecontext(-1),
_activemode(-1)
{
	_readerconnimg[0] = NULL;
	_readerconnimg[1] = NULL;
	_serverconnimg[0] = NULL;
	_serverconnimg[1] = NULL;
}

GUI::~GUI()
{
	while (!_contexts.empty()) {
		contexts::iterator it = _contexts.begin();
		delete it->second;
		_contexts.erase(it);
	}
	while (!_appmodes.empty()) {
		appmodes::iterator it = _appmodes.begin();
		delete it->second;
		_appmodes.erase(it);
	}
	
	delete _opensettingsaction;
	delete _quitaction;
	if (_readerconnimg[0]) g_object_unref(_readerconnimg[0]);
	if (_readerconnimg[1]) g_object_unref(_readerconnimg[1]);
	if (_serverconnimg[0]) g_object_unref(_serverconnimg[0]);
	if (_serverconnimg[1]) g_object_unref(_serverconnimg[1]);
	if (_guierrorpage)	g_object_unref(_guierrorpage);
}

void GUI::kill(int exitcode) {
	if (!is_killed()) {
		Thread::kill(exitcode);
		gdk_threads_enter();	// Preparing to mess with Gtk...
		gtk_main_quit();
		gdk_threads_leave();	// Ending messup with Gtk
	}
}

int GUI::setup() {
	_appdata->log->write("GUI thread: Initializing...");
	// TODO: Check various return values
	GdkThread::enter();

	glade_init();
	// Make the program go away by clicking the X in upper right
	g_signal_connect(G_OBJECT(_appdata->window), "delete_event", G_CALLBACK(main_application_quit), this);	
	
	//Prepare the gui error page
	_guierrorpage = gtk_label_new(MESSAGE::ERROR::GUI_MISSING);
	gtk_widget_show_all(_guierrorpage);
	g_object_ref(_guierrorpage);
	gtk_object_sink(GTK_OBJECT(_guierrorpage));
	
	// ****** Main menu ******
	_menu = GTK_MENU(gtk_menu_new());						// Create the menu
	hildon_window_set_menu(_appdata->window, _menu);		// Add the menu to the main window
	//hildon_program_set_common_menu(_appdata->program, _menu);
	
	// ******* Toolbar ******* 
	_toolbar = GTK_TOOLBAR(gtk_toolbar_new()); 				// Create the toolbar	
	// Create the context selector item
	_contexttoolitem = GTK_TOOL_ITEM(gtk_tool_item_new());
	_contextbox = GTK_COMBO_BOX(gtk_combo_box_new_text());
	g_signal_connect(G_OBJECT(_contextbox), "changed", G_CALLBACK(context_changed), this);
	gtk_container_add(GTK_CONTAINER(_contexttoolitem), GTK_WIDGET(_contextbox));
	gtk_toolbar_insert(_toolbar, _contexttoolitem, 0);
	// Attach the toolbar to the main window
	hildon_window_add_toolbar(_appdata->window, _toolbar);	// Add the toolbar to the main window	
	// Connection status icons
	string iconspath = string(_appdata->iconpath) + "icons/hicolor/40x40/hildon/";
	cout << "Searching icons from: " << iconspath << endl;
	_readerconnimg[0] = gtk_image_new_from_file((iconspath + IO::READER_CONN_OFF_FILE).c_str());
	_readerconnimg[1] = gtk_image_new_from_file((iconspath + IO::READER_CONN_ON_FILE).c_str());
	_serverconnimg[0] = gtk_image_new_from_file((iconspath + IO::SERVER_CONN_OFF_FILE).c_str());
	_serverconnimg[1] = gtk_image_new_from_file((iconspath + IO::SERVER_CONN_ON_FILE).c_str());
	g_object_ref(_readerconnimg[0]);
	g_object_ref(_readerconnimg[1]);
	g_object_ref(_serverconnimg[0]);
	g_object_ref(_serverconnimg[1]);
	_readerstatusicon = gtk_tool_button_new(_readerconnimg[0], "RFID");
	_serverstatusicon = gtk_tool_button_new(_serverconnimg[0], "Server");
	g_signal_connect(G_OBJECT(_readerstatusicon), "clicked", G_CALLBACK(reader_status_requested), this);
	g_signal_connect(G_OBJECT(_serverstatusicon), "clicked", G_CALLBACK(server_status_requested), this);
	gtk_toolbar_insert(_toolbar, _readerstatusicon, 1);
	gtk_toolbar_insert(_toolbar, _serverstatusicon, 2);
	gtk_toolbar_set_icon_size(_toolbar, GTK_ICON_SIZE_LARGE_TOOLBAR);
	
	// ******* Actions *******
	_appdata->log->write("Initializing actions...");
	_opensettingsaction = new OpenSettingsDialogAction(_appdata->evbuf->requestWriter(),
			_appdata->uifilename, "preferences", "Preferences", "Program preferences");
	_opensettingsaction->setTarget(_appsettings);
	_opensettingsaction->addToMenu(_menu);

	_quitaction = new QuitAction(_appdata->evbuf->requestWriter(), "quit", "Quit", "Quit");
	_quitaction->addToMenu(_menu);

	// ******** Modes ********
	_appdata->log->write("Creating management mode...");
	ApplicationMode * managemode = new ManageMode(_appdata, _appsettings, _db, _rootnodes);
	_appmodes[managemode->getModeID()] = managemode;
	_appdata->log->write("Creating ordering mode...");
	ApplicationMode * orderingmode = new OrderingMode(_appdata, _appsettings, _db, _rootnodes);
	_appmodes[orderingmode->getModeID()] = orderingmode;
	
	// ******* Contexts ******
	_appdata->log->write("Loading preinstalled contexts...");
	loadContexts();

	// Select notebook or no data page based on situation
	setFrontpage();

	GdkThread::leave();
	_appdata->log->write("GUI thread: Initialized succesfully.");
	return 0;
}

int GUI::run() {
	_appdata->log->write("GUI thread: Running...");
	gdk_threads_enter();	// Entering the critical section...
	gtk_widget_show_all(GTK_WIDGET(_appdata->window));	
	gtk_main();
	gdk_threads_leave();		// Leaving the critical section
	_appdata->log->write("GUI thread: Stopped.");
	return getExitcode();
}


void GUI::setFrontpage() {
	GdkThread::enter();
	GtkWidget * correctpage = NULL;
	
	ApplicationMode * mode = getAppMode();
	Context * context = getContext();
	
	if (!_dialogs.empty()) {
		correctpage = _dialogs.back()->requestTopWidget();
		if (!correctpage)
			cerr << "Warning: Request for dialog top widget failed!" << endl;
	} else if (context) {
		if (mode)
			correctpage = mode->getFrontWidget();
		else {
			gtk_label_set_text(GTK_LABEL(_guierrorpage), MESSAGE::ERROR::MODE_MISSING);
			correctpage = _guierrorpage;
		} 
	} else {
		gtk_label_set_text(GTK_LABEL(_guierrorpage), MESSAGE::ERROR::CONTEXT_MISSING);
		correctpage = _guierrorpage;
	}

	
	if (_frontpage && correctpage != _frontpage) {
		gtk_container_remove(GTK_CONTAINER(_appdata->window), _frontpage);
		_frontpage = NULL;
	}
	if (!_frontpage && correctpage) {
		_frontpage = correctpage;
		gtk_container_add(GTK_CONTAINER(_appdata->window), _frontpage);
	}
	GdkThread::leave();
}
void GUI::displayDialog(Dialog * dialog) {
	// If there's already a copy of the same dialog in the stack, instead reactivate that dialog
	GdkThread::enter();
	if (!_dialogs.empty()) {
		for (dialogs::iterator it = _dialogs.begin(); it != _dialogs.end(); it++) {
			if (**it == *dialog) {
				dialog = *it;
				it = _dialogs.erase(it);
				break;
			}
		}
	} 
	_dialogs.push_back(dialog);
	setFrontpage();
	GdkThread::leave();
}

void GUI::closeDialog(Dialog * dialog) {
	//cout << "In GUI::closeDialog" << endl;
	GdkThread::enter();
	if (!_dialogs.empty()) {
		for (dialogs::iterator it = _dialogs.begin(); it != _dialogs.end(); it++) {
			if (**it == *dialog) {
				it = _dialogs.erase(it);
				setFrontpage();
				delete *it;
				break;
			}
		}
	} 	
	GdkThread::leave();
	//cout << "Leaving GUI::closeDialog" << endl;
}

Context * GUI::getContext(int id) {
	contexts::iterator it = _contexts.find(id);
	if (it == _contexts.end())
		return NULL;
	else
		return it->second;
}

Context * GUI::getContext() {
	contexts::iterator it = _contexts.find(_activecontext);
	if (it == _contexts.end())
		return NULL;
	else
		return it->second;
}

ApplicationMode * GUI::getAppMode() {
	appmodes::iterator it = _appmodes.find(_activemode);
	if (it == _appmodes.end())
		return NULL;
	else
		return it->second;
}

const Node * GUI::getNode(const string & ID) const {
	return _db.get(ID);
}

// Called when a new set of data has arrived.
// This will try to create new Node objects if necessary
bool GUI::updateDataBase(Node * newnode) {
	if (!newnode)
		return false;
	//cout << "In GUI::updateDataBase" << endl;
	bool result = true;
	GdkThread::enter();
	string nodeid = newnode->getID();
	result = _db.update(newnode);
	if (result) {
		//cout << "GUI::updateDataBase: Update success" << endl;
		checkRemoteImages(nodeid);
		refreshNode(nodeid);
		setFrontpage();
	}// else
		//cout << "GUI::updateDataBase: Update failure" << endl;
	GdkThread::leave();
	//cout << "Leaving GUI::updateDataBase" << endl;
	return result;
}

bool GUI::updateDataBase(const string & nodeid, unsigned int version, char * data, size_t datalen) {
	if (nodeid.length() == 0 || data == NULL || datalen == 0)
		return false;
	bool result;
	GdkThread::enter();
	result = _db.update(nodeid, version, data, datalen);
	if (result) {
		refreshNode(nodeid);
	}
	GdkThread::leave();
	return result;
}

// Called when a new root node has arrived.
// This will try to create new Node objects if necessary
bool GUI::updateDataBaseWithRootNode(Node * newnode) {
	if (!newnode)
		return false;
	//cout << "In GUI::updateDataBaseWithRootNode" << endl;
	bool result = true;
	GdkThread::enter();
	string nodeid = newnode->getID();
	result = _db.update(newnode);
	if (result) {
		//cout << "GUI::updateDataBaseWithRootNode: Update success" << endl;
		checkRemoteImages(nodeid);
		registerRootNode(nodeid);
		refreshNode(nodeid);
		setFrontpage();
	}// else
		//cout << "GUI::updateDataBaseWithRootNode: Update failure" << endl;
	GdkThread::leave();
	//cout << "Leaving GUI::updateDataBaseWithRootNode" << endl;
	return result;
}

bool GUI::removeNode(const string & nodeid) {
	//cout << "Deleting: " << nodeid << endl;
	GdkThread::enter();
	Node * target = _db.detach(nodeid);
	if (target) {
		//cout << "Delete success. Removing from root nodes and refreshing the display. " << endl;
		_rootnodes.remove(nodeid);
		refreshNode(nodeid);
		setFrontpage();
		// It is important that the node is deleted only after refreshing the nodeviews, since the nodeviews contain pointer references to the node
		delete target;
	} //else
		//cout << "Delete failed." << endl;
	GdkThread::leave();
	return target != NULL;
}

void GUI::refreshNode(const string & nodeid) {
	ApplicationMode * mode = getAppMode();
	if (mode) {
		mode->refreshNode(nodeid);
	}
}

void GUI::registerRootNode(const string & nodeid) {
	GdkThread::enter();
	_rootnodes.remove(nodeid);
	_rootnodes.push_back(nodeid);
	GdkThread::leave();
}

void GUI::setServerStatus(bool status) {
	_serverstatus = status;
	if (_serverstatusicon) {
		GtkWidget * oldwidget = gtk_tool_button_get_icon_widget(GTK_TOOL_BUTTON(_serverstatusicon));
		GtkWidget * newwidget = NULL;
		if (status && _serverconnimg[1] && oldwidget != _serverconnimg[1])
			newwidget = _serverconnimg[1];
		else if (!status && _serverconnimg[0] && oldwidget != _serverconnimg[0])
			newwidget = _serverconnimg[0];
		if (newwidget) {
			GdkThread::enter();
			gtk_tool_button_set_icon_widget(GTK_TOOL_BUTTON(_serverstatusicon), newwidget);
			gtk_widget_show_all(GTK_WIDGET(_serverstatusicon));
			GdkThread::leave();
		}	
	}
}

void GUI::setReaderStatus(bool status, const string & statusmsg) {
	_readerstatusmsg = statusmsg;
	if (_readerstatusicon) {
		GtkWidget * oldwidget = gtk_tool_button_get_icon_widget(GTK_TOOL_BUTTON(_readerstatusicon));
		GtkWidget * newwidget = NULL;
		if (status && _readerconnimg[1] && oldwidget != _readerconnimg[1])
			newwidget = _readerconnimg[1];
		else if (!status && _readerconnimg[0] && oldwidget != _readerconnimg[0])
			newwidget = _readerconnimg[0];
		if (newwidget) {
			GdkThread::enter();
			gtk_tool_button_set_icon_widget(GTK_TOOL_BUTTON(_readerstatusicon), newwidget);
			gtk_widget_show_all(GTK_WIDGET(_readerstatusicon));
			GdkThread::leave();
		}	
	}
}

void GUI::checkRemoteImages(const string & nodeid) {
	const Node * node = _db.get(nodeid);
	if (node) {
		if (node->getContentType() == NodeContent::TYPE_IMAGE) {
			const ImageLeaf * imageleaf = static_cast<const ImageLeaf *>(node->getContents());
			if (imageleaf->getImage() == NULL && imageleaf->getRemoteURL().length() > 0)
				_evwriter->push(new RemoteQueryImageEvent(nodeid, imageleaf->getRemoteURL(), imageleaf->getVersion()));
		} else if (node->getContentType() == NodeContent::TYPE_BRANCH) {
			const Branch * branch = static_cast<const Branch *>(node->getContents());
			const Branch::children & children = branch->getChildren();
			for (Branch::children::const_iterator it = children.begin(); it != children.end(); it++) {
				checkRemoteImages(it->first);
			}
		}
	}
}

void GUI::loadContexts() {
	string contextfolder = string(_appdata->datapath) + IO::CONTEXT_FOLDER;
	DIR * dir = opendir(contextfolder.c_str());
	if (dir == NULL) {
		cerr << "GUI::loadContexts: Error (" << errno << ") while opening context directory: " << contextfolder << endl;
		return;
	}
	struct dirent * entry;
	string suffix = IO::CONTEXT_SUFFIX;
	while ((entry = readdir(dir)) != NULL) {
		string file = contextfolder + entry->d_name;
		// Check if the filename ends with the correct context suffix
		//cout << "Found file: " << file << endl;
		if (file.length() >= suffix.length() && !suffix.compare(file.substr(file.length()-suffix.length(), suffix.length()))) {
			//cout << "File has suffix " << suffix << endl;
			ifstream contextfile(file.c_str(), ios::in);
			if (contextfile.is_open()) {
				string content = string(istreambuf_iterator<char>(contextfile), istreambuf_iterator<char>());
				contextfile.close();
				Context * context = Context::parseContextData(content.c_str());
				if (context) {
					if (_contexts.find(context->getID()) != _contexts.end())
						cerr << "Warning! Several contexts with id \"" << context->getID() << "\" found" << endl;
					else {
						_contexts[context->getID()] = context;
						gtk_combo_box_insert_text(_contextbox, context->getID(), context->getLabel().c_str());
						if (!strcmp(entry->d_name, IO::DEFAULT_CONTEXT_FILE))
							gtk_combo_box_set_active(_contextbox, context->getID());
					}
				} else
					cerr << "Warning! Could not parse context file: " << file << endl;
			} else
				cerr << "Could not open file!" << endl;
		}
	}
	closedir(dir);
}

// ***************** CALLBACKS ******************
bool GUI::main_application_quit(GtkButton *widget, GdkEvent * event, gpointer guiptr) {
	GUI * gui = (GUI*)guiptr;
	gui->_evwriter->push(new ApplicationQuitEvent);
	return true;
}

void GUI::context_changed(GtkComboBox * contextbox, gpointer guiptr) {
	GUI * gui = static_cast<GUI*>(guiptr);
	int newcontext = gtk_combo_box_get_active(contextbox);
	//cout << "GUI::context_changed. Old:" << gui->_activecontext << " New:" << newcontext << endl;
	gui->_evwriter->push(new ContextChangeEvent(newcontext));
}

void GUI::reader_status_requested(GtkButton * button, gpointer guiptr) {
	GUI * gui = static_cast<GUI*>(guiptr);
	hildon_banner_show_information(GTK_WIDGET(gui->_appdata->window), NULL, gui->_readerstatusmsg.c_str());
}

void GUI::server_status_requested(GtkButton * button, gpointer guiptr) {
	GUI * gui = static_cast<GUI*>(guiptr);
	if (gui->_serverstatus)
		hildon_banner_show_information(GTK_WIDGET(gui->_appdata->window), NULL, MESSAGE::STATUS::ONLINE);
	else
		hildon_banner_show_information(GTK_WIDGET(gui->_appdata->window), NULL, MESSAGE::STATUS::OFFLINE);
}
