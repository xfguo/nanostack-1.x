#ifndef GLADETAG_H_
#define GLADETAG_H_

namespace GLADE {
	namespace COMMON {
		extern const char * NODATAPAGE;
	}

	namespace ORDERING {
		extern const char * ROOT;
		extern const char * DELETE_BUTTON;
		extern const char * DETAILS_BUTTON;
		extern const char * ORDER_BUTTON;
		extern const char * STATUSBAR;
		extern const char * VIEW;
		extern const char * CLOSE_BUTTON;
	}
	
	namespace MANAGE {
		extern const char * ROOT;
		extern const char * SELECTLIST_VIEW;
		extern const char * MAINLIST_VIEW;
		extern const char * MAINLIST_ROOT;
		extern const char * BRANCHVIEW_TOOLBAR;
		extern const char * BROWSE_BACK_BUTTON;
		extern const char * BROWSE_FORWARD_BUTTON;
		extern const char * BROWSE_PARENT_BUTTON;
	}
	
}

#endif /*GLADETAG_H_*/
