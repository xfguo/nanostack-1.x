#include "NodeView.h"
#include "event/GUIEvent.h"
#include <iostream>

NodeView::~NodeView() {
}

void NodeView::attachNode(const Node * node) {
	if (!node)
		return;
	GdkThread::enter();
	if (_node != node) {
		_node = node;
		redrawObjects();
	}
	GdkThread::leave();
}

void NodeView::removeNode() {
	_node = NULL;
}


void NodeView::node_close(GtkButton *button, gpointer nodeview) {
	NodeView * view = static_cast<NodeView*>(nodeview);
	view->_mode->_writer->push(new RemoveNodeEvent(view->_node->getID()));
}
