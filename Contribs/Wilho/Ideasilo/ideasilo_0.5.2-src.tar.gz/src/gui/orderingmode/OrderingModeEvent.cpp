#include "OrderingModeEvent.h"

bool OrderingModeEvent::processInMode(ApplicationMode * mode) {
	OrderingMode * orderingmode = static_cast<OrderingMode*>(mode);
	return processInOrderingMode(orderingmode);
}

bool ModifyOrderEvent::processInOrderingMode(OrderingMode * mode) {
	switch (_type) {
	case INCREASE_STEP:
		mode->increaseCount(_nodeid);
		break;
	case DECREASE_STEP:
		mode->decreaseCount(_nodeid);
		break;
	default:
		break;
	}
	return true;
}
