#ifndef ORDERINGMODEEVENT_H_
#define ORDERINGMODEEVENT_H_

#include "gui/ApplicationModeEvent.h"
#include "OrderingMode.h"

class OrderingModeEvent: public ApplicationModeEvent {
public:	
	OrderingModeEvent(): ApplicationModeEvent(OrderingMode::MODE_ID) { }
	virtual ~OrderingModeEvent() {}
	
	virtual bool processInOrderingMode(OrderingMode * mode)=0;
	
protected:
	bool processInMode(ApplicationMode * mode);
};

class ModifyOrderEvent : public OrderingModeEvent {
public:
	enum ModifyOrderEventType { UNKNOWN, INCREASE_STEP, DECREASE_STEP };
	ModifyOrderEvent(ModifyOrderEventType type, const string & nodeid):_type(type), _nodeid(nodeid) {}
	virtual ~ModifyOrderEvent() {}
	
	virtual bool processInOrderingMode(OrderingMode * mode);
	
private:
	ModifyOrderEventType 	_type;
	string					_nodeid;
};


#endif /*ORDERINGMODEEVENT_H_*/
