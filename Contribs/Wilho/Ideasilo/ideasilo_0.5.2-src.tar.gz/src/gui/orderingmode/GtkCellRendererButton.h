#ifndef GTKCELLRENDERERBUTTON_H_
#define GTKCELLRENDERERBUTTON_H_

#include <gtk/gtk.h>
//#include <pango/pango.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


// GObject type check and type cast macros
#define GTK_TYPE_CELL_RENDERER_BUTTON             (gtk_cell_renderer_button_get_type())
#define GTK_CELL_RENDERER_BUTTON(obj)             (G_TYPE_CHECK_INSTANCE_CAST((obj),  GTK_TYPE_CELL_RENDERER_BUTTON, GtkCellRendererButton))
#define GTK_CELL_RENDERER_BUTTON_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass),  GTK_TYPE_CELL_RENDERER_BUTTON, GtkCellRendererButtonClass))
#define GTK_IS_CELL_RENDERER_BUTTON(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GTK_TYPE_CELL_RENDERER_BUTTON))
#define GTK_IS_CELL_RENDERER_BUTTON_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass),  GTK_TYPE_CELL_RENDERER_BUTTON))
#define GTK_CELL_RENDERER_BUTTON_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj),  GTK_TYPE_CELL_RENDERER_BUTTON, GtkCellRendererButtonClass))

struct GtkCellRendererButton {
	GtkCellRenderer	parent;			// The parent class must always be the first item in the structure
	
	// Data
};

struct GtkCellRendererButtonClass {
	GtkCellRendererClass	parent_class;

	// From GtkCellRendererText
	void (* edited) (GtkCellRendererButton * gtk_cell_renderer_button,
			const gchar         *path,
			const gchar         *new_text);

	void (* activated) (GtkCellRendererButton *gtk_cell_renderer_button);
	
	/* Padding for future expansion */
	void (*_gtk_reserved1) (void);
	void (*_gtk_reserved2) (void);
	void (*_gtk_reserved3) (void);
	void (*_gtk_reserved4) (void);
};

GType				gtk_cell_renderer_button_get_type();
GtkCellRenderer*	gtk_cell_renderer_button_new();

#ifdef __cplusplus
}
#endif // __cplusplus 


#endif
