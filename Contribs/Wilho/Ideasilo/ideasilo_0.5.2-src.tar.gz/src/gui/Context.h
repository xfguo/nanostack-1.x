#ifndef CONTEXT_H_
#define CONTEXT_H_

#include <string>
#include <map>
#include <libxml/parser.h>
#include <libxml/tree.h>

using namespace std;

class ContextSetting {
public:
	
	typedef map<string,ContextSetting*> settings;
	typedef pair<string,ContextSetting*> setting;
	
	ContextSetting();
	ContextSetting(const ContextSetting & ot);	
	~ContextSetting();
	
	ContextSetting & operator=(const ContextSetting & ot);	
	
	bool					isEmpty() const { return data.length() == 0 && children.empty() == true; }
	string 					getData() const { return data; }
	const setting 			getSettingPair(const string & path) const;
	const ContextSetting * 	getSetting(const string & path) const;
	const settings & 		getChildren() const { return children; }
	
	static ContextSetting* parseContextSetting(const xmlNode * root);
private:
	string data;
	settings children;
};

class Context
{
public:
	typedef map<string,ContextSetting*>  settings;
	
	Context();
	Context(const Context & ot);
	~Context();
	Context & operator=(const Context & ot);
	
	int 			getID() const		{ return _id; }
	int				getModeID() const	{ return _mode; }
	ContextSetting	getSetting(const string & path) const;
	string 			getSettingValue(const string & path) const;
	string		 	getLabel() const	{ return _label; }
	static Context * parseContextData(const string & xmldata);
	static Context * parseContextData(const xmlNode * root);

	
	
protected:
	mutable pthread_mutex_t _lock;
	int 		_id;
	int 		_mode;
	string 		_label;
	string 		_shortlabel;
	ContextSetting * _settings;
	
	
};

#endif /*CONTEXT_H_*/
