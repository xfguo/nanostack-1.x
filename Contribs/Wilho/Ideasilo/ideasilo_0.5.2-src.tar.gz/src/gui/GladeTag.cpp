#include "GladeTag.h"

namespace GLADE {
	namespace COMMON {
		const char * NODATAPAGE = 		"[main]nodatapage";
	}

	namespace ORDERING {
		const char * ROOT = 			"[ordering]root";
		const char * DELETE_BUTTON = 	"[ordering]delete_button";
		const char * DETAILS_BUTTON = 	"[ordering]details_button";
		const char * ORDER_BUTTON = 	"[ordering]order_button";
		const char * STATUSBAR = 		"[ordering]statusbar";
		const char * VIEW = 			"[ordering]view";
		const char * CLOSE_BUTTON =		"[ordering]delete_button";
	}
	
	namespace MANAGE {
		const char * ROOT = 				"[manage]root";
		const char * SELECTLIST_VIEW = 		"[manage]select_treeview";
		const char * MAINLIST_VIEW = 		"[manage]view_treeview";
		const char * MAINLIST_ROOT = 		"[manage]view_scrolledwindow";
		const char * BRANCHVIEW_TOOLBAR = 	"[manage]branchview_toolbar";
		const char * BROWSE_BACK_BUTTON = 	"[manage]back_button";
		const char * BROWSE_FORWARD_BUTTON = "[manage]forward_button";
		const char * BROWSE_PARENT_BUTTON = "[manage]parent_button";
	}
	
}
