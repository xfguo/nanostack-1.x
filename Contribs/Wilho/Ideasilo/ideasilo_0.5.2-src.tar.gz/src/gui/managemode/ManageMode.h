#ifndef MANAGEMODE_H_
#define MANAGEMODE_H_

#include <set>
#include <list>
#include "gui/ApplicationMode.h"
#include "ManageNodeView.h"
#include "gui/action/Action.h"
#include "CellRendererMulti.h"

using namespace std;

class ManageMode: public ApplicationMode
{
public:
	typedef set<ManageNodeView*> 		nodeviews;
	typedef list<string>				branchhistory;
	
	static const int MODE_ID = 1;
	
	ManageMode(AppData * appdata, SettingHandler * appsettings, const DataBase & db, const rootnodes & rnodes);
	virtual ~ManageMode();
	
	
	virtual int 	getModeID()			{ return MODE_ID; }
	virtual void 	activate();
	virtual void 	release();
	
	virtual void	setToolbar(GtkToolbar * toolbar);
	virtual void	resetToolbar();
	virtual void	refreshNode(const string & nodeid);
	virtual string	getSelection();
	string 			getRootSelection();
	//virtual void	changeFocus(const string & nodeid);
	virtual void	activateNodeView(const string & ID);
	
	void			browseBack();
	void			browseForward();
	void			browseParent();
	
protected:
	virtual void		setFrontpage();
	ManageNodeView *	getNodeView(const string & nodeid);
	
	void 				refreshRootlistView(const Node * node);
	void				removeFromRootlistView(const string & nodeid);
	void				removeReferencesToNode(const string & nodeid);
	
	
	GladeXML *			_managerootxml;
	GtkWidget * 		_manageroot;
	GtkTreeView *		_rootlistview;
	GtkListStore * 		_rootlist;
	GtkTreeView *		_branchview;
	
	GtkWidget * 		_nodatapage;			// The Standby screen
	
	nodeviews 			_nodeviews;				// Currently opened views that display pages
	branchhistory		_branchhistory;
	branchhistory::iterator _currentbranch;
	
	Action * 			_openeditaction;
	Action * 			_removedatapageaction;
private:
	
	static void 		page_selection_changed(GtkTreeSelection *selection, gpointer mode);
	static bool			rootlistview_selected(GtkWidget * widget, GdkEventCrossing * event, gpointer mode);
	static void			node_activated(CellRendererMulti * multi, gpointer mode);
	static void			back_button_clicked(GtkWidget * widget, ManageMode * mode);
	static void			forward_button_clicked(GtkWidget * widget, ManageMode * mode);
	static void			parent_button_clicked(GtkWidget * widget, ManageMode * mode);

};


#endif /*MANAGEMODE_H_*/
