#ifndef CELLRENDERERMULTI_H_
#define CELLRENDERERMULTI_H_

#include <gtk/gtk.h>
#include <pango/pango.h>
#include <dataformat/Node.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


// GObject type check and type cast macros
#define TYPE_CELL_RENDERER_MULTI             (cell_renderer_multi_get_type())
#define CELL_RENDERER_MULTI(obj)             (G_TYPE_CHECK_INSTANCE_CAST((obj),  TYPE_CELL_RENDERER_MULTI, CellRendererMulti))
#define CELL_RENDERER_MULTI_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass),  TYPE_CELL_RENDERER_MULTI, CellRendererMultiClass))
#define IS_CELL_RENDERER_MULTI(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), TYPE_CELL_RENDERER_MULTI))
#define IS_CELL_RENDERER_MULTI_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass),  TYPE_CELL_RENDERER_MULTI))
#define CELL_RENDERER_MULTI_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj),  TYPE_CELL_RENDERER_MULTI, CellRendererMultiClass))

struct CellRendererMulti {
	GtkCellRenderer	parent;			// The parent class must always be the first item in the structure
	
	// Data
	// TODO: In case of additional properties, add them here here
	Node * 			node;		// Just a reference, but cannot make it const

	// From GtkCellRendererText
	gchar *text;
	PangoFontDescription *font;
	gdouble font_scale;
	PangoColor foreground;
	PangoColor background;

	PangoAttrList *extra_attrs;

	PangoUnderline underline_style;

	gint rise;
	gint fixed_height_rows;

	guint strikethrough : 1;

	guint editable  : 1;

	guint scale_set : 1;

	guint foreground_set : 1;
	guint background_set : 1;

	guint underline_set : 1;

	guint rise_set : 1;

	guint strikethrough_set : 1;

	guint editable_set : 1;
	guint calc_fixed_height : 1;
};

struct CellRendererMultiClass {
	GtkCellRendererClass	parent_class;

	// From GtkCellRendererText
	void (* edited) (CellRendererMulti *cell_renderer_text,
			const gchar         *path,
			const gchar         *new_text);

	void (* activated) (CellRendererMulti *cell_renderer_text);
	
	/* Padding for future expansion */
	void (*_gtk_reserved1) (void);
	void (*_gtk_reserved2) (void);
	void (*_gtk_reserved3) (void);
	void (*_gtk_reserved4) (void);
};

GType				cell_renderer_multi_get_type();
GtkCellRenderer*	cell_renderer_multi_new();
void				cell_renderer_multi_set_fixed_height_from_font (CellRendererMulti *renderer,gint number_of_rows);

#ifdef __cplusplus
}
#endif // __cplusplus 


#endif
