#ifndef GUI_H_
#define GUI_H_

#include "main.h"
#include <gtk/gtk.h> 
#include <glade/glade.h>
#include <string>
#include <map>
#include <list>
#include <vector>
#include "ApplicationMode.h"
#include "util/widgethandler.h"
#include "util/Thread.h"
#include "action/Action.h"
#include "event/EventBuffer.h"
#include "dialog/Dialog.h"
#include "Context.h"
#include "dataformat/DataBase.h"
 

using namespace std;

class GUI:public Thread {
public:
	friend class ContextChangeEvent;
	friend class ContextDataEvent;
	
	typedef vector<Dialog*> 				dialogs;
	typedef map<int,Context*>				contexts;
	typedef map<int,ApplicationMode*>		appmodes;
	typedef list<string>					rootnodes;
	
	GUI(AppData * appdata, SettingHandler * appsettings);
	virtual ~GUI();

	void 		setUIFilepath(string path);
	void 		kill(int exitcode = 0);
	void 		displayDialog(Dialog * dialog);
	void		closeDialog(Dialog * dialog);
	
	
	Context *			getContext();
	Context *			getContext(int id);
	ApplicationMode * 	getAppMode();
	DataBase &			getDataBase()			{ return _db; }
	
	const Node * getNode(const string & nodeid) const;
	bool 		removeNode(const string & nodeid);
	bool 		updateDataBase(Node * newnode);
	bool		updateDataBase(const string & nodeid, unsigned int version, char * data, size_t datalen);
	bool		updateDataBaseWithRootNode(Node * rootnode);
	void		registerRootNode(const string & nodeid);
	void		refreshNode(const string & nodeid);
	
	void 		setServerStatus(bool status);
	void 		setReaderStatus(bool status, const string & statusmsg);
	
protected:
	virtual int setup();
	virtual int run();
	
private:
	GUI(const GUI &);				// No definition
	GUI & operator=(const GUI &);	// No definition
	void 		setFrontpage();
	//bool 		addNode(Node * newnode);
	//long		getNewReadID()	{ return _nextreadid++; }
	void		checkRemoteImages(const string & nodeid);
	void		loadContexts();
	
	//Callbacks
	static bool main_application_quit(GtkButton *widget, GdkEvent * event, gpointer guiptr);
	static void context_changed(GtkComboBox * widget, gpointer guiptr);
	static void reader_status_requested(GtkButton * button, gpointer guiptr);
	static void server_status_requested(GtkButton * button, gpointer guiptr);
		
	EventBuffer::Writer * _evwriter;
	
	AppData * 			_appdata;				// Struct containing system data
	SettingHandler * 	_appsettings;			// Link to application settings
	GtkToolbar *		_toolbar;				// The Toolbar
	GtkMenu * 			_menu;					// The Menu
	GtkToolItem * 		_contexttoolitem;
	GtkComboBox *		_contextbox;
	GtkWidget *			_frontpage;				// Current page in front: A dialog or the main page from the active mode
	GtkWidget * 		_guierrorpage;
	GtkWidget *			_readerconnimg[2];
	GtkWidget *			_serverconnimg[2];
	string				_readerstatusmsg;
	GtkToolItem *	 	_readerstatusicon;
	GtkToolItem *		_serverstatusicon;
	bool				_serverstatus;
	
	//DEBUG
	Action * 			_opensettingsaction;	
	Action * 			_quitaction;
	
	DataBase			_db;
	rootnodes			_rootnodes;
	dialogs 			_dialogs;				// Currently opened dialogs
	contexts			_contexts;

	appmodes			_appmodes;
	int 				_activecontext;
	int					_activemode;
	//long				_nextreadid;
	
};

#endif /*GUI_H_*/
