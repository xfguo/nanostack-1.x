#include "GUIAction.h"
#include "event/GUIEvent.h"
#include "gui/ApplicationMode.h"
#include <iostream>

using namespace std;

void RemoveNodeAction::activate(void * target) {
	if (!target)
		return;
	ApplicationMode * mode = static_cast<ApplicationMode*>(target);
	string selection = mode->getSelection();
	//cout << "RemoveDataPageAction - node: " << selection << endl;
	_evwriter->push(new RemoveNodeEvent(selection));
}
