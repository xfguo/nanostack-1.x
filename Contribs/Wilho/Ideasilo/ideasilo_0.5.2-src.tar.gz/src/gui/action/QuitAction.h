#ifndef QUITACTION_H_
#define QUITACTION_H_
#include "gui/action/Action.h"
#include "event/ApplicationEvent.h"

class QuitAction : public Action
{
public:
	QuitAction(EventBuffer::Writer * writer, const string & name, 
			const string & label, const string & tooltip):
				Action(writer, name, label, tooltip, "gtk-quit") {}
	~QuitAction() {}
	
	virtual void activate(void * target) {
		_evwriter->push(new ApplicationQuitEvent);
	}
	
};

#endif /*QUITACTION_H_*/
