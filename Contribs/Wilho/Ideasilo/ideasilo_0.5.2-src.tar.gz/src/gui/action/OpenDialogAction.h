#ifndef OPENDIALOGACTION_H_
#define OPENDIALOGACTION_H_

#include "gui/action/Action.h"
#include "gui/dialog/Dialog.h"

class OpenDialogAction: public Action {
public:
	OpenDialogAction(EventBuffer::Writer * writer,  const string & UIFilename,
			const string & name, const string & label, 
			const string & tooltip, const string & stock_id):
		Action(writer, name, label, tooltip, stock_id),
		_uifilename(UIFilename) {}
	virtual ~OpenDialogAction() {}
	
	virtual Dialog * 	createDialog(void * target)	= 0;
	virtual void		activate(void * target); 
	
protected:
	string _uifilename;
};



#endif /*OPENDIALOGACTION_H_*/
