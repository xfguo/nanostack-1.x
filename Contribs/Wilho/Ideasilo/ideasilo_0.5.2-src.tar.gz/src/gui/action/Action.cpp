#include "Action.h"
#include <iostream>

//Action::Action(EventBuffer::Writer * writer):
//_action(NULL),
//_evwriter(writer)
//{
//	for (int n=0; n<WIDGETCOUNT; ++n)
//		_widgets[n] = NULL;
//}

Action::Action(EventBuffer::Writer * writer, 
		const string & name, const string & label, 
		const string & tooltip, const string & stock_id):
_evwriter(writer),
_name(name),
_label(label),
_stockid(stock_id),
_tooltip(tooltip),
_target(NULL)
{
	for (int n=0; n<WIDGETCOUNT; ++n)
		_widgets[n] = NULL;	
	_action = gtk_action_new(_name.c_str(), _label.c_str(), _tooltip.c_str(), _stockid.c_str());
	g_signal_connect(G_OBJECT(_action), "activate", G_CALLBACK(activateEntryPoint), this);
}


Action::~Action()
{
	//cout << "In Action::~Action" << endl;
	for (int n=0; n<WIDGETCOUNT; ++n)
		if (_widgets[n])
			g_object_unref(_widgets[n]);
	//cout << "Leaving Action::~Action" << endl;
}

GtkWidget * Action::getMenuWidget() {
	_widgets[0] = createWidget(0);
	return _widgets[0];
}

GtkWidget * Action::getToolWidget() {
	_widgets[1] = createWidget(1);
	return _widgets[1];
}

void Action::addToMenu(GtkMenu * menu) {
	GdkThread::enter();
	gtk_menu_append(menu, GTK_WIDGET(getMenuWidget()));
	GdkThread::leave();
}

void Action::addToToolbar(GtkToolbar * toolbar, int pos) {
	GdkThread::enter();
	gtk_toolbar_insert(toolbar, GTK_TOOL_ITEM(getToolWidget()), pos);	
	GdkThread::leave();
}

void Action::removeFromToolbar(GtkToolbar * toolbar) {
	GdkThread::enter();
	gtk_container_remove(GTK_CONTAINER(toolbar), getToolWidget());
	GdkThread::leave();
}


GtkWidget * Action::createWidget(int n) {
	if (!_action)
		return NULL;
	if (_widgets[n])
		return _widgets[n];
	if (n < 0 || n >= WIDGETCOUNT)
		return NULL;
	GtkWidget * newWidget = NULL;
	if (n == 0) newWidget = gtk_action_create_menu_item(_action);
	if (n == 1) newWidget = gtk_action_create_tool_item(_action);
	g_object_ref(newWidget);
	gtk_object_sink(GTK_OBJECT(newWidget));	// Make sure the widget isn't destroyed prematurely
	return newWidget;
}

// Static
void Action::activateEntryPoint(GtkWidget * widget, void * object) {
	Action * action = static_cast<Action*>(object);
	action->activate(action->_target);
}

