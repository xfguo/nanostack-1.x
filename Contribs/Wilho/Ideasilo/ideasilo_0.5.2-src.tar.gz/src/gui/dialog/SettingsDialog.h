#ifndef SETTINGSDIALOG_H_
#define SETTINGSDIALOG_H_
#include "gui/action/OpenDialogAction.h"
#include "gui/dialog/Dialog.h"
#include "util/SettingHandler.h"
#include <iostream> //DEBUG

using namespace std;

class SettingsDialog : public Dialog
{
public:
	SettingsDialog(EventBuffer::Writer * writer, const string & UIFilename,
			SettingHandler * settings);
	virtual ~SettingsDialog();
	
protected:
	virtual bool 			initTopWidget();
	virtual GtkWidget * 	getTopWidget();
	
private:
	SettingHandler * 	_settings;
	static void cancelButtonPress(GtkWidget * widget, gpointer data);
	static void okButtonPress(GtkWidget * widget, SettingsDialog * dialog);
};

class OpenSettingsDialogAction: public OpenDialogAction {
public:
	OpenSettingsDialogAction(EventBuffer::Writer * writer,  const string & UIFilename,
			const string & name, const string & label, 
			const string & tooltip):
		OpenDialogAction(writer,UIFilename, name, label, tooltip, "gtk-preferences") {}
	
	Dialog * createDialog(void * target) {
		if (!target)
			return NULL;
		SettingHandler * handler = static_cast<SettingHandler*>(target);
		
		return new SettingsDialog(_evwriter, _uifilename, handler);
	}
	
};



#endif /*SETTINGSDIALOG_H_*/
