#include "Dialog.h"
#include "gui/Context.h"
#include "gui/GUI.h"
#include "event/GUIEvent.h"


#include <iostream>
using namespace std;

Dialog::Dialog(EventBuffer::Writer * writer, const string & UIFilename):
_evwriter(writer),
_context(NULL)
{
	setUIFilename(UIFilename);
}

Dialog::~Dialog() {
	delete _context;
}

GtkWidget * Dialog::requestTopWidget() {
	GtkWidget * topwidget = getTopWidget();
	if (topwidget)
		return topwidget;
	else {
		if (initTopWidget()) {
			return getTopWidget();
		} else
			return NULL;
	}
}

void Dialog::setContext(const Context * context) { 
	_context = new Context(*context);
}


void Dialog::closeButtonPress(GtkWidget * widget, gpointer data) {
	//cout << "Dialog::closeButtonPress" << endl;
	Dialog * dialog = static_cast<Dialog*>(data);
	dialog->_evwriter->push(new CloseDialogEvent(dialog));
}

