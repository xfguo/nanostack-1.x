#ifndef DIALOG_H_
#define DIALOG_H_


#include <string>
#include "event/EventBuffer.h"
#include "util/GObjectHandler.h"

using namespace std;

class Context;
class Dialog: public GObjectHandler
{
public:
	friend class OpenDialogEvent;
	friend class CloseDialogEvent;
	
	Dialog(EventBuffer::Writer * writer, const string & UIFilename);
	virtual ~Dialog();
	
	GtkWidget * requestTopWidget();
	
	void setID(string id)				{ _ID = id; }
	bool operator==(const Dialog & op)	{ if (_ID.compare(op._ID)) return false; else return true; }
	
protected:
	virtual bool 			initTopWidget() = 0;
	virtual GtkWidget * 	getTopWidget() = 0;
	
	EventBuffer::Writer * 	_evwriter;
	Context * 				_context;
	string 					_ID;

	// Default callbacks
	static void closeButtonPress(GtkWidget * widget, gpointer data);	
	
private:
	void 		setContext(const Context * context);
};



#endif /*DIALOG_H_*/
