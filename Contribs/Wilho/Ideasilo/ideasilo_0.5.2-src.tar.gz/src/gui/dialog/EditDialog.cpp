#include "EditDialog.h"
#include "gui/ApplicationMode.h"
#include "dataformat/Node.h"
#include "dataformat/TextLeaf.h"
#include "dataformat/ImageLeaf.h"
#include "dataformat/Branch.h"
#include "network/NetworkEvent.h"
#include "event/GUIEvent.h"

#include <iostream>
#include <sstream>

using namespace std;

enum EditDialogWidget { EDIT_TOP, EDIT_TEXT_VIEW, EDIT_BRANCH_VIEW, EDIT_IMAGE_VIEW };

namespace GLADE {
	namespace EDIT {
		const char * TOP = "[edit]top";
		const char * TABLE = "[edit]entrydata_table";
		const char * CLOSEBUTTON = "[edit]closebutton";
		const char * CANCELBUTTON = "[edit]cancelbutton";
		const char * UPDATEBUTTON = "[edit]updatebutton";
		const char * NODEID = "[edit]nodeid";
		const char * LABEL = "[edit]label";
		const char * VERSION = "[edit]version";
		const char * DATA_FRAME = "[edit]data_frame";
		const char * DATA_TYPE_LABEL = "[edit]data_type_label";
	}
	
//	const char * DATA = "[edit]data";
}

Dialog * OpenEditDialogAction::createDialog(void * target) {
	if (!target)
		return NULL;
	ApplicationMode * mode = static_cast<ApplicationMode*>(target);
	string targetid = mode->getSelection();
	//cout << "OpenEditDialogAction::createDialog: " << targetid << endl;
	if (targetid.length() == 0)
		return NULL;
	Node * node = mode->getNodeCopy(targetid,1);
	if (!node) {
		//cout << "OpenEditDialogAction::createDialog: Could not find the node to edit" << endl;
		return NULL;
	}
	return new EditDialog(_evwriter, _uifilename, node);
}

EditDialog::EditDialog(EventBuffer::Writer * writer, const string & UIFilename, 
		Node * node):
Dialog(writer, UIFilename),
_customdata(NULL),
_customdata_label(NULL)
{
	_node = node;
	_ID = "edit_dialog";
}

EditDialog::~EditDialog() {
	//cout << "In EditDialog::~EditDialog" << endl;
	releaseObjects();
	releaseXMLs();
	delete _node;
	if (_customdata)
		delete [] _customdata;
	if (_customdata_label)
		delete [] _customdata_label;
	//cout << "Leaving EditDialog::~EditDialog" << endl;
}

bool EditDialog::initTopWidget() {
	GdkThread::enter();
	if (!hasXML(EDIT_TOP)) {
		GladeXML * xml = glade_xml_new(_uifilename.c_str(), GLADE::EDIT::TOP, NULL);
		registerXML(EDIT_TOP, xml);
	}
	if (!hasObject(EDIT_TOP) && hasXML(EDIT_TOP)) {
		registerObject(EDIT_TOP, GLADE::EDIT::TOP);
	}
	if (hasXML(EDIT_TOP) && hasObject(EDIT_TOP)) {
		GladeXML * xml = getXML(EDIT_TOP);
		GtkWidget * widget;
		widget = glade_xml_get_widget(xml, GLADE::EDIT::CLOSEBUTTON);
		g_signal_connect(widget, "clicked", G_CALLBACK(closeButtonPress), this);
		widget = glade_xml_get_widget(xml, GLADE::EDIT::CANCELBUTTON);
		g_signal_connect(widget, "clicked", G_CALLBACK(closeButtonPress), this);
		widget = glade_xml_get_widget(xml, GLADE::EDIT::UPDATEBUTTON);
		g_signal_connect(widget, "clicked", G_CALLBACK(updateButtonPress), this);
		if (_node) {
			NodeContent * contents = _node->getContents();
			GtkEntry * nodeidentry = GTK_ENTRY(glade_xml_get_widget(xml, GLADE::EDIT::NODEID));
			gtk_entry_set_text(nodeidentry, _node->getID().c_str());
			if (contents) {
				GtkEntry * labelentry = GTK_ENTRY(glade_xml_get_widget(xml, GLADE::EDIT::LABEL));
				gtk_entry_set_text(labelentry, contents->getLabel().c_str());
				GtkEntry * versionentry = GTK_ENTRY(glade_xml_get_widget(xml, GLADE::EDIT::VERSION));
				stringstream str;
				str << contents->getVersion();
				gtk_entry_set_text(versionentry, str.str().c_str());						
				// Prepare the actual data view frame
				GtkFrame * dataframe = GTK_FRAME(glade_xml_get_widget(xml, GLADE::EDIT::DATA_FRAME));
				GtkLabel * typelabel = GTK_LABEL(glade_xml_get_widget(xml, GLADE::EDIT::DATA_TYPE_LABEL));
				NodeContent::ContentType contenttype = contents->getType();
				if (contenttype == NodeContent::TYPE_TEXT ||
						contenttype == NodeContent::TYPE_URI) {
					if (contenttype == NodeContent::TYPE_TEXT)
						gtk_label_set_text(typelabel, "Text");
					else
						gtk_label_set_text(typelabel, "Remote link");
					TextLeaf * leaf = static_cast<TextLeaf*>(contents);
					const string & leafdata = leaf->getData();
					
					GtkWidget * textview = gtk_text_view_new();
					registerObject(EDIT_TEXT_VIEW, textview);
					WidgetUtil::setTextViewData(GTK_TEXT_VIEW(textview), leafdata.c_str());
//					GtkTextBuffer * databuf = gtk_text_view_get_buffer(GTK_TEXT_VIEW(textview));
//					gtk_text_buffer_set_text(databuf, leafdata.c_str(), leafdata.length());
					gtk_container_add(GTK_CONTAINER(dataframe), textview);
				} else if (contenttype == NodeContent::TYPE_IMAGE) {
					ImageLeaf * leaf = static_cast<ImageLeaf*>(contents);
					stringstream typetext;
					if (leaf->getRemoteURL().length() > 0 || leaf->getImage() == NULL) {
						typetext << "Remote image";
						GtkWidget * entry = gtk_entry_new();
						gtk_entry_set_text(GTK_ENTRY(entry), leaf->getRemoteURL().c_str());
						GtkWidget * label = gtk_label_new("URL:");
						gtk_misc_set_alignment(GTK_MISC(label), 1.0f, 0.5f);
						GtkTable * table = GTK_TABLE(glade_xml_get_widget(xml, GLADE::EDIT::TABLE));
						gtk_table_attach(table, label, 0, 1, 2, 3, (GtkAttachOptions)GTK_FILL, (GtkAttachOptions)GTK_FILL, 0, 0);
						gtk_table_attach(table, entry, 1, 2, 2, 3, (GtkAttachOptions)(GTK_EXPAND | GTK_FILL), (GtkAttachOptions)0, 0, 0);
						//gtk_widget_show_all(GTK_WIDGET(label));
						//gtk_widget_show_all(GTK_WIDGET(entry));
						_customdata_count = 1;
						_customdata = new GtkWidget*[_customdata_count];
						_customdata_label = new GtkWidget*[_customdata_count];
						_customdata[0] = entry;
						_customdata_label[0] = label;
					} else
						typetext << "Image";
					if (leaf->getFormat().length() > 0)
						typetext << " (" << leaf->getFormat() << ")";
					gtk_label_set_text(typelabel, typetext.str().c_str());
					if (leaf->getImage()) {
						GtkWidget * image = gtk_image_new_from_pixbuf(leaf->getImage());
						registerObject(EDIT_IMAGE_VIEW, image);
						gtk_container_add(GTK_CONTAINER(dataframe), image);
					}
				} else if (contenttype == NodeContent::TYPE_BRANCH) {
					gtk_label_set_text(typelabel, "Children");
					Branch * branch = static_cast<Branch*>(contents);
					GtkListStore * model = gtk_list_store_new(N_COLUMNS, G_TYPE_STRING, G_TYPE_STRING);	
					GtkTreeIter treeit;
					for (Branch::children::const_iterator childit = branch->getChildren().begin(); childit != branch->getChildren().end(); childit++) {
						string childnodeid = childit->first;
						string childnodelabel = "";
						if (childit->second && childit->second->getContentType() != NodeContent::TYPE_EMPTY)
							childnodelabel = childit->second->getContents()->getLabel();
						gtk_list_store_append(model, &treeit);
						gtk_list_store_set(model, &treeit,
											NODE_ID_COLUMN, childnodeid.c_str(),
											LABEL_COLUMN, childnodelabel.c_str(),
						                    -1);
					}
					GtkWidget * scrolledwindow = gtk_scrolled_window_new(NULL, NULL);
					gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolledwindow), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
					GtkWidget * treeview = gtk_tree_view_new_with_model(GTK_TREE_MODEL(model));
					GtkTreeSelection * select = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
					gtk_tree_selection_set_mode(select, GTK_SELECTION_NONE);

					gtk_container_add(GTK_CONTAINER(scrolledwindow), treeview);
					GtkCellRenderer * renderer;
					GtkTreeViewColumn * column;
					renderer = gtk_cell_renderer_text_new();
					g_object_set(renderer, "foreground", "red", "size-points", 8.0, NULL);
					column = gtk_tree_view_column_new_with_attributes ("Node ID",
					                                                   renderer,
					                                                   "text", NODE_ID_COLUMN,
					                                                   NULL);
					gtk_tree_view_append_column (GTK_TREE_VIEW(treeview), column);
					renderer = gtk_cell_renderer_text_new();
					column = gtk_tree_view_column_new_with_attributes ("Label",
					                                                   renderer,
					                                                   "text", LABEL_COLUMN,
					                                                   NULL);
					gtk_tree_view_append_column (GTK_TREE_VIEW(treeview), column);
					gtk_container_add(GTK_CONTAINER(dataframe), scrolledwindow);
					_customdata_count = 1;
					_customdata = new GtkWidget*[_customdata_count];
					_customdata[0] = treeview;
				} else if (contenttype == NodeContent::TYPE_BINARY) {
					gtk_label_set_text(typelabel, "Binary data");
					gtk_widget_set_sensitive(GTK_WIDGET(dataframe), false);
				}
				gtk_widget_show_all(GTK_WIDGET(dataframe));
			}
		}
	}

	GdkThread::leave();
	return true;
}

GtkWidget * 	EditDialog::getTopWidget() {
	return getWidget(EDIT_TOP);
}

string EditDialog::extractEntryContents(int xmlid, const char * entrytag) {
	GladeXML * xml = getXML(xmlid);
	if (xml) {
		GtkEntry * entry = GTK_ENTRY(glade_xml_get_widget(xml, entrytag));
		if (entry)
			return gtk_entry_get_text(entry);
	}
	return "";
}

//
//string EditDialog::extractEntryLabel() {
//	GtkEntry * entryname = GTK_ENTRY(glade_xml_get_widget(_topwidgetxml, EDIT::ENTRYNAME));
//	return gtk_entry_get_text(entryname);
//}
//string EditDialog::extractEntryData() {
//	GtkTextView * data = GTK_TEXT_VIEW(glade_xml_get_widget(_topwidgetxml, EDIT::DATA));
//	GtkTextBuffer * databuf = gtk_text_view_get_buffer(data);
//	GtkTextIter begin;
//	GtkTextIter end;
//	gtk_text_buffer_get_start_iter(databuf, &begin);
//	gtk_text_buffer_get_end_iter(databuf, &end);
//	return gtk_text_buffer_get_text(databuf, &begin, &end, false);
//}

void EditDialog::updateButtonPress(GtkWidget * widget, gpointer data) {
	EditDialog * dialog = static_cast<EditDialog*>(data);
	if (dialog) {
		string newlabel = dialog->extractEntryContents(EDIT_TOP, GLADE::EDIT::LABEL);
		string newid = dialog->extractEntryContents(EDIT_TOP, GLADE::EDIT::NODEID);
		string newversion = dialog->extractEntryContents(EDIT_TOP, GLADE::EDIT::VERSION);
		Node * newnode = new Node(newid);
		NodeContent * content = dialog->_node->detachContent();
		if (content) {
			content->setLabel(newlabel);
			unsigned int newversionnum = atoi(newversion.c_str()) + 1;
			content->setVersion(newversionnum);
			if (content->getType() == NodeContent::TYPE_TEXT ||
					content->getType() == NodeContent::TYPE_URI) {
				TextLeaf * leaf = static_cast<TextLeaf*>(content);
				GtkWidget * textview = dialog->getWidget(EDIT_TEXT_VIEW);
				if (textview)
					leaf->setData(WidgetUtil::getTextViewData(GTK_TEXT_VIEW(textview)));
			} else if (content->getType() == NodeContent::TYPE_IMAGE) {
				ImageLeaf * leaf = static_cast<ImageLeaf*>(content);
				if (dialog->_customdata && dialog->_customdata[0])
					leaf->setRemoteURL(gtk_entry_get_text(GTK_ENTRY(dialog->_customdata[0])));
			}
			newnode->attachContent(content);
		}
		dialog->_evwriter->push(new ServerUpdateNodeEvent(newnode));
		dialog->_evwriter->push(new CloseDialogEvent(dialog));
		
	}
}

