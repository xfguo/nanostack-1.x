#ifndef DATAENTRYVIEW_H_
#define DATAENTRYVIEW_H_

#include <glade/glade.h>
#include <gtk/gtk.h>
#include "dataformat/DataSet.h"
#include "event/EventBuffer.h"

namespace DataEntryTag {
	extern const char * BUTTONROOT;
	extern const char * LABELROOT;
	//extern const char * LABELBUTTON;
	extern const char * DATA;	
}

struct DataEntryWidgets {
	GtkWidget * buttonroot;
	GtkWidget * labelroot;
	GtkWidget * dataroot;
};

class ManagePageView;
class DataEntryView
{
public:
	DataEntryView(const char * uifilename, EventBuffer::Writer * writer, ManagePageView * pageview);
	~DataEntryView();
	
	DataEntry * getEntry()		{ return _entry; }
	DataSet * getSet()			{ return _set; }
	
	DataEntryWidgets getWidgets();
	DataEntryWidgets createEntryWidgets();
	void displayEntry(DataEntry * entry, DataSet * set, bool showbutton);
	void redrawWidgets();
	
	void setHilight(bool hilight=true); 
	
private:
	// Callbacks
	static void entry_source_change(GtkWidget * widget, gpointer entryview);
	static void entry_label_clicked(GtkWidget * widget, gpointer entryview);
	static bool pointer_crossing_event(GtkWidget * widget, GdkEventCrossing * event, gpointer entryview);
		
	EventBuffer::Writer	* _writer;	// Reference
	const char * _uifilename;		// Reference
	ManagePageView * _pageview;		// Reference
	DataSet *	_set;				// Reference
	DataEntry * _entry;				// Reference
	
	GladeXML * 	_buttonxml;			// Owned
	GladeXML * 	_labelxml;			// Owned
	GladeXML * 	_dataxml;			// Owned
	GtkWidget * _buttonroot;		// Owned
	GtkWidget * _labelroot;			// Owned
	GtkWidget * _dataroot;			// Owned
	
	bool		_showbutton;
};

#endif /*DATAENTRYVIEW_H_*/
