#include "Request.h"

Request::Request(RequestType rqtype):
	content_sent(0), 
	type(rqtype)
{
}

Request::Request(RequestType rqtype, const string & nodeid):
	nodeid(nodeid),
	type(rqtype)
{
}

Request::~Request() {
	
}
