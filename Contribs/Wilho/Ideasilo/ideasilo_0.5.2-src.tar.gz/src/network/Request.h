#ifndef REQUEST_H_
#define REQUEST_H_

#include <string>

using namespace std;

class Request {
public:
	
	enum RequestType { TYPE_IDEASILO_SERVER_REQUEST, TYPE_REMOTE_QUERY_IMAGE };
	
	Request(RequestType rqtype);
	Request(RequestType rqtype, const string & nodeid);
	~Request();
	string req_params;
	string remote;
	string nodeid;
	int		client_version;
	int		reply_version;
	string content;
	size_t content_sent;
	RequestType type;
};

#endif /*REQUEST_H_*/
