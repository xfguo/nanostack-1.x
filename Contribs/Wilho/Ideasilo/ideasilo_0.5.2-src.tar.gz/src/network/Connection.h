#ifndef CONNECTION_H_
#define CONNECTION_H_

#include <string>
#include <sstream>
#include <map>
#include <curl/curl.h>	// For implementing HTTP connection
#include "Request.h"

using namespace std;

class Connection {
public:
	//friend class NetworkController;
	
	typedef map<string, string>		headers;
	
	Connection();
	~Connection();
	
	CURL * 	getHandle()					{ return _handle; }
	const stringstream & getData()		{ return _received; }
	string	getHeader(const string & header);
	bool	isIdle()					{ return _request == NULL; }
	bool	setRequest(Request * request);
	const Request * getRequest()		{ return _request; }
	void	setIdle(bool idle = true)	{ _idle = idle; }
	bool	setURL(const string & url);
	
private:
	static size_t write_data_callback(void *buffer, size_t size, size_t nmemb, void *userp);
	static size_t write_header_callback(void *buffer, size_t size, size_t nmemb, void *stream);
	//static size_t read_data_callback(void *buffer, size_t size, size_t nitems, void *userp);
	
	
	string			_url;
	CURL * 			_handle;			// Handle to curl easy interface
	stringstream 	_received;
	headers			_headers;
	bool			_idle;
	const Request *	_request;			// The request the connection is trying to complete 
	
};

#endif /*CONNECTION_H_*/
