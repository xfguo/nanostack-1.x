#include "NetworkEvent.h"
#include "gui/GUI.h"
#include "NetworkController.h"
#include "dataformat/ImageLeaf.h"
#include "EventMonitor.h"
#include <iostream>

static const char * SOUND_SERVER_RESPONSE = "serverresponse";

bool ServerQueryResponseEvent::process(ApplicationContext & context) {
	Node * temp = _node;
	_node = NULL;
	if (temp) {
		context.evmon.requestSound(SOUND_SERVER_RESPONSE);
		context.gui.updateDataBase(temp);
	}
	return true;
}

bool ServerUpdateNodeEvent::process(ApplicationContext & context) {
	context.net.updateServerNode(_node);	// The node will be destroyed naturally in the destructor
	return true;
}

bool ServerQueryImageEvent::process(ApplicationContext & context) {
	context.net.queryServerImage(_nodeid);
	return true;
}
//#include <iostream>
bool ServerQueryImageResponseEvent::process(ApplicationContext & context) {
	if (_image) {
		//cout << "In ServerQueryImageResponseEvent::process " << endl;
		char * image = _image;
		_image = NULL;
		context.gui.updateDataBase(_nodeid, _version, image, _imagesize);
	}
	return true;
}

bool ServerSendOrderFormEvent::process(ApplicationContext & context) {
	context.net.sendOrderForm(_orderer, _supplier, _orderlist);
	return true;
}

bool RemoteQueryImageEvent::process(ApplicationContext & context) {
	context.net.queryRemoteImage(_nodeid, _url, _version);
	return true;
}

bool ServerConnectionStatusChangeEvent::process(ApplicationContext & context)
{
	context.gui.setServerStatus(_status);
	if (_serverurl.length() > 0 && _serverurl.compare(context.net.getServerURL())) {
		context.gui.setServerStatus(false);
		context.net.setServerURL(_serverurl);
		context.net.sendLogin();
	}	
	return true;
}
