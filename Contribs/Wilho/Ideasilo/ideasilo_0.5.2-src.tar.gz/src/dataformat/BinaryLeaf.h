#ifndef BINARYLEAF_H_
#define BINARYLEAF_H_

#include "Leaf.h"

class BinaryLeaf:  public Leaf {
public:
	BinaryLeaf();
	BinaryLeaf(unsigned int version, const string & label);
	virtual ~BinaryLeaf();
	BinaryLeaf(const BinaryLeaf & ot);
	static BinaryLeaf * 	parseXMLToBinaryLeaf(const xmlNode * root, BinaryLeaf * binaryleaf = NULL);
	
	virtual bool 			hasData() const;
	virtual ContentType		getType() const			{ return TYPE_BINARY; }
	virtual const char * 	getTypeString() const 	{ return "binary"; }
	virtual NodeContent *	clone() const;
	
	virtual string			serializeToXML(int indent = 0) const;
	
	void					setData(char * data, size_t size);
	const char * 			getData()				{ return _data; }
	size_t					getSize() const			{ return _size; }
	
protected:
	char * _data;		// malloc() and free() must be used with these
	size_t _size;
};

#endif /*BINARYLEAF_H_*/
