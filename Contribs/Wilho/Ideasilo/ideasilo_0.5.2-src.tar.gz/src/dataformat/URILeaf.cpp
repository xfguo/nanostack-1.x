#include "URILeaf.h"

UriLeaf::UriLeaf() {}

UriLeaf::~UriLeaf() {}

UriLeaf * UriLeaf::parseXMLToUriLeaf(const xmlNode * root, UriLeaf * urileaf) {
	if (!urileaf)
		urileaf = new UriLeaf;
	TextLeaf::parseXMLToTextLeaf(root, urileaf);
	return urileaf;
}

NodeContent * UriLeaf::clone() const {
	return new UriLeaf(*this);
}
