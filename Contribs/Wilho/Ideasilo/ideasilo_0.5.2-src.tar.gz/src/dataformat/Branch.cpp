#include "Branch.h"

#include <iostream>
#include <sstream>

namespace XML {
	const xmlChar * DATASET_TAG = (xmlChar*)"dataset";
	const xmlChar * ENTRY_TAG = (xmlChar*)"entry";
	const xmlChar * KEY_TAG = (xmlChar*)"key";
	const xmlChar * ID_TAG = (xmlChar*)"ID";
	const xmlChar * CHECKSUM_TAG = (xmlChar*)"sha1";
}

Branch::Branch()
{
}

Branch::~Branch()
{
	for (children::const_iterator it = _children.begin(); it != _children.end(); it++) {
		delete it->second;
	}
	_children.clear();
}

Branch::Branch(const Branch & ot) {
	_label = ot._label;
	_version = ot._version;
	for (children::const_iterator it = ot._children.begin(); it != ot._children.end(); it++) {
		if (it->second)
			_children.push_back(child(it->first, new Node(*it->second)));
		else
			_children.push_back(child(it->first,NULL));
	}
}

//bool	Branch::update(NodeContent * newcontent) {
//	if (newcontent->getType() == NodeContent::TYPE_BRANCH) {
//		Branch * newbranch = static_cast<Branch*>(newcontent);
//		for (children::iterator it = newbranch->_children; it != newbranch->_children.end(); it++) {
//			
//		}
//	} else
//		return false;
//}

NodeContent * Branch::clone() const {
	return new Branch(*this);
}

Branch * Branch::parseXMLToBranch(const xmlNode * root) {
	//cout << "Parsing Branch" << endl;
	if (!root)
		return NULL;
	Branch * newbranch = new Branch;
	for (const xmlNode * current = root->children; current; current = current->next) {
		if (current->type == XML_ELEMENT_NODE) {
			Node * newchild = Node::parseXML(current);
			if (newchild) {
				//cout << "...branch had child: " << newchild->getID() << endl;
				if (newchild->getContentType() == NodeContent::TYPE_EMPTY) {
					//cout << ".....child had no defined contents. Saving just the ID." << endl;
					newbranch->_children.push_back(child(newchild->getID(), NULL));
					delete newchild;
				} else {
					//cout << ".....child had defined contents. Saving the node." << endl;
					newbranch->_children.push_back(child(newchild->getID(), newchild));
				}
			}
			
		}
	}

	return newbranch;
}

string Branch::serializeToXML(int indent) const {
	stringstream str;
	if (!_children.empty())
		str << "\n";
	for (children::const_iterator it = _children.begin(); it != _children.end(); it++) {
		if (it->second)
			str << it->second->serializeToXML(indent+1);
		else
			str << Node(it->first).serializeToXML(indent+1);
	}

	return str.str();
}
