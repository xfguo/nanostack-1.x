#ifndef DATABASE_H_
#define DATABASE_H_

#include <pthread.h>
#include <map>
#include "Node.h"

using namespace std;

class DataBase
{
public:
	typedef map<string, Node*> nodes;
	
	DataBase();
	~DataBase();

	const Node * 			get(const string & id) const;
	Node *					get(const string & id);
	Node *					getCopy(const string & id, int depth = 0) const;
	const nodes &			getNodes() const				{ return _nodes; }
	bool					update(Node * newnode);
	bool					update(const string & nodeid, unsigned int version, char * data, size_t datalen);
	//bool 					insert(DataNode* newnode);
	Node * 					detach(const string & id);
	void					clear();

private:
	void					assimilate(Node * root);
	
	nodes _nodes;
	mutable pthread_mutex_t _lock;
};

#endif /*DATABASE_H_*/
