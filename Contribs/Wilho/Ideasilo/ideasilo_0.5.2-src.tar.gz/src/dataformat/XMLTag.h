#ifndef XMLTAG_H_
#define XMLTAG_H_

#include <libxml/parser.h>

namespace XML {
	namespace ATTRIB {
		extern const xmlChar * FORMAT;
	}

	namespace ELEMENT { 
		extern const xmlChar * TEXT;
		extern const xmlChar * IMAGE;
		extern const xmlChar * URI;
		extern const xmlChar * BINARY;
	};

	
};

#endif /*XMLTAG_H_*/
