#include "XMLTag.h"

namespace XML {
	namespace ATTRIB {
		const xmlChar * FORMAT = (xmlChar*)"format";
	}

	namespace ELEMENT { 
		const xmlChar * TEXT = (xmlChar*)"text";
		const xmlChar * IMAGE = (xmlChar*)"image";
		const xmlChar * URI = (xmlChar*)"uri";
		const xmlChar * BINARY = (xmlChar*)"binary";
	};
};
