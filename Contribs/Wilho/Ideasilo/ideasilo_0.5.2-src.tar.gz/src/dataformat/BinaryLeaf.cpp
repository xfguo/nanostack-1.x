#include "BinaryLeaf.h"

#include <sstream>
#include <gsasl.h>		// For base64 decoding
#include "util/Util.h"


BinaryLeaf::BinaryLeaf():
	_data(NULL),
	_size(0)
{ 	
}

BinaryLeaf::BinaryLeaf(unsigned int version, const string & label):
	Leaf(version, label),
	_data(NULL),
	_size(0)
{
}

BinaryLeaf::~BinaryLeaf() {
	// Free must be used to free the memory, because malloc was used to allocate it
	if (_data)
		free(_data);
}

BinaryLeaf::BinaryLeaf(const BinaryLeaf & ot)
{
	_label = ot._label;
	_version = ot._version;
	if (ot._data) {
		_size = ot.getSize();
		_data = (char*)malloc(sizeof(char)*_size);
		memcpy(_data, ot._data, _size);
	} else {
		_data = NULL;
		_size = 0;
	}
}

bool BinaryLeaf::hasData() const {
	if (_data)
		return true;
	else
		return false;
}


BinaryLeaf * BinaryLeaf::parseXMLToBinaryLeaf(const xmlNode * root, BinaryLeaf * binaryleaf) {
	if (!binaryleaf)
		binaryleaf = new BinaryLeaf;
	stringstream base64codestream;
	for (const xmlNode * current = root->children; current; current = current->next) {
		if (current->type == XML_CDATA_SECTION_NODE)
			base64codestream << (char*)current->content; // IS THIS RIGHT?
	}
	//cout << "BinaryLeaf::parseXMLToBinaryLeaf: data: " << base64code.str() << endl;
	string base64code = base64codestream.str();
	// Due to offhanded libgsasl code, the input must be filtered out of whitespace characters
	Util::filterString(base64code, "\n \t\r");
	if (base64code.length() > 0) {
		char * binarydata = NULL;
		size_t binarydatalen = 0;
		int result = gsasl_base64_from(base64code.c_str(), base64code.length(), &binarydata, &binarydatalen);
		if (result == GSASL_OK && binarydatalen > 0) {
			//cout << "BinaryLeaf::parseXMLToBinaryLeaf: parse base64code success" << endl;
			binaryleaf->_data = binarydata;
			binaryleaf->_size = binarydatalen;
			
		} else {
			//cout << "BinaryLeaf::parseXMLToBinaryLeaf: parse base64code fail: " << base64code.length() << endl;
		}
	}
	return binaryleaf;
}

string BinaryLeaf::serializeToXML(int indent) const {
	if (_data) {
		stringstream base64;
		char * base64c = NULL;
		size_t base64len = 0;
		int result = gsasl_base64_to(_data, _size, &base64c, &base64len);
		if (result == GSASL_OK && base64len > 0) {
			base64 << "<![CDATA[" << base64c << "]]>";
			free(base64c);
			return base64.str();
		} 
	} 
	return "";
}

NodeContent * BinaryLeaf::clone() const {
	return new BinaryLeaf(*this);
}

void BinaryLeaf::setData(char * data, size_t size) {
	if (!data)
		return;
	if (_data)
		free(_data);
	_data = data;
	_size = size;
		
}
