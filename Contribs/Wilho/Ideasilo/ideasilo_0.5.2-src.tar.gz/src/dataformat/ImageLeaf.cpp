#include "ImageLeaf.h"
#include <sstream>
#include "util/widgethandler.h"
#include "XMLTag.h"

ImageLeaf::ImageLeaf():
	_image(NULL),
	_format("")
{	
}

ImageLeaf::ImageLeaf(unsigned int version, const string & label):
	BinaryLeaf(version, label),
	_image(NULL),
	_format("")
{
}


ImageLeaf::~ImageLeaf()
{	
	if (_image)
		g_object_unref(_image);
}

#include <iostream>
ImageLeaf::ImageLeaf(const ImageLeaf & ot) {
	_label = ot._label;
	_version = ot._version;
	if (ot._data) {
		_size = ot.getSize();
		_data = (char*)malloc(sizeof(char)*_size);
		memcpy(_data, ot._data, _size);
	} else {
		_data = NULL;
		_size = 0;
	}
	_remoteurl = ot._remoteurl;
	_format = ot._format;
	if (ot._image) {
		_image = ot._image;
		g_object_ref(_image);
	} else {
		_image = NULL;
	}
}

bool ImageLeaf::hasData() const {
	if (_image || _remoteurl.length() > 0)
		return true;
	if (!BinaryLeaf::hasData())
		return false;
	if (initImage())
		return true;
	else
		return false;
}

ImageLeaf * ImageLeaf::parseXMLToImageLeaf(const xmlNode * root, ImageLeaf * imageleaf) {
	if (!imageleaf)
		imageleaf = new ImageLeaf;
	BinaryLeaf::parseXMLToBinaryLeaf(root, imageleaf);
	
	for (const xmlAttr * curattr = root->properties; curattr; curattr = curattr->next) {
		if (curattr->type == XML_ATTRIBUTE_NODE) {
			if (xmlStrEqual(curattr->name, XML::ATTRIB::FORMAT)) {
				imageleaf->_format = (char*)curattr->children->content;
			}
		}
	}
	stringstream remoteurl;
	for (const xmlNode * current = root->children; current; current = current->next) {
		if (current->type == XML_ELEMENT_NODE)
			if (xmlStrEqual(current->name, XML::ELEMENT::URI)) {
				for (const xmlNode * current2 = current->children; current2; current2 = current2->next) 
					if (current2->type == XML_TEXT_NODE)
						remoteurl << (char*)current2->content;
				break;
			}
	}
	if (remoteurl.str().length() > 0) {
		imageleaf->_remoteurl = remoteurl.str();
	}
	//cout << "ImageLeaf::parseXMLToImageLeaf: remoteurl: " << imageleaf->_remoteurl << endl;
	return imageleaf;
}



string ImageLeaf::serializeAttributesToXML() const {
	stringstream xml;
	xml << NodeContent::serializeAttributesToXML();
	xml << XML::ATTRIB::FORMAT << "=\"" << _format << "\" ";
	return xml.str();
}

string ImageLeaf::serializeToXML(int indent) const {
	stringstream xml;
	if (_remoteurl.length() > 0)
		xml << "<uri>" << _remoteurl << "</uri>";
	xml << BinaryLeaf::serializeToXML();
	return xml.str();
}
//
//void ImageLeaf::setImage(GdkPixbuf * newimage) {
//	if (!newimage)
//		return;
//	if (_image)
//		g_object_unref(_image);
//	_image = newimage;
//	//g_object_ref(_image);
//}

GdkPixbuf * ImageLeaf::getImage() {
	if (_image)
		return _image;
	else
		return initImage();
}

const GdkPixbuf * ImageLeaf::getImage() const {
	if (_image)
		return _image;
	else
		return initImage();
}

GdkPixbuf * ImageLeaf::initImage() const {
	if (_data) {
		_image = WidgetUtil::loadImage(_data, _size);
	}
	if (_image)
		return _image;
	else
		return NULL;
}


//
//GdkPixbuf * ImageLeaf::detachImage() {
//	GdkPixbuf * temp = _image;
//	_image = NULL;
//	return temp;
//}

NodeContent * ImageLeaf::clone() const {
	return new ImageLeaf(*this);
}

//bool ImageLeaf::update(NodeContent * newcontent) {
//	if (newcontent && newcontent->getType() == NodeContent::TYPE_IMAGE) {
//		ImageLeaf * newimageleaf = static_cast<ImageLeaf*>(newcontent);
//		if (_data == NULL && newimageleaf->getData() != NULL) {
//			_data = newimageleaf->_data;
//			_size = newimageleaf->_size;
//			newimageleaf->_data = NULL;
//			newimageleaf->_size = 0;
//			return true;
//		} 
//	}
//	return false;
//}

bool ImageLeaf::update(char * data, size_t datalen) {
	if (!data || datalen == 0)
		return false;
	if (_image) {
		g_object_unref(_image);
		_image = NULL;
	}
	if (_data) {
		free(_data);
		_data = NULL;
	}
	_data = data;
	_size = datalen;
	return true;
}
