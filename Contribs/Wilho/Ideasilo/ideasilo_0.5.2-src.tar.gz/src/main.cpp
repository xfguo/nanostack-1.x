#include "main.h"

#include <signal.h>
#include <curl/curl.h>	// For initializing libcurl
#include <stdlib.h>
#include <errno.h>
#include "localisation.h"
#include "EventMonitor.h"
#include "event/ApplicationEvent.h"
#include "AppData.h"

using namespace std;

EventMonitor * 			_evmon = NULL;
AppData * 				_appdata = NULL;

void 		error(const char * msg, int erno);
void 		sig_interrupt();
void 		sig_child_terminated();

int main( int argc, char* argv[] )
{
	gtk_init(&argc, &argv);	// Init Gtk. Bad things will happen if you don't. Btw, the initial command line parameters are modified.
	g_thread_init(NULL);	// Obligatory initializations to make gtk thread-safe
	gdk_threads_init();		// Obligatory initializations to make gtk thread-safe
	LIBXML_TEST_VERSION;	// Init the xml-parsing library libxml

    // Set up a handler for keyboard interrupt signal
    if((signal(SIGINT, (sighandler_t)sig_interrupt)) == SIG_ERR) {
    	cerr << "Warning! Could not install interrupt signal handler" << endl;
    }

	
	// Process command line arguments and create a nice list of them
	list<string> args;
	for (int n=1; n < argc; ++n) {
		args.push_back(argv[n]);
	}
	
	_appdata = new AppData(args);
	// Initialize libcurl
	if (CURLcode curlresult = curl_global_init(CURL_GLOBAL_ALL))
		_appdata->fatal_error("Error initializing libcurl.", curlresult);
	
    // Set up the event monitor
	_evmon = new EventMonitor(_appdata);
	int result;
	if ((result = _evmon->init()))
		_appdata->fatal_error("Error initializing event monitor.", result);
  	if ((result = _evmon->start(NULL)))
  		_appdata->fatal_error(_evmon->startErrMsg(result, "EventMonitor").c_str(), result);
  	_evmon->join(NULL);
  	
  	// Clean up and exit gracefully
	delete _evmon;
	_evmon = NULL;

	xmlCleanupParser();							// Clean up the XML parser
  	curl_global_cleanup();						// Clean up curl library
  	delete _appdata;
  	cout << "Shutting down gracefully..." << endl;
  	
  	return 0; 
}

void sig_interrupt() {
	if (_evmon) {
		_evmon->kill(0);
	} else {
		exit(1);
	}
}





