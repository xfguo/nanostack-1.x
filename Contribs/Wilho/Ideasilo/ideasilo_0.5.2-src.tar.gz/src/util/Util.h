#ifndef UTIL_H_
#define UTIL_H_

#include <string>

using namespace std;

namespace Util {
	void 	filterString(string & str, const string & filterchars); 
	bool 	stringEndsWith(const string & str, const string & end);
	int 	compareNoCase(const string & s1, const string& s2);
	int		copyFile(const string & source, const string & destination);
}

#endif /*UTIL_H_*/
