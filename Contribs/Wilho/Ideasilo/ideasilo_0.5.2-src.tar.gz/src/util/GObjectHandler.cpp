#include "GObjectHandler.h"

#include <iostream>

GObjectHandler::~GObjectHandler()
{
	//cout << "In GObjectHandler::~GObjectHandler" << endl;
	releaseObjects();
	releaseXMLs();
	//cout << "Leaving GObjectHandler::~GObjectHandler" << endl;
}


bool GObjectHandler::hasObject(int objectid) {
	return _objects.find(objectid) != _objects.end();
}

GObject* GObjectHandler::getObject(int objectid) {
	objects::iterator wit = _objects.find(objectid);
	if (wit != _objects.end())
		return wit->second;
	else
		return NULL;
}

GtkWidget * GObjectHandler::getWidget(int widgetid) {
	GObject * object = getObject(widgetid);
	if (object && GTK_IS_WIDGET(object)) {
		return GTK_WIDGET(object);
	} else
		return NULL;
}

bool GObjectHandler::hasXML(int xmlid) {
	return _xmls.find(xmlid) != _xmls.end(); 
}

GladeXML* GObjectHandler::getXML(int xmlid) {
	objectxmls::iterator it = _xmls.find(xmlid);
	if (it != _xmls.end())
		return it->second;
	else
		return NULL;
}

void GObjectHandler::registerObject(int objectid, const char * tag) {
	GObject * widget = G_OBJECT(glade_xml_get_widget(_xmls[objectid], tag));
	g_object_ref(widget);
	_objects[objectid] = widget;
}

void GObjectHandler::registerObject(int objectid, GObject * object) {
	g_object_ref(object);
	_objects[objectid] = object;
}

void GObjectHandler::registerObject(int objectid, GtkWidget * object) {
	registerObject(objectid, G_OBJECT(object));
}

void GObjectHandler::releaseObjects() {
	//cout << "start NodeView::releaseWidgets" << endl;
	for (objects::iterator it = _objects.begin(); !_objects.empty(); it = _objects.begin()) {
		if (it->second) {
			if (GTK_IS_WIDGET(it->second)) {
				gtk_object_sink(GTK_OBJECT(it->second));
				gtk_widget_destroy(GTK_WIDGET(it->second));
			}
			g_object_unref(it->second);
		}
		_objects.erase(it);
	}
	//cout << "end NodeView::releaseWidgets" << endl;
}

void GObjectHandler::releaseXMLs() {
	for (objectxmls::iterator it = _xmls.begin(); !_xmls.empty(); it = _xmls.begin()) {
		if (it->second)
			g_object_unref(it->second);
		_xmls.erase(it);
	}
}

void GObjectHandler::registerXML(int xmlid, GladeXML * xml) {
	objectxmls::iterator it = _xmls.find(xmlid);
	if (it != _xmls.end() && it->second)
		g_object_unref(it->second);
	_xmls[xmlid] = xml;
}

