#include "Logger.h"
#include <time.h>

Logger::Logger(const char * filename):
_filename(filename),
_disable(false)
{
	pthread_mutex_init( &_lock, NULL);
	remove(_filename);
	_file = fopen(_filename, "a");
}

Logger::~Logger()
{
	pthread_mutex_lock( &_lock );
	fclose(_file);
	_file = NULL;
	pthread_mutex_unlock( &_lock );
}

void Logger::write(const string & msg, int erno) {
	if (_disable || !_file)
		return;
	
	pthread_mutex_lock( &_lock );
	time_t tim = time(NULL);
	struct tm * timept = localtime(&tim);
	char timestr[30];
	strftime(timestr, 29, "%Y %b %d %a %H:%M:%S", timept);
	fprintf(_file, "%s: ", timestr);
	if (erno) 
		fprintf(_file, "ERROR (%d): ", erno);
	fprintf(_file, "%s\n", msg.c_str());
	fflush(_file);
	pthread_mutex_unlock( &_lock );
}
