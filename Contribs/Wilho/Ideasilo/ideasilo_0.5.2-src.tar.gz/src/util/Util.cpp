#include "Util.h"
#include <iostream>
#include <errno.h>

void Util::filterString(string & str, const string & filterchars) {
	string::iterator it = str.begin();
	int len = filterchars.length();
	if (len == 0)
		return;
	while (it != str.end()) {
		for (unsigned int n = 0; n < filterchars.length(); n++) {
			if (*it == filterchars[n]) {
				it = str.erase(it);
				it--;
				break;
			}
		}
		++it;
	}
	
}

bool Util::stringEndsWith(const string & str, const string & end) {
	if (end.length() > str.length())
		return false;
	return !end.compare(str.substr(str.length()-end.length(), end.length())); 
}

int Util::compareNoCase(const string & s1, const string& s2) 
{
  string::const_iterator it1=s1.begin();
  string::const_iterator it2=s2.begin();

  //stop when either string's end has been reached
  while ( (it1!=s1.end()) && (it2!=s2.end()) ) 
  { 
    if(::toupper(*it1) != ::toupper(*it2)) //letters differ?
     // return -1 to indicate smaller than, 1 otherwise
      return (::toupper(*it1)  < ::toupper(*it2)) ? -1 : 1; 
    //proceed to the next character in each string
    ++it1;
    ++it2;
  }
  size_t size1=s1.size(), size2=s2.size();// cache lengths
   //return -1,0 or 1 according to strings' lengths
    if (size1==size2) 
      return 0;
    return (size1<size2) ? -1 : 1;
}

int Util::copyFile(const string & source, const string & destination) {	
	FILE * in = fopen( source.c_str(), "r" );
	if (!in) {
		return errno;
    }
	FILE * out = fopen( destination.c_str(), "w" );
    if (!out) {
    	return errno;
    }
    int c;
    while((c = getc(in)) != EOF)
    	putc(c,out);
    fclose(in);
    fclose(out);
    return 0;
}


