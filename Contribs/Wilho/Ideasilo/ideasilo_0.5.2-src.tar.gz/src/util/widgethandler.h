#ifndef WIDGETHANDLER_H_
#define WIDGETHANDLER_H_

#include <gtk/gtk.h>
#include <glade/glade.h>
#include <sstream>
#include <string>

using std::stringstream;
using std::string;

class PackingSettings {
public:
	PackingSettings():expand(false), fill(false), padding(0), packtype(GTK_PACK_START) {}
	
	gboolean expand;
	gboolean fill;
	unsigned int padding;
	GtkPackType packtype;	
};

class TablePackingSettings {
public:

	TablePackingSettings():xoptions((GtkAttachOptions)0), yoptions((GtkAttachOptions)0), xpadding(0), ypadding(0) {}
	TablePackingSettings(GtkWidget * table, int x, int y); 
	
	void define(GtkWidget * table, int x, int y);
	void define(GtkTableChild * child);

	GtkAttachOptions xoptions;
	GtkAttachOptions yoptions;
	guint16 xpadding;
	guint16 ypadding;
};

namespace WidgetUtil {

	void attachToTable(GtkTable * table, GtkWidget * widget, 
		int left, int right, int top, int bottom, TablePackingSettings settings);
	void setTextViewData(GtkTextView * textview, const char * text);
	string getTextViewData(GtkTextView * textview);
	void destroyWidget(GtkWidget * widget);
	void destroyAndForget(GtkWidget *& widget);
	void unrefAndForget(GladeXML *& gladexml);
	void unrefAndForget(GtkWidget *& widget);
	
	bool disable_event(GtkWidget * widget, gpointer something);
	GdkPixbuf * loadImage(const stringstream & stream);
	GdkPixbuf * loadImage(const char * stream, size_t len);
}

namespace GdkThread {
	void enter();
	void leave();
}

#endif /*WIDGETHANDLER_H_*/
