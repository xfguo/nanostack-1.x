#include "Thread.h"
#include <errno.h>
#include <sstream>
#include <iostream>

Thread::Thread():
_arg(NULL),
_handle(0),
_alive(false),
_killed(true),
_initcode(-1),
_exitcode(0)
{
	pthread_cond_init(&_killedcondition,NULL);
	pthread_mutex_init(&_lock,NULL);
}

Thread::~Thread() {}

int Thread::start(void * arg) {
	if (_initcode < 0) {
		cerr << "Thread must be succesfully initialized before it can be started" << endl;
		return EAGAIN;
	}
		
	setArg(arg);
	_killed = false;
	int result = pthread_create(&_handle, NULL, Thread::entrypoint, this);	
	if (result)
		_killed = true;
	return result;
}

int Thread::join(void ** exit_value) {
	return pthread_join(_handle, exit_value);
}

// STATIC
void * Thread::entrypoint(void * pthis) {
	Thread * thread = static_cast<Thread*>(pthis);
	thread->execute();
	return NULL;
}

void Thread::execute() {
	_alive = true;
	_exitcode = run();
	_alive = false;
	_killed = true;
}

string Thread::startErrMsg(int code, const char * module) {
	stringstream msg;
	msg << "Failed to start " << string(module);
	switch (code) {
		case EAGAIN:
			msg << ": System lacks resources to create thread.\n";
			return msg.str();
		case EINVAL:
			msg << ": Invalid attribute.\n";
			return msg.str();
		case EPERM:
			msg << ": No appropriate permissions to set scheduling.\n";
			return msg.str();
		default:
			msg << ": Unspecified error code " << code << ". This is bad.\n";
			return msg.str();
	}
}

void Thread::wait(unsigned long msec) {
	if (!_killed) {
		pthread_mutex_lock(&_lock);
		timespec limit;
		unsigned int sec = (unsigned int)(msec / 1000);
		msec -= sec * 1000;
		clock_gettime(CLOCK_REALTIME, &limit);
		limit.tv_sec += sec;
		limit.tv_nsec += msec * 1000000;
		pthread_cond_timedwait(&_killedcondition, &_lock, &limit);
		
		pthread_mutex_unlock(&_lock);
	}
}
