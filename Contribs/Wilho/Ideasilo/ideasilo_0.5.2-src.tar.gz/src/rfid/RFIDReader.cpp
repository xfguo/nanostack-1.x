#include "RFIDReader.h"

#include <errno.h>
#include <string>
#include <sstream>
#include "gui/GUI.h"
#include <iostream> //DEBUG
#include "RFIDEvent.h"
#include <dirent.h>	// for looking up the lock file


#ifndef LIBNRP_H
#include "libnRP/libnRP.h"
#endif

#include <sys/stat.h>	// For finding out info about the nRouted lock file and /dev/ttyUSB0
#include <unistd.h>		// For fork and exec
#include <signal.h>		// For SIGKILL

const char * NROUTE_STATUS_CONNECT_ERROR = "Could not connect to nRouted";
const char * NROUTE_STATUS_SOCKET_CREATION_ERROR = "Could not create socket for nRoute connection";
const char * NROUTE_STATUS_CONFIG_CREATION_ERROR = "Could not create nRouted configuration";
const char * NROUTE_STATUS_CONFIG_ERROR = "Could not configure nRouted";
const char * NROUTE_STATUS_READY = "nRouted is ready";



const char * SOUND_RFID_READ = "rfidread";
const char * SOUND_RFID_READ_FAIL = "rfidreadfail";

const unsigned char NDEF_TERMINATOR = 0xFE;
const unsigned char NDEF_START = 0xE1;

NRPPacket::NRPPacket():rbuf(0), data(0) {
	clear();
}

NRPPacket::~NRPPacket() {
	if (rbuf) {
		delete rbuf;
	}
	if (data) {
		delete data;
	}
}

void NRPPacket::clear() {
	if (rbuf) {
		delete rbuf;
	}
	if (data) {
		delete data;
	}
	memset(this,0,sizeof(this));
	rbuf = new unsigned char[BUFFER_SIZE];
	data = new unsigned char[BUFFER_SIZE];
	prot = 0xFF;
}

NDEFMessage::NDEFMessage():
_header(0),
_typelen(0),
_idlen(0),
_payloadlen(0),
_type(NULL),
_id(NULL),
_payload(NULL)
{
}

NDEFMessage::~NDEFMessage() {
	delete _type;
	delete _id;
	delete _payload;
}

NDEFMessage* NDEFMessage::parse(const unsigned char * data, unsigned long len) {
	unsigned int n;
	for (n=0; n < len && data[n] != NDEF_START; n++);
	if (n + 6 > len) {
		cerr << "Error! Corrupted NDEF Message. Too short" << endl;
		return NULL;
	}
	n++;
	if (data[len-1] != NDEF_TERMINATOR) {
		cerr << "Error! Corrupted NDEF Message. Message did not end with terminator byte." << endl;
		return NULL;
	}
	NDEFMessage * newmsg = new NDEFMessage;
	newmsg->_ndefversion = data[n++];
	newmsg->_memorysize = data[n++];
	newmsg->_rwaccess = data[n++];
	newmsg->_vfieldtype = data[n++];
	newmsg->_vfieldlen = data[n++];
	if (newmsg->_vfieldlen >= len - n) {
		cerr << "Error! Corrupted NDEF Message. Reported V field size too large. " << newmsg->_vfieldlen << " " << len << " " << n << endl;
		delete newmsg;
		return NULL;
	}
	newmsg->_header = data[n++];
	newmsg->_typelen = data[n++];
	newmsg->_type = new unsigned char[newmsg->_typelen];
	if (newmsg->isSet(NDEFMessage::SHORT_RECORD)) {
		newmsg->_payloadlen = data[n++];
		newmsg->_payload = new char[newmsg->_payloadlen+1];	// Room for a null byte
	} else {
		cerr << "Warning! Payload length not designated short. Recheck endianness." << endl;
		delete newmsg;
		return NULL;
	}
	if (newmsg->isSet(NDEFMessage::ID_LEN)) {
		newmsg->_idlen = data[n++];
		newmsg->_id = new unsigned char[newmsg->_idlen];
	}
	unsigned int x;
	for (x = 0; x < newmsg->_typelen; x++)
		newmsg->_type[x] = data[n++];
	for (x = 0; x < newmsg->_idlen; x++)
		newmsg->_id[x] = data[n++];
	for (x = 0; x < newmsg->_payloadlen; x++)
		newmsg->_payload[x] = data[n++];
	newmsg->_payload[x] = '\0';			// Append a null byte, just in case
	return newmsg;
}



RFIDReader::RFIDReader(AppData * appdata, EventBuffer::Writer * writer, SettingHandler & appsettings):
_appdata(appdata),
_writer(writer),
_appsettings(appsettings),
_retrywait(0),
_failcount(0),
_sockfd(0)
{
	memset(&srvaddr, 0, sizeof(srvaddr));
	srvaddr.sin_family = AF_INET;
	srvaddr.sin_port = htons(21870);
	inet_pton(AF_INET,"127.0.0.1", &srvaddr.sin_addr);
	_pfds.events = POLLIN | POLLPRI | POLLERR | POLLHUP | POLLNVAL;
	// Search for sound effects
	loadSounds(string(_appdata->datapath) + "sound/");
}

RFIDReader::~RFIDReader()
{
	if (_sockfd) {
		shutdown(_sockfd, SHUT_RDWR);
		_sockfd = 0;
	}

}

void RFIDReader::raiseTestMsg_v2(const string & nodeid) {
	stringstream xml;
	xml << "<branch ID=\"" << nodeid << "\"/>";
	Node * newnode = Node::parseXML(xml.str());
	raiseRFIDReadEvent(newnode);
}

bool RFIDReader::raiseRFIDReadEvent(Node * newnode) {
	string soundfile;
	bool result = true;
	if (newnode) {
		if (newnode->getID().length() > 0) {
			requestSound(SOUND_RFID_READ);
			RFIDReadEvent * ev = new RFIDReadEvent(newnode);
			_writer->push(ev);
		} else {
			requestSound(SOUND_RFID_READ_FAIL);
		}
	} else {
		result = false;
		requestSound(SOUND_RFID_READ_FAIL);
	}	
	return result;
}

void RFIDReader::setNRouteAvailable(bool available, bool running) {
	if (!available)
		_nroute_status = NROUTE_NOT_AVAILABLE;
	else if (!running)
		_nroute_status = NROUTE_AVAILABLE;
	else if (_nroute_status != NROUTE_CONNECTION_READY)
		_nroute_status = NROUTE_RUNNING;
}

bool RFIDReader::nRoutedStatusUpdate() {
	
	if (_nroute_status == NROUTE_NOT_AVAILABLE) {
		//cout << "RFIDReader::nRoutedStatusUpdate: nRoute is not available, doing nothing" << endl;
		return false;
	} else if (_nroute_status == NROUTE_CONNECTION_READY) {
		//cout << "RFIDReader::nRoutedStatusUpdate: nRoute connection is already ready, doing nothing" << endl;
		_retrywait = 0;
		return true;
	} else  {
		if (--_retrywait < 0) {
			if (_nroute_status == NROUTE_AVAILABLE) {
				cout << "RFIDReader::nRoutedStatusUpdate: nRoute is available, but not started. Trying to start" << endl;
				_writer->push(new NRouteStartRequestEvent());
				_retrywait = 5;
				return false;
			} else if (_nroute_status == NROUTE_RUNNING) {
				cout << "RFIDReader::nRoutedStatusUpdate: nRoute is running, trying to configure" << endl;
				const char * msg;
				if (!nRoutedConfigure(&msg)) {
					cout << "RFIDReader::nRoutedStatusUpdate: configure succeeded" << endl;
					_retrywait = 0;
					_writer->push(new ReaderConnectionStatusChangeEvent(true, true, true, msg));
					return true;
				} else {
					cout << "RFIDReader::nRoutedStatusUpdate: configure failed, retrying..." << endl;
					_retrywait = 10;
					if (++_failcount > 2) {
						_writer->push(new NRouteTerminationEvent());
						_nroute_status = NROUTE_NOT_AVAILABLE;
						_failcount = 0;
					} else {
						_writer->push(new ReaderConnectionStatusChangeEvent(true, true, false, msg));
					}
					return false;
				}	
			}
		}
		return false;
	} 
	
}

int RFIDReader::nRoutedConfigure(const char ** message) {
	// Open a TCP socket.
	if (!_sockfd && (_sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		*message = NROUTE_STATUS_SOCKET_CREATION_ERROR;
		return errno;
	}
	
	_pfds.fd = (int)(_sockfd);
	
	// Connect to nRouted.
	if((connect(_sockfd, (struct sockaddr *)&srvaddr, sizeof(srvaddr))) != 0) {
		*message = NROUTE_STATUS_CONNECT_ERROR;
		return -1;
    }
	//if((rval = libnrp_create_conf_pkt(sndbuf_conf, PROTO_IEEE_802_15_4_RAW, NULL, NULL, ADDR_UNDEFINED, NULL, PORT_UNDEFINED)) == -1) {
	int result;
	unsigned char sndbuf_conf[128];
	if((result = libnrp_create_conf_pkt(sndbuf_conf, PROTO_6LOWPAN, NULL, NULL, ADDR_UNDEFINED, NULL, PORT_UNDEFINED)) == -1) {
		*message = NROUTE_STATUS_CONFIG_CREATION_ERROR;
		return -2;
    }
	write(_sockfd, sndbuf_conf, 13);
	// Read the configuration reply.
	unsigned char rbuf[128];
	int bytes = read(_sockfd, rbuf, 128);
	if((result = libnrp_check_nRoute_reply(rbuf, bytes)) != 1) {
		*message = NROUTE_STATUS_CONFIG_ERROR;
		return -3;
	}
	_nroute_status = NROUTE_CONNECTION_READY;
	*message = NROUTE_STATUS_READY;
	return 0;
}


string RFIDReader::getTimeString()
{
	struct timeval now;
 	struct tm* ptm;
	char str[64], time_str[128];
	
	gettimeofday(&now, NULL);
 	ptm = localtime (&now.tv_sec);
	strftime (str, sizeof (str), "%H:%M:%S", ptm);	// Format time down to a single second. 
 	long msec = now.tv_usec / 1000; // Compute milliseconds from microseconds.
	sprintf(time_str,"%s.%03ld",str,msec);
	return time_str;
}

int RFIDReader::setup() {
	//_appdata->log->write("RFID reader thread: Initializing...");
	_appdata->log->write("RFID reader thread: Nothing to initialize.");
	return 0;
}


int RFIDReader::run() {
	_appdata->log->write("RFID reader thread: Running...");
	//if (_nrouted_status == NROUTED_READY)
	//	_writer->push(new ReaderConnectionStatusChangeEvent(true));
	while(!is_killed()) {
		SoundController::checkRequests();		// Check for requested sound effects
		if (!nRoutedStatusUpdate()) {
			this->wait(200);
		} else {	// nRouted is ready and configured
			int result = 0;
			//while (result == 0 && !is_killed()) {
			result = poll(&_pfds, 1, 250);
			//} 
			if (result < 0) {
				if (!handlePollingError(errno))
					kill();
			} else if (result > 0) {
				//cout << "RFID-lukija toimii! Return code: "<< pfds.revents << endl;
				// There is something readable in the buffer
				NRPPacket packet;
				packet.len = read(_sockfd, packet.rbuf, 256);
				if(packet.len > 0) { // check whether got some bytes
					cout << "------ Received packet from nRoute -------" << endl;
					packet.timestamp = getTimeString();
//					cout << endl << "Timestamp: " << packet.timestamp << " Format: ";
//					for(j=0;j<=2;j++)
//						cout << packet.rbuf[j];
					libnrp_parse_nrp_hdr(packet.rbuf, packet.len, packet.data,&packet.d_len,
							&packet.prot,packet.s_addr,&packet.s_type,packet.d_addr,&packet.d_type,
							&packet.s_port,&packet.d_port,&packet.siglvl,&packet.seq);
		
					if (packet.d_len != 0) {				
						NDEFMessage * msg = NDEFMessage::parse(packet.data, packet.d_len);
						if (msg) {
							static int n = 0;
							cout << "Received an NDEF message (" << n++ << ") from nRouted, payload length: " << msg->getLength() << " Payload: " << endl;
							cout << msg->toString() << endl;
							Node * newnode = Node::parseXML(msg->toString());
							raiseRFIDReadEvent(newnode);					
							delete msg;
						}						
					}
				}
			}
		}
	}

	close(_sockfd);
	_appdata->log->write("RFID reader thread: Stopped");

	return(1);
}

bool RFIDReader::handlePollingError(int error) {
	if (error == EINTR) {
		return true;
	} else {
		cerr << "Error (" << errno << ") occurred while polling RFID" << endl;
		return false;
	}

}

