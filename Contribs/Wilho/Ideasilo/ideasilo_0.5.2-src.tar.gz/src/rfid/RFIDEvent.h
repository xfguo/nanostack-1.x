#ifndef RFIDEVENT_H_
#define RFIDEVENT_H_

#include <string>
#include "event/Event.h"
#include "dataformat/Node.h"

using namespace std;

class RFIDReadEvent: public Event
{
public:
	RFIDReadEvent(Node * newnode):_node(newnode) {}
	virtual ~RFIDReadEvent()	{ delete _node; }
	
	virtual bool process(ApplicationContext & context);
	Node * detach();
	
private:
	Node * _node;
};

class NRouteTerminationEvent : public Event
{
public:
	NRouteTerminationEvent() { }
	virtual ~NRouteTerminationEvent() { }
	
	virtual bool process(ApplicationContext & context);

};

class NRouteRestartRequestEvent : public Event
{
public:
	NRouteRestartRequestEvent() { }
	virtual ~NRouteRestartRequestEvent() { }
	
	virtual bool process(ApplicationContext & context);

};

class NRouteStartRequestEvent : public Event
{
public:
	NRouteStartRequestEvent() { }
	virtual ~NRouteStartRequestEvent() { }
	
	virtual bool process(ApplicationContext & context);

};


class ReaderConnectionStatusChangeEvent : public Event
{
public:
	ReaderConnectionStatusChangeEvent(bool nroute_available, bool nroute_running, bool connection_ready, const string & statusmsg):
		_nroute_available(nroute_available), 
		_nroute_running(nroute_running),
		_connection_ready(connection_ready),
		_statusmsg(statusmsg) {}
	virtual ~ReaderConnectionStatusChangeEvent() {}
	
	virtual bool process(ApplicationContext & context);
	
private:
	bool 		_nroute_available;
	bool		_nroute_running;
	bool		_connection_ready;
	string		_statusmsg;
};



#endif /*RFIDEVENT_H_*/
