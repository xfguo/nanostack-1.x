The RFID reader's PCB was designed using CadSoft's Eagle Layout Editor.

www.cadsoftusa.com

Open file "passive_template_v1_2.sch" for RFID reader's schematic layout
and file "passive_template_v1_2.brd" for board layout.