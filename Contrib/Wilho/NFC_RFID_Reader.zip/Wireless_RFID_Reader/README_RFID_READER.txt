
****************************************************

	            RFID Reader

	Contents of the development material

****************************************************


 Hardware

 - Document files of the component list and layout
   for the RFID reader's printed circuit board.

 - JPG pictures of the schematics.

 - The PCB schematic files designed with Cadsoft's
   Eagle Layout Editor.


 Software

 - Software for the RFID reader's NanoModule.

 - A document file descriping the software
   with compiling and installation instructions.


 Instructions

 - Brief user instructions of how to use the RFID reader.
